import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        double double0 = org.apache.commons.math.special.Gamma.GAMMA;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.5772156649015329d + "'", double0 == 0.5772156649015329d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        double double1 = org.apache.commons.math.util.FastMath.asinh((-1.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8813735870195429d) + "'", double1 == (-0.8813735870195429d));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.000000000000002d + "'", double1 == 10.000000000000002d);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        double double1 = org.apache.commons.math.special.Gamma.digamma((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5772156677920679d) + "'", double1 == (-0.5772156677920679d));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ((double) 0.0f, (double) (short) -1);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        int int1 = org.apache.commons.math.util.FastMath.round((float) ' ');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 32 + "'", int1 == 32);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        double double1 = org.apache.commons.math.util.FastMath.sinh(10.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11013.232874703393d + "'", double1 == 11013.232874703393d);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        int int2 = org.apache.commons.math.util.FastMath.min((int) '4', (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.302585092994046d + "'", double1 == 2.302585092994046d);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1752011936438014d + "'", double1 == 1.1752011936438014d);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        long long2 = org.apache.commons.math.util.FastMath.max(0L, (long) (byte) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        long long1 = org.apache.commons.math.util.FastMath.abs((-1L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        float float1 = org.apache.commons.math.util.FastMath.abs(0.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 1, 10L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        double double1 = org.apache.commons.math.special.Erf.erf((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 10L, (double) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): standard deviation (-1)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 0L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 32);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 32L + "'", long1 == 32L);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        long long2 = org.apache.commons.math.util.FastMath.max(10L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        double double1 = org.apache.commons.math.util.FastMath.log((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.605170185988092d + "'", double1 == 4.605170185988092d);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.248699261236361d + "'", double1 == 4.248699261236361d);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 32L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6610060414837631d + "'", double1 == 0.6610060414837631d);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        int int1 = org.apache.commons.math.util.FastMath.abs(100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        double double0 = org.apache.commons.math.util.FastMath.E;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.718281828459045d + "'", double0 == 2.718281828459045d);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        int int1 = org.apache.commons.math.util.FastMath.round((float) '#');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 35 + "'", int1 == 35);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (short) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (short) 1, (java.lang.Number) 100, false);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 1L, (double) (short) 1);
        try {
            double[] doubleArray4 = normalDistributionImpl2.sample(0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): number of samples (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(1);
        int int2 = maxIterationsExceededException1.getMaxIterations();
        int int3 = maxIterationsExceededException1.getMaxIterations();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 100L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.6881171418161356E43d + "'", double1 == 2.6881171418161356E43d);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        double double1 = org.apache.commons.math.util.FastMath.sin(1.1752011936438014d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9227673888116062d + "'", double1 == 0.9227673888116062d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 10L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 10L + "'", long1 == 10L);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9866275920404853d + "'", double1 == 0.9866275920404853d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP((double) (-1.0f), (double) 35, (double) (short) 10, (int) (short) -1);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 100.0f);
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getSpecificPattern();
        java.lang.Object[] objArray10 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException("", objArray10);
        java.lang.Throwable[] throwableArray12 = convergenceException11.getSuppressed();
        java.lang.Class<?> wildcardClass13 = convergenceException11.getClass();
        java.lang.Object[] objArray21 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException("", objArray21);
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException11, "", objArray21);
        java.lang.Object[] objArray31 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException("", objArray31);
        java.lang.Throwable[] throwableArray33 = convergenceException32.getSuppressed();
        java.lang.Class<?> wildcardClass34 = convergenceException32.getClass();
        java.lang.Object[] objArray42 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException43 = new org.apache.commons.math.ConvergenceException("", objArray42);
        org.apache.commons.math.ConvergenceException convergenceException44 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException32, "", objArray42);
        org.apache.commons.math.ConvergenceException convergenceException45 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException11, "hi!", objArray42);
        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException1, "", objArray42);
        java.lang.String str47 = convergenceException46.getPattern();
        java.lang.Object[] objArray49 = null;
        org.apache.commons.math.ConvergenceException convergenceException50 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException46, "hi!", objArray49);
        org.junit.Assert.assertNull(localizable2);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(throwableArray33);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "" + "'", str47.equals(""));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        java.lang.Object[] objArray6 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException("", objArray6);
        java.lang.Throwable[] throwableArray8 = convergenceException7.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        java.lang.Object[] objArray16 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException("", objArray16);
        java.lang.Throwable[] throwableArray18 = convergenceException17.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException7, localizable9, (java.lang.Object[]) throwableArray18);
        org.apache.commons.math.exception.util.Localizable localizable20 = convergenceException19.getSpecificPattern();
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertNull(localizable20);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 35);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.248291097914389d + "'", double1 == 4.248291097914389d);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        double double2 = org.apache.commons.math.util.FastMath.max(10.0d, (double) 10L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(10.000000000000002d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9999999999999999d) + "'", double1 == (-0.9999999999999999d));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 32L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 32.0d + "'", double1 == 32.0d);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        double double2 = org.apache.commons.math.util.FastMath.min((double) (-1L), (-0.5772156677920679d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 0, (float) (byte) 100);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (byte) -1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.9866275920404853d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6821738184917205d + "'", double1 == 1.6821738184917205d);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5860134523134308E15d + "'", double1 == 1.5860134523134308E15d);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        int int2 = org.apache.commons.math.util.FastMath.max((int) 'a', 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) 1.6821738184917205d, false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(4.605170185988092d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.605170185988093d + "'", double1 == 4.605170185988093d);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        double double1 = org.apache.commons.math.util.FastMath.floor((-0.5772156677920679d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        double double1 = org.apache.commons.math.util.FastMath.floor((-1.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 0L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        double double2 = org.apache.commons.math.util.FastMath.max(0.398906612308477d, (double) 0.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.398906612308477d + "'", double2 == 0.398906612308477d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        double double1 = org.apache.commons.math.special.Gamma.digamma(0.9227673888116062d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7119668703638151d) + "'", double1 == (-0.7119668703638151d));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        double double0 = org.apache.commons.math.util.FastMath.PI;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.141592653589793d + "'", double0 == 3.141592653589793d);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        try {
            randomDataImpl0.setSecureAlgorithm("hi!", "");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: missing provider");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        try {
            int int3 = randomDataImpl0.nextBinomial(97, (double) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 10 out of [0, 1] range");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        double double1 = org.apache.commons.math.util.FastMath.sinh(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1752011936438014d + "'", double1 == 1.1752011936438014d);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.0d, (double) 10.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.9E-324d + "'", double2 == 4.9E-324d);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) (short) 1, 3.141592653589793d);
        try {
            double[] doubleArray5 = normalDistributionImpl3.sample(0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): number of samples (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

//    @Test
//    public void test070() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test070");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        try {
//            int int6 = randomDataImpl0.nextInt((int) (byte) -1, (int) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: -1 is larger than, or equal to, the maximum (-1): lower bound (-1) must be strictly less than upper bound (-1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 35.534052241881895d + "'", double3 == 35.534052241881895d);
//    }

//    @Test
//    public void test071() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test071");
//        double double0 = org.apache.commons.math.util.FastMath.random();
//        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.7602273367625401d + "'", double0 == 0.7602273367625401d);
//    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) (byte) 0, (double) (-1L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        double double1 = org.apache.commons.math.util.FastMath.asinh((-0.7119668703638151d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6624426489214782d) + "'", double1 == (-0.6624426489214782d));
    }

//    @Test
//    public void test074() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test074");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        try {
//            int int6 = randomDataImpl0.nextPascal((int) (short) 10, (-0.7119668703638151d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: -0.712 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 7.181196512685867d + "'", double3 == 7.181196512685867d);
//    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 10L + "'", long1 == 10L);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 32L, (float) 'a');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 97.0f + "'", float2 == 97.0f);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        double double2 = org.apache.commons.math.util.FastMath.atan2(1.5860134523134308E15d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (byte) 100);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 100.0f + "'", float1 == 100.0f);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 1, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        double double1 = org.apache.commons.math.special.Gamma.digamma((double) (short) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (short) 10, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 1L, (double) (short) 1);
        double double5 = normalDistributionImpl2.cumulativeProbability(0.0d, 0.0d);
        double double7 = normalDistributionImpl2.cumulativeProbability(10.000000000000002d);
        try {
            double[] doubleArray9 = normalDistributionImpl2.sample((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): number of samples (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        int int2 = org.apache.commons.math.util.FastMath.max((-1), (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

//    @Test
//    public void test085() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test085");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        try {
//            int int6 = randomDataImpl0.nextZipf((int) (short) 100, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): exponent (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 5.482054923930687d + "'", double3 == 5.482054923930687d);
//    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        double double1 = org.apache.commons.math.util.FastMath.sinh(44.57328158058611d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1399878826998993E19d + "'", double1 == 1.1399878826998993E19d);
    }

//    @Test
//    public void test087() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test087");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        int int6 = randomDataImpl0.nextSecureInt(0, (int) (short) 10);
//        try {
//            int int9 = randomDataImpl0.nextSecureInt((int) (short) 0, (int) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 0 is larger than, or equal to, the maximum (-1): lower bound (0) must be strictly less than upper bound (-1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 5.97512168674209d + "'", double3 == 5.97512168674209d);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 9 + "'", int6 == 9);
//    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 10, (double) (-1L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.6704649792860586d + "'", double2 == 1.6704649792860586d);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (short) 0, (long) (byte) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        try {
            double double4 = randomDataImpl1.nextBeta((double) 32L, (double) (-1L));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.5 p = 0.137");
        } catch (org.apache.commons.math.exception.MathUserException e) {
        }
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        double double1 = org.apache.commons.math.special.Gamma.logGamma((double) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 12.801827480081469d + "'", double1 == 12.801827480081469d);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 0);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) '#');
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        try {
            double double4 = randomDataImpl1.nextWeibull(Double.POSITIVE_INFINITY, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): scale (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

//    @Test
//    public void test098() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test098");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution4 = null;
//        try {
//            int int5 = randomDataImpl0.nextInversionDeviate(integerDistribution4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.8280431650889417d + "'", double3 == 3.8280431650889417d);
//    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 32, (java.lang.Number) Double.NaN, false);
        java.lang.Number number4 = numberIsTooLargeException3.getMax();
        java.lang.Number number5 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertEquals((double) number4, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) number5, Double.NaN, 0);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 10);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        int int1 = org.apache.commons.math.util.FastMath.abs(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5574077246549023d) + "'", double1 == (-1.5574077246549023d));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        double double2 = org.apache.commons.math.util.FastMath.pow(1.5860134523134308E15d, (double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        int int1 = org.apache.commons.math.util.FastMath.round(0.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (byte) 100, 4);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        try {
            double double3 = randomDataImpl0.nextGamma(Double.NaN, (double) (-1.0f));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): beta");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (byte) 1, (long) (short) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (-1), (long) (short) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7853981633974483d) + "'", double1 == (-0.7853981633974483d));
    }

//    @Test
//    public void test112() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test112");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        try {
//            double double6 = randomDataImpl0.nextUniform(1.5860134523134308E15d, (double) (short) -1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 1,586,013,452,313,430.8 is larger than, or equal to, the maximum (-1): lower bound (1,586,013,452,313,430.8) must be strictly less than upper bound (-1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 9.577052889183552d + "'", double3 == 9.577052889183552d);
//    }

//    @Test
//    public void test113() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test113");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        int int6 = randomDataImpl0.nextSecureInt(0, (int) (short) 10);
//        try {
//            long long9 = randomDataImpl0.nextLong(0L, (long) (byte) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 0 is larger than, or equal to, the maximum (0): lower bound (0) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 9.587849958298547d + "'", double3 == 9.587849958298547d);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
//    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) '4');
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (short) 0, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

//    @Test
//    public void test116() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test116");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        int int6 = randomDataImpl0.nextSecureInt(0, (int) (short) 10);
//        try {
//            double double9 = randomDataImpl0.nextGaussian(0.0d, (double) 0L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): standard deviation (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 9.269771928567915d + "'", double3 == 9.269771928567915d);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 5 + "'", int6 == 5);
//    }

//    @Test
//    public void test117() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test117");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        randomDataImpl0.reSeedSecure((long) '4');
//        double double7 = randomDataImpl0.nextChiSquare((double) 1.0f);
//        try {
//            java.lang.String str9 = randomDataImpl0.nextHexString(0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): length (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 9.221144317294998d + "'", double3 == 9.221144317294998d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0191386230292663d + "'", double7 == 1.0191386230292663d);
//    }

//    @Test
//    public void test118() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test118");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        randomDataImpl0.reSeedSecure((long) '4');
//        double double7 = randomDataImpl0.nextChiSquare((double) 1.0f);
//        try {
//            double double10 = randomDataImpl0.nextWeibull(0.0d, (-0.7119668703638151d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): shape (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 9.202348322289406d + "'", double3 == 9.202348322289406d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.009627910157679545d + "'", double7 == 0.009627910157679545d);
//    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        double double0 = org.apache.commons.math.distribution.NormalDistributionImpl.DEFAULT_INVERSE_ABSOLUTE_ACCURACY;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-9d + "'", double0 == 1.0E-9d);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        double double2 = org.apache.commons.math.util.FastMath.pow(1.5860134523134308E15d, 1.6821738184917205d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.711575027927711E25d + "'", double2 == 3.711575027927711E25d);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        double double1 = org.apache.commons.math.util.FastMath.tanh(1.5707963267948966d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9171523356672744d + "'", double1 == 0.9171523356672744d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 100L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8623188722876839d + "'", double1 == 0.8623188722876839d);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.9036417751182644d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.61875315207275d + "'", double1 == 0.61875315207275d);
    }

//    @Test
//    public void test124() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test124");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        try {
//            double double6 = randomDataImpl0.nextCauchy(0.0d, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): scale (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 9.31899571014528d + "'", double3 == 9.31899571014528d);
//    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) (short) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5707963267948966d) + "'", double1 == (-1.5707963267948966d));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        double double1 = org.apache.commons.math.util.FastMath.acos((-0.6624426489214782d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.2948711289906125d + "'", double1 == 2.2948711289906125d);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 1L, (double) (short) 1);
        double double5 = normalDistributionImpl2.cumulativeProbability(0.0d, 0.0d);
        double double6 = normalDistributionImpl2.getMean();
        try {
            double double9 = normalDistributionImpl2.cumulativeProbability((double) 10, (double) (byte) -1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        double double1 = org.apache.commons.math.special.Gamma.digamma(4.605170185988092d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.414694723542776d + "'", double1 == 1.414694723542776d);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        double double1 = org.apache.commons.math.util.FastMath.asinh(1.6821738184917205d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2917468367601999d + "'", double1 == 1.2917468367601999d);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        double double1 = org.apache.commons.math.util.FastMath.expm1(2.302585092994046d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.000000000000002d + "'", double1 == 9.000000000000002d);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5729.5779513082325d + "'", double1 == 5729.5779513082325d);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        double double2 = org.apache.commons.math.util.FastMath.pow(10.0d, (double) 35);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E35d + "'", double2 == 1.0E35d);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP((double) 0.0f, 32.0d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        double double1 = org.apache.commons.math.special.Gamma.digamma(2.2948711289906125d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5972534764549589d + "'", double1 == 0.5972534764549589d);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        double double1 = org.apache.commons.math.util.FastMath.cos((-1.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5403023058681398d + "'", double1 == 0.5403023058681398d);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 100.0f);
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable3 = notStrictlyPositiveException1.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable4 = notStrictlyPositiveException1.getSpecificPattern();
        boolean boolean5 = notStrictlyPositiveException1.getBoundIsAllowed();
        org.junit.Assert.assertNull(localizable2);
        org.junit.Assert.assertNull(localizable3);
        org.junit.Assert.assertNull(localizable4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        double double1 = org.apache.commons.math.util.FastMath.cos(2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.04229861514908033d) + "'", double1 == (-0.04229861514908033d));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.5772156649015329d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.615314862365699d + "'", double1 == 0.615314862365699d);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (byte) 1, (float) (short) -1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 5, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.718281828459045d + "'", double1 == 2.718281828459045d);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 35.0d + "'", double1 == 35.0d);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 4);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 4.0f + "'", float1 == 4.0f);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        int int2 = org.apache.commons.math.util.FastMath.max(6, 35);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException("", objArray7);
        java.lang.Throwable[] throwableArray9 = convergenceException8.getSuppressed();
        java.lang.Class<?> wildcardClass10 = convergenceException8.getClass();
        java.lang.Object[] objArray18 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException("", objArray18);
        java.lang.Throwable[] throwableArray20 = convergenceException19.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable21 = null;
        java.lang.Object[] objArray28 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException("", objArray28);
        java.lang.Throwable[] throwableArray30 = convergenceException29.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException19, localizable21, (java.lang.Object[]) throwableArray30);
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException8, "", (java.lang.Object[]) throwableArray30);
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException37 = new org.apache.commons.math.exception.OutOfRangeException(localizable33, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 10.0f, (java.lang.Number) (byte) 10);
        org.apache.commons.math.exception.util.Localizable localizable38 = outOfRangeException37.getGeneralPattern();
        java.lang.Object[] objArray45 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException("", objArray45);
        java.lang.Throwable[] throwableArray47 = convergenceException46.getSuppressed();
        java.lang.Class<?> wildcardClass48 = convergenceException46.getClass();
        java.lang.Object[] objArray56 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException57 = new org.apache.commons.math.ConvergenceException("", objArray56);
        java.lang.Throwable[] throwableArray58 = convergenceException57.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable59 = null;
        java.lang.Object[] objArray66 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException67 = new org.apache.commons.math.ConvergenceException("", objArray66);
        java.lang.Throwable[] throwableArray68 = convergenceException67.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException69 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException57, localizable59, (java.lang.Object[]) throwableArray68);
        org.apache.commons.math.ConvergenceException convergenceException70 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException46, "", (java.lang.Object[]) throwableArray68);
        org.apache.commons.math.MathException mathException71 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException32, localizable38, (java.lang.Object[]) throwableArray68);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException72 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, (java.lang.Object[]) throwableArray68);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(throwableArray20);
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertNotNull(throwableArray30);
        org.junit.Assert.assertTrue("'" + localizable38 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable38.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray45);
        org.junit.Assert.assertNotNull(throwableArray47);
        org.junit.Assert.assertNotNull(wildcardClass48);
        org.junit.Assert.assertNotNull(objArray56);
        org.junit.Assert.assertNotNull(throwableArray58);
        org.junit.Assert.assertNotNull(objArray66);
        org.junit.Assert.assertNotNull(throwableArray68);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.0d, (double) 32L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 32L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.158638853279167d + "'", double1 == 4.158638853279167d);
    }

//    @Test
//    public void test152() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test152");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        double double6 = randomDataImpl0.nextCauchy(1.6704649792860586d, 86.78823356954149d);
//        try {
//            double double9 = randomDataImpl0.nextUniform(0.0d, (-0.8813735870195429d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 0 is larger than, or equal to, the maximum (-0.881): lower bound (0) must be strictly less than upper bound (-0.881)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.6096500996874585d + "'", double3 == 1.6096500996874585d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-29.01661884154803d) + "'", double6 == (-29.01661884154803d));
//    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        java.lang.Throwable throwable0 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException("", objArray8);
        java.lang.Throwable[] throwableArray10 = convergenceException9.getSuppressed();
        java.lang.Class<?> wildcardClass11 = convergenceException9.getClass();
        java.lang.Object[] objArray19 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException("", objArray19);
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException9, "", objArray19);
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException(throwable0, "hi!", objArray19);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(objArray19);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 6, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 6L + "'", long2 == 6L);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(8.205002241254977d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.941144909753433d + "'", double1 == 8.941144909753433d);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        try {
            int int3 = randomDataImpl0.nextInt(4, (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 4 is larger than, or equal to, the maximum (-1): lower bound (4) must be strictly less than upper bound (-1)");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        double double1 = org.apache.commons.math.util.FastMath.acosh(100.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.298292365610485d + "'", double1 == 5.298292365610485d);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        double double1 = org.apache.commons.math.special.Erf.erf(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

//    @Test
//    public void test160() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test160");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        int int6 = randomDataImpl0.nextSecureInt(0, (int) (short) 10);
//        double double9 = randomDataImpl0.nextUniform(0.9866275920404853d, (double) '#');
//        try {
//            int int12 = randomDataImpl0.nextBinomial((int) (byte) 100, 1.6704649792860586d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 1.67 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 7.231920261308696d + "'", double3 == 7.231920261308696d);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2 + "'", int6 == 2);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.533524580415573d + "'", double9 == 2.533524580415573d);
//    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.9036417751182644d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.468576762660578d + "'", double1 == 2.468576762660578d);
    }

//    @Test
//    public void test162() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test162");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        double double6 = randomDataImpl0.nextCauchy(1.6704649792860586d, 86.78823356954149d);
//        long long9 = randomDataImpl0.nextLong((long) 1, (long) 16);
//        try {
//            double double11 = randomDataImpl0.nextChiSquare((-1.5707963267948966d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.785 is smaller than, or equal to, the minimum (0): alpha");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 7.189229408703428d + "'", double3 == 7.189229408703428d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 37.03862311549372d + "'", double6 == 37.03862311549372d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10L + "'", long9 == 10L);
//    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

//    @Test
//    public void test164() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test164");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        int int6 = randomDataImpl0.nextSecureInt(0, (int) (short) 10);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl9 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 1L, (double) (short) 1);
//        double double11 = normalDistributionImpl9.density(0.9866275920404853d);
//        double double12 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl9);
//        try {
//            int int15 = randomDataImpl0.nextPascal(0, 0.6235200651203063d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MathException; message: Discrete cumulative probability function returned NaN for argument 1,073,741,822");
//        } catch (org.apache.commons.math.MathException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 7.139492174287847d + "'", double3 == 7.139492174287847d);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 3 + "'", int6 == 3);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.398906612308477d + "'", double11 == 0.398906612308477d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.170271098196084d + "'", double12 == 2.170271098196084d);
//    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        java.lang.Object[] objArray6 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException("", objArray6);
        java.lang.Throwable[] throwableArray8 = convergenceException7.getSuppressed();
        java.lang.Class<?> wildcardClass9 = convergenceException7.getClass();
        java.lang.Object[] objArray17 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException("", objArray17);
        java.lang.Throwable[] throwableArray19 = convergenceException18.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException("", objArray27);
        java.lang.Throwable[] throwableArray29 = convergenceException28.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException18, localizable20, (java.lang.Object[]) throwableArray29);
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException7, "", (java.lang.Object[]) throwableArray29);
        org.apache.commons.math.exception.util.Localizable localizable32 = convergenceException31.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException34 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable32, (java.lang.Number) 2.718281828459045d);
        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException34);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(throwableArray29);
        org.junit.Assert.assertNotNull(localizable32);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.9171523356672744d, 5729.5779513082325d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.3901532053355E-216d + "'", double2 == 6.3901532053355E-216d);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10L, (java.lang.Number) (-0.7853981633974483d), true);
        boolean boolean4 = numberIsTooLargeException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 4.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6094379124341003d + "'", double1 == 1.6094379124341003d);
    }

//    @Test
//    public void test169() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test169");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        int int6 = randomDataImpl0.nextSecureInt(0, (int) (short) 10);
//        int int9 = randomDataImpl0.nextInt(0, (int) '#');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl13 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 0, (double) '#', 0.6610060414837631d);
//        double double14 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl13);
//        java.lang.String str16 = randomDataImpl0.nextSecureHexString(9);
//        try {
//            long long19 = randomDataImpl0.nextSecureLong(10L, 0L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 10 is larger than, or equal to, the maximum (0): lower bound (10) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 9.478534114467662d + "'", double3 == 9.478534114467662d);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 7 + "'", int6 == 7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 40.33899395851542d + "'", double14 == 40.33899395851542d);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "33ca237f6" + "'", str16.equals("33ca237f6"));
//    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(44.57328158058611d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.676322459302435d + "'", double1 == 6.676322459302435d);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.017453292519943295d + "'", double1 == 0.017453292519943295d);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.6610060414837631d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6204290412244261d + "'", double1 == 0.6204290412244261d);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 1L, (double) (short) 1);
        double double5 = normalDistributionImpl2.cumulativeProbability(0.0d, 0.0d);
        double double6 = normalDistributionImpl2.getMean();
        try {
            double double9 = normalDistributionImpl2.cumulativeProbability(9.339333518010317d, 0.0d);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP((double) 1.0f, 0.9036417751182644d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5949082827295911d + "'", double2 == 0.5949082827295911d);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP((double) '#', 4.239302734211798d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.42617598242928E-20d + "'", double2 == 1.42617598242928E-20d);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        try {
            randomDataImpl0.setSecureAlgorithm("0426b643d", "");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: missing provider");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        double double1 = org.apache.commons.math.util.FastMath.log1p(5729.5779513082325d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.653571668725002d + "'", double1 == 8.653571668725002d);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 4);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.0d + "'", double1 == 4.0d);
    }

//    @Test
//    public void test180() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test180");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        int int6 = randomDataImpl0.nextSecureInt(0, (int) (short) 10);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl9 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 1L, (double) (short) 1);
//        double double11 = normalDistributionImpl9.density(0.9866275920404853d);
//        double double12 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl9);
//        try {
//            int[] intArray15 = randomDataImpl0.nextPermutation((int) (short) 1, (int) (byte) 100);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100 is larger than the maximum (1): permutation size (100) exceeds permuation domain (1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 8.978088521605715d + "'", double3 == 8.978088521605715d);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 7 + "'", int6 == 7);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.398906612308477d + "'", double11 == 0.398906612308477d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.6830713817942332d + "'", double12 == 0.6830713817942332d);
//    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.9171523356672744d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948968d + "'", double1 == 1.5707963267948968d);
    }

//    @Test
//    public void test182() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test182");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        int int6 = randomDataImpl0.nextSecureInt(0, (int) (short) 10);
//        int int9 = randomDataImpl0.nextInt(0, (int) '#');
//        double double12 = randomDataImpl0.nextBeta((double) 97.0f, 1.0E35d);
//        try {
//            int int15 = randomDataImpl0.nextSecureInt((int) '#', (int) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 35 is larger than, or equal to, the maximum (-1): lower bound (35) must be strictly less than upper bound (-1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 9.169362968009523d + "'", double3 == 9.169362968009523d);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 5 + "'", int6 == 5);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 22 + "'", int9 == 22);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
//    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        double double2 = org.apache.commons.math.util.FastMath.pow(2.8991410882239435d, (double) 1.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.8991410882239435d + "'", double2 == 2.8991410882239435d);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        double double1 = org.apache.commons.math.util.FastMath.atanh(1.5707963267948966d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        double double1 = org.apache.commons.math.util.FastMath.floor(4.7699116308280525d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.0d + "'", double1 == 4.0d);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 35);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 35L + "'", long1 == 35L);
    }

//    @Test
//    public void test187() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test187");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        randomDataImpl0.reSeedSecure((long) '4');
//        try {
//            double double8 = randomDataImpl0.nextCauchy(1.8548725935371486d, (-1.0d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): scale (-1)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 13.14294350807947d + "'", double3 == 13.14294350807947d);
//    }

//    @Test
//    public void test188() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test188");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        randomDataImpl0.reSeedSecure((long) '4');
//        double double7 = randomDataImpl0.nextChiSquare((double) 1.0f);
//        randomDataImpl0.reSeed();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl12 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) (short) 1, 3.141592653589793d);
//        double double13 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl12);
//        try {
//            double double15 = normalDistributionImpl12.inverseCumulativeProbability(8.03325469850426d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 8.033 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 13.167807822479581d + "'", double3 == 13.167807822479581d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.10405412380673067d + "'", double7 == 0.10405412380673067d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
//    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        double double1 = org.apache.commons.math.util.FastMath.rint(8.205002241254977d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.0d + "'", double1 == 8.0d);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        double double1 = org.apache.commons.math.special.Erf.erf((-0.9999999999999999d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8427007929497151d) + "'", double1 == (-0.8427007929497151d));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 35L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 35 + "'", int1 == 35);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        int int2 = org.apache.commons.math.util.FastMath.min(35, 7);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        double double1 = org.apache.commons.math.util.FastMath.asin(12.801827480081469d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ((double) 9, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

//    @Test
//    public void test195() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test195");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        int int6 = randomDataImpl0.nextSecureInt(0, (int) (short) 10);
//        int int9 = randomDataImpl0.nextInt(0, (int) '#');
//        randomDataImpl0.reSeed();
//        try {
//            double double12 = randomDataImpl0.nextExponential(0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): mean (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 13.37794921205506d + "'", double3 == 13.37794921205506d);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2 + "'", int6 == 2);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 33 + "'", int9 == 33);
//    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.40702284518531173d, (double) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.1061068447653153E-45d + "'", double2 == 1.1061068447653153E-45d);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (short) 0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        java.lang.Throwable throwable0 = null;
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException(throwable0, "0426b643d", objArray2);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 35L, (float) 17L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 17.0f + "'", float2 == 17.0f);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0.9866275920404853d, (java.lang.Number) 0.61875315207275d, false);
        java.lang.Object[] objArray12 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException("", objArray12);
        java.lang.Throwable[] throwableArray14 = convergenceException13.getSuppressed();
        java.lang.Class<?> wildcardClass15 = convergenceException13.getClass();
        java.lang.Object[] objArray23 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException("", objArray23);
        java.lang.Throwable[] throwableArray25 = convergenceException24.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        java.lang.Object[] objArray33 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException34 = new org.apache.commons.math.ConvergenceException("", objArray33);
        java.lang.Throwable[] throwableArray35 = convergenceException34.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException24, localizable26, (java.lang.Object[]) throwableArray35);
        org.apache.commons.math.ConvergenceException convergenceException37 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException13, "", (java.lang.Object[]) throwableArray35);
        org.apache.commons.math.exception.util.Localizable localizable38 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException42 = new org.apache.commons.math.exception.OutOfRangeException(localizable38, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 10.0f, (java.lang.Number) (byte) 10);
        org.apache.commons.math.exception.util.Localizable localizable43 = outOfRangeException42.getGeneralPattern();
        java.lang.Object[] objArray50 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException51 = new org.apache.commons.math.ConvergenceException("", objArray50);
        java.lang.Throwable[] throwableArray52 = convergenceException51.getSuppressed();
        java.lang.Class<?> wildcardClass53 = convergenceException51.getClass();
        java.lang.Object[] objArray61 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException62 = new org.apache.commons.math.ConvergenceException("", objArray61);
        java.lang.Throwable[] throwableArray63 = convergenceException62.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable64 = null;
        java.lang.Object[] objArray71 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException72 = new org.apache.commons.math.ConvergenceException("", objArray71);
        java.lang.Throwable[] throwableArray73 = convergenceException72.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException74 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException62, localizable64, (java.lang.Object[]) throwableArray73);
        org.apache.commons.math.ConvergenceException convergenceException75 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException51, "", (java.lang.Object[]) throwableArray73);
        org.apache.commons.math.MathException mathException76 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException37, localizable43, (java.lang.Object[]) throwableArray73);
        org.apache.commons.math.ConvergenceException convergenceException77 = new org.apache.commons.math.ConvergenceException("", (java.lang.Object[]) throwableArray73);
        org.apache.commons.math.ConvergenceException convergenceException78 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException3, "", (java.lang.Object[]) throwableArray73);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNotNull(throwableArray25);
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertNotNull(throwableArray35);
        org.junit.Assert.assertTrue("'" + localizable43 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable43.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray50);
        org.junit.Assert.assertNotNull(throwableArray52);
        org.junit.Assert.assertNotNull(wildcardClass53);
        org.junit.Assert.assertNotNull(objArray61);
        org.junit.Assert.assertNotNull(throwableArray63);
        org.junit.Assert.assertNotNull(objArray71);
        org.junit.Assert.assertNotNull(throwableArray73);
    }

//    @Test
//    public void test201() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test201");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        int int6 = randomDataImpl0.nextSecureInt(0, (int) (short) 10);
//        long long9 = randomDataImpl0.nextSecureLong((long) 0, (long) 'a');
//        try {
//            double double11 = randomDataImpl0.nextChiSquare(0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): alpha");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 11.431823620708002d + "'", double3 == 11.431823620708002d);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 5 + "'", int6 == 5);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 67L + "'", long9 == 67L);
//    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 1L, (double) (short) 1);
        double double5 = normalDistributionImpl2.cumulativeProbability(0.0d, 0.0d);
        double double7 = normalDistributionImpl2.cumulativeProbability(10.000000000000002d);
        double double10 = normalDistributionImpl2.cumulativeProbability(0.6610060414837631d, 2.302585092994046d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.5363346344187385d + "'", double10 == 0.5363346344187385d);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        double double1 = org.apache.commons.math.util.FastMath.abs(4.158638853279167d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.158638853279167d + "'", double1 == 4.158638853279167d);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.398906612308477d, 0.7602273367625401d, (double) (byte) 1, 97);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.5276511697442289d + "'", double4 == 0.5276511697442289d);
    }

//    @Test
//    public void test205() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test205");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextChiSquare(0.398906612308477d);
//        try {
//            double double5 = randomDataImpl0.nextGamma((double) '4', (-1.5707963267948966d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1.571 is smaller than, or equal to, the minimum (0): beta");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.1617086483648813d + "'", double2 == 0.1617086483648813d);
//    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        double double1 = org.apache.commons.math.special.Erf.erf(0.398906612308477d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.42734055810300414d + "'", double1 == 0.42734055810300414d);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.9036417751182644d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0317425226950845d + "'", double1 == 1.0317425226950845d);
    }

//    @Test
//    public void test208() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test208");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        int int6 = randomDataImpl0.nextSecureInt(0, (int) (short) 10);
//        int int9 = randomDataImpl0.nextInt(0, (int) '#');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl13 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 0, (double) '#', 0.6610060414837631d);
//        double double14 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl13);
//        try {
//            double[] doubleArray16 = normalDistributionImpl13.sample(0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): number of samples (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 11.494224848020105d + "'", double3 == 11.494224848020105d);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 16 + "'", int9 == 16);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 43.33899395851536d + "'", double14 == 43.33899395851536d);
//    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 7);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6569865987187891d + "'", double1 == 0.6569865987187891d);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.398906612308477d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4223479548124092d + "'", double1 == 0.4223479548124092d);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        double double1 = org.apache.commons.math.special.Gamma.digamma(4.158638853279167d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3001647594029435d + "'", double1 == 1.3001647594029435d);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 35L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.58351893845611d + "'", double1 == 3.58351893845611d);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100);
        int int2 = maxIterationsExceededException1.getMaxIterations();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

//    @Test
//    public void test214() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test214");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextChiSquare(0.398906612308477d);
//        try {
//            int int5 = randomDataImpl0.nextPascal((int) '4', 4.7699116308280525d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 4.77 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.16362934316014727d + "'", double2 == 0.16362934316014727d);
//    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 4, (float) 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        double double1 = org.apache.commons.math.util.FastMath.log(8.941144909753433d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.1906636469536225d + "'", double1 == 2.1906636469536225d);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(1.0E35d, 0.0d, 8.737800111547191d, 7);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        double double1 = org.apache.commons.math.util.FastMath.log(0.6348620231205278d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.45434759012392645d) + "'", double1 == (-0.45434759012392645d));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 7, 10.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        double double1 = org.apache.commons.math.special.Gamma.digamma(1.6704649792860586d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.18485236397967297d + "'", double1 == 0.18485236397967297d);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) -1, 26);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 26 + "'", int2 == 26);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 10.0f, (java.lang.Number) (byte) 10);
        org.apache.commons.math.exception.util.Localizable localizable5 = outOfRangeException4.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) (short) 100, (java.lang.Number) 11013.232874703393d, false);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException13 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) 8.737800111547191d, (java.lang.Number) 8.737800111547191d, false);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException17 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable5, (java.lang.Number) 0.2636018486682622d, (java.lang.Number) 0.5358329035727638d, false);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
    }

//    @Test
//    public void test224() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test224");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        int int6 = randomDataImpl0.nextSecureInt(0, (int) (short) 10);
//        try {
//            int int9 = randomDataImpl0.nextPascal((int) (byte) 10, (double) 4.0f);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 4 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.87053796094035d + "'", double3 == 10.87053796094035d);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2 + "'", int6 == 2);
//    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        java.lang.Object[] objArray7 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException("", objArray7);
        java.lang.Throwable[] throwableArray9 = convergenceException8.getSuppressed();
        java.lang.Class<?> wildcardClass10 = convergenceException8.getClass();
        java.lang.Object[] objArray18 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException("", objArray18);
        java.lang.Throwable[] throwableArray20 = convergenceException19.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable21 = null;
        java.lang.Object[] objArray28 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException("", objArray28);
        java.lang.Throwable[] throwableArray30 = convergenceException29.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException19, localizable21, (java.lang.Object[]) throwableArray30);
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException8, "", (java.lang.Object[]) throwableArray30);
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException37 = new org.apache.commons.math.exception.OutOfRangeException(localizable33, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 10.0f, (java.lang.Number) (byte) 10);
        org.apache.commons.math.exception.util.Localizable localizable38 = outOfRangeException37.getGeneralPattern();
        java.lang.Object[] objArray45 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException("", objArray45);
        java.lang.Throwable[] throwableArray47 = convergenceException46.getSuppressed();
        java.lang.Class<?> wildcardClass48 = convergenceException46.getClass();
        java.lang.Object[] objArray56 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException57 = new org.apache.commons.math.ConvergenceException("", objArray56);
        java.lang.Throwable[] throwableArray58 = convergenceException57.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable59 = null;
        java.lang.Object[] objArray66 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException67 = new org.apache.commons.math.ConvergenceException("", objArray66);
        java.lang.Throwable[] throwableArray68 = convergenceException67.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException69 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException57, localizable59, (java.lang.Object[]) throwableArray68);
        org.apache.commons.math.ConvergenceException convergenceException70 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException46, "", (java.lang.Object[]) throwableArray68);
        org.apache.commons.math.MathException mathException71 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException32, localizable38, (java.lang.Object[]) throwableArray68);
        java.lang.Object[] objArray78 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException79 = new org.apache.commons.math.ConvergenceException("", objArray78);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException80 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable38, objArray78);
        int int81 = maxIterationsExceededException80.getMaxIterations();
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(throwableArray20);
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertNotNull(throwableArray30);
        org.junit.Assert.assertTrue("'" + localizable38 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable38.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray45);
        org.junit.Assert.assertNotNull(throwableArray47);
        org.junit.Assert.assertNotNull(wildcardClass48);
        org.junit.Assert.assertNotNull(objArray56);
        org.junit.Assert.assertNotNull(throwableArray58);
        org.junit.Assert.assertNotNull(objArray66);
        org.junit.Assert.assertNotNull(throwableArray68);
        org.junit.Assert.assertNotNull(objArray78);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 0 + "'", int81 == 0);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 100.0f);
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getSpecificPattern();
        java.lang.String str3 = notStrictlyPositiveException1.toString();
        org.junit.Assert.assertNull(localizable2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str3.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 100.0f);
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable3 = notStrictlyPositiveException1.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable4 = notStrictlyPositiveException1.getSpecificPattern();
        java.lang.Class<?> wildcardClass5 = notStrictlyPositiveException1.getClass();
        org.junit.Assert.assertNull(localizable2);
        org.junit.Assert.assertNull(localizable3);
        org.junit.Assert.assertNull(localizable4);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        double double1 = org.apache.commons.math.util.FastMath.expm1(1.3344764463477395E-9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3344764472381532E-9d + "'", double1 == 1.3344764472381532E-9d);
    }

//    @Test
//    public void test229() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test229");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        int int6 = randomDataImpl0.nextSecureInt(0, (int) (short) 10);
//        try {
//            double double8 = randomDataImpl0.nextT((-17.169940132922783d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -17.17 is smaller than, or equal to, the minimum (0): degrees of freedom (-17.17)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 11.259169058821332d + "'", double3 == 11.259169058821332d);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        double double2 = org.apache.commons.math.util.FastMath.pow(3.58351893845611d, 0.5363346344187385d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.9828757086554465d + "'", double2 == 1.9828757086554465d);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        double double1 = org.apache.commons.math.special.Erf.erf((double) 100L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.5276511697442289d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5827661623296411d + "'", double1 == 0.5827661623296411d);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.615314862365699d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        double double2 = org.apache.commons.math.util.FastMath.atan2(5.298292365610485d, 4.239302734211798d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.8959784153937458d + "'", double2 == 0.8959784153937458d);
    }

//    @Test
//    public void test236() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test236");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        int int6 = randomDataImpl0.nextSecureInt(0, (int) (short) 10);
//        int int9 = randomDataImpl0.nextInt(0, (int) '#');
//        double double12 = randomDataImpl0.nextBeta((double) 97.0f, 1.0E35d);
//        double double15 = randomDataImpl0.nextCauchy(0.615314862365699d, 0.5772156649015329d);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution16 = null;
//        try {
//            int int17 = randomDataImpl0.nextInversionDeviate(integerDistribution16);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 8.924078909782033d + "'", double3 == 8.924078909782033d);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 7 + "'", int6 == 7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 11 + "'", int9 == 11);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.39975683309871d + "'", double15 == 8.39975683309871d);
//    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1 == 100.0d);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        double double1 = org.apache.commons.math.util.FastMath.signum((-17.169940132922783d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

//    @Test
//    public void test239() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test239");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        int int6 = randomDataImpl0.nextSecureInt(0, (int) (short) 10);
//        int int9 = randomDataImpl0.nextInt(0, (int) '#');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl13 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 0, (double) '#', 0.6610060414837631d);
//        double double14 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl13);
//        double double15 = normalDistributionImpl13.getMean();
//        double[] doubleArray17 = normalDistributionImpl13.sample(31);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 8.995696864925984d + "'", double3 == 8.995696864925984d);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2 + "'", int6 == 2);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 34 + "'", int9 == 34);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 30.743471618496034d + "'", double14 == 30.743471618496034d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
//        org.junit.Assert.assertNotNull(doubleArray17);
//    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 'a');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 97 + "'", int1 == 97);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.016941759914687875d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.01694013920788123d + "'", double1 == 0.01694013920788123d);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        int int1 = org.apache.commons.math.util.FastMath.abs(16);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 16 + "'", int1 == 16);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        double double1 = org.apache.commons.math.util.FastMath.log1p((-0.04229861514908033d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.04321925643815076d) + "'", double1 == (-0.04321925643815076d));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 0L, (float) 16);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 26);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 26.0f + "'", float1 == 26.0f);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(2.287352489659993d, (double) 97, 0.6235200651203063d, 9);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        double double1 = org.apache.commons.math.util.FastMath.tan(1.6094379124341003d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-25.86597340317637d) + "'", double1 == (-25.86597340317637d));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 10.0f, (java.lang.Number) (byte) 10);
        org.apache.commons.math.exception.util.Localizable localizable5 = outOfRangeException4.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) (short) 100, (java.lang.Number) 11013.232874703393d, false);
        boolean boolean10 = numberIsTooSmallException9.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ((-31.0d), 0.8086810944281969d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.6204290412244261d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

//    @Test
//    public void test251() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test251");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        double double6 = randomDataImpl0.nextCauchy(1.6704649792860586d, 86.78823356954149d);
//        long long9 = randomDataImpl0.nextLong((long) 1, (long) 16);
//        double double11 = randomDataImpl0.nextChiSquare(56.0d);
//        double double14 = randomDataImpl0.nextGaussian(8.928976450870955d, 11013.232874703393d);
//        try {
//            double double17 = randomDataImpl0.nextUniform(1.9828757086554465d, 0.40702284518531173d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 1.983 is larger than, or equal to, the maximum (0.407): lower bound (1.983) must be strictly less than upper bound (0.407)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 8.154314338117157d + "'", double3 == 8.154314338117157d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 15.117373804024252d + "'", double6 == 15.117373804024252d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 4L + "'", long9 == 4L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 50.192886233309686d + "'", double11 == 50.192886233309686d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-14072.035724352363d) + "'", double14 == (-14072.035724352363d));
//    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(66.78690542226121d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.165651396836512d + "'", double1 == 1.165651396836512d);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        double double1 = org.apache.commons.math.util.FastMath.log(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        double double1 = org.apache.commons.math.util.FastMath.ulp(1.2917468367601999d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (short) -1, (float) 9L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 9.0f + "'", float2 == 9.0f);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 56.0d, (java.lang.Number) 0.9171523356672744d, true);
        boolean boolean4 = numberIsTooLargeException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        double double1 = org.apache.commons.math.util.FastMath.sin(2.468576762660578d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.623347079987928d + "'", double1 == 0.623347079987928d);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 1L, (double) (short) 1);
        double double4 = normalDistributionImpl2.density(0.9866275920404853d);
        double double6 = normalDistributionImpl2.density((-0.04321925643815076d));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.398906612308477d + "'", double4 == 0.398906612308477d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.23151936896823624d + "'", double6 == 0.23151936896823624d);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.6348620231205278d, 52.780035402544826d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.9746370780062322E-24d + "'", double2 == 1.9746370780062322E-24d);
    }

//    @Test
//    public void test261() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test261");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        double double6 = randomDataImpl0.nextCauchy(1.6704649792860586d, 86.78823356954149d);
//        long long9 = randomDataImpl0.nextLong((long) 1, (long) 16);
//        double double11 = randomDataImpl0.nextChiSquare(56.0d);
//        randomDataImpl0.reSeedSecure((-1L));
//        try {
//            java.lang.String str15 = randomDataImpl0.nextHexString((int) (byte) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): length (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 11.524739252864219d + "'", double3 == 11.524739252864219d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-49.525962265850616d) + "'", double6 == (-49.525962265850616d));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 3L + "'", long9 == 3L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 64.76184461394865d + "'", double11 == 64.76184461394865d);
//    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 10, (java.lang.Number) 5.109650487152199d, true);
        java.lang.Throwable[] throwableArray4 = numberIsTooSmallException3.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray4);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 100.0f);
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable3 = notStrictlyPositiveException1.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable4 = notStrictlyPositiveException1.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException9 = new org.apache.commons.math.exception.OutOfRangeException(localizable5, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 10.0f, (java.lang.Number) (byte) 10);
        org.apache.commons.math.exception.util.Localizable localizable10 = outOfRangeException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException18 = new org.apache.commons.math.exception.OutOfRangeException(localizable14, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 10.0f, (java.lang.Number) (byte) 10);
        org.apache.commons.math.exception.util.Localizable localizable19 = outOfRangeException18.getGeneralPattern();
        java.lang.Object[] objArray26 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException("", objArray26);
        java.lang.Throwable[] throwableArray28 = convergenceException27.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable29 = null;
        java.lang.Object[] objArray36 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException37 = new org.apache.commons.math.ConvergenceException("", objArray36);
        java.lang.Throwable[] throwableArray38 = convergenceException37.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException27, localizable29, (java.lang.Object[]) throwableArray38);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException40 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable19, (java.lang.Object[]) throwableArray38);
        java.lang.Object[] objArray41 = maxIterationsExceededException40.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException42 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 100, "", objArray41);
        org.apache.commons.math.MathException mathException43 = new org.apache.commons.math.MathException(localizable10, objArray41);
        java.lang.Number number44 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException45 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable10, number44);
        notStrictlyPositiveException1.addSuppressed((java.lang.Throwable) notStrictlyPositiveException45);
        org.junit.Assert.assertNull(localizable2);
        org.junit.Assert.assertNull(localizable3);
        org.junit.Assert.assertNull(localizable4);
        org.junit.Assert.assertTrue("'" + localizable10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable10.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable19.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(throwableArray28);
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertNotNull(throwableArray38);
        org.junit.Assert.assertNotNull(objArray41);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP((double) (byte) 100, (double) 9L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.855581740684184E-67d + "'", double2 == 3.855581740684184E-67d);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 10L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 10.0f + "'", float1 == 10.0f);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(4.248291097914389d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2652432325175126d + "'", double1 == 0.2652432325175126d);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        long long1 = org.apache.commons.math.util.FastMath.round((-0.8427007929497151d));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        float float1 = org.apache.commons.math.util.FastMath.abs(9.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 9.0f + "'", float1 == 9.0f);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException6 = new org.apache.commons.math.exception.OutOfRangeException(localizable2, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 10.0f, (java.lang.Number) (byte) 10);
        org.apache.commons.math.exception.util.Localizable localizable7 = outOfRangeException6.getGeneralPattern();
        java.lang.Object[] objArray14 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException("", objArray14);
        java.lang.Throwable[] throwableArray16 = convergenceException15.getSuppressed();
        java.lang.Class<?> wildcardClass17 = convergenceException15.getClass();
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        java.lang.Object[] objArray25 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException26 = new org.apache.commons.math.ConvergenceException("", objArray25);
        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException15, localizable18, objArray25);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException28 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable7, objArray25);
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException("hi!", objArray25);
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(objArray25);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        float float2 = org.apache.commons.math.util.FastMath.min((float) '#', (float) 9L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 9.0f + "'", float2 == 9.0f);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        double double1 = org.apache.commons.math.util.FastMath.asin(1.9828757086554465d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException5 = new org.apache.commons.math.exception.OutOfRangeException(localizable1, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 10.0f, (java.lang.Number) (byte) 10);
        org.apache.commons.math.exception.util.Localizable localizable6 = outOfRangeException5.getGeneralPattern();
        java.lang.Object[] objArray13 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException("", objArray13);
        java.lang.Throwable[] throwableArray15 = convergenceException14.getSuppressed();
        java.lang.Class<?> wildcardClass16 = convergenceException14.getClass();
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        java.lang.Object[] objArray24 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException25 = new org.apache.commons.math.ConvergenceException("", objArray24);
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException14, localizable17, objArray24);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException27 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable6, objArray24);
        java.lang.Object[] objArray34 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException("", objArray34);
        java.lang.Throwable[] throwableArray36 = convergenceException35.getSuppressed();
        java.lang.Class<?> wildcardClass37 = convergenceException35.getClass();
        java.lang.Object[] objArray45 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException("", objArray45);
        java.lang.Throwable[] throwableArray47 = convergenceException46.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable48 = null;
        java.lang.Object[] objArray55 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException56 = new org.apache.commons.math.ConvergenceException("", objArray55);
        java.lang.Throwable[] throwableArray57 = convergenceException56.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException58 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException46, localizable48, (java.lang.Object[]) throwableArray57);
        org.apache.commons.math.ConvergenceException convergenceException59 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException35, "", (java.lang.Object[]) throwableArray57);
        org.apache.commons.math.exception.util.Localizable localizable60 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException64 = new org.apache.commons.math.exception.OutOfRangeException(localizable60, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 10.0f, (java.lang.Number) (byte) 10);
        org.apache.commons.math.exception.util.Localizable localizable65 = outOfRangeException64.getGeneralPattern();
        java.lang.Object[] objArray72 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException73 = new org.apache.commons.math.ConvergenceException("", objArray72);
        java.lang.Throwable[] throwableArray74 = convergenceException73.getSuppressed();
        java.lang.Class<?> wildcardClass75 = convergenceException73.getClass();
        java.lang.Object[] objArray83 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException84 = new org.apache.commons.math.ConvergenceException("", objArray83);
        java.lang.Throwable[] throwableArray85 = convergenceException84.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable86 = null;
        java.lang.Object[] objArray93 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException94 = new org.apache.commons.math.ConvergenceException("", objArray93);
        java.lang.Throwable[] throwableArray95 = convergenceException94.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException96 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException84, localizable86, (java.lang.Object[]) throwableArray95);
        org.apache.commons.math.ConvergenceException convergenceException97 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException73, "", (java.lang.Object[]) throwableArray95);
        org.apache.commons.math.MathException mathException98 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException59, localizable65, (java.lang.Object[]) throwableArray95);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException99 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, (java.lang.Object[]) throwableArray95);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(throwableArray36);
        org.junit.Assert.assertNotNull(wildcardClass37);
        org.junit.Assert.assertNotNull(objArray45);
        org.junit.Assert.assertNotNull(throwableArray47);
        org.junit.Assert.assertNotNull(objArray55);
        org.junit.Assert.assertNotNull(throwableArray57);
        org.junit.Assert.assertTrue("'" + localizable65 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable65.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray72);
        org.junit.Assert.assertNotNull(throwableArray74);
        org.junit.Assert.assertNotNull(wildcardClass75);
        org.junit.Assert.assertNotNull(objArray83);
        org.junit.Assert.assertNotNull(throwableArray85);
        org.junit.Assert.assertNotNull(objArray93);
        org.junit.Assert.assertNotNull(throwableArray95);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(175.8653249411727d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 175.86532494117273d + "'", double1 == 175.86532494117273d);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (short) 100, 31);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        long long2 = org.apache.commons.math.util.FastMath.min((long) '#', (long) (byte) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(30);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        int int2 = org.apache.commons.math.util.FastMath.max(33, (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 33 + "'", int2 == 33);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.8623188722876839d, 12.801827480081469d);
        double double3 = normalDistributionImpl2.getMean();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.8623188722876839d + "'", double3 == 0.8623188722876839d);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 10.0f, (java.lang.Number) 2.718281828459045d, false);
        java.lang.Number number5 = numberIsTooSmallException4.getMin();
        java.lang.Object[] objArray13 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException("", objArray13);
        java.lang.Throwable[] throwableArray15 = convergenceException14.getSuppressed();
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException4, "hi!", (java.lang.Object[]) throwableArray15);
        org.apache.commons.math.exception.util.Localizable localizable17 = mathException16.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 2.718281828459045d + "'", number5.equals(2.718281828459045d));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertNull(localizable17);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 5);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        double double1 = org.apache.commons.math.util.FastMath.ulp(2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.951760157141521E27d + "'", double1 == 4.951760157141521E27d);
    }

//    @Test
//    public void test282() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test282");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        int int6 = randomDataImpl0.nextSecureInt(0, (int) (short) 10);
//        double double8 = randomDataImpl0.nextExponential(3.41643668911758d);
//        double double11 = randomDataImpl0.nextCauchy(0.015061189059456493d, (double) 1.0f);
//        try {
//            java.lang.String str13 = randomDataImpl0.nextHexString(0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): length (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 13.453264041809321d + "'", double3 == 13.453264041809321d);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 5 + "'", int6 == 5);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.2230973349956708d + "'", double8 == 0.2230973349956708d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.15061420737436518d + "'", double11 == 0.15061420737436518d);
//    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (byte) 0);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        double double1 = org.apache.commons.math.util.FastMath.cos((-1.0504596969243527d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4971722435431834d + "'", double1 == 0.4971722435431834d);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        double double1 = org.apache.commons.math.special.Gamma.trigamma((double) 6L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.1813229557370451d + "'", double1 == 0.1813229557370451d);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        int int2 = org.apache.commons.math.util.FastMath.max(35, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException5 = new org.apache.commons.math.exception.OutOfRangeException(localizable1, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 10.0f, (java.lang.Number) (byte) 10);
        org.apache.commons.math.exception.util.Localizable localizable6 = outOfRangeException5.getGeneralPattern();
        java.lang.Object[] objArray13 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException("", objArray13);
        java.lang.Throwable[] throwableArray15 = convergenceException14.getSuppressed();
        java.lang.Class<?> wildcardClass16 = convergenceException14.getClass();
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        java.lang.Object[] objArray24 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException25 = new org.apache.commons.math.ConvergenceException("", objArray24);
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException14, localizable17, objArray24);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException27 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable6, objArray24);
        java.lang.String str28 = maxIterationsExceededException27.getPattern();
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "{0} out of [{1}, {2}] range" + "'", str28.equals("{0} out of [{1}, {2}] range"));
    }

//    @Test
//    public void test288() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test288");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        randomDataImpl0.reSeedSecure((long) 'a');
//        try {
//            double double8 = randomDataImpl0.nextF((-0.9882377874054193d), (-0.8427007929497151d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.988 is smaller than, or equal to, the minimum (0): degrees of freedom (-0.988)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 11.90338549254767d + "'", double3 == 11.90338549254767d);
//    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(3.141592653589793d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4645918875615231d + "'", double1 == 1.4645918875615231d);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(48.33899395851526d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.952624968924705d + "'", double1 == 6.952624968924705d);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.42734055810300414d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0927080481029119d + "'", double1 == 1.0927080481029119d);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        double double1 = org.apache.commons.math.util.FastMath.sinh(1.414694723542776d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.936115103562213d + "'", double1 == 1.936115103562213d);
    }

//    @Test
//    public void test293() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test293");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        randomDataImpl0.reSeedSecure((long) '4');
//        double double7 = randomDataImpl0.nextChiSquare((double) 1.0f);
//        randomDataImpl0.reSeed();
//        int int11 = randomDataImpl0.nextPascal(2, 1.9746370780062322E-24d);
//        try {
//            java.lang.String str13 = randomDataImpl0.nextHexString(0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): length (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 12.079371996234872d + "'", double3 == 12.079371996234872d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.15414895926016328d + "'", double7 == 0.15414895926016328d);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2147483647 + "'", int11 == 2147483647);
//    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        double double1 = org.apache.commons.math.special.Gamma.digamma(0.015061189059456493d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-66.94853018111154d) + "'", double1 == (-66.94853018111154d));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 33);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 33L + "'", long1 == 33L);
    }

//    @Test
//    public void test296() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test296");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        int int6 = randomDataImpl0.nextSecureInt(0, (int) (short) 10);
//        int int9 = randomDataImpl0.nextInt(0, (int) '#');
//        double double12 = randomDataImpl0.nextBeta((double) 97.0f, 1.0E35d);
//        double double14 = randomDataImpl0.nextChiSquare((double) 4L);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 12.12416669812663d + "'", double3 == 12.12416669812663d);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 7 + "'", int6 == 7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 13 + "'", int9 == 13);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.5738396991040955d + "'", double14 == 1.5738396991040955d);
//    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(3.58351893845611d, (-0.9999999999999999d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        java.lang.Object[] objArray6 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException("", objArray6);
        java.lang.Throwable[] throwableArray8 = convergenceException7.getSuppressed();
        java.lang.Class<?> wildcardClass9 = convergenceException7.getClass();
        java.lang.Object[] objArray17 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException("", objArray17);
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException7, "", objArray17);
        java.lang.Object[] objArray27 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException("", objArray27);
        java.lang.Throwable[] throwableArray29 = convergenceException28.getSuppressed();
        java.lang.Class<?> wildcardClass30 = convergenceException28.getClass();
        java.lang.Object[] objArray38 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException("", objArray38);
        org.apache.commons.math.ConvergenceException convergenceException40 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException28, "", objArray38);
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException7, "hi!", objArray38);
        org.apache.commons.math.exception.util.Localizable localizable42 = convergenceException41.getSpecificPattern();
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(throwableArray29);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNull(localizable42);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(47.72559009637225d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 47.72559009637226d + "'", double1 == 47.72559009637226d);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        java.lang.Object[] objArray6 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException("", objArray6);
        java.lang.Throwable[] throwableArray8 = convergenceException7.getSuppressed();
        java.lang.Class<?> wildcardClass9 = convergenceException7.getClass();
        java.lang.String str10 = convergenceException7.getPattern();
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        java.lang.Object[] objArray6 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException("", objArray6);
        java.lang.Throwable[] throwableArray8 = convergenceException7.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        java.lang.Object[] objArray16 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException("", objArray16);
        java.lang.Throwable[] throwableArray18 = convergenceException17.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException7, localizable9, (java.lang.Object[]) throwableArray18);
        try {
            java.lang.String str20 = convergenceException19.getPattern();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(throwableArray18);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(1.42617598242928E-20d, 10.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.4261759824292803E-20d + "'", double2 == 1.4261759824292803E-20d);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 26.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.414973347970818d + "'", double1 == 1.414973347970818d);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (byte) -1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        double double1 = org.apache.commons.math.util.FastMath.expm1(86.78823356954149d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.916442150459739E37d + "'", double1 == 4.916442150459739E37d);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(8.653571668725002d, 4.858821229924069d, 0.7602273367625401d);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        double double1 = org.apache.commons.math.special.Gamma.trigamma((double) 8L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.13313701469396122d + "'", double1 == 0.13313701469396122d);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException5 = new org.apache.commons.math.exception.OutOfRangeException(localizable1, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 10.0f, (java.lang.Number) (byte) 10);
        org.apache.commons.math.exception.util.Localizable localizable6 = outOfRangeException5.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException10 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable6, (java.lang.Number) (short) 100, (java.lang.Number) 11013.232874703393d, false);
        java.lang.Number number11 = numberIsTooSmallException10.getMin();
        java.lang.Object[] objArray12 = numberIsTooSmallException10.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException("hi!", objArray12);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 11013.232874703393d + "'", number11.equals(11013.232874703393d));
        org.junit.Assert.assertNotNull(objArray12);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        double double1 = org.apache.commons.math.special.Gamma.digamma((double) 33);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.481279527644452d + "'", double1 == 3.481279527644452d);
    }

//    @Test
//    public void test311() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test311");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextChiSquare(0.398906612308477d);
//        randomDataImpl0.reSeedSecure();
//        double double5 = randomDataImpl0.nextT((double) 100.0f);
//        try {
//            int int8 = randomDataImpl0.nextInt(12, (int) (short) 10);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 12 is larger than, or equal to, the maximum (10): lower bound (12) must be strictly less than upper bound (10)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.3736585848705969d + "'", double2 == 1.3736585848705969d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.967461367778296d + "'", double5 == 0.967461367778296d);
//    }

//    @Test
//    public void test312() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test312");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        int int6 = randomDataImpl0.nextSecureInt(0, (int) (short) 10);
//        int int9 = randomDataImpl0.nextInt(0, (int) '#');
//        try {
//            int[] intArray12 = randomDataImpl0.nextPermutation(1, 5);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 5 is larger than the maximum (1): permutation size (5) exceeds permuation domain (1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 20.78755882313729d + "'", double3 == 20.78755882313729d);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 34 + "'", int9 == 34);
//    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        int int2 = org.apache.commons.math.util.FastMath.min(0, 6);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10L, (java.lang.Number) (-0.7853981633974483d), true);
        java.lang.Number number4 = numberIsTooLargeException3.getArgument();
        java.lang.Number number5 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 10L + "'", number4.equals(10L));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-0.7853981633974483d) + "'", number5.equals((-0.7853981633974483d)));
    }

//    @Test
//    public void test315() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test315");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        int int6 = randomDataImpl0.nextSecureInt(0, (int) (short) 10);
//        int int9 = randomDataImpl0.nextInt(0, (int) '#');
//        double double12 = randomDataImpl0.nextBeta((double) 97.0f, 1.0E35d);
//        double double15 = randomDataImpl0.nextCauchy(0.615314862365699d, 0.5772156649015329d);
//        try {
//            int[] intArray18 = randomDataImpl0.nextPermutation((-1), 35);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 35 is larger than the maximum (-1): permutation size (35) exceeds permuation domain (-1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 18.89044857825077d + "'", double3 == 18.89044857825077d);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 31 + "'", int9 == 31);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.9543990520206769d + "'", double15 == 0.9543990520206769d);
//    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 12);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 12 + "'", int1 == 12);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        int int2 = org.apache.commons.math.util.FastMath.min((int) ' ', (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(32.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5585053606381855d + "'", double1 == 0.5585053606381855d);
    }

//    @Test
//    public void test320() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test320");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 1L, (double) (short) 1);
//        double double5 = normalDistributionImpl2.cumulativeProbability(0.0d, 0.0d);
//        double double7 = normalDistributionImpl2.cumulativeProbability(10.000000000000002d);
//        double double9 = normalDistributionImpl2.cumulativeProbability(2.302585092994046d);
//        double double10 = normalDistributionImpl2.getMean();
//        double double11 = normalDistributionImpl2.sample();
//        double[] doubleArray13 = normalDistributionImpl2.sample((int) 'a');
//        double[] doubleArray15 = normalDistributionImpl2.sample((int) '4');
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.9036417751182644d + "'", double9 == 0.9036417751182644d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.791630772658661d + "'", double11 == 1.791630772658661d);
//        org.junit.Assert.assertNotNull(doubleArray13);
//        org.junit.Assert.assertNotNull(doubleArray15);
//    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.6348620231205278d, 2.1906636469536225d, 16.0d, 34);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.9474491130379984d + "'", double4 == 0.9474491130379984d);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        double double1 = org.apache.commons.math.util.FastMath.exp(4.858821229924069d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 128.872201843145d + "'", double1 == 128.872201843145d);
    }

//    @Test
//    public void test323() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test323");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure((long) (short) 1);
//        double double5 = randomDataImpl1.nextT((double) 5);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.6339865993972527d + "'", double5 == 0.6339865993972527d);
//    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        double double1 = org.apache.commons.math.util.FastMath.sin(3.711575027927711E25d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9973498474408802d) + "'", double1 == (-0.9973498474408802d));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        try {
            randomDataImpl1.setSecureAlgorithm("0426b643d", "5f880764e45ee705");
            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: 5f880764e45ee705");
        } catch (java.security.NoSuchProviderException e) {
        }
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.5363346344187385d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.2705641570714845d) + "'", double1 == (-0.2705641570714845d));
    }

//    @Test
//    public void test327() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test327");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        double double6 = randomDataImpl0.nextCauchy(1.6704649792860586d, 86.78823356954149d);
//        long long9 = randomDataImpl0.nextLong((long) 1, (long) 16);
//        double double11 = randomDataImpl0.nextChiSquare(56.0d);
//        double double14 = randomDataImpl0.nextGaussian(8.928976450870955d, 11013.232874703393d);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution15 = null;
//        try {
//            int int16 = randomDataImpl0.nextInversionDeviate(integerDistribution15);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 12.846191506531081d + "'", double3 == 12.846191506531081d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 71.02603308731409d + "'", double6 == 71.02603308731409d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 7L + "'", long9 == 7L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 49.77041770089512d + "'", double11 == 49.77041770089512d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 8462.150203707175d + "'", double14 == 8462.150203707175d);
//    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        double double2 = org.apache.commons.math.util.FastMath.min(0.11717703212592656d, (double) 100.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.11717703212592656d + "'", double2 == 0.11717703212592656d);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        java.lang.Object[] objArray6 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException("", objArray6);
        java.lang.Throwable[] throwableArray8 = convergenceException7.getSuppressed();
        java.lang.Class<?> wildcardClass9 = convergenceException7.getClass();
        java.lang.Object[] objArray17 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException("", objArray17);
        java.lang.Throwable[] throwableArray19 = convergenceException18.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException("", objArray27);
        java.lang.Throwable[] throwableArray29 = convergenceException28.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException18, localizable20, (java.lang.Object[]) throwableArray29);
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException7, "", (java.lang.Object[]) throwableArray29);
        org.apache.commons.math.exception.util.Localizable localizable32 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException36 = new org.apache.commons.math.exception.OutOfRangeException(localizable32, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 10.0f, (java.lang.Number) (byte) 10);
        org.apache.commons.math.exception.util.Localizable localizable37 = outOfRangeException36.getGeneralPattern();
        java.lang.Object[] objArray44 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException45 = new org.apache.commons.math.ConvergenceException("", objArray44);
        java.lang.Throwable[] throwableArray46 = convergenceException45.getSuppressed();
        java.lang.Class<?> wildcardClass47 = convergenceException45.getClass();
        java.lang.Object[] objArray55 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException56 = new org.apache.commons.math.ConvergenceException("", objArray55);
        java.lang.Throwable[] throwableArray57 = convergenceException56.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable58 = null;
        java.lang.Object[] objArray65 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException66 = new org.apache.commons.math.ConvergenceException("", objArray65);
        java.lang.Throwable[] throwableArray67 = convergenceException66.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException68 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException56, localizable58, (java.lang.Object[]) throwableArray67);
        org.apache.commons.math.ConvergenceException convergenceException69 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException45, "", (java.lang.Object[]) throwableArray67);
        org.apache.commons.math.MathException mathException70 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException31, localizable37, (java.lang.Object[]) throwableArray67);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException74 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable37, (java.lang.Number) 100L, (java.lang.Number) 11013.232874703393d, false);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException76 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable37, (java.lang.Number) 1.676055631171775E-4d);
        java.lang.Object[] objArray77 = notStrictlyPositiveException76.getArguments();
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(throwableArray29);
        org.junit.Assert.assertTrue("'" + localizable37 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable37.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertNotNull(throwableArray46);
        org.junit.Assert.assertNotNull(wildcardClass47);
        org.junit.Assert.assertNotNull(objArray55);
        org.junit.Assert.assertNotNull(throwableArray57);
        org.junit.Assert.assertNotNull(objArray65);
        org.junit.Assert.assertNotNull(throwableArray67);
        org.junit.Assert.assertNotNull(objArray77);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) 100, 9);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 10.0f, (java.lang.Number) (byte) 10);
        org.apache.commons.math.exception.util.Localizable localizable5 = outOfRangeException4.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) (short) 100, (java.lang.Number) 11013.232874703393d, false);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException11 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 100.0f);
        org.apache.commons.math.exception.util.Localizable localizable12 = notStrictlyPositiveException11.getSpecificPattern();
        java.lang.Object[] objArray20 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException("", objArray20);
        java.lang.Throwable[] throwableArray22 = convergenceException21.getSuppressed();
        java.lang.Class<?> wildcardClass23 = convergenceException21.getClass();
        java.lang.Object[] objArray31 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException("", objArray31);
        org.apache.commons.math.ConvergenceException convergenceException33 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException21, "", objArray31);
        java.lang.Object[] objArray41 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException("", objArray41);
        java.lang.Throwable[] throwableArray43 = convergenceException42.getSuppressed();
        java.lang.Class<?> wildcardClass44 = convergenceException42.getClass();
        java.lang.Object[] objArray52 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException53 = new org.apache.commons.math.ConvergenceException("", objArray52);
        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException42, "", objArray52);
        org.apache.commons.math.ConvergenceException convergenceException55 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException21, "hi!", objArray52);
        org.apache.commons.math.ConvergenceException convergenceException56 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException11, "", objArray52);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException57 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, objArray52);
        java.lang.Object[] objArray64 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException65 = new org.apache.commons.math.ConvergenceException("", objArray64);
        java.lang.Throwable[] throwableArray66 = convergenceException65.getSuppressed();
        java.lang.Class<?> wildcardClass67 = convergenceException65.getClass();
        java.lang.Object[] objArray75 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException76 = new org.apache.commons.math.ConvergenceException("", objArray75);
        java.lang.Throwable[] throwableArray77 = convergenceException76.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable78 = null;
        java.lang.Object[] objArray85 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException86 = new org.apache.commons.math.ConvergenceException("", objArray85);
        java.lang.Throwable[] throwableArray87 = convergenceException86.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException88 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException76, localizable78, (java.lang.Object[]) throwableArray87);
        org.apache.commons.math.ConvergenceException convergenceException89 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException65, "", (java.lang.Object[]) throwableArray87);
        org.apache.commons.math.ConvergenceException convergenceException90 = new org.apache.commons.math.ConvergenceException(localizable5, (java.lang.Object[]) throwableArray87);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException92 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable5, (java.lang.Number) 1.165651396836512d);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNull(localizable12);
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(throwableArray22);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(objArray41);
        org.junit.Assert.assertNotNull(throwableArray43);
        org.junit.Assert.assertNotNull(wildcardClass44);
        org.junit.Assert.assertNotNull(objArray52);
        org.junit.Assert.assertNotNull(objArray64);
        org.junit.Assert.assertNotNull(throwableArray66);
        org.junit.Assert.assertNotNull(wildcardClass67);
        org.junit.Assert.assertNotNull(objArray75);
        org.junit.Assert.assertNotNull(throwableArray77);
        org.junit.Assert.assertNotNull(objArray85);
        org.junit.Assert.assertNotNull(throwableArray87);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        int int2 = org.apache.commons.math.util.FastMath.max(97, 35);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        double double1 = org.apache.commons.math.special.Gamma.logGamma((double) 97);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 345.37940706226686d + "'", double1 == 345.37940706226686d);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        double double1 = org.apache.commons.math.util.FastMath.sinh(6.676322459302435d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 396.6973669525801d + "'", double1 == 396.6973669525801d);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        double double1 = org.apache.commons.math.util.FastMath.sinh(4.916442150459739E37d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        double double1 = org.apache.commons.math.util.FastMath.acos(4.158638853279167d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (short) -1, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException5 = new org.apache.commons.math.exception.OutOfRangeException(localizable1, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 10.0f, (java.lang.Number) (byte) 10);
        org.apache.commons.math.exception.util.Localizable localizable6 = outOfRangeException5.getGeneralPattern();
        java.lang.Object[] objArray13 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException("", objArray13);
        java.lang.Throwable[] throwableArray15 = convergenceException14.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        java.lang.Object[] objArray23 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException("", objArray23);
        java.lang.Throwable[] throwableArray25 = convergenceException24.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException26 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException14, localizable16, (java.lang.Object[]) throwableArray25);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException27 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable6, (java.lang.Object[]) throwableArray25);
        java.lang.Object[] objArray28 = maxIterationsExceededException27.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable29 = maxIterationsExceededException27.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNotNull(throwableArray25);
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertNull(localizable29);
    }

//    @Test
//    public void test340() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test340");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextChiSquare(0.398906612308477d);
//        randomDataImpl0.reSeedSecure();
//        double double5 = randomDataImpl0.nextT((double) 100.0f);
//        try {
//            int int8 = randomDataImpl0.nextSecureInt(97, 31);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 97 is larger than, or equal to, the maximum (31): lower bound (97) must be strictly less than upper bound (31)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.16717178091197274d + "'", double2 == 0.16717178091197274d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-0.6148269412142043d) + "'", double5 == (-0.6148269412142043d));
//    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        double double1 = org.apache.commons.math.util.FastMath.ulp(1.6823565279386816d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(6);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 10.0d, (java.lang.Number) (byte) 0, false);
        java.lang.Number number4 = numberIsTooSmallException3.getMin();
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException3.getSpecificPattern();
        boolean boolean6 = numberIsTooSmallException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (byte) 0 + "'", number4.equals((byte) 0));
        org.junit.Assert.assertNull(localizable5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        long long1 = org.apache.commons.math.util.FastMath.round(4.858821229924069d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 5L + "'", long1 == 5L);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((-0.8813735870195429d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test346() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test346");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        int int6 = randomDataImpl0.nextSecureInt(0, (int) (short) 10);
//        int int9 = randomDataImpl0.nextInt(0, (int) '#');
//        double double12 = randomDataImpl0.nextBeta((double) 97.0f, 1.0E35d);
//        double double15 = randomDataImpl0.nextUniform(2.287352489659993d, (double) 22);
//        int int18 = randomDataImpl0.nextSecureInt((int) (short) -1, 0);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.66998482942705d + "'", double3 == 10.66998482942705d);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2 + "'", int6 == 2);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 21 + "'", int9 == 21);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 9.642467988978417d + "'", double15 == 9.642467988978417d);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 8L, 1.1102230246251565E-16d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

//    @Test
//    public void test348() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test348");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        randomDataImpl0.reSeedSecure((long) '4');
//        double double7 = randomDataImpl0.nextChiSquare((double) 1.0f);
//        randomDataImpl0.reSeed();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl12 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) (short) 1, 3.141592653589793d);
//        double double13 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl12);
//        randomDataImpl0.reSeed();
//        double double17 = randomDataImpl0.nextBeta(0.0140436016105168d, 1.0d);
//        try {
//            int int20 = randomDataImpl0.nextPascal((int) '#', (double) 33L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 33 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.829811301073091d + "'", double3 == 10.829811301073091d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.7113191000422375d + "'", double7 == 0.7113191000422375d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0948714682781684E-9d + "'", double17 == 1.0948714682781684E-9d);
//    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        double double2 = org.apache.commons.math.util.FastMath.min(0.07995708192013753d, 9.642467988978417d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.07995708192013753d + "'", double2 == 0.07995708192013753d);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(1.414694723542776d, 9.642467988978417d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.9502958802207327E-4d + "'", double2 == 1.9502958802207327E-4d);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        double double1 = org.apache.commons.math.special.Erf.erf(9.241796535393869d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.5827661623296411d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5503356286700535d + "'", double1 == 0.5503356286700535d);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (byte) 10, (long) 8);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 8L + "'", long2 == 8L);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        long long1 = org.apache.commons.math.util.FastMath.round(0.6235868443416331d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        double double1 = org.apache.commons.math.util.FastMath.log(2.1906636469536225d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7842045330611761d + "'", double1 == 0.7842045330611761d);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        double double1 = org.apache.commons.math.util.FastMath.expm1(2.7383311244009776d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 14.4611607995733d + "'", double1 == 14.4611607995733d);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 6);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 201.71315737027922d + "'", double1 == 201.71315737027922d);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 16, (long) 9);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 16L + "'", long2 == 16L);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 2147483647, 3.175169392061453d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.1474836469999998E9d + "'", double2 == 2.1474836469999998E9d);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        int int2 = org.apache.commons.math.util.FastMath.min(26, 13);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22026.465794806718d + "'", double1 == 22026.465794806718d);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(3.175169392061453d, 52.780035402544826d, 4.239302734211798d);
        double double5 = normalDistributionImpl3.density(0.0d);
        try {
            double[] doubleArray7 = normalDistributionImpl3.sample(0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): number of samples (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.007544917965956679d + "'", double5 == 0.007544917965956679d);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.0f, (java.lang.Number) (-25.86597340317637d), false);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException5 = new org.apache.commons.math.exception.OutOfRangeException(localizable1, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 10.0f, (java.lang.Number) (byte) 10);
        org.apache.commons.math.exception.util.Localizable localizable6 = outOfRangeException5.getGeneralPattern();
        java.lang.Object[] objArray13 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException("", objArray13);
        java.lang.Throwable[] throwableArray15 = convergenceException14.getSuppressed();
        java.lang.Class<?> wildcardClass16 = convergenceException14.getClass();
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        java.lang.Object[] objArray24 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException25 = new org.apache.commons.math.ConvergenceException("", objArray24);
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException14, localizable17, objArray24);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException27 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable6, objArray24);
        org.apache.commons.math.exception.util.Localizable localizable28 = maxIterationsExceededException27.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNull(localizable28);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

//    @Test
//    public void test367() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test367");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        int int6 = randomDataImpl0.nextSecureInt(0, (int) (short) 10);
//        int int9 = randomDataImpl0.nextInt(0, (int) '#');
//        double double12 = randomDataImpl0.nextBeta((double) 97.0f, 1.0E35d);
//        int int15 = randomDataImpl0.nextInt(7, 9);
//        double double17 = randomDataImpl0.nextExponential((double) 34);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 11.047516915046149d + "'", double3 == 11.047516915046149d);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 7 + "'", int6 == 7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.607132023323726E-9d + "'", double12 == 1.607132023323726E-9d);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 9 + "'", int15 == 9);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 10.84666847367277d + "'", double17 == 10.84666847367277d);
//    }

//    @Test
//    public void test368() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test368");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        randomDataImpl0.reSeedSecure((long) '4');
//        double double7 = randomDataImpl0.nextChiSquare((double) 1.0f);
//        randomDataImpl0.reSeed();
//        int int11 = randomDataImpl0.nextBinomial((int) (byte) 0, 0.40702284518531173d);
//        double double14 = randomDataImpl0.nextUniform((double) (short) 1, (double) 4);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl17 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 1L, (double) ' ');
//        double double19 = normalDistributionImpl17.cumulativeProbability(0.7602273367625401d);
//        double double20 = normalDistributionImpl17.sample();
//        double double21 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl17);
//        try {
//            int int24 = randomDataImpl0.nextInt(26, 16);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 26 is larger than, or equal to, the maximum (16): lower bound (26) must be strictly less than upper bound (16)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 11.01421970404762d + "'", double3 == 11.01421970404762d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.003694828663182822d + "'", double7 == 0.003694828663182822d);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.654042176035047d + "'", double14 == 1.654042176035047d);
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.4970107950629486d + "'", double19 == 0.4970107950629486d);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 5.832090410330572d + "'", double20 == 5.832090410330572d);
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 30.68810301040782d + "'", double21 == 30.68810301040782d);
//    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.18485236397967297d, 3.711575027927711E25d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        float float2 = org.apache.commons.math.util.FastMath.min((float) '#', (float) (byte) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.23151936896823624d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.20824866640299536d + "'", double1 == 0.20824866640299536d);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(100.0d, (double) (byte) 10);
        double double4 = normalDistributionImpl2.density(3.175169392061453d);
        try {
            double double7 = normalDistributionImpl2.cumulativeProbability(8.941144909753433d, 2.2948711289906125d);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.7508638739482679E-22d + "'", double4 == 1.7508638739482679E-22d);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 32, (java.lang.Number) Double.NaN, false);
        boolean boolean4 = numberIsTooLargeException3.getBoundIsAllowed();
        java.lang.Throwable throwable5 = null;
        try {
            numberIsTooLargeException3.addSuppressed(throwable5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

//    @Test
//    public void test374() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test374");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        int int6 = randomDataImpl0.nextSecureInt(0, (int) (short) 10);
//        double double9 = randomDataImpl0.nextUniform(0.9866275920404853d, (double) '#');
//        try {
//            int[] intArray12 = randomDataImpl0.nextPermutation(16, 31);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 31 is larger than the maximum (16): permutation size (31) exceeds permuation domain (16)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 19.490270476945d + "'", double3 == 19.490270476945d);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 9 + "'", int6 == 9);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 16.236988078382108d + "'", double9 == 16.236988078382108d);
//    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(56.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 56.00000000000001d + "'", double1 == 56.00000000000001d);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(Double.NaN, 100.03497115658965d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

//    @Test
//    public void test377() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test377");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        int int6 = randomDataImpl0.nextSecureInt(0, (int) (short) 10);
//        int int9 = randomDataImpl0.nextInt(0, (int) '#');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl13 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 0, (double) '#', 0.6610060414837631d);
//        double double14 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl13);
//        java.lang.String str16 = randomDataImpl0.nextSecureHexString(9);
//        try {
//            java.lang.String str18 = randomDataImpl0.nextHexString(0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): length (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 22.15226794161441d + "'", double3 == 22.15226794161441d);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2 + "'", int6 == 2);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 7.0d + "'", double14 == 7.0d);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "e949c6a98" + "'", str16.equals("e949c6a98"));
//    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 1L, (double) (short) 1);
        double double3 = normalDistributionImpl2.getStandardDeviation();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

//    @Test
//    public void test379() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test379");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        int int6 = randomDataImpl0.nextSecureInt(0, (int) (short) 10);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl9 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 1L, (double) (short) 1);
//        double double11 = normalDistributionImpl9.density(0.9866275920404853d);
//        double double12 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl9);
//        try {
//            double double15 = randomDataImpl0.nextF(3.2609579964406024d, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): degrees of freedom (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 24.290560785947896d + "'", double3 == 24.290560785947896d);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 7 + "'", int6 == 7);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.398906612308477d + "'", double11 == 0.398906612308477d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.24648496513695192d + "'", double12 == 0.24648496513695192d);
//    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        long long1 = org.apache.commons.math.util.FastMath.round(0.4970107950629486d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 6L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9459101490553132d + "'", double1 == 1.9459101490553132d);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 100.0f);
        java.lang.Number number2 = notStrictlyPositiveException1.getMin();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0 + "'", number2.equals(0));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.5503356286700535d, (-1.0d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        java.lang.Object[] objArray7 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException("", objArray7);
        java.lang.Throwable[] throwableArray9 = convergenceException8.getSuppressed();
        java.lang.Class<?> wildcardClass10 = convergenceException8.getClass();
        java.lang.Object[] objArray18 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException("", objArray18);
        java.lang.Throwable[] throwableArray20 = convergenceException19.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable21 = null;
        java.lang.Object[] objArray28 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException("", objArray28);
        java.lang.Throwable[] throwableArray30 = convergenceException29.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException19, localizable21, (java.lang.Object[]) throwableArray30);
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException8, "", (java.lang.Object[]) throwableArray30);
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException37 = new org.apache.commons.math.exception.OutOfRangeException(localizable33, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 10.0f, (java.lang.Number) (byte) 10);
        org.apache.commons.math.exception.util.Localizable localizable38 = outOfRangeException37.getGeneralPattern();
        java.lang.Object[] objArray45 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException("", objArray45);
        java.lang.Throwable[] throwableArray47 = convergenceException46.getSuppressed();
        java.lang.Class<?> wildcardClass48 = convergenceException46.getClass();
        java.lang.Object[] objArray56 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException57 = new org.apache.commons.math.ConvergenceException("", objArray56);
        java.lang.Throwable[] throwableArray58 = convergenceException57.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable59 = null;
        java.lang.Object[] objArray66 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException67 = new org.apache.commons.math.ConvergenceException("", objArray66);
        java.lang.Throwable[] throwableArray68 = convergenceException67.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException69 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException57, localizable59, (java.lang.Object[]) throwableArray68);
        org.apache.commons.math.ConvergenceException convergenceException70 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException46, "", (java.lang.Object[]) throwableArray68);
        org.apache.commons.math.MathException mathException71 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException32, localizable38, (java.lang.Object[]) throwableArray68);
        java.lang.Object[] objArray78 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException79 = new org.apache.commons.math.ConvergenceException("", objArray78);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException80 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable38, objArray78);
        org.apache.commons.math.exception.util.Localizable localizable81 = maxIterationsExceededException80.getGeneralPattern();
        java.lang.Object[] objArray85 = new java.lang.Object[] { 1.0d };
        org.apache.commons.math.ConvergenceException convergenceException86 = new org.apache.commons.math.ConvergenceException("", objArray85);
        org.apache.commons.math.MathException mathException87 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException80, "org.apache.commons.math.MathException: org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)", objArray85);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(throwableArray20);
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertNotNull(throwableArray30);
        org.junit.Assert.assertTrue("'" + localizable38 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable38.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray45);
        org.junit.Assert.assertNotNull(throwableArray47);
        org.junit.Assert.assertNotNull(wildcardClass48);
        org.junit.Assert.assertNotNull(objArray56);
        org.junit.Assert.assertNotNull(throwableArray58);
        org.junit.Assert.assertNotNull(objArray66);
        org.junit.Assert.assertNotNull(throwableArray68);
        org.junit.Assert.assertNotNull(objArray78);
        org.junit.Assert.assertTrue("'" + localizable81 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable81.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray85);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ((-0.5772156677920679d), 0.0d, (double) 8L, (int) '4');
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeedSecure((long) (short) 1);
        try {
            int int6 = randomDataImpl1.nextBinomial(100, 100.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 100 out of [0, 1] range");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (short) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.4223479548124092d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.45054629246894656d + "'", double1 == 0.45054629246894656d);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 16);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2041199826559248d + "'", double1 == 1.2041199826559248d);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 52L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.9474491130379984d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8119290521338487d + "'", double1 == 0.8119290521338487d);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 10.0f, (java.lang.Number) 2.718281828459045d, false);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getGeneralPattern();
        java.lang.Object[] objArray6 = null;
        org.apache.commons.math.MathException mathException7 = new org.apache.commons.math.MathException(localizable5, objArray6);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.015061189059456493d, 0.13313701469396122d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.015061189059456494d + "'", double2 == 0.015061189059456494d);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        double double1 = org.apache.commons.math.util.FastMath.rint(2.302585092994046d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        java.lang.Object[] objArray7 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException("", objArray7);
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException("", objArray7);
        java.lang.String str10 = convergenceException9.getPattern();
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(1.9459101490553132d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 111.49243885254238d + "'", double1 == 111.49243885254238d);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.9036417751182644d, 0.0d, 52.780035402544826d, 9);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(5);
    }

//    @Test
//    public void test400() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test400");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        int int6 = randomDataImpl0.nextSecureInt(0, (int) (short) 10);
//        int int9 = randomDataImpl0.nextInt(0, (int) '#');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl13 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 0, (double) '#', 0.6610060414837631d);
//        double double14 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl13);
//        java.lang.String str16 = randomDataImpl0.nextSecureHexString(9);
//        double double19 = randomDataImpl0.nextGaussian(8.995696864925984d, 8.941144909753433d);
//        try {
//            int int22 = randomDataImpl0.nextBinomial(0, (double) 52L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 52 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 25.425368887289306d + "'", double3 == 25.425368887289306d);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 32 + "'", int9 == 32);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-50.33899395851522d) + "'", double14 == (-50.33899395851522d));
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "cc2b48d79" + "'", str16.equals("cc2b48d79"));
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 10.27754605161789d + "'", double19 == 10.27754605161789d);
//    }

//    @Test
//    public void test401() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test401");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        int int6 = randomDataImpl0.nextSecureInt(0, (int) (short) 10);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl9 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 1L, (double) (short) 1);
//        double double11 = normalDistributionImpl9.density(0.9866275920404853d);
//        double double12 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl9);
//        int int16 = randomDataImpl0.nextHypergeometric(6, 5, 0);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 24.445576929479255d + "'", double3 == 24.445576929479255d);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 5 + "'", int6 == 5);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.398906612308477d + "'", double11 == 0.398906612308477d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.122688407517981d + "'", double12 == 2.122688407517981d);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.8119290521338487d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8119290521338488d + "'", double1 == 0.8119290521338488d);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 1L, (double) (short) 1);
        double double4 = normalDistributionImpl2.density(0.9866275920404853d);
        double double7 = normalDistributionImpl2.cumulativeProbability(0.8119290521338488d, 10.796755102555307d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.398906612308477d + "'", double4 == 0.398906612308477d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.5745894825315334d + "'", double7 == 0.5745894825315334d);
    }

//    @Test
//    public void test404() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test404");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        randomDataImpl0.reSeedSecure((long) '#');
//        long long7 = randomDataImpl0.nextPoisson(56.0d);
//        try {
//            java.lang.String str9 = randomDataImpl0.nextSecureHexString(0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): length (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 30.4009900143837d + "'", double3 == 30.4009900143837d);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 58L + "'", long7 == 58L);
//    }

//    @Test
//    public void test405() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test405");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        randomDataImpl0.reSeedSecure((long) '4');
//        double double7 = randomDataImpl0.nextChiSquare((double) 1.0f);
//        randomDataImpl0.reSeed();
//        int int11 = randomDataImpl0.nextBinomial((int) (byte) 0, 0.40702284518531173d);
//        long long13 = randomDataImpl0.nextPoisson(52.476429300534186d);
//        try {
//            double double16 = randomDataImpl0.nextF(0.0d, 86.78823356954149d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): degrees of freedom (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 31.070658489830898d + "'", double3 == 31.070658489830898d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.00108540597018335d + "'", double7 == 0.00108540597018335d);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 47L + "'", long13 == 47L);
//    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        double double1 = org.apache.commons.math.util.FastMath.expm1(1.4261759824292803E-20d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4261759824292803E-20d + "'", double1 == 1.4261759824292803E-20d);
    }

//    @Test
//    public void test407() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test407");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        randomDataImpl0.reSeedSecure((long) '4');
//        double double7 = randomDataImpl0.nextChiSquare((double) 1.0f);
//        randomDataImpl0.reSeed();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl12 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) (short) 1, 3.141592653589793d);
//        double double13 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl12);
//        randomDataImpl0.reSeed();
//        double double17 = randomDataImpl0.nextBeta(0.0140436016105168d, 1.0d);
//        double double20 = randomDataImpl0.nextCauchy(4.605170185988093d, 44.57328158058611d);
//        try {
//            long long23 = randomDataImpl0.nextSecureLong((long) 36, (long) (-1));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 36 is larger than, or equal to, the maximum (-1): lower bound (36) must be strictly less than upper bound (-1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 28.684378717019687d + "'", double3 == 28.684378717019687d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.07528775265030055d + "'", double7 == 0.07528775265030055d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.0d + "'", double13 == 2.0d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.020522318791679352d + "'", double17 == 0.020522318791679352d);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + (-12.116718412395105d) + "'", double20 == (-12.116718412395105d));
//    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(56.00000000000001d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): standard deviation (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number0);
        boolean boolean2 = notStrictlyPositiveException1.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8390715290764524d) + "'", double1 == (-0.8390715290764524d));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 13, (long) 21);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 21L + "'", long2 == 21L);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        double double1 = org.apache.commons.math.util.FastMath.signum(11.047516915046149d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable1, (java.lang.Number) 10.0f, (java.lang.Number) 2.718281828459045d, false);
        java.lang.Number number6 = numberIsTooSmallException5.getMin();
        java.lang.Object[] objArray14 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException("", objArray14);
        java.lang.Throwable[] throwableArray16 = convergenceException15.getSuppressed();
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException5, "hi!", (java.lang.Object[]) throwableArray16);
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException("a6a8f52cba4d7302", (java.lang.Object[]) throwableArray16);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 2.718281828459045d + "'", number6.equals(2.718281828459045d));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(throwableArray16);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(1.1863680640712555d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2878315793230852d + "'", double1 == 1.2878315793230852d);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        double double1 = org.apache.commons.math.special.Erf.erf((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8427007929497151d) + "'", double1 == (-0.8427007929497151d));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(175.8653249411727d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 13.261422432800062d + "'", double1 == 13.261422432800062d);
    }

//    @Test
//    public void test417() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test417");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 1L, (double) (short) 1);
//        double double5 = normalDistributionImpl2.cumulativeProbability(0.0d, 0.0d);
//        double double7 = normalDistributionImpl2.cumulativeProbability(10.000000000000002d);
//        double double9 = normalDistributionImpl2.cumulativeProbability(2.302585092994046d);
//        double double10 = normalDistributionImpl2.getMean();
//        double double11 = normalDistributionImpl2.sample();
//        double double12 = normalDistributionImpl2.getMean();
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.9036417751182644d + "'", double9 == 0.9036417751182644d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0316374448464236d + "'", double11 == 1.0316374448464236d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
//    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        float float2 = org.apache.commons.math.util.FastMath.min(17.0f, (float) 32L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 17.0f + "'", float2 == 17.0f);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (short) 1, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        java.lang.Object[] objArray6 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException("", objArray6);
        java.lang.Throwable[] throwableArray8 = convergenceException7.getSuppressed();
        java.lang.Class<?> wildcardClass9 = convergenceException7.getClass();
        java.lang.Object[] objArray17 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException("", objArray17);
        java.lang.Throwable[] throwableArray19 = convergenceException18.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException("", objArray27);
        java.lang.Throwable[] throwableArray29 = convergenceException28.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException18, localizable20, (java.lang.Object[]) throwableArray29);
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException7, "", (java.lang.Object[]) throwableArray29);
        org.apache.commons.math.exception.util.Localizable localizable32 = convergenceException31.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException34 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable32, (java.lang.Number) 2.718281828459045d);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException38 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10L, (java.lang.Number) (-0.7853981633974483d), true);
        java.lang.Object[] objArray39 = numberIsTooLargeException38.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException40 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable32, objArray39);
        org.apache.commons.math.exception.util.Localizable localizable41 = mathIllegalArgumentException40.getSpecificPattern();
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(throwableArray29);
        org.junit.Assert.assertNotNull(localizable32);
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertNull(localizable41);
    }

//    @Test
//    public void test421() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test421");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        int int6 = randomDataImpl0.nextSecureInt(0, (int) (short) 10);
//        int int9 = randomDataImpl0.nextInt(0, (int) '#');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl13 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 0, (double) '#', 0.6610060414837631d);
//        double double14 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl13);
//        double double15 = normalDistributionImpl13.sample();
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 44.799253237397195d + "'", double3 == 44.799253237397195d);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 5 + "'", int6 == 5);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-11.038441819493801d) + "'", double14 == (-11.038441819493801d));
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-50.4992543512033d) + "'", double15 == (-50.4992543512033d));
//    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 4, (long) 21);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 21L + "'", long2 == 21L);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 1L, (double) (short) 1);
        double double5 = normalDistributionImpl2.cumulativeProbability(0.0d, 0.0d);
        double double7 = normalDistributionImpl2.cumulativeProbability(10.000000000000002d);
        double[] doubleArray9 = normalDistributionImpl2.sample(34);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray9);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        double double2 = org.apache.commons.math.util.FastMath.max(100.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

//    @Test
//    public void test425() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test425");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        randomDataImpl0.reSeedSecure((long) 'a');
//        int int8 = randomDataImpl0.nextInt(10, 36);
//        try {
//            int int11 = randomDataImpl0.nextPascal((int) '4', 8.941144909753433d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 8.941 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 7.049337483591849d + "'", double3 == 7.049337483591849d);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 32 + "'", int8 == 32);
//    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        int int1 = org.apache.commons.math.util.FastMath.abs(7);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 7 + "'", int1 == 7);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 10.0f, (java.lang.Number) (byte) 10);
        org.apache.commons.math.exception.util.Localizable localizable5 = outOfRangeException4.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) (short) 100, (java.lang.Number) 11013.232874703393d, false);
        java.lang.Number number10 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException13 = new org.apache.commons.math.exception.OutOfRangeException(localizable5, number10, (java.lang.Number) (-0.6687796041949511d), (java.lang.Number) 2.6881171418161356E43d);
        java.lang.Number number14 = outOfRangeException13.getHi();
        java.lang.Number number15 = outOfRangeException13.getHi();
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 2.6881171418161356E43d + "'", number14.equals(2.6881171418161356E43d));
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 2.6881171418161356E43d + "'", number15.equals(2.6881171418161356E43d));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 100L, false);
    }

//    @Test
//    public void test430() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test430");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        java.lang.String str2 = randomDataImpl0.nextHexString(16);
//        java.lang.Class<?> wildcardClass3 = randomDataImpl0.getClass();
//        randomDataImpl0.reSeedSecure();
//        double double7 = randomDataImpl0.nextBeta(3.711575027927711E25d, (double) 100L);
//        randomDataImpl0.reSeedSecure();
//        double double10 = randomDataImpl0.nextExponential(111.49243885254238d);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "acf57acb556e189f" + "'", str2.equals("acf57acb556e189f"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.9999999981057772d + "'", double7 == 0.9999999981057772d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 354.7577630510578d + "'", double10 == 354.7577630510578d);
//    }

//    @Test
//    public void test431() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test431");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        double double6 = randomDataImpl0.nextCauchy(1.6704649792860586d, 86.78823356954149d);
//        try {
//            long long9 = randomDataImpl0.nextSecureLong(67L, 0L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 67 is larger than, or equal to, the maximum (0): lower bound (67) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 7.5769818272685585d + "'", double3 == 7.5769818272685585d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-47.73341988826592d) + "'", double6 == (-47.73341988826592d));
//    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        long long2 = org.apache.commons.math.util.FastMath.max(71L, (long) '#');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 71L + "'", long2 == 71L);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException3 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 100.0f);
        java.lang.String str4 = notStrictlyPositiveException3.toString();
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException();
        notStrictlyPositiveException3.addSuppressed((java.lang.Throwable) mathException5);
        java.lang.Object[] objArray7 = notStrictlyPositiveException3.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException8 = new org.apache.commons.math.MaxIterationsExceededException(33, "2be42114f03bb789", objArray7);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str4.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertNotNull(objArray7);
    }

//    @Test
//    public void test434() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test434");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        int int6 = randomDataImpl0.nextSecureInt(0, (int) (short) 10);
//        int int9 = randomDataImpl0.nextInt(0, (int) '#');
//        randomDataImpl0.reSeed();
//        try {
//            int int14 = randomDataImpl0.nextHypergeometric((int) (byte) 0, 0, 36);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): population size (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 5.977642269025711d + "'", double3 == 5.977642269025711d);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 14 + "'", int9 == 14);
//    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        float float2 = org.apache.commons.math.util.FastMath.max(0.0f, (float) 6L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 6.0f + "'", float2 == 6.0f);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(1.3344764463477395E-9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0011009568661199708d + "'", double1 == 0.0011009568661199708d);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        double double1 = org.apache.commons.math.util.FastMath.expm1(30.743471618496034d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.2476054601406227E13d + "'", double1 == 2.2476054601406227E13d);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.015156788265952006d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.015272234910556496d + "'", double1 == 0.015272234910556496d);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 65.88002677690446d, (java.lang.Number) 1.0d, false);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5440211108893698d) + "'", double1 == (-0.5440211108893698d));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        double double1 = org.apache.commons.math.util.FastMath.asin(16.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        double double2 = org.apache.commons.math.util.FastMath.max(2.6881171418161356E43d, (double) 97);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.6881171418161356E43d + "'", double2 == 2.6881171418161356E43d);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.5d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5210953054937474d + "'", double1 == 0.5210953054937474d);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        double double1 = org.apache.commons.math.special.Erf.erf(5.15973307183883d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999999999997057d + "'", double1 == 0.9999999999997057d);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        double double2 = org.apache.commons.math.util.FastMath.pow(1.2041199826559248d, 2.2948711289906125d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5315342435588306d + "'", double2 == 1.5315342435588306d);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 4);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0634370688955608d + "'", double1 == 2.0634370688955608d);
    }

//    @Test
//    public void test447() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test447");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        int int6 = randomDataImpl0.nextSecureInt(0, (int) (short) 10);
//        int int9 = randomDataImpl0.nextInt(0, (int) '#');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl13 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 0, (double) '#', 0.6610060414837631d);
//        double double14 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl13);
//        double double15 = normalDistributionImpl13.getMean();
//        normalDistributionImpl13.reseedRandomGenerator((long) 3);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 6.6164926131935715d + "'", double3 == 6.6164926131935715d);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 3 + "'", int6 == 3);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-3.661006041483823d) + "'", double14 == (-3.661006041483823d));
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
//    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 9L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 9 + "'", int1 == 9);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(201.71315737027922d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11557.312589575195d + "'", double1 == 11557.312589575195d);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((-0.8813735870195429d), 0.9821806397330133d);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        double double1 = org.apache.commons.math.special.Erf.erf(0.02052926951466442d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.02316154617212319d + "'", double1 == 0.02316154617212319d);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        double double1 = org.apache.commons.math.util.FastMath.atan(13.360915028654388d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4960904415889775d + "'", double1 == 1.4960904415889775d);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 16L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 16 + "'", int1 == 16);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        double double1 = org.apache.commons.math.util.FastMath.atan(4.605170185988092d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3569687047394818d + "'", double1 == 1.3569687047394818d);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.45054629246894656d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6712274521121335d + "'", double1 == 0.6712274521121335d);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        double double1 = org.apache.commons.math.util.FastMath.acosh(11.047516915046149d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.093298166482431d + "'", double1 == 3.093298166482431d);
    }

//    @Test
//    public void test457() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test457");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        double double6 = randomDataImpl0.nextCauchy(1.6704649792860586d, 86.78823356954149d);
//        long long9 = randomDataImpl0.nextLong((long) 1, (long) 16);
//        double double11 = randomDataImpl0.nextChiSquare(56.0d);
//        randomDataImpl0.reSeedSecure((-1L));
//        try {
//            int int16 = randomDataImpl0.nextBinomial(8, 12.801827480081469d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 12.802 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 5.079494892128646d + "'", double3 == 5.079494892128646d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 11.470998491384297d + "'", double6 == 11.470998491384297d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 8L + "'", long9 == 8L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 58.77255998870773d + "'", double11 == 58.77255998870773d);
//    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        double double1 = org.apache.commons.math.util.FastMath.expm1(13.752058065869516d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 938517.7052992809d + "'", double1 == 938517.7052992809d);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        double double1 = org.apache.commons.math.util.FastMath.log10(6.644933029497134d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8224906082935876d + "'", double1 == 0.8224906082935876d);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        long long1 = org.apache.commons.math.util.FastMath.round((double) '4');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 52L + "'", long1 == 52L);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.623347079987928d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4210854715202004E-14d + "'", double1 == 1.4210854715202004E-14d);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(4.7699116308280525d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6833332855487244d + "'", double1 == 1.6833332855487244d);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException5 = new org.apache.commons.math.exception.OutOfRangeException(localizable1, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 10.0f, (java.lang.Number) (byte) 10);
        org.apache.commons.math.exception.util.Localizable localizable6 = outOfRangeException5.getGeneralPattern();
        java.lang.Object[] objArray13 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException("", objArray13);
        java.lang.Throwable[] throwableArray15 = convergenceException14.getSuppressed();
        java.lang.Class<?> wildcardClass16 = convergenceException14.getClass();
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        java.lang.Object[] objArray24 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException25 = new org.apache.commons.math.ConvergenceException("", objArray24);
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException14, localizable17, objArray24);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException27 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable6, objArray24);
        java.lang.Throwable throwable28 = null;
        java.lang.Object[] objArray32 = new java.lang.Object[] { 1.0d };
        org.apache.commons.math.ConvergenceException convergenceException33 = new org.apache.commons.math.ConvergenceException("", objArray32);
        org.apache.commons.math.MathException mathException34 = new org.apache.commons.math.MathException(throwable28, "", objArray32);
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException(localizable6, objArray32);
        java.lang.Object[] objArray36 = null;
        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException(localizable6, objArray36);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(objArray32);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        long long1 = org.apache.commons.math.util.FastMath.round((-258.5630901011945d));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-259L) + "'", long1 == (-259L));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        double double1 = org.apache.commons.math.special.Gamma.logGamma((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 78.0922235533153d + "'", double1 == 78.0922235533153d);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 10.0f, (java.lang.Number) 2.718281828459045d, false);
        java.lang.Number number5 = numberIsTooSmallException4.getMin();
        java.lang.Object[] objArray13 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException("", objArray13);
        java.lang.Throwable[] throwableArray15 = convergenceException14.getSuppressed();
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException4, "hi!", (java.lang.Object[]) throwableArray15);
        boolean boolean17 = numberIsTooSmallException4.getBoundIsAllowed();
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException4);
        java.lang.String str19 = mathException18.toString();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 2.718281828459045d + "'", number5.equals(2.718281828459045d));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.apache.commons.math.MathException: 10 is smaller than, or equal to, the minimum (2.718)" + "'", str19.equals("org.apache.commons.math.MathException: 10 is smaller than, or equal to, the minimum (2.718)"));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) 1, (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.6235200651203063d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0108824780885988d + "'", double1 == 0.0108824780885988d);
    }

//    @Test
//    public void test470() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test470");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        int int6 = randomDataImpl0.nextSecureInt(0, (int) (short) 10);
//        double double8 = randomDataImpl0.nextExponential(3.41643668911758d);
//        try {
//            java.lang.String str10 = randomDataImpl0.nextHexString((int) (short) -1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): length (-1)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.27598487706996d + "'", double3 == 3.27598487706996d);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2 + "'", int6 == 2);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.0832014229523503d + "'", double8 == 2.0832014229523503d);
//    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 9);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.999999969540041d + "'", double1 == 0.999999969540041d);
    }

//    @Test
//    public void test472() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test472");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        randomDataImpl0.reSeedSecure((long) 'a');
//        int int8 = randomDataImpl0.nextBinomial(12, 0.9585304424717216d);
//        try {
//            double double11 = randomDataImpl0.nextCauchy((double) 35L, (-0.3089204746152383d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.309 is smaller than, or equal to, the minimum (0): scale (-0.309)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.113963367661645d + "'", double3 == 4.113963367661645d);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
//    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        double double1 = org.apache.commons.math.util.FastMath.log10(1.0317425226950845d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.013571330116420874d + "'", double1 == 0.013571330116420874d);
    }

//    @Test
//    public void test474() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test474");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long3 = randomDataImpl0.nextSecureLong((long) 18, (long) 32);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 20L + "'", long3 == 20L);
//    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 100.0f);
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable3 = notStrictlyPositiveException1.getSpecificPattern();
        java.lang.Number number4 = notStrictlyPositiveException1.getArgument();
        java.lang.Number number5 = notStrictlyPositiveException1.getMin();
        org.junit.Assert.assertNull(localizable2);
        org.junit.Assert.assertNull(localizable3);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 100.0f + "'", number4.equals(100.0f));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0 + "'", number5.equals(0));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0.5972534764549589d, (java.lang.Number) 0.9999999999997057d, false);
    }

//    @Test
//    public void test477() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test477");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextChiSquare(0.398906612308477d);
//        randomDataImpl0.reSeedSecure();
//        double double5 = randomDataImpl0.nextT((double) 100.0f);
//        int int9 = randomDataImpl0.nextHypergeometric((int) '4', 36, (int) (byte) 1);
//        double double11 = randomDataImpl0.nextExponential(0.5276511697442289d);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.555870611193584E-5d + "'", double2 == 9.555870611193584E-5d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.09372728576604687d + "'", double5 == 0.09372728576604687d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.08008157859897952d + "'", double11 == 0.08008157859897952d);
//    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 100, (float) 31);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 31.0f + "'", float2 == 31.0f);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 16L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8886109.520507872d + "'", double1 == 8886109.520507872d);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.6235200651203063d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.48459667165920106d + "'", double1 == 0.48459667165920106d);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 0.0d, (double) 9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): standard deviation (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 10, (long) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (byte) -1, (java.lang.Number) 1.0d, (java.lang.Number) 44.57328158058611d);
        java.lang.Number number4 = outOfRangeException3.getLo();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 1.0d + "'", number4.equals(1.0d));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        java.lang.Object[] objArray8 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException("", objArray8);
        java.lang.Throwable[] throwableArray10 = convergenceException9.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        java.lang.Object[] objArray18 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException("", objArray18);
        java.lang.Throwable[] throwableArray20 = convergenceException19.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException9, localizable11, (java.lang.Object[]) throwableArray20);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException22 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "863e1f46c93d370b", (java.lang.Object[]) throwableArray20);
        int int23 = maxIterationsExceededException22.getMaxIterations();
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(throwableArray20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        double double2 = org.apache.commons.math.util.FastMath.pow(11.465100751341446d, Double.NaN);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.2041199826559248d, number1, (java.lang.Number) 1.6821738184917205d);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException5 = new org.apache.commons.math.exception.OutOfRangeException(localizable1, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 10.0f, (java.lang.Number) (byte) 10);
        org.apache.commons.math.exception.util.Localizable localizable6 = outOfRangeException5.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException10 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable6, (java.lang.Number) (short) 100, (java.lang.Number) 11013.232874703393d, false);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException12 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 100.0f);
        org.apache.commons.math.exception.util.Localizable localizable13 = notStrictlyPositiveException12.getSpecificPattern();
        java.lang.Object[] objArray21 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException("", objArray21);
        java.lang.Throwable[] throwableArray23 = convergenceException22.getSuppressed();
        java.lang.Class<?> wildcardClass24 = convergenceException22.getClass();
        java.lang.Object[] objArray32 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException33 = new org.apache.commons.math.ConvergenceException("", objArray32);
        org.apache.commons.math.ConvergenceException convergenceException34 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException22, "", objArray32);
        java.lang.Object[] objArray42 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException43 = new org.apache.commons.math.ConvergenceException("", objArray42);
        java.lang.Throwable[] throwableArray44 = convergenceException43.getSuppressed();
        java.lang.Class<?> wildcardClass45 = convergenceException43.getClass();
        java.lang.Object[] objArray53 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException("", objArray53);
        org.apache.commons.math.ConvergenceException convergenceException55 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException43, "", objArray53);
        org.apache.commons.math.ConvergenceException convergenceException56 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException22, "hi!", objArray53);
        org.apache.commons.math.ConvergenceException convergenceException57 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException12, "", objArray53);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException58 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, objArray53);
        java.lang.Object[] objArray65 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException66 = new org.apache.commons.math.ConvergenceException("", objArray65);
        java.lang.Throwable[] throwableArray67 = convergenceException66.getSuppressed();
        java.lang.Class<?> wildcardClass68 = convergenceException66.getClass();
        java.lang.Object[] objArray76 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException77 = new org.apache.commons.math.ConvergenceException("", objArray76);
        java.lang.Throwable[] throwableArray78 = convergenceException77.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable79 = null;
        java.lang.Object[] objArray86 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException87 = new org.apache.commons.math.ConvergenceException("", objArray86);
        java.lang.Throwable[] throwableArray88 = convergenceException87.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException89 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException77, localizable79, (java.lang.Object[]) throwableArray88);
        org.apache.commons.math.ConvergenceException convergenceException90 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException66, "", (java.lang.Object[]) throwableArray88);
        org.apache.commons.math.ConvergenceException convergenceException91 = new org.apache.commons.math.ConvergenceException(localizable6, (java.lang.Object[]) throwableArray88);
        org.apache.commons.math.ConvergenceException convergenceException92 = new org.apache.commons.math.ConvergenceException("919dd57de", (java.lang.Object[]) throwableArray88);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNull(localizable13);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(throwableArray23);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertNotNull(throwableArray44);
        org.junit.Assert.assertNotNull(wildcardClass45);
        org.junit.Assert.assertNotNull(objArray53);
        org.junit.Assert.assertNotNull(objArray65);
        org.junit.Assert.assertNotNull(throwableArray67);
        org.junit.Assert.assertNotNull(wildcardClass68);
        org.junit.Assert.assertNotNull(objArray76);
        org.junit.Assert.assertNotNull(throwableArray78);
        org.junit.Assert.assertNotNull(objArray86);
        org.junit.Assert.assertNotNull(throwableArray88);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        double double1 = org.apache.commons.math.util.FastMath.rint((-0.6687796041949511d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(35.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.916079783099616d + "'", double1 == 5.916079783099616d);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        java.lang.Object[] objArray6 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException("", objArray6);
        java.lang.Throwable[] throwableArray8 = convergenceException7.getSuppressed();
        java.lang.Class<?> wildcardClass9 = convergenceException7.getClass();
        java.lang.Object[] objArray17 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException("", objArray17);
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException7, "", objArray17);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException26 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 100L, (java.lang.Number) 10.000000000000002d, false);
        java.lang.Object[] objArray27 = numberIsTooSmallException26.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException28 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "", objArray27);
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException19, "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)", objArray27);
        java.lang.String str30 = mathException29.toString();
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException29);
        java.lang.Object[] objArray32 = mathException29.getArguments();
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "org.apache.commons.math.MathException: org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str30.equals("org.apache.commons.math.MathException: org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertNotNull(objArray32);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (short) 1, (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        int int2 = org.apache.commons.math.util.FastMath.min(97, 27);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 27 + "'", int2 == 27);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 10.0f, (java.lang.Number) 2.718281828459045d, false);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException9 = new org.apache.commons.math.exception.OutOfRangeException(localizable5, (java.lang.Number) 10, (java.lang.Number) 4.239302734211798d, (java.lang.Number) 1.4261759824292803E-20d);
        java.lang.Object[] objArray16 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException("", objArray16);
        java.lang.Throwable[] throwableArray18 = convergenceException17.getSuppressed();
        java.lang.Class<?> wildcardClass19 = convergenceException17.getClass();
        java.lang.Object[] objArray27 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException("", objArray27);
        java.lang.Throwable[] throwableArray29 = convergenceException28.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable30 = null;
        java.lang.Object[] objArray37 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException38 = new org.apache.commons.math.ConvergenceException("", objArray37);
        java.lang.Throwable[] throwableArray39 = convergenceException38.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException40 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException28, localizable30, (java.lang.Object[]) throwableArray39);
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException17, "", (java.lang.Object[]) throwableArray39);
        org.apache.commons.math.exception.util.Localizable localizable42 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException46 = new org.apache.commons.math.exception.OutOfRangeException(localizable42, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 10.0f, (java.lang.Number) (byte) 10);
        org.apache.commons.math.exception.util.Localizable localizable47 = outOfRangeException46.getGeneralPattern();
        java.lang.Object[] objArray54 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException55 = new org.apache.commons.math.ConvergenceException("", objArray54);
        java.lang.Throwable[] throwableArray56 = convergenceException55.getSuppressed();
        java.lang.Class<?> wildcardClass57 = convergenceException55.getClass();
        java.lang.Object[] objArray65 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException66 = new org.apache.commons.math.ConvergenceException("", objArray65);
        java.lang.Throwable[] throwableArray67 = convergenceException66.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable68 = null;
        java.lang.Object[] objArray75 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException76 = new org.apache.commons.math.ConvergenceException("", objArray75);
        java.lang.Throwable[] throwableArray77 = convergenceException76.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException78 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException66, localizable68, (java.lang.Object[]) throwableArray77);
        org.apache.commons.math.ConvergenceException convergenceException79 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException55, "", (java.lang.Object[]) throwableArray77);
        org.apache.commons.math.MathException mathException80 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException41, localizable47, (java.lang.Object[]) throwableArray77);
        java.lang.Throwable throwable82 = null;
        java.lang.Object[] objArray86 = new java.lang.Object[] { 1.0d };
        org.apache.commons.math.ConvergenceException convergenceException87 = new org.apache.commons.math.ConvergenceException("", objArray86);
        org.apache.commons.math.MathException mathException88 = new org.apache.commons.math.MathException(throwable82, "", objArray86);
        org.apache.commons.math.ConvergenceException convergenceException89 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException41, "919dd57de", objArray86);
        org.apache.commons.math.ConvergenceException convergenceException90 = new org.apache.commons.math.ConvergenceException(localizable5, objArray86);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(throwableArray29);
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertNotNull(throwableArray39);
        org.junit.Assert.assertTrue("'" + localizable47 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable47.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray54);
        org.junit.Assert.assertNotNull(throwableArray56);
        org.junit.Assert.assertNotNull(wildcardClass57);
        org.junit.Assert.assertNotNull(objArray65);
        org.junit.Assert.assertNotNull(throwableArray67);
        org.junit.Assert.assertNotNull(objArray75);
        org.junit.Assert.assertNotNull(throwableArray77);
        org.junit.Assert.assertNotNull(objArray86);
    }

//    @Test
//    public void test494() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test494");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        java.lang.String str2 = randomDataImpl0.nextHexString(16);
//        java.lang.Class<?> wildcardClass3 = randomDataImpl0.getClass();
//        try {
//            int int6 = randomDataImpl0.nextInt(30, (int) (short) 10);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 30 is larger than, or equal to, the maximum (10): lower bound (30) must be strictly less than upper bound (10)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "eb0da1a5ea839692" + "'", str2.equals("eb0da1a5ea839692"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException7 = new org.apache.commons.math.exception.OutOfRangeException(localizable3, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 10.0f, (java.lang.Number) (byte) 10);
        org.apache.commons.math.exception.util.Localizable localizable8 = outOfRangeException7.getGeneralPattern();
        java.lang.Object[] objArray15 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException("", objArray15);
        java.lang.Throwable[] throwableArray17 = convergenceException16.getSuppressed();
        java.lang.Class<?> wildcardClass18 = convergenceException16.getClass();
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        java.lang.Object[] objArray26 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException("", objArray26);
        org.apache.commons.math.MathException mathException28 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException16, localizable19, objArray26);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException29 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable8, objArray26);
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException("", objArray26);
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException("", objArray26);
        org.apache.commons.math.exception.util.Localizable localizable32 = mathException31.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(localizable32);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 10.0f, (java.lang.Number) (byte) 10);
        org.apache.commons.math.exception.util.Localizable localizable5 = outOfRangeException4.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) (short) 100, (java.lang.Number) 11013.232874703393d, false);
        java.lang.Number number10 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException13 = new org.apache.commons.math.exception.OutOfRangeException(localizable5, number10, (java.lang.Number) (-0.6687796041949511d), (java.lang.Number) 2.6881171418161356E43d);
        java.lang.Number number14 = outOfRangeException13.getLo();
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + (-0.6687796041949511d) + "'", number14.equals((-0.6687796041949511d)));
    }

//    @Test
//    public void test497() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test497");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextChiSquare(0.398906612308477d);
//        double double4 = randomDataImpl0.nextT(13.754204050669212d);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.744927971311212E-6d + "'", double2 == 4.744927971311212E-6d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.981153707124144d + "'", double4 == 0.981153707124144d);
//    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException("c57e573ea", objArray1);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 6);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 6.0f + "'", float1 == 6.0f);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        java.lang.Object[] objArray7 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException("", objArray7);
        java.lang.Throwable[] throwableArray9 = convergenceException8.getSuppressed();
        java.lang.Class<?> wildcardClass10 = convergenceException8.getClass();
        java.lang.Object[] objArray18 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException("", objArray18);
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException8, "", objArray18);
        org.apache.commons.math.exception.util.Localizable localizable21 = convergenceException20.getGeneralPattern();
        java.lang.Object[] objArray28 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException("", objArray28);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable21, objArray28);
        java.lang.Object[] objArray38 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException("", objArray38);
        org.apache.commons.math.ConvergenceException convergenceException40 = new org.apache.commons.math.ConvergenceException("", objArray38);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException41 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable21, objArray38);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(localizable21);
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertNotNull(objArray38);
    }
}

