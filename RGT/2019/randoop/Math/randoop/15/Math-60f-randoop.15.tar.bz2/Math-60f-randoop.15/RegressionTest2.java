import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test1() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(3.175169392061453d, 52.780035402544826d, 4.239302734211798d);
        double[] doubleArray5 = normalDistributionImpl3.sample(15);
        org.junit.Assert.assertNotNull(doubleArray5);
    }

    @Test
    public void test2() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test2");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 1L, (double) (short) 1);
        double double5 = normalDistributionImpl2.cumulativeProbability(0.0d, 0.0d);
        double double7 = normalDistributionImpl2.cumulativeProbability(10.000000000000002d);
        double double9 = normalDistributionImpl2.cumulativeProbability(2.302585092994046d);
        double double10 = normalDistributionImpl2.getMean();
        double[] doubleArray12 = normalDistributionImpl2.sample(97);
        double double13 = normalDistributionImpl2.getMean();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.9036417751182644d + "'", double9 == 0.9036417751182644d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
    }

    @Test
    public void test3() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test3");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (short) 0, 31L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }
}

