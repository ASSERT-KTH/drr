import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 9.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.0d + "'", double1 == 9.0d);
    }

//    @Test
//    public void test002() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test002");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextChiSquare(0.398906612308477d);
//        randomDataImpl0.reSeedSecure();
//        double double5 = randomDataImpl0.nextT((double) 100.0f);
//        double double7 = randomDataImpl0.nextChiSquare(0.23151936896823624d);
//        java.lang.String str9 = randomDataImpl0.nextHexString(18);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5398907041877406E-5d + "'", double2 == 1.5398907041877406E-5d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.330069567820944d + "'", double5 == 0.330069567820944d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 5.644044591410018d + "'", double7 == 5.644044591410018d);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "a15c80ea61ffc4b3d4" + "'", str9.equals("a15c80ea61ffc4b3d4"));
//    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        double double1 = org.apache.commons.math.special.Erf.erf((-0.5995445690087358d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6034974578256168d) + "'", double1 == (-0.6034974578256168d));
    }

//    @Test
//    public void test004() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test004");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        int int6 = randomDataImpl0.nextSecureInt(0, (int) (short) 10);
//        randomDataImpl0.reSeedSecure((long) 12);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.7903759725004953d + "'", double3 == 0.7903759725004953d);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 5 + "'", int6 == 5);
//    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        long long2 = org.apache.commons.math.util.FastMath.max(20L, (long) 6);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 20L + "'", long2 == 20L);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        java.lang.Object[] objArray8 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException("", objArray8);
        java.lang.Throwable[] throwableArray10 = convergenceException9.getSuppressed();
        java.lang.Class<?> wildcardClass11 = convergenceException9.getClass();
        java.lang.Object[] objArray19 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException("", objArray19);
        java.lang.Throwable[] throwableArray21 = convergenceException20.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable22 = null;
        java.lang.Object[] objArray29 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException("", objArray29);
        java.lang.Throwable[] throwableArray31 = convergenceException30.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException20, localizable22, (java.lang.Object[]) throwableArray31);
        org.apache.commons.math.ConvergenceException convergenceException33 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException9, "", (java.lang.Object[]) throwableArray31);
        org.apache.commons.math.exception.util.Localizable localizable34 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException38 = new org.apache.commons.math.exception.OutOfRangeException(localizable34, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 10.0f, (java.lang.Number) (byte) 10);
        org.apache.commons.math.exception.util.Localizable localizable39 = outOfRangeException38.getGeneralPattern();
        java.lang.Object[] objArray46 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException47 = new org.apache.commons.math.ConvergenceException("", objArray46);
        java.lang.Throwable[] throwableArray48 = convergenceException47.getSuppressed();
        java.lang.Class<?> wildcardClass49 = convergenceException47.getClass();
        java.lang.Object[] objArray57 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException58 = new org.apache.commons.math.ConvergenceException("", objArray57);
        java.lang.Throwable[] throwableArray59 = convergenceException58.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable60 = null;
        java.lang.Object[] objArray67 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException68 = new org.apache.commons.math.ConvergenceException("", objArray67);
        java.lang.Throwable[] throwableArray69 = convergenceException68.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException70 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException58, localizable60, (java.lang.Object[]) throwableArray69);
        org.apache.commons.math.ConvergenceException convergenceException71 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException47, "", (java.lang.Object[]) throwableArray69);
        org.apache.commons.math.MathException mathException72 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException33, localizable39, (java.lang.Object[]) throwableArray69);
        org.apache.commons.math.ConvergenceException convergenceException73 = new org.apache.commons.math.ConvergenceException("", (java.lang.Object[]) throwableArray69);
        org.apache.commons.math.MathException mathException74 = new org.apache.commons.math.MathException("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)", (java.lang.Object[]) throwableArray69);
        java.lang.Object[] objArray75 = mathException74.getArguments();
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(throwableArray21);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(throwableArray31);
        org.junit.Assert.assertTrue("'" + localizable39 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable39.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray46);
        org.junit.Assert.assertNotNull(throwableArray48);
        org.junit.Assert.assertNotNull(wildcardClass49);
        org.junit.Assert.assertNotNull(objArray57);
        org.junit.Assert.assertNotNull(throwableArray59);
        org.junit.Assert.assertNotNull(objArray67);
        org.junit.Assert.assertNotNull(throwableArray69);
        org.junit.Assert.assertNotNull(objArray75);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 97.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-259L), (float) 9L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-259.0f) + "'", float2 == (-259.0f));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 10.0f, (java.lang.Number) (byte) 10);
        org.apache.commons.math.exception.util.Localizable localizable5 = outOfRangeException4.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) (short) 100, (java.lang.Number) 11013.232874703393d, false);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException11 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 100.0f);
        org.apache.commons.math.exception.util.Localizable localizable12 = notStrictlyPositiveException11.getSpecificPattern();
        java.lang.Object[] objArray20 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException("", objArray20);
        java.lang.Throwable[] throwableArray22 = convergenceException21.getSuppressed();
        java.lang.Class<?> wildcardClass23 = convergenceException21.getClass();
        java.lang.Object[] objArray31 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException("", objArray31);
        org.apache.commons.math.ConvergenceException convergenceException33 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException21, "", objArray31);
        java.lang.Object[] objArray41 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException("", objArray41);
        java.lang.Throwable[] throwableArray43 = convergenceException42.getSuppressed();
        java.lang.Class<?> wildcardClass44 = convergenceException42.getClass();
        java.lang.Object[] objArray52 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException53 = new org.apache.commons.math.ConvergenceException("", objArray52);
        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException42, "", objArray52);
        org.apache.commons.math.ConvergenceException convergenceException55 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException21, "hi!", objArray52);
        org.apache.commons.math.ConvergenceException convergenceException56 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException11, "", objArray52);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException57 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, objArray52);
        java.lang.Object[] objArray64 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException65 = new org.apache.commons.math.ConvergenceException("", objArray64);
        java.lang.Throwable[] throwableArray66 = convergenceException65.getSuppressed();
        java.lang.Class<?> wildcardClass67 = convergenceException65.getClass();
        java.lang.Object[] objArray75 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException76 = new org.apache.commons.math.ConvergenceException("", objArray75);
        java.lang.Throwable[] throwableArray77 = convergenceException76.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable78 = null;
        java.lang.Object[] objArray85 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException86 = new org.apache.commons.math.ConvergenceException("", objArray85);
        java.lang.Throwable[] throwableArray87 = convergenceException86.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException88 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException76, localizable78, (java.lang.Object[]) throwableArray87);
        org.apache.commons.math.ConvergenceException convergenceException89 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException65, "", (java.lang.Object[]) throwableArray87);
        org.apache.commons.math.ConvergenceException convergenceException90 = new org.apache.commons.math.ConvergenceException(localizable5, (java.lang.Object[]) throwableArray87);
        java.lang.String str91 = convergenceException90.getPattern();
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNull(localizable12);
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(throwableArray22);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(objArray41);
        org.junit.Assert.assertNotNull(throwableArray43);
        org.junit.Assert.assertNotNull(wildcardClass44);
        org.junit.Assert.assertNotNull(objArray52);
        org.junit.Assert.assertNotNull(objArray64);
        org.junit.Assert.assertNotNull(throwableArray66);
        org.junit.Assert.assertNotNull(wildcardClass67);
        org.junit.Assert.assertNotNull(objArray75);
        org.junit.Assert.assertNotNull(throwableArray77);
        org.junit.Assert.assertNotNull(objArray85);
        org.junit.Assert.assertNotNull(throwableArray87);
        org.junit.Assert.assertTrue("'" + str91 + "' != '" + "{0} out of [{1}, {2}] range" + "'", str91.equals("{0} out of [{1}, {2}] range"));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.017453292519943295d + "'", double1 == 0.017453292519943295d);
    }

//    @Test
//    public void test011() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test011");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextChiSquare(0.398906612308477d);
//        double double5 = randomDataImpl0.nextBeta(4.158638853279167d, 0.13313701469396122d);
//        java.lang.String str7 = randomDataImpl0.nextHexString(22);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.007491108390705375d + "'", double2 == 0.007491108390705375d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.9999559537824507d + "'", double5 == 0.9999559537824507d);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "c4cacf68d12f50b58eda94" + "'", str7.equals("c4cacf68d12f50b58eda94"));
//    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 4L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }

//    @Test
//    public void test013() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test013");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        int int6 = randomDataImpl0.nextSecureInt(0, (int) (short) 10);
//        double double9 = randomDataImpl0.nextUniform(0.9866275920404853d, (double) '#');
//        randomDataImpl0.reSeed(16L);
//        try {
//            double double13 = randomDataImpl0.nextT(0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): degrees of freedom (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 8.371402775539117d + "'", double3 == 8.371402775539117d);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 7 + "'", int6 == 7);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 11.145701008299202d + "'", double9 == 11.145701008299202d);
//    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 100.0f);
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable3 = notStrictlyPositiveException1.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable4 = notStrictlyPositiveException1.getSpecificPattern();
        java.lang.Object[] objArray11 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException("", objArray11);
        java.lang.Throwable[] throwableArray13 = convergenceException12.getSuppressed();
        java.lang.Class<?> wildcardClass14 = convergenceException12.getClass();
        java.lang.Object[] objArray22 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException("", objArray22);
        java.lang.Throwable[] throwableArray24 = convergenceException23.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        java.lang.Object[] objArray32 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException33 = new org.apache.commons.math.ConvergenceException("", objArray32);
        java.lang.Throwable[] throwableArray34 = convergenceException33.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException23, localizable25, (java.lang.Object[]) throwableArray34);
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException12, "", (java.lang.Object[]) throwableArray34);
        org.apache.commons.math.exception.util.Localizable localizable37 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException41 = new org.apache.commons.math.exception.OutOfRangeException(localizable37, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 10.0f, (java.lang.Number) (byte) 10);
        org.apache.commons.math.exception.util.Localizable localizable42 = outOfRangeException41.getGeneralPattern();
        java.lang.Object[] objArray49 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException50 = new org.apache.commons.math.ConvergenceException("", objArray49);
        java.lang.Throwable[] throwableArray51 = convergenceException50.getSuppressed();
        java.lang.Class<?> wildcardClass52 = convergenceException50.getClass();
        java.lang.Object[] objArray60 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException61 = new org.apache.commons.math.ConvergenceException("", objArray60);
        java.lang.Throwable[] throwableArray62 = convergenceException61.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable63 = null;
        java.lang.Object[] objArray70 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException71 = new org.apache.commons.math.ConvergenceException("", objArray70);
        java.lang.Throwable[] throwableArray72 = convergenceException71.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException73 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException61, localizable63, (java.lang.Object[]) throwableArray72);
        org.apache.commons.math.ConvergenceException convergenceException74 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException50, "", (java.lang.Object[]) throwableArray72);
        org.apache.commons.math.MathException mathException75 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException36, localizable42, (java.lang.Object[]) throwableArray72);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException79 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable42, (java.lang.Number) 100L, (java.lang.Number) 11013.232874703393d, false);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException83 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 56.0d, (java.lang.Number) 0.9171523356672744d, true);
        numberIsTooSmallException79.addSuppressed((java.lang.Throwable) numberIsTooLargeException83);
        notStrictlyPositiveException1.addSuppressed((java.lang.Throwable) numberIsTooLargeException83);
        java.lang.Number number86 = numberIsTooLargeException83.getMax();
        org.junit.Assert.assertNull(localizable2);
        org.junit.Assert.assertNull(localizable3);
        org.junit.Assert.assertNull(localizable4);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(throwableArray24);
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(throwableArray34);
        org.junit.Assert.assertTrue("'" + localizable42 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable42.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertNotNull(throwableArray51);
        org.junit.Assert.assertNotNull(wildcardClass52);
        org.junit.Assert.assertNotNull(objArray60);
        org.junit.Assert.assertNotNull(throwableArray62);
        org.junit.Assert.assertNotNull(objArray70);
        org.junit.Assert.assertNotNull(throwableArray72);
        org.junit.Assert.assertTrue("'" + number86 + "' != '" + 0.9171523356672744d + "'", number86.equals(0.9171523356672744d));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 10.0f, (java.lang.Number) (byte) 10);
        org.apache.commons.math.exception.util.Localizable localizable5 = outOfRangeException4.getGeneralPattern();
        java.lang.Number number6 = outOfRangeException4.getHi();
        java.lang.Number number7 = outOfRangeException4.getHi();
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (byte) 10 + "'", number6.equals((byte) 10));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (byte) 10 + "'", number7.equals((byte) 10));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ((double) '4', 0.9036417751182644d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        double double1 = org.apache.commons.math.util.FastMath.log(0.9227673888116062d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.08037809269623272d) + "'", double1 == (-0.08037809269623272d));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 7, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.0d + "'", double2 == 7.0d);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.896296018267969E13d + "'", double1 == 7.896296018267969E13d);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(3.790626942629932d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        double double1 = org.apache.commons.math.util.FastMath.abs(3.141592653589793d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.141592653589793d + "'", double1 == 3.141592653589793d);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 32, (java.lang.Number) (short) 10, (java.lang.Number) 0.398906612308477d);
        java.lang.Number number4 = outOfRangeException3.getLo();
        java.lang.Number number5 = outOfRangeException3.getLo();
        java.lang.Number number6 = outOfRangeException3.getArgument();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (short) 10 + "'", number4.equals((short) 10));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (short) 10 + "'", number5.equals((short) 10));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 32 + "'", number6.equals(32));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 10);
        java.lang.Number number2 = notStrictlyPositiveException1.getMin();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0 + "'", number2.equals(0));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        double double1 = org.apache.commons.math.util.FastMath.asinh(4.627182148660879d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.2365722420271585d + "'", double1 == 2.2365722420271585d);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(1.936115103562213d, (double) 32L, 8.388192002392895d, 7);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.999999999999657d + "'", double4 == 0.999999999999657d);
    }

//    @Test
//    public void test026() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test026");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        int int6 = randomDataImpl0.nextSecureInt(0, (int) (short) 10);
//        double double8 = randomDataImpl0.nextExponential(3.41643668911758d);
//        try {
//            long long11 = randomDataImpl0.nextSecureLong(71L, 0L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 71 is larger than, or equal to, the maximum (0): lower bound (71) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 7.948696683830161d + "'", double3 == 7.948696683830161d);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 5 + "'", int6 == 5);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.4378317696115155d + "'", double8 == 1.4378317696115155d);
//    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.9821806397330133d, 0.9474491130379984d, 13.207354306806415d, 27);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.6295505449206482d + "'", double4 == 0.6295505449206482d);
    }

//    @Test
//    public void test028() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test028");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        randomDataImpl0.reSeedSecure((long) '4');
//        double double7 = randomDataImpl0.nextChiSquare((double) 1.0f);
//        randomDataImpl0.reSeed();
//        int int11 = randomDataImpl0.nextBinomial((int) (byte) 0, 0.40702284518531173d);
//        double double14 = randomDataImpl0.nextUniform((double) (short) 1, (double) 4);
//        double double17 = randomDataImpl0.nextGamma((double) (byte) 100, 8.995696864925984d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 6.843097971334233d + "'", double3 == 6.843097971334233d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.6243572450282606d + "'", double7 == 1.6243572450282606d);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.6594480363430075d + "'", double14 == 1.6594480363430075d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 805.8192384809655d + "'", double17 == 805.8192384809655d);
//    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 10.0f, (java.lang.Number) (byte) 10);
        org.apache.commons.math.exception.util.Localizable localizable5 = outOfRangeException4.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) (short) 100, (java.lang.Number) 11013.232874703393d, false);
        java.lang.Number number10 = numberIsTooSmallException9.getArgument();
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + (short) 100 + "'", number10.equals((short) 100));
    }

//    @Test
//    public void test030() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test030");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        int int6 = randomDataImpl0.nextSecureInt(0, (int) (short) 10);
//        int int9 = randomDataImpl0.nextInt(0, (int) '#');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl13 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 0, (double) '#', 0.6610060414837631d);
//        double double14 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl13);
//        java.lang.String str16 = randomDataImpl0.nextSecureHexString(9);
//        double double19 = randomDataImpl0.nextGaussian(8.995696864925984d, 8.941144909753433d);
//        long long21 = randomDataImpl0.nextPoisson(0.6204290412244261d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 6.751143534863933d + "'", double3 == 6.751143534863933d);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 5 + "'", int6 == 5);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 11.812032778095482d + "'", double14 == 11.812032778095482d);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "54bdfd25f" + "'", str16.equals("54bdfd25f"));
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-1.8828107572943757d) + "'", double19 == (-1.8828107572943757d));
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
//    }

//    @Test
//    public void test031() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test031");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        randomDataImpl0.reSeedSecure((long) '4');
//        double double7 = randomDataImpl0.nextChiSquare((double) 1.0f);
//        double double10 = randomDataImpl0.nextF(1.5707963267948966d, (double) 34);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl14 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.11717703212592656d, 9.81191859311744d, 4.0d);
//        double double15 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl14);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 6.721731521631732d + "'", double3 == 6.721731521631732d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.03922136897574888d + "'", double7 == 0.03922136897574888d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.4626891635348451d + "'", double10 == 1.4626891635348451d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 5.929095625243367d + "'", double15 == 5.929095625243367d);
//    }

//    @Test
//    public void test032() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test032");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        int int6 = randomDataImpl0.nextSecureInt(0, (int) (short) 10);
//        int int9 = randomDataImpl0.nextInt(0, (int) '#');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl13 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 0, (double) '#', 0.6610060414837631d);
//        double double14 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl13);
//        java.lang.String str16 = randomDataImpl0.nextSecureHexString(9);
//        double double19 = randomDataImpl0.nextGaussian(8.995696864925984d, 8.941144909753433d);
//        try {
//            randomDataImpl0.setSecureAlgorithm("80639cb324", "863e1f46c93d370b");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: 863e1f46c93d370b");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 6.618477970948394d + "'", double3 == 6.618477970948394d);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 7 + "'", int6 == 7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 17 + "'", int9 == 17);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-41.0d) + "'", double14 == (-41.0d));
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "fa3cc0473" + "'", str16.equals("fa3cc0473"));
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 20.26078020594414d + "'", double19 == 20.26078020594414d);
//    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.015061189059456494d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0001134218519636d + "'", double1 == 1.0001134218519636d);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeedSecure((long) (short) 1);
        randomDataImpl1.reSeedSecure();
        int int7 = randomDataImpl1.nextZipf(18, 2.4243120925476567d);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 33L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 33.00000000000001d + "'", double1 == 33.00000000000001d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        java.lang.Throwable throwable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException7 = new org.apache.commons.math.exception.OutOfRangeException(localizable3, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 10.0f, (java.lang.Number) (byte) 10);
        org.apache.commons.math.exception.util.Localizable localizable8 = outOfRangeException7.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException16 = new org.apache.commons.math.exception.OutOfRangeException(localizable12, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 10.0f, (java.lang.Number) (byte) 10);
        org.apache.commons.math.exception.util.Localizable localizable17 = outOfRangeException16.getGeneralPattern();
        java.lang.Object[] objArray24 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException25 = new org.apache.commons.math.ConvergenceException("", objArray24);
        java.lang.Throwable[] throwableArray26 = convergenceException25.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable27 = null;
        java.lang.Object[] objArray34 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException("", objArray34);
        java.lang.Throwable[] throwableArray36 = convergenceException35.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException37 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException25, localizable27, (java.lang.Object[]) throwableArray36);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException38 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable17, (java.lang.Object[]) throwableArray36);
        java.lang.Object[] objArray39 = maxIterationsExceededException38.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException40 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 100, "", objArray39);
        org.apache.commons.math.MathException mathException41 = new org.apache.commons.math.MathException(localizable8, objArray39);
        java.lang.Number number42 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException43 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable8, number42);
        org.apache.commons.math.exception.util.Localizable localizable44 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException46 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 100.0f);
        org.apache.commons.math.exception.util.Localizable localizable47 = notStrictlyPositiveException46.getSpecificPattern();
        java.lang.Object[] objArray55 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException56 = new org.apache.commons.math.ConvergenceException("", objArray55);
        java.lang.Throwable[] throwableArray57 = convergenceException56.getSuppressed();
        java.lang.Class<?> wildcardClass58 = convergenceException56.getClass();
        java.lang.Object[] objArray66 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException67 = new org.apache.commons.math.ConvergenceException("", objArray66);
        org.apache.commons.math.ConvergenceException convergenceException68 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException56, "", objArray66);
        java.lang.Object[] objArray76 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException77 = new org.apache.commons.math.ConvergenceException("", objArray76);
        java.lang.Throwable[] throwableArray78 = convergenceException77.getSuppressed();
        java.lang.Class<?> wildcardClass79 = convergenceException77.getClass();
        java.lang.Object[] objArray87 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException88 = new org.apache.commons.math.ConvergenceException("", objArray87);
        org.apache.commons.math.ConvergenceException convergenceException89 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException77, "", objArray87);
        org.apache.commons.math.ConvergenceException convergenceException90 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException56, "hi!", objArray87);
        org.apache.commons.math.ConvergenceException convergenceException91 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException46, "", objArray87);
        java.lang.String str92 = convergenceException91.getPattern();
        java.lang.Object[] objArray93 = convergenceException91.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException94 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, localizable44, objArray93);
        org.apache.commons.math.MathException mathException95 = new org.apache.commons.math.MathException(throwable1, "c57e573ea", objArray93);
        org.apache.commons.math.MathException mathException96 = new org.apache.commons.math.MathException("a15c80ea61ffc4b3d4", objArray93);
        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(throwableArray26);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(throwableArray36);
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertNull(localizable47);
        org.junit.Assert.assertNotNull(objArray55);
        org.junit.Assert.assertNotNull(throwableArray57);
        org.junit.Assert.assertNotNull(wildcardClass58);
        org.junit.Assert.assertNotNull(objArray66);
        org.junit.Assert.assertNotNull(objArray76);
        org.junit.Assert.assertNotNull(throwableArray78);
        org.junit.Assert.assertNotNull(wildcardClass79);
        org.junit.Assert.assertNotNull(objArray87);
        org.junit.Assert.assertTrue("'" + str92 + "' != '" + "" + "'", str92.equals(""));
        org.junit.Assert.assertNotNull(objArray93);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 100.0f);
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable3 = notStrictlyPositiveException1.getSpecificPattern();
        java.lang.Number number4 = notStrictlyPositiveException1.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable5 = notStrictlyPositiveException1.getGeneralPattern();
        org.junit.Assert.assertNull(localizable2);
        org.junit.Assert.assertNull(localizable3);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 100.0f + "'", number4.equals(100.0f));
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        double double1 = org.apache.commons.math.util.FastMath.sinh(1.6704649792860586d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.5632394322605294d + "'", double1 == 2.5632394322605294d);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.01694013920788123d, 0.01694013920788123d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9419339984549245d + "'", double2 == 0.9419339984549245d);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.11717703212592656d, 7.922060682256977d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.574048747574973E-6d + "'", double2 == 6.574048747574973E-6d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        java.lang.Object[] objArray6 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException("", objArray6);
        java.lang.Throwable[] throwableArray8 = convergenceException7.getSuppressed();
        java.lang.Class<?> wildcardClass9 = convergenceException7.getClass();
        java.lang.Object[] objArray17 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException("", objArray17);
        java.lang.Throwable[] throwableArray19 = convergenceException18.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException("", objArray27);
        java.lang.Throwable[] throwableArray29 = convergenceException28.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException18, localizable20, (java.lang.Object[]) throwableArray29);
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException7, "", (java.lang.Object[]) throwableArray29);
        org.apache.commons.math.exception.util.Localizable localizable32 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException36 = new org.apache.commons.math.exception.OutOfRangeException(localizable32, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 10.0f, (java.lang.Number) (byte) 10);
        org.apache.commons.math.exception.util.Localizable localizable37 = outOfRangeException36.getGeneralPattern();
        java.lang.Object[] objArray44 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException45 = new org.apache.commons.math.ConvergenceException("", objArray44);
        java.lang.Throwable[] throwableArray46 = convergenceException45.getSuppressed();
        java.lang.Class<?> wildcardClass47 = convergenceException45.getClass();
        java.lang.Object[] objArray55 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException56 = new org.apache.commons.math.ConvergenceException("", objArray55);
        java.lang.Throwable[] throwableArray57 = convergenceException56.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable58 = null;
        java.lang.Object[] objArray65 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException66 = new org.apache.commons.math.ConvergenceException("", objArray65);
        java.lang.Throwable[] throwableArray67 = convergenceException66.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException68 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException56, localizable58, (java.lang.Object[]) throwableArray67);
        org.apache.commons.math.ConvergenceException convergenceException69 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException45, "", (java.lang.Object[]) throwableArray67);
        org.apache.commons.math.MathException mathException70 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException31, localizable37, (java.lang.Object[]) throwableArray67);
        java.lang.Throwable throwable72 = null;
        java.lang.Object[] objArray76 = new java.lang.Object[] { 1.0d };
        org.apache.commons.math.ConvergenceException convergenceException77 = new org.apache.commons.math.ConvergenceException("", objArray76);
        org.apache.commons.math.MathException mathException78 = new org.apache.commons.math.MathException(throwable72, "", objArray76);
        org.apache.commons.math.ConvergenceException convergenceException79 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException31, "919dd57de", objArray76);
        java.lang.Object[] objArray80 = convergenceException79.getArguments();
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(throwableArray29);
        org.junit.Assert.assertTrue("'" + localizable37 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable37.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertNotNull(throwableArray46);
        org.junit.Assert.assertNotNull(wildcardClass47);
        org.junit.Assert.assertNotNull(objArray55);
        org.junit.Assert.assertNotNull(throwableArray57);
        org.junit.Assert.assertNotNull(objArray65);
        org.junit.Assert.assertNotNull(throwableArray67);
        org.junit.Assert.assertNotNull(objArray76);
        org.junit.Assert.assertNotNull(objArray80);
    }

//    @Test
//    public void test042() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test042");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 1L, (double) (short) 1);
//        double double5 = normalDistributionImpl2.cumulativeProbability(0.0d, 0.0d);
//        double double7 = normalDistributionImpl2.cumulativeProbability(10.000000000000002d);
//        double double9 = normalDistributionImpl2.cumulativeProbability(2.302585092994046d);
//        double double10 = normalDistributionImpl2.getMean();
//        double double11 = normalDistributionImpl2.sample();
//        double double12 = normalDistributionImpl2.getStandardDeviation();
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.9036417751182644d + "'", double9 == 0.9036417751182644d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.33561568610268344d + "'", double11 == 0.33561568610268344d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
//    }

//    @Test
//    public void test043() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test043");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        randomDataImpl0.reSeedSecure((long) '#');
//        long long7 = randomDataImpl0.nextPoisson(56.0d);
//        try {
//            int int10 = randomDataImpl0.nextBinomial((int) 'a', 7.981279804720954d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 7.981 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 9.59604875486866d + "'", double3 == 9.59604875486866d);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 54L + "'", long7 == 54L);
//    }

//    @Test
//    public void test044() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test044");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        randomDataImpl0.reSeedSecure((long) '4');
//        double double7 = randomDataImpl0.nextChiSquare((double) 1.0f);
//        double double10 = randomDataImpl0.nextF(1.5707963267948966d, (double) 34);
//        java.lang.String str12 = randomDataImpl0.nextSecureHexString(9);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 9.614011030717908d + "'", double3 == 9.614011030717908d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.839730909241869d + "'", double7 == 1.839730909241869d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.662417130429843d + "'", double10 == 1.662417130429843d);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "baebd7eee" + "'", str12.equals("baebd7eee"));
//    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException5 = new org.apache.commons.math.exception.OutOfRangeException(localizable1, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 10.0f, (java.lang.Number) (byte) 10);
        org.apache.commons.math.exception.util.Localizable localizable6 = outOfRangeException5.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException14 = new org.apache.commons.math.exception.OutOfRangeException(localizable10, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 10.0f, (java.lang.Number) (byte) 10);
        org.apache.commons.math.exception.util.Localizable localizable15 = outOfRangeException14.getGeneralPattern();
        java.lang.Object[] objArray22 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException("", objArray22);
        java.lang.Throwable[] throwableArray24 = convergenceException23.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        java.lang.Object[] objArray32 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException33 = new org.apache.commons.math.ConvergenceException("", objArray32);
        java.lang.Throwable[] throwableArray34 = convergenceException33.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException23, localizable25, (java.lang.Object[]) throwableArray34);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException36 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable15, (java.lang.Object[]) throwableArray34);
        java.lang.Object[] objArray37 = maxIterationsExceededException36.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException38 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 100, "", objArray37);
        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException(localizable6, objArray37);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException43 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable6, (java.lang.Number) 1.1752011936438014d, (java.lang.Number) 0.61875315207275d, false);
        java.lang.Object[] objArray51 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException52 = new org.apache.commons.math.ConvergenceException("", objArray51);
        java.lang.Throwable[] throwableArray53 = convergenceException52.getSuppressed();
        java.lang.Class<?> wildcardClass54 = convergenceException52.getClass();
        java.lang.Object[] objArray62 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException63 = new org.apache.commons.math.ConvergenceException("", objArray62);
        org.apache.commons.math.ConvergenceException convergenceException64 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException52, "", objArray62);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException71 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 100L, (java.lang.Number) 10.000000000000002d, false);
        java.lang.Object[] objArray72 = numberIsTooSmallException71.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException73 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "", objArray72);
        org.apache.commons.math.MathException mathException74 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException64, "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)", objArray72);
        org.apache.commons.math.MathException mathException75 = new org.apache.commons.math.MathException("4e91ca1fd531df76daf34440a21eba9e15e1cfc0e4fd2754ca119a106b125d399e7a5d28189361c270a03f629343216065bd", objArray72);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException76 = new org.apache.commons.math.MaxIterationsExceededException(15, localizable6, objArray72);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable15.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(throwableArray24);
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(throwableArray34);
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertNotNull(objArray51);
        org.junit.Assert.assertNotNull(throwableArray53);
        org.junit.Assert.assertNotNull(wildcardClass54);
        org.junit.Assert.assertNotNull(objArray62);
        org.junit.Assert.assertNotNull(objArray72);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.6542297019220056d, 6.952624968924705d, (double) (short) 100, 97);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 3.40081118778545E-4d + "'", double4 == 3.40081118778545E-4d);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.8319176536209936d);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a');
    }

//    @Test
//    public void test049() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test049");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        randomDataImpl0.reSeedSecure((long) 'a');
//        int int8 = randomDataImpl0.nextInt(10, 36);
//        double double11 = randomDataImpl0.nextF((double) 26.0f, 5.298292365610485d);
//        double double14 = randomDataImpl0.nextUniform(0.038667623566644216d, 66.78690542226121d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 9.156181462421332d + "'", double3 == 9.156181462421332d);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 2.101333753744988d + "'", double11 == 2.101333753744988d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 54.85907906241573d + "'", double14 == 54.85907906241573d);
//    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        double double1 = org.apache.commons.math.util.FastMath.log(1.136390668384291d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.1278571594051268d + "'", double1 == 0.1278571594051268d);
    }

//    @Test
//    public void test051() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test051");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        randomDataImpl0.reSeedSecure((long) '4');
//        double double7 = randomDataImpl0.nextChiSquare((double) 1.0f);
//        randomDataImpl0.reSeed();
//        int int11 = randomDataImpl0.nextBinomial((int) (byte) 0, 0.40702284518531173d);
//        long long14 = randomDataImpl0.nextLong((long) 29, (long) 33);
//        randomDataImpl0.reSeedSecure();
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 9.160919125000353d + "'", double3 == 9.160919125000353d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.290976997624149d + "'", double7 == 0.290976997624149d);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 30L + "'", long14 == 30L);
//    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(7.922060682256977d, 303.76685876477154d);
        try {
            double double4 = normalDistributionImpl2.inverseCumulativeProbability(12.421787449410939d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 12.422 out of [0, 1] range");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        java.lang.Object[] objArray6 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException("", objArray6);
        java.lang.Throwable[] throwableArray8 = convergenceException7.getSuppressed();
        java.lang.Class<?> wildcardClass9 = convergenceException7.getClass();
        org.apache.commons.math.exception.util.Localizable localizable10 = convergenceException7.getSpecificPattern();
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNull(localizable10);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 100.0f);
        java.lang.String str2 = notStrictlyPositiveException1.toString();
        org.apache.commons.math.MathException mathException3 = new org.apache.commons.math.MathException();
        notStrictlyPositiveException1.addSuppressed((java.lang.Throwable) mathException3);
        org.apache.commons.math.exception.util.Localizable localizable5 = notStrictlyPositiveException1.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str2.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertNull(localizable5);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 32, (java.lang.Number) (short) 10, (java.lang.Number) 0.398906612308477d);
        java.lang.Number number4 = outOfRangeException3.getLo();
        java.lang.Number number5 = outOfRangeException3.getLo();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException9 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 32, (java.lang.Number) Double.NaN, false);
        boolean boolean10 = numberIsTooLargeException9.getBoundIsAllowed();
        outOfRangeException3.addSuppressed((java.lang.Throwable) numberIsTooLargeException9);
        java.lang.Number number12 = numberIsTooLargeException9.getMax();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (short) 10 + "'", number4.equals((short) 10));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (short) 10 + "'", number5.equals((short) 10));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertEquals((double) number12, Double.NaN, 0);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(0);
        org.apache.commons.math.exception.util.Localizable localizable2 = maxIterationsExceededException1.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAX_ITERATIONS_EXCEEDED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAX_ITERATIONS_EXCEEDED));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 16);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.833213344056216d + "'", double1 == 2.833213344056216d);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        double double1 = org.apache.commons.math.util.FastMath.signum(1.0927080481029119d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

//    @Test
//    public void test059() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test059");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextUniform(0.5585053606381855d, (double) 30);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 8.444786207965075d + "'", double4 == 8.444786207965075d);
//    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 100.0f);
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getSpecificPattern();
        java.lang.Object[] objArray10 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException("", objArray10);
        java.lang.Throwable[] throwableArray12 = convergenceException11.getSuppressed();
        java.lang.Class<?> wildcardClass13 = convergenceException11.getClass();
        java.lang.Object[] objArray21 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException("", objArray21);
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException11, "", objArray21);
        java.lang.Object[] objArray31 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException("", objArray31);
        java.lang.Throwable[] throwableArray33 = convergenceException32.getSuppressed();
        java.lang.Class<?> wildcardClass34 = convergenceException32.getClass();
        java.lang.Object[] objArray42 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException43 = new org.apache.commons.math.ConvergenceException("", objArray42);
        org.apache.commons.math.ConvergenceException convergenceException44 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException32, "", objArray42);
        org.apache.commons.math.ConvergenceException convergenceException45 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException11, "hi!", objArray42);
        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException1, "", objArray42);
        java.lang.String str47 = convergenceException46.getPattern();
        java.lang.Throwable[] throwableArray48 = convergenceException46.getSuppressed();
        java.lang.Class<?> wildcardClass49 = convergenceException46.getClass();
        org.junit.Assert.assertNull(localizable2);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(throwableArray33);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "" + "'", str47.equals(""));
        org.junit.Assert.assertNotNull(throwableArray48);
        org.junit.Assert.assertNotNull(wildcardClass49);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        double double1 = org.apache.commons.math.util.FastMath.expm1(9.000000000000002d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8102.083927575399d + "'", double1 == 8102.083927575399d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) ' ');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 32 + "'", int1 == 32);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        java.lang.Object[] objArray6 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException("", objArray6);
        java.lang.Throwable[] throwableArray8 = convergenceException7.getSuppressed();
        java.lang.Class<?> wildcardClass9 = convergenceException7.getClass();
        java.lang.Object[] objArray17 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException("", objArray17);
        java.lang.Throwable[] throwableArray19 = convergenceException18.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException("", objArray27);
        java.lang.Throwable[] throwableArray29 = convergenceException28.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException18, localizable20, (java.lang.Object[]) throwableArray29);
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException7, "", (java.lang.Object[]) throwableArray29);
        org.apache.commons.math.exception.util.Localizable localizable32 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException36 = new org.apache.commons.math.exception.OutOfRangeException(localizable32, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 10.0f, (java.lang.Number) (byte) 10);
        org.apache.commons.math.exception.util.Localizable localizable37 = outOfRangeException36.getGeneralPattern();
        java.lang.Object[] objArray44 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException45 = new org.apache.commons.math.ConvergenceException("", objArray44);
        java.lang.Throwable[] throwableArray46 = convergenceException45.getSuppressed();
        java.lang.Class<?> wildcardClass47 = convergenceException45.getClass();
        java.lang.Object[] objArray55 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException56 = new org.apache.commons.math.ConvergenceException("", objArray55);
        java.lang.Throwable[] throwableArray57 = convergenceException56.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable58 = null;
        java.lang.Object[] objArray65 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException66 = new org.apache.commons.math.ConvergenceException("", objArray65);
        java.lang.Throwable[] throwableArray67 = convergenceException66.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException68 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException56, localizable58, (java.lang.Object[]) throwableArray67);
        org.apache.commons.math.ConvergenceException convergenceException69 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException45, "", (java.lang.Object[]) throwableArray67);
        org.apache.commons.math.MathException mathException70 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException31, localizable37, (java.lang.Object[]) throwableArray67);
        java.lang.Throwable throwable72 = null;
        java.lang.Object[] objArray76 = new java.lang.Object[] { 1.0d };
        org.apache.commons.math.ConvergenceException convergenceException77 = new org.apache.commons.math.ConvergenceException("", objArray76);
        org.apache.commons.math.MathException mathException78 = new org.apache.commons.math.MathException(throwable72, "", objArray76);
        org.apache.commons.math.ConvergenceException convergenceException79 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException31, "919dd57de", objArray76);
        java.lang.String str80 = convergenceException31.toString();
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(throwableArray29);
        org.junit.Assert.assertTrue("'" + localizable37 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable37.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertNotNull(throwableArray46);
        org.junit.Assert.assertNotNull(wildcardClass47);
        org.junit.Assert.assertNotNull(objArray55);
        org.junit.Assert.assertNotNull(throwableArray57);
        org.junit.Assert.assertNotNull(objArray65);
        org.junit.Assert.assertNotNull(throwableArray67);
        org.junit.Assert.assertNotNull(objArray76);
        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "org.apache.commons.math.ConvergenceException: " + "'", str80.equals("org.apache.commons.math.ConvergenceException: "));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(0.5972534764549589d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.6637527079352568d + "'", double1 == 3.6637527079352568d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(396.6973669525801d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.34772858964088d + "'", double1 == 7.34772858964088d);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.2355953673343148d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.23137609444272214d + "'", double1 == 0.23137609444272214d);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 22, (float) 35);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 22.0f + "'", float2 == 22.0f);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException5 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 32, (java.lang.Number) Double.NaN, false);
        maxIterationsExceededException1.addSuppressed((java.lang.Throwable) numberIsTooLargeException5);
        java.lang.Number number7 = numberIsTooLargeException5.getMax();
        org.junit.Assert.assertEquals((double) number7, Double.NaN, 0);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 100, (float) 15);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 15.0f + "'", float2 == 15.0f);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 10.0f, (java.lang.Number) (byte) 10);
        org.apache.commons.math.exception.util.Localizable localizable5 = outOfRangeException4.getGeneralPattern();
        java.lang.Number number6 = outOfRangeException4.getHi();
        org.apache.commons.math.exception.util.Localizable localizable7 = outOfRangeException4.getGeneralPattern();
        java.lang.Number number8 = outOfRangeException4.getHi();
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (byte) 10 + "'", number6.equals((byte) 10));
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + (byte) 10 + "'", number8.equals((byte) 10));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        java.lang.Object[] objArray8 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException("", objArray8);
        java.lang.Throwable[] throwableArray10 = convergenceException9.getSuppressed();
        java.lang.Class<?> wildcardClass11 = convergenceException9.getClass();
        java.lang.Object[] objArray19 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException("", objArray19);
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException9, "", objArray19);
        org.apache.commons.math.exception.util.Localizable localizable22 = convergenceException21.getGeneralPattern();
        java.lang.Object[] objArray29 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException("", objArray29);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException31 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable22, objArray29);
        java.lang.Object[] objArray38 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException("", objArray38);
        java.lang.Throwable[] throwableArray40 = convergenceException39.getSuppressed();
        java.lang.Class<?> wildcardClass41 = convergenceException39.getClass();
        java.lang.Object[] objArray49 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException50 = new org.apache.commons.math.ConvergenceException("", objArray49);
        java.lang.Throwable[] throwableArray51 = convergenceException50.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable52 = null;
        java.lang.Object[] objArray59 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException60 = new org.apache.commons.math.ConvergenceException("", objArray59);
        java.lang.Throwable[] throwableArray61 = convergenceException60.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException62 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException50, localizable52, (java.lang.Object[]) throwableArray61);
        org.apache.commons.math.ConvergenceException convergenceException63 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException39, "", (java.lang.Object[]) throwableArray61);
        org.apache.commons.math.exception.util.Localizable localizable64 = convergenceException63.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException66 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable64, (java.lang.Number) 2.718281828459045d);
        java.lang.Object[] objArray67 = notStrictlyPositiveException66.getArguments();
        boolean boolean68 = notStrictlyPositiveException66.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable69 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException73 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable69, (java.lang.Number) 10.0f, (java.lang.Number) 2.718281828459045d, false);
        java.lang.Number number74 = numberIsTooSmallException73.getMin();
        org.apache.commons.math.exception.util.Localizable localizable75 = numberIsTooSmallException73.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException77 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable75, (java.lang.Number) 11.465100751341446d);
        java.lang.Object[] objArray84 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException85 = new org.apache.commons.math.ConvergenceException("", objArray84);
        java.lang.Throwable[] throwableArray86 = convergenceException85.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable87 = null;
        java.lang.Object[] objArray94 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException95 = new org.apache.commons.math.ConvergenceException("", objArray94);
        java.lang.Throwable[] throwableArray96 = convergenceException95.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException97 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException85, localizable87, (java.lang.Object[]) throwableArray96);
        org.apache.commons.math.MathException mathException98 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException66, localizable75, (java.lang.Object[]) throwableArray96);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException99 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, localizable22, (java.lang.Object[]) throwableArray96);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(localizable22);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(throwableArray40);
        org.junit.Assert.assertNotNull(wildcardClass41);
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertNotNull(throwableArray51);
        org.junit.Assert.assertNotNull(objArray59);
        org.junit.Assert.assertNotNull(throwableArray61);
        org.junit.Assert.assertNotNull(localizable64);
        org.junit.Assert.assertNotNull(objArray67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + number74 + "' != '" + 2.718281828459045d + "'", number74.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable75 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable75.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray84);
        org.junit.Assert.assertNotNull(throwableArray86);
        org.junit.Assert.assertNotNull(objArray94);
        org.junit.Assert.assertNotNull(throwableArray96);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(7.922060682256977d, 303.76685876477154d);
        double double5 = normalDistributionImpl2.cumulativeProbability(5.644044591410018d, 7.922060682256977d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.002991729972222412d + "'", double5 == 0.002991729972222412d);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        double double1 = org.apache.commons.math.util.FastMath.log10(65.88002677690446d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.818753767016531d + "'", double1 == 1.818753767016531d);
    }

//    @Test
//    public void test075() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test075");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(100.0d, (double) (byte) 10);
//        double double3 = normalDistributionImpl2.sample();
//        try {
//            double double5 = normalDistributionImpl2.inverseCumulativeProbability((-3.661006041483823d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: -3.661 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 96.8070723923485d + "'", double3 == 96.8070723923485d);
//    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        long long1 = org.apache.commons.math.util.FastMath.round(1.9646397077969224E-9d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        double double1 = org.apache.commons.math.util.FastMath.acos((-0.9965901122182603d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.058987236879791d + "'", double1 == 3.058987236879791d);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        double double1 = org.apache.commons.math.util.FastMath.asinh(1.0317425226950845d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9036417751182644d + "'", double1 == 0.9036417751182644d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 0.015061189059456494d);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 10.0f, (java.lang.Number) 2.718281828459045d, false);
        java.lang.Number number5 = numberIsTooSmallException4.getMin();
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException4.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) 7.694598626706421E-24d, (java.lang.Number) 0.23180484196660436d, false);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 2.718281828459045d + "'", number5.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException3 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 10);
        java.lang.Object[] objArray4 = notStrictlyPositiveException3.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException(6, "c4cacf68d12f50b58eda94", objArray4);
        org.junit.Assert.assertNotNull(objArray4);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10L, (java.lang.Number) (-0.7853981633974483d), true);
        java.lang.Number number4 = numberIsTooLargeException3.getMax();
        boolean boolean5 = numberIsTooLargeException3.getBoundIsAllowed();
        boolean boolean6 = numberIsTooLargeException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-0.7853981633974483d) + "'", number4.equals((-0.7853981633974483d)));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        double double1 = org.apache.commons.math.util.FastMath.acos(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

//    @Test
//    public void test085() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test085");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        randomDataImpl0.reSeedSecure((long) '4');
//        double double7 = randomDataImpl0.nextChiSquare((double) 1.0f);
//        randomDataImpl0.reSeed();
//        int int11 = randomDataImpl0.nextBinomial((int) (byte) 0, 0.40702284518531173d);
//        double double14 = randomDataImpl0.nextUniform((double) (short) 1, (double) 4);
//        try {
//            int int17 = randomDataImpl0.nextBinomial(3, 14.4611607995733d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 14.461 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 9.370807868385702d + "'", double3 == 9.370807868385702d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.5119137144265964d + "'", double7 == 2.5119137144265964d);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 2.135134539533282d + "'", double14 == 2.135134539533282d);
//    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(6.3490204604719394E-6d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1081131131172184E-7d + "'", double1 == 1.1081131131172184E-7d);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP((-0.953949911799454d), 0.0d, 3.790626942629932d, 29);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        double double1 = org.apache.commons.math.util.FastMath.floor(3.40081118778545E-4d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        java.lang.Object[] objArray6 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException("", objArray6);
        java.lang.Throwable[] throwableArray8 = convergenceException7.getSuppressed();
        java.lang.Class<?> wildcardClass9 = convergenceException7.getClass();
        java.lang.Object[] objArray17 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException("", objArray17);
        java.lang.Throwable[] throwableArray19 = convergenceException18.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException("", objArray27);
        java.lang.Throwable[] throwableArray29 = convergenceException28.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException18, localizable20, (java.lang.Object[]) throwableArray29);
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException7, "", (java.lang.Object[]) throwableArray29);
        org.apache.commons.math.exception.util.Localizable localizable32 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException36 = new org.apache.commons.math.exception.OutOfRangeException(localizable32, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 10.0f, (java.lang.Number) (byte) 10);
        org.apache.commons.math.exception.util.Localizable localizable37 = outOfRangeException36.getGeneralPattern();
        java.lang.Object[] objArray44 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException45 = new org.apache.commons.math.ConvergenceException("", objArray44);
        java.lang.Throwable[] throwableArray46 = convergenceException45.getSuppressed();
        java.lang.Class<?> wildcardClass47 = convergenceException45.getClass();
        java.lang.Object[] objArray55 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException56 = new org.apache.commons.math.ConvergenceException("", objArray55);
        java.lang.Throwable[] throwableArray57 = convergenceException56.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable58 = null;
        java.lang.Object[] objArray65 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException66 = new org.apache.commons.math.ConvergenceException("", objArray65);
        java.lang.Throwable[] throwableArray67 = convergenceException66.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException68 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException56, localizable58, (java.lang.Object[]) throwableArray67);
        org.apache.commons.math.ConvergenceException convergenceException69 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException45, "", (java.lang.Object[]) throwableArray67);
        org.apache.commons.math.MathException mathException70 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException31, localizable37, (java.lang.Object[]) throwableArray67);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException74 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable37, (java.lang.Number) 100L, (java.lang.Number) 11013.232874703393d, false);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException76 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable37, (java.lang.Number) 0.02185824040377586d);
        org.apache.commons.math.exception.util.Localizable localizable77 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException81 = new org.apache.commons.math.exception.OutOfRangeException(localizable77, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 10.0f, (java.lang.Number) (byte) 10);
        org.apache.commons.math.exception.util.Localizable localizable82 = outOfRangeException81.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException86 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable82, (java.lang.Number) (short) 100, (java.lang.Number) 11013.232874703393d, false);
        java.lang.Number number87 = numberIsTooSmallException86.getMin();
        java.lang.Object[] objArray88 = numberIsTooSmallException86.getArguments();
        org.apache.commons.math.MathException mathException89 = new org.apache.commons.math.MathException(localizable37, objArray88);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(throwableArray29);
        org.junit.Assert.assertTrue("'" + localizable37 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable37.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertNotNull(throwableArray46);
        org.junit.Assert.assertNotNull(wildcardClass47);
        org.junit.Assert.assertNotNull(objArray55);
        org.junit.Assert.assertNotNull(throwableArray57);
        org.junit.Assert.assertNotNull(objArray65);
        org.junit.Assert.assertNotNull(throwableArray67);
        org.junit.Assert.assertTrue("'" + localizable82 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable82.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + number87 + "' != '" + 11013.232874703393d + "'", number87.equals(11013.232874703393d));
        org.junit.Assert.assertNotNull(objArray88);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(8.03325469850426d, 0.6235868443416331d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 8.033254698504258d + "'", double2 == 8.033254698504258d);
    }

//    @Test
//    public void test091() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test091");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        double double6 = randomDataImpl0.nextCauchy(1.6704649792860586d, 86.78823356954149d);
//        long long9 = randomDataImpl0.nextLong((long) 1, (long) 16);
//        double double11 = randomDataImpl0.nextChiSquare(56.0d);
//        double double14 = randomDataImpl0.nextGaussian(8.928976450870955d, 11013.232874703393d);
//        double double17 = randomDataImpl0.nextBeta(2.468576762660578d, 0.23151936896823624d);
//        try {
//            randomDataImpl0.setSecureAlgorithm("", "a15c80ea61ffc4b3d4");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: a15c80ea61ffc4b3d4");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 9.096208581792759d + "'", double3 == 9.096208581792759d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 19.22286483797367d + "'", double6 == 19.22286483797367d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 16L + "'", long9 == 16L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 60.93447057682309d + "'", double11 == 60.93447057682309d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-18862.005241385606d) + "'", double14 == (-18862.005241385606d));
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.999493781743132d + "'", double17 == 0.999493781743132d);
//    }

//    @Test
//    public void test092() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test092");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        int int6 = randomDataImpl0.nextSecureInt(0, (int) (short) 10);
//        int int9 = randomDataImpl0.nextInt(0, (int) '#');
//        double double12 = randomDataImpl0.nextBeta((double) 97.0f, 1.0E35d);
//        double double15 = randomDataImpl0.nextCauchy(0.615314862365699d, 0.5772156649015329d);
//        double double18 = randomDataImpl0.nextF((double) 32, 1.5707963267948966d);
//        randomDataImpl0.reSeedSecure();
//        try {
//            java.lang.String str21 = randomDataImpl0.nextSecureHexString(0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): length (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 9.052970083109177d + "'", double3 == 9.052970083109177d);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 9 + "'", int6 == 9);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.1595094936071157E-9d + "'", double12 == 1.1595094936071157E-9d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 2.3845263757781776d + "'", double15 == 2.3845263757781776d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 24.028492385837332d + "'", double18 == 24.028492385837332d);
//    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        java.lang.Object[] objArray7 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException("", objArray7);
        java.lang.Throwable[] throwableArray9 = convergenceException8.getSuppressed();
        java.lang.Class<?> wildcardClass10 = convergenceException8.getClass();
        java.lang.Object[] objArray18 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException("", objArray18);
        java.lang.Throwable[] throwableArray20 = convergenceException19.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable21 = null;
        java.lang.Object[] objArray28 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException("", objArray28);
        java.lang.Throwable[] throwableArray30 = convergenceException29.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException19, localizable21, (java.lang.Object[]) throwableArray30);
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException8, "", (java.lang.Object[]) throwableArray30);
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException37 = new org.apache.commons.math.exception.OutOfRangeException(localizable33, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 10.0f, (java.lang.Number) (byte) 10);
        org.apache.commons.math.exception.util.Localizable localizable38 = outOfRangeException37.getGeneralPattern();
        java.lang.Object[] objArray45 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException("", objArray45);
        java.lang.Throwable[] throwableArray47 = convergenceException46.getSuppressed();
        java.lang.Class<?> wildcardClass48 = convergenceException46.getClass();
        java.lang.Object[] objArray56 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException57 = new org.apache.commons.math.ConvergenceException("", objArray56);
        java.lang.Throwable[] throwableArray58 = convergenceException57.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable59 = null;
        java.lang.Object[] objArray66 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException67 = new org.apache.commons.math.ConvergenceException("", objArray66);
        java.lang.Throwable[] throwableArray68 = convergenceException67.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException69 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException57, localizable59, (java.lang.Object[]) throwableArray68);
        org.apache.commons.math.ConvergenceException convergenceException70 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException46, "", (java.lang.Object[]) throwableArray68);
        org.apache.commons.math.MathException mathException71 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException32, localizable38, (java.lang.Object[]) throwableArray68);
        java.lang.Object[] objArray74 = new java.lang.Object[] { 1.0d };
        org.apache.commons.math.ConvergenceException convergenceException75 = new org.apache.commons.math.ConvergenceException("", objArray74);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException76 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, localizable38, objArray74);
        org.apache.commons.math.exception.util.Localizable localizable77 = maxIterationsExceededException76.getGeneralPattern();
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(throwableArray20);
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertNotNull(throwableArray30);
        org.junit.Assert.assertTrue("'" + localizable38 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable38.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray45);
        org.junit.Assert.assertNotNull(throwableArray47);
        org.junit.Assert.assertNotNull(wildcardClass48);
        org.junit.Assert.assertNotNull(objArray56);
        org.junit.Assert.assertNotNull(throwableArray58);
        org.junit.Assert.assertNotNull(objArray66);
        org.junit.Assert.assertNotNull(throwableArray68);
        org.junit.Assert.assertNotNull(objArray74);
        org.junit.Assert.assertTrue("'" + localizable77 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable77.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        int int2 = org.apache.commons.math.util.FastMath.min(16, 18);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
    }

//    @Test
//    public void test095() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test095");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        double double6 = randomDataImpl0.nextCauchy(1.6704649792860586d, 86.78823356954149d);
//        long long9 = randomDataImpl0.nextLong((long) 1, (long) 16);
//        double double11 = randomDataImpl0.nextChiSquare(56.0d);
//        double double14 = randomDataImpl0.nextGaussian(8.928976450870955d, 11013.232874703393d);
//        double double16 = randomDataImpl0.nextExponential(0.37882055894916916d);
//        try {
//            int int19 = randomDataImpl0.nextPascal((int) (short) 0, (double) (short) -1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: -1 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 8.6571049195008d + "'", double3 == 8.6571049195008d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-152.6705595822824d) + "'", double6 == (-152.6705595822824d));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 15L + "'", long9 == 15L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 69.93465054667443d + "'", double11 == 69.93465054667443d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-13562.507456392132d) + "'", double14 == (-13562.507456392132d));
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.42957385241930185d + "'", double16 == 0.42957385241930185d);
//    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(100.03497115658965d, (double) 29, 6.040040854243273d);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        double double1 = org.apache.commons.math.special.Gamma.trigamma((-11.038441819493801d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 679.9065688451432d + "'", double1 == 679.9065688451432d);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) '4');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 52L + "'", long1 == 52L);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        java.lang.Object[] objArray6 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException("", objArray6);
        java.lang.Throwable[] throwableArray8 = convergenceException7.getSuppressed();
        java.lang.Class<?> wildcardClass9 = convergenceException7.getClass();
        java.lang.Object[] objArray17 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException("", objArray17);
        java.lang.Throwable[] throwableArray19 = convergenceException18.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException("", objArray27);
        java.lang.Throwable[] throwableArray29 = convergenceException28.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException18, localizable20, (java.lang.Object[]) throwableArray29);
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException7, "", (java.lang.Object[]) throwableArray29);
        org.apache.commons.math.exception.util.Localizable localizable32 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException36 = new org.apache.commons.math.exception.OutOfRangeException(localizable32, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 10.0f, (java.lang.Number) (byte) 10);
        org.apache.commons.math.exception.util.Localizable localizable37 = outOfRangeException36.getGeneralPattern();
        java.lang.Object[] objArray44 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException45 = new org.apache.commons.math.ConvergenceException("", objArray44);
        java.lang.Throwable[] throwableArray46 = convergenceException45.getSuppressed();
        java.lang.Class<?> wildcardClass47 = convergenceException45.getClass();
        java.lang.Object[] objArray55 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException56 = new org.apache.commons.math.ConvergenceException("", objArray55);
        java.lang.Throwable[] throwableArray57 = convergenceException56.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable58 = null;
        java.lang.Object[] objArray65 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException66 = new org.apache.commons.math.ConvergenceException("", objArray65);
        java.lang.Throwable[] throwableArray67 = convergenceException66.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException68 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException56, localizable58, (java.lang.Object[]) throwableArray67);
        org.apache.commons.math.ConvergenceException convergenceException69 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException45, "", (java.lang.Object[]) throwableArray67);
        org.apache.commons.math.MathException mathException70 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException31, localizable37, (java.lang.Object[]) throwableArray67);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException74 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable37, (java.lang.Number) 100L, (java.lang.Number) 11013.232874703393d, false);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException78 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 56.0d, (java.lang.Number) 0.9171523356672744d, true);
        numberIsTooSmallException74.addSuppressed((java.lang.Throwable) numberIsTooLargeException78);
        java.lang.Number number80 = numberIsTooSmallException74.getArgument();
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(throwableArray29);
        org.junit.Assert.assertTrue("'" + localizable37 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable37.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertNotNull(throwableArray46);
        org.junit.Assert.assertNotNull(wildcardClass47);
        org.junit.Assert.assertNotNull(objArray55);
        org.junit.Assert.assertNotNull(throwableArray57);
        org.junit.Assert.assertNotNull(objArray65);
        org.junit.Assert.assertNotNull(throwableArray67);
        org.junit.Assert.assertTrue("'" + number80 + "' != '" + 100L + "'", number80.equals(100L));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeed((long) (short) 0);
        randomDataImpl1.reSeedSecure();
    }

//    @Test
//    public void test101() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test101");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(100.0d, (double) (byte) 10);
//        double double3 = normalDistributionImpl2.sample();
//        double double4 = normalDistributionImpl2.getMean();
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 104.85690140512888d + "'", double3 == 104.85690140512888d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 100.0d + "'", double4 == 100.0d);
//    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 30L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.0940666686320855d + "'", double1 == 4.0940666686320855d);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(3.2194621878464096d, 0.4452462176212178d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9933642790819155d + "'", double2 == 0.9933642790819155d);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        double double1 = org.apache.commons.math.special.Gamma.logGamma((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 12.801827480081469d + "'", double1 == 12.801827480081469d);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 10.0f, (java.lang.Number) (byte) 10);
        org.apache.commons.math.exception.util.Localizable localizable5 = outOfRangeException4.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) (short) 100, (java.lang.Number) 11013.232874703393d, false);
        java.lang.Number number10 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException13 = new org.apache.commons.math.exception.OutOfRangeException(localizable5, number10, (java.lang.Number) (-0.6687796041949511d), (java.lang.Number) 2.6881171418161356E43d);
        java.lang.Object[] objArray14 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, objArray14);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 10.0f, (java.lang.Number) (byte) 10);
        org.apache.commons.math.exception.util.Localizable localizable5 = outOfRangeException4.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) (short) 100, (java.lang.Number) 11013.232874703393d, false);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException13 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) 8.737800111547191d, (java.lang.Number) 8.737800111547191d, false);
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException18 = new org.apache.commons.math.exception.OutOfRangeException(localizable14, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 10.0f, (java.lang.Number) (byte) 10);
        org.apache.commons.math.exception.util.Localizable localizable19 = outOfRangeException18.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable20 = outOfRangeException18.getGeneralPattern();
        java.lang.Object[] objArray27 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException("", objArray27);
        java.lang.Throwable[] throwableArray29 = convergenceException28.getSuppressed();
        java.lang.Class<?> wildcardClass30 = convergenceException28.getClass();
        org.apache.commons.math.exception.util.Localizable localizable31 = null;
        java.lang.Object[] objArray38 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException("", objArray38);
        org.apache.commons.math.MathException mathException40 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException28, localizable31, objArray38);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException41 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable20, objArray38);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException43 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable5, (java.lang.Number) 7.922060682256977d);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable19.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable20.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(throwableArray29);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertNotNull(objArray38);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((-11.038441819493801d), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-11.0384418194938d) + "'", double2 == (-11.0384418194938d));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.9821806397330133d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.007808630721608704d) + "'", double1 == (-0.007808630721608704d));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable1, (java.lang.Number) 10.0f, (java.lang.Number) 2.718281828459045d, false);
        java.lang.Number number6 = numberIsTooSmallException5.getMin();
        org.apache.commons.math.exception.util.Localizable localizable7 = numberIsTooSmallException5.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException9 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable7, (java.lang.Number) 11.465100751341446d);
        java.lang.Object[] objArray17 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException("", objArray17);
        java.lang.Throwable[] throwableArray19 = convergenceException18.getSuppressed();
        java.lang.Class<?> wildcardClass20 = convergenceException18.getClass();
        java.lang.Object[] objArray28 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException("", objArray28);
        java.lang.Throwable[] throwableArray30 = convergenceException29.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable31 = null;
        java.lang.Object[] objArray38 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException("", objArray38);
        java.lang.Throwable[] throwableArray40 = convergenceException39.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException29, localizable31, (java.lang.Object[]) throwableArray40);
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException18, "", (java.lang.Object[]) throwableArray40);
        org.apache.commons.math.exception.util.Localizable localizable43 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException47 = new org.apache.commons.math.exception.OutOfRangeException(localizable43, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 10.0f, (java.lang.Number) (byte) 10);
        org.apache.commons.math.exception.util.Localizable localizable48 = outOfRangeException47.getGeneralPattern();
        java.lang.Object[] objArray55 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException56 = new org.apache.commons.math.ConvergenceException("", objArray55);
        java.lang.Throwable[] throwableArray57 = convergenceException56.getSuppressed();
        java.lang.Class<?> wildcardClass58 = convergenceException56.getClass();
        java.lang.Object[] objArray66 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException67 = new org.apache.commons.math.ConvergenceException("", objArray66);
        java.lang.Throwable[] throwableArray68 = convergenceException67.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable69 = null;
        java.lang.Object[] objArray76 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException77 = new org.apache.commons.math.ConvergenceException("", objArray76);
        java.lang.Throwable[] throwableArray78 = convergenceException77.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException79 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException67, localizable69, (java.lang.Object[]) throwableArray78);
        org.apache.commons.math.ConvergenceException convergenceException80 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException56, "", (java.lang.Object[]) throwableArray78);
        org.apache.commons.math.MathException mathException81 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException42, localizable48, (java.lang.Object[]) throwableArray78);
        java.lang.Object[] objArray88 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException89 = new org.apache.commons.math.ConvergenceException("", objArray88);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException90 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable48, objArray88);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException91 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, localizable7, objArray88);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 2.718281828459045d + "'", number6.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertNotNull(throwableArray30);
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(throwableArray40);
        org.junit.Assert.assertTrue("'" + localizable48 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable48.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray55);
        org.junit.Assert.assertNotNull(throwableArray57);
        org.junit.Assert.assertNotNull(wildcardClass58);
        org.junit.Assert.assertNotNull(objArray66);
        org.junit.Assert.assertNotNull(throwableArray68);
        org.junit.Assert.assertNotNull(objArray76);
        org.junit.Assert.assertNotNull(throwableArray78);
        org.junit.Assert.assertNotNull(objArray88);
    }

//    @Test
//    public void test110() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test110");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        randomDataImpl0.reSeedSecure((long) '4');
//        double double7 = randomDataImpl0.nextChiSquare((double) 1.0f);
//        randomDataImpl0.reSeed();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl12 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) (short) 1, 3.141592653589793d);
//        double double13 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl12);
//        randomDataImpl0.reSeed();
//        int int17 = randomDataImpl0.nextSecureInt(18, 31);
//        int int20 = randomDataImpl0.nextBinomial((int) '4', (double) 0);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.80624689015837d + "'", double3 == 10.80624689015837d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.3824391781242185d + "'", double7 == 0.3824391781242185d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 28 + "'", int17 == 28);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        int int2 = org.apache.commons.math.util.FastMath.max(31, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31 + "'", int2 == 31);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(1.662417130429843d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1846225673840816d + "'", double1 == 1.1846225673840816d);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        double double1 = org.apache.commons.math.util.FastMath.tanh(10.660747022194085d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999999989004302d + "'", double1 == 0.9999999989004302d);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 10.0f, (java.lang.Number) (byte) 10);
        org.apache.commons.math.exception.util.Localizable localizable5 = outOfRangeException4.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) (short) 100, (java.lang.Number) 11013.232874703393d, false);
        java.lang.Number number10 = numberIsTooSmallException9.getMin();
        java.lang.Object[] objArray11 = numberIsTooSmallException9.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable12 = numberIsTooSmallException9.getGeneralPattern();
        java.lang.Number number13 = numberIsTooSmallException9.getMin();
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 11013.232874703393d + "'", number10.equals(11013.232874703393d));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 11013.232874703393d + "'", number13.equals(11013.232874703393d));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) 345.37940706226686d, (java.lang.Number) 805.8192384809655d, (java.lang.Number) (-11.038441819493801d));
    }

//    @Test
//    public void test116() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test116");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        randomDataImpl0.reSeedSecure((long) '4');
//        double double7 = randomDataImpl0.nextChiSquare((double) 1.0f);
//        randomDataImpl0.reSeed();
//        int int11 = randomDataImpl0.nextBinomial((int) (byte) 0, 0.40702284518531173d);
//        double double14 = randomDataImpl0.nextUniform((double) (short) 1, (double) 4);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl17 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 1L, (double) ' ');
//        double double19 = normalDistributionImpl17.cumulativeProbability(0.7602273367625401d);
//        double double20 = normalDistributionImpl17.sample();
//        double double21 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl17);
//        int int24 = randomDataImpl0.nextZipf(27, 5.331121990781351d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.194441339470178d + "'", double3 == 10.194441339470178d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.6149716547136217d + "'", double7 == 0.6149716547136217d);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 2.046561508608323d + "'", double14 == 2.046561508608323d);
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.4970107950629486d + "'", double19 == 0.4970107950629486d);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 3.325957937361413d + "'", double20 == 3.325957937361413d);
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 35.52033127663033d + "'", double21 == 35.52033127663033d);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//    }

//    @Test
//    public void test117() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test117");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        int int6 = randomDataImpl0.nextSecureInt(0, (int) (short) 10);
//        int int9 = randomDataImpl0.nextInt(0, (int) '#');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl13 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 0, (double) '#', 0.6610060414837631d);
//        double double14 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl13);
//        java.lang.String str16 = randomDataImpl0.nextSecureHexString((int) 'a');
//        long long18 = randomDataImpl0.nextPoisson((double) 34);
//        try {
//            int[] intArray21 = randomDataImpl0.nextPermutation(3, 22);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 22 is larger than the maximum (3): permutation size (22) exceeds permuation domain (3)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.291395449027167d + "'", double3 == 10.291395449027167d);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 42.17668728093799d + "'", double14 == 42.17668728093799d);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "8f32c4224c712f785ee11ff9c076e9704cf79c0b0f79e1a12a22dee1abfd3474dc057a7194a03e2d068fdff7d45a1b8ac" + "'", str16.equals("8f32c4224c712f785ee11ff9c076e9704cf79c0b0f79e1a12a22dee1abfd3474dc057a7194a03e2d068fdff7d45a1b8ac"));
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 47L + "'", long18 == 47L);
//    }

//    @Test
//    public void test118() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test118");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        randomDataImpl0.reSeedSecure((long) '4');
//        double double7 = randomDataImpl0.nextChiSquare((double) 1.0f);
//        double double9 = randomDataImpl0.nextChiSquare(7.659130937910243d);
//        try {
//            double double12 = randomDataImpl0.nextGamma(0.0d, (double) (short) 10);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): alpha");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.248642893051844d + "'", double3 == 10.248642893051844d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.08160786930924731d + "'", double7 == 0.08160786930924731d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 4.877351251318113d + "'", double9 == 4.877351251318113d);
//    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(10.0d, 0.4970107950629486d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.999999999999998d + "'", double2 == 9.999999999999998d);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        double double2 = org.apache.commons.math.util.FastMath.min(1.0E-9d, 3.41643668911758d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E-9d + "'", double2 == 1.0E-9d);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable1, (java.lang.Number) 10.0f, (java.lang.Number) 2.718281828459045d, false);
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException5.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable6, (java.lang.Number) 11176.468962402905d);
        java.lang.Object[] objArray16 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException("", objArray16);
        java.lang.Throwable[] throwableArray18 = convergenceException17.getSuppressed();
        java.lang.Class<?> wildcardClass19 = convergenceException17.getClass();
        java.lang.Object[] objArray27 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException("", objArray27);
        java.lang.Throwable[] throwableArray29 = convergenceException28.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable30 = null;
        java.lang.Object[] objArray37 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException38 = new org.apache.commons.math.ConvergenceException("", objArray37);
        java.lang.Throwable[] throwableArray39 = convergenceException38.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException40 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException28, localizable30, (java.lang.Object[]) throwableArray39);
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException17, "", (java.lang.Object[]) throwableArray39);
        org.apache.commons.math.exception.util.Localizable localizable42 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException46 = new org.apache.commons.math.exception.OutOfRangeException(localizable42, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 10.0f, (java.lang.Number) (byte) 10);
        org.apache.commons.math.exception.util.Localizable localizable47 = outOfRangeException46.getGeneralPattern();
        java.lang.Object[] objArray54 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException55 = new org.apache.commons.math.ConvergenceException("", objArray54);
        java.lang.Throwable[] throwableArray56 = convergenceException55.getSuppressed();
        java.lang.Class<?> wildcardClass57 = convergenceException55.getClass();
        java.lang.Object[] objArray65 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException66 = new org.apache.commons.math.ConvergenceException("", objArray65);
        java.lang.Throwable[] throwableArray67 = convergenceException66.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable68 = null;
        java.lang.Object[] objArray75 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException76 = new org.apache.commons.math.ConvergenceException("", objArray75);
        java.lang.Throwable[] throwableArray77 = convergenceException76.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException78 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException66, localizable68, (java.lang.Object[]) throwableArray77);
        org.apache.commons.math.ConvergenceException convergenceException79 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException55, "", (java.lang.Object[]) throwableArray77);
        org.apache.commons.math.MathException mathException80 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException41, localizable47, (java.lang.Object[]) throwableArray77);
        org.apache.commons.math.ConvergenceException convergenceException81 = new org.apache.commons.math.ConvergenceException("", (java.lang.Object[]) throwableArray77);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException82 = new org.apache.commons.math.MaxIterationsExceededException(24, localizable6, (java.lang.Object[]) throwableArray77);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(throwableArray29);
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertNotNull(throwableArray39);
        org.junit.Assert.assertTrue("'" + localizable47 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable47.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray54);
        org.junit.Assert.assertNotNull(throwableArray56);
        org.junit.Assert.assertNotNull(wildcardClass57);
        org.junit.Assert.assertNotNull(objArray65);
        org.junit.Assert.assertNotNull(throwableArray67);
        org.junit.Assert.assertNotNull(objArray75);
        org.junit.Assert.assertNotNull(throwableArray77);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        double double1 = org.apache.commons.math.util.FastMath.tanh(19.305568189558123d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        float float2 = org.apache.commons.math.util.FastMath.min(4.0f, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(2);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(16784.965439410335d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 129.55680391013948d + "'", double1 == 129.55680391013948d);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        org.apache.commons.math.distribution.IntegerDistribution integerDistribution2 = null;
        try {
            int int3 = randomDataImpl1.nextInversionDeviate(integerDistribution2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        double double1 = org.apache.commons.math.util.FastMath.log1p(10.217527670354155d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.417477525578055d + "'", double1 == 2.417477525578055d);
    }

//    @Test
//    public void test130() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test130");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        java.lang.String str2 = randomDataImpl0.nextHexString(16);
//        java.lang.Class<?> wildcardClass3 = randomDataImpl0.getClass();
//        randomDataImpl0.reSeedSecure();
//        try {
//            int int7 = randomDataImpl0.nextInt(34, (int) (short) 1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 34 is larger than, or equal to, the maximum (1): lower bound (34) must be strictly less than upper bound (1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "077576fce0c0c762" + "'", str2.equals("077576fce0c0c762"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        java.lang.Object[] objArray6 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException("", objArray6);
        java.lang.Throwable[] throwableArray8 = convergenceException7.getSuppressed();
        java.lang.Class<?> wildcardClass9 = convergenceException7.getClass();
        java.lang.Object[] objArray17 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException("", objArray17);
        java.lang.Throwable[] throwableArray19 = convergenceException18.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException("", objArray27);
        java.lang.Throwable[] throwableArray29 = convergenceException28.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException18, localizable20, (java.lang.Object[]) throwableArray29);
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException7, "", (java.lang.Object[]) throwableArray29);
        org.apache.commons.math.exception.util.Localizable localizable32 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException36 = new org.apache.commons.math.exception.OutOfRangeException(localizable32, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 10.0f, (java.lang.Number) (byte) 10);
        org.apache.commons.math.exception.util.Localizable localizable37 = outOfRangeException36.getGeneralPattern();
        java.lang.Object[] objArray44 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException45 = new org.apache.commons.math.ConvergenceException("", objArray44);
        java.lang.Throwable[] throwableArray46 = convergenceException45.getSuppressed();
        java.lang.Class<?> wildcardClass47 = convergenceException45.getClass();
        java.lang.Object[] objArray55 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException56 = new org.apache.commons.math.ConvergenceException("", objArray55);
        java.lang.Throwable[] throwableArray57 = convergenceException56.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable58 = null;
        java.lang.Object[] objArray65 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException66 = new org.apache.commons.math.ConvergenceException("", objArray65);
        java.lang.Throwable[] throwableArray67 = convergenceException66.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException68 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException56, localizable58, (java.lang.Object[]) throwableArray67);
        org.apache.commons.math.ConvergenceException convergenceException69 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException45, "", (java.lang.Object[]) throwableArray67);
        org.apache.commons.math.MathException mathException70 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException31, localizable37, (java.lang.Object[]) throwableArray67);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException74 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable37, (java.lang.Number) 100L, (java.lang.Number) 11013.232874703393d, false);
        boolean boolean75 = numberIsTooSmallException74.getBoundIsAllowed();
        boolean boolean76 = numberIsTooSmallException74.getBoundIsAllowed();
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(throwableArray29);
        org.junit.Assert.assertTrue("'" + localizable37 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable37.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertNotNull(throwableArray46);
        org.junit.Assert.assertNotNull(wildcardClass47);
        org.junit.Assert.assertNotNull(objArray55);
        org.junit.Assert.assertNotNull(throwableArray57);
        org.junit.Assert.assertNotNull(objArray65);
        org.junit.Assert.assertNotNull(throwableArray67);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
    }

//    @Test
//    public void test132() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test132");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 1L, (double) ' ');
//        double double4 = normalDistributionImpl2.cumulativeProbability(0.7602273367625401d);
//        double double5 = normalDistributionImpl2.sample();
//        double double6 = normalDistributionImpl2.sample();
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.4970107950629486d + "'", double4 == 0.4970107950629486d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 14.504326722931726d + "'", double5 == 14.504326722931726d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-15.238437550889657d) + "'", double6 == (-15.238437550889657d));
//    }

//    @Test
//    public void test133() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test133");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextChiSquare(0.398906612308477d);
//        randomDataImpl0.reSeedSecure();
//        try {
//            double double6 = randomDataImpl0.nextUniform(0.23151936896823624d, 7.616456827590592E-5d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 0.232 is larger than, or equal to, the maximum (0): lower bound (0.232) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5454230334579567d + "'", double2 == 0.5454230334579567d);
//    }

//    @Test
//    public void test134() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test134");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        int int6 = randomDataImpl0.nextSecureInt(0, (int) (short) 10);
//        int int9 = randomDataImpl0.nextInt(0, (int) '#');
//        randomDataImpl0.reSeed();
//        try {
//            randomDataImpl0.setSecureAlgorithm("6d5d5b9b4e1779dcc999835b90550a069234d05f2f2ed541a037ccdb7f3b587f59f4ae34e7768b2921b480061eae884ecf02", "baebd7eee");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: baebd7eee");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 14.521003263640868d + "'", double3 == 14.521003263640868d);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 12 + "'", int9 == 12);
//    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        double double1 = org.apache.commons.math.util.FastMath.expm1(6.751143534863933d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 854.0359671242223d + "'", double1 == 854.0359671242223d);
    }

//    @Test
//    public void test136() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test136");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        java.lang.String str2 = randomDataImpl0.nextHexString(16);
//        java.lang.Class<?> wildcardClass3 = randomDataImpl0.getClass();
//        randomDataImpl0.reSeedSecure();
//        long long7 = randomDataImpl0.nextSecureLong(16L, (long) 18);
//        try {
//            double double10 = randomDataImpl0.nextUniform(6.6164926131935715d, 6.4154354279789345d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 6.616 is larger than, or equal to, the maximum (6.415): lower bound (6.616) must be strictly less than upper bound (6.415)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "bf02c64daf3a2a3b" + "'", str2.equals("bf02c64daf3a2a3b"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 16L + "'", long7 == 16L);
//    }

//    @Test
//    public void test137() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test137");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        int int6 = randomDataImpl0.nextSecureInt(0, (int) (short) 10);
//        long long9 = randomDataImpl0.nextSecureLong((long) 0, (long) 'a');
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl10 = new org.apache.commons.math.random.RandomDataImpl();
//        double double13 = randomDataImpl10.nextCauchy((double) (short) 10, 3.141592653589793d);
//        int int16 = randomDataImpl10.nextSecureInt(0, (int) (short) 10);
//        int int19 = randomDataImpl10.nextInt(0, (int) '#');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl23 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 0, (double) '#', 0.6610060414837631d);
//        double double24 = randomDataImpl10.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl23);
//        double double25 = normalDistributionImpl23.getMean();
//        double double28 = normalDistributionImpl23.cumulativeProbability(0.6204290412244261d, (double) (short) 1);
//        double double29 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl23);
//        try {
//            int int32 = randomDataImpl0.nextBinomial(9, 4.605170185988093d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 4.605 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 14.4378763438976d + "'", double3 == 14.4378763438976d);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 9 + "'", int6 == 9);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 27L + "'", long9 == 27L);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 14.435228969356174d + "'", double13 == 14.435228969356174d);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 27 + "'", int19 == 27);
//        org.junit.Assert.assertTrue("'" + double24 + "' != '" + (-53.338993958515154d) + "'", double24 == (-53.338993958515154d));
//        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.004325302709978329d + "'", double28 == 0.004325302709978329d);
//        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 9.0d + "'", double29 == 9.0d);
//    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        double double1 = org.apache.commons.math.util.FastMath.signum((-0.7853981633974483d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        double double1 = org.apache.commons.math.special.Erf.erf(0.5972534764549589d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6016903466682588d + "'", double1 == 0.6016903466682588d);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        double double2 = org.apache.commons.math.util.FastMath.min(0.0d, 3.6637527079352568d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

//    @Test
//    public void test141() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test141");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        java.lang.String str2 = randomDataImpl0.nextHexString(16);
//        double double5 = randomDataImpl0.nextGamma((double) (byte) 100, 1.6823565279386816d);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "cbd91051d6fc0eec" + "'", str2.equals("cbd91051d6fc0eec"));
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 161.42988243025457d + "'", double5 == 161.42988243025457d);
//    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException6 = new org.apache.commons.math.exception.OutOfRangeException(localizable2, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 10.0f, (java.lang.Number) (byte) 10);
        org.apache.commons.math.exception.util.Localizable localizable7 = outOfRangeException6.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException15 = new org.apache.commons.math.exception.OutOfRangeException(localizable11, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 10.0f, (java.lang.Number) (byte) 10);
        org.apache.commons.math.exception.util.Localizable localizable16 = outOfRangeException15.getGeneralPattern();
        java.lang.Object[] objArray23 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException("", objArray23);
        java.lang.Throwable[] throwableArray25 = convergenceException24.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        java.lang.Object[] objArray33 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException34 = new org.apache.commons.math.ConvergenceException("", objArray33);
        java.lang.Throwable[] throwableArray35 = convergenceException34.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException24, localizable26, (java.lang.Object[]) throwableArray35);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException37 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable16, (java.lang.Object[]) throwableArray35);
        java.lang.Object[] objArray38 = maxIterationsExceededException37.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException39 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 100, "", objArray38);
        org.apache.commons.math.MathException mathException40 = new org.apache.commons.math.MathException(localizable7, objArray38);
        java.lang.Number number41 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException42 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable7, number41);
        org.apache.commons.math.exception.util.Localizable localizable43 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException45 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 100.0f);
        org.apache.commons.math.exception.util.Localizable localizable46 = notStrictlyPositiveException45.getSpecificPattern();
        java.lang.Object[] objArray54 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException55 = new org.apache.commons.math.ConvergenceException("", objArray54);
        java.lang.Throwable[] throwableArray56 = convergenceException55.getSuppressed();
        java.lang.Class<?> wildcardClass57 = convergenceException55.getClass();
        java.lang.Object[] objArray65 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException66 = new org.apache.commons.math.ConvergenceException("", objArray65);
        org.apache.commons.math.ConvergenceException convergenceException67 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException55, "", objArray65);
        java.lang.Object[] objArray75 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException76 = new org.apache.commons.math.ConvergenceException("", objArray75);
        java.lang.Throwable[] throwableArray77 = convergenceException76.getSuppressed();
        java.lang.Class<?> wildcardClass78 = convergenceException76.getClass();
        java.lang.Object[] objArray86 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException87 = new org.apache.commons.math.ConvergenceException("", objArray86);
        org.apache.commons.math.ConvergenceException convergenceException88 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException76, "", objArray86);
        org.apache.commons.math.ConvergenceException convergenceException89 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException55, "hi!", objArray86);
        org.apache.commons.math.ConvergenceException convergenceException90 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException45, "", objArray86);
        java.lang.String str91 = convergenceException90.getPattern();
        java.lang.Object[] objArray92 = convergenceException90.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException93 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, localizable43, objArray92);
        org.apache.commons.math.MathException mathException94 = new org.apache.commons.math.MathException(throwable0, "c57e573ea", objArray92);
        java.lang.String str95 = mathException94.toString();
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable16.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNotNull(throwableArray25);
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertNotNull(throwableArray35);
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNull(localizable46);
        org.junit.Assert.assertNotNull(objArray54);
        org.junit.Assert.assertNotNull(throwableArray56);
        org.junit.Assert.assertNotNull(wildcardClass57);
        org.junit.Assert.assertNotNull(objArray65);
        org.junit.Assert.assertNotNull(objArray75);
        org.junit.Assert.assertNotNull(throwableArray77);
        org.junit.Assert.assertNotNull(wildcardClass78);
        org.junit.Assert.assertNotNull(objArray86);
        org.junit.Assert.assertTrue("'" + str91 + "' != '" + "" + "'", str91.equals(""));
        org.junit.Assert.assertNotNull(objArray92);
        org.junit.Assert.assertTrue("'" + str95 + "' != '" + "org.apache.commons.math.MathException: c57e573ea" + "'", str95.equals("org.apache.commons.math.MathException: c57e573ea"));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.5972534764549589d);
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException6 = new org.apache.commons.math.exception.OutOfRangeException(localizable2, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 10.0f, (java.lang.Number) (byte) 10);
        org.apache.commons.math.exception.util.Localizable localizable7 = outOfRangeException6.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException11 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable7, (java.lang.Number) (short) 100, (java.lang.Number) 11013.232874703393d, false);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException15 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable7, (java.lang.Number) 8.737800111547191d, (java.lang.Number) 8.737800111547191d, false);
        java.lang.Object[] objArray16 = null;
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException(localizable7, objArray16);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException21 = new org.apache.commons.math.exception.OutOfRangeException(localizable7, (java.lang.Number) 4.744927971311212E-6d, (java.lang.Number) 22, (java.lang.Number) 0.23180484196660436d);
        java.lang.Object[] objArray22 = null;
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException1, localizable7, objArray22);
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        int int1 = org.apache.commons.math.util.FastMath.round(31.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 31 + "'", int1 == 31);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        double double1 = org.apache.commons.math.util.FastMath.abs(679.9065688451432d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 679.9065688451432d + "'", double1 == 679.9065688451432d);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        double double1 = org.apache.commons.math.util.FastMath.atan(465.3582260850801d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5686474479211192d + "'", double1 == 1.5686474479211192d);
    }

//    @Test
//    public void test147() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test147");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        randomDataImpl0.reSeedSecure((long) '4');
//        double double7 = randomDataImpl0.nextChiSquare((double) 1.0f);
//        double double9 = randomDataImpl0.nextChiSquare(7.659130937910243d);
//        double double12 = randomDataImpl0.nextGaussian(6.028576045602152d, 47.72559009637225d);
//        java.lang.String str14 = randomDataImpl0.nextSecureHexString(6);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 12.226292863546284d + "'", double3 == 12.226292863546284d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.26762847161077635d + "'", double7 == 0.26762847161077635d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 19.993373485786336d + "'", double9 == 19.993373485786336d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-24.46057190575371d) + "'", double12 == (-24.46057190575371d));
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ffd4d8" + "'", str14.equals("ffd4d8"));
//    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ((-0.04229861514908033d), (double) 67L);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 6, (long) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 6L + "'", long2 == 6L);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 97.0f, (java.lang.Number) 62L, (java.lang.Number) 15.0f);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 10.0f, (java.lang.Number) 2.718281828459045d, false);
        java.lang.Number number5 = numberIsTooSmallException4.getMin();
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException4.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable6, (java.lang.Number) 11.465100751341446d);
        java.lang.String str9 = notStrictlyPositiveException8.toString();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 2.718281828459045d + "'", number5.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 11.465 is smaller than, or equal to, the minimum (0): 11.465 is smaller than, or equal to, the minimum (0)" + "'", str9.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 11.465 is smaller than, or equal to, the minimum (0): 11.465 is smaller than, or equal to, the minimum (0)"));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        double double1 = org.apache.commons.math.special.Erf.erf(47.72559009637225d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        double double2 = org.apache.commons.math.util.FastMath.atan2(4.9E-324d, 4.158638853279167d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.999999969540041d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.84147096835031d + "'", double1 == 0.84147096835031d);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 100.0f);
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable3 = notStrictlyPositiveException1.getSpecificPattern();
        boolean boolean4 = notStrictlyPositiveException1.getBoundIsAllowed();
        org.junit.Assert.assertNull(localizable2);
        org.junit.Assert.assertNull(localizable3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        double double1 = org.apache.commons.math.util.FastMath.tanh((-0.1274261656522208d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.12674092487704056d) + "'", double1 == (-0.12674092487704056d));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 26.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7625584504796027d + "'", double1 == 0.7625584504796027d);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) (short) 1, 3.141592653589793d);
        double double4 = normalDistributionImpl3.getStandardDeviation();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

//    @Test
//    public void test160() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test160");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        randomDataImpl0.reSeedSecure((long) '4');
//        double double7 = randomDataImpl0.nextChiSquare((double) 1.0f);
//        randomDataImpl0.reSeed();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl12 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) (short) 1, 3.141592653589793d);
//        double double13 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl12);
//        randomDataImpl0.reSeed();
//        double double17 = randomDataImpl0.nextBeta(0.0140436016105168d, 1.0d);
//        double double20 = randomDataImpl0.nextCauchy(4.605170185988093d, 44.57328158058611d);
//        long long22 = randomDataImpl0.nextPoisson(2.209173234929765d);
//        double double24 = randomDataImpl0.nextT((double) 34L);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 12.707670388921219d + "'", double3 == 12.707670388921219d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.10890990407181832d + "'", double7 == 0.10890990407181832d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.3654737832802758E-9d + "'", double17 == 1.3654737832802758E-9d);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + (-123.82469528104606d) + "'", double20 == (-123.82469528104606d));
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 3L + "'", long22 == 3L);
//        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.14421622641593745d + "'", double24 == 0.14421622641593745d);
//    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 10.0f, (java.lang.Number) 2.718281828459045d, false);
        java.lang.Number number5 = numberIsTooSmallException4.getMin();
        boolean boolean6 = numberIsTooSmallException4.getBoundIsAllowed();
        boolean boolean7 = numberIsTooSmallException4.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 2.718281828459045d + "'", number5.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        java.lang.Object[] objArray6 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException("", objArray6);
        java.lang.Throwable[] throwableArray8 = convergenceException7.getSuppressed();
        java.lang.Class<?> wildcardClass9 = convergenceException7.getClass();
        java.lang.Object[] objArray17 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException("", objArray17);
        java.lang.Throwable[] throwableArray19 = convergenceException18.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException("", objArray27);
        java.lang.Throwable[] throwableArray29 = convergenceException28.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException18, localizable20, (java.lang.Object[]) throwableArray29);
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException7, "", (java.lang.Object[]) throwableArray29);
        org.apache.commons.math.exception.util.Localizable localizable32 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException36 = new org.apache.commons.math.exception.OutOfRangeException(localizable32, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 10.0f, (java.lang.Number) (byte) 10);
        org.apache.commons.math.exception.util.Localizable localizable37 = outOfRangeException36.getGeneralPattern();
        java.lang.Object[] objArray44 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException45 = new org.apache.commons.math.ConvergenceException("", objArray44);
        java.lang.Throwable[] throwableArray46 = convergenceException45.getSuppressed();
        java.lang.Class<?> wildcardClass47 = convergenceException45.getClass();
        java.lang.Object[] objArray55 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException56 = new org.apache.commons.math.ConvergenceException("", objArray55);
        java.lang.Throwable[] throwableArray57 = convergenceException56.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable58 = null;
        java.lang.Object[] objArray65 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException66 = new org.apache.commons.math.ConvergenceException("", objArray65);
        java.lang.Throwable[] throwableArray67 = convergenceException66.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException68 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException56, localizable58, (java.lang.Object[]) throwableArray67);
        org.apache.commons.math.ConvergenceException convergenceException69 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException45, "", (java.lang.Object[]) throwableArray67);
        org.apache.commons.math.MathException mathException70 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException31, localizable37, (java.lang.Object[]) throwableArray67);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException74 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable37, (java.lang.Number) 100L, (java.lang.Number) 11013.232874703393d, false);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException78 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 56.0d, (java.lang.Number) 0.9171523356672744d, true);
        numberIsTooSmallException74.addSuppressed((java.lang.Throwable) numberIsTooLargeException78);
        org.apache.commons.math.exception.util.Localizable localizable80 = numberIsTooSmallException74.getSpecificPattern();
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(throwableArray29);
        org.junit.Assert.assertTrue("'" + localizable37 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable37.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertNotNull(throwableArray46);
        org.junit.Assert.assertNotNull(wildcardClass47);
        org.junit.Assert.assertNotNull(objArray55);
        org.junit.Assert.assertNotNull(throwableArray57);
        org.junit.Assert.assertNotNull(objArray65);
        org.junit.Assert.assertNotNull(throwableArray67);
        org.junit.Assert.assertTrue("'" + localizable80 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable80.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.8119290521338488d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8119290521338488d + "'", double1 == 0.8119290521338488d);
    }

//    @Test
//    public void test164() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test164");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        int int6 = randomDataImpl0.nextSecureInt(0, (int) (short) 10);
//        double double9 = randomDataImpl0.nextUniform(0.9866275920404853d, (double) '#');
//        long long11 = randomDataImpl0.nextPoisson(2.920339088816128d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.10585561610596d + "'", double3 == 10.10585561610596d);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 5.939425567162953d + "'", double9 == 5.939425567162953d);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
//    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        int int2 = org.apache.commons.math.util.FastMath.min(0, 15);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        int int1 = org.apache.commons.math.util.FastMath.abs(35);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 35 + "'", int1 == 35);
    }

//    @Test
//    public void test167() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test167");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        int int6 = randomDataImpl0.nextSecureInt(0, (int) (short) 10);
//        double double9 = randomDataImpl0.nextWeibull(0.5827661623296411d, 1.2917468367601999d);
//        int int12 = randomDataImpl0.nextInt(0, 35);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 9.598816382358734d + "'", double3 == 9.598816382358734d);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 5 + "'", int6 == 5);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 9.058959269382907d + "'", double9 == 9.058959269382907d);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 34 + "'", int12 == 34);
//    }

//    @Test
//    public void test168() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test168");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        randomDataImpl0.reSeedSecure((long) '4');
//        double double7 = randomDataImpl0.nextChiSquare((double) 1.0f);
//        randomDataImpl0.reSeed();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl12 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) (short) 1, 3.141592653589793d);
//        double double13 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl12);
//        java.lang.String str15 = randomDataImpl0.nextSecureHexString(100);
//        double double18 = randomDataImpl0.nextGaussian(345.37940706226686d, 54.85907906241573d);
//        double double21 = randomDataImpl0.nextGaussian(0.0d, 47.72559009637225d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 9.561919785721265d + "'", double3 == 9.561919785721265d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.817935711541585d + "'", double7 == 2.817935711541585d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "19ef123b4779986c5a4778a1347b2f35bfbb000c0ec410cf0938deba512684f68abb8bdb33751baebffa6409835d5811f5c3" + "'", str15.equals("19ef123b4779986c5a4778a1347b2f35bfbb000c0ec410cf0938deba512684f68abb8bdb33751baebffa6409835d5811f5c3"));
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 354.21883610736046d + "'", double18 == 354.21883610736046d);
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + (-37.8541046342316d) + "'", double21 == (-37.8541046342316d));
//    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 10.0f, (java.lang.Number) (byte) 10);
        org.apache.commons.math.exception.util.Localizable localizable5 = outOfRangeException4.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException13 = new org.apache.commons.math.exception.OutOfRangeException(localizable9, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 10.0f, (java.lang.Number) (byte) 10);
        org.apache.commons.math.exception.util.Localizable localizable14 = outOfRangeException13.getGeneralPattern();
        java.lang.Object[] objArray21 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException("", objArray21);
        java.lang.Throwable[] throwableArray23 = convergenceException22.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        java.lang.Object[] objArray31 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException("", objArray31);
        java.lang.Throwable[] throwableArray33 = convergenceException32.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException34 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException22, localizable24, (java.lang.Object[]) throwableArray33);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException35 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable14, (java.lang.Object[]) throwableArray33);
        java.lang.Object[] objArray36 = maxIterationsExceededException35.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException37 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 100, "", objArray36);
        org.apache.commons.math.MathException mathException38 = new org.apache.commons.math.MathException(localizable5, objArray36);
        java.lang.Number number39 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException42 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable5, number39, (java.lang.Number) 8.205002241254977d, false);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable14.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(throwableArray23);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(throwableArray33);
        org.junit.Assert.assertNotNull(objArray36);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 10.0f, (java.lang.Number) 2.718281828459045d, false);
        java.lang.Throwable[] throwableArray5 = numberIsTooSmallException4.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 10.0f, (java.lang.Number) 2.718281828459045d, false);
        java.lang.Number number5 = numberIsTooSmallException4.getMin();
        java.lang.Object[] objArray13 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException("", objArray13);
        java.lang.Throwable[] throwableArray15 = convergenceException14.getSuppressed();
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException4, "hi!", (java.lang.Object[]) throwableArray15);
        java.lang.Number number17 = numberIsTooSmallException4.getMin();
        org.apache.commons.math.exception.util.Localizable localizable18 = numberIsTooSmallException4.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable22 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException26 = new org.apache.commons.math.exception.OutOfRangeException(localizable22, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 10.0f, (java.lang.Number) (byte) 10);
        org.apache.commons.math.exception.util.Localizable localizable27 = outOfRangeException26.getGeneralPattern();
        java.lang.Object[] objArray34 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException("", objArray34);
        java.lang.Throwable[] throwableArray36 = convergenceException35.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable37 = null;
        java.lang.Object[] objArray44 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException45 = new org.apache.commons.math.ConvergenceException("", objArray44);
        java.lang.Throwable[] throwableArray46 = convergenceException45.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException47 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException35, localizable37, (java.lang.Object[]) throwableArray46);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException48 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable27, (java.lang.Object[]) throwableArray46);
        java.lang.Object[] objArray49 = maxIterationsExceededException48.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException50 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 100, "", objArray49);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException51 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable18, objArray49);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 2.718281828459045d + "'", number5.equals(2.718281828459045d));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 2.718281828459045d + "'", number17.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable18.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable27.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(throwableArray36);
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertNotNull(throwableArray46);
        org.junit.Assert.assertNotNull(objArray49);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        double double1 = org.apache.commons.math.util.FastMath.ulp(5.46028307934607d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.881784197001252E-16d + "'", double1 == 8.881784197001252E-16d);
    }

//    @Test
//    public void test173() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test173");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        int int6 = randomDataImpl0.nextSecureInt(0, (int) (short) 10);
//        int int9 = randomDataImpl0.nextInt(0, (int) '#');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl13 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 0, (double) '#', 0.6610060414837631d);
//        double double14 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl13);
//        double[] doubleArray16 = normalDistributionImpl13.sample(36);
//        try {
//            double double18 = normalDistributionImpl13.inverseCumulativeProbability(35.52033127663033d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 35.52 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 9.46958976397623d + "'", double3 == 9.46958976397623d);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 8 + "'", int6 == 8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 7 + "'", int9 == 7);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
//        org.junit.Assert.assertNotNull(doubleArray16);
//    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        int int2 = org.apache.commons.math.util.FastMath.min((int) ' ', 28);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28 + "'", int2 == 28);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 21);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 21L + "'", long1 == 21L);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        double double1 = org.apache.commons.math.util.FastMath.exp(91.07457264406051d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.574245186795206E39d + "'", double1 == 3.574245186795206E39d);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.9036417751182644d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9036417751182644d + "'", double1 == 0.9036417751182644d);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 10.0f, (java.lang.Number) 2.718281828459045d, false);
        java.lang.Number number5 = numberIsTooSmallException4.getMin();
        java.lang.Object[] objArray13 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException("", objArray13);
        java.lang.Throwable[] throwableArray15 = convergenceException14.getSuppressed();
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException4, "hi!", (java.lang.Object[]) throwableArray15);
        java.lang.String str17 = mathException16.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException23 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable19, (java.lang.Number) 10.0f, (java.lang.Number) 2.718281828459045d, false);
        java.lang.Number number24 = numberIsTooSmallException23.getMin();
        java.lang.Object[] objArray32 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException33 = new org.apache.commons.math.ConvergenceException("", objArray32);
        java.lang.Throwable[] throwableArray34 = convergenceException33.getSuppressed();
        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException23, "hi!", (java.lang.Object[]) throwableArray34);
        org.apache.commons.math.MathException mathException36 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException23);
        java.lang.Throwable[] throwableArray37 = numberIsTooSmallException23.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException38 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException16, localizable18, (java.lang.Object[]) throwableArray37);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 2.718281828459045d + "'", number5.equals(2.718281828459045d));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + 2.718281828459045d + "'", number24.equals(2.718281828459045d));
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(throwableArray34);
        org.junit.Assert.assertNotNull(throwableArray37);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10L, (java.lang.Number) (-0.7853981633974483d), true);
        java.lang.Number number4 = numberIsTooLargeException3.getMax();
        boolean boolean5 = numberIsTooLargeException3.getBoundIsAllowed();
        java.lang.Number number6 = numberIsTooLargeException3.getArgument();
        java.lang.Object[] objArray13 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException("", objArray13);
        java.lang.Throwable[] throwableArray15 = convergenceException14.getSuppressed();
        java.lang.Class<?> wildcardClass16 = convergenceException14.getClass();
        java.lang.Object[] objArray24 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException25 = new org.apache.commons.math.ConvergenceException("", objArray24);
        java.lang.Throwable[] throwableArray26 = convergenceException25.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable27 = null;
        java.lang.Object[] objArray34 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException("", objArray34);
        java.lang.Throwable[] throwableArray36 = convergenceException35.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException37 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException25, localizable27, (java.lang.Object[]) throwableArray36);
        org.apache.commons.math.ConvergenceException convergenceException38 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException14, "", (java.lang.Object[]) throwableArray36);
        org.apache.commons.math.exception.util.Localizable localizable39 = convergenceException38.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException41 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable39, (java.lang.Number) 2.718281828459045d);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException45 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10L, (java.lang.Number) (-0.7853981633974483d), true);
        java.lang.Object[] objArray46 = numberIsTooLargeException45.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException47 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable39, objArray46);
        numberIsTooLargeException3.addSuppressed((java.lang.Throwable) mathIllegalArgumentException47);
        java.lang.Object[] objArray55 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException56 = new org.apache.commons.math.ConvergenceException("", objArray55);
        java.lang.Throwable[] throwableArray57 = convergenceException56.getSuppressed();
        java.lang.Class<?> wildcardClass58 = convergenceException56.getClass();
        java.lang.Object[] objArray66 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException67 = new org.apache.commons.math.ConvergenceException("", objArray66);
        org.apache.commons.math.ConvergenceException convergenceException68 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException56, "", objArray66);
        numberIsTooLargeException3.addSuppressed((java.lang.Throwable) convergenceException56);
        boolean boolean70 = numberIsTooLargeException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-0.7853981633974483d) + "'", number4.equals((-0.7853981633974483d)));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 10L + "'", number6.equals(10L));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(throwableArray26);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(throwableArray36);
        org.junit.Assert.assertNotNull(localizable39);
        org.junit.Assert.assertNotNull(objArray46);
        org.junit.Assert.assertNotNull(objArray55);
        org.junit.Assert.assertNotNull(throwableArray57);
        org.junit.Assert.assertNotNull(wildcardClass58);
        org.junit.Assert.assertNotNull(objArray66);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        double double1 = org.apache.commons.math.special.Gamma.trigamma((double) 18);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.05712732579071241d + "'", double1 == 0.05712732579071241d);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 10, (java.lang.Number) 5.109650487152199d, true);
        java.lang.Object[] objArray4 = numberIsTooSmallException3.getArguments();
        org.junit.Assert.assertNotNull(objArray4);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        double double1 = org.apache.commons.math.util.FastMath.ulp(78.0922235533153d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4210854715202004E-14d + "'", double1 == 1.4210854715202004E-14d);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 16);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 16.0d + "'", double1 == 16.0d);
    }

//    @Test
//    public void test184() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test184");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextChiSquare(0.398906612308477d);
//        randomDataImpl0.reSeedSecure();
//        double double5 = randomDataImpl0.nextT((double) 100.0f);
//        int int9 = randomDataImpl0.nextHypergeometric((int) '4', 36, (int) (byte) 1);
//        double double12 = randomDataImpl0.nextWeibull(0.5585053606381855d, 0.6610060414837631d);
//        int int16 = randomDataImpl0.nextHypergeometric(26, (int) (byte) 0, 0);
//        try {
//            int int19 = randomDataImpl0.nextBinomial(4, 8.737800111547191d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 8.738 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.014379662438586302d + "'", double2 == 0.014379662438586302d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-0.01183471871173123d) + "'", double5 == (-0.01183471871173123d));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.6255829017465503d + "'", double12 == 0.6255829017465503d);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(938517.7052992809d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.065510567471183E-6d + "'", double1 == 1.065510567471183E-6d);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) (short) 1, 3.141592653589793d);
        double double5 = normalDistributionImpl3.cumulativeProbability(1.9746370780062322E-24d);
        double double7 = normalDistributionImpl3.density(0.07995708192013753d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.5d + "'", double5 == 0.5d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.3976690705184548d + "'", double7 == 0.3976690705184548d);
    }

//    @Test
//    public void test187() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test187");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        randomDataImpl0.reSeedSecure((long) '4');
//        double double7 = randomDataImpl0.nextChiSquare((double) 1.0f);
//        double double10 = randomDataImpl0.nextF(1.5707963267948966d, (double) 34);
//        double double13 = randomDataImpl0.nextF(2.122688407517981d, (double) 5);
//        try {
//            int int16 = randomDataImpl0.nextSecureInt(1, 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 1 is larger than, or equal to, the maximum (0): lower bound (1) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 12.198570596408718d + "'", double3 == 12.198570596408718d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.6491992522144079d + "'", double7 == 0.6491992522144079d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.1590682634772142d + "'", double10 == 0.1590682634772142d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.5314549786661598d + "'", double13 == 0.5314549786661598d);
//    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        double double1 = org.apache.commons.math.util.FastMath.atan(5.929095625243367d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4037090270353363d + "'", double1 == 1.4037090270353363d);
    }

//    @Test
//    public void test189() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test189");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        int int6 = randomDataImpl0.nextSecureInt(0, (int) (short) 10);
//        try {
//            int int10 = randomDataImpl0.nextHypergeometric(2, 4, 12);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 4 is larger than the maximum (2): number of successes (4) must be less than or equal to population size (2)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 12.151485676359073d + "'", double3 == 12.151485676359073d);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 8 + "'", int6 == 8);
//    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 100.0f);
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getSpecificPattern();
        java.lang.Object[] objArray10 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException("", objArray10);
        java.lang.Throwable[] throwableArray12 = convergenceException11.getSuppressed();
        java.lang.Class<?> wildcardClass13 = convergenceException11.getClass();
        java.lang.Object[] objArray21 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException("", objArray21);
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException11, "", objArray21);
        java.lang.Object[] objArray31 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException("", objArray31);
        java.lang.Throwable[] throwableArray33 = convergenceException32.getSuppressed();
        java.lang.Class<?> wildcardClass34 = convergenceException32.getClass();
        java.lang.Object[] objArray42 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException43 = new org.apache.commons.math.ConvergenceException("", objArray42);
        org.apache.commons.math.ConvergenceException convergenceException44 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException32, "", objArray42);
        org.apache.commons.math.ConvergenceException convergenceException45 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException11, "hi!", objArray42);
        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException1, "", objArray42);
        java.lang.Number number47 = notStrictlyPositiveException1.getMin();
        org.apache.commons.math.exception.util.Localizable localizable48 = notStrictlyPositiveException1.getSpecificPattern();
        org.junit.Assert.assertNull(localizable2);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(throwableArray33);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertTrue("'" + number47 + "' != '" + 0 + "'", number47.equals(0));
        org.junit.Assert.assertNull(localizable48);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.05787828647786176d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.05794304543691382d + "'", double1 == 0.05794304543691382d);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        double double2 = org.apache.commons.math.util.FastMath.min((-0.6624426489214782d), (double) 4L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.6624426489214782d) + "'", double2 == (-0.6624426489214782d));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        double double1 = org.apache.commons.math.util.FastMath.acosh(1.6594480363430075d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0931798983084986d + "'", double1 == 1.0931798983084986d);
    }

//    @Test
//    public void test194() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test194");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        double double6 = randomDataImpl0.nextCauchy(1.6704649792860586d, 86.78823356954149d);
//        long long9 = randomDataImpl0.nextLong((long) 1, (long) 16);
//        double double11 = randomDataImpl0.nextChiSquare(56.0d);
//        double double14 = randomDataImpl0.nextGaussian(8.928976450870955d, 11013.232874703393d);
//        double double16 = randomDataImpl0.nextExponential(269.85625772799693d);
//        double double19 = randomDataImpl0.nextUniform(0.007491108390705375d, 2.468576762660578d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 12.258375325986009d + "'", double3 == 12.258375325986009d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 550.7804072323402d + "'", double6 == 550.7804072323402d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9L + "'", long9 == 9L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 45.90991419246418d + "'", double11 == 45.90991419246418d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 522.7090318562417d + "'", double14 == 522.7090318562417d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 92.56088272128933d + "'", double16 == 92.56088272128933d);
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.4428979418706953d + "'", double19 == 1.4428979418706953d);
//    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10L, (java.lang.Number) (-0.7853981633974483d), true);
        java.lang.Number number4 = numberIsTooLargeException3.getMax();
        boolean boolean5 = numberIsTooLargeException3.getBoundIsAllowed();
        java.lang.Number number6 = numberIsTooLargeException3.getArgument();
        java.lang.Number number7 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-0.7853981633974483d) + "'", number4.equals((-0.7853981633974483d)));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 10L + "'", number6.equals(10L));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (-0.7853981633974483d) + "'", number7.equals((-0.7853981633974483d)));
    }

//    @Test
//    public void test196() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test196");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        randomDataImpl0.reSeedSecure((long) '4');
//        double double7 = randomDataImpl0.nextChiSquare((double) 1.0f);
//        randomDataImpl0.reSeed();
//        int int11 = randomDataImpl0.nextBinomial((int) (byte) 0, 0.40702284518531173d);
//        double double14 = randomDataImpl0.nextUniform((double) (short) 1, (double) 4);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl17 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 1L, (double) ' ');
//        double double19 = normalDistributionImpl17.cumulativeProbability(0.7602273367625401d);
//        double double20 = normalDistributionImpl17.sample();
//        double double21 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl17);
//        double double23 = normalDistributionImpl17.cumulativeProbability((double) 36);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 12.221037307019284d + "'", double3 == 12.221037307019284d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.06246414812714d + "'", double7 == 1.06246414812714d);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 3.092038473707282d + "'", double14 == 3.092038473707282d);
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.4970107950629486d + "'", double19 == 0.4970107950629486d);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 32.775300928005464d + "'", double20 == 32.775300928005464d);
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.2281078460311114d + "'", double21 == 1.2281078460311114d);
//        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.8629676806950886d + "'", double23 == 0.8629676806950886d);
//    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.011396318286638113d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999350626675765d + "'", double1 == 0.9999350626675765d);
    }

//    @Test
//    public void test198() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test198");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        randomDataImpl0.reSeedSecure((long) 'a');
//        int int8 = randomDataImpl0.nextInt(10, 36);
//        double double10 = randomDataImpl0.nextChiSquare(68.0d);
//        try {
//            double double13 = randomDataImpl0.nextGaussian((double) 18L, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): standard deviation (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 12.567555794314249d + "'", double3 == 12.567555794314249d);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 27 + "'", int8 == 27);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 51.57501943607682d + "'", double10 == 51.57501943607682d);
//    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        double double1 = org.apache.commons.math.util.FastMath.sin((-66.94853018111154d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8277492790706d + "'", double1 == 0.8277492790706d);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        double double1 = org.apache.commons.math.special.Gamma.digamma(1.332604751533575E-9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-7.504100519065313E8d) + "'", double1 == (-7.504100519065313E8d));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.0108824780885988d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.010941907637883524d + "'", double1 == 0.010941907637883524d);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        long long1 = org.apache.commons.math.util.FastMath.round(0.0d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) (short) 1, 3.141592653589793d);
        double double4 = normalDistributionImpl3.getMean();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        double double1 = org.apache.commons.math.util.FastMath.sinh(Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1.1531906604012572d, (java.lang.Number) 0.002991729972222412d, true);
    }

//    @Test
//    public void test206() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test206");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        randomDataImpl0.reSeedSecure((long) '4');
//        double double7 = randomDataImpl0.nextChiSquare((double) 1.0f);
//        double double9 = randomDataImpl0.nextT(0.5972534764549589d);
//        double double12 = randomDataImpl0.nextWeibull(7.7352975085310565d, 0.005272776613447272d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 12.46595069109408d + "'", double3 == 12.46595069109408d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.4953366118853225d + "'", double7 == 0.4953366118853225d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 315.87119598841383d + "'", double9 == 315.87119598841383d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.005673036483267484d + "'", double12 == 0.005673036483267484d);
//    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException6 = new org.apache.commons.math.exception.OutOfRangeException(localizable2, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 10.0f, (java.lang.Number) (byte) 10);
        org.apache.commons.math.exception.util.Localizable localizable7 = outOfRangeException6.getGeneralPattern();
        java.lang.Object[] objArray14 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException("", objArray14);
        java.lang.Throwable[] throwableArray16 = convergenceException15.getSuppressed();
        java.lang.Class<?> wildcardClass17 = convergenceException15.getClass();
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        java.lang.Object[] objArray25 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException26 = new org.apache.commons.math.ConvergenceException("", objArray25);
        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException15, localizable18, objArray25);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException28 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable7, objArray25);
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException("", objArray25);
        org.apache.commons.math.exception.util.Localizable localizable30 = convergenceException29.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNull(localizable30);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.0d, (-17.661006041484104d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.2652432325175126d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2683643439509365d + "'", double1 == 0.2683643439509365d);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 32, (java.lang.Number) (short) 10, (java.lang.Number) 0.398906612308477d);
        java.lang.Object[] objArray5 = outOfRangeException4.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException("hi!", objArray5);
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException6);
        org.junit.Assert.assertNotNull(objArray5);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        double double1 = org.apache.commons.math.util.FastMath.log((-0.5772156677920679d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.14421622641593745d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.1437168368187111d + "'", double1 == 0.1437168368187111d);
    }

//    @Test
//    public void test213() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test213");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(3.175169392061453d, 52.780035402544826d, 4.239302734211798d);
//        double double5 = normalDistributionImpl3.density(0.0d);
//        double double6 = normalDistributionImpl3.sample();
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.007544917965956679d + "'", double5 == 0.007544917965956679d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 21.14461583465974d + "'", double6 == 21.14461583465974d);
//    }

//    @Test
//    public void test214() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test214");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        randomDataImpl0.reSeedSecure((long) '#');
//        long long7 = randomDataImpl0.nextPoisson(56.0d);
//        double double9 = randomDataImpl0.nextT(1.6821738184917205d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl12 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 1L, (double) (short) 1);
//        double double15 = normalDistributionImpl12.cumulativeProbability(0.0d, 0.0d);
//        double double16 = normalDistributionImpl12.getMean();
//        double double17 = normalDistributionImpl12.getMean();
//        double double19 = normalDistributionImpl12.cumulativeProbability((-1.5574077246549023d));
//        double double20 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl12);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 12.657283524981636d + "'", double3 == 12.657283524981636d);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 63L + "'", long7 == 63L);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.26503460035014d) + "'", double9 == (-1.26503460035014d));
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.005272776613447272d + "'", double19 == 0.005272776613447272d);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 2.251896810768105d + "'", double20 == 2.251896810768105d);
//    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.03438096319641899d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.4636819605451232d) + "'", double1 == (-1.4636819605451232d));
    }

//    @Test
//    public void test216() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test216");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        int int6 = randomDataImpl0.nextSecureInt(0, (int) (short) 10);
//        double double8 = randomDataImpl0.nextExponential(3.41643668911758d);
//        randomDataImpl0.reSeedSecure();
//        randomDataImpl0.reSeed();
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 11.113843390606775d + "'", double3 == 11.113843390606775d);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 6.000400193474694d + "'", double8 == 6.000400193474694d);
//    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        double double1 = org.apache.commons.math.util.FastMath.cos(9.160919125000353d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9653907539064467d) + "'", double1 == (-0.9653907539064467d));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.8277492790706d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (-1.242450988594219d), (java.lang.Number) 10.22104609692517d, (java.lang.Number) 0.8481594451388405d);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        float float2 = org.apache.commons.math.util.FastMath.max((float) '#', 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeedSecure((long) 12);
    }

//    @Test
//    public void test222() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test222");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        int int6 = randomDataImpl0.nextSecureInt(0, (int) (short) 10);
//        int int9 = randomDataImpl0.nextInt(0, (int) '#');
//        double double12 = randomDataImpl0.nextWeibull((double) 1L, 8.457927173787883d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 11.292290850704005d + "'", double3 == 11.292290850704005d);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 3 + "'", int6 == 3);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 11 + "'", int9 == 11);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 11.41889462522756d + "'", double12 == 11.41889462522756d);
//    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 1L, (double) (short) 1);
        double double5 = normalDistributionImpl2.cumulativeProbability(0.0d, 0.0d);
        double double6 = normalDistributionImpl2.getMean();
        double[] doubleArray8 = normalDistributionImpl2.sample((int) 'a');
        try {
            double double11 = normalDistributionImpl2.cumulativeProbability(6.721731521631732d, 0.4971722435431834d);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(0.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.48459667165920106d, 0.0108824780885988d, 1.0931798983084986d, 3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.12489050054499408d + "'", double4 == 0.12489050054499408d);
    }

//    @Test
//    public void test226() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test226");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        randomDataImpl0.reSeedSecure((long) '4');
//        double double7 = randomDataImpl0.nextChiSquare((double) 1.0f);
//        randomDataImpl0.reSeed();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl12 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) (short) 1, 3.141592653589793d);
//        double double13 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl12);
//        randomDataImpl0.reSeed();
//        int int17 = randomDataImpl0.nextSecureInt(18, 31);
//        double double20 = randomDataImpl0.nextGaussian((-1.5707963267948966d), (double) 36);
//        long long22 = randomDataImpl0.nextPoisson(100.0d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 11.256254980164478d + "'", double3 == 11.256254980164478d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.116299683340745d + "'", double7 == 0.116299683340745d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 29 + "'", int17 == 29);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 71.0282811537272d + "'", double20 == 71.0282811537272d);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 88L + "'", long22 == 88L);
//    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException("f63e9fd5e0", objArray1);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 1L, (double) (short) 1);
        double double5 = normalDistributionImpl2.cumulativeProbability(0.0d, 0.0d);
        double double6 = normalDistributionImpl2.getMean();
        double double7 = normalDistributionImpl2.getMean();
        double double9 = normalDistributionImpl2.cumulativeProbability(0.8623188722876839d);
        double double11 = normalDistributionImpl2.cumulativeProbability(5.644044591410018d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.4452462176212178d + "'", double9 == 0.4452462176212178d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.9999982917311425d + "'", double11 == 0.9999982917311425d);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(1.9746370780062322E-24d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9746370780062326E-24d + "'", double1 == 1.9746370780062326E-24d);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.013571330116420874d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.013570913554083993d + "'", double1 == 0.013570913554083993d);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((-1));
        org.apache.commons.math.exception.util.Localizable localizable2 = maxIterationsExceededException1.getSpecificPattern();
        org.junit.Assert.assertNull(localizable2);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 8);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0794415416798357d + "'", double1 == 2.0794415416798357d);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1.1061068447653153E-45d, (java.lang.Number) (byte) 10, true);
        java.lang.Number number4 = numberIsTooSmallException3.getMin();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (byte) 10 + "'", number4.equals((byte) 10));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        java.lang.Object[] objArray7 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException("", objArray7);
        java.lang.Throwable[] throwableArray9 = convergenceException8.getSuppressed();
        java.lang.Class<?> wildcardClass10 = convergenceException8.getClass();
        java.lang.Object[] objArray18 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException("", objArray18);
        java.lang.Throwable[] throwableArray20 = convergenceException19.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable21 = null;
        java.lang.Object[] objArray28 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException("", objArray28);
        java.lang.Throwable[] throwableArray30 = convergenceException29.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException19, localizable21, (java.lang.Object[]) throwableArray30);
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException8, "", (java.lang.Object[]) throwableArray30);
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException37 = new org.apache.commons.math.exception.OutOfRangeException(localizable33, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 10.0f, (java.lang.Number) (byte) 10);
        org.apache.commons.math.exception.util.Localizable localizable38 = outOfRangeException37.getGeneralPattern();
        java.lang.Object[] objArray45 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException("", objArray45);
        java.lang.Throwable[] throwableArray47 = convergenceException46.getSuppressed();
        java.lang.Class<?> wildcardClass48 = convergenceException46.getClass();
        java.lang.Object[] objArray56 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException57 = new org.apache.commons.math.ConvergenceException("", objArray56);
        java.lang.Throwable[] throwableArray58 = convergenceException57.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable59 = null;
        java.lang.Object[] objArray66 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException67 = new org.apache.commons.math.ConvergenceException("", objArray66);
        java.lang.Throwable[] throwableArray68 = convergenceException67.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException69 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException57, localizable59, (java.lang.Object[]) throwableArray68);
        org.apache.commons.math.ConvergenceException convergenceException70 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException46, "", (java.lang.Object[]) throwableArray68);
        org.apache.commons.math.MathException mathException71 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException32, localizable38, (java.lang.Object[]) throwableArray68);
        java.lang.Object[] objArray78 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException79 = new org.apache.commons.math.ConvergenceException("", objArray78);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException80 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable38, objArray78);
        org.apache.commons.math.exception.util.Localizable localizable81 = maxIterationsExceededException80.getGeneralPattern();
        java.lang.Object[] objArray83 = null;
        org.apache.commons.math.ConvergenceException convergenceException84 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException80, "75c35ae8ddd3bd53", objArray83);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(throwableArray20);
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertNotNull(throwableArray30);
        org.junit.Assert.assertTrue("'" + localizable38 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable38.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray45);
        org.junit.Assert.assertNotNull(throwableArray47);
        org.junit.Assert.assertNotNull(wildcardClass48);
        org.junit.Assert.assertNotNull(objArray56);
        org.junit.Assert.assertNotNull(throwableArray58);
        org.junit.Assert.assertNotNull(objArray66);
        org.junit.Assert.assertNotNull(throwableArray68);
        org.junit.Assert.assertNotNull(objArray78);
        org.junit.Assert.assertTrue("'" + localizable81 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable81.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 10.0f, (java.lang.Number) 2.718281828459045d, false);
        java.lang.Number number5 = numberIsTooSmallException4.getMin();
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException4.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable7 = numberIsTooSmallException4.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 2.718281828459045d + "'", number5.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        double double1 = org.apache.commons.math.util.FastMath.atanh((-1.5574077246549023d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test238() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test238");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        java.lang.String str2 = randomDataImpl0.nextHexString(16);
//        java.lang.Class<?> wildcardClass3 = randomDataImpl0.getClass();
//        randomDataImpl0.reSeedSecure();
//        long long7 = randomDataImpl0.nextSecureLong(16L, (long) 18);
//        double double10 = randomDataImpl0.nextGaussian(11.85293232633846d, 9.11330113809026d);
//        try {
//            java.lang.String str12 = randomDataImpl0.nextSecureHexString((int) (byte) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): length (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "793f1a16682381d0" + "'", str2.equals("793f1a16682381d0"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 17L + "'", long7 == 17L);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 34.73820353677793d + "'", double10 == 34.73820353677793d);
//    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        double double1 = org.apache.commons.math.special.Erf.erf(5.46028307934607d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999999999999886d + "'", double1 == 0.9999999999999886d);
    }

//    @Test
//    public void test240() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test240");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        int int6 = randomDataImpl0.nextSecureInt(0, (int) (short) 10);
//        long long9 = randomDataImpl0.nextSecureLong((long) 0, (long) 'a');
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl10 = new org.apache.commons.math.random.RandomDataImpl();
//        double double13 = randomDataImpl10.nextCauchy((double) (short) 10, 3.141592653589793d);
//        int int16 = randomDataImpl10.nextSecureInt(0, (int) (short) 10);
//        int int19 = randomDataImpl10.nextInt(0, (int) '#');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl23 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 0, (double) '#', 0.6610060414837631d);
//        double double24 = randomDataImpl10.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl23);
//        double double25 = normalDistributionImpl23.getMean();
//        double double28 = normalDistributionImpl23.cumulativeProbability(0.6204290412244261d, (double) (short) 1);
//        double double29 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl23);
//        double double31 = randomDataImpl0.nextChiSquare(11013.232874703393d);
//        double double34 = randomDataImpl0.nextGaussian(3.141592653589793d, 343.9572681668244d);
//        randomDataImpl0.reSeed();
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.873546460461817d + "'", double3 == 10.873546460461817d);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 5 + "'", int6 == 5);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 54L + "'", long9 == 54L);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 10.867834325268122d + "'", double13 == 10.867834325268122d);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 8 + "'", int16 == 8);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2 + "'", int19 == 2);
//        org.junit.Assert.assertTrue("'" + double24 + "' != '" + (-9.0d) + "'", double24 == (-9.0d));
//        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.004325302709978329d + "'", double28 == 0.004325302709978329d);
//        org.junit.Assert.assertTrue("'" + double29 + "' != '" + (-57.338993958515076d) + "'", double29 == (-57.338993958515076d));
//        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 11310.231150110518d + "'", double31 == 11310.231150110518d);
//        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 344.51150907219534d + "'", double34 == 344.51150907219534d);
//    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        java.lang.Object[] objArray6 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException("", objArray6);
        java.lang.Throwable[] throwableArray8 = convergenceException7.getSuppressed();
        java.lang.Class<?> wildcardClass9 = convergenceException7.getClass();
        java.lang.Object[] objArray17 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException("", objArray17);
        java.lang.Throwable[] throwableArray19 = convergenceException18.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException("", objArray27);
        java.lang.Throwable[] throwableArray29 = convergenceException28.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException18, localizable20, (java.lang.Object[]) throwableArray29);
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException7, "", (java.lang.Object[]) throwableArray29);
        org.apache.commons.math.exception.util.Localizable localizable32 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException36 = new org.apache.commons.math.exception.OutOfRangeException(localizable32, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 10.0f, (java.lang.Number) (byte) 10);
        org.apache.commons.math.exception.util.Localizable localizable37 = outOfRangeException36.getGeneralPattern();
        java.lang.Object[] objArray44 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException45 = new org.apache.commons.math.ConvergenceException("", objArray44);
        java.lang.Throwable[] throwableArray46 = convergenceException45.getSuppressed();
        java.lang.Class<?> wildcardClass47 = convergenceException45.getClass();
        java.lang.Object[] objArray55 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException56 = new org.apache.commons.math.ConvergenceException("", objArray55);
        java.lang.Throwable[] throwableArray57 = convergenceException56.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable58 = null;
        java.lang.Object[] objArray65 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException66 = new org.apache.commons.math.ConvergenceException("", objArray65);
        java.lang.Throwable[] throwableArray67 = convergenceException66.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException68 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException56, localizable58, (java.lang.Object[]) throwableArray67);
        org.apache.commons.math.ConvergenceException convergenceException69 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException45, "", (java.lang.Object[]) throwableArray67);
        org.apache.commons.math.MathException mathException70 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException31, localizable37, (java.lang.Object[]) throwableArray67);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException74 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable37, (java.lang.Number) 100L, (java.lang.Number) 11013.232874703393d, false);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException76 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable37, (java.lang.Number) 0.02185824040377586d);
        org.apache.commons.math.exception.util.Localizable localizable77 = notStrictlyPositiveException76.getSpecificPattern();
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(throwableArray29);
        org.junit.Assert.assertTrue("'" + localizable37 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable37.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertNotNull(throwableArray46);
        org.junit.Assert.assertNotNull(wildcardClass47);
        org.junit.Assert.assertNotNull(objArray55);
        org.junit.Assert.assertNotNull(throwableArray57);
        org.junit.Assert.assertNotNull(objArray65);
        org.junit.Assert.assertNotNull(throwableArray67);
        org.junit.Assert.assertTrue("'" + localizable77 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable77.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 1L, (double) (short) 1);
        double double5 = normalDistributionImpl2.cumulativeProbability(0.0d, 0.0d);
        double double6 = normalDistributionImpl2.getMean();
        double double7 = normalDistributionImpl2.getMean();
        double double9 = normalDistributionImpl2.cumulativeProbability((-1.5574077246549023d));
        try {
            double double11 = normalDistributionImpl2.inverseCumulativeProbability((double) 17L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 17 out of [0, 1] range");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.005272776613447272d + "'", double9 == 0.005272776613447272d);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        double double1 = org.apache.commons.math.util.FastMath.ceil(59.55000679005425d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 60.0d + "'", double1 == 60.0d);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(11.256254980164478d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 644.9359034865387d + "'", double1 == 644.9359034865387d);
    }

//    @Test
//    public void test245() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test245");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        randomDataImpl0.reSeedSecure((long) '4');
//        double double7 = randomDataImpl0.nextChiSquare((double) 1.0f);
//        randomDataImpl0.reSeed();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl12 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) (short) 1, 3.141592653589793d);
//        double double13 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl12);
//        randomDataImpl0.reSeed();
//        double double17 = randomDataImpl0.nextBeta(0.0140436016105168d, 1.0d);
//        double double20 = randomDataImpl0.nextBeta(7.7352975085310565d, 0.5276511697442289d);
//        try {
//            long long23 = randomDataImpl0.nextLong((long) 33, (long) (byte) 1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 33 is larger than, or equal to, the maximum (1): lower bound (33) must be strictly less than upper bound (1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 15.247492477654692d + "'", double3 == 15.247492477654692d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.019383888903598278d + "'", double7 == 0.019383888903598278d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.5156500618785283E-6d + "'", double17 == 1.5156500618785283E-6d);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.9933374605263411d + "'", double20 == 0.9933374605263411d);
//    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(9.334863143861648d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.1055682266654805d + "'", double1 == 2.1055682266654805d);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(100.0d, (double) (byte) 10);
        double double3 = normalDistributionImpl2.getStandardDeviation();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
    }

//    @Test
//    public void test248() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test248");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        int int6 = randomDataImpl0.nextSecureInt(0, (int) (short) 10);
//        int int9 = randomDataImpl0.nextInt(0, (int) '#');
//        double double12 = randomDataImpl0.nextBeta(0.05787828647786176d, 62.338993958514976d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 16.96398675077917d + "'", double3 == 16.96398675077917d);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.7594143422545917E-9d + "'", double12 == 1.7594143422545917E-9d);
//    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        double double2 = org.apache.commons.math.util.FastMath.min(0.1774732597393479d, 2.302585092994046d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.1774732597393479d + "'", double2 == 0.1774732597393479d);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 32, (java.lang.Number) (short) 10, (java.lang.Number) 0.398906612308477d);
        java.lang.Number number4 = outOfRangeException3.getLo();
        java.lang.Number number5 = outOfRangeException3.getLo();
        java.lang.Number number6 = outOfRangeException3.getLo();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (short) 10 + "'", number4.equals((short) 10));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (short) 10 + "'", number5.equals((short) 10));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (short) 10 + "'", number6.equals((short) 10));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        double double1 = org.apache.commons.math.util.FastMath.cos(10.000000000000002d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8390715290764514d) + "'", double1 == (-0.8390715290764514d));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 0, (double) '#', 0.6610060414837631d);
        normalDistributionImpl3.reseedRandomGenerator((long) (short) 10);
        double double7 = normalDistributionImpl3.density(0.6610060414837631d);
        double double9 = normalDistributionImpl3.cumulativeProbability(0.0d);
        double double11 = normalDistributionImpl3.density((double) 10L);
        double double14 = normalDistributionImpl3.cumulativeProbability(0.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.011396318286638113d + "'", double7 == 0.011396318286638113d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.5d + "'", double9 == 0.5d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.01094247885554892d + "'", double11 == 0.01094247885554892d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 1L, (double) (short) 1);
        double double5 = normalDistributionImpl2.cumulativeProbability(0.0d, 0.0d);
        double double7 = normalDistributionImpl2.cumulativeProbability(10.000000000000002d);
        normalDistributionImpl2.reseedRandomGenerator(29L);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
    }

//    @Test
//    public void test254() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test254");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        randomDataImpl0.reSeedSecure((long) '4');
//        double double7 = randomDataImpl0.nextChiSquare((double) 1.0f);
//        randomDataImpl0.reSeed();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl12 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) (short) 1, 3.141592653589793d);
//        double double13 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl12);
//        randomDataImpl0.reSeed();
//        double double17 = randomDataImpl0.nextBeta(0.0140436016105168d, 1.0d);
//        double double20 = randomDataImpl0.nextCauchy(4.605170185988093d, 44.57328158058611d);
//        try {
//            double double23 = randomDataImpl0.nextF(522.7090318562417d, (-0.5772156677920679d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.577 is smaller than, or equal to, the minimum (0): degrees of freedom (-0.577)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 16.61806321057491d + "'", double3 == 16.61806321057491d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.025367371714649433d + "'", double7 == 0.025367371714649433d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 2.4036551141725335E-5d + "'", double17 == 2.4036551141725335E-5d);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 41.10137723137618d + "'", double20 == 41.10137723137618d);
//    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(2.468576762660578d, 0.6235200651203063d, 2.1906636469536225d);
        double double5 = normalDistributionImpl3.inverseCumulativeProbability(0.8959784153937458d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 3.280336795220731d + "'", double5 == 3.280336795220731d);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        double double1 = org.apache.commons.math.util.FastMath.cos(13.754204050669212d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3736703688972512d + "'", double1 == 0.3736703688972512d);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        double double1 = org.apache.commons.math.util.FastMath.cosh((-9.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4051.542025492594d + "'", double1 == 4051.542025492594d);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.6610060414837631d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7221586788190554d + "'", double1 == 0.7221586788190554d);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        int int2 = org.apache.commons.math.util.FastMath.min(26, 16);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
    }

//    @Test
//    public void test260() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test260");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        randomDataImpl0.reSeedSecure((long) '4');
//        double double7 = randomDataImpl0.nextChiSquare((double) 1.0f);
//        randomDataImpl0.reSeed();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl12 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) (short) 1, 3.141592653589793d);
//        double double13 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl12);
//        randomDataImpl0.reSeed();
//        int int17 = randomDataImpl0.nextSecureInt(18, 31);
//        double double19 = randomDataImpl0.nextExponential(91.07457264406051d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 13.82821341364453d + "'", double3 == 13.82821341364453d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.023383695466532326d + "'", double7 == 0.023383695466532326d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 30 + "'", int17 == 30);
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 22.54454093470796d + "'", double19 == 22.54454093470796d);
//    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 100.0f);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 100L + "'", long1 == 100L);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 100L, (java.lang.Number) 10.000000000000002d, false);
        java.lang.Object[] objArray4 = numberIsTooSmallException3.getArguments();
        java.lang.Number number5 = numberIsTooSmallException3.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException3.getGeneralPattern();
        java.lang.Number number7 = numberIsTooSmallException3.getMin();
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Object[] objArray16 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException("", objArray16);
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException("acf57acb556e189f", objArray16);
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException3, localizable8, objArray16);
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 100L + "'", number5.equals(100L));
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 10.000000000000002d + "'", number7.equals(10.000000000000002d));
        org.junit.Assert.assertNotNull(objArray16);
    }

//    @Test
//    public void test263() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test263");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        randomDataImpl0.reSeedSecure((long) '#');
//        long long7 = randomDataImpl0.nextPoisson(56.0d);
//        double double9 = randomDataImpl0.nextT(1.6821738184917205d);
//        double double12 = randomDataImpl0.nextCauchy(3.058987236879791d, (double) 17.0f);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 14.156335560032263d + "'", double3 == 14.156335560032263d);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 51L + "'", long7 == 51L);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-3.7805173426687215d) + "'", double9 == (-3.7805173426687215d));
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-0.5470467700833206d) + "'", double12 == (-0.5470467700833206d));
//    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        java.lang.Object[] objArray6 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException("", objArray6);
        java.lang.Throwable[] throwableArray8 = convergenceException7.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        java.lang.Object[] objArray16 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException("", objArray16);
        java.lang.Throwable[] throwableArray18 = convergenceException17.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException7, localizable9, (java.lang.Object[]) throwableArray18);
        org.apache.commons.math.exception.util.Localizable localizable20 = convergenceException19.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable21 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException25 = new org.apache.commons.math.exception.OutOfRangeException(localizable21, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 10.0f, (java.lang.Number) (byte) 10);
        org.apache.commons.math.exception.util.Localizable localizable26 = outOfRangeException25.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable30 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException34 = new org.apache.commons.math.exception.OutOfRangeException(localizable30, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 10.0f, (java.lang.Number) (byte) 10);
        org.apache.commons.math.exception.util.Localizable localizable35 = outOfRangeException34.getGeneralPattern();
        java.lang.Object[] objArray42 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException43 = new org.apache.commons.math.ConvergenceException("", objArray42);
        java.lang.Throwable[] throwableArray44 = convergenceException43.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable45 = null;
        java.lang.Object[] objArray52 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException53 = new org.apache.commons.math.ConvergenceException("", objArray52);
        java.lang.Throwable[] throwableArray54 = convergenceException53.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException55 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException43, localizable45, (java.lang.Object[]) throwableArray54);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException56 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable35, (java.lang.Object[]) throwableArray54);
        java.lang.Object[] objArray57 = maxIterationsExceededException56.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException58 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 100, "", objArray57);
        org.apache.commons.math.MathException mathException59 = new org.apache.commons.math.MathException(localizable26, objArray57);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException63 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable26, (java.lang.Number) (-0.9999999999999999d), (java.lang.Number) 2.209173234929765d, false);
        java.lang.Object[] objArray64 = null;
        org.apache.commons.math.ConvergenceException convergenceException65 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException19, localizable26, objArray64);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertNull(localizable20);
        org.junit.Assert.assertTrue("'" + localizable26 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable26.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable35 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable35.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertNotNull(throwableArray44);
        org.junit.Assert.assertNotNull(objArray52);
        org.junit.Assert.assertNotNull(throwableArray54);
        org.junit.Assert.assertNotNull(objArray57);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        java.lang.Number number0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException(number0, number1, true);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 0, (double) '#', 0.6610060414837631d);
        double double5 = normalDistributionImpl3.cumulativeProbability((double) 36);
        java.lang.Class<?> wildcardClass6 = normalDistributionImpl3.getClass();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.8481594451388405d + "'", double5 == 0.8481594451388405d);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException5 = new org.apache.commons.math.exception.OutOfRangeException(localizable1, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 10.0f, (java.lang.Number) (byte) 10);
        org.apache.commons.math.exception.util.Localizable localizable6 = outOfRangeException5.getGeneralPattern();
        java.lang.Object[] objArray13 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException("", objArray13);
        java.lang.Throwable[] throwableArray15 = convergenceException14.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        java.lang.Object[] objArray23 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException("", objArray23);
        java.lang.Throwable[] throwableArray25 = convergenceException24.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException26 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException14, localizable16, (java.lang.Object[]) throwableArray25);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException27 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable6, (java.lang.Object[]) throwableArray25);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException31 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) 1.136390668384291d, (java.lang.Number) (-6.435110937730336d), false);
        java.lang.Number number32 = numberIsTooLargeException31.getMax();
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNotNull(throwableArray25);
        org.junit.Assert.assertTrue("'" + number32 + "' != '" + (-6.435110937730336d) + "'", number32.equals((-6.435110937730336d)));
    }

//    @Test
//    public void test268() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test268");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        double double6 = randomDataImpl0.nextCauchy(1.6704649792860586d, 86.78823356954149d);
//        long long9 = randomDataImpl0.nextLong((long) 1, (long) 16);
//        int int12 = randomDataImpl0.nextInt(0, (int) (byte) 100);
//        int int15 = randomDataImpl0.nextSecureInt((int) (short) 10, 34);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 13.144994770684171d + "'", double3 == 13.144994770684171d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 590.7909222259701d + "'", double6 == 590.7909222259701d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 15L + "'", long9 == 15L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 33 + "'", int15 == 33);
//    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 1L, (double) (short) 1);
        double double5 = normalDistributionImpl2.cumulativeProbability(0.0d, 0.0d);
        double double7 = normalDistributionImpl2.cumulativeProbability(10.000000000000002d);
        double double9 = normalDistributionImpl2.cumulativeProbability(2.302585092994046d);
        double double10 = normalDistributionImpl2.getMean();
        double double11 = normalDistributionImpl2.getStandardDeviation();
        normalDistributionImpl2.reseedRandomGenerator((long) 2147483647);
        double double15 = normalDistributionImpl2.density(0.14421622641593745d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.9036417751182644d + "'", double9 == 0.9036417751182644d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.2766169818200754d + "'", double15 == 0.2766169818200754d);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 0.0d, 0.1278571594051268d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): standard deviation (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        double double1 = org.apache.commons.math.util.FastMath.abs(7.659130937910243d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.659130937910243d + "'", double1 == 7.659130937910243d);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 5, (java.lang.Number) 2.7383311244009776d, false);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(4.525122772071478d, (double) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): standard deviation (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(54.85907906241573d, 11.711522549255331d, 0.012080516344795228d, 4);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 6.023688612611268E-20d + "'", double4 == 6.023688612611268E-20d);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(0);
        java.lang.Throwable[] throwableArray2 = maxIterationsExceededException1.getSuppressed();
        java.lang.Class<?> wildcardClass3 = maxIterationsExceededException1.getClass();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException6 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 100L, (java.lang.Number) 10.000000000000002d, false);
        java.lang.Object[] objArray7 = numberIsTooSmallException6.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException8 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "", objArray7);
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException("", objArray7);
        org.junit.Assert.assertNotNull(objArray7);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException3 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 100.0f);
        org.apache.commons.math.exception.util.Localizable localizable4 = notStrictlyPositiveException3.getSpecificPattern();
        java.lang.Object[] objArray12 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException("", objArray12);
        java.lang.Throwable[] throwableArray14 = convergenceException13.getSuppressed();
        java.lang.Class<?> wildcardClass15 = convergenceException13.getClass();
        java.lang.Object[] objArray23 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException("", objArray23);
        org.apache.commons.math.ConvergenceException convergenceException25 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException13, "", objArray23);
        java.lang.Object[] objArray33 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException34 = new org.apache.commons.math.ConvergenceException("", objArray33);
        java.lang.Throwable[] throwableArray35 = convergenceException34.getSuppressed();
        java.lang.Class<?> wildcardClass36 = convergenceException34.getClass();
        java.lang.Object[] objArray44 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException45 = new org.apache.commons.math.ConvergenceException("", objArray44);
        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException34, "", objArray44);
        org.apache.commons.math.ConvergenceException convergenceException47 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException13, "hi!", objArray44);
        org.apache.commons.math.ConvergenceException convergenceException48 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException3, "", objArray44);
        java.lang.String str49 = convergenceException48.getPattern();
        java.lang.Throwable[] throwableArray50 = convergenceException48.getSuppressed();
        org.apache.commons.math.MathException mathException51 = new org.apache.commons.math.MathException(throwable0, "a6a8f52cba4d7302", (java.lang.Object[]) throwableArray50);
        java.lang.String str52 = mathException51.toString();
        java.lang.Object[] objArray53 = mathException51.getArguments();
        java.lang.Class<?> wildcardClass54 = mathException51.getClass();
        org.junit.Assert.assertNull(localizable4);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertNotNull(throwableArray35);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "" + "'", str49.equals(""));
        org.junit.Assert.assertNotNull(throwableArray50);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "org.apache.commons.math.MathException: a6a8f52cba4d7302" + "'", str52.equals("org.apache.commons.math.MathException: a6a8f52cba4d7302"));
        org.junit.Assert.assertNotNull(objArray53);
        org.junit.Assert.assertNotNull(wildcardClass54);
    }

//    @Test
//    public void test278() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test278");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        randomDataImpl0.reSeedSecure((long) '4');
//        double double7 = randomDataImpl0.nextChiSquare((double) 1.0f);
//        randomDataImpl0.reSeed();
//        int int11 = randomDataImpl0.nextBinomial((int) (byte) 0, 0.40702284518531173d);
//        long long14 = randomDataImpl0.nextLong((long) 29, (long) 33);
//        int int17 = randomDataImpl0.nextZipf(4, 13.144994770684171d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-3.573855070468783d) + "'", double3 == (-3.573855070468783d));
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.016512866880788114d + "'", double7 == 0.016512866880788114d);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 30L + "'", long14 == 30L);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//    }

//    @Test
//    public void test279() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test279");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        double double6 = randomDataImpl0.nextCauchy(1.6704649792860586d, 86.78823356954149d);
//        long long9 = randomDataImpl0.nextLong((long) 1, (long) 16);
//        double double11 = randomDataImpl0.nextChiSquare(56.0d);
//        double double14 = randomDataImpl0.nextGaussian(8.928976450870955d, 11013.232874703393d);
//        double double16 = randomDataImpl0.nextExponential(269.85625772799693d);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution17 = null;
//        try {
//            int int18 = randomDataImpl0.nextInversionDeviate(integerDistribution17);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-4.382286199441069d) + "'", double3 == (-4.382286199441069d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 18.849281574152258d + "'", double6 == 18.849281574152258d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 11L + "'", long9 == 11L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 57.24527447078569d + "'", double11 == 57.24527447078569d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-9925.176568176777d) + "'", double14 == (-9925.176568176777d));
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 40.20109143640813d + "'", double16 == 40.20109143640813d);
//    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        java.lang.Object[] objArray6 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException("", objArray6);
        java.lang.Throwable[] throwableArray8 = convergenceException7.getSuppressed();
        java.lang.Class<?> wildcardClass9 = convergenceException7.getClass();
        java.lang.Object[] objArray17 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException("", objArray17);
        java.lang.Throwable[] throwableArray19 = convergenceException18.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException("", objArray27);
        java.lang.Throwable[] throwableArray29 = convergenceException28.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException18, localizable20, (java.lang.Object[]) throwableArray29);
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException7, "", (java.lang.Object[]) throwableArray29);
        org.apache.commons.math.exception.util.Localizable localizable32 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException36 = new org.apache.commons.math.exception.OutOfRangeException(localizable32, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 10.0f, (java.lang.Number) (byte) 10);
        org.apache.commons.math.exception.util.Localizable localizable37 = outOfRangeException36.getGeneralPattern();
        java.lang.Object[] objArray44 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException45 = new org.apache.commons.math.ConvergenceException("", objArray44);
        java.lang.Throwable[] throwableArray46 = convergenceException45.getSuppressed();
        java.lang.Class<?> wildcardClass47 = convergenceException45.getClass();
        java.lang.Object[] objArray55 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException56 = new org.apache.commons.math.ConvergenceException("", objArray55);
        java.lang.Throwable[] throwableArray57 = convergenceException56.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable58 = null;
        java.lang.Object[] objArray65 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException66 = new org.apache.commons.math.ConvergenceException("", objArray65);
        java.lang.Throwable[] throwableArray67 = convergenceException66.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException68 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException56, localizable58, (java.lang.Object[]) throwableArray67);
        org.apache.commons.math.ConvergenceException convergenceException69 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException45, "", (java.lang.Object[]) throwableArray67);
        org.apache.commons.math.MathException mathException70 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException31, localizable37, (java.lang.Object[]) throwableArray67);
        java.lang.Object[] objArray77 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException78 = new org.apache.commons.math.ConvergenceException("", objArray77);
        java.lang.Throwable[] throwableArray79 = convergenceException78.getSuppressed();
        java.lang.Class<?> wildcardClass80 = convergenceException78.getClass();
        org.apache.commons.math.exception.util.Localizable localizable81 = null;
        java.lang.Object[] objArray88 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException89 = new org.apache.commons.math.ConvergenceException("", objArray88);
        org.apache.commons.math.MathException mathException90 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException78, localizable81, objArray88);
        org.apache.commons.math.ConvergenceException convergenceException91 = new org.apache.commons.math.ConvergenceException(localizable37, objArray88);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException93 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable37, (java.lang.Number) 4.0f);
        java.lang.Object[] objArray94 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException95 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable37, objArray94);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(throwableArray29);
        org.junit.Assert.assertTrue("'" + localizable37 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable37.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertNotNull(throwableArray46);
        org.junit.Assert.assertNotNull(wildcardClass47);
        org.junit.Assert.assertNotNull(objArray55);
        org.junit.Assert.assertNotNull(throwableArray57);
        org.junit.Assert.assertNotNull(objArray65);
        org.junit.Assert.assertNotNull(throwableArray67);
        org.junit.Assert.assertNotNull(objArray77);
        org.junit.Assert.assertNotNull(throwableArray79);
        org.junit.Assert.assertNotNull(wildcardClass80);
        org.junit.Assert.assertNotNull(objArray88);
    }

//    @Test
//    public void test281() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test281");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        int int6 = randomDataImpl0.nextSecureInt(0, (int) (short) 10);
//        int int9 = randomDataImpl0.nextInt(0, (int) '#');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl13 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 0, (double) '#', 0.6610060414837631d);
//        double double14 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl13);
//        java.lang.String str16 = randomDataImpl0.nextSecureHexString(9);
//        double double18 = randomDataImpl0.nextT(0.5358329035727638d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-50.56069438179521d) + "'", double3 == (-50.56069438179521d));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 32 + "'", int9 == 32);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-8.0d) + "'", double14 == (-8.0d));
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "105c41ce9" + "'", str16.equals("105c41ce9"));
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + (-1.015912844861063d) + "'", double18 == (-1.015912844861063d));
//    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(4.481893892359017d, 0.23151936896823624d, 0.5745894825315334d, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: maximal number of iterations (1) exceeded");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException6 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10L, (java.lang.Number) (-0.7853981633974483d), true);
        java.lang.Object[] objArray7 = numberIsTooLargeException6.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException8 = new org.apache.commons.math.MaxIterationsExceededException(18, "c4cacf68d12f50b58eda94", objArray7);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException14 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 100L, (java.lang.Number) 10.000000000000002d, false);
        java.lang.Object[] objArray15 = numberIsTooSmallException14.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException16 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "", objArray15);
        org.apache.commons.math.exception.util.Localizable localizable17 = maxIterationsExceededException16.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException24 = new org.apache.commons.math.exception.OutOfRangeException(localizable20, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 10.0f, (java.lang.Number) (byte) 10);
        org.apache.commons.math.exception.util.Localizable localizable25 = outOfRangeException24.getGeneralPattern();
        java.lang.Object[] objArray32 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException33 = new org.apache.commons.math.ConvergenceException("", objArray32);
        java.lang.Throwable[] throwableArray34 = convergenceException33.getSuppressed();
        java.lang.Class<?> wildcardClass35 = convergenceException33.getClass();
        org.apache.commons.math.exception.util.Localizable localizable36 = null;
        java.lang.Object[] objArray43 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException44 = new org.apache.commons.math.ConvergenceException("", objArray43);
        org.apache.commons.math.MathException mathException45 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException33, localizable36, objArray43);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException46 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable25, objArray43);
        org.apache.commons.math.ConvergenceException convergenceException47 = new org.apache.commons.math.ConvergenceException("", objArray43);
        org.apache.commons.math.ConvergenceException convergenceException48 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException8, localizable17, objArray43);
        org.apache.commons.math.MathException mathException49 = new org.apache.commons.math.MathException("baebd7eee", objArray43);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(localizable17);
        org.junit.Assert.assertTrue("'" + localizable25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable25.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(throwableArray34);
        org.junit.Assert.assertNotNull(wildcardClass35);
        org.junit.Assert.assertNotNull(objArray43);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        java.lang.Object[] objArray7 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException("", objArray7);
        java.lang.Throwable[] throwableArray9 = convergenceException8.getSuppressed();
        java.lang.Class<?> wildcardClass10 = convergenceException8.getClass();
        java.lang.Object[] objArray18 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException("", objArray18);
        java.lang.Throwable[] throwableArray20 = convergenceException19.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable21 = null;
        java.lang.Object[] objArray28 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException("", objArray28);
        java.lang.Throwable[] throwableArray30 = convergenceException29.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException19, localizable21, (java.lang.Object[]) throwableArray30);
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException8, "", (java.lang.Object[]) throwableArray30);
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException37 = new org.apache.commons.math.exception.OutOfRangeException(localizable33, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 10.0f, (java.lang.Number) (byte) 10);
        org.apache.commons.math.exception.util.Localizable localizable38 = outOfRangeException37.getGeneralPattern();
        java.lang.Object[] objArray45 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException("", objArray45);
        java.lang.Throwable[] throwableArray47 = convergenceException46.getSuppressed();
        java.lang.Class<?> wildcardClass48 = convergenceException46.getClass();
        java.lang.Object[] objArray56 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException57 = new org.apache.commons.math.ConvergenceException("", objArray56);
        java.lang.Throwable[] throwableArray58 = convergenceException57.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable59 = null;
        java.lang.Object[] objArray66 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException67 = new org.apache.commons.math.ConvergenceException("", objArray66);
        java.lang.Throwable[] throwableArray68 = convergenceException67.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException69 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException57, localizable59, (java.lang.Object[]) throwableArray68);
        org.apache.commons.math.ConvergenceException convergenceException70 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException46, "", (java.lang.Object[]) throwableArray68);
        org.apache.commons.math.MathException mathException71 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException32, localizable38, (java.lang.Object[]) throwableArray68);
        java.lang.Object[] objArray74 = new java.lang.Object[] { 1.0d };
        org.apache.commons.math.ConvergenceException convergenceException75 = new org.apache.commons.math.ConvergenceException("", objArray74);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException76 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, localizable38, objArray74);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException78 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 10);
        java.lang.Object[] objArray79 = notStrictlyPositiveException78.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException80 = new org.apache.commons.math.ConvergenceException(localizable38, objArray79);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException84 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable38, (java.lang.Number) 0.3647624899860726d, (java.lang.Number) 303.76685876477154d, false);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(throwableArray20);
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertNotNull(throwableArray30);
        org.junit.Assert.assertTrue("'" + localizable38 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable38.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray45);
        org.junit.Assert.assertNotNull(throwableArray47);
        org.junit.Assert.assertNotNull(wildcardClass48);
        org.junit.Assert.assertNotNull(objArray56);
        org.junit.Assert.assertNotNull(throwableArray58);
        org.junit.Assert.assertNotNull(objArray66);
        org.junit.Assert.assertNotNull(throwableArray68);
        org.junit.Assert.assertNotNull(objArray74);
        org.junit.Assert.assertNotNull(objArray79);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.0d, 0.0d, 6.721731521631732d, 5);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException5 = new org.apache.commons.math.exception.OutOfRangeException(localizable1, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 10.0f, (java.lang.Number) (byte) 10);
        org.apache.commons.math.exception.util.Localizable localizable6 = outOfRangeException5.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException14 = new org.apache.commons.math.exception.OutOfRangeException(localizable10, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 10.0f, (java.lang.Number) (byte) 10);
        org.apache.commons.math.exception.util.Localizable localizable15 = outOfRangeException14.getGeneralPattern();
        java.lang.Object[] objArray22 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException("", objArray22);
        java.lang.Throwable[] throwableArray24 = convergenceException23.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        java.lang.Object[] objArray32 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException33 = new org.apache.commons.math.ConvergenceException("", objArray32);
        java.lang.Throwable[] throwableArray34 = convergenceException33.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException23, localizable25, (java.lang.Object[]) throwableArray34);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException36 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable15, (java.lang.Object[]) throwableArray34);
        java.lang.Object[] objArray37 = maxIterationsExceededException36.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException38 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 100, "", objArray37);
        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException(localizable6, objArray37);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException43 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable6, (java.lang.Number) 1.1752011936438014d, (java.lang.Number) 0.61875315207275d, false);
        org.apache.commons.math.exception.util.Localizable localizable48 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException52 = new org.apache.commons.math.exception.OutOfRangeException(localizable48, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 10.0f, (java.lang.Number) (byte) 10);
        org.apache.commons.math.exception.util.Localizable localizable53 = outOfRangeException52.getGeneralPattern();
        java.lang.Object[] objArray60 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException61 = new org.apache.commons.math.ConvergenceException("", objArray60);
        java.lang.Throwable[] throwableArray62 = convergenceException61.getSuppressed();
        java.lang.Class<?> wildcardClass63 = convergenceException61.getClass();
        org.apache.commons.math.exception.util.Localizable localizable64 = null;
        java.lang.Object[] objArray71 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException72 = new org.apache.commons.math.ConvergenceException("", objArray71);
        org.apache.commons.math.MathException mathException73 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException61, localizable64, objArray71);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException74 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable53, objArray71);
        org.apache.commons.math.ConvergenceException convergenceException75 = new org.apache.commons.math.ConvergenceException("", objArray71);
        org.apache.commons.math.MathException mathException76 = new org.apache.commons.math.MathException("", objArray71);
        org.apache.commons.math.ConvergenceException convergenceException77 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException43, "", objArray71);
        org.apache.commons.math.ConvergenceException convergenceException78 = new org.apache.commons.math.ConvergenceException("hi!", objArray71);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable15.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(throwableArray24);
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(throwableArray34);
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertTrue("'" + localizable53 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable53.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray60);
        org.junit.Assert.assertNotNull(throwableArray62);
        org.junit.Assert.assertNotNull(wildcardClass63);
        org.junit.Assert.assertNotNull(objArray71);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 12);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4876550949064553d + "'", double1 == 1.4876550949064553d);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1.5860134523134308E15d, (java.lang.Number) 68.0d, true);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        double double1 = org.apache.commons.math.util.FastMath.tan(4.0940666686320855d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4057198752773794d + "'", double1 == 1.4057198752773794d);
    }

//    @Test
//    public void test290() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test290");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        randomDataImpl0.reSeedSecure((long) '4');
//        double double7 = randomDataImpl0.nextChiSquare((double) 1.0f);
//        double double10 = randomDataImpl0.nextWeibull(7.922060682256977d, 9.555870611193584E-5d);
//        double double13 = randomDataImpl0.nextF(0.8086810944281969d, 2.220446049250313E-16d);
//        double double15 = randomDataImpl0.nextT(3.482265822014589d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 29.047400086545906d + "'", double3 == 29.047400086545906d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.7065696033928847d + "'", double7 == 0.7065696033928847d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 9.73451272249713E-5d + "'", double10 == 9.73451272249713E-5d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 3.4264562498874724d + "'", double13 == 3.4264562498874724d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-1.234658575723068d) + "'", double15 == (-1.234658575723068d));
//    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        double double1 = org.apache.commons.math.special.Erf.erf(3.2194621878464096d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999947115509781d + "'", double1 == 0.9999947115509781d);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(4.605170185988093d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): standard deviation (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(2.251896810768105d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.2518968107681054d + "'", double1 == 2.2518968107681054d);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (short) 0);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.5358329035727638d);
        boolean boolean2 = notStrictlyPositiveException1.getBoundIsAllowed();
        org.apache.commons.math.MathException mathException3 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException1);
        java.lang.Number number4 = notStrictlyPositiveException1.getMin();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0 + "'", number4.equals(0));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        long long2 = org.apache.commons.math.util.FastMath.min(4L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

//    @Test
//    public void test297() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test297");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        randomDataImpl0.reSeedSecure((long) '4');
//        double double7 = randomDataImpl0.nextChiSquare((double) 1.0f);
//        randomDataImpl0.reSeed();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl12 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) (short) 1, 3.141592653589793d);
//        double double13 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl12);
//        java.lang.String str15 = randomDataImpl0.nextSecureHexString(100);
//        java.lang.String str17 = randomDataImpl0.nextSecureHexString((int) (byte) 10);
//        try {
//            long long20 = randomDataImpl0.nextLong((long) 34, 0L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 34 is larger than, or equal to, the maximum (0): lower bound (34) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.164816132366116d + "'", double3 == 10.164816132366116d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 3.0871403584967645d + "'", double7 == 3.0871403584967645d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "c22d664b37444821d4ecd1e1e9d778d25a4edf89582703444894f5145ac0972ed6058b23c45e74d68542cf87b37b3d9a6c9f" + "'", str15.equals("c22d664b37444821d4ecd1e1e9d778d25a4edf89582703444894f5145ac0972ed6058b23c45e74d68542cf87b37b3d9a6c9f"));
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "df0e8b1d06" + "'", str17.equals("df0e8b1d06"));
//    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 27, (long) 26);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 26L + "'", long2 == 26L);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(2.718281828459045d, 0.9999999985894203d, 0.0d, 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: maximal number of iterations (1) exceeded");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(2.8991410882239435d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.899141088223944d + "'", double1 == 2.899141088223944d);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException5 = new org.apache.commons.math.exception.OutOfRangeException(localizable1, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 10.0f, (java.lang.Number) (byte) 10);
        org.apache.commons.math.exception.util.Localizable localizable6 = outOfRangeException5.getGeneralPattern();
        java.lang.Object[] objArray13 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException("", objArray13);
        java.lang.Throwable[] throwableArray15 = convergenceException14.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        java.lang.Object[] objArray23 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException("", objArray23);
        java.lang.Throwable[] throwableArray25 = convergenceException24.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException26 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException14, localizable16, (java.lang.Object[]) throwableArray25);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException27 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable6, (java.lang.Object[]) throwableArray25);
        int int28 = maxIterationsExceededException27.getMaxIterations();
        java.lang.String str29 = maxIterationsExceededException27.toString();
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNotNull(throwableArray25);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "org.apache.commons.math.MaxIterationsExceededException: {0} out of [{1}, {2}] range" + "'", str29.equals("org.apache.commons.math.MaxIterationsExceededException: {0} out of [{1}, {2}] range"));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 13);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.2566139548000526d + "'", double1 == 3.2566139548000526d);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(100.0d, (double) (byte) 10);
        double double4 = normalDistributionImpl2.density(3.175169392061453d);
        double double6 = normalDistributionImpl2.density(1.2917468367601999d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.7508638739482679E-22d + "'", double4 == 1.7508638739482679E-22d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.7769058381042455E-23d + "'", double6 == 2.7769058381042455E-23d);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 1L, (double) (short) 1);
        double double5 = normalDistributionImpl2.cumulativeProbability(0.0d, 0.0d);
        double double7 = normalDistributionImpl2.cumulativeProbability(10.000000000000002d);
        double double9 = normalDistributionImpl2.cumulativeProbability(2.302585092994046d);
        double double10 = normalDistributionImpl2.getMean();
        double double12 = normalDistributionImpl2.density(0.5276511697442289d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.9036417751182644d + "'", double9 == 0.9036417751182644d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.3568301995275126d + "'", double12 == 0.3568301995275126d);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.9585304424717216d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9790456794612402d + "'", double1 == 0.9790456794612402d);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException5 = new org.apache.commons.math.exception.OutOfRangeException(localizable1, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 10.0f, (java.lang.Number) (byte) 10);
        org.apache.commons.math.exception.util.Localizable localizable6 = outOfRangeException5.getGeneralPattern();
        java.lang.Object[] objArray13 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException("", objArray13);
        java.lang.Throwable[] throwableArray15 = convergenceException14.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        java.lang.Object[] objArray23 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException("", objArray23);
        java.lang.Throwable[] throwableArray25 = convergenceException24.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException26 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException14, localizable16, (java.lang.Object[]) throwableArray25);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException27 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable6, (java.lang.Object[]) throwableArray25);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException31 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) 1.136390668384291d, (java.lang.Number) (-6.435110937730336d), false);
        java.lang.Object[] objArray38 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException("", objArray38);
        java.lang.Throwable[] throwableArray40 = convergenceException39.getSuppressed();
        java.lang.Class<?> wildcardClass41 = convergenceException39.getClass();
        java.lang.Object[] objArray49 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException50 = new org.apache.commons.math.ConvergenceException("", objArray49);
        java.lang.Throwable[] throwableArray51 = convergenceException50.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable52 = null;
        java.lang.Object[] objArray59 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException60 = new org.apache.commons.math.ConvergenceException("", objArray59);
        java.lang.Throwable[] throwableArray61 = convergenceException60.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException62 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException50, localizable52, (java.lang.Object[]) throwableArray61);
        org.apache.commons.math.ConvergenceException convergenceException63 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException39, "", (java.lang.Object[]) throwableArray61);
        org.apache.commons.math.exception.util.Localizable localizable64 = convergenceException63.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException66 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable64, (java.lang.Number) 2.718281828459045d);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException70 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10L, (java.lang.Number) (-0.7853981633974483d), true);
        java.lang.Object[] objArray71 = numberIsTooLargeException70.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException72 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable64, objArray71);
        org.apache.commons.math.ConvergenceException convergenceException73 = new org.apache.commons.math.ConvergenceException(localizable6, objArray71);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNotNull(throwableArray25);
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(throwableArray40);
        org.junit.Assert.assertNotNull(wildcardClass41);
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertNotNull(throwableArray51);
        org.junit.Assert.assertNotNull(objArray59);
        org.junit.Assert.assertNotNull(throwableArray61);
        org.junit.Assert.assertNotNull(localizable64);
        org.junit.Assert.assertNotNull(objArray71);
    }

//    @Test
//    public void test307() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test307");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        double double6 = randomDataImpl0.nextCauchy(1.6704649792860586d, 86.78823356954149d);
//        long long9 = randomDataImpl0.nextLong((long) 1, (long) 16);
//        double double12 = randomDataImpl0.nextGaussian(54.85907906241573d, (double) 10.0f);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 9.797470351388457d + "'", double3 == 9.797470351388457d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-69.20821075847039d) + "'", double6 == (-69.20821075847039d));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 4L + "'", long9 == 4L);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 64.82296377358114d + "'", double12 == 64.82296377358114d);
//    }

//    @Test
//    public void test308() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test308");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        randomDataImpl0.reSeedSecure((long) '4');
//        double double7 = randomDataImpl0.nextChiSquare((double) 1.0f);
//        randomDataImpl0.reSeed();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl12 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) (short) 1, 3.141592653589793d);
//        double double13 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl12);
//        randomDataImpl0.reSeed();
//        int int17 = randomDataImpl0.nextSecureInt(18, 31);
//        randomDataImpl0.reSeed();
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 9.815220173345839d + "'", double3 == 9.815220173345839d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.5704486394003982d + "'", double7 == 2.5704486394003982d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 24 + "'", int17 == 24);
//    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 32, (java.lang.Number) Double.NaN, false);
        java.lang.Number number4 = numberIsTooLargeException3.getMax();
        java.lang.Object[] objArray5 = numberIsTooLargeException3.getArguments();
        org.junit.Assert.assertEquals((double) number4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(objArray5);
    }

//    @Test
//    public void test310() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test310");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        int int6 = randomDataImpl0.nextSecureInt(0, (int) (short) 10);
//        int int9 = randomDataImpl0.nextInt(0, (int) '#');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl13 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 0, (double) '#', 0.6610060414837631d);
//        double double14 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl13);
//        double double15 = normalDistributionImpl13.getMean();
//        double[] doubleArray17 = normalDistributionImpl13.sample((int) (short) 100);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 9.740578521872024d + "'", double3 == 9.740578521872024d);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 22.661006041484203d + "'", double14 == 22.661006041484203d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
//        org.junit.Assert.assertNotNull(doubleArray17);
//    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        double double1 = org.apache.commons.math.util.FastMath.atanh((-0.04229861514908033d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0423238687756717d) + "'", double1 == (-0.0423238687756717d));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 6.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.29100619138474915d) + "'", double1 == (-0.29100619138474915d));
    }

//    @Test
//    public void test313() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test313");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        int int6 = randomDataImpl0.nextSecureInt(0, (int) (short) 10);
//        int int9 = randomDataImpl0.nextInt(0, (int) '#');
//        double double12 = randomDataImpl0.nextBeta((double) 97.0f, 1.0E35d);
//        int int15 = randomDataImpl0.nextInt(7, 9);
//        try {
//            double double18 = randomDataImpl0.nextUniform(326.41127383084927d, 0.6814847386837123d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 326.411 is larger than, or equal to, the maximum (0.681): lower bound (326.411) must be strictly less than upper bound (0.681)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 9.170044929964194d + "'", double3 == 9.170044929964194d);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 9 + "'", int15 == 9);
//    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 0, (double) '#', 0.6610060414837631d);
        normalDistributionImpl3.reseedRandomGenerator((long) (short) 10);
        double double7 = normalDistributionImpl3.density(0.6610060414837631d);
        double double9 = normalDistributionImpl3.cumulativeProbability(0.0d);
        double double11 = normalDistributionImpl3.density((double) 10L);
        double double12 = normalDistributionImpl3.getMean();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.011396318286638113d + "'", double7 == 0.011396318286638113d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.5d + "'", double9 == 0.5d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.01094247885554892d + "'", double11 == 0.01094247885554892d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
    }

//    @Test
//    public void test315() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test315");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        randomDataImpl0.reSeedSecure((long) '4');
//        double double7 = randomDataImpl0.nextChiSquare((double) 1.0f);
//        double double10 = randomDataImpl0.nextWeibull(7.922060682256977d, 9.555870611193584E-5d);
//        try {
//            long long13 = randomDataImpl0.nextSecureLong(71L, (long) 28);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 71 is larger than, or equal to, the maximum (28): lower bound (71) must be strictly less than upper bound (28)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 9.346495417675209d + "'", double3 == 9.346495417675209d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.004623119904960463d + "'", double7 == 0.004623119904960463d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 8.737329189672529E-5d + "'", double10 == 8.737329189672529E-5d);
//    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        double double1 = org.apache.commons.math.util.FastMath.acos(8.876439600277887d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test317() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test317");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        randomDataImpl0.reSeedSecure((long) '#');
//        double double8 = randomDataImpl0.nextGaussian(1.7508638739482679E-22d, 9.81191859311744d);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution9 = null;
//        try {
//            int int10 = randomDataImpl0.nextInversionDeviate(integerDistribution9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 9.36031927337264d + "'", double3 == 9.36031927337264d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.4113818752945554d + "'", double8 == 0.4113818752945554d);
//    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        double double1 = org.apache.commons.math.util.FastMath.log1p(1.5398907041877406E-5d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.539878847992551E-5d + "'", double1 == 1.539878847992551E-5d);
    }

//    @Test
//    public void test319() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test319");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        int int6 = randomDataImpl0.nextSecureInt(0, (int) (short) 10);
//        int int9 = randomDataImpl0.nextInt(0, (int) '#');
//        try {
//            long long11 = randomDataImpl0.nextPoisson((-0.04229861514908033d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.042 is smaller than, or equal to, the minimum (0): mean (-0.042)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 9.311365102342862d + "'", double3 == 9.311365102342862d);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 8 + "'", int6 == 8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 17 + "'", int9 == 17);
//    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 12L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 12 + "'", int1 == 12);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 6.793027944470163E-5d);
        org.apache.commons.math.exception.util.Localizable localizable3 = notStrictlyPositiveException2.getSpecificPattern();
        java.lang.Number number4 = notStrictlyPositiveException2.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable5 = notStrictlyPositiveException2.getSpecificPattern();
        org.junit.Assert.assertNull(localizable3);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 6.793027944470163E-5d + "'", number4.equals(6.793027944470163E-5d));
        org.junit.Assert.assertNull(localizable5);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(1.4640127048843006d, (double) 33, 1.06246414812714d);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 10.0f, (java.lang.Number) 2.718281828459045d, false);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException9 = new org.apache.commons.math.exception.OutOfRangeException(localizable5, (java.lang.Number) 10, (java.lang.Number) 4.239302734211798d, (java.lang.Number) 1.4261759824292803E-20d);
        java.lang.Object[] objArray16 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException("", objArray16);
        java.lang.Throwable[] throwableArray18 = convergenceException17.getSuppressed();
        java.lang.Class<?> wildcardClass19 = convergenceException17.getClass();
        java.lang.Object[] objArray27 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException("", objArray27);
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException17, "", objArray27);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException36 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 100L, (java.lang.Number) 10.000000000000002d, false);
        java.lang.Object[] objArray37 = numberIsTooSmallException36.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException38 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "", objArray37);
        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException29, "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)", objArray37);
        org.apache.commons.math.exception.util.Localizable localizable40 = convergenceException29.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException44 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 10.0d, (java.lang.Number) (byte) 0, false);
        java.lang.Number number45 = numberIsTooSmallException44.getMin();
        java.lang.Object[] objArray46 = numberIsTooSmallException44.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException47 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable40, objArray46);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertNotNull(localizable40);
        org.junit.Assert.assertTrue("'" + number45 + "' != '" + (byte) 0 + "'", number45.equals((byte) 0));
        org.junit.Assert.assertNotNull(objArray46);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(1.1399878826998993E19d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1399878826998995E19d + "'", double1 == 1.1399878826998995E19d);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((-69.20821075847039d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.2079111471494703d) + "'", double1 == (-1.2079111471494703d));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        double double2 = org.apache.commons.math.util.FastMath.pow(9.160919125000353d, (-0.5470467700833206d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2976969260033571d + "'", double2 == 0.2976969260033571d);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 0, (double) '#', 0.6610060414837631d);
        normalDistributionImpl3.reseedRandomGenerator((long) (short) 10);
        double double7 = normalDistributionImpl3.density(0.6610060414837631d);
        double double8 = normalDistributionImpl3.getMean();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.011396318286638113d + "'", double7 == 0.011396318286638113d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.5358329035727638d);
        java.lang.Object[] objArray2 = notStrictlyPositiveException1.getArguments();
        org.junit.Assert.assertNotNull(objArray2);
    }

//    @Test
//    public void test329() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test329");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        randomDataImpl0.reSeedSecure((long) '4');
//        double double7 = randomDataImpl0.nextChiSquare((double) 1.0f);
//        double double9 = randomDataImpl0.nextT(0.5972534764549589d);
//        randomDataImpl0.reSeedSecure();
//        int int13 = randomDataImpl0.nextPascal(12, 0.8623188722876839d);
//        double double16 = randomDataImpl0.nextWeibull(1.607132023323726E-9d, 1.9777654857699758d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 8.673388829468351d + "'", double3 == 8.673388829468351d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.07049807485650515d + "'", double7 == 0.07049807485650515d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-0.12782597051145378d) + "'", double9 == (-0.12782597051145378d));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2 + "'", int13 == 2);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
//    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        float float1 = org.apache.commons.math.util.FastMath.abs(97.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 97.0f + "'", float1 == 97.0f);
    }

//    @Test
//    public void test331() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test331");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 1L, (double) (short) 1);
//        double double5 = normalDistributionImpl2.cumulativeProbability(0.0d, 0.0d);
//        double double7 = normalDistributionImpl2.cumulativeProbability(10.000000000000002d);
//        double double9 = normalDistributionImpl2.cumulativeProbability(2.302585092994046d);
//        double double10 = normalDistributionImpl2.getMean();
//        double double11 = normalDistributionImpl2.getStandardDeviation();
//        double double12 = normalDistributionImpl2.sample();
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.9036417751182644d + "'", double9 == 0.9036417751182644d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.518785653128647d + "'", double12 == 0.518785653128647d);
//    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (byte) 100, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 10.0f, (java.lang.Number) (byte) 10);
        org.apache.commons.math.exception.util.Localizable localizable5 = outOfRangeException4.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException13 = new org.apache.commons.math.exception.OutOfRangeException(localizable9, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 10.0f, (java.lang.Number) (byte) 10);
        org.apache.commons.math.exception.util.Localizable localizable14 = outOfRangeException13.getGeneralPattern();
        java.lang.Object[] objArray21 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException("", objArray21);
        java.lang.Throwable[] throwableArray23 = convergenceException22.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        java.lang.Object[] objArray31 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException("", objArray31);
        java.lang.Throwable[] throwableArray33 = convergenceException32.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException34 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException22, localizable24, (java.lang.Object[]) throwableArray33);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException35 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable14, (java.lang.Object[]) throwableArray33);
        java.lang.Object[] objArray36 = maxIterationsExceededException35.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException37 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 100, "", objArray36);
        org.apache.commons.math.MathException mathException38 = new org.apache.commons.math.MathException(localizable5, objArray36);
        java.lang.Number number39 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException40 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable5, number39);
        org.apache.commons.math.exception.util.Localizable localizable41 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException43 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 100.0f);
        org.apache.commons.math.exception.util.Localizable localizable44 = notStrictlyPositiveException43.getSpecificPattern();
        java.lang.Object[] objArray52 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException53 = new org.apache.commons.math.ConvergenceException("", objArray52);
        java.lang.Throwable[] throwableArray54 = convergenceException53.getSuppressed();
        java.lang.Class<?> wildcardClass55 = convergenceException53.getClass();
        java.lang.Object[] objArray63 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException64 = new org.apache.commons.math.ConvergenceException("", objArray63);
        org.apache.commons.math.ConvergenceException convergenceException65 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException53, "", objArray63);
        java.lang.Object[] objArray73 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException74 = new org.apache.commons.math.ConvergenceException("", objArray73);
        java.lang.Throwable[] throwableArray75 = convergenceException74.getSuppressed();
        java.lang.Class<?> wildcardClass76 = convergenceException74.getClass();
        java.lang.Object[] objArray84 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException85 = new org.apache.commons.math.ConvergenceException("", objArray84);
        org.apache.commons.math.ConvergenceException convergenceException86 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException74, "", objArray84);
        org.apache.commons.math.ConvergenceException convergenceException87 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException53, "hi!", objArray84);
        org.apache.commons.math.ConvergenceException convergenceException88 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException43, "", objArray84);
        java.lang.String str89 = convergenceException88.getPattern();
        java.lang.Object[] objArray90 = convergenceException88.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException91 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable41, objArray90);
        java.lang.Number number92 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException93 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable41, number92);
        java.lang.Object[] objArray94 = notStrictlyPositiveException93.getArguments();
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable14.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(throwableArray23);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(throwableArray33);
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertNull(localizable44);
        org.junit.Assert.assertNotNull(objArray52);
        org.junit.Assert.assertNotNull(throwableArray54);
        org.junit.Assert.assertNotNull(wildcardClass55);
        org.junit.Assert.assertNotNull(objArray63);
        org.junit.Assert.assertNotNull(objArray73);
        org.junit.Assert.assertNotNull(throwableArray75);
        org.junit.Assert.assertNotNull(wildcardClass76);
        org.junit.Assert.assertNotNull(objArray84);
        org.junit.Assert.assertTrue("'" + str89 + "' != '" + "" + "'", str89.equals(""));
        org.junit.Assert.assertNotNull(objArray90);
        org.junit.Assert.assertNotNull(objArray94);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 68.0d);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        double double1 = org.apache.commons.math.special.Gamma.digamma(1.8319176536209936d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3082509284845315d + "'", double1 == 0.3082509284845315d);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        double double1 = org.apache.commons.math.util.FastMath.rint(4.239302734211798d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.0d + "'", double1 == 4.0d);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.9999999999997057d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7853981633973012d + "'", double1 == 0.7853981633973012d);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(21.482484630319618d, 344.51150907219534d, (-395.900529910686d));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 3.141592653589793d, (java.lang.Number) 6.574048747574973E-6d, (java.lang.Number) 8.388192002392895d);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.002991729972222412d, 11310.231150110518d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

//    @Test
//    public void test341() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test341");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        int int6 = randomDataImpl0.nextSecureInt(0, (int) (short) 10);
//        double double8 = randomDataImpl0.nextExponential(3.41643668911758d);
//        try {
//            long long11 = randomDataImpl0.nextLong((long) (byte) 10, 9L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 10 is larger than, or equal to, the maximum (9): lower bound (10) must be strictly less than upper bound (9)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 12.540479757994d + "'", double3 == 12.540479757994d);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 5 + "'", int6 == 5);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.6075522913743945d + "'", double8 == 0.6075522913743945d);
//    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.010941907637883524d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.000059863268637d + "'", double1 == 1.000059863268637d);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(22);
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException6 = new org.apache.commons.math.exception.OutOfRangeException(localizable2, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 10.0f, (java.lang.Number) (byte) 10);
        org.apache.commons.math.exception.util.Localizable localizable7 = outOfRangeException6.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException11 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable7, (java.lang.Number) (short) 100, (java.lang.Number) 11013.232874703393d, false);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException15 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable7, (java.lang.Number) 8.737800111547191d, (java.lang.Number) 8.737800111547191d, false);
        java.lang.Object[] objArray16 = null;
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException1, localizable7, objArray16);
        java.lang.Class<?> wildcardClass18 = convergenceException17.getClass();
        org.apache.commons.math.exception.util.Localizable localizable19 = convergenceException17.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNull(localizable19);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        long long1 = org.apache.commons.math.util.FastMath.round((double) (short) 0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 100L, (java.lang.Number) 10.000000000000002d, false);
        java.lang.Object[] objArray4 = numberIsTooSmallException3.getArguments();
        java.lang.Number number5 = numberIsTooSmallException3.getArgument();
        java.lang.Object[] objArray6 = numberIsTooSmallException3.getArguments();
        java.lang.Number number7 = numberIsTooSmallException3.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable8 = numberIsTooSmallException3.getSpecificPattern();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 100L + "'", number5.equals(100L));
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 100L + "'", number7.equals(100L));
        org.junit.Assert.assertNull(localizable8);
    }

//    @Test
//    public void test347() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test347");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        randomDataImpl0.reSeedSecure((long) 'a');
//        int int8 = randomDataImpl0.nextInt(10, 36);
//        double double11 = randomDataImpl0.nextF((double) 26.0f, 5.298292365610485d);
//        double double14 = randomDataImpl0.nextCauchy((-0.45434759012392645d), 10.217527670354155d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 11.700898964595845d + "'", double3 == 11.700898964595845d);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 24 + "'", int8 == 24);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.645872238411457d + "'", double11 == 0.645872238411457d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-1.5600537095027767d) + "'", double14 == (-1.5600537095027767d));
//    }

//    @Test
//    public void test348() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test348");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        randomDataImpl0.reSeedSecure((long) '4');
//        double double7 = randomDataImpl0.nextChiSquare((double) 1.0f);
//        double double9 = randomDataImpl0.nextT(0.5972534764549589d);
//        randomDataImpl0.reSeedSecure();
//        int int13 = randomDataImpl0.nextPascal(12, 0.8623188722876839d);
//        try {
//            double double16 = randomDataImpl0.nextCauchy(6.574048747574973E-6d, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): scale (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 11.720385529790374d + "'", double3 == 11.720385529790374d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.9384334415476943d + "'", double7 == 0.9384334415476943d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.04355614655713751d + "'", double9 == 0.04355614655713751d);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        double double1 = org.apache.commons.math.util.FastMath.exp(7.34772858964088d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1552.6657783315172d + "'", double1 == 1552.6657783315172d);
    }

//    @Test
//    public void test350() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test350");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        randomDataImpl0.reSeedSecure((long) '4');
//        double double7 = randomDataImpl0.nextChiSquare((double) 1.0f);
//        double double9 = randomDataImpl0.nextChiSquare(7.659130937910243d);
//        double double12 = randomDataImpl0.nextGaussian(6.028576045602152d, 47.72559009637225d);
//        double double15 = randomDataImpl0.nextGamma(6.802032797158093d, 0.5210953054937474d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 11.98615539533064d + "'", double3 == 11.98615539533064d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.166124136478495d + "'", double7 == 2.166124136478495d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 5.548138945339239d + "'", double9 == 5.548138945339239d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 79.24025137797729d + "'", double12 == 79.24025137797729d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 4.319799979550179d + "'", double15 == 4.319799979550179d);
//    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        int int2 = org.apache.commons.math.util.FastMath.min((int) '#', 21);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21 + "'", int2 == 21);
    }

//    @Test
//    public void test352() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test352");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        int int6 = randomDataImpl0.nextSecureInt(0, (int) (short) 10);
//        int int9 = randomDataImpl0.nextInt(0, (int) '#');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl13 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 0, (double) '#', 0.6610060414837631d);
//        double double14 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl13);
//        double double15 = normalDistributionImpl13.getMean();
//        double double16 = normalDistributionImpl13.getMean();
//        double double17 = normalDistributionImpl13.getMean();
//        double double18 = normalDistributionImpl13.sample();
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 11.922389964939175d + "'", double3 == 11.922389964939175d);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 5 + "'", int6 == 5);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 24 + "'", int9 == 24);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 83.33899395851455d + "'", double14 == 83.33899395851455d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 17.32687496910347d + "'", double18 == 17.32687496910347d);
//    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 10.0f, (java.lang.Number) 2.718281828459045d, false);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException4.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException4);
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException12 = new org.apache.commons.math.exception.OutOfRangeException(localizable8, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 10.0f, (java.lang.Number) (byte) 10);
        org.apache.commons.math.exception.util.Localizable localizable13 = outOfRangeException12.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException17 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable13, (java.lang.Number) (short) 100, (java.lang.Number) 11013.232874703393d, false);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException21 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable13, (java.lang.Number) 8.737800111547191d, (java.lang.Number) 8.737800111547191d, false);
        org.apache.commons.math.exception.util.Localizable localizable22 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException26 = new org.apache.commons.math.exception.OutOfRangeException(localizable22, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 10.0f, (java.lang.Number) (byte) 10);
        org.apache.commons.math.exception.util.Localizable localizable27 = outOfRangeException26.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable28 = outOfRangeException26.getGeneralPattern();
        java.lang.Object[] objArray35 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException("", objArray35);
        java.lang.Throwable[] throwableArray37 = convergenceException36.getSuppressed();
        java.lang.Class<?> wildcardClass38 = convergenceException36.getClass();
        org.apache.commons.math.exception.util.Localizable localizable39 = null;
        java.lang.Object[] objArray46 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException47 = new org.apache.commons.math.ConvergenceException("", objArray46);
        org.apache.commons.math.MathException mathException48 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException36, localizable39, objArray46);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException49 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable13, localizable28, objArray46);
        java.lang.String str50 = mathIllegalArgumentException49.toString();
        org.apache.commons.math.exception.util.Localizable localizable51 = mathIllegalArgumentException49.getSpecificPattern();
        java.lang.Object[] objArray58 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException59 = new org.apache.commons.math.ConvergenceException("", objArray58);
        org.apache.commons.math.ConvergenceException convergenceException60 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException7, localizable51, objArray58);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException62 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable51, (java.lang.Number) 0.981153707124144d);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable13.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable27.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable28 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable28.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertNotNull(throwableArray37);
        org.junit.Assert.assertNotNull(wildcardClass38);
        org.junit.Assert.assertNotNull(objArray46);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "org.apache.commons.math.exception.MathIllegalArgumentException: 10 out of [hi!, 0] range: 10 out of [hi!, 0] range" + "'", str50.equals("org.apache.commons.math.exception.MathIllegalArgumentException: 10 out of [hi!, 0] range: 10 out of [hi!, 0] range"));
        org.junit.Assert.assertTrue("'" + localizable51 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable51.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray58);
    }

//    @Test
//    public void test354() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test354");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        randomDataImpl0.reSeedSecure((long) 'a');
//        int int8 = randomDataImpl0.nextInt(10, 36);
//        double double11 = randomDataImpl0.nextF((double) 26.0f, 5.298292365610485d);
//        try {
//            double double14 = randomDataImpl0.nextF((-24.46057190575371d), (double) 100L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -24.461 is smaller than, or equal to, the minimum (0): degrees of freedom (-24.461)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 11.031470507020687d + "'", double3 == 11.031470507020687d);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 20 + "'", int8 == 20);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 3.342732296314173d + "'", double11 == 3.342732296314173d);
//    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException5 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 32, (java.lang.Number) Double.NaN, false);
        maxIterationsExceededException1.addSuppressed((java.lang.Throwable) numberIsTooLargeException5);
        java.lang.Throwable[] throwableArray7 = numberIsTooLargeException5.getSuppressed();
        java.lang.Number number8 = numberIsTooLargeException5.getMax();
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertEquals((double) number8, Double.NaN, 0);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.4223479548124092d, 0.999999999999657d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.4223479548124093d + "'", double2 == 0.4223479548124093d);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException("{0} out of [{1}, {2}] range", objArray1);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        double double1 = org.apache.commons.math.util.FastMath.log10(6.874990646515254d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8372721116412711d + "'", double1 == 0.8372721116412711d);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.3568301995275126d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4287932394879327d + "'", double1 == 0.4287932394879327d);
    }

//    @Test
//    public void test360() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test360");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        randomDataImpl0.reSeedSecure((long) '4');
//        double double7 = randomDataImpl0.nextChiSquare((double) 1.0f);
//        randomDataImpl0.reSeed();
//        int int11 = randomDataImpl0.nextPascal(2, 1.9746370780062322E-24d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl15 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 0, (double) '#', 0.6610060414837631d);
//        normalDistributionImpl15.reseedRandomGenerator((long) (short) 10);
//        double double19 = normalDistributionImpl15.density(0.6610060414837631d);
//        double double20 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl15);
//        double double21 = normalDistributionImpl15.getMean();
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 11.220056179351564d + "'", double3 == 11.220056179351564d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.1886038422803406d + "'", double7 == 0.1886038422803406d);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2147483647 + "'", int11 == 2147483647);
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.011396318286638113d + "'", double19 == 0.011396318286638113d);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.6610060414837631d + "'", double20 == 0.6610060414837631d);
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
//    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 34L, (float) (byte) 100);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        java.lang.Object[] objArray6 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException("", objArray6);
        java.lang.Throwable[] throwableArray8 = convergenceException7.getSuppressed();
        java.lang.Class<?> wildcardClass9 = convergenceException7.getClass();
        java.lang.Object[] objArray17 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException("", objArray17);
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException7, "", objArray17);
        org.apache.commons.math.exception.util.Localizable localizable20 = convergenceException19.getGeneralPattern();
        java.lang.Object[] objArray29 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException("", objArray29);
        java.lang.Throwable[] throwableArray31 = convergenceException30.getSuppressed();
        java.lang.Class<?> wildcardClass32 = convergenceException30.getClass();
        java.lang.Object[] objArray40 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException("", objArray40);
        java.lang.Throwable[] throwableArray42 = convergenceException41.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable43 = null;
        java.lang.Object[] objArray50 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException51 = new org.apache.commons.math.ConvergenceException("", objArray50);
        java.lang.Throwable[] throwableArray52 = convergenceException51.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException53 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException41, localizable43, (java.lang.Object[]) throwableArray52);
        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException30, "", (java.lang.Object[]) throwableArray52);
        org.apache.commons.math.exception.util.Localizable localizable55 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException59 = new org.apache.commons.math.exception.OutOfRangeException(localizable55, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 10.0f, (java.lang.Number) (byte) 10);
        org.apache.commons.math.exception.util.Localizable localizable60 = outOfRangeException59.getGeneralPattern();
        java.lang.Object[] objArray67 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException68 = new org.apache.commons.math.ConvergenceException("", objArray67);
        java.lang.Throwable[] throwableArray69 = convergenceException68.getSuppressed();
        java.lang.Class<?> wildcardClass70 = convergenceException68.getClass();
        java.lang.Object[] objArray78 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException79 = new org.apache.commons.math.ConvergenceException("", objArray78);
        java.lang.Throwable[] throwableArray80 = convergenceException79.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable81 = null;
        java.lang.Object[] objArray88 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException89 = new org.apache.commons.math.ConvergenceException("", objArray88);
        java.lang.Throwable[] throwableArray90 = convergenceException89.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException91 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException79, localizable81, (java.lang.Object[]) throwableArray90);
        org.apache.commons.math.ConvergenceException convergenceException92 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException68, "", (java.lang.Object[]) throwableArray90);
        org.apache.commons.math.MathException mathException93 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException54, localizable60, (java.lang.Object[]) throwableArray90);
        org.apache.commons.math.ConvergenceException convergenceException94 = new org.apache.commons.math.ConvergenceException("", (java.lang.Object[]) throwableArray90);
        org.apache.commons.math.MathException mathException95 = new org.apache.commons.math.MathException("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)", (java.lang.Object[]) throwableArray90);
        org.apache.commons.math.MathException mathException96 = new org.apache.commons.math.MathException(localizable20, (java.lang.Object[]) throwableArray90);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(localizable20);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(throwableArray31);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertNotNull(objArray40);
        org.junit.Assert.assertNotNull(throwableArray42);
        org.junit.Assert.assertNotNull(objArray50);
        org.junit.Assert.assertNotNull(throwableArray52);
        org.junit.Assert.assertTrue("'" + localizable60 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable60.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray67);
        org.junit.Assert.assertNotNull(throwableArray69);
        org.junit.Assert.assertNotNull(wildcardClass70);
        org.junit.Assert.assertNotNull(objArray78);
        org.junit.Assert.assertNotNull(throwableArray80);
        org.junit.Assert.assertNotNull(objArray88);
        org.junit.Assert.assertNotNull(throwableArray90);
    }

//    @Test
//    public void test363() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test363");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        double double6 = randomDataImpl0.nextCauchy(1.6704649792860586d, 86.78823356954149d);
//        long long9 = randomDataImpl0.nextLong((long) 1, (long) 16);
//        double double11 = randomDataImpl0.nextChiSquare(56.0d);
//        double double14 = randomDataImpl0.nextGaussian(8.928976450870955d, 11013.232874703393d);
//        double double16 = randomDataImpl0.nextExponential(269.85625772799693d);
//        try {
//            int[] intArray19 = randomDataImpl0.nextPermutation(0, 9);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 9 is larger than the maximum (0): permutation size (9) exceeds permuation domain (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.896986890442589d + "'", double3 == 10.896986890442589d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 512.9774505339716d + "'", double6 == 512.9774505339716d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 4L + "'", long9 == 4L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 62.12100354713413d + "'", double11 == 62.12100354713413d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-7758.8395410876865d) + "'", double14 == (-7758.8395410876865d));
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 324.2549325860635d + "'", double16 == 324.2549325860635d);
//    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(3.40081118778545E-4d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.019485212798097874d + "'", double1 == 0.019485212798097874d);
    }

//    @Test
//    public void test365() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test365");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextChiSquare(0.398906612308477d);
//        randomDataImpl0.reSeedSecure();
//        double double5 = randomDataImpl0.nextT((double) 100.0f);
//        double double7 = randomDataImpl0.nextChiSquare(0.23151936896823624d);
//        try {
//            double double10 = randomDataImpl0.nextGamma((-0.29100619138474915d), 0.5403023058681398d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.291 is smaller than, or equal to, the minimum (0): alpha");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0533707416506357d + "'", double2 == 1.0533707416506357d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.6913592188934317d + "'", double5 == 0.6913592188934317d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.003275099909258775d + "'", double7 == 0.003275099909258775d);
//    }

//    @Test
//    public void test366() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test366");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        double double6 = randomDataImpl0.nextCauchy(1.6704649792860586d, 86.78823356954149d);
//        long long9 = randomDataImpl0.nextLong((long) 1, (long) 16);
//        double double11 = randomDataImpl0.nextChiSquare(56.0d);
//        double double14 = randomDataImpl0.nextGaussian(8.928976450870955d, 11013.232874703393d);
//        double double17 = randomDataImpl0.nextBeta(2.468576762660578d, 0.23151936896823624d);
//        double double20 = randomDataImpl0.nextBeta(91.07457264406051d, 0.038667623566644216d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 18.219228748820704d + "'", double3 == 18.219228748820704d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-202.125659768049d) + "'", double6 == (-202.125659768049d));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 8L + "'", long9 == 8L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 51.050260022014854d + "'", double11 == 51.050260022014854d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 6802.055650710697d + "'", double14 == 6802.055650710697d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.9984029903280077d + "'", double17 == 0.9984029903280077d);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.9999999989613638d + "'", double20 == 0.9999999989613638d);
//    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.08008157859897952d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0964673744639435d) + "'", double1 == (-1.0964673744639435d));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        java.lang.Object[] objArray6 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException("", objArray6);
        java.lang.Throwable[] throwableArray8 = convergenceException7.getSuppressed();
        java.lang.Class<?> wildcardClass9 = convergenceException7.getClass();
        java.lang.Object[] objArray17 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException("", objArray17);
        java.lang.Throwable[] throwableArray19 = convergenceException18.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException("", objArray27);
        java.lang.Throwable[] throwableArray29 = convergenceException28.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException18, localizable20, (java.lang.Object[]) throwableArray29);
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException7, "", (java.lang.Object[]) throwableArray29);
        org.apache.commons.math.exception.util.Localizable localizable32 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException36 = new org.apache.commons.math.exception.OutOfRangeException(localizable32, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 10.0f, (java.lang.Number) (byte) 10);
        org.apache.commons.math.exception.util.Localizable localizable37 = outOfRangeException36.getGeneralPattern();
        java.lang.Object[] objArray44 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException45 = new org.apache.commons.math.ConvergenceException("", objArray44);
        java.lang.Throwable[] throwableArray46 = convergenceException45.getSuppressed();
        java.lang.Class<?> wildcardClass47 = convergenceException45.getClass();
        java.lang.Object[] objArray55 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException56 = new org.apache.commons.math.ConvergenceException("", objArray55);
        java.lang.Throwable[] throwableArray57 = convergenceException56.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable58 = null;
        java.lang.Object[] objArray65 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException66 = new org.apache.commons.math.ConvergenceException("", objArray65);
        java.lang.Throwable[] throwableArray67 = convergenceException66.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException68 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException56, localizable58, (java.lang.Object[]) throwableArray67);
        org.apache.commons.math.ConvergenceException convergenceException69 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException45, "", (java.lang.Object[]) throwableArray67);
        org.apache.commons.math.MathException mathException70 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException31, localizable37, (java.lang.Object[]) throwableArray67);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException74 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable37, (java.lang.Number) 100L, (java.lang.Number) 11013.232874703393d, false);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException78 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 56.0d, (java.lang.Number) 0.9171523356672744d, true);
        numberIsTooSmallException74.addSuppressed((java.lang.Throwable) numberIsTooLargeException78);
        boolean boolean80 = numberIsTooLargeException78.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray81 = numberIsTooLargeException78.getSuppressed();
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(throwableArray29);
        org.junit.Assert.assertTrue("'" + localizable37 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable37.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertNotNull(throwableArray46);
        org.junit.Assert.assertNotNull(wildcardClass47);
        org.junit.Assert.assertNotNull(objArray55);
        org.junit.Assert.assertNotNull(throwableArray57);
        org.junit.Assert.assertNotNull(objArray65);
        org.junit.Assert.assertNotNull(throwableArray67);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + true + "'", boolean80 == true);
        org.junit.Assert.assertNotNull(throwableArray81);
    }

//    @Test
//    public void test369() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test369");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextChiSquare(0.398906612308477d);
//        randomDataImpl0.reSeedSecure();
//        double double5 = randomDataImpl0.nextT((double) 100.0f);
//        int int9 = randomDataImpl0.nextHypergeometric((int) '4', 36, (int) (byte) 1);
//        double double12 = randomDataImpl0.nextWeibull(0.5585053606381855d, 0.6610060414837631d);
//        int int15 = randomDataImpl0.nextPascal(2147483647, 0.6569865987187891d);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.4676498671925746d + "'", double2 == 1.4676498671925746d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-0.5460443737438536d) + "'", double5 == (-0.5460443737438536d));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0819763378088205d + "'", double12 == 1.0819763378088205d);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1121140518 + "'", int15 == 1121140518);
//    }

//    @Test
//    public void test370() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test370");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        java.lang.String str2 = randomDataImpl0.nextHexString(16);
//        java.lang.Class<?> wildcardClass3 = randomDataImpl0.getClass();
//        randomDataImpl0.reSeedSecure();
//        long long7 = randomDataImpl0.nextSecureLong(16L, (long) 18);
//        try {
//            long long10 = randomDataImpl0.nextLong(62L, 21L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 62 is larger than, or equal to, the maximum (21): lower bound (62) must be strictly less than upper bound (21)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "f1d0076a5eb72be1" + "'", str2.equals("f1d0076a5eb72be1"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 17L + "'", long7 == 17L);
//    }

//    @Test
//    public void test371() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test371");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        double double6 = randomDataImpl0.nextCauchy(1.6704649792860586d, 86.78823356954149d);
//        long long9 = randomDataImpl0.nextLong((long) 1, (long) 16);
//        double double11 = randomDataImpl0.nextChiSquare(56.0d);
//        int int14 = randomDataImpl0.nextZipf(26, 1.5707963267948966d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 21.925435537276492d + "'", double3 == 21.925435537276492d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-38.44155916868695d) + "'", double6 == (-38.44155916868695d));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 11L + "'", long9 == 11L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 55.512389067792256d + "'", double11 == 55.512389067792256d);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
//    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1.1061068447653153E-45d, (java.lang.Number) (byte) 10, true);
        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException3);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        java.lang.Object[] objArray6 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException("", objArray6);
        java.lang.Throwable[] throwableArray8 = convergenceException7.getSuppressed();
        java.lang.Class<?> wildcardClass9 = convergenceException7.getClass();
        java.lang.Object[] objArray17 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException("", objArray17);
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException7, "", objArray17);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException26 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 100L, (java.lang.Number) 10.000000000000002d, false);
        java.lang.Object[] objArray27 = numberIsTooSmallException26.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException28 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "", objArray27);
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException19, "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)", objArray27);
        java.lang.Object[] objArray31 = null;
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException19, "f4b78578c6457e57", objArray31);
        java.lang.String str33 = convergenceException19.getPattern();
        org.apache.commons.math.ConvergenceException convergenceException34 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException19);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "" + "'", str33.equals(""));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        double double1 = org.apache.commons.math.util.FastMath.log10(1.106025565344833d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.04376516563040503d + "'", double1 == 0.04376516563040503d);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 10.0f, (java.lang.Number) (byte) 10);
        org.apache.commons.math.exception.util.Localizable localizable5 = outOfRangeException4.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) (short) 100, (java.lang.Number) 11013.232874703393d, false);
        java.lang.Number number10 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException13 = new org.apache.commons.math.exception.OutOfRangeException(localizable5, number10, (java.lang.Number) (-0.6687796041949511d), (java.lang.Number) 2.6881171418161356E43d);
        java.lang.Number number14 = outOfRangeException13.getHi();
        java.lang.Throwable[] throwableArray15 = outOfRangeException13.getSuppressed();
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 2.6881171418161356E43d + "'", number14.equals(2.6881171418161356E43d));
        org.junit.Assert.assertNotNull(throwableArray15);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(22);
        int int2 = maxIterationsExceededException1.getMaxIterations();
        int int3 = maxIterationsExceededException1.getMaxIterations();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22 + "'", int2 == 22);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 22 + "'", int3 == 22);
    }

//    @Test
//    public void test377() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test377");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextChiSquare(0.398906612308477d);
//        randomDataImpl0.reSeed();
//        double double6 = randomDataImpl0.nextGaussian((double) (-1L), 0.04913214592285228d);
//        randomDataImpl0.reSeedSecure();
//        randomDataImpl0.reSeedSecure();
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.7844984252472659d + "'", double2 == 0.7844984252472659d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-0.9505185373283362d) + "'", double6 == (-0.9505185373283362d));
//    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        long long1 = org.apache.commons.math.util.FastMath.round(9.078837083513239d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 9L + "'", long1 == 9L);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 32, (java.lang.Number) (short) 10, (java.lang.Number) 0.398906612308477d);
        java.lang.Object[] objArray5 = outOfRangeException4.getArguments();
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException("org.apache.commons.math.exception.MathIllegalArgumentException: 10 out of [hi!, 0] range: 10 out of [hi!, 0] range", objArray5);
        org.junit.Assert.assertNotNull(objArray5);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 10.0f, (java.lang.Number) (byte) 10);
        org.apache.commons.math.exception.util.Localizable localizable5 = outOfRangeException4.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException13 = new org.apache.commons.math.exception.OutOfRangeException(localizable9, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 10.0f, (java.lang.Number) (byte) 10);
        org.apache.commons.math.exception.util.Localizable localizable14 = outOfRangeException13.getGeneralPattern();
        java.lang.Object[] objArray21 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException("", objArray21);
        java.lang.Throwable[] throwableArray23 = convergenceException22.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        java.lang.Object[] objArray31 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException("", objArray31);
        java.lang.Throwable[] throwableArray33 = convergenceException32.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException34 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException22, localizable24, (java.lang.Object[]) throwableArray33);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException35 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable14, (java.lang.Object[]) throwableArray33);
        java.lang.Object[] objArray36 = maxIterationsExceededException35.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException37 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 100, "", objArray36);
        org.apache.commons.math.MathException mathException38 = new org.apache.commons.math.MathException(localizable5, objArray36);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException42 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable5, (java.lang.Number) (-0.9999999999999999d), (java.lang.Number) 2.209173234929765d, false);
        org.apache.commons.math.exception.util.Localizable localizable43 = numberIsTooLargeException42.getSpecificPattern();
        java.lang.Object[] objArray44 = numberIsTooLargeException42.getArguments();
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable14.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(throwableArray23);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(throwableArray33);
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertTrue("'" + localizable43 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable43.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray44);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException5 = new org.apache.commons.math.exception.OutOfRangeException(localizable1, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 10.0f, (java.lang.Number) (byte) 10);
        org.apache.commons.math.exception.util.Localizable localizable6 = outOfRangeException5.getGeneralPattern();
        java.lang.Object[] objArray13 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException("", objArray13);
        java.lang.Throwable[] throwableArray15 = convergenceException14.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        java.lang.Object[] objArray23 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException("", objArray23);
        java.lang.Throwable[] throwableArray25 = convergenceException24.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException26 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException14, localizable16, (java.lang.Object[]) throwableArray25);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException27 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable6, (java.lang.Object[]) throwableArray25);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException31 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) 1.136390668384291d, (java.lang.Number) (-6.435110937730336d), false);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException35 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) 32.775300928005464d, (java.lang.Number) 97.0f, (java.lang.Number) 10.22104609692517d);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNotNull(throwableArray25);
    }

//    @Test
//    public void test382() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test382");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        randomDataImpl0.reSeedSecure((long) '4');
//        double double7 = randomDataImpl0.nextChiSquare((double) 1.0f);
//        randomDataImpl0.reSeed();
//        int int11 = randomDataImpl0.nextBinomial((int) (byte) 0, 0.40702284518531173d);
//        double double14 = randomDataImpl0.nextUniform((double) (short) 1, (double) 4);
//        try {
//            int int17 = randomDataImpl0.nextPascal(35, 1.3001647594029435d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 1.3 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 17.567031658464273d + "'", double3 == 17.567031658464273d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.10333358649648416d + "'", double7 == 0.10333358649648416d);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 3.2305045191428374d + "'", double14 == 3.2305045191428374d);
//    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(1552.6657783315172d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 88961.19609279097d + "'", double1 == 88961.19609279097d);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        double double1 = org.apache.commons.math.util.FastMath.acosh(4.9E-324d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test386() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test386");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextChiSquare(0.398906612308477d);
//        randomDataImpl0.reSeedSecure();
//        double double5 = randomDataImpl0.nextT((double) 100.0f);
//        double double7 = randomDataImpl0.nextChiSquare(0.23151936896823624d);
//        int int11 = randomDataImpl0.nextHypergeometric((int) (short) 10, 3, 1);
//        try {
//            int int14 = randomDataImpl0.nextSecureInt(22, 1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 22 is larger than, or equal to, the maximum (1): lower bound (22) must be strictly less than upper bound (1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9371328876307307d + "'", double2 == 0.9371328876307307d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-0.8960516035933156d) + "'", double5 == (-0.8960516035933156d));
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.1945151254513751E-9d + "'", double7 == 1.1945151254513751E-9d);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException3 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 100.0f);
        org.apache.commons.math.exception.util.Localizable localizable4 = notStrictlyPositiveException3.getSpecificPattern();
        java.lang.Object[] objArray12 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException("", objArray12);
        java.lang.Throwable[] throwableArray14 = convergenceException13.getSuppressed();
        java.lang.Class<?> wildcardClass15 = convergenceException13.getClass();
        java.lang.Object[] objArray23 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException("", objArray23);
        org.apache.commons.math.ConvergenceException convergenceException25 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException13, "", objArray23);
        java.lang.Object[] objArray33 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException34 = new org.apache.commons.math.ConvergenceException("", objArray33);
        java.lang.Throwable[] throwableArray35 = convergenceException34.getSuppressed();
        java.lang.Class<?> wildcardClass36 = convergenceException34.getClass();
        java.lang.Object[] objArray44 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException45 = new org.apache.commons.math.ConvergenceException("", objArray44);
        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException34, "", objArray44);
        org.apache.commons.math.ConvergenceException convergenceException47 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException13, "hi!", objArray44);
        org.apache.commons.math.ConvergenceException convergenceException48 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException3, "", objArray44);
        java.lang.String str49 = convergenceException48.getPattern();
        java.lang.Throwable[] throwableArray50 = convergenceException48.getSuppressed();
        org.apache.commons.math.MathException mathException51 = new org.apache.commons.math.MathException(throwable0, "a6a8f52cba4d7302", (java.lang.Object[]) throwableArray50);
        java.lang.String str52 = mathException51.toString();
        org.apache.commons.math.exception.util.Localizable localizable53 = mathException51.getGeneralPattern();
        org.junit.Assert.assertNull(localizable4);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertNotNull(throwableArray35);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "" + "'", str49.equals(""));
        org.junit.Assert.assertNotNull(throwableArray50);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "org.apache.commons.math.MathException: a6a8f52cba4d7302" + "'", str52.equals("org.apache.commons.math.MathException: a6a8f52cba4d7302"));
        org.junit.Assert.assertNotNull(localizable53);
    }

//    @Test
//    public void test388() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test388");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        randomDataImpl0.reSeedSecure((long) '4');
//        double double7 = randomDataImpl0.nextChiSquare((double) 1.0f);
//        double double9 = randomDataImpl0.nextChiSquare(7.659130937910243d);
//        double double12 = randomDataImpl0.nextGaussian(6.028576045602152d, 47.72559009637225d);
//        double double15 = randomDataImpl0.nextF(0.5949082827295911d, 5729.5779513082325d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 14.452744899004044d + "'", double3 == 14.452744899004044d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.19901852967211167d + "'", double7 == 0.19901852967211167d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 10.136395447003984d + "'", double9 == 10.136395447003984d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.049634007513251d + "'", double12 == 2.049634007513251d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0877641165034478E-4d + "'", double15 == 1.0877641165034478E-4d);
//    }

//    @Test
//    public void test389() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test389");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        int int6 = randomDataImpl0.nextSecureInt(0, (int) (short) 10);
//        int int9 = randomDataImpl0.nextInt(0, (int) '#');
//        double double12 = randomDataImpl0.nextBeta((double) 97.0f, 1.0E35d);
//        double double15 = randomDataImpl0.nextUniform(2.287352489659993d, (double) 22);
//        int int18 = randomDataImpl0.nextInt(8, 54);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl22 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 0, (double) '#', 0.6610060414837631d);
//        normalDistributionImpl22.reseedRandomGenerator((long) (short) 10);
//        double double26 = normalDistributionImpl22.density(0.6610060414837631d);
//        double double28 = normalDistributionImpl22.cumulativeProbability(0.0d);
//        double double29 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl22);
//        try {
//            double double31 = normalDistributionImpl22.inverseCumulativeProbability(1.6823565279386816d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 1.682 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 14.503676492898165d + "'", double3 == 14.503676492898165d);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 9 + "'", int6 == 9);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.742396831148489E-9d + "'", double12 == 1.742396831148489E-9d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 13.61233563849402d + "'", double15 == 13.61233563849402d);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 51 + "'", int18 == 51);
//        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.011396318286638113d + "'", double26 == 0.011396318286638113d);
//        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.5d + "'", double28 == 0.5d);
//        org.junit.Assert.assertTrue("'" + double29 + "' != '" + (-21.957161241601074d) + "'", double29 == (-21.957161241601074d));
//    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        long long2 = org.apache.commons.math.util.FastMath.max(52L, (long) 36);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52L + "'", long2 == 52L);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        double double2 = org.apache.commons.math.util.FastMath.atan2((-0.7853981633974483d), (double) (short) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.07837892038914972d) + "'", double2 == (-0.07837892038914972d));
    }

//    @Test
//    public void test392() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test392");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        int int6 = randomDataImpl0.nextSecureInt(0, (int) (short) 10);
//        int int9 = randomDataImpl0.nextInt(0, (int) '#');
//        double double12 = randomDataImpl0.nextBeta((double) 97.0f, 1.0E35d);
//        double double15 = randomDataImpl0.nextUniform(2.287352489659993d, (double) 22);
//        randomDataImpl0.reSeedSecure();
//        try {
//            int int19 = randomDataImpl0.nextInt((int) (byte) 1, (int) (short) -1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 1 is larger than, or equal to, the maximum (-1): lower bound (1) must be strictly less than upper bound (-1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 14.418339659290602d + "'", double3 == 14.418339659290602d);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 7 + "'", int6 == 7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 19 + "'", int9 == 19);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 14.262088640714907d + "'", double15 == 14.262088640714907d);
//    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 56.0d, (java.lang.Number) 0.9171523356672744d, true);
        java.lang.Object[] objArray10 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException("", objArray10);
        java.lang.Throwable[] throwableArray12 = convergenceException11.getSuppressed();
        java.lang.Class<?> wildcardClass13 = convergenceException11.getClass();
        java.lang.Object[] objArray21 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException("", objArray21);
        java.lang.Throwable[] throwableArray23 = convergenceException22.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        java.lang.Object[] objArray31 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException("", objArray31);
        java.lang.Throwable[] throwableArray33 = convergenceException32.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException34 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException22, localizable24, (java.lang.Object[]) throwableArray33);
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException11, "", (java.lang.Object[]) throwableArray33);
        org.apache.commons.math.exception.util.Localizable localizable36 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException40 = new org.apache.commons.math.exception.OutOfRangeException(localizable36, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 10.0f, (java.lang.Number) (byte) 10);
        org.apache.commons.math.exception.util.Localizable localizable41 = outOfRangeException40.getGeneralPattern();
        java.lang.Object[] objArray48 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException49 = new org.apache.commons.math.ConvergenceException("", objArray48);
        java.lang.Throwable[] throwableArray50 = convergenceException49.getSuppressed();
        java.lang.Class<?> wildcardClass51 = convergenceException49.getClass();
        java.lang.Object[] objArray59 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException60 = new org.apache.commons.math.ConvergenceException("", objArray59);
        java.lang.Throwable[] throwableArray61 = convergenceException60.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable62 = null;
        java.lang.Object[] objArray69 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException70 = new org.apache.commons.math.ConvergenceException("", objArray69);
        java.lang.Throwable[] throwableArray71 = convergenceException70.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException72 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException60, localizable62, (java.lang.Object[]) throwableArray71);
        org.apache.commons.math.ConvergenceException convergenceException73 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException49, "", (java.lang.Object[]) throwableArray71);
        org.apache.commons.math.MathException mathException74 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException35, localizable41, (java.lang.Object[]) throwableArray71);
        java.lang.Object[] objArray81 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException82 = new org.apache.commons.math.ConvergenceException("", objArray81);
        java.lang.Throwable[] throwableArray83 = convergenceException82.getSuppressed();
        java.lang.Class<?> wildcardClass84 = convergenceException82.getClass();
        org.apache.commons.math.exception.util.Localizable localizable85 = null;
        java.lang.Object[] objArray92 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException93 = new org.apache.commons.math.ConvergenceException("", objArray92);
        org.apache.commons.math.MathException mathException94 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException82, localizable85, objArray92);
        org.apache.commons.math.ConvergenceException convergenceException95 = new org.apache.commons.math.ConvergenceException(localizable41, objArray92);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException97 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable41, (java.lang.Number) 4.0f);
        numberIsTooLargeException3.addSuppressed((java.lang.Throwable) notStrictlyPositiveException97);
        java.lang.Number number99 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(throwableArray23);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(throwableArray33);
        org.junit.Assert.assertTrue("'" + localizable41 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable41.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray48);
        org.junit.Assert.assertNotNull(throwableArray50);
        org.junit.Assert.assertNotNull(wildcardClass51);
        org.junit.Assert.assertNotNull(objArray59);
        org.junit.Assert.assertNotNull(throwableArray61);
        org.junit.Assert.assertNotNull(objArray69);
        org.junit.Assert.assertNotNull(throwableArray71);
        org.junit.Assert.assertNotNull(objArray81);
        org.junit.Assert.assertNotNull(throwableArray83);
        org.junit.Assert.assertNotNull(wildcardClass84);
        org.junit.Assert.assertNotNull(objArray92);
        org.junit.Assert.assertTrue("'" + number99 + "' != '" + 0.9171523356672744d + "'", number99.equals(0.9171523356672744d));
    }

//    @Test
//    public void test394() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test394");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        int int6 = randomDataImpl0.nextSecureInt(0, (int) (short) 10);
//        int int9 = randomDataImpl0.nextInt(0, (int) '#');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl13 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 0, (double) '#', 0.6610060414837631d);
//        double double14 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl13);
//        java.lang.String str16 = randomDataImpl0.nextSecureHexString(9);
//        double double19 = randomDataImpl0.nextCauchy((double) 10, 0.9999999985894203d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 13.442896942419331d + "'", double3 == 13.442896942419331d);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2 + "'", int6 == 2);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 28 + "'", int9 == 28);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.833168788913026d + "'", double14 == 4.833168788913026d);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "40ef9bace" + "'", str16.equals("40ef9bace"));
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 10.16625604269485d + "'", double19 == 10.16625604269485d);
//    }

//    @Test
//    public void test395() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test395");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextChiSquare(0.398906612308477d);
//        randomDataImpl0.reSeedSecure();
//        double double5 = randomDataImpl0.nextT((double) 100.0f);
//        int int9 = randomDataImpl0.nextHypergeometric((int) '4', 36, (int) (byte) 1);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution10 = null;
//        try {
//            int int11 = randomDataImpl0.nextInversionDeviate(integerDistribution10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.4023844923197929d + "'", double2 == 0.4023844923197929d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-0.20724350737336178d) + "'", double5 == (-0.20724350737336178d));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 1L, (double) (short) 1);
        double double5 = normalDistributionImpl2.cumulativeProbability(0.0d, 0.0d);
        double double7 = normalDistributionImpl2.cumulativeProbability(10.000000000000002d);
        double double9 = normalDistributionImpl2.cumulativeProbability(2.302585092994046d);
        double double11 = normalDistributionImpl2.inverseCumulativeProbability(0.0d);
        double double12 = normalDistributionImpl2.getStandardDeviation();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.9036417751182644d + "'", double9 == 0.9036417751182644d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + Double.NEGATIVE_INFINITY + "'", double11 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.0d, 7.981279804720954d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 0, (double) '#', 0.6610060414837631d);
        normalDistributionImpl3.reseedRandomGenerator((long) (short) 10);
        double double7 = normalDistributionImpl3.density(0.6610060414837631d);
        double double8 = normalDistributionImpl3.sample();
        double double10 = normalDistributionImpl3.density((-15.238437550889657d));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.011396318286638113d + "'", double7 == 0.011396318286638113d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 30.613761382617433d + "'", double8 == 30.613761382617433d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.010367636726324828d + "'", double10 == 0.010367636726324828d);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException(number0, (java.lang.Number) 35.0d, false);
        boolean boolean4 = numberIsTooSmallException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 28);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.291502622129181d + "'", double1 == 5.291502622129181d);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 10.0f, (java.lang.Number) (byte) 10);
        org.apache.commons.math.exception.util.Localizable localizable5 = outOfRangeException4.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) (short) 100, (java.lang.Number) 11013.232874703393d, false);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException13 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable5, (java.lang.Number) 6.000400193474694d, (java.lang.Number) 1.4645918875615231d, true);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        double double2 = org.apache.commons.math.util.FastMath.max(0.0d, 5.298292365610485d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.298292365610485d + "'", double2 == 5.298292365610485d);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        double double1 = org.apache.commons.math.util.FastMath.asinh(1.0927080481029119d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9454329180680194d + "'", double1 == 0.9454329180680194d);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        double double1 = org.apache.commons.math.util.FastMath.acosh(2.468576762660578d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5529812859266974d + "'", double1 == 1.5529812859266974d);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        double double1 = org.apache.commons.math.util.FastMath.floor(8.737800111547191d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.0d + "'", double1 == 8.0d);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        double double1 = org.apache.commons.math.util.FastMath.expm1((-15.661006041484063d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9999998420529587d) + "'", double1 == (-0.9999998420529587d));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        double double2 = org.apache.commons.math.util.FastMath.min(1.1399878826998995E19d, 86.78823356954149d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 86.78823356954149d + "'", double2 == 86.78823356954149d);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 100.0f);
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable3 = notStrictlyPositiveException1.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable4 = notStrictlyPositiveException1.getSpecificPattern();
        java.lang.Object[] objArray11 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException("", objArray11);
        java.lang.Throwable[] throwableArray13 = convergenceException12.getSuppressed();
        java.lang.Class<?> wildcardClass14 = convergenceException12.getClass();
        java.lang.Object[] objArray22 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException("", objArray22);
        java.lang.Throwable[] throwableArray24 = convergenceException23.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        java.lang.Object[] objArray32 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException33 = new org.apache.commons.math.ConvergenceException("", objArray32);
        java.lang.Throwable[] throwableArray34 = convergenceException33.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException23, localizable25, (java.lang.Object[]) throwableArray34);
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException12, "", (java.lang.Object[]) throwableArray34);
        org.apache.commons.math.exception.util.Localizable localizable37 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException41 = new org.apache.commons.math.exception.OutOfRangeException(localizable37, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 10.0f, (java.lang.Number) (byte) 10);
        org.apache.commons.math.exception.util.Localizable localizable42 = outOfRangeException41.getGeneralPattern();
        java.lang.Object[] objArray49 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException50 = new org.apache.commons.math.ConvergenceException("", objArray49);
        java.lang.Throwable[] throwableArray51 = convergenceException50.getSuppressed();
        java.lang.Class<?> wildcardClass52 = convergenceException50.getClass();
        java.lang.Object[] objArray60 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException61 = new org.apache.commons.math.ConvergenceException("", objArray60);
        java.lang.Throwable[] throwableArray62 = convergenceException61.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable63 = null;
        java.lang.Object[] objArray70 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException71 = new org.apache.commons.math.ConvergenceException("", objArray70);
        java.lang.Throwable[] throwableArray72 = convergenceException71.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException73 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException61, localizable63, (java.lang.Object[]) throwableArray72);
        org.apache.commons.math.ConvergenceException convergenceException74 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException50, "", (java.lang.Object[]) throwableArray72);
        org.apache.commons.math.MathException mathException75 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException36, localizable42, (java.lang.Object[]) throwableArray72);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException79 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable42, (java.lang.Number) 100L, (java.lang.Number) 11013.232874703393d, false);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException83 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 56.0d, (java.lang.Number) 0.9171523356672744d, true);
        numberIsTooSmallException79.addSuppressed((java.lang.Throwable) numberIsTooLargeException83);
        notStrictlyPositiveException1.addSuppressed((java.lang.Throwable) numberIsTooLargeException83);
        java.lang.Object[] objArray86 = numberIsTooLargeException83.getArguments();
        org.junit.Assert.assertNull(localizable2);
        org.junit.Assert.assertNull(localizable3);
        org.junit.Assert.assertNull(localizable4);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(throwableArray24);
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(throwableArray34);
        org.junit.Assert.assertTrue("'" + localizable42 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable42.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertNotNull(throwableArray51);
        org.junit.Assert.assertNotNull(wildcardClass52);
        org.junit.Assert.assertNotNull(objArray60);
        org.junit.Assert.assertNotNull(throwableArray62);
        org.junit.Assert.assertNotNull(objArray70);
        org.junit.Assert.assertNotNull(throwableArray72);
        org.junit.Assert.assertNotNull(objArray86);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        double double1 = org.apache.commons.math.util.FastMath.asin(6.952624968924705d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 10.0f, (java.lang.Number) (byte) 10);
        org.apache.commons.math.exception.util.Localizable localizable5 = outOfRangeException4.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) (short) 100, (java.lang.Number) 11013.232874703393d, false);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException13 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) 8.737800111547191d, (java.lang.Number) 8.737800111547191d, false);
        java.lang.Object[] objArray14 = null;
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException(localizable5, objArray14);
        java.lang.Throwable[] throwableArray16 = convergenceException15.getSuppressed();
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(throwableArray16);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        java.lang.Object[] objArray6 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException("", objArray6);
        java.lang.Throwable[] throwableArray8 = convergenceException7.getSuppressed();
        java.lang.Class<?> wildcardClass9 = convergenceException7.getClass();
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException("", objArray17);
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException7, localizable10, objArray17);
        org.apache.commons.math.exception.util.Localizable localizable20 = mathException19.getGeneralPattern();
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNull(localizable20);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(1.181963266712225d, 3.175169392061453d);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.8277492790706d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7364105463092888d + "'", double1 == 0.7364105463092888d);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(Double.NaN, 590.7909222259701d, 0.9790456794612402d, 29);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        double double1 = org.apache.commons.math.util.FastMath.cos(3.40081118778545E-4d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999999421724168d + "'", double1 == 0.9999999421724168d);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 0, (double) '#', 0.6610060414837631d);
        normalDistributionImpl3.reseedRandomGenerator((long) (short) 0);
        double[] doubleArray7 = normalDistributionImpl3.sample(13);
        double double9 = normalDistributionImpl3.density(0.5210953054937474d);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.011397087627673917d + "'", double9 == 0.011397087627673917d);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        java.lang.Object[] objArray7 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException("", objArray7);
        java.lang.Throwable[] throwableArray9 = convergenceException8.getSuppressed();
        java.lang.Class<?> wildcardClass10 = convergenceException8.getClass();
        java.lang.Object[] objArray18 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException("", objArray18);
        java.lang.Throwable[] throwableArray20 = convergenceException19.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable21 = null;
        java.lang.Object[] objArray28 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException("", objArray28);
        java.lang.Throwable[] throwableArray30 = convergenceException29.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException19, localizable21, (java.lang.Object[]) throwableArray30);
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException8, "", (java.lang.Object[]) throwableArray30);
        java.lang.Object[] objArray33 = convergenceException32.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable34 = convergenceException32.getSpecificPattern();
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException32);
        org.apache.commons.math.exception.util.Localizable localizable36 = convergenceException32.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable37 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException41 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable37, (java.lang.Number) 10.0f, (java.lang.Number) 2.718281828459045d, false);
        java.lang.Number number42 = numberIsTooSmallException41.getMin();
        java.lang.Object[] objArray50 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException51 = new org.apache.commons.math.ConvergenceException("", objArray50);
        java.lang.Throwable[] throwableArray52 = convergenceException51.getSuppressed();
        org.apache.commons.math.MathException mathException53 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException41, "hi!", (java.lang.Object[]) throwableArray52);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException54 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable36, (java.lang.Object[]) throwableArray52);
        java.lang.Object[] objArray55 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException56 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable36, objArray55);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(throwableArray20);
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertNotNull(throwableArray30);
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertNull(localizable34);
        org.junit.Assert.assertNotNull(localizable36);
        org.junit.Assert.assertTrue("'" + number42 + "' != '" + 2.718281828459045d + "'", number42.equals(2.718281828459045d));
        org.junit.Assert.assertNotNull(objArray50);
        org.junit.Assert.assertNotNull(throwableArray52);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        double double1 = org.apache.commons.math.util.FastMath.sin(10.867834325268122d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9918523391812248d) + "'", double1 == (-0.9918523391812248d));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        java.lang.Object[] objArray7 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException("", objArray7);
        java.lang.Throwable[] throwableArray9 = convergenceException8.getSuppressed();
        java.lang.Class<?> wildcardClass10 = convergenceException8.getClass();
        java.lang.Object[] objArray18 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException("", objArray18);
        java.lang.Throwable[] throwableArray20 = convergenceException19.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable21 = null;
        java.lang.Object[] objArray28 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException("", objArray28);
        java.lang.Throwable[] throwableArray30 = convergenceException29.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException19, localizable21, (java.lang.Object[]) throwableArray30);
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException8, "", (java.lang.Object[]) throwableArray30);
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException37 = new org.apache.commons.math.exception.OutOfRangeException(localizable33, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 10.0f, (java.lang.Number) (byte) 10);
        org.apache.commons.math.exception.util.Localizable localizable38 = outOfRangeException37.getGeneralPattern();
        java.lang.Object[] objArray45 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException("", objArray45);
        java.lang.Throwable[] throwableArray47 = convergenceException46.getSuppressed();
        java.lang.Class<?> wildcardClass48 = convergenceException46.getClass();
        java.lang.Object[] objArray56 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException57 = new org.apache.commons.math.ConvergenceException("", objArray56);
        java.lang.Throwable[] throwableArray58 = convergenceException57.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable59 = null;
        java.lang.Object[] objArray66 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException67 = new org.apache.commons.math.ConvergenceException("", objArray66);
        java.lang.Throwable[] throwableArray68 = convergenceException67.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException69 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException57, localizable59, (java.lang.Object[]) throwableArray68);
        org.apache.commons.math.ConvergenceException convergenceException70 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException46, "", (java.lang.Object[]) throwableArray68);
        org.apache.commons.math.MathException mathException71 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException32, localizable38, (java.lang.Object[]) throwableArray68);
        java.lang.Object[] objArray78 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException79 = new org.apache.commons.math.ConvergenceException("", objArray78);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException80 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable38, objArray78);
        org.apache.commons.math.exception.util.Localizable localizable81 = maxIterationsExceededException80.getGeneralPattern();
        int int82 = maxIterationsExceededException80.getMaxIterations();
        org.apache.commons.math.exception.util.Localizable localizable83 = maxIterationsExceededException80.getSpecificPattern();
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(throwableArray20);
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertNotNull(throwableArray30);
        org.junit.Assert.assertTrue("'" + localizable38 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable38.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray45);
        org.junit.Assert.assertNotNull(throwableArray47);
        org.junit.Assert.assertNotNull(wildcardClass48);
        org.junit.Assert.assertNotNull(objArray56);
        org.junit.Assert.assertNotNull(throwableArray58);
        org.junit.Assert.assertNotNull(objArray66);
        org.junit.Assert.assertNotNull(throwableArray68);
        org.junit.Assert.assertNotNull(objArray78);
        org.junit.Assert.assertTrue("'" + localizable81 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable81.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 0 + "'", int82 == 0);
        org.junit.Assert.assertNull(localizable83);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        java.lang.Object[] objArray7 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException("", objArray7);
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException("", objArray7);
        org.apache.commons.math.exception.util.Localizable localizable10 = convergenceException9.getSpecificPattern();
        java.lang.Object[] objArray11 = convergenceException9.getArguments();
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNull(localizable10);
        org.junit.Assert.assertNotNull(objArray11);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(10.041205904090312d, 1.1399878826998995E19d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.041205904090313d + "'", double2 == 10.041205904090313d);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 10, 56.0d);
        double[] doubleArray4 = normalDistributionImpl2.sample(97);
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        int int2 = org.apache.commons.math.util.FastMath.min(10, 35);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.9790456794612402d, 0.0d, 0.04913214592285228d, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        double double1 = org.apache.commons.math.special.Gamma.logGamma((double) 9L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.60460290274525d + "'", double1 == 10.60460290274525d);
    }

//    @Test
//    public void test427() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test427");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextChiSquare(0.398906612308477d);
//        randomDataImpl0.reSeedSecure();
//        double double5 = randomDataImpl0.nextT((double) 100.0f);
//        double double8 = randomDataImpl0.nextCauchy(22.54454093470796d, (double) 30L);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.3963055722224557d + "'", double2 == 0.3963055722224557d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-0.2636694928820048d) + "'", double5 == (-0.2636694928820048d));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 29.852356251827985d + "'", double8 == 29.852356251827985d);
//    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        double double2 = org.apache.commons.math.util.FastMath.atan2(1.9646397077969224E-9d, 1.136390668384291d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.7288418168641139E-9d + "'", double2 == 1.7288418168641139E-9d);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(0);
        java.lang.Throwable[] throwableArray2 = maxIterationsExceededException1.getSuppressed();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException4 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1);
        maxIterationsExceededException1.addSuppressed((java.lang.Throwable) maxIterationsExceededException4);
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.8357736605195625d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        java.lang.Object[] objArray6 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException("", objArray6);
        java.lang.Throwable[] throwableArray8 = convergenceException7.getSuppressed();
        java.lang.Class<?> wildcardClass9 = convergenceException7.getClass();
        java.lang.Object[] objArray17 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException("", objArray17);
        java.lang.Throwable[] throwableArray19 = convergenceException18.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException("", objArray27);
        java.lang.Throwable[] throwableArray29 = convergenceException28.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException18, localizable20, (java.lang.Object[]) throwableArray29);
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException7, "", (java.lang.Object[]) throwableArray29);
        org.apache.commons.math.exception.util.Localizable localizable32 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException36 = new org.apache.commons.math.exception.OutOfRangeException(localizable32, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 10.0f, (java.lang.Number) (byte) 10);
        org.apache.commons.math.exception.util.Localizable localizable37 = outOfRangeException36.getGeneralPattern();
        java.lang.Object[] objArray44 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException45 = new org.apache.commons.math.ConvergenceException("", objArray44);
        java.lang.Throwable[] throwableArray46 = convergenceException45.getSuppressed();
        java.lang.Class<?> wildcardClass47 = convergenceException45.getClass();
        java.lang.Object[] objArray55 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException56 = new org.apache.commons.math.ConvergenceException("", objArray55);
        java.lang.Throwable[] throwableArray57 = convergenceException56.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable58 = null;
        java.lang.Object[] objArray65 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException66 = new org.apache.commons.math.ConvergenceException("", objArray65);
        java.lang.Throwable[] throwableArray67 = convergenceException66.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException68 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException56, localizable58, (java.lang.Object[]) throwableArray67);
        org.apache.commons.math.ConvergenceException convergenceException69 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException45, "", (java.lang.Object[]) throwableArray67);
        org.apache.commons.math.MathException mathException70 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException31, localizable37, (java.lang.Object[]) throwableArray67);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException74 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable37, (java.lang.Number) 100L, (java.lang.Number) 11013.232874703393d, false);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException78 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 56.0d, (java.lang.Number) 0.9171523356672744d, true);
        numberIsTooSmallException74.addSuppressed((java.lang.Throwable) numberIsTooLargeException78);
        java.lang.Throwable[] throwableArray80 = numberIsTooLargeException78.getSuppressed();
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(throwableArray29);
        org.junit.Assert.assertTrue("'" + localizable37 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable37.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertNotNull(throwableArray46);
        org.junit.Assert.assertNotNull(wildcardClass47);
        org.junit.Assert.assertNotNull(objArray55);
        org.junit.Assert.assertNotNull(throwableArray57);
        org.junit.Assert.assertNotNull(objArray65);
        org.junit.Assert.assertNotNull(throwableArray67);
        org.junit.Assert.assertNotNull(throwableArray80);
    }

//    @Test
//    public void test432() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test432");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        randomDataImpl0.reSeedSecure((long) '4');
//        double double7 = randomDataImpl0.nextChiSquare((double) 1.0f);
//        randomDataImpl0.reSeed();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl12 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) (short) 1, 3.141592653589793d);
//        double double13 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl12);
//        java.lang.String str15 = randomDataImpl0.nextSecureHexString(100);
//        java.lang.String str17 = randomDataImpl0.nextSecureHexString((int) (byte) 10);
//        int int20 = randomDataImpl0.nextInt((int) (byte) -1, (int) (byte) 100);
//        double double23 = randomDataImpl0.nextCauchy(3.482265822014589d, 354.7577630510578d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 11.014962636859122d + "'", double3 == 11.014962636859122d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.02862464963550398d + "'", double7 == 0.02862464963550398d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2c0c13647c826f6b2f17802b14358ac83d960847327c2cc174b974f5669c5eb8e363eaf32b60982debfe1fbebf8cce624bda" + "'", str15.equals("2c0c13647c826f6b2f17802b14358ac83d960847327c2cc174b974f5669c5eb8e363eaf32b60982debfe1fbebf8cce624bda"));
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "dfd0c34e1a" + "'", str17.equals("dfd0c34e1a"));
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 99 + "'", int20 == 99);
//        org.junit.Assert.assertTrue("'" + double23 + "' != '" + (-674.6124764052208d) + "'", double23 == (-674.6124764052208d));
//    }

//    @Test
//    public void test433() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test433");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        double double6 = randomDataImpl0.nextCauchy(1.6704649792860586d, 86.78823356954149d);
//        long long9 = randomDataImpl0.nextLong((long) 1, (long) 16);
//        double double11 = randomDataImpl0.nextChiSquare(56.0d);
//        double double14 = randomDataImpl0.nextGaussian(8.928976450870955d, 11013.232874703393d);
//        randomDataImpl0.reSeed(67L);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 11.02571387304307d + "'", double3 == 11.02571387304307d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-75.15285460616228d) + "'", double6 == (-75.15285460616228d));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 54.43453614813563d + "'", double11 == 54.43453614813563d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-153.11673085462516d) + "'", double14 == (-153.11673085462516d));
//    }

//    @Test
//    public void test434() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test434");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        randomDataImpl0.reSeedSecure((long) '4');
//        double double7 = randomDataImpl0.nextChiSquare((double) 1.0f);
//        randomDataImpl0.reSeed();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl12 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) (short) 1, 3.141592653589793d);
//        double double13 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl12);
//        try {
//            double double16 = randomDataImpl0.nextF(0.0d, 14.270047164198795d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): degrees of freedom (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.987691922029374d + "'", double3 == 10.987691922029374d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.4382864462089144d + "'", double7 == 2.4382864462089144d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
//    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1);
        int int2 = maxIterationsExceededException1.getMaxIterations();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException6 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 56.0d, (java.lang.Number) 0.9171523356672744d, true);
        maxIterationsExceededException1.addSuppressed((java.lang.Throwable) numberIsTooLargeException6);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

//    @Test
//    public void test436() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test436");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        randomDataImpl0.reSeedSecure((long) '4');
//        double double7 = randomDataImpl0.nextChiSquare((double) 1.0f);
//        randomDataImpl0.reSeed();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl12 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) (short) 1, 3.141592653589793d);
//        double double13 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl12);
//        randomDataImpl0.reSeed();
//        double double17 = randomDataImpl0.nextBeta(0.0140436016105168d, 1.0d);
//        double double20 = randomDataImpl0.nextCauchy(4.605170185988093d, 44.57328158058611d);
//        java.lang.String str22 = randomDataImpl0.nextHexString(7);
//        randomDataImpl0.reSeedSecure(71L);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.989635158147054d + "'", double3 == 10.989635158147054d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.5520179931425976d + "'", double7 == 0.5520179931425976d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.1236430481874825E-9d + "'", double17 == 1.1236430481874825E-9d);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + (-412.68068650505165d) + "'", double20 == (-412.68068650505165d));
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "4fceb5e" + "'", str22.equals("4fceb5e"));
//    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 100.0f);
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable3 = notStrictlyPositiveException1.getSpecificPattern();
        java.lang.Number number4 = notStrictlyPositiveException1.getArgument();
        boolean boolean5 = notStrictlyPositiveException1.getBoundIsAllowed();
        java.lang.Object[] objArray13 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException("", objArray13);
        java.lang.Throwable[] throwableArray15 = convergenceException14.getSuppressed();
        java.lang.Class<?> wildcardClass16 = convergenceException14.getClass();
        java.lang.Object[] objArray24 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException25 = new org.apache.commons.math.ConvergenceException("", objArray24);
        java.lang.Throwable[] throwableArray26 = convergenceException25.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable27 = null;
        java.lang.Object[] objArray34 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException("", objArray34);
        java.lang.Throwable[] throwableArray36 = convergenceException35.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException37 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException25, localizable27, (java.lang.Object[]) throwableArray36);
        org.apache.commons.math.ConvergenceException convergenceException38 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException14, "", (java.lang.Object[]) throwableArray36);
        org.apache.commons.math.exception.util.Localizable localizable39 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException43 = new org.apache.commons.math.exception.OutOfRangeException(localizable39, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 10.0f, (java.lang.Number) (byte) 10);
        org.apache.commons.math.exception.util.Localizable localizable44 = outOfRangeException43.getGeneralPattern();
        java.lang.Object[] objArray51 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException52 = new org.apache.commons.math.ConvergenceException("", objArray51);
        java.lang.Throwable[] throwableArray53 = convergenceException52.getSuppressed();
        java.lang.Class<?> wildcardClass54 = convergenceException52.getClass();
        java.lang.Object[] objArray62 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException63 = new org.apache.commons.math.ConvergenceException("", objArray62);
        java.lang.Throwable[] throwableArray64 = convergenceException63.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable65 = null;
        java.lang.Object[] objArray72 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException73 = new org.apache.commons.math.ConvergenceException("", objArray72);
        java.lang.Throwable[] throwableArray74 = convergenceException73.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException75 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException63, localizable65, (java.lang.Object[]) throwableArray74);
        org.apache.commons.math.ConvergenceException convergenceException76 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException52, "", (java.lang.Object[]) throwableArray74);
        org.apache.commons.math.MathException mathException77 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException38, localizable44, (java.lang.Object[]) throwableArray74);
        java.lang.Object[] objArray84 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException85 = new org.apache.commons.math.ConvergenceException("", objArray84);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException86 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable44, objArray84);
        org.apache.commons.math.exception.util.Localizable localizable87 = maxIterationsExceededException86.getGeneralPattern();
        notStrictlyPositiveException1.addSuppressed((java.lang.Throwable) maxIterationsExceededException86);
        org.junit.Assert.assertNull(localizable2);
        org.junit.Assert.assertNull(localizable3);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 100.0f + "'", number4.equals(100.0f));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(throwableArray26);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(throwableArray36);
        org.junit.Assert.assertTrue("'" + localizable44 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable44.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray51);
        org.junit.Assert.assertNotNull(throwableArray53);
        org.junit.Assert.assertNotNull(wildcardClass54);
        org.junit.Assert.assertNotNull(objArray62);
        org.junit.Assert.assertNotNull(throwableArray64);
        org.junit.Assert.assertNotNull(objArray72);
        org.junit.Assert.assertNotNull(throwableArray74);
        org.junit.Assert.assertNotNull(objArray84);
        org.junit.Assert.assertTrue("'" + localizable87 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable87.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        double double1 = org.apache.commons.math.util.FastMath.ceil(1.0877641165034478E-4d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        double double2 = org.apache.commons.math.util.FastMath.pow(29.852356251827985d, 14.03874848995977d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.091594570728693E20d + "'", double2 == 5.091594570728693E20d);
    }

//    @Test
//    public void test440() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test440");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        double double6 = randomDataImpl0.nextCauchy(1.6704649792860586d, 86.78823356954149d);
//        long long9 = randomDataImpl0.nextLong((long) 1, (long) 16);
//        int int12 = randomDataImpl0.nextPascal(5, 0.0d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.228831667781666d + "'", double3 == 10.228831667781666d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 25.75832187728846d + "'", double6 == 25.75832187728846d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 4L + "'", long9 == 4L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2147483647 + "'", int12 == 2147483647);
//    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        double double1 = org.apache.commons.math.util.FastMath.atanh(1.9502958802207327E-4d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.950295904948236E-4d + "'", double1 == 1.950295904948236E-4d);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        double double1 = org.apache.commons.math.util.FastMath.rint(8.941144909753433d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.0d + "'", double1 == 9.0d);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0.9866275920404853d, (java.lang.Number) 0.61875315207275d, false);
        java.lang.Number number4 = numberIsTooLargeException3.getMax();
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooLargeException3.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.61875315207275d + "'", number4.equals(0.61875315207275d));
        org.junit.Assert.assertNull(localizable5);
    }

//    @Test
//    public void test444() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test444");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextChiSquare(0.398906612308477d);
//        randomDataImpl0.reSeed();
//        double double6 = randomDataImpl0.nextGaussian((double) (-1L), 0.04913214592285228d);
//        double double8 = randomDataImpl0.nextT(3.141592653589793d);
//        long long11 = randomDataImpl0.nextLong((long) ' ', 100L);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.04862494506650378d + "'", double2 == 0.04862494506650378d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-0.9959297325684614d) + "'", double6 == (-0.9959297325684614d));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-0.7347331991875249d) + "'", double8 == (-0.7347331991875249d));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 93L + "'", long11 == 93L);
//    }

//    @Test
//    public void test445() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test445");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        randomDataImpl0.reSeedSecure((long) '4');
//        double double7 = randomDataImpl0.nextChiSquare((double) 1.0f);
//        try {
//            int int10 = randomDataImpl0.nextInt(2, 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 2 is larger than, or equal to, the maximum (0): lower bound (2) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.173789027901655d + "'", double3 == 10.173789027901655d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.01514040028203978d + "'", double7 == 0.01514040028203978d);
//    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 32, (java.lang.Number) Double.NaN, false);
        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException3);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException5 = new org.apache.commons.math.exception.OutOfRangeException(localizable1, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 10.0f, (java.lang.Number) (byte) 10);
        org.apache.commons.math.exception.util.Localizable localizable6 = outOfRangeException5.getGeneralPattern();
        java.lang.Object[] objArray13 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException("", objArray13);
        java.lang.Throwable[] throwableArray15 = convergenceException14.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        java.lang.Object[] objArray23 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException("", objArray23);
        java.lang.Throwable[] throwableArray25 = convergenceException24.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException26 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException14, localizable16, (java.lang.Object[]) throwableArray25);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException27 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable6, (java.lang.Object[]) throwableArray25);
        org.apache.commons.math.exception.util.Localizable localizable28 = maxIterationsExceededException27.getSpecificPattern();
        int int29 = maxIterationsExceededException27.getMaxIterations();
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNotNull(throwableArray25);
        org.junit.Assert.assertNull(localizable28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.791630772658661d, (java.lang.Number) 0.01694013920788123d, (java.lang.Number) 2147483647);
        java.lang.Number number4 = outOfRangeException3.getHi();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 2147483647 + "'", number4.equals(2147483647));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 10.0f, (java.lang.Number) 2.718281828459045d, false);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException10 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable6, (java.lang.Number) 10.0f, (java.lang.Number) 2.718281828459045d, false);
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooSmallException10.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = numberIsTooSmallException10.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException10);
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException18 = new org.apache.commons.math.exception.OutOfRangeException(localizable14, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 10.0f, (java.lang.Number) (byte) 10);
        org.apache.commons.math.exception.util.Localizable localizable19 = outOfRangeException18.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException23 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable19, (java.lang.Number) (short) 100, (java.lang.Number) 11013.232874703393d, false);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException27 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable19, (java.lang.Number) 8.737800111547191d, (java.lang.Number) 8.737800111547191d, false);
        org.apache.commons.math.exception.util.Localizable localizable28 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException32 = new org.apache.commons.math.exception.OutOfRangeException(localizable28, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 10.0f, (java.lang.Number) (byte) 10);
        org.apache.commons.math.exception.util.Localizable localizable33 = outOfRangeException32.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable34 = outOfRangeException32.getGeneralPattern();
        java.lang.Object[] objArray41 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException("", objArray41);
        java.lang.Throwable[] throwableArray43 = convergenceException42.getSuppressed();
        java.lang.Class<?> wildcardClass44 = convergenceException42.getClass();
        org.apache.commons.math.exception.util.Localizable localizable45 = null;
        java.lang.Object[] objArray52 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException53 = new org.apache.commons.math.ConvergenceException("", objArray52);
        org.apache.commons.math.MathException mathException54 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException42, localizable45, objArray52);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException55 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable19, localizable34, objArray52);
        java.lang.String str56 = mathIllegalArgumentException55.toString();
        org.apache.commons.math.exception.util.Localizable localizable57 = mathIllegalArgumentException55.getSpecificPattern();
        java.lang.Object[] objArray64 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException65 = new org.apache.commons.math.ConvergenceException("", objArray64);
        org.apache.commons.math.ConvergenceException convergenceException66 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException13, localizable57, objArray64);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException67 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, objArray64);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable19.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable33 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable33.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable34 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable34.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray41);
        org.junit.Assert.assertNotNull(throwableArray43);
        org.junit.Assert.assertNotNull(wildcardClass44);
        org.junit.Assert.assertNotNull(objArray52);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "org.apache.commons.math.exception.MathIllegalArgumentException: 10 out of [hi!, 0] range: 10 out of [hi!, 0] range" + "'", str56.equals("org.apache.commons.math.exception.MathIllegalArgumentException: 10 out of [hi!, 0] range: 10 out of [hi!, 0] range"));
        org.junit.Assert.assertTrue("'" + localizable57 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable57.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray64);
    }

//    @Test
//    public void test450() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test450");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        randomDataImpl0.reSeedSecure((long) 'a');
//        double double8 = randomDataImpl0.nextF(1.5860134523134308E15d, 0.01694013920788123d);
//        try {
//            double double11 = randomDataImpl0.nextGaussian(71.0282811537272d, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): standard deviation (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 9.728218414426262d + "'", double3 == 9.728218414426262d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.1774732593647872d + "'", double8 == 0.1774732593647872d);
//    }

//    @Test
//    public void test451() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test451");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        randomDataImpl0.reSeedSecure((long) '4');
//        double double7 = randomDataImpl0.nextChiSquare((double) 1.0f);
//        randomDataImpl0.reSeed();
//        int int11 = randomDataImpl0.nextPascal(2, 1.9746370780062322E-24d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl15 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 0, (double) '#', 0.6610060414837631d);
//        normalDistributionImpl15.reseedRandomGenerator((long) (short) 10);
//        double double19 = normalDistributionImpl15.density(0.6610060414837631d);
//        double double20 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl15);
//        java.lang.String str22 = randomDataImpl0.nextSecureHexString(2);
//        double double25 = randomDataImpl0.nextCauchy(0.762775077962d, 0.4962187457749329d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 9.751363770594978d + "'", double3 == 9.751363770594978d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.744424846767693d + "'", double7 == 4.744424846767693d);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2147483647 + "'", int11 == 2147483647);
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.011396318286638113d + "'", double19 == 0.011396318286638113d);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 66.33899395851489d + "'", double20 == 66.33899395851489d);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "3e" + "'", str22.equals("3e"));
//        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.8996228651797273d + "'", double25 == 0.8996228651797273d);
//    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.6339865993972527d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5607911911089808d + "'", double1 == 0.5607911911089808d);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 0, (double) '#', 0.6610060414837631d);
        normalDistributionImpl3.reseedRandomGenerator((long) (short) 0);
        double double7 = normalDistributionImpl3.cumulativeProbability(78.0922235533153d);
        normalDistributionImpl3.reseedRandomGenerator((long) 33);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.9871662694571679d + "'", double7 == 0.9871662694571679d);
    }

//    @Test
//    public void test454() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test454");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        int int6 = randomDataImpl0.nextSecureInt(0, (int) (short) 10);
//        int int9 = randomDataImpl0.nextInt(0, (int) '#');
//        double double12 = randomDataImpl0.nextBeta((double) 97.0f, 1.0E35d);
//        double double15 = randomDataImpl0.nextUniform(2.287352489659993d, (double) 22);
//        randomDataImpl0.reSeedSecure();
//        double double19 = randomDataImpl0.nextGaussian(0.011397087627673917d, (double) 54L);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 9.71841761659624d + "'", double3 == 9.71841761659624d);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 3 + "'", int6 == 3);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 8 + "'", int9 == 8);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.2790026949617985E-9d + "'", double12 == 1.2790026949617985E-9d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 5.5726106048401665d + "'", double15 == 5.5726106048401665d);
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 39.1599940575273d + "'", double19 == 39.1599940575273d);
//    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 51L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 51 + "'", int1 == 51);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 10.0f, (java.lang.Number) (byte) 10);
        org.apache.commons.math.exception.util.Localizable localizable5 = outOfRangeException4.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException13 = new org.apache.commons.math.exception.OutOfRangeException(localizable9, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 10.0f, (java.lang.Number) (byte) 10);
        org.apache.commons.math.exception.util.Localizable localizable14 = outOfRangeException13.getGeneralPattern();
        java.lang.Object[] objArray21 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException("", objArray21);
        java.lang.Throwable[] throwableArray23 = convergenceException22.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        java.lang.Object[] objArray31 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException("", objArray31);
        java.lang.Throwable[] throwableArray33 = convergenceException32.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException34 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException22, localizable24, (java.lang.Object[]) throwableArray33);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException35 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable14, (java.lang.Object[]) throwableArray33);
        java.lang.Object[] objArray36 = maxIterationsExceededException35.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException37 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 100, "", objArray36);
        org.apache.commons.math.MathException mathException38 = new org.apache.commons.math.MathException(localizable5, objArray36);
        java.lang.Class<?> wildcardClass39 = localizable5.getClass();
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable14.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(throwableArray23);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(throwableArray33);
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertNotNull(wildcardClass39);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        java.lang.Object[] objArray6 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException("", objArray6);
        java.lang.Throwable[] throwableArray8 = convergenceException7.getSuppressed();
        java.lang.Class<?> wildcardClass9 = convergenceException7.getClass();
        java.lang.Object[] objArray17 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException("", objArray17);
        java.lang.Throwable[] throwableArray19 = convergenceException18.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException("", objArray27);
        java.lang.Throwable[] throwableArray29 = convergenceException28.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException18, localizable20, (java.lang.Object[]) throwableArray29);
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException7, "", (java.lang.Object[]) throwableArray29);
        org.apache.commons.math.exception.util.Localizable localizable32 = convergenceException31.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException34 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable32, (java.lang.Number) 2.718281828459045d);
        java.lang.Object[] objArray35 = notStrictlyPositiveException34.getArguments();
        boolean boolean36 = notStrictlyPositiveException34.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable37 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException41 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable37, (java.lang.Number) 10.0f, (java.lang.Number) 2.718281828459045d, false);
        java.lang.Number number42 = numberIsTooSmallException41.getMin();
        org.apache.commons.math.exception.util.Localizable localizable43 = numberIsTooSmallException41.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException45 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable43, (java.lang.Number) 11.465100751341446d);
        java.lang.Object[] objArray52 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException53 = new org.apache.commons.math.ConvergenceException("", objArray52);
        java.lang.Throwable[] throwableArray54 = convergenceException53.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable55 = null;
        java.lang.Object[] objArray62 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException63 = new org.apache.commons.math.ConvergenceException("", objArray62);
        java.lang.Throwable[] throwableArray64 = convergenceException63.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException65 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException53, localizable55, (java.lang.Object[]) throwableArray64);
        org.apache.commons.math.MathException mathException66 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException34, localizable43, (java.lang.Object[]) throwableArray64);
        java.lang.String str67 = mathException66.toString();
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(throwableArray29);
        org.junit.Assert.assertNotNull(localizable32);
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + number42 + "' != '" + 2.718281828459045d + "'", number42.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable43 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable43.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray52);
        org.junit.Assert.assertNotNull(throwableArray54);
        org.junit.Assert.assertNotNull(objArray62);
        org.junit.Assert.assertNotNull(throwableArray64);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "org.apache.commons.math.MathException: {0} is smaller than, or equal to, the minimum ({1})" + "'", str67.equals("org.apache.commons.math.MathException: {0} is smaller than, or equal to, the minimum ({1})"));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        double double1 = org.apache.commons.math.util.FastMath.atanh(3.6637527079352568d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 15, (long) 6);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 6L + "'", long2 == 6L);
    }

//    @Test
//    public void test460() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test460");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        int int6 = randomDataImpl0.nextSecureInt(0, (int) (short) 10);
//        int int9 = randomDataImpl0.nextInt(0, (int) '#');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl13 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 0, (double) '#', 0.6610060414837631d);
//        double double14 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl13);
//        java.lang.String str16 = randomDataImpl0.nextSecureHexString(9);
//        double double19 = randomDataImpl0.nextGaussian(8.995696864925984d, 8.941144909753433d);
//        double double22 = randomDataImpl0.nextUniform((-0.04229861514908033d), 0.9036417751182644d);
//        try {
//            randomDataImpl0.setSecureAlgorithm("80639cb324", "105c41ce9");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: 105c41ce9");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 14.20701625667394d + "'", double3 == 14.20701625667394d);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 17 + "'", int9 == 17);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-28.0d) + "'", double14 == (-28.0d));
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "565e19bb2" + "'", str16.equals("565e19bb2"));
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-8.498987859328194d) + "'", double19 == (-8.498987859328194d));
//        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.29554714020557155d + "'", double22 == 0.29554714020557155d);
//    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        java.lang.Object[] objArray6 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException("", objArray6);
        java.lang.Throwable[] throwableArray8 = convergenceException7.getSuppressed();
        java.lang.Class<?> wildcardClass9 = convergenceException7.getClass();
        java.lang.Object[] objArray17 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException("", objArray17);
        java.lang.Throwable[] throwableArray19 = convergenceException18.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException("", objArray27);
        java.lang.Throwable[] throwableArray29 = convergenceException28.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException18, localizable20, (java.lang.Object[]) throwableArray29);
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException7, "", (java.lang.Object[]) throwableArray29);
        java.lang.String str32 = convergenceException7.getPattern();
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(throwableArray29);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "" + "'", str32.equals(""));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) '4');
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(100.0d, (double) (byte) 10);
        double double4 = normalDistributionImpl2.density(0.0d);
        double double5 = normalDistributionImpl2.getMean();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 7.694598626706421E-24d + "'", double4 == 7.694598626706421E-24d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        double double2 = org.apache.commons.math.util.FastMath.max(2.9286017816744514d, 13.82821341364453d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 13.82821341364453d + "'", double2 == 13.82821341364453d);
    }

//    @Test
//    public void test465() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test465");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextChiSquare(0.398906612308477d);
//        randomDataImpl0.reSeedSecure();
//        double double5 = randomDataImpl0.nextT((double) 100.0f);
//        double double7 = randomDataImpl0.nextChiSquare(0.23151936896823624d);
//        try {
//            double double10 = randomDataImpl0.nextUniform(0.2976969260033571d, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 0.298 is larger than, or equal to, the maximum (0): lower bound (0.298) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2773279298706594d + "'", double2 == 0.2773279298706594d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.9472994169405061d + "'", double5 == 0.9472994169405061d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.19124141416121998d + "'", double7 == 0.19124141416121998d);
//    }

//    @Test
//    public void test466() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test466");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        int int6 = randomDataImpl0.nextSecureInt(0, (int) (short) 10);
//        int int9 = randomDataImpl0.nextInt(0, (int) '#');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl13 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 0, (double) '#', 0.6610060414837631d);
//        double double14 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl13);
//        java.lang.String str16 = randomDataImpl0.nextSecureHexString((int) 'a');
//        long long18 = randomDataImpl0.nextPoisson((double) 34);
//        double double20 = randomDataImpl0.nextExponential(1.2878315793230852d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 12.510090541544734d + "'", double3 == 12.510090541544734d);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 7 + "'", int6 == 7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-2.7728748896265465d) + "'", double14 == (-2.7728748896265465d));
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "d7b37d236aeb1b0d3bd4b6b3fdc127426870ddd67435e5cf5c96291a9d641dda76ce577c4eeadce5c37207cff87d66fab" + "'", str16.equals("d7b37d236aeb1b0d3bd4b6b3fdc127426870ddd67435e5cf5c96291a9d641dda76ce577c4eeadce5c37207cff87d66fab"));
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 32L + "'", long18 == 32L);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 3.775406523803087d + "'", double20 == 3.775406523803087d);
//    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.5949082827295911d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        double double1 = org.apache.commons.math.util.FastMath.log1p(10.041205904090312d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.401634265326702d + "'", double1 == 2.401634265326702d);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        int int2 = org.apache.commons.math.util.FastMath.min(22, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        int int2 = org.apache.commons.math.util.FastMath.min((int) '#', 30);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 30 + "'", int2 == 30);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        double double1 = org.apache.commons.math.special.Erf.erf((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

//    @Test
//    public void test472() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test472");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        randomDataImpl0.reSeedSecure((long) '4');
//        double double7 = randomDataImpl0.nextChiSquare((double) 1.0f);
//        randomDataImpl0.reSeed();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl12 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) (short) 1, 3.141592653589793d);
//        double double13 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl12);
//        double double15 = normalDistributionImpl12.density(2.5632394322605294d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 12.469784274537258d + "'", double3 == 12.469784274537258d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.5645039131968164E-4d + "'", double7 == 4.5645039131968164E-4d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.014935165787809915d + "'", double15 == 0.014935165787809915d);
//    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(1.4247971303902998d, 1.607132023323726E-9d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.4247971303902995d + "'", double2 == 1.4247971303902995d);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable1, (java.lang.Number) 10.0f, (java.lang.Number) 2.718281828459045d, false);
        java.lang.Number number6 = numberIsTooSmallException5.getMin();
        java.lang.Object[] objArray14 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException("", objArray14);
        java.lang.Throwable[] throwableArray16 = convergenceException15.getSuppressed();
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException5, "hi!", (java.lang.Object[]) throwableArray16);
        java.lang.String str18 = mathException17.getPattern();
        java.lang.Object[] objArray26 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException("", objArray26);
        java.lang.Throwable[] throwableArray28 = convergenceException27.getSuppressed();
        java.lang.Class<?> wildcardClass29 = convergenceException27.getClass();
        java.lang.Object[] objArray37 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException38 = new org.apache.commons.math.ConvergenceException("", objArray37);
        java.lang.Throwable[] throwableArray39 = convergenceException38.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable40 = null;
        java.lang.Object[] objArray47 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException48 = new org.apache.commons.math.ConvergenceException("", objArray47);
        java.lang.Throwable[] throwableArray49 = convergenceException48.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException50 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException38, localizable40, (java.lang.Object[]) throwableArray49);
        org.apache.commons.math.ConvergenceException convergenceException51 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException27, "", (java.lang.Object[]) throwableArray49);
        org.apache.commons.math.exception.util.Localizable localizable52 = convergenceException51.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException54 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable52, (java.lang.Number) 2.718281828459045d);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException58 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10L, (java.lang.Number) (-0.7853981633974483d), true);
        java.lang.Object[] objArray59 = numberIsTooLargeException58.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException60 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable52, objArray59);
        org.apache.commons.math.exception.util.Localizable localizable61 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException65 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable61, (java.lang.Number) 10.0f, (java.lang.Number) 2.718281828459045d, false);
        java.lang.Number number66 = numberIsTooSmallException65.getMin();
        java.lang.Object[] objArray74 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException75 = new org.apache.commons.math.ConvergenceException("", objArray74);
        java.lang.Throwable[] throwableArray76 = convergenceException75.getSuppressed();
        org.apache.commons.math.MathException mathException77 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException65, "hi!", (java.lang.Object[]) throwableArray76);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException78 = new org.apache.commons.math.MaxIterationsExceededException(31, localizable52, (java.lang.Object[]) throwableArray76);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException80 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 10);
        java.lang.Object[] objArray81 = notStrictlyPositiveException80.getArguments();
        org.apache.commons.math.MathException mathException82 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException17, localizable52, objArray81);
        org.apache.commons.math.ConvergenceException convergenceException83 = new org.apache.commons.math.ConvergenceException(localizable0, objArray81);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 2.718281828459045d + "'", number6.equals(2.718281828459045d));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "hi!" + "'", str18.equals("hi!"));
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(throwableArray28);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertNotNull(throwableArray39);
        org.junit.Assert.assertNotNull(objArray47);
        org.junit.Assert.assertNotNull(throwableArray49);
        org.junit.Assert.assertNotNull(localizable52);
        org.junit.Assert.assertNotNull(objArray59);
        org.junit.Assert.assertTrue("'" + number66 + "' != '" + 2.718281828459045d + "'", number66.equals(2.718281828459045d));
        org.junit.Assert.assertNotNull(objArray74);
        org.junit.Assert.assertNotNull(throwableArray76);
        org.junit.Assert.assertNotNull(objArray81);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 10.0f, (java.lang.Number) (byte) 10);
        org.apache.commons.math.exception.util.Localizable localizable5 = outOfRangeException4.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) (short) 100, (java.lang.Number) 11013.232874703393d, false);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException13 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) 8.737800111547191d, (java.lang.Number) 8.737800111547191d, false);
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException18 = new org.apache.commons.math.exception.OutOfRangeException(localizable14, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 10.0f, (java.lang.Number) (byte) 10);
        org.apache.commons.math.exception.util.Localizable localizable19 = outOfRangeException18.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable20 = outOfRangeException18.getGeneralPattern();
        java.lang.Object[] objArray27 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException("", objArray27);
        java.lang.Throwable[] throwableArray29 = convergenceException28.getSuppressed();
        java.lang.Class<?> wildcardClass30 = convergenceException28.getClass();
        org.apache.commons.math.exception.util.Localizable localizable31 = null;
        java.lang.Object[] objArray38 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException("", objArray38);
        org.apache.commons.math.MathException mathException40 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException28, localizable31, objArray38);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException41 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable20, objArray38);
        java.lang.String str42 = mathIllegalArgumentException41.toString();
        org.apache.commons.math.exception.util.Localizable localizable43 = mathIllegalArgumentException41.getSpecificPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException47 = new org.apache.commons.math.exception.OutOfRangeException(localizable43, (java.lang.Number) 5729.5779513082325d, (java.lang.Number) (-259.0f), (java.lang.Number) 0.02052926951466442d);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable19.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable20.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(throwableArray29);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "org.apache.commons.math.exception.MathIllegalArgumentException: 10 out of [hi!, 0] range: 10 out of [hi!, 0] range" + "'", str42.equals("org.apache.commons.math.exception.MathIllegalArgumentException: 10 out of [hi!, 0] range: 10 out of [hi!, 0] range"));
        org.junit.Assert.assertTrue("'" + localizable43 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable43.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 100.0f);
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getSpecificPattern();
        java.lang.Object[] objArray10 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException("", objArray10);
        java.lang.Throwable[] throwableArray12 = convergenceException11.getSuppressed();
        java.lang.Class<?> wildcardClass13 = convergenceException11.getClass();
        java.lang.Object[] objArray21 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException("", objArray21);
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException11, "", objArray21);
        java.lang.Object[] objArray31 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException("", objArray31);
        java.lang.Throwable[] throwableArray33 = convergenceException32.getSuppressed();
        java.lang.Class<?> wildcardClass34 = convergenceException32.getClass();
        java.lang.Object[] objArray42 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException43 = new org.apache.commons.math.ConvergenceException("", objArray42);
        org.apache.commons.math.ConvergenceException convergenceException44 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException32, "", objArray42);
        org.apache.commons.math.ConvergenceException convergenceException45 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException11, "hi!", objArray42);
        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException1, "", objArray42);
        java.lang.Class<?> wildcardClass47 = convergenceException46.getClass();
        org.apache.commons.math.MathException mathException48 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException46);
        org.apache.commons.math.exception.util.Localizable localizable49 = convergenceException46.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException51 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable49, (java.lang.Number) 2.302585092994046d);
        org.junit.Assert.assertNull(localizable2);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(throwableArray33);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertNotNull(wildcardClass47);
        org.junit.Assert.assertNotNull(localizable49);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        int int2 = org.apache.commons.math.util.FastMath.max(33, 1121140518);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1121140518 + "'", int2 == 1121140518);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 100L, (java.lang.Number) 10.000000000000002d, false);
        java.lang.Object[] objArray4 = numberIsTooSmallException3.getArguments();
        java.lang.Number number5 = numberIsTooSmallException3.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException3.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) 0.37882055894916916d, (java.lang.Number) 9.241796535393869d, false);
        java.lang.Number number11 = numberIsTooLargeException10.getMax();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 100L + "'", number5.equals(100L));
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 9.241796535393869d + "'", number11.equals(9.241796535393869d));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        double double2 = org.apache.commons.math.util.FastMath.max(13.207354306806415d, 52.476429300534186d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 52.476429300534186d + "'", double2 == 52.476429300534186d);
    }

//    @Test
//    public void test480() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test480");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        randomDataImpl0.reSeedSecure((long) '4');
//        double double7 = randomDataImpl0.nextChiSquare((double) 1.0f);
//        randomDataImpl0.reSeed();
//        double double11 = randomDataImpl0.nextUniform(0.0d, 1.1531906604012572d);
//        int int14 = randomDataImpl0.nextInt(0, 2);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 11.267221880648954d + "'", double3 == 11.267221880648954d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.28903985606367866d + "'", double7 == 0.28903985606367866d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.7173334931056596d + "'", double11 == 0.7173334931056596d);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        double double2 = org.apache.commons.math.util.FastMath.max(12.226292863546284d, (double) 24);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 24.0d + "'", double2 == 24.0d);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (-535.8091588260934d), (java.lang.Number) 33.618738037974566d, (java.lang.Number) (-32.661006041484406d));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        java.lang.Object[] objArray6 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException("", objArray6);
        java.lang.Throwable[] throwableArray8 = convergenceException7.getSuppressed();
        java.lang.Class<?> wildcardClass9 = convergenceException7.getClass();
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException("", objArray17);
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException7, localizable10, objArray17);
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException24 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable20, (java.lang.Number) 10.0f, (java.lang.Number) 2.718281828459045d, false);
        java.lang.Number number25 = numberIsTooSmallException24.getMin();
        org.apache.commons.math.exception.util.Localizable localizable26 = numberIsTooSmallException24.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException28 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable26, (java.lang.Number) 11.465100751341446d);
        java.lang.Object[] objArray31 = new java.lang.Object[] { 1.0d };
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException("", objArray31);
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException37 = new org.apache.commons.math.exception.OutOfRangeException(localizable33, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 10.0f, (java.lang.Number) (byte) 10);
        org.apache.commons.math.exception.util.Localizable localizable38 = outOfRangeException37.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable39 = outOfRangeException37.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable42 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException46 = new org.apache.commons.math.exception.OutOfRangeException(localizable42, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 10.0f, (java.lang.Number) (byte) 10);
        org.apache.commons.math.exception.util.Localizable localizable47 = outOfRangeException46.getGeneralPattern();
        java.lang.Object[] objArray54 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException55 = new org.apache.commons.math.ConvergenceException("", objArray54);
        java.lang.Throwable[] throwableArray56 = convergenceException55.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable57 = null;
        java.lang.Object[] objArray64 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException65 = new org.apache.commons.math.ConvergenceException("", objArray64);
        java.lang.Throwable[] throwableArray66 = convergenceException65.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException67 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException55, localizable57, (java.lang.Object[]) throwableArray66);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException68 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable47, (java.lang.Object[]) throwableArray66);
        java.lang.Object[] objArray69 = maxIterationsExceededException68.getArguments();
        org.apache.commons.math.MathException mathException70 = new org.apache.commons.math.MathException("hi!", objArray69);
        org.apache.commons.math.MathException mathException71 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException32, localizable39, objArray69);
        org.apache.commons.math.MathException mathException72 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException7, localizable26, objArray69);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + 2.718281828459045d + "'", number25.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable26 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable26.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertTrue("'" + localizable38 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable38.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable39 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable39.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable47 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable47.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray54);
        org.junit.Assert.assertNotNull(throwableArray56);
        org.junit.Assert.assertNotNull(objArray64);
        org.junit.Assert.assertNotNull(throwableArray66);
        org.junit.Assert.assertNotNull(objArray69);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 10.0f, (java.lang.Number) (byte) 10);
        org.apache.commons.math.exception.util.Localizable localizable5 = outOfRangeException4.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) (short) 100, (java.lang.Number) 11013.232874703393d, false);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException13 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) 8.737800111547191d, (java.lang.Number) 8.737800111547191d, false);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException17 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable5, (java.lang.Number) 33.618738037974566d, (java.lang.Number) 11.220056179351564d, false);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 63L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 63 + "'", int1 == 63);
    }

//    @Test
//    public void test486() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test486");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        int int6 = randomDataImpl0.nextSecureInt(0, (int) (short) 10);
//        int int9 = randomDataImpl0.nextInt(0, (int) '#');
//        double double12 = randomDataImpl0.nextBeta((double) 97.0f, 1.0E35d);
//        double double15 = randomDataImpl0.nextCauchy(0.615314862365699d, 0.5772156649015329d);
//        double double18 = randomDataImpl0.nextF((double) 32, 1.5707963267948966d);
//        long long21 = randomDataImpl0.nextSecureLong((long) 26, 100L);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 46.371721602851096d + "'", double3 == 46.371721602851096d);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 35 + "'", int9 == 35);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 2.001464459546872d + "'", double15 == 2.001464459546872d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.2790961354153569d + "'", double18 == 0.2790961354153569d);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 27L + "'", long21 == 27L);
//    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 10.0f, (java.lang.Number) 2.718281828459045d, false);
        java.lang.Number number5 = numberIsTooSmallException4.getMin();
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException4.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable6, (java.lang.Number) 11.465100751341446d);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException12 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable6, (java.lang.Number) 0.038667623566644216d, (java.lang.Number) 0.5363346344187385d, false);
        org.apache.commons.math.exception.util.Localizable localizable13 = numberIsTooSmallException12.getSpecificPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException15 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable13, (java.lang.Number) (-50.4992543512033d));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 2.718281828459045d + "'", number5.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable13.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        double double1 = org.apache.commons.math.special.Erf.erf((double) 34);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 10.0f, (java.lang.Number) (byte) 10);
        java.lang.Number number5 = outOfRangeException4.getHi();
        java.lang.Number number6 = outOfRangeException4.getArgument();
        java.lang.Number number7 = outOfRangeException4.getHi();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (byte) 10 + "'", number5.equals((byte) 10));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (-0.5772156677920679d) + "'", number6.equals((-0.5772156677920679d)));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (byte) 10 + "'", number7.equals((byte) 10));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        double double2 = org.apache.commons.math.util.FastMath.min(35.52033127663033d, 0.1774732597393479d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.1774732597393479d + "'", double2 == 0.1774732597393479d);
    }

//    @Test
//    public void test491() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test491");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        randomDataImpl0.reSeedSecure((long) '4');
//        double double7 = randomDataImpl0.nextChiSquare((double) 1.0f);
//        randomDataImpl0.reSeed();
//        double double11 = randomDataImpl0.nextUniform(0.0d, 1.1531906604012572d);
//        randomDataImpl0.reSeedSecure();
//        randomDataImpl0.reSeedSecure(12L);
//        try {
//            int int17 = randomDataImpl0.nextBinomial(2, 12.661006041484002d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 12.661 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 40.54719071059363d + "'", double3 == 40.54719071059363d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.7611260983975647d + "'", double7 == 1.7611260983975647d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.1154684935179464d + "'", double11 == 1.1154684935179464d);
//    }

//    @Test
//    public void test492() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test492");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        randomDataImpl0.reSeedSecure((long) 'a');
//        double double7 = randomDataImpl0.nextT((double) 7);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 37.3648319201826d + "'", double3 == 37.3648319201826d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.7300598042181101d + "'", double7 == 1.7300598042181101d);
//    }

//    @Test
//    public void test493() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test493");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy((double) (short) 10, 3.141592653589793d);
//        randomDataImpl0.reSeedSecure((long) '4');
//        double double7 = randomDataImpl0.nextChiSquare((double) 1.0f);
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeedSecure((long) 0);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 38.57050830207139d + "'", double3 == 38.57050830207139d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.004608879867659855d + "'", double7 == 0.004608879867659855d);
//    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 10.0f, (java.lang.Number) (byte) 10);
        org.apache.commons.math.exception.util.Localizable localizable5 = outOfRangeException4.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException13 = new org.apache.commons.math.exception.OutOfRangeException(localizable9, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 10.0f, (java.lang.Number) (byte) 10);
        org.apache.commons.math.exception.util.Localizable localizable14 = outOfRangeException13.getGeneralPattern();
        java.lang.Object[] objArray21 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException("", objArray21);
        java.lang.Throwable[] throwableArray23 = convergenceException22.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        java.lang.Object[] objArray31 = new java.lang.Object[] { 10, "hi!", 0, 1L, (short) 0 };
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException("", objArray31);
        java.lang.Throwable[] throwableArray33 = convergenceException32.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException34 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException22, localizable24, (java.lang.Object[]) throwableArray33);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException35 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable14, (java.lang.Object[]) throwableArray33);
        java.lang.Object[] objArray36 = maxIterationsExceededException35.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException37 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 100, "", objArray36);
        org.apache.commons.math.MathException mathException38 = new org.apache.commons.math.MathException(localizable5, objArray36);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException42 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) 1.065510567471183E-6d, (java.lang.Number) 8.457927173787883d, true);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable14.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(throwableArray23);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(throwableArray33);
        org.junit.Assert.assertNotNull(objArray36);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        double double1 = org.apache.commons.math.util.FastMath.atanh(1.0317425226950845d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        double double1 = org.apache.commons.math.util.FastMath.log10(2.1474836469999998E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.331929865381182d + "'", double1 == 9.331929865381182d);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 6L, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.999999999999999d + "'", double2 == 5.999999999999999d);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 8L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        double double1 = org.apache.commons.math.util.FastMath.log1p(1.818753767016531d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0362948606818054d + "'", double1 == 1.0362948606818054d);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.5772156649015329d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8326184616337932d + "'", double1 == 0.8326184616337932d);
    }
}

