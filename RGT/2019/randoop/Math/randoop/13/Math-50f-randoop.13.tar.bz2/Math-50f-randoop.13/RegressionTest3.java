import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest3 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test001");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(1, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test002");
        double double1 = org.apache.commons.math.util.FastMath.sinh(195.99999999999997d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.617416307822664E84d + "'", double1 == 6.617416307822664E84d);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test003");
        double double1 = org.apache.commons.math.util.MathUtils.sign(0.9169927026825043d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test004");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL;
        java.lang.String str1 = localizedFormats0.getSourceString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "function is not polynomial" + "'", str1.equals("function is not polynomial"));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test005");
        int int2 = org.apache.commons.math.util.MathUtils.pow(110, (long) 7);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 453845888 + "'", int2 == 453845888);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test006");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 196L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test007");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 9, 8.998336506481754d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.0d + "'", double2 == 9.0d);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test008");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_ADDITION;
        org.apache.commons.math.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math.exception.NotPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 97L);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_ADDITION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_ADDITION));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test009");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (-2852977536870709880L), 10.04987562112089d, 9.615723196941646E238d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test010");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction1 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        double double3 = regulaFalsiSolver2.getFunctionValueAccuracy();
        double double4 = regulaFalsiSolver2.getFunctionValueAccuracy();
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution8 = org.apache.commons.math.analysis.solvers.AllowedSolution.BELOW_SIDE;
        try {
            double double9 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide(61, univariateRealFunction1, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver2, 200.0d, 0.0d, (double) 52000, allowedSolution8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E-15d + "'", double3 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-15d + "'", double4 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + allowedSolution8 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.BELOW_SIDE + "'", allowedSolution8.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.BELOW_SIDE));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test011");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET;
        org.apache.commons.math.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math.exception.NotPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 100.0f);
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.TOO_LARGE_CUTOFF_SINGULAR_VALUE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.SHAPE;
        java.lang.Object[] objArray7 = new java.lang.Object[] { localizedFormats6 };
        org.apache.commons.math.exception.NullArgumentException nullArgumentException8 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, objArray7);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException9 = new org.apache.commons.math.exception.MathIllegalStateException(localizable4, objArray7);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) notPositiveException2, localizable3, objArray7);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TOO_LARGE_CUTOFF_SINGULAR_VALUE + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.TOO_LARGE_CUTOFF_SINGULAR_VALUE));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SHAPE + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.SHAPE));
        org.junit.Assert.assertNotNull(objArray7);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test012");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) (-35), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test013");
        double[] doubleArray3 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray3);
        double[] doubleArray6 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, 100.0d);
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray3, (int) (byte) 1);
        double[] doubleArray12 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray12);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, 100.0d);
        double[] doubleArray19 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray19);
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, 100.0d);
        double[] doubleArray24 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray19, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray24);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray15, doubleArray24);
        java.lang.Number number27 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection30 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException32 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number27, (java.lang.Number) 132.0d, 6, orderDirection30, false);
        boolean boolean35 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray15, orderDirection30, false, false);
        double double36 = org.apache.commons.math.util.MathUtils.distance1(doubleArray8, doubleArray15);
        double[] doubleArray40 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray40);
        double[] doubleArray43 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray40, 100.0d);
        double[] doubleArray45 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray43, (double) 1.0f);
        double[] doubleArray49 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray49);
        double[] doubleArray52 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray49, 100.0d);
        double[] doubleArray54 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray49, (int) (byte) 1);
        double double55 = org.apache.commons.math.util.MathUtils.distance1(doubleArray43, doubleArray49);
        double double56 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray43);
        double double57 = org.apache.commons.math.util.MathUtils.distance1(doubleArray15, doubleArray43);
        try {
            double[] doubleArray59 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray43, (-127));
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + orderDirection30 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection30.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 18.20689655172414d + "'", double36 == 18.20689655172414d);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 132.0d + "'", double55 == 132.0d);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 62.49851365652365d + "'", double56 == 62.49851365652365d);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test014");
        double double1 = org.apache.commons.math.util.FastMath.atanh(3.355443453504948E7d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test015");
        int[] intArray0 = null;
        int[] intArray3 = new int[] { 99, 'a' };
        int[] intArray9 = new int[] { (short) 100, 100, (byte) 10, (byte) 1, (byte) -1 };
        int[] intArray10 = org.apache.commons.math.util.MathUtils.copyOf(intArray9);
        int int11 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray9);
        int[] intArray14 = new int[] { 99, 'a' };
        int[] intArray20 = new int[] { (short) 100, 100, (byte) 10, (byte) 1, (byte) -1 };
        int[] intArray21 = org.apache.commons.math.util.MathUtils.copyOf(intArray20);
        int int22 = org.apache.commons.math.util.MathUtils.distance1(intArray14, intArray20);
        int[] intArray28 = new int[] { (short) 100, 100, (byte) 10, (byte) 1, (byte) -1 };
        int[] intArray29 = org.apache.commons.math.util.MathUtils.copyOf(intArray28);
        double double30 = org.apache.commons.math.util.MathUtils.distance(intArray20, intArray29);
        int int31 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray20);
        int[] intArray34 = new int[] { 99, 'a' };
        int[] intArray40 = new int[] { (short) 100, 100, (byte) 10, (byte) 1, (byte) -1 };
        int[] intArray41 = org.apache.commons.math.util.MathUtils.copyOf(intArray40);
        int int42 = org.apache.commons.math.util.MathUtils.distance1(intArray34, intArray40);
        int[] intArray44 = org.apache.commons.math.util.MathUtils.copyOf(intArray34, 9);
        double double45 = org.apache.commons.math.util.MathUtils.distance(intArray3, intArray34);
        try {
            int int46 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 4 + "'", int22 == 4);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 4 + "'", int31 == 4);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 4 + "'", int42 == 4);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test016");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((-1201819478), 4);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1201819482) + "'", int2 == (-1201819482));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test017");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(4.679207401552301E62d, 29937.07084924806d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test018");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((int) (byte) 100, 110);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: must have n >= k for binomial coefficient (n, k), got k = 110, n = 100");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test019");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((-0.6163965733697803d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6163965733697802d) + "'", double1 == (-0.6163965733697802d));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test020");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(2005.3522829578812d, 5.298292365610485d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test021");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.TOO_LARGE_CUTOFF_SINGULAR_VALUE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM;
        java.lang.Object[] objArray8 = new java.lang.Object[] { localizedFormats2, (-1), 0, localizedFormats5, 10.0d, (byte) 100 };
        java.lang.Object[] objArray9 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray8);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) localizedFormats0, (org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray9);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TOO_LARGE_CUTOFF_SINGULAR_VALUE + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.TOO_LARGE_CUTOFF_SINGULAR_VALUE));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(objArray9);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test022");
        double double8 = org.apache.commons.math.util.MathUtils.linearCombination((-0.5595106570525964d), 1.1102230246251565E-16d, (double) 10, (double) 5.0f, 132.0d, (-0.6321205588285577d), (double) (short) 10, 1.000000000000007d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-23.439913765369543d) + "'", double8 == (-23.439913765369543d));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test023");
        java.lang.Number number0 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 132.0d, 6, orderDirection3, false);
        int int6 = nonMonotonousSequenceException5.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test024");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 1.3258176496434093d);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test025");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException(1.1102230246251565E-16d, (double) (-90L), (double) 3628800L, 82.49803802661121d);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test026");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 1100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1100.0d + "'", double1 == 1100.0d);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test027");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(0.0d, (double) 0L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test028");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test029");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1L);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test030");
        double double1 = org.apache.commons.math.util.MathUtils.sign(1.80006593694412058E18d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test031");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((-11), (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test032");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(1082658816L, 990L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 59546234880L + "'", long2 == 59546234880L);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test033");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.DEGREES_OF_FREEDOM;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1.8189894035458565E-12d, (java.lang.Number) 97L, true);
        java.lang.Number number5 = numberIsTooSmallException4.getMin();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DEGREES_OF_FREEDOM + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.DEGREES_OF_FREEDOM));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 97L + "'", number5.equals(97L));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test034");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_BINARY_DIGIT;
        java.lang.Class<?> wildcardClass1 = localizedFormats0.getClass();
        java.lang.Throwable throwable3 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM;
        java.lang.Object[] objArray7 = new java.lang.Object[] { localizedFormats5, 52L };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException8 = new org.apache.commons.math.exception.MathIllegalStateException(throwable3, (org.apache.commons.math.exception.util.Localizable) localizedFormats4, objArray7);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext9 = mathIllegalStateException8.getContext();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext10 = mathIllegalStateException8.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats20 = org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats23 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_INCREMENT_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS;
        java.lang.Object[] objArray24 = new java.lang.Object[] { 0, 0.0d, localizedFormats20, 81.55795945611504d, 10.0d, localizedFormats23 };
        org.apache.commons.math.exception.NoBracketingException noBracketingException25 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats13, (double) (-1L), (double) ' ', (double) 100L, (double) (short) 10, objArray24);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException26 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats12, objArray24);
        exceptionContext10.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats11, objArray24);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException28 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) Double.NaN, objArray24);
        java.lang.Throwable[] throwableArray29 = maxCountExceededException28.getSuppressed();
        java.lang.Number number30 = maxCountExceededException28.getMax();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_BINARY_DIGIT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_BINARY_DIGIT));
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM));
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(exceptionContext9);
        org.junit.Assert.assertNotNull(exceptionContext10);
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE + "'", localizedFormats11.equals(org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE + "'", localizedFormats12.equals(org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE));
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS + "'", localizedFormats13.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS));
        org.junit.Assert.assertTrue("'" + localizedFormats20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER + "'", localizedFormats20.equals(org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER));
        org.junit.Assert.assertTrue("'" + localizedFormats23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_INCREMENT_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS + "'", localizedFormats23.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_INCREMENT_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS));
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(throwableArray29);
        org.junit.Assert.assertEquals((double) number30, Double.NaN, 0);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test035");
        double[] doubleArray3 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray3);
        double[] doubleArray6 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, 100.0d);
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) 1.0f);
        double[] doubleArray12 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray12);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, 100.0d);
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray12, (int) (byte) 1);
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray12);
        double[] doubleArray22 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray22);
        double[] doubleArray25 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray22, 100.0d);
        double[] doubleArray27 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, (double) 1.0f);
        double[] doubleArray31 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray31);
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray31, 100.0d);
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray31, (int) (byte) 1);
        double double37 = org.apache.commons.math.util.MathUtils.distance1(doubleArray25, doubleArray31);
        double double38 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray25);
        double double39 = org.apache.commons.math.util.MathUtils.distance(doubleArray12, doubleArray25);
        double[] doubleArray43 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray43);
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray43, 100.0d);
        double[] doubleArray47 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray43);
        int int48 = org.apache.commons.math.util.MathUtils.hash(doubleArray43);
        double[] doubleArray50 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray43, 6.283185307179586d);
        boolean boolean51 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray25, doubleArray43);
        java.lang.Number number52 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection55 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException57 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number52, (java.lang.Number) 132.0d, 6, orderDirection55, false);
        boolean boolean60 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray25, orderDirection55, true, false);
        double[] doubleArray62 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, (double) 74690.0f);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 132.0d + "'", double18 == 132.0d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 132.0d + "'", double37 == 132.0d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 62.49851365652365d + "'", double38 == 62.49851365652365d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 82.49803802661121d + "'", double39 == 82.49803802661121d);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 996176991 + "'", int48 == 996176991);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + orderDirection55 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection55.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(doubleArray62);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test036");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NON_SQUARE_LINEAR_OPERATOR;
        java.lang.Class<?> wildcardClass1 = localizedFormats0.getClass();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_SQUARE_LINEAR_OPERATOR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_SQUARE_LINEAR_OPERATOR));
        org.junit.Assert.assertNotNull(wildcardClass1);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test037");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math.exception.NotPositiveException(localizable0, (java.lang.Number) 10.049875621120892d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test038");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(56.89655172413793d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.846171529538503d + "'", double1 == 3.846171529538503d);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test039");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_LENGTH;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 0);
        boolean boolean3 = notStrictlyPositiveException2.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_LENGTH + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_LENGTH));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test040");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) (-90.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-5.192987713658941d) + "'", double1 == (-5.192987713658941d));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test041");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) 9.536743E-7f, 35.0d, (double) 87L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test042");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.9874056173207585d, (double) (byte) 1, 35.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test043");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 52.0f, (java.lang.Number) (-1), (int) (byte) 1, orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getPrevious();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext7 = nonMonotonousSequenceException5.getContext();
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (-1) + "'", number6.equals((-1)));
        org.junit.Assert.assertNotNull(exceptionContext7);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test044");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(200.0d, (double) 40L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test045");
        int int1 = org.apache.commons.math.util.MathUtils.hash(6.283185307179586d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 341642467 + "'", int1 == 341642467);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test046");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 4, (long) 'a');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 101L + "'", long2 == 101L);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test047");
        double double6 = org.apache.commons.math.util.MathUtils.linearCombination(3.948148009134034E13d, 9.615723196941646E238d, (double) 5040L, 9.834532502485658E-6d, (-4.0d), (double) (-1.0000001f));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 3.7964298396389114E252d + "'", double6 == 3.7964298396389114E252d);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test048");
        float float2 = org.apache.commons.math.util.FastMath.copySign(0.0f, (float) 2);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test049");
        int int1 = org.apache.commons.math.util.FastMath.getExponent((-279305.0d));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 18 + "'", int1 == 18);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test050");
        double[] doubleArray3 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray3);
        double[] doubleArray6 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, 100.0d);
        double[] doubleArray7 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray3);
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        double[] doubleArray10 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, 6.283185307179586d);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, 3.1366342700391465E18d);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 996176991 + "'", int8 == 996176991);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test051");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction1 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        int int3 = regulaFalsiSolver2.getMaxEvaluations();
        int int4 = regulaFalsiSolver2.getEvaluations();
        double double5 = regulaFalsiSolver2.getMax();
        double double6 = regulaFalsiSolver2.getFunctionValueAccuracy();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction11 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver12 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        double double13 = regulaFalsiSolver12.getMin();
        double double14 = regulaFalsiSolver12.getFunctionValueAccuracy();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction19 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver23 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(52.0d, 90.0d, 6.617416307822852E84d);
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution27 = org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE;
        double double28 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide(0, univariateRealFunction19, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver23, (double) (short) 1, 11013.232874703393d, 1.0076685815103525d, allowedSolution27);
        double double29 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide(127, univariateRealFunction11, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver12, 5.298292365610485d, 2.718281828459045d, 1.1920928955078125E-7d, allowedSolution27);
        double double30 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide((-33), univariateRealFunction1, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver2, 1.69759663277E-313d, (double) (-8934108775301215359L), (double) (short) 10, allowedSolution27);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction32 = null;
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction37 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver38 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        int int39 = regulaFalsiSolver38.getMaxEvaluations();
        int int40 = regulaFalsiSolver38.getEvaluations();
        double double41 = regulaFalsiSolver38.getMax();
        double double42 = regulaFalsiSolver38.getFunctionValueAccuracy();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction47 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver48 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        double double49 = regulaFalsiSolver48.getMin();
        double double50 = regulaFalsiSolver48.getFunctionValueAccuracy();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction55 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver59 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(52.0d, 90.0d, 6.617416307822852E84d);
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution63 = org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE;
        double double64 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide(0, univariateRealFunction55, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver59, (double) (short) 1, 11013.232874703393d, 1.0076685815103525d, allowedSolution63);
        double double65 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide(127, univariateRealFunction47, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver48, 5.298292365610485d, 2.718281828459045d, 1.1920928955078125E-7d, allowedSolution63);
        double double66 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide((-33), univariateRealFunction37, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver38, 1.69759663277E-313d, (double) (-8934108775301215359L), (double) (short) 10, allowedSolution63);
        try {
            double double67 = regulaFalsiSolver2.solve(0, univariateRealFunction32, 6.47985642107054E9d, 4.304404484108674E9d, (-8.699715755749389E31d), allowedSolution63);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0E-15d + "'", double6 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0E-15d + "'", double14 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + allowedSolution27 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE + "'", allowedSolution27.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE));
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.0d + "'", double28 == 1.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 5.298292365610485d + "'", double29 == 5.298292365610485d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.69759663277E-313d + "'", double30 == 1.69759663277E-313d);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 1.0E-15d + "'", double42 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 1.0E-15d + "'", double50 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + allowedSolution63 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE + "'", allowedSolution63.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE));
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 1.0d + "'", double64 == 1.0d);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 5.298292365610485d + "'", double65 == 5.298292365610485d);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 1.69759663277E-313d + "'", double66 == 1.69759663277E-313d);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test052");
        double double1 = org.apache.commons.math.util.FastMath.tanh(77116.9095292137d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test053");
        double double2 = org.apache.commons.math.util.FastMath.scalb(0.0d, (int) '#');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test054");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) 1100, 1000.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test055");
        int int1 = org.apache.commons.math.util.MathUtils.hash(1.205127862798442d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 412103574 + "'", int1 == 412103574);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test056");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver0 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        int int1 = regulaFalsiSolver0.getMaxEvaluations();
        double double2 = regulaFalsiSolver0.getStartValue();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction4 = null;
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction9 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver13 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(52.0d, 90.0d, 6.617416307822852E84d);
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution17 = org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE;
        double double18 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide(0, univariateRealFunction9, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver13, (double) (short) 1, 11013.232874703393d, 1.0076685815103525d, allowedSolution17);
        try {
            double double19 = regulaFalsiSolver0.solve((int) (byte) 1, univariateRealFunction4, (double) 35.000004f, (double) (-8843210507033658501L), 11.04987562112089d, allowedSolution17);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + allowedSolution17 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE + "'", allowedSolution17.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE));
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test057");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException(57.29577951308233d, 9.999999999999998d, (double) 30, (double) 99);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test058");
        double[] doubleArray3 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray3);
        double[] doubleArray6 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, 100.0d);
        double[] doubleArray10 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray10);
        double[] doubleArray13 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray10, 100.0d);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray10, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray15);
        boolean boolean17 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray15);
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray6);
        int int19 = org.apache.commons.math.util.MathUtils.hash(doubleArray18);
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray18);
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray18, 1.1102230246251565E-16d);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1201819478) + "'", int19 == (-1201819478));
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test059");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) (-1201819482));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test060");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(412103574, 30);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2060517870 + "'", int2 == 2060517870);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test061");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 74690L, (double) 3.136634E18f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 74690.00000000001d + "'", double2 == 74690.00000000001d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test062");
        double double4 = org.apache.commons.math.util.MathUtils.linearCombination(5050.000003814698d, (double) 9.536743E-7f, (double) '4', (double) 56693912375296L);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 2.948083443515392E15d + "'", double4 == 2.948083443515392E15d);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test063");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, (double) 52000, (double) 1201819575, (-12700.0d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test064");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 52L, 2.718281828459045d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test065");
        double double1 = org.apache.commons.math.util.FastMath.floor(3.141592653589793d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test066");
        double[] doubleArray3 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray3);
        double[] doubleArray6 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, 100.0d);
        int int7 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        double[] doubleArray11 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray11);
        double[] doubleArray16 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray16);
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, 100.0d);
        double double20 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray11, doubleArray16);
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray16);
        double[] doubleArray25 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray25);
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, 100.0d);
        double[] doubleArray32 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray32);
        double[] doubleArray35 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray32, 100.0d);
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equals(doubleArray25, doubleArray35);
        double double37 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray35);
        double[] doubleArray41 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray41);
        double[] doubleArray44 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray41, 100.0d);
        double[] doubleArray45 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray41);
        int int46 = org.apache.commons.math.util.MathUtils.hash(doubleArray41);
        double[] doubleArray48 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray41, 6.283185307179586d);
        double double49 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray35, doubleArray48);
        double double50 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1201819478) + "'", int7 == (-1201819478));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 21024.0d + "'", double20 == 21024.0d);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 996176991 + "'", int46 == 996176991);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 245.42525248614677d + "'", double49 == 245.42525248614677d);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 3.9268974272723214d + "'", double50 == 3.9268974272723214d);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test067");
        float float2 = org.apache.commons.math.util.FastMath.nextAfter((float) 1082658816, (-2.0d));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.08265869E9f + "'", float2 == 1.08265869E9f);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test068");
        double double6 = org.apache.commons.math.util.MathUtils.linearCombination((double) (byte) 0, 8.998336506481754d, 196.0d, 0.0d, (double) (byte) -1, 35.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-35.0d) + "'", double6 == (-35.0d));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test069");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver0 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        double double1 = regulaFalsiSolver0.getAbsoluteAccuracy();
        double double2 = regulaFalsiSolver0.getMin();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0E-6d + "'", double1 == 1.0E-6d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test070");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((-23.439913765369543d), 0.0d, 1.1102230246251565E-16d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test071");
        double double4 = org.apache.commons.math.util.MathUtils.linearCombination(0.0d, 1.971702351536336d, (double) 10L, 3.311419785216E12d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 3.311419785216E13d + "'", double4 == 3.311419785216E13d);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test072");
        double double1 = org.apache.commons.math.util.FastMath.cos(200535.2282957881d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4659999899699459d + "'", double1 == 0.4659999899699459d);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test073");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 2L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9092974268256817d + "'", double1 == 0.9092974268256817d);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test074");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(62.49851365652365d, Double.POSITIVE_INFINITY, (double) (-1.0f));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test075");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(77116.9095292137d, (double) 30);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 28.50899542735715d + "'", double2 == 28.50899542735715d);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test076");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(0, 1100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test077");
        double double1 = org.apache.commons.math.util.FastMath.cos(2.2250738585072014E-308d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test078");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((-2.0d), (double) 109.0f, 1.570527203285422d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test079");
        int int1 = org.apache.commons.math.util.MathUtils.sign(1100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test080");
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext0 = new org.apache.commons.math.exception.util.ExceptionContext();
        java.util.Set<java.lang.String> strSet1 = exceptionContext0.getKeys();
        java.util.Set<java.lang.String> strSet2 = exceptionContext0.getKeys();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.SINGULAR_MATRIX;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_WEIGHT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats19 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_INCREMENT_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS;
        java.lang.Object[] objArray20 = new java.lang.Object[] { 0, 0.0d, localizedFormats16, 81.55795945611504d, 10.0d, localizedFormats19 };
        org.apache.commons.math.exception.NoBracketingException noBracketingException21 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats9, (double) (-1L), (double) ' ', (double) 100L, (double) (short) 10, objArray20);
        org.apache.commons.math.exception.NoBracketingException noBracketingException22 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats4, (-1.4309082844072307d), 22026.465794806718d, (-0.12408049872194353d), 52.0d, objArray20);
        exceptionContext0.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats3, objArray20);
        java.lang.Object[] objArray24 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray20);
        org.junit.Assert.assertNotNull(strSet1);
        org.junit.Assert.assertNotNull(strSet2);
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SINGULAR_MATRIX + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.SINGULAR_MATRIX));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_WEIGHT + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_WEIGHT));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS + "'", localizedFormats9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS));
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER + "'", localizedFormats16.equals(org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER));
        org.junit.Assert.assertTrue("'" + localizedFormats19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_INCREMENT_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS + "'", localizedFormats19.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_INCREMENT_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS));
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(objArray24);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test081");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((float) 5200L, (float) (-127));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test082");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(1.0779361614282227E9d);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction3 = null;
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction8 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver9 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        int int10 = regulaFalsiSolver9.getMaxEvaluations();
        int int11 = regulaFalsiSolver9.getEvaluations();
        double double12 = regulaFalsiSolver9.getMax();
        double double13 = regulaFalsiSolver9.getFunctionValueAccuracy();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction18 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver19 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        double double20 = regulaFalsiSolver19.getMin();
        double double21 = regulaFalsiSolver19.getFunctionValueAccuracy();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction26 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver30 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(52.0d, 90.0d, 6.617416307822852E84d);
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution34 = org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE;
        double double35 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide(0, univariateRealFunction26, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver30, (double) (short) 1, 11013.232874703393d, 1.0076685815103525d, allowedSolution34);
        double double36 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide(127, univariateRealFunction18, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver19, 5.298292365610485d, 2.718281828459045d, 1.1920928955078125E-7d, allowedSolution34);
        double double37 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide((-33), univariateRealFunction8, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver9, 1.69759663277E-313d, (double) (-8934108775301215359L), (double) (short) 10, allowedSolution34);
        try {
            double double38 = regulaFalsiSolver1.solve(7710, univariateRealFunction3, (double) 35L, 2.2737367544323206E-13d, 0.0d, allowedSolution34);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0E-15d + "'", double13 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0E-15d + "'", double21 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + allowedSolution34 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE + "'", allowedSolution34.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE));
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 1.0d + "'", double35 == 1.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 5.298292365610485d + "'", double36 == 5.298292365610485d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 1.69759663277E-313d + "'", double37 == 1.69759663277E-313d);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test083");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.DEGREES_OF_FREEDOM;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1.8189894035458565E-12d, (java.lang.Number) 97L, true);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_SUBSTITUTE_ELEMENT_FROM_EMPTY_ARRAY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.EVALUATIONS;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 52.0f, (java.lang.Number) (-1), (int) (byte) 1, orderDirection14, false);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext17 = nonMonotonousSequenceException16.getContext();
        java.lang.Throwable[] throwableArray18 = nonMonotonousSequenceException16.getSuppressed();
        org.apache.commons.math.exception.NoBracketingException noBracketingException19 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats6, 0.8414709848078965d, (-0.23251381989123973d), (double) (-196L), (double) (byte) -1, (java.lang.Object[]) throwableArray18);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException20 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, (java.lang.Object[]) throwableArray18);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException21 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) throwableArray18);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DEGREES_OF_FREEDOM + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.DEGREES_OF_FREEDOM));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_SUBSTITUTE_ELEMENT_FROM_EMPTY_ARRAY + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_SUBSTITUTE_ELEMENT_FROM_EMPTY_ARRAY));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EVALUATIONS + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.EVALUATIONS));
        org.junit.Assert.assertNotNull(exceptionContext17);
        org.junit.Assert.assertNotNull(throwableArray18);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test084");
        int[] intArray0 = new int[] {};
        int[] intArray6 = new int[] { (short) 100, 100, (byte) 10, (byte) 1, (byte) -1 };
        int[] intArray7 = org.apache.commons.math.util.MathUtils.copyOf(intArray6);
        int int8 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray7);
        int[] intArray14 = new int[] { (short) 100, 100, (byte) 10, (byte) 1, (byte) -1 };
        int[] intArray15 = org.apache.commons.math.util.MathUtils.copyOf(intArray14);
        double double16 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray14);
        int[] intArray17 = new int[] {};
        int[] intArray23 = new int[] { (short) 100, 100, (byte) 10, (byte) 1, (byte) -1 };
        int[] intArray24 = org.apache.commons.math.util.MathUtils.copyOf(intArray23);
        int int25 = org.apache.commons.math.util.MathUtils.distance1(intArray17, intArray24);
        int[] intArray27 = org.apache.commons.math.util.MathUtils.copyOf(intArray24, 97);
        int int28 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray24);
        int[] intArray29 = null;
        int int30 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray29);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test085");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (byte) 1, (float) 453845888);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 4.53845888E8f + "'", float2 == 4.53845888E8f);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test086");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 127);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test087");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver0 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        int int1 = regulaFalsiSolver0.getMaxEvaluations();
        double double2 = regulaFalsiSolver0.getStartValue();
        double double3 = regulaFalsiSolver0.getAbsoluteAccuracy();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction5 = null;
        try {
            double double9 = regulaFalsiSolver0.solve(52000, univariateRealFunction5, 5.267884728309446d, (double) 7710, 29937.07084924806d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E-6d + "'", double3 == 1.0E-6d);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test088");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyBracketing(univariateRealFunction0, (double) 200L, (double) 74690L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test089");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((int) (short) 100, 1100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: must have n >= k for binomial coefficient (n, k), got k = 1,100, n = 100");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test090");
        double double1 = org.apache.commons.math.util.FastMath.acos(3.5413887082388813d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test091");
        float float2 = org.apache.commons.math.util.FastMath.min(1.07793613E9f, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test092");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.0d, 1227.2200291716233d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test093");
        java.lang.Number number4 = null;
        double[] doubleArray9 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray9);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, 100.0d);
        double[] doubleArray16 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray16);
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, 100.0d);
        double[] doubleArray21 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray16, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray21);
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray21);
        java.lang.Number number24 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection27 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException29 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number24, (java.lang.Number) 132.0d, 6, orderDirection27, false);
        boolean boolean32 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray12, orderDirection27, false, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException34 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.000000000000007d, number4, (int) '4', orderDirection27, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException36 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 4.53845888E8f, (java.lang.Number) 4.806217383937352E-6d, 0, orderDirection27, true);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + orderDirection27 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection27.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test094");
        double double1 = org.apache.commons.math.util.FastMath.tan((-1.201819478E9d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0360979297067585d) + "'", double1 == (-1.0360979297067585d));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test095");
        double[] doubleArray3 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray3);
        double[] doubleArray6 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, 100.0d);
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) 1.0f);
        double[] doubleArray12 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray12);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, 100.0d);
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray12, (int) (byte) 1);
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray12);
        double double19 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray6);
        double[] doubleArray24 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray24);
        double[] doubleArray27 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray24, 100.0d);
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray24);
        int int29 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        double[] doubleArray33 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray33);
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray33, 100.0d);
        double[] doubleArray40 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray40);
        double[] doubleArray43 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray40, 100.0d);
        double[] doubleArray45 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray40, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray45);
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray36, doubleArray45);
        java.lang.Number number48 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection51 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException53 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number48, (java.lang.Number) 132.0d, 6, orderDirection51, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray45, orderDirection51, true);
        boolean boolean58 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray24, orderDirection51, true, false);
        boolean boolean61 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray6, orderDirection51, true, false);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 132.0d + "'", double18 == 132.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 62.49851365652365d + "'", double19 == 62.49851365652365d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 996176991 + "'", int29 == 996176991);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + orderDirection51 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection51.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test096");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.6300396599891174d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8080041422019902d + "'", double1 == 0.8080041422019902d);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test097");
        double[] doubleArray3 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray3);
        double[] doubleArray8 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray8);
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray8, 100.0d);
        double double12 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray3, doubleArray8);
        double[] doubleArray13 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray8);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray8);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (100 >= 100)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 21024.0d + "'", double12 == 21024.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test098");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 4.0f, 0.0927837451120071d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.137264232982505d + "'", double2 == 1.137264232982505d);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test099");
        double double1 = org.apache.commons.math.util.FastMath.log(0.9874056173207585d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.012674364171370817d) + "'", double1 == (-0.012674364171370817d));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test100");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(3);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test101");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(23151.906933686558d, (double) 9999L);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test102");
        double[] doubleArray0 = null;
        try {
            double[] doubleArray2 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray0, (double) 9.536743E-7f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test103");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 9.536743E-7f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.53674316406539E-7d + "'", double1 == 9.53674316406539E-7d);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test104");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.0d), (java.lang.Number) 10.04987562112089d, (int) (byte) 0, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        java.lang.Throwable[] throwableArray7 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.Throwable[] throwableArray8 = nonMonotonousSequenceException5.getSuppressed();
        org.junit.Assert.assertNull(orderDirection6);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(throwableArray8);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test105");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(139.0d, 3200.0003814697266d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test106");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(0, 5200);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5200 + "'", int2 == 5200);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test107");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.BOBYQA_BOUND_DIFFERENCE_CONDITION;
        java.lang.String str1 = localizedFormats0.getSourceString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.BOBYQA_BOUND_DIFFERENCE_CONDITION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.BOBYQA_BOUND_DIFFERENCE_CONDITION));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "the difference between the upper and lower bound must be larger than twice the initial trust region radius ({0})" + "'", str1.equals("the difference between the upper and lower bound must be larger than twice the initial trust region radius ({0})"));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test108");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException(number0, (java.lang.Number) 1.7160033436347992d, true);
        java.lang.Throwable[] throwableArray4 = numberIsTooSmallException3.getSuppressed();
        java.lang.Number number5 = numberIsTooSmallException3.getMin();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1.7160033436347992d + "'", number5.equals(1.7160033436347992d));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test109");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((float) 870L, (float) 35L, 770);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test110");
        int[] intArray0 = new int[] {};
        int[] intArray6 = new int[] { (short) 100, 100, (byte) 10, (byte) 1, (byte) -1 };
        int[] intArray7 = org.apache.commons.math.util.MathUtils.copyOf(intArray6);
        int int8 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray7);
        try {
            int[] intArray10 = org.apache.commons.math.util.MathUtils.copyOf(intArray0, (-1201819482));
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test111");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 6, (java.lang.Number) 3136633892082024448L, (int) '#', orderDirection3, false);
        boolean boolean6 = nonMonotonousSequenceException5.getStrict();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test112");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException2 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, objArray1);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test113");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.028563657838759995d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5441861779368737d) + "'", double1 == (-1.5441861779368737d));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test114");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NO_DATA;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_BINARY_DIGIT;
        java.lang.Class<?> wildcardClass2 = localizedFormats1.getClass();
        java.lang.Throwable throwable4 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM;
        java.lang.Object[] objArray8 = new java.lang.Object[] { localizedFormats6, 52L };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException9 = new org.apache.commons.math.exception.MathIllegalStateException(throwable4, (org.apache.commons.math.exception.util.Localizable) localizedFormats5, objArray8);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext10 = mathIllegalStateException9.getContext();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext11 = mathIllegalStateException9.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats14 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats24 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_INCREMENT_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS;
        java.lang.Object[] objArray25 = new java.lang.Object[] { 0, 0.0d, localizedFormats21, 81.55795945611504d, 10.0d, localizedFormats24 };
        org.apache.commons.math.exception.NoBracketingException noBracketingException26 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats14, (double) (-1L), (double) ' ', (double) 100L, (double) (short) 10, objArray25);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException27 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats13, objArray25);
        exceptionContext11.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats12, objArray25);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException29 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Number) Double.NaN, objArray25);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException30 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray25);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_DATA + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_DATA));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_BINARY_DIGIT + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_BINARY_DIGIT));
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(exceptionContext10);
        org.junit.Assert.assertNotNull(exceptionContext11);
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE + "'", localizedFormats12.equals(org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE + "'", localizedFormats13.equals(org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE));
        org.junit.Assert.assertTrue("'" + localizedFormats14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS + "'", localizedFormats14.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS));
        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER + "'", localizedFormats21.equals(org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER));
        org.junit.Assert.assertTrue("'" + localizedFormats24 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_INCREMENT_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS + "'", localizedFormats24.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_INCREMENT_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS));
        org.junit.Assert.assertNotNull(objArray25);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test115");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(0.0d, 0.0d, 3.311419785216E12d);
        double double4 = regulaFalsiSolver3.getMax();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction6 = null;
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction10 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver11 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        int int12 = regulaFalsiSolver11.getMaxEvaluations();
        int int13 = regulaFalsiSolver11.getEvaluations();
        double double14 = regulaFalsiSolver11.getMax();
        double double15 = regulaFalsiSolver11.getFunctionValueAccuracy();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction20 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver21 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        double double22 = regulaFalsiSolver21.getMin();
        double double23 = regulaFalsiSolver21.getFunctionValueAccuracy();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction28 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver32 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(52.0d, 90.0d, 6.617416307822852E84d);
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution36 = org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE;
        double double37 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide(0, univariateRealFunction28, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver32, (double) (short) 1, 11013.232874703393d, 1.0076685815103525d, allowedSolution36);
        double double38 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide(127, univariateRealFunction20, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver21, 5.298292365610485d, 2.718281828459045d, 1.1920928955078125E-7d, allowedSolution36);
        double double39 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide((-33), univariateRealFunction10, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver11, 1.69759663277E-313d, (double) (-8934108775301215359L), (double) (short) 10, allowedSolution36);
        try {
            double double40 = regulaFalsiSolver3.solve(0, univariateRealFunction6, 0.0d, 3.141592653589793d, allowedSolution36);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0E-15d + "'", double15 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0E-15d + "'", double23 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + allowedSolution36 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE + "'", allowedSolution36.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE));
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 1.0d + "'", double37 == 1.0d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 5.298292365610485d + "'", double38 == 5.298292365610485d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 1.69759663277E-313d + "'", double39 == 1.69759663277E-313d);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test116");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 3136633892082024448L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test117");
        double double1 = org.apache.commons.math.util.MathUtils.sign(195.99999999999997d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test118");
        double double1 = org.apache.commons.math.util.FastMath.exp(18.20689655172414d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.075226358803664E7d + "'", double1 == 8.075226358803664E7d);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test119");
        java.lang.Number number0 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) (-1), (-1201819478), orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getPrevious();
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (-1) + "'", number6.equals((-1)));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test120");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(0.0d, 0.0d, 1.7160033436347992d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test121");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException(35.01450265204638d, 4.9E-324d, 0.0d, 2.958103478741511E26d);
        double double5 = noBracketingException4.getHi();
        double double6 = noBracketingException4.getLo();
        double double7 = noBracketingException4.getFLo();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.9E-324d + "'", double5 == 4.9E-324d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 35.01450265204638d + "'", double6 == 35.01450265204638d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test122");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 1.4E-45f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test123");
        int int1 = org.apache.commons.math.util.FastMath.getExponent(4.9E-324d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1023) + "'", int1 == (-1023));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test124");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.setMaximalCount((-1));
        incrementor0.setMaximalCount(1100);
        int int5 = incrementor0.getMaximalCount();
        int int6 = incrementor0.getCount();
        try {
            incrementor0.incrementCount(1201819478);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MaxCountExceededException; message: illegal state: maximal count (1,100) exceeded");
        } catch (org.apache.commons.math.exception.MaxCountExceededException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1100 + "'", int5 == 1100);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test125");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.NO_FEASIBLE_SOLUTION;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException6 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, (java.lang.Number) 10.0f, (java.lang.Number) 1, true);
        java.lang.String str7 = numberIsTooSmallException6.toString();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext8 = numberIsTooSmallException6.getContext();
        java.lang.Throwable throwable9 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM;
        java.lang.Object[] objArray13 = new java.lang.Object[] { localizedFormats11, 52L };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException14 = new org.apache.commons.math.exception.MathIllegalStateException(throwable9, (org.apache.commons.math.exception.util.Localizable) localizedFormats10, objArray13);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats23 = org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats26 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_INCREMENT_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS;
        java.lang.Object[] objArray27 = new java.lang.Object[] { 0, 0.0d, localizedFormats23, 81.55795945611504d, 10.0d, localizedFormats26 };
        org.apache.commons.math.exception.NoBracketingException noBracketingException28 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats16, (double) (-1L), (double) ' ', (double) 100L, (double) (short) 10, objArray27);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException29 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats15, objArray27);
        exceptionContext8.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats10, objArray27);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException31 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 6.283185307179586d, objArray27);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException32 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 18.20689655172414d, objArray27);
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_FEASIBLE_SOLUTION + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_FEASIBLE_SOLUTION));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: no feasible solution" + "'", str7.equals("org.apache.commons.math.exception.NumberIsTooSmallException: no feasible solution"));
        org.junit.Assert.assertNotNull(exceptionContext8);
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizedFormats10.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM + "'", localizedFormats11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE + "'", localizedFormats15.equals(org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE));
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS + "'", localizedFormats16.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS));
        org.junit.Assert.assertTrue("'" + localizedFormats23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER + "'", localizedFormats23.equals(org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER));
        org.junit.Assert.assertTrue("'" + localizedFormats26 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_INCREMENT_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS + "'", localizedFormats26.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_INCREMENT_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS));
        org.junit.Assert.assertNotNull(objArray27);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test126");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(0.0d, (-1.960323183182555E166d));
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction4 = null;
        try {
            double double8 = regulaFalsiSolver2.solve(4, univariateRealFunction4, (-0.5595106570525964d), 0.6725571839577216d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test127");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(5.267884728309446d, (double) (-90.0f));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.267884728309445d + "'", double2 == 5.267884728309445d);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test128");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(0.0d, 0.6300396599891174d);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test129");
        double[] doubleArray3 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray3);
        double[] doubleArray8 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray8);
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray8, 100.0d);
        double double12 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray3, doubleArray8);
        double[] doubleArray13 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray8);
        double[] doubleArray14 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 21024.0d + "'", double12 == 21024.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test130");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.0d, (double) 1992353982, 6.617416307822664E84d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test131");
        int[] intArray2 = new int[] { 99, 'a' };
        int[] intArray8 = new int[] { (short) 100, 100, (byte) 10, (byte) 1, (byte) -1 };
        int[] intArray9 = org.apache.commons.math.util.MathUtils.copyOf(intArray8);
        int int10 = org.apache.commons.math.util.MathUtils.distance1(intArray2, intArray8);
        int[] intArray12 = org.apache.commons.math.util.MathUtils.copyOf(intArray2, 9);
        int[] intArray18 = new int[] { (short) 100, 100, (byte) 10, (byte) 1, (byte) -1 };
        int[] intArray19 = org.apache.commons.math.util.MathUtils.copyOf(intArray18);
        int[] intArray25 = new int[] { (short) 100, 100, (byte) 10, (byte) 1, (byte) -1 };
        int[] intArray26 = org.apache.commons.math.util.MathUtils.copyOf(intArray25);
        int int27 = org.apache.commons.math.util.MathUtils.distance1(intArray18, intArray26);
        int[] intArray33 = new int[] { (short) 100, 100, (byte) 10, (byte) 1, (byte) -1 };
        int[] intArray34 = org.apache.commons.math.util.MathUtils.copyOf(intArray33);
        int[] intArray40 = new int[] { (short) 100, 100, (byte) 10, (byte) 1, (byte) -1 };
        int[] intArray41 = org.apache.commons.math.util.MathUtils.copyOf(intArray40);
        int int42 = org.apache.commons.math.util.MathUtils.distance1(intArray33, intArray41);
        double double43 = org.apache.commons.math.util.MathUtils.distance(intArray26, intArray41);
        try {
            int int44 = org.apache.commons.math.util.MathUtils.distanceInf(intArray12, intArray26);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test132");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(1.5706487647081802d, (-12700.0d), 771);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test133");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) 1090L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test134");
        double double1 = org.apache.commons.math.util.FastMath.tanh(144.99655168313487d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test135");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 'a', 90L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 7L + "'", long2 == 7L);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test136");
        float float2 = org.apache.commons.math.util.FastMath.max(0.0f, (float) (byte) -1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test137");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 1100, (long) 52);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1100L + "'", long2 == 1100L);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test138");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.028563657838759995d, (java.lang.Number) 97, 11);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext4 = nonMonotonousSequenceException3.getContext();
        java.util.Set<java.lang.String> strSet5 = exceptionContext4.getKeys();
        org.junit.Assert.assertNotNull(exceptionContext4);
        org.junit.Assert.assertNotNull(strSet5);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test139");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(0.8414443185301054d, 0.8414443185301054d, 1.5707963259628248d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test140");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0f, (float) (byte) 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test141");
        double double1 = org.apache.commons.math.util.FastMath.log(57.29577951308232d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.0482269650408105d + "'", double1 == 4.0482269650408105d);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test142");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.setMaximalCount((-1));
        incrementor0.setMaximalCount(1100);
        incrementor0.incrementCount();
        java.lang.Class<?> wildcardClass6 = incrementor0.getClass();
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test143");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 1L, 1100.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test144");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 7);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9459101490553132d + "'", double1 == 1.9459101490553132d);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test145");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.0d, (double) 2060517870);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test146");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 61);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test147");
        double double2 = org.apache.commons.math.util.FastMath.copySign((-279305.0d), 0.9914714639237341d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 279305.0d + "'", double2 == 279305.0d);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test148");
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext0 = new org.apache.commons.math.exception.util.ExceptionContext();
        java.util.Set<java.lang.String> strSet1 = exceptionContext0.getKeys();
        java.util.Set<java.lang.String> strSet2 = exceptionContext0.getKeys();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.SINGULAR_MATRIX;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_WEIGHT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats19 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_INCREMENT_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS;
        java.lang.Object[] objArray20 = new java.lang.Object[] { 0, 0.0d, localizedFormats16, 81.55795945611504d, 10.0d, localizedFormats19 };
        org.apache.commons.math.exception.NoBracketingException noBracketingException21 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats9, (double) (-1L), (double) ' ', (double) 100L, (double) (short) 10, objArray20);
        org.apache.commons.math.exception.NoBracketingException noBracketingException22 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats4, (-1.4309082844072307d), 22026.465794806718d, (-0.12408049872194353d), 52.0d, objArray20);
        exceptionContext0.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats3, objArray20);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats24 = org.apache.commons.math.exception.util.LocalizedFormats.COVARIANCE_MATRIX;
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats27 = org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats30 = org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM;
        java.lang.Object[] objArray33 = new java.lang.Object[] { localizedFormats27, (-1), 0, localizedFormats30, 10.0d, (byte) 100 };
        java.lang.Object[] objArray34 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray33);
        java.lang.Object[] objArray35 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray33);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException36 = new org.apache.commons.math.exception.MaxCountExceededException(localizable25, (java.lang.Number) 32.000004f, objArray33);
        exceptionContext0.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats24, objArray33);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats38 = org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats39 = org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_32_BITS;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException41 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats39, (java.lang.Number) 11.0d);
        java.lang.Throwable[] throwableArray42 = notStrictlyPositiveException41.getSuppressed();
        exceptionContext0.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats38, (java.lang.Object[]) throwableArray42);
        java.lang.Object obj45 = exceptionContext0.getValue("initial row {1} after final row {0}");
        java.lang.Object obj47 = exceptionContext0.getValue("Abscissa {0} is duplicated at both indices {1} and {2}");
        org.junit.Assert.assertNotNull(strSet1);
        org.junit.Assert.assertNotNull(strSet2);
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SINGULAR_MATRIX + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.SINGULAR_MATRIX));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_WEIGHT + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_WEIGHT));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS + "'", localizedFormats9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS));
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER + "'", localizedFormats16.equals(org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER));
        org.junit.Assert.assertTrue("'" + localizedFormats19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_INCREMENT_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS + "'", localizedFormats19.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_INCREMENT_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS));
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertTrue("'" + localizedFormats24 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.COVARIANCE_MATRIX + "'", localizedFormats24.equals(org.apache.commons.math.exception.util.LocalizedFormats.COVARIANCE_MATRIX));
        org.junit.Assert.assertTrue("'" + localizedFormats27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY + "'", localizedFormats27.equals(org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY));
        org.junit.Assert.assertTrue("'" + localizedFormats30 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM + "'", localizedFormats30.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM));
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertTrue("'" + localizedFormats38 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizedFormats38.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertTrue("'" + localizedFormats39 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_32_BITS + "'", localizedFormats39.equals(org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_32_BITS));
        org.junit.Assert.assertNotNull(throwableArray42);
        org.junit.Assert.assertNull(obj45);
        org.junit.Assert.assertNull(obj47);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test149");
        double double1 = org.apache.commons.math.util.FastMath.floor(2005.3522829578812d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2005.0d + "'", double1 == 2005.0d);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test150");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, (-0.5595106570525964d));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test151");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.028563657838759995d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.16900786324535316d + "'", double1 == 0.16900786324535316d);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test152");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException(5.267884728309446d, (double) 3628800L, 8.96280949311433d, (double) 18);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test153");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) ' ');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 32 + "'", int1 == 32);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test154");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((int) '#', 52000);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: must have n >= k for binomial coefficient (n, k), got k = 52,000, n = 35");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test155");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.0d), (java.lang.Number) 10.04987562112089d, (int) (byte) 0, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        int int7 = nonMonotonousSequenceException5.getIndex();
        int int8 = nonMonotonousSequenceException5.getIndex();
        org.junit.Assert.assertNull(orderDirection6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test156");
        double[] doubleArray3 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray3);
        double[] doubleArray6 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, 100.0d);
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray3, (int) (byte) 1);
        double[] doubleArray12 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray12);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, 100.0d);
        double[] doubleArray19 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray19);
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, 100.0d);
        double[] doubleArray24 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray19, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray24);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray15, doubleArray24);
        java.lang.Number number27 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection30 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException32 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number27, (java.lang.Number) 132.0d, 6, orderDirection30, false);
        boolean boolean35 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray15, orderDirection30, false, false);
        double double36 = org.apache.commons.math.util.MathUtils.distance1(doubleArray8, doubleArray15);
        int int37 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        double[] doubleArray41 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray41);
        double[] doubleArray44 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray41, 100.0d);
        double[] doubleArray45 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray41);
        double double46 = org.apache.commons.math.util.MathUtils.distance(doubleArray15, doubleArray45);
        double[] doubleArray50 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray50);
        double[] doubleArray53 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray50, 100.0d);
        double[] doubleArray55 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray50, (int) (byte) 1);
        double[] doubleArray59 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray59);
        double[] doubleArray62 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray59, 100.0d);
        double[] doubleArray66 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray66);
        double[] doubleArray69 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray66, 100.0d);
        double[] doubleArray71 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray66, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray71);
        boolean boolean73 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray62, doubleArray71);
        java.lang.Number number74 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection77 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException79 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number74, (java.lang.Number) 132.0d, 6, orderDirection77, false);
        boolean boolean82 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray62, orderDirection77, false, false);
        double double83 = org.apache.commons.math.util.MathUtils.distance1(doubleArray55, doubleArray62);
        int int84 = org.apache.commons.math.util.MathUtils.hash(doubleArray62);
        double[] doubleArray88 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray88);
        double[] doubleArray91 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray88, 100.0d);
        double[] doubleArray92 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray88);
        double double93 = org.apache.commons.math.util.MathUtils.distance(doubleArray62, doubleArray92);
        double double94 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray45, doubleArray62);
        double double95 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + orderDirection30 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection30.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 18.20689655172414d + "'", double36 == 18.20689655172414d);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1201819478) + "'", int37 == (-1201819478));
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 82.49803802661121d + "'", double46 == 82.49803802661121d);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + orderDirection77 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection77.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + true + "'", boolean82 == true);
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + 18.20689655172414d + "'", double83 == 18.20689655172414d);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + (-1201819478) + "'", int84 == (-1201819478));
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertNotNull(doubleArray91);
        org.junit.Assert.assertNotNull(doubleArray92);
        org.junit.Assert.assertTrue("'" + double93 + "' != '" + 82.49803802661121d + "'", double93 == 82.49803802661121d);
        org.junit.Assert.assertTrue("'" + double94 + "' != '" + 56.89655172413793d + "'", double94 == 56.89655172413793d);
        org.junit.Assert.assertTrue("'" + double95 + "' != '" + 62.49851365652365d + "'", double95 == 62.49851365652365d);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test157");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_COST_RELATIVE_TOLERANCE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.NO_DENSITY_FOR_THIS_DISTRIBUTION;
        java.lang.Throwable throwable7 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM;
        java.lang.Object[] objArray11 = new java.lang.Object[] { localizedFormats9, 52L };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException12 = new org.apache.commons.math.exception.MathIllegalStateException(throwable7, (org.apache.commons.math.exception.util.Localizable) localizedFormats8, objArray11);
        org.apache.commons.math.exception.NoBracketingException noBracketingException13 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, (double) (byte) 10, 0.0d, 11.04987562112089d, (double) (byte) 100, objArray11);
        java.lang.Object[] objArray14 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray11);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException15 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1.80006593694412058E18d, objArray11);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_COST_RELATIVE_TOLERANCE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_COST_RELATIVE_TOLERANCE));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_DENSITY_FOR_THIS_DISTRIBUTION + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_DENSITY_FOR_THIS_DISTRIBUTION));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM + "'", localizedFormats9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(objArray14);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test158");
        double[] doubleArray3 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray3);
        double[] doubleArray6 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, 100.0d);
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray3, (int) (byte) 1);
        double[] doubleArray12 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray12);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, 100.0d);
        double[] doubleArray19 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray19);
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, 100.0d);
        double[] doubleArray24 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray19, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray24);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray15, doubleArray24);
        java.lang.Number number27 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection30 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException32 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number27, (java.lang.Number) 132.0d, 6, orderDirection30, false);
        boolean boolean35 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray15, orderDirection30, false, false);
        double double36 = org.apache.commons.math.util.MathUtils.distance1(doubleArray8, doubleArray15);
        int int37 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        double[] doubleArray41 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray41);
        double[] doubleArray44 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray41, 100.0d);
        double[] doubleArray45 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray41);
        double double46 = org.apache.commons.math.util.MathUtils.distance(doubleArray15, doubleArray45);
        double[] doubleArray48 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, 58.351573254317536d);
        double[] doubleArray52 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray52);
        double[] doubleArray55 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray52, 100.0d);
        int int56 = org.apache.commons.math.util.MathUtils.hash(doubleArray55);
        double[] doubleArray60 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray60);
        double[] doubleArray63 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray60, 100.0d);
        boolean boolean64 = org.apache.commons.math.util.MathUtils.equals(doubleArray55, doubleArray60);
        double[] doubleArray68 = new double[] { 9.332621544395286E157d, 9.332621544395286E157d, 770 };
        double[] doubleArray72 = new double[] { 9.332621544395286E157d, 9.332621544395286E157d, 770 };
        double[][] doubleArray73 = new double[][] { doubleArray68, doubleArray72 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray60, doubleArray73);
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray15, doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + orderDirection30 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection30.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 18.20689655172414d + "'", double36 == 18.20689655172414d);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1201819478) + "'", int37 == (-1201819478));
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 82.49803802661121d + "'", double46 == 82.49803802661121d);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + (-1201819478) + "'", int56 == (-1201819478));
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray73);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test159");
        double double1 = org.apache.commons.math.util.FastMath.ceil(3.1003275537854505E-17d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test160");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 101L, 1.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 101.0f + "'", float2 == 101.0f);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test161");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(8.96280949311433d, 3.1366342700391465E18d, 20.798314057214018d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test162");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_32_BITS;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 11.0d);
        boolean boolean3 = notStrictlyPositiveException2.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_32_BITS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_32_BITS));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test163");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 2.04175667E9f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.563537645096192E7d + "'", double1 == 3.563537645096192E7d);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test164");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (-127));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: exponent (-127)");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test165");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 2.2250738585072014E-308d, (java.lang.Number) 0.02051113020245179d, false);
        org.apache.commons.math.exception.MathInternalError mathInternalError4 = new org.apache.commons.math.exception.MathInternalError((java.lang.Throwable) numberIsTooSmallException3);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test166");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(4.822399275321542E13d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.416674520014944E11d + "'", double1 == 8.416674520014944E11d);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test167");
        double double1 = org.apache.commons.math.util.FastMath.tanh((-27.03274004183787d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test168");
        double[] doubleArray3 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray3);
        double[] doubleArray6 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, 100.0d);
        double[] doubleArray10 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray10);
        double[] doubleArray13 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray10, 100.0d);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray10, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray15);
        boolean boolean17 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray15);
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray6);
        int int19 = org.apache.commons.math.util.MathUtils.hash(doubleArray18);
        double[] doubleArray23 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray23);
        double[] doubleArray26 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray23, 100.0d);
        double[] doubleArray30 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray30);
        double[] doubleArray33 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray30, 100.0d);
        double[] doubleArray35 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray30, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray35);
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray26, doubleArray35);
        double[] doubleArray38 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray26);
        int int39 = org.apache.commons.math.util.MathUtils.hash(doubleArray38);
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray18, doubleArray38);
        double[] doubleArray44 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray44);
        double[] doubleArray47 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray44, 100.0d);
        double[] doubleArray51 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray51);
        double[] doubleArray54 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray51, 100.0d);
        double[] doubleArray56 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray51, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray56);
        boolean boolean58 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray47, doubleArray56);
        double[] doubleArray59 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray47);
        double double60 = org.apache.commons.math.util.MathUtils.distance1(doubleArray38, doubleArray59);
        double[] doubleArray61 = null;
        double[] doubleArray67 = new double[] { (byte) 100, 81.55795945611504d, 1.0d, 100.0d, (-1) };
        boolean boolean68 = org.apache.commons.math.util.MathUtils.equals(doubleArray61, doubleArray67);
        double[] doubleArray69 = null;
        double[] doubleArray75 = new double[] { (byte) 100, 81.55795945611504d, 1.0d, 100.0d, (-1) };
        boolean boolean76 = org.apache.commons.math.util.MathUtils.equals(doubleArray69, doubleArray75);
        double double77 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray67, doubleArray75);
        try {
            double double78 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray38, doubleArray67);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 3 != 5");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1201819478) + "'", int19 == (-1201819478));
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1201819478) + "'", int39 == (-1201819478));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 0.0d + "'", double77 == 0.0d);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test169");
        long long2 = org.apache.commons.math.util.FastMath.max(97L, (long) 771);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 771L + "'", long2 == 771L);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test170");
        double double2 = org.apache.commons.math.util.FastMath.IEEEremainder((double) 870L, 10.049875621120892d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-4.33917903751758d) + "'", double2 == (-4.33917903751758d));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test171");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 196L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test172");
        double double1 = org.apache.commons.math.util.FastMath.asin(1.4210854715202004E-14d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4210854715202004E-14d + "'", double1 == 1.4210854715202004E-14d);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test173");
        float float1 = org.apache.commons.math.util.FastMath.ulp((float) ' ');
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 3.8146973E-6f + "'", float1 == 3.8146973E-6f);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test174");
        int[] intArray0 = new int[] {};
        int[] intArray6 = new int[] { (short) 100, 100, (byte) 10, (byte) 1, (byte) -1 };
        int[] intArray7 = org.apache.commons.math.util.MathUtils.copyOf(intArray6);
        int int8 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray7);
        int[] intArray10 = org.apache.commons.math.util.MathUtils.copyOf(intArray7, 97);
        int[] intArray12 = org.apache.commons.math.util.MathUtils.copyOf(intArray7, 5200);
        try {
            int[] intArray14 = org.apache.commons.math.util.MathUtils.copyOf(intArray7, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray12);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test175");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver0 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        int int1 = regulaFalsiSolver0.getMaxEvaluations();
        double double2 = regulaFalsiSolver0.getStartValue();
        double double3 = regulaFalsiSolver0.getRelativeAccuracy();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction5 = null;
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution9 = org.apache.commons.math.analysis.solvers.AllowedSolution.RIGHT_SIDE;
        try {
            double double10 = regulaFalsiSolver0.solve(0, univariateRealFunction5, 3628800.0d, 0.0d, 9.999999999999998d, allowedSolution9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E-14d + "'", double3 == 1.0E-14d);
        org.junit.Assert.assertTrue("'" + allowedSolution9 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.RIGHT_SIDE + "'", allowedSolution9.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.RIGHT_SIDE));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test176");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.0d, 0.27684597255769317d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.9E-324d + "'", double2 == 4.9E-324d);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test177");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.0826587809999998E9d, 8.96280949311433d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test178");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(10, 2060517870);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test179");
        double[] doubleArray0 = null;
        try {
            double[] doubleArray2 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test180");
        double double1 = org.apache.commons.math.util.FastMath.expm1(20.798314057214018d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0779361270000014E9d + "'", double1 == 1.0779361270000014E9d);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test181");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) 10L, (float) 101L, 2041756729);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test182");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) (-127));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-127.0d) + "'", double1 == (-127.0d));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test183");
        float float1 = org.apache.commons.math.util.FastMath.ulp(1.08265882E9f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 128.0f + "'", float1 == 128.0f);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test184");
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext0 = new org.apache.commons.math.exception.util.ExceptionContext();
        java.util.Set<java.lang.String> strSet1 = exceptionContext0.getKeys();
        java.util.Set<java.lang.String> strSet2 = exceptionContext0.getKeys();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.SINGULAR_MATRIX;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_WEIGHT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats19 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_INCREMENT_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS;
        java.lang.Object[] objArray20 = new java.lang.Object[] { 0, 0.0d, localizedFormats16, 81.55795945611504d, 10.0d, localizedFormats19 };
        org.apache.commons.math.exception.NoBracketingException noBracketingException21 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats9, (double) (-1L), (double) ' ', (double) 100L, (double) (short) 10, objArray20);
        org.apache.commons.math.exception.NoBracketingException noBracketingException22 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats4, (-1.4309082844072307d), 22026.465794806718d, (-0.12408049872194353d), 52.0d, objArray20);
        exceptionContext0.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats3, objArray20);
        exceptionContext0.setValue("", (java.lang.Object) 993.8153752080916d);
        exceptionContext0.setValue("org.apache.commons.math.exception.MathInternalError: internal error, please fill a bug report at https://issues.apache.org/jira/browse/MATH", (java.lang.Object) 27.30822632959398d);
        org.junit.Assert.assertNotNull(strSet1);
        org.junit.Assert.assertNotNull(strSet2);
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SINGULAR_MATRIX + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.SINGULAR_MATRIX));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_WEIGHT + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_WEIGHT));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS + "'", localizedFormats9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS));
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER + "'", localizedFormats16.equals(org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER));
        org.junit.Assert.assertTrue("'" + localizedFormats19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_INCREMENT_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS + "'", localizedFormats19.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_INCREMENT_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS));
        org.junit.Assert.assertNotNull(objArray20);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test185");
        float float2 = org.apache.commons.math.util.FastMath.scalb((float) 9999L, 1201819575);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + Float.POSITIVE_INFINITY + "'", float2 == Float.POSITIVE_INFINITY);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test186");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 1201819575, 900, 196);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathIllegalArgumentException; message: invalid rounding method 196, valid methods: ROUND_CEILING (2), ROUND_DOWN (1), ROUND_FLOOR (3), ROUND_HALF_DOWN (5), ROUND_HALF_EVEN (6), ROUND_HALF_UP (4), ROUND_UNNECESSARY (7), ROUND_UP (0)");
        } catch (org.apache.commons.math.exception.MathIllegalArgumentException e) {
        }
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test187");
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifySequence((double) 1.0f, 81.55795945611504d, (double) (-1201819478));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [81.558, -1,201,819,478]");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test188");
        int[] intArray5 = new int[] { (short) 100, 100, (byte) 10, (byte) 1, (byte) -1 };
        int[] intArray6 = org.apache.commons.math.util.MathUtils.copyOf(intArray5);
        int[] intArray9 = new int[] { 99, 'a' };
        int[] intArray15 = new int[] { (short) 100, 100, (byte) 10, (byte) 1, (byte) -1 };
        int[] intArray16 = org.apache.commons.math.util.MathUtils.copyOf(intArray15);
        int int17 = org.apache.commons.math.util.MathUtils.distance1(intArray9, intArray15);
        int[] intArray19 = org.apache.commons.math.util.MathUtils.copyOf(intArray15, 770);
        double double20 = org.apache.commons.math.util.MathUtils.distance(intArray6, intArray19);
        int[] intArray21 = org.apache.commons.math.util.MathUtils.copyOf(intArray19);
        int[] intArray22 = org.apache.commons.math.util.MathUtils.copyOf(intArray21);
        int[] intArray25 = new int[] { 99, 'a' };
        int[] intArray31 = new int[] { (short) 100, 100, (byte) 10, (byte) 1, (byte) -1 };
        int[] intArray32 = org.apache.commons.math.util.MathUtils.copyOf(intArray31);
        int int33 = org.apache.commons.math.util.MathUtils.distance1(intArray25, intArray31);
        int[] intArray36 = new int[] { 99, 'a' };
        int[] intArray42 = new int[] { (short) 100, 100, (byte) 10, (byte) 1, (byte) -1 };
        int[] intArray43 = org.apache.commons.math.util.MathUtils.copyOf(intArray42);
        int int44 = org.apache.commons.math.util.MathUtils.distance1(intArray36, intArray42);
        int[] intArray50 = new int[] { (short) 100, 100, (byte) 10, (byte) 1, (byte) -1 };
        int[] intArray51 = org.apache.commons.math.util.MathUtils.copyOf(intArray50);
        double double52 = org.apache.commons.math.util.MathUtils.distance(intArray42, intArray51);
        int int53 = org.apache.commons.math.util.MathUtils.distance1(intArray25, intArray42);
        int[] intArray56 = new int[] { 99, 'a' };
        int[] intArray62 = new int[] { (short) 100, 100, (byte) 10, (byte) 1, (byte) -1 };
        int[] intArray63 = org.apache.commons.math.util.MathUtils.copyOf(intArray62);
        int int64 = org.apache.commons.math.util.MathUtils.distance1(intArray56, intArray62);
        int[] intArray66 = org.apache.commons.math.util.MathUtils.copyOf(intArray56, 9);
        double double67 = org.apache.commons.math.util.MathUtils.distance(intArray25, intArray56);
        try {
            int int68 = org.apache.commons.math.util.MathUtils.distance1(intArray21, intArray56);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 4 + "'", int17 == 4);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 4 + "'", int44 == 4);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 4 + "'", int53 == 4);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertNotNull(intArray62);
        org.junit.Assert.assertNotNull(intArray63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 4 + "'", int64 == 4);
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test189");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 1077936159);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.384185791015625E-7d + "'", double1 == 2.384185791015625E-7d);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test190");
        double[] doubleArray3 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray3);
        double[] doubleArray6 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, 100.0d);
        double[] doubleArray7 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray3);
        double[] doubleArray8 = null;
        boolean boolean9 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray8);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.028563657838759995d, (java.lang.Number) 97, 11);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection17 = nonMonotonousSequenceException16.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 32.000004f, (java.lang.Number) 100L, (int) (short) 0, orderDirection17, true);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7, orderDirection17, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (100 >= 100)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + orderDirection17 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection17.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test191");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(900, (int) ' ');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 135.5610173213613d + "'", double2 == 135.5610173213613d);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test192");
        float float2 = org.apache.commons.math.util.FastMath.copySign((float) '#', (float) 35);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 35.0f + "'", float2 == 35.0f);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test193");
        double double1 = org.apache.commons.math.util.FastMath.acosh(23151.906933686558d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.742979609160876d + "'", double1 == 10.742979609160876d);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test194");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0f, (float) 1000L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test195");
        int[] intArray0 = new int[] {};
        int[] intArray6 = new int[] { (short) 100, 100, (byte) 10, (byte) 1, (byte) -1 };
        int[] intArray7 = org.apache.commons.math.util.MathUtils.copyOf(intArray6);
        int int8 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray7);
        int[] intArray14 = new int[] { (short) 100, 100, (byte) 10, (byte) 1, (byte) -1 };
        int[] intArray15 = org.apache.commons.math.util.MathUtils.copyOf(intArray14);
        double double16 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray14);
        int[] intArray17 = null;
        try {
            int int18 = org.apache.commons.math.util.MathUtils.distanceInf(intArray14, intArray17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test196");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(11013.232874703393d, 1.0826587809999998E9d, (double) (byte) 0);
        int int4 = regulaFalsiSolver3.getMaxEvaluations();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test197");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 996176991L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.96176991E8d + "'", double1 == 9.96176991E8d);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test198");
        double[] doubleArray3 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray3);
        double[] doubleArray8 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray8);
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray8, 100.0d);
        double double12 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray3, doubleArray8);
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray8);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray8, orderDirection14, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (100 >= 100)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 21024.0d + "'", double12 == 21024.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 144.99655168313487d + "'", double13 == 144.99655168313487d);
        org.junit.Assert.assertTrue("'" + orderDirection14 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection14.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test199");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(7.600902709541988d, 2.958103478741511E26d);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction4 = null;
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction8 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver9 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        double double10 = regulaFalsiSolver9.getMin();
        double double11 = regulaFalsiSolver9.getFunctionValueAccuracy();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction16 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver20 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(52.0d, 90.0d, 6.617416307822852E84d);
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution24 = org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE;
        double double25 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide(0, univariateRealFunction16, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver20, (double) (short) 1, 11013.232874703393d, 1.0076685815103525d, allowedSolution24);
        double double26 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide(127, univariateRealFunction8, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver9, 5.298292365610485d, 2.718281828459045d, 1.1920928955078125E-7d, allowedSolution24);
        try {
            double double27 = regulaFalsiSolver2.solve(4, univariateRealFunction4, (double) 56693912375296L, (-1.0d), allowedSolution24);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0E-15d + "'", double11 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + allowedSolution24 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE + "'", allowedSolution24.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE));
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 5.298292365610485d + "'", double26 == 5.298292365610485d);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test200");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 1.4E-45f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.401298464324817E-45d + "'", double1 == 1.401298464324817E-45d);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test201");
        double double1 = org.apache.commons.math.util.FastMath.atan((-0.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test202");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 3.13663427E18f, 3.1366338920820244E18d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.1366342700391465E18d + "'", double2 == 3.1366342700391465E18d);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test203");
        double double6 = org.apache.commons.math.util.MathUtils.linearCombination(9.999999999999998d, 0.0d, 0.0d, 2.094712489436101d, 23151.906933686558d, 32.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 740861.0218779698d + "'", double6 == 740861.0218779698d);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test204");
        double double6 = org.apache.commons.math.util.MathUtils.linearCombination(1227.2200291716233d, (double) 2, (double) 99L, 0.0d, (double) 52, 3.311419785216E12d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.7219382883368644E14d + "'", double6 == 1.7219382883368644E14d);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test205");
        double double2 = org.apache.commons.math.util.FastMath.max(32.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 32.0d + "'", double2 == 32.0d);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test206");
        double double1 = org.apache.commons.math.util.FastMath.floor(22025.465794806718d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22025.0d + "'", double1 == 22025.0d);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test207");
        double double2 = org.apache.commons.math.util.FastMath.IEEEremainder(3.0d, 0.0d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test208");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 97, (long) (byte) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 96L + "'", long2 == 96L);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test209");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(Double.POSITIVE_INFINITY, (double) 870L, (double) 10000L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test210");
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifySequence(9.0d, 0.0d, (double) (-1L));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [9, 0]");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test211");
        int[] intArray2 = new int[] { 99, 'a' };
        int[] intArray8 = new int[] { (short) 100, 100, (byte) 10, (byte) 1, (byte) -1 };
        int[] intArray9 = org.apache.commons.math.util.MathUtils.copyOf(intArray8);
        int int10 = org.apache.commons.math.util.MathUtils.distance1(intArray2, intArray8);
        int[] intArray16 = new int[] { (short) 100, 100, (byte) 10, (byte) 1, (byte) -1 };
        int[] intArray17 = org.apache.commons.math.util.MathUtils.copyOf(intArray16);
        int[] intArray23 = new int[] { (short) 100, 100, (byte) 10, (byte) 1, (byte) -1 };
        int[] intArray24 = org.apache.commons.math.util.MathUtils.copyOf(intArray23);
        int int25 = org.apache.commons.math.util.MathUtils.distance1(intArray16, intArray24);
        int[] intArray26 = new int[] {};
        int[] intArray32 = new int[] { (short) 100, 100, (byte) 10, (byte) 1, (byte) -1 };
        int[] intArray33 = org.apache.commons.math.util.MathUtils.copyOf(intArray32);
        int int34 = org.apache.commons.math.util.MathUtils.distance1(intArray26, intArray33);
        int[] intArray36 = org.apache.commons.math.util.MathUtils.copyOf(intArray33, 97);
        int[] intArray38 = org.apache.commons.math.util.MathUtils.copyOf(intArray33, 5200);
        int int39 = org.apache.commons.math.util.MathUtils.distance1(intArray24, intArray38);
        int[] intArray45 = new int[] { (short) 100, 100, (byte) 10, (byte) 1, (byte) -1 };
        int[] intArray46 = org.apache.commons.math.util.MathUtils.copyOf(intArray45);
        int[] intArray49 = new int[] { 99, 'a' };
        int[] intArray55 = new int[] { (short) 100, 100, (byte) 10, (byte) 1, (byte) -1 };
        int[] intArray56 = org.apache.commons.math.util.MathUtils.copyOf(intArray55);
        int int57 = org.apache.commons.math.util.MathUtils.distance1(intArray49, intArray55);
        int[] intArray59 = org.apache.commons.math.util.MathUtils.copyOf(intArray55, 770);
        double double60 = org.apache.commons.math.util.MathUtils.distance(intArray46, intArray59);
        int int61 = org.apache.commons.math.util.MathUtils.distanceInf(intArray24, intArray59);
        int int62 = org.apache.commons.math.util.MathUtils.distanceInf(intArray8, intArray59);
        int[] intArray63 = org.apache.commons.math.util.MathUtils.copyOf(intArray59);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 4 + "'", int57 == 4);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertNotNull(intArray63);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test212");
        double double1 = org.apache.commons.math.util.FastMath.rint(100.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1 == 100.0d);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test213");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray5 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, 32.0d, (double) 1992353982, (-0.6258392201887784d), (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test214");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NO_DENSITY_FOR_THIS_DISTRIBUTION;
        java.lang.Throwable throwable5 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM;
        java.lang.Object[] objArray9 = new java.lang.Object[] { localizedFormats7, 52L };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException10 = new org.apache.commons.math.exception.MathIllegalStateException(throwable5, (org.apache.commons.math.exception.util.Localizable) localizedFormats6, objArray9);
        org.apache.commons.math.exception.NoBracketingException noBracketingException11 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (double) (byte) 10, 0.0d, 11.04987562112089d, (double) (byte) 100, objArray9);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_WEIGHT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats17 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats24 = org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats27 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_INCREMENT_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS;
        java.lang.Object[] objArray28 = new java.lang.Object[] { 0, 0.0d, localizedFormats24, 81.55795945611504d, 10.0d, localizedFormats27 };
        org.apache.commons.math.exception.NoBracketingException noBracketingException29 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats17, (double) (-1L), (double) ' ', (double) 100L, (double) (short) 10, objArray28);
        org.apache.commons.math.exception.NoBracketingException noBracketingException30 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats12, (-1.4309082844072307d), 22026.465794806718d, (-0.12408049872194353d), 52.0d, objArray28);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException31 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray28);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext32 = mathArithmeticException31.getContext();
        java.util.Set<java.lang.String> strSet33 = exceptionContext32.getKeys();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_DENSITY_FOR_THIS_DISTRIBUTION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_DENSITY_FOR_THIS_DISTRIBUTION));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM));
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_WEIGHT + "'", localizedFormats12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_WEIGHT));
        org.junit.Assert.assertTrue("'" + localizedFormats17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS + "'", localizedFormats17.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS));
        org.junit.Assert.assertTrue("'" + localizedFormats24 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER + "'", localizedFormats24.equals(org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER));
        org.junit.Assert.assertTrue("'" + localizedFormats27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_INCREMENT_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS + "'", localizedFormats27.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_INCREMENT_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS));
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertNotNull(exceptionContext32);
        org.junit.Assert.assertNotNull(strSet33);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test215");
        double[] doubleArray0 = null;
        double[] doubleArray6 = new double[] { (byte) 100, 81.55795945611504d, 1.0d, 100.0d, (-1) };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray6);
        double[] doubleArray8 = null;
        double[] doubleArray14 = new double[] { (byte) 100, 81.55795945611504d, 1.0d, 100.0d, (-1) };
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray8, doubleArray14);
        double double16 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray6, doubleArray14);
        double[] doubleArray20 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray20);
        double[] doubleArray23 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray20, 100.0d);
        double[] doubleArray25 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray20, (int) (byte) 1);
        double[] doubleArray29 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray29);
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray29, 100.0d);
        double[] doubleArray36 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray36);
        double[] doubleArray39 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray36, 100.0d);
        double[] doubleArray41 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray36, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray41);
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray32, doubleArray41);
        java.lang.Number number44 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection47 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException49 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number44, (java.lang.Number) 132.0d, 6, orderDirection47, false);
        boolean boolean52 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray32, orderDirection47, false, false);
        double double53 = org.apache.commons.math.util.MathUtils.distance1(doubleArray25, doubleArray32);
        int int54 = org.apache.commons.math.util.MathUtils.hash(doubleArray32);
        double[] doubleArray58 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray58);
        double[] doubleArray61 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray58, 100.0d);
        double[] doubleArray62 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray58);
        double double63 = org.apache.commons.math.util.MathUtils.distance(doubleArray32, doubleArray62);
        boolean boolean64 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray32);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + orderDirection47 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection47.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 18.20689655172414d + "'", double53 == 18.20689655172414d);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1201819478) + "'", int54 == (-1201819478));
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 82.49803802661121d + "'", double63 == 82.49803802661121d);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test216");
        double double1 = org.apache.commons.math.util.FastMath.cos(2.041756729E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9973954461310504d + "'", double1 == 0.9973954461310504d);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test217");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(0.0d, 0.0d, 3.311419785216E12d);
        double double4 = regulaFalsiSolver3.getMin();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test218");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 3.136634E18f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.1366339951612396E18d + "'", double1 == 3.1366339951612396E18d);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test219");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5430806348152437d + "'", double1 == 1.5430806348152437d);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test220");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double double3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(univariateRealFunction0, 0.0d, (double) 3.9999998f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test221");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 59546234880L, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.NEGATIVE_INFINITY + "'", double2 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test222");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 4.768372E-7f, (java.lang.Number) 1.7763568394002505E-15d, 412103574);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test223");
        double double1 = org.apache.commons.math.util.FastMath.log1p(3.1366338920820244E18d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 42.58968188990939d + "'", double1 == 42.58968188990939d);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test224");
        float float2 = org.apache.commons.math.util.FastMath.nextAfter((-1.0f), 2005.3522829578812d);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-0.99999994f) + "'", float2 == (-0.99999994f));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test225");
        double double2 = org.apache.commons.math.util.MathUtils.log(1.9459101490553132d, 3.5553481704807584d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.9053570631129d + "'", double2 == 1.9053570631129d);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test226");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(2005.3522829578812d, (double) 30, (double) 3.136634E18f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test227");
        double double3 = org.apache.commons.math.util.MathUtils.reduce(22026.465794806718d, 0.0d, (double) 6);
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test228");
        double[] doubleArray3 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray3);
        double[] doubleArray6 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, 100.0d);
        double[] doubleArray7 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray3);
        double double8 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 144.99655168313487d + "'", double8 == 144.99655168313487d);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test229");
        double double2 = org.apache.commons.math.util.MathUtils.round((double) 11, 139);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 11.0d + "'", double2 == 11.0d);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test230");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(3.3683149054752465E35d, (double) 720L, 9.53674316406539E-7d);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test231");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.0E-15d, (java.lang.Number) (-0.8414709848078965d), 99, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        boolean boolean7 = nonMonotonousSequenceException5.getStrict();
        int int8 = nonMonotonousSequenceException5.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 99 + "'", int8 == 99);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test232");
        double double2 = org.apache.commons.math.util.FastMath.min((-8.648179E7d), 2.948083443515392E15d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-8.648179E7d) + "'", double2 == (-8.648179E7d));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test233");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(7.340835974686194d, (double) 0L, 52.0d);
        int int4 = regulaFalsiSolver3.getEvaluations();
        double double5 = regulaFalsiSolver3.getStartValue();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction7 = null;
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution11 = org.apache.commons.math.analysis.solvers.AllowedSolution.BELOW_SIDE;
        try {
            double double12 = regulaFalsiSolver3.solve(196, univariateRealFunction7, (double) 2041756729, 0.6725571839577216d, (-2.2239800905693157d), allowedSolution11);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + allowedSolution11 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.BELOW_SIDE + "'", allowedSolution11.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.BELOW_SIDE));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test234");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException((double) 25937424601L, 3.7964298396389114E252d, 0.0d, 0.0d);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test235");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) 110);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.960486013832335E47d + "'", double1 == 2.960486013832335E47d);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test236");
        float float3 = org.apache.commons.math.util.MathUtils.round((float) 59546234880L, (int) '4', 1);
        org.junit.Assert.assertEquals((float) float3, Float.NaN, 0);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test237");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(7.340835974686194d, (double) 0L, 52.0d);
        double double4 = regulaFalsiSolver3.getRelativeAccuracy();
        double double5 = regulaFalsiSolver3.getMin();
        double double6 = regulaFalsiSolver3.getMin();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 7.340835974686194d + "'", double4 == 7.340835974686194d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test238");
        int int2 = org.apache.commons.math.util.FastMath.min(10, 18);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test239");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 99);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test240");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 52000, (float) 18);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 18.0f + "'", float2 == 18.0f);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test241");
        double double2 = org.apache.commons.math.util.FastMath.scalb(200535.22829578814d, 1201819575);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test242");
        int int1 = org.apache.commons.math.util.FastMath.getExponent(18.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test243");
        double double1 = org.apache.commons.math.util.FastMath.expm1(1.5707963259628248d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.810477376962689d + "'", double1 == 3.810477376962689d);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test244");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) (-1201819478));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test245");
        double double2 = org.apache.commons.math.util.FastMath.copySign(9.96176991E8d, (double) 1.08265882E9f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.96176991E8d + "'", double2 == 9.96176991E8d);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test246");
        float float1 = org.apache.commons.math.util.FastMath.nextUp((-4.0f));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-3.9999998f) + "'", float1 == (-3.9999998f));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test247");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NO_RESULT_AVAILABLE;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 6);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_RESULT_AVAILABLE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_RESULT_AVAILABLE));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test248");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((-4.33917903751758d), (double) 1.08265869E9f, (-1023));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test249");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.DEGREES_OF_FREEDOM;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM;
        java.lang.Object[] objArray9 = new java.lang.Object[] { localizedFormats3, (-1), 0, localizedFormats6, 10.0d, (byte) 100 };
        java.lang.Object[] objArray10 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray9);
        java.lang.Object[] objArray11 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray9);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException12 = new org.apache.commons.math.exception.MaxCountExceededException(localizable1, (java.lang.Number) 32.000004f, objArray9);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException13 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray9);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext14 = mathArithmeticException13.getContext();
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver19 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(7.340835974686194d, (double) 0L, 52.0d);
        double double20 = regulaFalsiSolver19.getMin();
        exceptionContext14.setValue("", (java.lang.Object) double20);
        java.lang.Object obj23 = exceptionContext14.getValue("org.apache.commons.math.exception.NotFiniteNumberException: 0 is not a finite number");
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DEGREES_OF_FREEDOM + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.DEGREES_OF_FREEDOM));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM));
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(exceptionContext14);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNull(obj23);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test250");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(5.267884728309446d, (double) 720L, (double) 5040L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test251");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, (double) 4.53845888E8f, 4.9E-324d, (double) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test252");
        double double1 = org.apache.commons.math.util.FastMath.log10(2005.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.302114376956201d + "'", double1 == 3.302114376956201d);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test253");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 90L, 1.1920929E-7f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.1920929E-7f + "'", float2 == 1.1920929E-7f);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test254");
        double double1 = org.apache.commons.math.util.FastMath.abs(1.201819478E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.201819478E9d + "'", double1 == 1.201819478E9d);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test255");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM;
        java.lang.Object[] objArray7 = new java.lang.Object[] { localizedFormats1, (-1), 0, localizedFormats4, 10.0d, (byte) 100 };
        java.lang.Object[] objArray8 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray7);
        java.lang.Object[] objArray9 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray7);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException10 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 1.0779361614282227E9d, objArray9);
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM));
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(objArray9);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test256");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 9999L, 110, 1201819575);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathIllegalArgumentException; message: invalid rounding method 1,201,819,575, valid methods: ROUND_CEILING (2), ROUND_DOWN (1), ROUND_FLOOR (3), ROUND_HALF_DOWN (5), ROUND_HALF_EVEN (6), ROUND_HALF_UP (4), ROUND_UNNECESSARY (7), ROUND_UP (0)");
        } catch (org.apache.commons.math.exception.MathIllegalArgumentException e) {
        }
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test257");
        double double2 = org.apache.commons.math.util.FastMath.atan2(7.340835974686194d, (double) 870L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.008437542265098248d + "'", double2 == 0.008437542265098248d);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test258");
        int int2 = org.apache.commons.math.util.MathUtils.pow(127, 1201819575);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1675926399 + "'", int2 == 1675926399);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test259");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(2060517870, (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test260");
        float float2 = org.apache.commons.math.util.FastMath.min(3.3554432E7f, 128.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 128.0f + "'", float2 == 128.0f);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test261");
        float float2 = org.apache.commons.math.util.FastMath.scalb(3.8146973E-6f, 97);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 6.044629E23f + "'", float2 == 6.044629E23f);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test262");
        org.apache.commons.math.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math.exception.NotPositiveException((java.lang.Number) (-1.960323183182555E166d));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test263");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 127L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 127.0d + "'", double1 == 127.0d);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test264");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver0 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        double double1 = regulaFalsiSolver0.getMin();
        double double2 = regulaFalsiSolver0.getFunctionValueAccuracy();
        double double3 = regulaFalsiSolver0.getMin();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E-15d + "'", double2 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test265");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 1076101120, 9999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test266");
        double[] doubleArray3 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray3);
        double[] doubleArray6 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, 100.0d);
        double[] doubleArray10 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray10);
        double[] doubleArray13 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray10, 100.0d);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray10, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray15);
        boolean boolean17 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray15);
        java.lang.Number number18 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection21 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException23 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number18, (java.lang.Number) 132.0d, 6, orderDirection21, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray15, orderDirection21, true);
        double[] doubleArray29 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray29);
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray29, 100.0d);
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray29, (int) (byte) 1);
        double double35 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray15, doubleArray34);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection39 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException41 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.0E-15d, (java.lang.Number) (-0.8414709848078965d), 99, orderDirection39, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection42 = nonMonotonousSequenceException41.getDirection();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray15, orderDirection42, false);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + orderDirection21 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection21.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection39 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection39.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection42 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection42.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test267");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((-33.0f), 18.0f, (float) 127L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test268");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(90.0d, 4.0482269650408105d, 1201819575);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test269");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(1.42648876843535488E18d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.42648876843535514E18d + "'", double1 == 1.42648876843535514E18d);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test270");
        double double2 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.midpoint(5.298292365610486d, 3.5413887082388813d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.419840536924683d + "'", double2 == 4.419840536924683d);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test271");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(0, 52);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: must have n >= k for binomial coefficient (n, k), got k = 52, n = 0");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test272");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (byte) 10);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 10.0f + "'", float1 == 10.0f);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test273");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, 0.028563657838759995d, 2.094712489436101d, 3.7621956910836314d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test274");
        int int2 = org.apache.commons.math.util.FastMath.max(61, 7);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 61 + "'", int2 == 61);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test275");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) '4', (double) 1.1920929E-7f, 2.718281828459045d);
        int int4 = regulaFalsiSolver3.getEvaluations();
        double double5 = regulaFalsiSolver3.getMax();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test276");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(0.0d, 9.834532502485658E-6d, 0.0d);
        double double4 = regulaFalsiSolver3.getMin();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test277");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(1992353982, 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1992353992 + "'", int2 == 1992353992);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test278");
        double[] doubleArray0 = null;
        double[] doubleArray6 = new double[] { (byte) 100, 81.55795945611504d, 1.0d, 100.0d, (-1) };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray6);
        double[] doubleArray8 = null;
        double[] doubleArray14 = new double[] { (byte) 100, 81.55795945611504d, 1.0d, 100.0d, (-1) };
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray8, doubleArray14);
        double double16 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray6, doubleArray14);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray14);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (100 >= 81.558)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test279");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(11013.232874703393d, (double) 7710, (double) 7);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test280");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) (byte) -1, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.5707963267948966d) + "'", double2 == (-1.5707963267948966d));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test281");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 1.1920929E-7f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.6469779601696886E-23d + "'", double1 == 2.6469779601696886E-23d);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test282");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(0.0d, (double) 3.136634E18f, (double) 1.4E-45f);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test283");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(56693912375296L, (long) 453845888);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 56694366221184L + "'", long2 == 56694366221184L);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test284");
        double double2 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.midpoint(3.5413887082388813d, 2.948083443515392E15d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.4740417217576978E15d + "'", double2 == 1.4740417217576978E15d);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test285");
        int int1 = org.apache.commons.math.util.FastMath.getExponent((-0.99999994f));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test286");
        double[] doubleArray0 = null;
        double[] doubleArray6 = new double[] { (byte) 100, 81.55795945611504d, 1.0d, 100.0d, (-1) };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray6);
        double[] doubleArray8 = null;
        double[] doubleArray14 = new double[] { (byte) 100, 81.55795945611504d, 1.0d, 100.0d, (-1) };
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray8, doubleArray14);
        double double16 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray6, doubleArray14);
        double[] doubleArray20 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray20);
        double[] doubleArray23 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray20, 100.0d);
        double[] doubleArray27 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray27);
        double[] doubleArray30 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, 100.0d);
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray27, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray32);
        boolean boolean34 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray23, doubleArray32);
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray23);
        double[] doubleArray39 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray39);
        double[] doubleArray42 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray39, 100.0d);
        double double43 = org.apache.commons.math.util.MathUtils.distance(doubleArray23, doubleArray42);
        double[] doubleArray45 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray23, 0);
        double[] doubleArray49 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray49);
        double[] doubleArray52 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray49, 100.0d);
        int int53 = org.apache.commons.math.util.MathUtils.hash(doubleArray52);
        int int54 = org.apache.commons.math.util.MathUtils.hash(doubleArray52);
        double double55 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray23, doubleArray52);
        double double56 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-1201819478) + "'", int53 == (-1201819478));
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1201819478) + "'", int54 == (-1201819478));
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 62.49851365652365d + "'", double56 == 62.49851365652365d);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test287");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0f, (float) '4', (float) 7710);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test288");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 52.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 52.0d + "'", double1 == 52.0d);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test289");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        int int1 = incrementor0.getCount();
        int int2 = incrementor0.getMaximalCount();
        incrementor0.setMaximalCount((int) (byte) 100);
        incrementor0.incrementCount((int) (byte) -1);
        incrementor0.setMaximalCount(127);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test290");
        double double1 = org.apache.commons.math.util.FastMath.rint(3628800.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3628800.0d + "'", double1 == 3628800.0d);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test291");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-8934108775301215359L), 35L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathArithmeticException; message: arithmetic exception");
        } catch (org.apache.commons.math.exception.MathArithmeticException e) {
        }
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test292");
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math.exception.DimensionMismatchException(10, 33554432);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test293");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_DEFINING_VECTOR;
        java.lang.Class<?> wildcardClass1 = localizedFormats0.getClass();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_DEFINING_VECTOR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_DEFINING_VECTOR));
        org.junit.Assert.assertNotNull(wildcardClass1);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test294");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(4.0482269650408105d, 2.718281828459045d, (-1201819482));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test295");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) 1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test296");
        double[] doubleArray0 = null;
        double[] doubleArray6 = new double[] { (byte) 100, 81.55795945611504d, 1.0d, 100.0d, (-1) };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray6);
        double[] doubleArray8 = null;
        double[] doubleArray14 = new double[] { (byte) 100, 81.55795945611504d, 1.0d, 100.0d, (-1) };
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray8, doubleArray14);
        double double16 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray6, doubleArray14);
        double[] doubleArray20 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray20);
        double[] doubleArray23 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray20, 100.0d);
        double[] doubleArray27 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray27);
        double[] doubleArray30 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, 100.0d);
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray27, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray32);
        boolean boolean34 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray23, doubleArray32);
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray23);
        double[] doubleArray39 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray39);
        double[] doubleArray42 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray39, 100.0d);
        double[] doubleArray44 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray39, (int) (byte) 1);
        double[] doubleArray48 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray48);
        double[] doubleArray51 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray48, 100.0d);
        double[] doubleArray55 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray55);
        double[] doubleArray58 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray55, 100.0d);
        double[] doubleArray60 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray55, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray60);
        boolean boolean62 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray51, doubleArray60);
        java.lang.Number number63 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection66 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException68 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number63, (java.lang.Number) 132.0d, 6, orderDirection66, false);
        boolean boolean71 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray51, orderDirection66, false, false);
        double double72 = org.apache.commons.math.util.MathUtils.distance1(doubleArray44, doubleArray51);
        double[] doubleArray76 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray76);
        double[] doubleArray79 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray76, 100.0d);
        double[] doubleArray81 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray79, (double) 1.0f);
        double[] doubleArray85 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray85);
        double[] doubleArray88 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray85, 100.0d);
        double[] doubleArray90 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray85, (int) (byte) 1);
        double double91 = org.apache.commons.math.util.MathUtils.distance1(doubleArray79, doubleArray85);
        double double92 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray79);
        double double93 = org.apache.commons.math.util.MathUtils.distance1(doubleArray51, doubleArray79);
        double[] doubleArray95 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray51, 127);
        boolean boolean96 = org.apache.commons.math.util.MathUtils.equals(doubleArray23, doubleArray51);
        double[] doubleArray97 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + orderDirection66 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection66.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 18.20689655172414d + "'", double72 == 18.20689655172414d);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertNotNull(doubleArray90);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 132.0d + "'", double91 == 132.0d);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 62.49851365652365d + "'", double92 == 62.49851365652365d);
        org.junit.Assert.assertTrue("'" + double93 + "' != '" + 0.0d + "'", double93 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray95);
        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + true + "'", boolean96 == true);
        org.junit.Assert.assertNotNull(doubleArray97);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test297");
        double double1 = org.apache.commons.math.util.FastMath.sinh(993.8153752080916d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test298");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(99);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 359.1342053695755d + "'", double1 == 359.1342053695755d);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test299");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(32, 1076101120);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: must have n >= k for binomial coefficient (n, k), got k = 1,076,101,120, n = 32");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test300");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7615941559557649d + "'", double1 == 0.7615941559557649d);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test301");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) '4', (double) 1.1920929E-7f, 2.718281828459045d);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction5 = null;
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution9 = org.apache.commons.math.analysis.solvers.AllowedSolution.BELOW_SIDE;
        try {
            double double10 = regulaFalsiSolver3.solve(10000, univariateRealFunction5, (double) 100L, 0.0d, (-0.12472122473624835d), allowedSolution9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + allowedSolution9 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.BELOW_SIDE + "'", allowedSolution9.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.BELOW_SIDE));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test302");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1 == 100.0d);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test303");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((-35), (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: must have n >= k for binomial coefficient (n, k), got k = 97, n = -35");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test304");
        double[] doubleArray0 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection1 = null;
        try {
            boolean boolean4 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray0, orderDirection1, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test305");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.0f);
        boolean boolean2 = notStrictlyPositiveException1.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test306");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_ROW_AFTER_FINAL_ROW;
        java.lang.String str1 = localizedFormats0.getSourceString();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.0d), (java.lang.Number) 10.04987562112089d, (int) (byte) 0, orderDirection6, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = nonMonotonousSequenceException8.getDirection();
        java.lang.Throwable[] throwableArray10 = nonMonotonousSequenceException8.getSuppressed();
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException11 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1.1752011936438014d, (java.lang.Object[]) throwableArray10);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException15 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 3.948148009134034E13d, (java.lang.Number) 2041756729, true);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_ROW_AFTER_FINAL_ROW + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_ROW_AFTER_FINAL_ROW));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "initial row {1} after final row {0}" + "'", str1.equals("initial row {1} after final row {0}"));
        org.junit.Assert.assertNull(orderDirection9);
        org.junit.Assert.assertNotNull(throwableArray10);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test307");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException(35.01450265204638d, 4.9E-324d, 0.0d, 2.958103478741511E26d);
        double double5 = noBracketingException4.getFLo();
        double double6 = noBracketingException4.getHi();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.9E-324d + "'", double6 == 4.9E-324d);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test308");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) (-90L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test309");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DIMENSION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM;
        java.lang.Object[] objArray12 = new java.lang.Object[] { localizedFormats6, (-1), 0, localizedFormats9, 10.0d, (byte) 100 };
        java.lang.Object[] objArray13 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray12);
        org.apache.commons.math.exception.NoBracketingException noBracketingException14 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, 1.201819478E9d, (double) 97L, (-1.4309082844072307d), (double) 1.4E-45f, objArray12);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray12);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DIMENSION + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DIMENSION));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM + "'", localizedFormats9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(objArray13);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test310");
        int[] intArray5 = new int[] { (short) 100, 100, (byte) 10, (byte) 1, (byte) -1 };
        int[] intArray6 = org.apache.commons.math.util.MathUtils.copyOf(intArray5);
        int[] intArray12 = new int[] { (short) 100, 100, (byte) 10, (byte) 1, (byte) -1 };
        int[] intArray13 = org.apache.commons.math.util.MathUtils.copyOf(intArray12);
        int int14 = org.apache.commons.math.util.MathUtils.distance1(intArray5, intArray13);
        int[] intArray15 = new int[] {};
        int[] intArray21 = new int[] { (short) 100, 100, (byte) 10, (byte) 1, (byte) -1 };
        int[] intArray22 = org.apache.commons.math.util.MathUtils.copyOf(intArray21);
        int int23 = org.apache.commons.math.util.MathUtils.distance1(intArray15, intArray22);
        int[] intArray25 = org.apache.commons.math.util.MathUtils.copyOf(intArray22, 97);
        int[] intArray27 = org.apache.commons.math.util.MathUtils.copyOf(intArray22, 5200);
        int int28 = org.apache.commons.math.util.MathUtils.distance1(intArray13, intArray27);
        int[] intArray34 = new int[] { (short) 100, 100, (byte) 10, (byte) 1, (byte) -1 };
        int[] intArray35 = org.apache.commons.math.util.MathUtils.copyOf(intArray34);
        int[] intArray38 = new int[] { 99, 'a' };
        int[] intArray44 = new int[] { (short) 100, 100, (byte) 10, (byte) 1, (byte) -1 };
        int[] intArray45 = org.apache.commons.math.util.MathUtils.copyOf(intArray44);
        int int46 = org.apache.commons.math.util.MathUtils.distance1(intArray38, intArray44);
        int[] intArray48 = org.apache.commons.math.util.MathUtils.copyOf(intArray44, 770);
        double double49 = org.apache.commons.math.util.MathUtils.distance(intArray35, intArray48);
        int int50 = org.apache.commons.math.util.MathUtils.distanceInf(intArray13, intArray48);
        int[] intArray52 = org.apache.commons.math.util.MathUtils.copyOf(intArray13, 52000);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 4 + "'", int46 == 4);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertNotNull(intArray52);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test311");
        int int2 = org.apache.commons.math.util.FastMath.max(10, 18);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18 + "'", int2 == 18);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test312");
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math.exception.DimensionMismatchException((int) (short) 100, 18);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test313");
        double double1 = org.apache.commons.math.util.FastMath.expm1((-2.288332793335697E56d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test314");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(2.69123515971881d, 1.0000048062289337d, 3.141592653589793d);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test315");
        float float1 = org.apache.commons.math.util.FastMath.signum((float) 870L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test316");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-0.12408049872194353d), (java.lang.Number) 100L, true);
        boolean boolean4 = numberIsTooSmallException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test317");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DIMENSION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM;
        java.lang.Object[] objArray11 = new java.lang.Object[] { localizedFormats5, (-1), 0, localizedFormats8, 10.0d, (byte) 100 };
        java.lang.Object[] objArray12 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray11);
        org.apache.commons.math.exception.NoBracketingException noBracketingException13 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, 1.201819478E9d, (double) 97L, (-1.4309082844072307d), (double) 1.4E-45f, objArray11);
        double double14 = noBracketingException13.getFLo();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DIMENSION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DIMENSION));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-1.4309082844072307d) + "'", double14 == (-1.4309082844072307d));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test318");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction1 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        int int3 = regulaFalsiSolver2.getMaxEvaluations();
        int int4 = regulaFalsiSolver2.getEvaluations();
        double double5 = regulaFalsiSolver2.getMax();
        double double6 = regulaFalsiSolver2.getFunctionValueAccuracy();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction11 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver12 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        double double13 = regulaFalsiSolver12.getMin();
        double double14 = regulaFalsiSolver12.getFunctionValueAccuracy();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction19 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver23 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(52.0d, 90.0d, 6.617416307822852E84d);
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution27 = org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE;
        double double28 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide(0, univariateRealFunction19, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver23, (double) (short) 1, 11013.232874703393d, 1.0076685815103525d, allowedSolution27);
        double double29 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide(127, univariateRealFunction11, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver12, 5.298292365610485d, 2.718281828459045d, 1.1920928955078125E-7d, allowedSolution27);
        double double30 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide((-33), univariateRealFunction1, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver2, 1.69759663277E-313d, (double) (-8934108775301215359L), (double) (short) 10, allowedSolution27);
        double double31 = regulaFalsiSolver2.getMax();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0E-15d + "'", double6 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0E-15d + "'", double14 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + allowedSolution27 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE + "'", allowedSolution27.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE));
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.0d + "'", double28 == 1.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 5.298292365610485d + "'", double29 == 5.298292365610485d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.69759663277E-313d + "'", double30 == 1.69759663277E-313d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test319");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0f, (float) 30);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test320");
        double double3 = org.apache.commons.math.util.MathUtils.reduce(0.4659999899699459d, 0.0d, 0.5403023058681398d);
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test321");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_0TH_ROOT_OF_UNITY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.NO_FEASIBLE_SOLUTION;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException6 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, (java.lang.Number) 10.0f, (java.lang.Number) 1, true);
        java.lang.String str7 = numberIsTooSmallException6.toString();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext8 = numberIsTooSmallException6.getContext();
        java.lang.Throwable throwable9 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM;
        java.lang.Object[] objArray13 = new java.lang.Object[] { localizedFormats11, 52L };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException14 = new org.apache.commons.math.exception.MathIllegalStateException(throwable9, (org.apache.commons.math.exception.util.Localizable) localizedFormats10, objArray13);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats23 = org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats26 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_INCREMENT_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS;
        java.lang.Object[] objArray27 = new java.lang.Object[] { 0, 0.0d, localizedFormats23, 81.55795945611504d, 10.0d, localizedFormats26 };
        org.apache.commons.math.exception.NoBracketingException noBracketingException28 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats16, (double) (-1L), (double) ' ', (double) 100L, (double) (short) 10, objArray27);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException29 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats15, objArray27);
        exceptionContext8.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats10, objArray27);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException31 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 6.283185307179586d, objArray27);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats32 = org.apache.commons.math.exception.util.LocalizedFormats.N_POINTS_GAUSS_LEGENDRE_INTEGRATOR_NOT_SUPPORTED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats34 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats35 = org.apache.commons.math.exception.util.LocalizedFormats.NAN_VALUE_CONVERSION;
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext38 = new org.apache.commons.math.exception.util.ExceptionContext();
        java.util.Set<java.lang.String> strSet39 = exceptionContext38.getKeys();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException45 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10.0d, (java.lang.Number) 100.0d, (int) 'a');
        java.lang.Object[] objArray46 = new java.lang.Object[] { 1.0f, strSet39, 10.0f, (short) 0, 10.0d };
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException47 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 0L, objArray46);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException48 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats35, objArray46);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException49 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats34, objArray46);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException50 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats32, (java.lang.Number) 770, objArray46);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext54 = new org.apache.commons.math.exception.util.ExceptionContext();
        java.util.Set<java.lang.String> strSet55 = exceptionContext54.getKeys();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException61 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10.0d, (java.lang.Number) 100.0d, (int) 'a');
        java.lang.Object[] objArray62 = new java.lang.Object[] { 1.0f, strSet55, 10.0f, (short) 0, 10.0d };
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException63 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 0L, objArray62);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException64 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 1.0d, objArray62);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException65 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats32, objArray62);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats66 = org.apache.commons.math.exception.util.LocalizedFormats.RANDOMKEY_MUTATION_WRONG_CLASS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats67 = org.apache.commons.math.exception.util.LocalizedFormats.NO_DENSITY_FOR_THIS_DISTRIBUTION;
        java.lang.Throwable throwable72 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats73 = org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats74 = org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM;
        java.lang.Object[] objArray76 = new java.lang.Object[] { localizedFormats74, 52L };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException77 = new org.apache.commons.math.exception.MathIllegalStateException(throwable72, (org.apache.commons.math.exception.util.Localizable) localizedFormats73, objArray76);
        org.apache.commons.math.exception.NoBracketingException noBracketingException78 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats67, (double) (byte) 10, 0.0d, 11.04987562112089d, (double) (byte) 100, objArray76);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException79 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats66, objArray76);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException80 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) notFiniteNumberException31, (org.apache.commons.math.exception.util.Localizable) localizedFormats32, objArray76);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException81 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray76);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) nullArgumentException81);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_0TH_ROOT_OF_UNITY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_0TH_ROOT_OF_UNITY));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_FEASIBLE_SOLUTION + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_FEASIBLE_SOLUTION));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: no feasible solution" + "'", str7.equals("org.apache.commons.math.exception.NumberIsTooSmallException: no feasible solution"));
        org.junit.Assert.assertNotNull(exceptionContext8);
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizedFormats10.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM + "'", localizedFormats11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE + "'", localizedFormats15.equals(org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE));
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS + "'", localizedFormats16.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS));
        org.junit.Assert.assertTrue("'" + localizedFormats23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER + "'", localizedFormats23.equals(org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER));
        org.junit.Assert.assertTrue("'" + localizedFormats26 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_INCREMENT_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS + "'", localizedFormats26.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_INCREMENT_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS));
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertTrue("'" + localizedFormats32 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.N_POINTS_GAUSS_LEGENDRE_INTEGRATOR_NOT_SUPPORTED + "'", localizedFormats32.equals(org.apache.commons.math.exception.util.LocalizedFormats.N_POINTS_GAUSS_LEGENDRE_INTEGRATOR_NOT_SUPPORTED));
        org.junit.Assert.assertTrue("'" + localizedFormats34 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM + "'", localizedFormats34.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM));
        org.junit.Assert.assertTrue("'" + localizedFormats35 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NAN_VALUE_CONVERSION + "'", localizedFormats35.equals(org.apache.commons.math.exception.util.LocalizedFormats.NAN_VALUE_CONVERSION));
        org.junit.Assert.assertNotNull(strSet39);
        org.junit.Assert.assertNotNull(objArray46);
        org.junit.Assert.assertNotNull(strSet55);
        org.junit.Assert.assertNotNull(objArray62);
        org.junit.Assert.assertTrue("'" + localizedFormats66 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.RANDOMKEY_MUTATION_WRONG_CLASS + "'", localizedFormats66.equals(org.apache.commons.math.exception.util.LocalizedFormats.RANDOMKEY_MUTATION_WRONG_CLASS));
        org.junit.Assert.assertTrue("'" + localizedFormats67 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_DENSITY_FOR_THIS_DISTRIBUTION + "'", localizedFormats67.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_DENSITY_FOR_THIS_DISTRIBUTION));
        org.junit.Assert.assertTrue("'" + localizedFormats73 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizedFormats73.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + localizedFormats74 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM + "'", localizedFormats74.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM));
        org.junit.Assert.assertNotNull(objArray76);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test322");
        double double1 = org.apache.commons.math.util.FastMath.tanh(3.99168E7d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test323");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.FIRST_ROWS_NOT_INITIALIZED_YET;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_WEIGHT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats17 = org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats20 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_INCREMENT_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS;
        java.lang.Object[] objArray21 = new java.lang.Object[] { 0, 0.0d, localizedFormats17, 81.55795945611504d, 10.0d, localizedFormats20 };
        org.apache.commons.math.exception.NoBracketingException noBracketingException22 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats10, (double) (-1L), (double) ' ', (double) 100L, (double) (short) 10, objArray21);
        org.apache.commons.math.exception.NoBracketingException noBracketingException23 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, (-1.4309082844072307d), 22026.465794806718d, (-0.12408049872194353d), 52.0d, objArray21);
        org.apache.commons.math.exception.NoBracketingException noBracketingException24 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, 0.0d, 0.0d, (double) 200.0f, 1.5748824832438753d, objArray21);
        double double25 = noBracketingException24.getHi();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FIRST_ROWS_NOT_INITIALIZED_YET + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.FIRST_ROWS_NOT_INITIALIZED_YET));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_WEIGHT + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_WEIGHT));
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS + "'", localizedFormats10.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS));
        org.junit.Assert.assertTrue("'" + localizedFormats17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER + "'", localizedFormats17.equals(org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER));
        org.junit.Assert.assertTrue("'" + localizedFormats20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_INCREMENT_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS + "'", localizedFormats20.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_INCREMENT_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS));
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test324");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 56694366221184L, 1.5707963259628248d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.669436622118399E13d + "'", double2 == 5.669436622118399E13d);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test325");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(62.49851365652365d, (double) 35, 3.1366338920820244E18d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test326");
        double double1 = org.apache.commons.math.util.FastMath.ulp(1.695197441753835d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test327");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) 1082658816);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test328");
        double double3 = org.apache.commons.math.util.MathUtils.reduce(15.104412573075516d, 1.2018194748584073E9d, (double) 1.08265869E9f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.1916080196281981E8d + "'", double3 == 1.1916080196281981E8d);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test329");
        double double4 = org.apache.commons.math.util.MathUtils.linearCombination(5.669436622118399E13d, 3.5553481704807584d, 0.0d, (double) 996176991);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 2.0156821122105262E14d + "'", double4 == 2.0156821122105262E14d);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test330");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1.201819478E9d, (java.lang.Number) (-1.5422326689561365d), false);
        java.lang.Number number5 = numberIsTooLargeException4.getMax();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-1.5422326689561365d) + "'", number5.equals((-1.5422326689561365d)));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test331");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((float) (-2852977536870709880L), (float) 52, (-1023));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test332");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((float) (short) -1, (float) 2L, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test333");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(1.56831713501957325E18d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2523246923300576E9d + "'", double1 == 1.2523246923300576E9d);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test334");
        float float2 = org.apache.commons.math.util.FastMath.copySign((float) 100, (float) 61);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test335");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 1.0000001f);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test336");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 61);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test337");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver0 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        int int1 = regulaFalsiSolver0.getMaxEvaluations();
        int int2 = regulaFalsiSolver0.getEvaluations();
        double double3 = regulaFalsiSolver0.getMax();
        double double4 = regulaFalsiSolver0.getFunctionValueAccuracy();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction6 = null;
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction10 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver13 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 9, 21024.0d);
        double double14 = regulaFalsiSolver13.getRelativeAccuracy();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction19 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver20 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        double double21 = regulaFalsiSolver20.getMin();
        double double22 = regulaFalsiSolver20.getFunctionValueAccuracy();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction27 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver31 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(52.0d, 90.0d, 6.617416307822852E84d);
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution35 = org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE;
        double double36 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide(0, univariateRealFunction27, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver31, (double) (short) 1, 11013.232874703393d, 1.0076685815103525d, allowedSolution35);
        double double37 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide(127, univariateRealFunction19, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver20, 5.298292365610485d, 2.718281828459045d, 1.1920928955078125E-7d, allowedSolution35);
        double double38 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide(1201819575, univariateRealFunction10, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver13, (-1.7051442881268803E34d), 196.0d, 4.806217383937352E-6d, allowedSolution35);
        try {
            double double39 = regulaFalsiSolver0.solve(110, univariateRealFunction6, (double) 3, 6.945917369462911E26d, allowedSolution35);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-15d + "'", double4 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 9.0d + "'", double14 == 9.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0E-15d + "'", double22 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + allowedSolution35 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE + "'", allowedSolution35.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE));
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 1.0d + "'", double36 == 1.0d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 5.298292365610485d + "'", double37 == 5.298292365610485d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + (-1.7051442881268803E34d) + "'", double38 == (-1.7051442881268803E34d));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test338");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, 0.7615941559557649d, (double) 56694366221184L, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test339");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 7710);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.8870543780509568d + "'", double1 == 3.8870543780509568d);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test340");
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) 3.141592653589793d);
        java.lang.Number number2 = maxCountExceededException1.getMax();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 3.141592653589793d + "'", number2.equals(3.141592653589793d));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test341");
        double double3 = org.apache.commons.math.util.MathUtils.reduce(3.136634270039147E18d, 0.0d, 0.8414709848078965d);
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test342");
        int[] intArray5 = new int[] { (short) 100, 100, (byte) 10, (byte) 1, (byte) -1 };
        int[] intArray6 = org.apache.commons.math.util.MathUtils.copyOf(intArray5);
        int[] intArray7 = org.apache.commons.math.util.MathUtils.copyOf(intArray5);
        int[] intArray10 = new int[] { 99, 'a' };
        int[] intArray16 = new int[] { (short) 100, 100, (byte) 10, (byte) 1, (byte) -1 };
        int[] intArray17 = org.apache.commons.math.util.MathUtils.copyOf(intArray16);
        int int18 = org.apache.commons.math.util.MathUtils.distance1(intArray10, intArray16);
        int[] intArray20 = org.apache.commons.math.util.MathUtils.copyOf(intArray16, 770);
        int int21 = org.apache.commons.math.util.MathUtils.distanceInf(intArray5, intArray20);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test343");
        org.apache.commons.math.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math.exception.TooManyEvaluationsException((java.lang.Number) 35);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test344");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 32);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.896296018268069E13d + "'", double1 == 7.896296018268069E13d);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test345");
        double[] doubleArray0 = null;
        double[] doubleArray6 = new double[] { (byte) 100, 81.55795945611504d, 1.0d, 100.0d, (-1) };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray6);
        double[] doubleArray8 = null;
        double[] doubleArray14 = new double[] { (byte) 100, 81.55795945611504d, 1.0d, 100.0d, (-1) };
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray8, doubleArray14);
        double double16 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray6, doubleArray14);
        double[] doubleArray20 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray20);
        double[] doubleArray23 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray20, 100.0d);
        double[] doubleArray27 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray27);
        double[] doubleArray30 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, 100.0d);
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray27, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray32);
        boolean boolean34 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray23, doubleArray32);
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray23);
        double[] doubleArray39 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray39);
        double[] doubleArray42 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray39, 100.0d);
        double double43 = org.apache.commons.math.util.MathUtils.distance(doubleArray23, doubleArray42);
        double[] doubleArray45 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray23, 0);
        double[] doubleArray49 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray49);
        double[] doubleArray52 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray49, 100.0d);
        int int53 = org.apache.commons.math.util.MathUtils.hash(doubleArray52);
        int int54 = org.apache.commons.math.util.MathUtils.hash(doubleArray52);
        double double55 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray23, doubleArray52);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray52);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (43.103 >= 43.103)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-1201819478) + "'", int53 == (-1201819478));
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1201819478) + "'", int54 == (-1201819478));
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test346");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 139);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 139.0d + "'", double1 == 139.0d);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test347");
        double double2 = org.apache.commons.math.util.FastMath.IEEEremainder((double) 10, (-1.5707963267948966d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5752220392306207d + "'", double2 == 0.5752220392306207d);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test348");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(0.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test349");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 35);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 0L);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, 5);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, (long) 1201819575);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, (int) (short) 100);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test350");
        org.apache.commons.math.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math.exception.NotPositiveException((java.lang.Number) (-1.4309082844072307d));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test351");
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifySequence((double) 1077936159, 23151.906933686558d, 62.49851365652365d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [1,077,936,159, 23,151.907]");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test352");
        org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifySequence((double) (-90.0f), (double) 10L, 3.136634270039147E18d);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test353");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM;
        java.lang.Object[] objArray4 = new java.lang.Object[] { localizedFormats2, 52L };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException5 = new org.apache.commons.math.exception.MathIllegalStateException(throwable0, (org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray4);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext6 = mathIllegalStateException5.getContext();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext7 = mathIllegalStateException5.getContext();
        java.util.Set<java.lang.String> strSet8 = exceptionContext7.getKeys();
        java.util.Set<java.lang.String> strSet9 = exceptionContext7.getKeys();
        java.lang.Object obj11 = exceptionContext7.getValue("RandomKeyMutation works only with RandomKeys, not {0}");
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM));
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(exceptionContext6);
        org.junit.Assert.assertNotNull(exceptionContext7);
        org.junit.Assert.assertNotNull(strSet8);
        org.junit.Assert.assertNotNull(strSet9);
        org.junit.Assert.assertNull(obj11);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test354");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyBracketing(univariateRealFunction0, (-2.1005064588307762E8d), (double) 1000L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test355");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver0 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        int int1 = regulaFalsiSolver0.getMaxEvaluations();
        double double2 = regulaFalsiSolver0.getStartValue();
        double double3 = regulaFalsiSolver0.getAbsoluteAccuracy();
        double double4 = regulaFalsiSolver0.getStartValue();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E-6d + "'", double3 == 1.0E-6d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test356");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) (-35));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2005.3522829578812d) + "'", double1 == (-2005.3522829578812d));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test357");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 1082658816);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 20.802685719319914d + "'", double1 == 20.802685719319914d);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test358");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(0.0d, (double) 200L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test359");
        double double1 = org.apache.commons.math.util.MathUtils.sign(4.419840536924683d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test360");
        double double1 = org.apache.commons.math.util.FastMath.tanh(7.340835974686194d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.999999158874692d + "'", double1 == 0.999999158874692d);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test361");
        double[] doubleArray0 = null;
        double[] doubleArray6 = new double[] { (byte) 100, 81.55795945611504d, 1.0d, 100.0d, (-1) };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray6);
        double[] doubleArray8 = null;
        double[] doubleArray14 = new double[] { (byte) 100, 81.55795945611504d, 1.0d, 100.0d, (-1) };
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray8, doubleArray14);
        double double16 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray6, doubleArray14);
        double[] doubleArray20 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray20);
        double[] doubleArray23 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray20, 100.0d);
        double[] doubleArray25 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray20, (int) (byte) 1);
        double[] doubleArray29 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray29);
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray29, 100.0d);
        double[] doubleArray36 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray36);
        double[] doubleArray39 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray36, 100.0d);
        double[] doubleArray41 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray36, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray41);
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray32, doubleArray41);
        java.lang.Number number44 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection47 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException49 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number44, (java.lang.Number) 132.0d, 6, orderDirection47, false);
        boolean boolean52 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray32, orderDirection47, false, false);
        double double53 = org.apache.commons.math.util.MathUtils.distance1(doubleArray25, doubleArray32);
        int int54 = org.apache.commons.math.util.MathUtils.hash(doubleArray32);
        double[] doubleArray58 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray58);
        double[] doubleArray61 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray58, 100.0d);
        double[] doubleArray62 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray58);
        double double63 = org.apache.commons.math.util.MathUtils.distance(doubleArray32, doubleArray62);
        boolean boolean64 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray32);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray32);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (43.103 >= 43.103)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + orderDirection47 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection47.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 18.20689655172414d + "'", double53 == 18.20689655172414d);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1201819478) + "'", int54 == (-1201819478));
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 82.49803802661121d + "'", double63 == 82.49803802661121d);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test362");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction1 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        double double3 = regulaFalsiSolver2.getMin();
        double double4 = regulaFalsiSolver2.getFunctionValueAccuracy();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction9 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver13 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(52.0d, 90.0d, 6.617416307822852E84d);
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution17 = org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE;
        double double18 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide(0, univariateRealFunction9, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver13, (double) (short) 1, 11013.232874703393d, 1.0076685815103525d, allowedSolution17);
        double double19 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide(127, univariateRealFunction1, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver2, 5.298292365610485d, 2.718281828459045d, 1.1920928955078125E-7d, allowedSolution17);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction21 = null;
        try {
            double double25 = regulaFalsiSolver2.solve(412103574, univariateRealFunction21, (-0.6163965733697803d), (double) (byte) 100, (double) 1201819478);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-15d + "'", double4 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + allowedSolution17 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE + "'", allowedSolution17.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE));
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 5.298292365610485d + "'", double19 == 5.298292365610485d);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test363");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CLASS_DOESNT_IMPLEMENT_COMPARABLE;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, 99, 196);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CLASS_DOESNT_IMPLEMENT_COMPARABLE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CLASS_DOESNT_IMPLEMENT_COMPARABLE));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test364");
        double double8 = org.apache.commons.math.util.MathUtils.linearCombination((double) 7710, (double) (-90L), (-0.12408049872194353d), (double) 127, 0.125274658203125d, 1.1752011936438014d, 3.810477376962689d, (double) 1.08265882E9f);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.12475300972621E9d + "'", double8 == 4.12475300972621E9d);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test365");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) Double.POSITIVE_INFINITY, (java.lang.Number) 990L, true);
        boolean boolean4 = numberIsTooLargeException3.getBoundIsAllowed();
        java.lang.Number number5 = numberIsTooLargeException3.getMax();
        org.apache.commons.math.exception.MathInternalError mathInternalError6 = new org.apache.commons.math.exception.MathInternalError((java.lang.Throwable) numberIsTooLargeException3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 990L + "'", number5.equals(990L));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test366");
        double double1 = org.apache.commons.math.util.FastMath.ceil((-5.192987713658941d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-5.0d) + "'", double1 == (-5.0d));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test367");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test368");
        double double8 = org.apache.commons.math.util.MathUtils.linearCombination(48640.0d, (-0.23251381989123973d), 1.5706487647081802d, 1.42648876843535514E18d, (-1.7051442881268803E34d), (double) 1, 5.669436622118399E13d, 1.1752011936438014d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.70514428812688E34d) + "'", double8 == (-1.70514428812688E34d));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test369");
        int[] intArray5 = new int[] { (short) 100, 100, (byte) 10, (byte) 1, (byte) -1 };
        int[] intArray6 = org.apache.commons.math.util.MathUtils.copyOf(intArray5);
        int[] intArray9 = new int[] { 99, 'a' };
        int[] intArray15 = new int[] { (short) 100, 100, (byte) 10, (byte) 1, (byte) -1 };
        int[] intArray16 = org.apache.commons.math.util.MathUtils.copyOf(intArray15);
        int int17 = org.apache.commons.math.util.MathUtils.distance1(intArray9, intArray15);
        int[] intArray19 = org.apache.commons.math.util.MathUtils.copyOf(intArray15, 770);
        double double20 = org.apache.commons.math.util.MathUtils.distance(intArray6, intArray19);
        int[] intArray21 = org.apache.commons.math.util.MathUtils.copyOf(intArray6);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 4 + "'", int17 == 4);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(intArray21);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test370");
        double[] doubleArray3 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray3);
        double[] doubleArray6 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, 100.0d);
        int int7 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        double[] doubleArray11 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray11);
        double[] doubleArray16 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray16);
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, 100.0d);
        double double20 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray11, doubleArray16);
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray16);
        double[] doubleArray25 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray25);
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, 100.0d);
        double[] doubleArray32 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray32);
        double[] doubleArray35 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray32, 100.0d);
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equals(doubleArray25, doubleArray35);
        double double37 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray35);
        double[] doubleArray41 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray41);
        double[] doubleArray44 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray41, 100.0d);
        double[] doubleArray45 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray41);
        int int46 = org.apache.commons.math.util.MathUtils.hash(doubleArray41);
        double[] doubleArray48 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray41, 6.283185307179586d);
        double double49 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray35, doubleArray48);
        double[] doubleArray51 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray48, (double) (-33.0f));
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1201819478) + "'", int7 == (-1201819478));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 21024.0d + "'", double20 == 21024.0d);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 996176991 + "'", int46 == 996176991);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 245.42525248614677d + "'", double49 == 245.42525248614677d);
        org.junit.Assert.assertNotNull(doubleArray51);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test371");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NAN_VALUE_CONVERSION;
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext3 = new org.apache.commons.math.exception.util.ExceptionContext();
        java.util.Set<java.lang.String> strSet4 = exceptionContext3.getKeys();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10.0d, (java.lang.Number) 100.0d, (int) 'a');
        java.lang.Object[] objArray11 = new java.lang.Object[] { 1.0f, strSet4, 10.0f, (short) 0, 10.0d };
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException12 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 0L, objArray11);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException13 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray11);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext14 = nullArgumentException13.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_REAL_VECTOR;
        java.lang.Number number18 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException20 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats16, (java.lang.Number) (-8.699715755749389E31d), number18, true);
        exceptionContext14.setValue("function values at endpoints do not have different signs, endpoints: [{0}, {1}], values: [{2}, {3}]", (java.lang.Object) number18);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NAN_VALUE_CONVERSION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NAN_VALUE_CONVERSION));
        org.junit.Assert.assertNotNull(strSet4);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(exceptionContext14);
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_REAL_VECTOR + "'", localizedFormats16.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_REAL_VECTOR));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test372");
        int int1 = org.apache.commons.math.util.FastMath.getExponent((double) 61);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 5 + "'", int1 == 5);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test373");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test374");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(0.0d, (-1.960323183182555E166d));
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction4 = null;
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction8 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver9 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        int int10 = regulaFalsiSolver9.getMaxEvaluations();
        int int11 = regulaFalsiSolver9.getEvaluations();
        double double12 = regulaFalsiSolver9.getMax();
        double double13 = regulaFalsiSolver9.getFunctionValueAccuracy();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction18 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver19 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        double double20 = regulaFalsiSolver19.getMin();
        double double21 = regulaFalsiSolver19.getFunctionValueAccuracy();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction26 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver30 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(52.0d, 90.0d, 6.617416307822852E84d);
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution34 = org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE;
        double double35 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide(0, univariateRealFunction26, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver30, (double) (short) 1, 11013.232874703393d, 1.0076685815103525d, allowedSolution34);
        double double36 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide(127, univariateRealFunction18, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver19, 5.298292365610485d, 2.718281828459045d, 1.1920928955078125E-7d, allowedSolution34);
        double double37 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide((-33), univariateRealFunction8, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver9, 1.69759663277E-313d, (double) (-8934108775301215359L), (double) (short) 10, allowedSolution34);
        try {
            double double38 = regulaFalsiSolver2.solve((-1), univariateRealFunction4, 1227.2200291716233d, 0.0d, allowedSolution34);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0E-15d + "'", double13 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0E-15d + "'", double21 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + allowedSolution34 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE + "'", allowedSolution34.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE));
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 1.0d + "'", double35 == 1.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 5.298292365610485d + "'", double36 == 5.298292365610485d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 1.69759663277E-313d + "'", double37 == 1.69759663277E-313d);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test375");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((float) 56694366221184L, (float) 5970);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test376");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 9, 21024.0d);
        double double3 = regulaFalsiSolver2.getRelativeAccuracy();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction5 = null;
        try {
            double double7 = regulaFalsiSolver2.solve((int) (short) 10, univariateRealFunction5, 1.7160033436347992d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 9.0d + "'", double3 == 9.0d);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test377");
        org.apache.commons.math.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math.exception.TooManyEvaluationsException((java.lang.Number) (-8843210507033658501L));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test378");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(200535.22829578814d);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test379");
        int int2 = org.apache.commons.math.util.MathUtils.pow(30, 3);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 27000 + "'", int2 == 27000);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test380");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (-1201819478), 1077936159);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test381");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(2.960486013832335E47d, (-42.0d), 20.802685719319914d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test382");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 1000L, 1082658816);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test383");
        double double1 = org.apache.commons.math.util.FastMath.exp((-0.12472122473624835d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8827429551864694d + "'", double1 == 0.8827429551864694d);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test384");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_INCREMENT_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS;
        java.lang.Object[] objArray12 = new java.lang.Object[] { 0, 0.0d, localizedFormats8, 81.55795945611504d, 10.0d, localizedFormats11 };
        org.apache.commons.math.exception.NoBracketingException noBracketingException13 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (double) (-1L), (double) ' ', (double) 100L, (double) (short) 10, objArray12);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException14 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray12);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext15 = mathIllegalStateException14.getContext();
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) mathIllegalStateException14);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER));
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_INCREMENT_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS + "'", localizedFormats11.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_INCREMENT_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(exceptionContext15);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test385");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver0 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        double double1 = regulaFalsiSolver0.getFunctionValueAccuracy();
        int int2 = regulaFalsiSolver0.getMaxEvaluations();
        int int3 = regulaFalsiSolver0.getMaxEvaluations();
        int int4 = regulaFalsiSolver0.getEvaluations();
        double double5 = regulaFalsiSolver0.getRelativeAccuracy();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0E-15d + "'", double1 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0E-14d + "'", double5 == 1.0E-14d);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test386");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) (-1023));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test387");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) 1675926399, 0.0f, (float) (short) 100);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test388");
        double double1 = org.apache.commons.math.util.FastMath.abs(20.798314057214018d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 20.798314057214018d + "'", double1 == 20.798314057214018d);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test389");
        double[] doubleArray0 = null;
        double[] doubleArray4 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray4, 100.0d);
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray7);
        double[] doubleArray12 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray12);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, 100.0d);
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray12);
        boolean boolean17 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray7);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (43.103 >= 43.103)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1201819478) + "'", int8 == (-1201819478));
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test390");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 35.000004f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.271066429027897d + "'", double1 == 3.271066429027897d);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test391");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) '4', (double) 1.1920929E-7f, 2.718281828459045d);
        int int4 = regulaFalsiSolver3.getEvaluations();
        double double5 = regulaFalsiSolver3.getMin();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction7 = null;
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution11 = org.apache.commons.math.analysis.solvers.AllowedSolution.ABOVE_SIDE;
        try {
            double double12 = regulaFalsiSolver3.solve((-127), univariateRealFunction7, (double) 1.0f, 9062.068965517241d, 0.0d, allowedSolution11);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + allowedSolution11 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ABOVE_SIDE + "'", allowedSolution11.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ABOVE_SIDE));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test392");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(0.0d, (-1.960323183182555E166d));
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction4 = null;
        try {
            double double7 = regulaFalsiSolver2.solve(1076101120, univariateRealFunction4, (-2.5093711872178237d), (double) 74690L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test393");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED;
        java.lang.Number number1 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, number1, number2, true);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test394");
        int int1 = org.apache.commons.math.util.FastMath.getExponent((float) 30);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test395");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver0 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        int int1 = regulaFalsiSolver0.getMaxEvaluations();
        double double2 = regulaFalsiSolver0.getMin();
        double double3 = regulaFalsiSolver0.getMin();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction5 = null;
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution9 = org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE;
        try {
            double double10 = regulaFalsiSolver0.solve(7710, univariateRealFunction5, (double) 1090L, (double) 5200L, 3.1366339951612396E18d, allowedSolution9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + allowedSolution9 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE + "'", allowedSolution9.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test396");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 0.0f);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test397");
        int[] intArray0 = new int[] {};
        int[] intArray6 = new int[] { (short) 100, 100, (byte) 10, (byte) 1, (byte) -1 };
        int[] intArray7 = org.apache.commons.math.util.MathUtils.copyOf(intArray6);
        int int8 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray7);
        int[] intArray10 = org.apache.commons.math.util.MathUtils.copyOf(intArray7, 97);
        int[] intArray16 = new int[] { (short) 100, 100, (byte) 10, (byte) 1, (byte) -1 };
        int[] intArray17 = org.apache.commons.math.util.MathUtils.copyOf(intArray16);
        int[] intArray23 = new int[] { (short) 100, 100, (byte) 10, (byte) 1, (byte) -1 };
        int[] intArray24 = org.apache.commons.math.util.MathUtils.copyOf(intArray23);
        int int25 = org.apache.commons.math.util.MathUtils.distance1(intArray16, intArray24);
        int[] intArray26 = new int[] {};
        int[] intArray32 = new int[] { (short) 100, 100, (byte) 10, (byte) 1, (byte) -1 };
        int[] intArray33 = org.apache.commons.math.util.MathUtils.copyOf(intArray32);
        int int34 = org.apache.commons.math.util.MathUtils.distance1(intArray26, intArray33);
        int[] intArray36 = org.apache.commons.math.util.MathUtils.copyOf(intArray33, 97);
        int[] intArray38 = org.apache.commons.math.util.MathUtils.copyOf(intArray33, 5200);
        int int39 = org.apache.commons.math.util.MathUtils.distance1(intArray24, intArray38);
        double double40 = org.apache.commons.math.util.MathUtils.distance(intArray7, intArray24);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test398");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE;
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException3 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) (-1.201819478E9d), objArray2);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 52.0f, (java.lang.Number) (-1), (int) (byte) 1, orderDirection7, false);
        notFiniteNumberException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException9);
        boolean boolean11 = nonMonotonousSequenceException9.getStrict();
        boolean boolean12 = nonMonotonousSequenceException9.getStrict();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test399");
        double double2 = org.apache.commons.math.util.FastMath.IEEEremainder((double) (-0.99999994f), 0.9874056173207585d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.012594323074596736d) + "'", double2 == (-0.012594323074596736d));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test400");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 128.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test401");
        double double1 = org.apache.commons.math.util.FastMath.floor(3.846171529538503d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test402");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(28.448275862068964d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.052708366019779d + "'", double1 == 3.052708366019779d);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test403");
        float float2 = org.apache.commons.math.util.FastMath.nextAfter((-4.0f), 3.948148009134034E13d);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-3.9999998f) + "'", float2 == (-3.9999998f));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test404");
        float float2 = org.apache.commons.math.util.FastMath.nextAfter((float) 27000, (double) 11);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 26999.998f + "'", float2 == 26999.998f);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test405");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM;
        java.lang.Object[] objArray4 = new java.lang.Object[] { localizedFormats2, 52L };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException5 = new org.apache.commons.math.exception.MathIllegalStateException(throwable0, (org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray4);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext6 = mathIllegalStateException5.getContext();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext7 = mathIllegalStateException5.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats17 = org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats20 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_INCREMENT_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS;
        java.lang.Object[] objArray21 = new java.lang.Object[] { 0, 0.0d, localizedFormats17, 81.55795945611504d, 10.0d, localizedFormats20 };
        org.apache.commons.math.exception.NoBracketingException noBracketingException22 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats10, (double) (-1L), (double) ' ', (double) 100L, (double) (short) 10, objArray21);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException23 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats9, objArray21);
        exceptionContext7.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats8, objArray21);
        exceptionContext7.setValue("RandomKeyMutation works only with RandomKeys, not {0}", (java.lang.Object) 0L);
        java.lang.Object obj29 = exceptionContext7.getValue("");
        java.lang.Object obj31 = exceptionContext7.getValue("org.apache.commons.math.exception.NotFiniteNumberException: 0 is not a finite number");
        java.util.Set<java.lang.String> strSet32 = exceptionContext7.getKeys();
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM));
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(exceptionContext6);
        org.junit.Assert.assertNotNull(exceptionContext7);
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE + "'", localizedFormats9.equals(org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE));
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS + "'", localizedFormats10.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS));
        org.junit.Assert.assertTrue("'" + localizedFormats17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER + "'", localizedFormats17.equals(org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER));
        org.junit.Assert.assertTrue("'" + localizedFormats20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_INCREMENT_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS + "'", localizedFormats20.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_INCREMENT_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS));
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNull(obj29);
        org.junit.Assert.assertNull(obj31);
        org.junit.Assert.assertNotNull(strSet32);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test406");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 196);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.278114659230517d + "'", double1 == 5.278114659230517d);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test407");
        double double1 = org.apache.commons.math.util.FastMath.log10(1.9053570631129d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.27997637424189475d + "'", double1 == 0.27997637424189475d);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test408");
        double[] doubleArray0 = null;
        double[] doubleArray4 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray4, 100.0d);
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, (double) 1.0f);
        double[] doubleArray13 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray13);
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray13, 100.0d);
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray13, (int) (byte) 1);
        double double19 = org.apache.commons.math.util.MathUtils.distance1(doubleArray7, doubleArray13);
        double[] doubleArray23 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray23);
        double[] doubleArray26 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray23, 100.0d);
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, (double) 1.0f);
        double[] doubleArray32 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray32);
        double[] doubleArray35 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray32, 100.0d);
        double[] doubleArray37 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray32, (int) (byte) 1);
        double double38 = org.apache.commons.math.util.MathUtils.distance1(doubleArray26, doubleArray32);
        double double39 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray26);
        double double40 = org.apache.commons.math.util.MathUtils.distance(doubleArray13, doubleArray26);
        boolean boolean41 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 132.0d + "'", double19 == 132.0d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 132.0d + "'", double38 == 132.0d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 62.49851365652365d + "'", double39 == 62.49851365652365d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 82.49803802661121d + "'", double40 == 82.49803802661121d);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test409");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        int int1 = incrementor0.getCount();
        incrementor0.resetCount();
        incrementor0.resetCount();
        incrementor0.resetCount();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test410");
        float[] floatArray3 = new float[] { 770, 'a', (short) 1 };
        float[] floatArray9 = new float[] { 100L, (byte) 10, (short) -1, 100L, 32.000004f };
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray3, floatArray9);
        float[] floatArray14 = new float[] { 770, 'a', (short) 1 };
        float[] floatArray20 = new float[] { 100L, (byte) 10, (short) -1, 100L, 32.000004f };
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray14, floatArray20);
        float[] floatArray25 = new float[] { 770, 'a', (short) 1 };
        float[] floatArray31 = new float[] { 100L, (byte) 10, (short) -1, 100L, 32.000004f };
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray25, floatArray31);
        float[] floatArray36 = new float[] { 770, 'a', (short) 1 };
        float[] floatArray42 = new float[] { 100L, (byte) 10, (short) -1, 100L, 32.000004f };
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray36, floatArray42);
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equals(floatArray25, floatArray36);
        boolean boolean45 = org.apache.commons.math.util.MathUtils.equals(floatArray20, floatArray25);
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray9, floatArray25);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(floatArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(floatArray36);
        org.junit.Assert.assertNotNull(floatArray42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test411");
        int int1 = org.apache.commons.math.util.MathUtils.sign(52);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test412");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray5 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, (double) 0.5f, (double) 59546234880L, 0.0d, 900);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test413");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 9, 21024.0d);
        double double3 = regulaFalsiSolver2.getRelativeAccuracy();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction5 = null;
        try {
            double double7 = regulaFalsiSolver2.solve(996176991, univariateRealFunction5, 2.2737367544323206E-13d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 9.0d + "'", double3 == 9.0d);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test414");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 96L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4210854715202004E-14d + "'", double1 == 1.4210854715202004E-14d);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test415");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.534812414758962d, (-1.0d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.650484500644428d + "'", double2 == 2.650484500644428d);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test416");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CUMULATIVE_PROBABILITY_RETURNED_NAN;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (int) '#', (int) (short) 1);
        int int4 = dimensionMismatchException3.getDimension();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext5 = dimensionMismatchException3.getContext();
        java.lang.Object obj7 = exceptionContext5.getValue("");
        java.lang.Object obj9 = exceptionContext5.getValue("org.apache.commons.math.exception.NotFiniteNumberException: 0 is not a finite number");
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CUMULATIVE_PROBABILITY_RETURNED_NAN + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CUMULATIVE_PROBABILITY_RETURNED_NAN));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(exceptionContext5);
        org.junit.Assert.assertNull(obj7);
        org.junit.Assert.assertNull(obj9);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test417");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(52.0f, (float) 996176991L, (float) 100);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test418");
        java.lang.Number number0 = null;
        double[] doubleArray6 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray6);
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 100.0d);
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray6, (int) (byte) 1);
        double[] doubleArray15 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, 100.0d);
        double[] doubleArray22 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray22);
        double[] doubleArray25 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray22, 100.0d);
        double[] doubleArray27 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray22, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray27);
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray18, doubleArray27);
        java.lang.Number number30 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection33 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException35 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number30, (java.lang.Number) 132.0d, 6, orderDirection33, false);
        boolean boolean38 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray18, orderDirection33, false, false);
        double double39 = org.apache.commons.math.util.MathUtils.distance1(doubleArray11, doubleArray18);
        int int40 = org.apache.commons.math.util.MathUtils.hash(doubleArray18);
        double[] doubleArray44 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray44);
        double[] doubleArray47 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray44, 100.0d);
        double[] doubleArray48 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray44);
        double double49 = org.apache.commons.math.util.MathUtils.distance(doubleArray18, doubleArray48);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection53 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException55 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.0E-15d, (java.lang.Number) (-0.8414709848078965d), 99, orderDirection53, false);
        boolean boolean58 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray48, orderDirection53, true, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException60 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 7.340835974686194d, 30, orderDirection53, true);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + orderDirection33 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection33.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 18.20689655172414d + "'", double39 == 18.20689655172414d);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1201819478) + "'", int40 == (-1201819478));
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 82.49803802661121d + "'", double49 == 82.49803802661121d);
        org.junit.Assert.assertTrue("'" + orderDirection53 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection53.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test419");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(1082658781, 1100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathArithmeticException; message: arithmetic exception");
        } catch (org.apache.commons.math.exception.MathArithmeticException e) {
        }
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test420");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver0 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        int int1 = regulaFalsiSolver0.getMaxEvaluations();
        int int2 = regulaFalsiSolver0.getEvaluations();
        double double3 = regulaFalsiSolver0.getMax();
        double double4 = regulaFalsiSolver0.getFunctionValueAccuracy();
        double double5 = regulaFalsiSolver0.getMin();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-15d + "'", double4 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test421");
        double double1 = org.apache.commons.math.util.FastMath.signum(3628800.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test422");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 35);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 56694366221184L);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test423");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 25937425601L);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test424");
        double[] doubleArray3 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray3);
        double[] doubleArray6 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, 100.0d);
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray3, (int) (byte) 1);
        double[] doubleArray12 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray12);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, 100.0d);
        double[] doubleArray19 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray19);
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, 100.0d);
        double[] doubleArray24 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray19, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray24);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray15, doubleArray24);
        java.lang.Number number27 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection30 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException32 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number27, (java.lang.Number) 132.0d, 6, orderDirection30, false);
        boolean boolean35 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray15, orderDirection30, false, false);
        double double36 = org.apache.commons.math.util.MathUtils.distance1(doubleArray8, doubleArray15);
        int int37 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        double[] doubleArray41 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray41);
        double[] doubleArray44 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray41, 100.0d);
        double[] doubleArray45 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray41);
        double double46 = org.apache.commons.math.util.MathUtils.distance(doubleArray15, doubleArray45);
        double[] doubleArray48 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray45, 11);
        double[] doubleArray49 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + orderDirection30 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection30.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 18.20689655172414d + "'", double36 == 18.20689655172414d);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1201819478) + "'", int37 == (-1201819478));
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 82.49803802661121d + "'", double46 == 82.49803802661121d);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray49);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test425");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) (-8843210507033658501L), (float) 4L, (float) 5200);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test426");
        double double2 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.midpoint(57.29577951308232d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 28.64788975654116d + "'", double2 == 28.64788975654116d);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test427");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM;
        org.apache.commons.math.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math.exception.NotPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 7806.261125049361d);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test428");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) (-12700));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test429");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_NUMBER_OF_POINTS;
        java.lang.Object[] objArray5 = null;
        org.apache.commons.math.exception.NoBracketingException noBracketingException6 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, 1.7763568394002505E-15d, (double) 127L, 1.42648876843535488E18d, (-1.5707963267948966d), objArray5);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_NUMBER_OF_POINTS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_NUMBER_OF_POINTS));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test430");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) (-33));
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction3 = null;
        try {
            double double7 = regulaFalsiSolver1.solve((int) '4', univariateRealFunction3, 200535.2282957881d, 7.340835974686194d, 1.5430806348152437d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test431");
        java.lang.Number number0 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 132.0d, 6, orderDirection3, false);
        java.lang.String str6 = nonMonotonousSequenceException5.toString();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException5.getDirection();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 5 and 6 are not increasing (132 > null)" + "'", str6.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 5 and 6 are not increasing (132 > null)"));
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test432");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((int) (byte) 100, 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 200 + "'", int2 == 200);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test433");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NO_FEASIBLE_SOLUTION;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 10.0f, (java.lang.Number) 1, true);
        java.lang.String str5 = numberIsTooSmallException4.toString();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext6 = numberIsTooSmallException4.getContext();
        java.lang.Throwable throwable7 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM;
        java.lang.Object[] objArray11 = new java.lang.Object[] { localizedFormats9, 52L };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException12 = new org.apache.commons.math.exception.MathIllegalStateException(throwable7, (org.apache.commons.math.exception.util.Localizable) localizedFormats8, objArray11);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats14 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats24 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_INCREMENT_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS;
        java.lang.Object[] objArray25 = new java.lang.Object[] { 0, 0.0d, localizedFormats21, 81.55795945611504d, 10.0d, localizedFormats24 };
        org.apache.commons.math.exception.NoBracketingException noBracketingException26 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats14, (double) (-1L), (double) ' ', (double) 100L, (double) (short) 10, objArray25);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException27 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats13, objArray25);
        exceptionContext6.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats8, objArray25);
        java.util.Set<java.lang.String> strSet29 = exceptionContext6.getKeys();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats30 = org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX_OUT_OF_RANGE;
        java.lang.Throwable throwable31 = null;
        org.apache.commons.math.exception.MathInternalError mathInternalError32 = new org.apache.commons.math.exception.MathInternalError(throwable31);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats33 = org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE;
        java.lang.Throwable throwable34 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats35 = org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats36 = org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM;
        java.lang.Object[] objArray38 = new java.lang.Object[] { localizedFormats36, 52L };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException39 = new org.apache.commons.math.exception.MathIllegalStateException(throwable34, (org.apache.commons.math.exception.util.Localizable) localizedFormats35, objArray38);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext40 = mathIllegalStateException39.getContext();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext41 = mathIllegalStateException39.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats42 = org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats43 = org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats44 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats51 = org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats54 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_INCREMENT_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS;
        java.lang.Object[] objArray55 = new java.lang.Object[] { 0, 0.0d, localizedFormats51, 81.55795945611504d, 10.0d, localizedFormats54 };
        org.apache.commons.math.exception.NoBracketingException noBracketingException56 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats44, (double) (-1L), (double) ' ', (double) 100L, (double) (short) 10, objArray55);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException57 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats43, objArray55);
        exceptionContext41.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats42, objArray55);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException59 = new org.apache.commons.math.exception.MathIllegalStateException(throwable31, (org.apache.commons.math.exception.util.Localizable) localizedFormats33, objArray55);
        exceptionContext6.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats30, objArray55);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats61 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_COLUMNDIMENSION;
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException63 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) 2.0d);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext64 = maxCountExceededException63.getContext();
        java.lang.Number number66 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats67 = org.apache.commons.math.exception.util.LocalizedFormats.RANDOMKEY_MUTATION_WRONG_CLASS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats68 = org.apache.commons.math.exception.util.LocalizedFormats.NO_DENSITY_FOR_THIS_DISTRIBUTION;
        java.lang.Throwable throwable73 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats74 = org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats75 = org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM;
        java.lang.Object[] objArray77 = new java.lang.Object[] { localizedFormats75, 52L };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException78 = new org.apache.commons.math.exception.MathIllegalStateException(throwable73, (org.apache.commons.math.exception.util.Localizable) localizedFormats74, objArray77);
        org.apache.commons.math.exception.NoBracketingException noBracketingException79 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats68, (double) (byte) 10, 0.0d, 11.04987562112089d, (double) (byte) 100, objArray77);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException80 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats67, objArray77);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats81 = org.apache.commons.math.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats82 = org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats85 = org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM;
        java.lang.Object[] objArray88 = new java.lang.Object[] { localizedFormats82, (-1), 0, localizedFormats85, 10.0d, (byte) 100 };
        java.lang.Object[] objArray89 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray88);
        java.lang.Object[] objArray90 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray88);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException91 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats81, objArray90);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException92 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats67, objArray90);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException93 = new org.apache.commons.math.exception.NotFiniteNumberException(number66, objArray90);
        exceptionContext64.setValue("org.apache.commons.math.exception.TooManyEvaluationsException: illegal state: maximal count (0.673) exceeded: evaluations", (java.lang.Object) objArray90);
        exceptionContext6.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats61, objArray90);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_FEASIBLE_SOLUTION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_FEASIBLE_SOLUTION));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: no feasible solution" + "'", str5.equals("org.apache.commons.math.exception.NumberIsTooSmallException: no feasible solution"));
        org.junit.Assert.assertNotNull(exceptionContext6);
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM + "'", localizedFormats9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE + "'", localizedFormats13.equals(org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE));
        org.junit.Assert.assertTrue("'" + localizedFormats14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS + "'", localizedFormats14.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS));
        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER + "'", localizedFormats21.equals(org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER));
        org.junit.Assert.assertTrue("'" + localizedFormats24 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_INCREMENT_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS + "'", localizedFormats24.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_INCREMENT_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS));
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(strSet29);
        org.junit.Assert.assertTrue("'" + localizedFormats30 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX_OUT_OF_RANGE + "'", localizedFormats30.equals(org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats33 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE + "'", localizedFormats33.equals(org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE));
        org.junit.Assert.assertTrue("'" + localizedFormats35 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizedFormats35.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + localizedFormats36 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM + "'", localizedFormats36.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM));
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(exceptionContext40);
        org.junit.Assert.assertNotNull(exceptionContext41);
        org.junit.Assert.assertTrue("'" + localizedFormats42 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE + "'", localizedFormats42.equals(org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats43 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE + "'", localizedFormats43.equals(org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE));
        org.junit.Assert.assertTrue("'" + localizedFormats44 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS + "'", localizedFormats44.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS));
        org.junit.Assert.assertTrue("'" + localizedFormats51 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER + "'", localizedFormats51.equals(org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER));
        org.junit.Assert.assertTrue("'" + localizedFormats54 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_INCREMENT_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS + "'", localizedFormats54.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_INCREMENT_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS));
        org.junit.Assert.assertNotNull(objArray55);
        org.junit.Assert.assertTrue("'" + localizedFormats61 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_COLUMNDIMENSION + "'", localizedFormats61.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_COLUMNDIMENSION));
        org.junit.Assert.assertNotNull(exceptionContext64);
        org.junit.Assert.assertTrue("'" + localizedFormats67 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.RANDOMKEY_MUTATION_WRONG_CLASS + "'", localizedFormats67.equals(org.apache.commons.math.exception.util.LocalizedFormats.RANDOMKEY_MUTATION_WRONG_CLASS));
        org.junit.Assert.assertTrue("'" + localizedFormats68 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_DENSITY_FOR_THIS_DISTRIBUTION + "'", localizedFormats68.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_DENSITY_FOR_THIS_DISTRIBUTION));
        org.junit.Assert.assertTrue("'" + localizedFormats74 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizedFormats74.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + localizedFormats75 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM + "'", localizedFormats75.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM));
        org.junit.Assert.assertNotNull(objArray77);
        org.junit.Assert.assertTrue("'" + localizedFormats81 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA + "'", localizedFormats81.equals(org.apache.commons.math.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA));
        org.junit.Assert.assertTrue("'" + localizedFormats82 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY + "'", localizedFormats82.equals(org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY));
        org.junit.Assert.assertTrue("'" + localizedFormats85 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM + "'", localizedFormats85.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM));
        org.junit.Assert.assertNotNull(objArray88);
        org.junit.Assert.assertNotNull(objArray89);
        org.junit.Assert.assertNotNull(objArray90);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test434");
        double[] doubleArray3 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray3);
        double[] doubleArray6 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, 100.0d);
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) 1.0f);
        double[] doubleArray12 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray12);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, 100.0d);
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray12, (int) (byte) 1);
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray12);
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, (double) (byte) 10);
        int int21 = org.apache.commons.math.util.MathUtils.hash(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 132.0d + "'", double18 == 132.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 996176991 + "'", int21 == 996176991);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test435");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_CLEAR_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS;
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException3 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 3.271066429027897d, objArray2);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_CLEAR_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_CLEAR_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test436");
        float[] floatArray3 = new float[] { 770, 'a', (short) 1 };
        float[] floatArray9 = new float[] { 100L, (byte) 10, (short) -1, 100L, 32.000004f };
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray3, floatArray9);
        float[] floatArray14 = new float[] { 770, 'a', (short) 1 };
        float[] floatArray20 = new float[] { 100L, (byte) 10, (short) -1, 100L, 32.000004f };
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray14, floatArray20);
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equals(floatArray3, floatArray14);
        java.lang.Class<?> wildcardClass23 = floatArray3.getClass();
        float[] floatArray27 = new float[] { 770, 'a', (short) 1 };
        float[] floatArray33 = new float[] { 100L, (byte) 10, (short) -1, 100L, 32.000004f };
        boolean boolean34 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray27, floatArray33);
        float[] floatArray38 = new float[] { 770, 'a', (short) 1 };
        float[] floatArray44 = new float[] { 100L, (byte) 10, (short) -1, 100L, 32.000004f };
        boolean boolean45 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray38, floatArray44);
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equals(floatArray27, floatArray38);
        java.lang.Class<?> wildcardClass47 = floatArray27.getClass();
        float[] floatArray51 = new float[] { 770, 'a', (short) 1 };
        float[] floatArray57 = new float[] { 100L, (byte) 10, (short) -1, 100L, 32.000004f };
        boolean boolean58 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray51, floatArray57);
        float[] floatArray62 = new float[] { 770, 'a', (short) 1 };
        float[] floatArray68 = new float[] { 100L, (byte) 10, (short) -1, 100L, 32.000004f };
        boolean boolean69 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray62, floatArray68);
        float[] floatArray73 = new float[] { 770, 'a', (short) 1 };
        float[] floatArray79 = new float[] { 100L, (byte) 10, (short) -1, 100L, 32.000004f };
        boolean boolean80 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray73, floatArray79);
        boolean boolean81 = org.apache.commons.math.util.MathUtils.equals(floatArray62, floatArray73);
        boolean boolean82 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray51, floatArray73);
        boolean boolean83 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray27, floatArray73);
        boolean boolean84 = org.apache.commons.math.util.MathUtils.equals(floatArray3, floatArray73);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNotNull(floatArray27);
        org.junit.Assert.assertNotNull(floatArray33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(floatArray38);
        org.junit.Assert.assertNotNull(floatArray44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(wildcardClass47);
        org.junit.Assert.assertNotNull(floatArray51);
        org.junit.Assert.assertNotNull(floatArray57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(floatArray62);
        org.junit.Assert.assertNotNull(floatArray68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(floatArray73);
        org.junit.Assert.assertNotNull(floatArray79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + true + "'", boolean81 == true);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + true + "'", boolean82 == true);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + true + "'", boolean83 == true);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + true + "'", boolean84 == true);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test437");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_COMPUTE_COVARIANCE_SINGULAR_PROBLEM;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 52000, (java.lang.Number) 8.96280949311433d, true);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_COMPUTE_COVARIANCE_SINGULAR_PROBLEM + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_COMPUTE_COVARIANCE_SINGULAR_PROBLEM));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test438");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(33554432, 1082658781);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathArithmeticException; message: arithmetic exception");
        } catch (org.apache.commons.math.exception.MathArithmeticException e) {
        }
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test439");
        double[] doubleArray3 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray3);
        double[] doubleArray6 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, 100.0d);
        double[] doubleArray7 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray3);
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        double[] doubleArray12 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray12);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, 100.0d);
        double[] doubleArray19 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray19);
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, 100.0d);
        double[] doubleArray24 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray19, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray24);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray15, doubleArray24);
        java.lang.Number number27 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection30 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException32 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number27, (java.lang.Number) 132.0d, 6, orderDirection30, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray24, orderDirection30, true);
        boolean boolean37 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray3, orderDirection30, true, false);
        int int38 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        double[] doubleArray42 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray42);
        double[] doubleArray47 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray47);
        double[] doubleArray50 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray47, 100.0d);
        double double51 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray42, doubleArray47);
        double[] doubleArray52 = null;
        double[] doubleArray58 = new double[] { (byte) 100, 81.55795945611504d, 1.0d, 100.0d, (-1) };
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equals(doubleArray52, doubleArray58);
        double[] doubleArray60 = null;
        double[] doubleArray66 = new double[] { (byte) 100, 81.55795945611504d, 1.0d, 100.0d, (-1) };
        boolean boolean67 = org.apache.commons.math.util.MathUtils.equals(doubleArray60, doubleArray66);
        double double68 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray58, doubleArray66);
        double double69 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray47, doubleArray66);
        double[] doubleArray70 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray47);
        boolean boolean71 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 996176991 + "'", int8 == 996176991);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + orderDirection30 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection30.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 996176991 + "'", int38 == 996176991);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 21024.0d + "'", double51 == 21024.0d);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 99.0d + "'", double69 == 99.0d);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test440");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 1100L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1100.0d + "'", double1 == 1100.0d);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test441");
        double double2 = org.apache.commons.math.util.FastMath.pow(1.7763568394002505E-15d, 22025.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test442");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction1 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        double double3 = regulaFalsiSolver2.getAbsoluteAccuracy();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction8 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver9 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        double double10 = regulaFalsiSolver9.getMin();
        double double11 = regulaFalsiSolver9.getFunctionValueAccuracy();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction16 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver20 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(52.0d, 90.0d, 6.617416307822852E84d);
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution24 = org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE;
        double double25 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide(0, univariateRealFunction16, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver20, (double) (short) 1, 11013.232874703393d, 1.0076685815103525d, allowedSolution24);
        double double26 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide(127, univariateRealFunction8, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver9, 5.298292365610485d, 2.718281828459045d, 1.1920928955078125E-7d, allowedSolution24);
        double double27 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide(1201819478, univariateRealFunction1, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver2, 196.0d, 6.945917369462911E26d, 0.0d, allowedSolution24);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E-6d + "'", double3 == 1.0E-6d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0E-15d + "'", double11 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + allowedSolution24 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE + "'", allowedSolution24.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE));
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 5.298292365610485d + "'", double26 == 5.298292365610485d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 196.0d + "'", double27 == 196.0d);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test443");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(35.01450265204638d, 0.0d, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test444");
        double double1 = org.apache.commons.math.util.FastMath.log1p(81.55795945611504d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.41350058553773d + "'", double1 == 4.41350058553773d);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test445");
        double double1 = org.apache.commons.math.util.FastMath.tanh((-1.70514428812688E34d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test446");
        double[] doubleArray0 = null;
        double[] doubleArray6 = new double[] { (byte) 100, 81.55795945611504d, 1.0d, 100.0d, (-1) };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray6);
        double[] doubleArray8 = null;
        double[] doubleArray14 = new double[] { (byte) 100, 81.55795945611504d, 1.0d, 100.0d, (-1) };
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray8, doubleArray14);
        double double16 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray6, doubleArray14);
        double[] doubleArray20 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray20);
        double[] doubleArray23 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray20, 100.0d);
        double[] doubleArray25 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray20, (int) (byte) 1);
        double[] doubleArray29 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray29);
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray29, 100.0d);
        double[] doubleArray36 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray36);
        double[] doubleArray39 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray36, 100.0d);
        double[] doubleArray41 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray36, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray41);
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray32, doubleArray41);
        java.lang.Number number44 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection47 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException49 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number44, (java.lang.Number) 132.0d, 6, orderDirection47, false);
        boolean boolean52 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray32, orderDirection47, false, false);
        double double53 = org.apache.commons.math.util.MathUtils.distance1(doubleArray25, doubleArray32);
        int int54 = org.apache.commons.math.util.MathUtils.hash(doubleArray32);
        double[] doubleArray58 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray58);
        double[] doubleArray61 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray58, 100.0d);
        double[] doubleArray62 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray58);
        double double63 = org.apache.commons.math.util.MathUtils.distance(doubleArray32, doubleArray62);
        boolean boolean64 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray32);
        double[] doubleArray66 = new double[] { 3.174802230091695d };
        double[] doubleArray68 = new double[] { 3.174802230091695d };
        double[] doubleArray70 = new double[] { 3.174802230091695d };
        double[] doubleArray72 = new double[] { 3.174802230091695d };
        double[] doubleArray74 = new double[] { 3.174802230091695d };
        double[] doubleArray76 = new double[] { 3.174802230091695d };
        double[][] doubleArray77 = new double[][] { doubleArray66, doubleArray68, doubleArray70, doubleArray72, doubleArray74, doubleArray76 };
        try {
            org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray32, doubleArray77);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 1 != 3");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + orderDirection47 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection47.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 18.20689655172414d + "'", double53 == 18.20689655172414d);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1201819478) + "'", int54 == (-1201819478));
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 82.49803802661121d + "'", double63 == 82.49803802661121d);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray77);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test447");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 771);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 771.0000000000001d + "'", double1 == 771.0000000000001d);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test448");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1082658816, (long) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1082658816 + "'", int2 == 1082658816);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test449");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-57.29577951308232d), (java.lang.Number) 1082658781, 0);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test450");
        double double1 = org.apache.commons.math.util.FastMath.asinh(279305.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 13.233206834233782d + "'", double1 == 13.233206834233782d);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test451");
        double[] doubleArray3 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray3);
        double[] doubleArray6 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, 100.0d);
        double[] doubleArray10 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray10);
        double[] doubleArray13 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray10, 100.0d);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray10, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray15);
        boolean boolean17 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray15);
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray6);
        int int19 = org.apache.commons.math.util.MathUtils.hash(doubleArray18);
        double[] doubleArray23 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray23);
        double[] doubleArray26 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray23, 100.0d);
        double[] doubleArray30 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray30);
        double[] doubleArray33 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray30, 100.0d);
        double[] doubleArray35 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray30, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray35);
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray26, doubleArray35);
        double[] doubleArray38 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray26);
        int int39 = org.apache.commons.math.util.MathUtils.hash(doubleArray38);
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray18, doubleArray38);
        double[] doubleArray44 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray44);
        double[] doubleArray47 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray44, 100.0d);
        double[] doubleArray51 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray51);
        double[] doubleArray54 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray51, 100.0d);
        double[] doubleArray56 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray51, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray56);
        boolean boolean58 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray47, doubleArray56);
        double[] doubleArray59 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray47);
        double double60 = org.apache.commons.math.util.MathUtils.distance1(doubleArray38, doubleArray59);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1201819478) + "'", int19 == (-1201819478));
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1201819478) + "'", int39 == (-1201819478));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test452");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException(number0, (java.lang.Number) 1.7160033436347992d, true);
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        java.lang.Throwable throwable5 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM;
        java.lang.Object[] objArray9 = new java.lang.Object[] { localizedFormats7, 52L };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException10 = new org.apache.commons.math.exception.MathIllegalStateException(throwable5, (org.apache.commons.math.exception.util.Localizable) localizedFormats6, objArray9);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException11 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooSmallException3, localizable4, objArray9);
        try {
            java.lang.String str12 = mathIllegalStateException11.toString();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM));
        org.junit.Assert.assertNotNull(objArray9);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test453");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 900, 9135298822100988993L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 900L + "'", long2 == 900L);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test454");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.DIFFERENT_ROWS_LENGTHS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_ARRAY_ELEMENT;
        double[] doubleArray8 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray8);
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray8, 100.0d);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray8);
        int int13 = org.apache.commons.math.util.MathUtils.hash(doubleArray8);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray8, 6.283185307179586d);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_CLUSTER_IN_K_MEANS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats17 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS;
        java.lang.Object[] objArray18 = null;
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException19 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats17, objArray18);
        java.lang.Object[] objArray20 = new java.lang.Object[] { (byte) 10, 6.283185307179586d, localizedFormats16, mathArithmeticException19 };
        java.lang.Object[] objArray21 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray20);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException22 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, (java.lang.Number) 870L, objArray21);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException23 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) (-8843210507033658501L), objArray21);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIFFERENT_ROWS_LENGTHS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIFFERENT_ROWS_LENGTHS));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_ARRAY_ELEMENT + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_ARRAY_ELEMENT));
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 996176991 + "'", int13 == 996176991);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_CLUSTER_IN_K_MEANS + "'", localizedFormats16.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_CLUSTER_IN_K_MEANS));
        org.junit.Assert.assertTrue("'" + localizedFormats17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS + "'", localizedFormats17.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS));
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(objArray21);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test455");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION;
        java.lang.String str1 = localizedFormats0.getSourceString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "function" + "'", str1.equals("function"));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test456");
        double double1 = org.apache.commons.math.util.FastMath.expm1(1.971702351536336d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.182893896694551d + "'", double1 == 6.182893896694551d);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test457");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((int) (byte) 0, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test458");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((-1201819478), 110);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: must have n >= k for binomial coefficient (n, k), got k = 110, n = -1,201,819,478");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test459");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS;
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException2 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray1);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext3 = mathArithmeticException2.getContext();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext4 = mathArithmeticException2.getContext();
        java.lang.Object obj6 = exceptionContext4.getValue("matrix must have at least one column");
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS));
        org.junit.Assert.assertNotNull(exceptionContext3);
        org.junit.Assert.assertNotNull(exceptionContext4);
        org.junit.Assert.assertNull(obj6);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test460");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction1 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver5 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) '4', (double) 1.1920929E-7f, 2.718281828459045d);
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution9 = org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE;
        double double10 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide(97, univariateRealFunction1, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver5, 6.47985642107054E9d, (double) 990L, 0.0d, allowedSolution9);
        double double11 = regulaFalsiSolver5.getMax();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction13 = null;
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction18 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver21 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 9, 21024.0d);
        double double22 = regulaFalsiSolver21.getRelativeAccuracy();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction27 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver28 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        double double29 = regulaFalsiSolver28.getMin();
        double double30 = regulaFalsiSolver28.getFunctionValueAccuracy();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction35 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver39 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(52.0d, 90.0d, 6.617416307822852E84d);
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution43 = org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE;
        double double44 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide(0, univariateRealFunction35, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver39, (double) (short) 1, 11013.232874703393d, 1.0076685815103525d, allowedSolution43);
        double double45 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide(127, univariateRealFunction27, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver28, 5.298292365610485d, 2.718281828459045d, 1.1920928955078125E-7d, allowedSolution43);
        double double46 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide(1201819575, univariateRealFunction18, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver21, (-1.7051442881268803E34d), 196.0d, 4.806217383937352E-6d, allowedSolution43);
        try {
            double double47 = regulaFalsiSolver5.solve((-12700), univariateRealFunction13, (double) 32, 1.000000000000007d, 8.998336506481754d, allowedSolution43);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + allowedSolution9 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE + "'", allowedSolution9.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 6.47985642107054E9d + "'", double10 == 6.47985642107054E9d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 9.0d + "'", double22 == 9.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.0E-15d + "'", double30 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + allowedSolution43 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE + "'", allowedSolution43.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE));
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 1.0d + "'", double44 == 1.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 5.298292365610485d + "'", double45 == 5.298292365610485d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + (-1.7051442881268803E34d) + "'", double46 == (-1.7051442881268803E34d));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test461");
        int[] intArray5 = new int[] { (short) 100, 100, (byte) 10, (byte) 1, (byte) -1 };
        int[] intArray6 = org.apache.commons.math.util.MathUtils.copyOf(intArray5);
        int[] intArray12 = new int[] { (short) 100, 100, (byte) 10, (byte) 1, (byte) -1 };
        int[] intArray13 = org.apache.commons.math.util.MathUtils.copyOf(intArray12);
        int int14 = org.apache.commons.math.util.MathUtils.distance1(intArray5, intArray13);
        int[] intArray15 = new int[] {};
        int[] intArray21 = new int[] { (short) 100, 100, (byte) 10, (byte) 1, (byte) -1 };
        int[] intArray22 = org.apache.commons.math.util.MathUtils.copyOf(intArray21);
        int int23 = org.apache.commons.math.util.MathUtils.distance1(intArray15, intArray22);
        int[] intArray25 = org.apache.commons.math.util.MathUtils.copyOf(intArray22, 97);
        int[] intArray27 = org.apache.commons.math.util.MathUtils.copyOf(intArray22, 5200);
        int int28 = org.apache.commons.math.util.MathUtils.distance1(intArray13, intArray27);
        int[] intArray34 = new int[] { (short) 100, 100, (byte) 10, (byte) 1, (byte) -1 };
        int[] intArray35 = org.apache.commons.math.util.MathUtils.copyOf(intArray34);
        int[] intArray38 = new int[] { 99, 'a' };
        int[] intArray44 = new int[] { (short) 100, 100, (byte) 10, (byte) 1, (byte) -1 };
        int[] intArray45 = org.apache.commons.math.util.MathUtils.copyOf(intArray44);
        int int46 = org.apache.commons.math.util.MathUtils.distance1(intArray38, intArray44);
        int[] intArray48 = org.apache.commons.math.util.MathUtils.copyOf(intArray44, 770);
        double double49 = org.apache.commons.math.util.MathUtils.distance(intArray35, intArray48);
        int int50 = org.apache.commons.math.util.MathUtils.distanceInf(intArray13, intArray48);
        int[] intArray56 = new int[] { (short) 100, 100, (byte) 10, (byte) 1, (byte) -1 };
        int[] intArray57 = org.apache.commons.math.util.MathUtils.copyOf(intArray56);
        int[] intArray60 = new int[] { 99, 'a' };
        int[] intArray66 = new int[] { (short) 100, 100, (byte) 10, (byte) 1, (byte) -1 };
        int[] intArray67 = org.apache.commons.math.util.MathUtils.copyOf(intArray66);
        int int68 = org.apache.commons.math.util.MathUtils.distance1(intArray60, intArray66);
        int[] intArray70 = org.apache.commons.math.util.MathUtils.copyOf(intArray66, 770);
        double double71 = org.apache.commons.math.util.MathUtils.distance(intArray57, intArray70);
        int[] intArray72 = org.apache.commons.math.util.MathUtils.copyOf(intArray70);
        int int73 = org.apache.commons.math.util.MathUtils.distanceInf(intArray13, intArray72);
        int[] intArray75 = org.apache.commons.math.util.MathUtils.copyOf(intArray13, 52000);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 4 + "'", int46 == 4);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertNotNull(intArray67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 4 + "'", int68 == 4);
        org.junit.Assert.assertNotNull(intArray70);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.0d + "'", double71 == 0.0d);
        org.junit.Assert.assertNotNull(intArray72);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 0 + "'", int73 == 0);
        org.junit.Assert.assertNotNull(intArray75);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test462");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) Double.POSITIVE_INFINITY, (java.lang.Number) 990L, true);
        boolean boolean4 = numberIsTooLargeException3.getBoundIsAllowed();
        java.lang.Number number5 = numberIsTooLargeException3.getMax();
        java.lang.Number number6 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 990L + "'", number5.equals(990L));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 990L + "'", number6.equals(990L));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test463");
        boolean boolean3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.isSequence(5.267884728309445d, (-0.9002915473040451d), 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test464");
        double[] doubleArray0 = null;
        double[] doubleArray6 = new double[] { (byte) 100, 81.55795945611504d, 1.0d, 100.0d, (-1) };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray6);
        double[] doubleArray8 = null;
        double[] doubleArray14 = new double[] { (byte) 100, 81.55795945611504d, 1.0d, 100.0d, (-1) };
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray8, doubleArray14);
        double double16 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray6, doubleArray14);
        double[] doubleArray20 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray20);
        double[] doubleArray23 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray20, 100.0d);
        double[] doubleArray25 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray20, (int) (byte) 1);
        double[] doubleArray29 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray29);
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray29, 100.0d);
        double[] doubleArray36 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray36);
        double[] doubleArray39 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray36, 100.0d);
        double[] doubleArray41 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray36, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray41);
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray32, doubleArray41);
        java.lang.Number number44 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection47 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException49 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number44, (java.lang.Number) 132.0d, 6, orderDirection47, false);
        boolean boolean52 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray32, orderDirection47, false, false);
        double double53 = org.apache.commons.math.util.MathUtils.distance1(doubleArray25, doubleArray32);
        int int54 = org.apache.commons.math.util.MathUtils.hash(doubleArray32);
        double[] doubleArray58 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray58);
        double[] doubleArray61 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray58, 100.0d);
        double[] doubleArray62 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray58);
        double double63 = org.apache.commons.math.util.MathUtils.distance(doubleArray32, doubleArray62);
        boolean boolean64 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray32);
        double[] doubleArray68 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray68);
        double[] doubleArray71 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray68, 0.0d);
        double double72 = org.apache.commons.math.util.MathUtils.distance1(doubleArray32, doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + orderDirection47 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection47.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 18.20689655172414d + "'", double53 == 18.20689655172414d);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1201819478) + "'", int54 == (-1201819478));
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 82.49803802661121d + "'", double63 == 82.49803802661121d);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 100.0d + "'", double72 == 100.0d);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test465");
        double[] doubleArray3 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray3);
        double[] doubleArray6 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, 100.0d);
        int int7 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        double[] doubleArray11 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, 100.0d);
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray14, (double) 1.0f);
        double[] doubleArray20 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray20);
        double[] doubleArray23 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray20, 100.0d);
        double[] doubleArray25 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray20, (int) (byte) 1);
        double double26 = org.apache.commons.math.util.MathUtils.distance1(doubleArray14, doubleArray20);
        double[] doubleArray30 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray30);
        double[] doubleArray33 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray30, 100.0d);
        double[] doubleArray35 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray33, (double) 1.0f);
        double[] doubleArray39 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray39);
        double[] doubleArray42 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray39, 100.0d);
        double[] doubleArray44 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray39, (int) (byte) 1);
        double double45 = org.apache.commons.math.util.MathUtils.distance1(doubleArray33, doubleArray39);
        double double46 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray33);
        double double47 = org.apache.commons.math.util.MathUtils.distance(doubleArray20, doubleArray33);
        double[] doubleArray51 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray51);
        double[] doubleArray54 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray51, 100.0d);
        double[] doubleArray55 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray51);
        int int56 = org.apache.commons.math.util.MathUtils.hash(doubleArray51);
        double[] doubleArray58 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray51, 6.283185307179586d);
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray33, doubleArray51);
        boolean boolean60 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1201819478) + "'", int7 == (-1201819478));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 132.0d + "'", double26 == 132.0d);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 132.0d + "'", double45 == 132.0d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 62.49851365652365d + "'", double46 == 62.49851365652365d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 82.49803802661121d + "'", double47 == 82.49803802661121d);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 996176991 + "'", int56 == 996176991);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test466");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_INCREMENT_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS;
        java.lang.Object[] objArray11 = new java.lang.Object[] { 0, 0.0d, localizedFormats7, 81.55795945611504d, 10.0d, localizedFormats10 };
        org.apache.commons.math.exception.NoBracketingException noBracketingException12 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (double) (-1L), (double) ' ', (double) 100L, (double) (short) 10, objArray11);
        double double13 = noBracketingException12.getFHi();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext14 = noBracketingException12.getContext();
        java.lang.Object obj16 = exceptionContext14.getValue("function is not polynomial");
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER));
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_INCREMENT_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS + "'", localizedFormats10.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_INCREMENT_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 10.0d + "'", double13 == 10.0d);
        org.junit.Assert.assertNotNull(exceptionContext14);
        org.junit.Assert.assertNull(obj16);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test467");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(5);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.787491742782046d + "'", double1 == 4.787491742782046d);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test468");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(28.448275862068964d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1629.9661413204453d + "'", double1 == 1629.9661413204453d);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test469");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5430806348152437d + "'", double1 == 1.5430806348152437d);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test470");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(74690.00000000001d, 1.7160033436347992d, (int) 'a');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test471");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(4.0f, (float) 87L, 6);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test472");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(9999L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test473");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException((double) 770, (double) 1076101120, 99.0d, (-1.971702351536336d));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test474");
        float float2 = org.apache.commons.math.util.FastMath.nextAfter((float) 1100L, 7.896296018268069E13d);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1100.0001f + "'", float2 == 1100.0001f);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test475");
        float[] floatArray3 = new float[] { 2L, 100, (-1L) };
        float[] floatArray7 = new float[] { 770, 'a', (short) 1 };
        float[] floatArray13 = new float[] { 100L, (byte) 10, (short) -1, 100L, 32.000004f };
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray7, floatArray13);
        float[] floatArray18 = new float[] { 770, 'a', (short) 1 };
        float[] floatArray24 = new float[] { 100L, (byte) 10, (short) -1, 100L, 32.000004f };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray18, floatArray24);
        float[] floatArray29 = new float[] { 770, 'a', (short) 1 };
        float[] floatArray35 = new float[] { 100L, (byte) 10, (short) -1, 100L, 32.000004f };
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray29, floatArray35);
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equals(floatArray18, floatArray29);
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equals(floatArray13, floatArray18);
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray3, floatArray13);
        float[] floatArray43 = new float[] { 770, 'a', (short) 1 };
        float[] floatArray49 = new float[] { 100L, (byte) 10, (short) -1, 100L, 32.000004f };
        boolean boolean50 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray43, floatArray49);
        float[] floatArray54 = new float[] { 770, 'a', (short) 1 };
        float[] floatArray60 = new float[] { 100L, (byte) 10, (short) -1, 100L, 32.000004f };
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray54, floatArray60);
        float[] floatArray65 = new float[] { 770, 'a', (short) 1 };
        float[] floatArray71 = new float[] { 100L, (byte) 10, (short) -1, 100L, 32.000004f };
        boolean boolean72 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray65, floatArray71);
        boolean boolean73 = org.apache.commons.math.util.MathUtils.equals(floatArray54, floatArray65);
        boolean boolean74 = org.apache.commons.math.util.MathUtils.equals(floatArray49, floatArray54);
        boolean boolean75 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray3, floatArray54);
        float[] floatArray79 = new float[] { 770, 'a', (short) 1 };
        float[] floatArray85 = new float[] { 100L, (byte) 10, (short) -1, 100L, 32.000004f };
        boolean boolean86 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray79, floatArray85);
        boolean boolean87 = org.apache.commons.math.util.MathUtils.equals(floatArray54, floatArray79);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(floatArray29);
        org.junit.Assert.assertNotNull(floatArray35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(floatArray43);
        org.junit.Assert.assertNotNull(floatArray49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(floatArray54);
        org.junit.Assert.assertNotNull(floatArray60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(floatArray65);
        org.junit.Assert.assertNotNull(floatArray71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + true + "'", boolean73 == true);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(floatArray79);
        org.junit.Assert.assertNotNull(floatArray85);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test476");
        float float1 = org.apache.commons.math.util.FastMath.nextUp((float) (-196L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-195.99998f) + "'", float1 == (-195.99998f));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test477");
        long long1 = org.apache.commons.math.util.MathUtils.sign(59546234880L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test478");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 996176991L, (-0.8414709848078965d), 139);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test479");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 3136633892082024448L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2147483647 + "'", int1 == 2147483647);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test480");
        org.apache.commons.math.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math.exception.NotPositiveException((java.lang.Number) 1.9721522630525295E-31d);
        boolean boolean2 = notPositiveException1.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test481");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 99L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9992068341863537d) + "'", double1 == (-0.9992068341863537d));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test482");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) Double.POSITIVE_INFINITY, (java.lang.Number) 990L, true);
        boolean boolean4 = numberIsTooLargeException3.getBoundIsAllowed();
        java.lang.Number number5 = numberIsTooLargeException3.getMax();
        boolean boolean6 = numberIsTooLargeException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 990L + "'", number5.equals(990L));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test483");
        double double1 = org.apache.commons.math.util.FastMath.signum((-35.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test484");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction1 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        double double3 = regulaFalsiSolver2.getMin();
        double double4 = regulaFalsiSolver2.getFunctionValueAccuracy();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction9 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver13 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(52.0d, 90.0d, 6.617416307822852E84d);
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution17 = org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE;
        double double18 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide(0, univariateRealFunction9, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver13, (double) (short) 1, 11013.232874703393d, 1.0076685815103525d, allowedSolution17);
        double double19 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide(127, univariateRealFunction1, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver2, 5.298292365610485d, 2.718281828459045d, 1.1920928955078125E-7d, allowedSolution17);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction21 = null;
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution25 = org.apache.commons.math.analysis.solvers.AllowedSolution.RIGHT_SIDE;
        try {
            double double26 = regulaFalsiSolver2.solve((int) (byte) 10, univariateRealFunction21, (-279305.06059554237d), 9.999999999999998d, 1.0986122886681098d, allowedSolution25);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-15d + "'", double4 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + allowedSolution17 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE + "'", allowedSolution17.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE));
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 5.298292365610485d + "'", double19 == 5.298292365610485d);
        org.junit.Assert.assertTrue("'" + allowedSolution25 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.RIGHT_SIDE + "'", allowedSolution25.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.RIGHT_SIDE));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test485");
        double double2 = org.apache.commons.math.util.FastMath.IEEEremainder((double) Float.NaN, 1.0E-6d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test486");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((-0.0d), 5, 2041756729);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test487");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.0d, (double) 990L, 770);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test488");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.setMaximalCount((-1));
        incrementor0.setMaximalCount(1100);
        int int5 = incrementor0.getCount();
        incrementor0.resetCount();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test489");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            boolean boolean3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.isBracketing(univariateRealFunction0, 14.749883135224437d, Double.NaN);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test490");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1201819575, 200);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 109881153 + "'", int2 == 109881153);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test491");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) 'a');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test492");
        double double2 = org.apache.commons.math.util.FastMath.scalb(0.0d, 1201819478);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test493");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 10000, 0.9395300555699313d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test494");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_ONE;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 100L, (java.lang.Number) Double.NaN, false);
        boolean boolean5 = numberIsTooLargeException4.getBoundIsAllowed();
        java.lang.Number number6 = numberIsTooLargeException4.getMax();
        java.lang.Number number7 = numberIsTooLargeException4.getArgument();
        java.lang.Number number8 = numberIsTooLargeException4.getMax();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_ONE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_ONE));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertEquals((double) number6, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 100L + "'", number7.equals(100L));
        org.junit.Assert.assertEquals((double) number8, Double.NaN, 0);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test495");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(7710, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test496");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((float) 87L, (float) 4, 412103574);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test497");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 993.8153752080916d, (java.lang.Number) (-1.0d), (int) (short) 1);
        int int4 = nonMonotonousSequenceException3.getIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test498");
        double double1 = org.apache.commons.math.util.FastMath.log10(2.041756729E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.310003995563468d + "'", double1 == 9.310003995563468d);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test499");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_FRACTION_TO_DIVIDE_BY;
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.TOO_LARGE_CUTOFF_SINGULAR_VALUE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.SHAPE;
        java.lang.Object[] objArray8 = new java.lang.Object[] { localizedFormats7 };
        org.apache.commons.math.exception.NullArgumentException nullArgumentException9 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats6, objArray8);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException10 = new org.apache.commons.math.exception.MathIllegalStateException(localizable5, objArray8);
        org.apache.commons.math.exception.NoBracketingException noBracketingException11 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, 0.0d, (double) 96L, (double) (-196L), 0.8414709848078965d, objArray8);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_FRACTION_TO_DIVIDE_BY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_FRACTION_TO_DIVIDE_BY));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TOO_LARGE_CUTOFF_SINGULAR_VALUE + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.TOO_LARGE_CUTOFF_SINGULAR_VALUE));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SHAPE + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.SHAPE));
        org.junit.Assert.assertNotNull(objArray8);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test500");
        int[] intArray2 = new int[] { 99, 'a' };
        int[] intArray8 = new int[] { (short) 100, 100, (byte) 10, (byte) 1, (byte) -1 };
        int[] intArray9 = org.apache.commons.math.util.MathUtils.copyOf(intArray8);
        int int10 = org.apache.commons.math.util.MathUtils.distance1(intArray2, intArray8);
        int[] intArray12 = org.apache.commons.math.util.MathUtils.copyOf(intArray8, 770);
        int[] intArray15 = new int[] { 99, 'a' };
        int[] intArray21 = new int[] { (short) 100, 100, (byte) 10, (byte) 1, (byte) -1 };
        int[] intArray22 = org.apache.commons.math.util.MathUtils.copyOf(intArray21);
        int int23 = org.apache.commons.math.util.MathUtils.distance1(intArray15, intArray21);
        int[] intArray29 = new int[] { (short) 100, 100, (byte) 10, (byte) 1, (byte) -1 };
        int[] intArray30 = org.apache.commons.math.util.MathUtils.copyOf(intArray29);
        int[] intArray36 = new int[] { (short) 100, 100, (byte) 10, (byte) 1, (byte) -1 };
        int[] intArray37 = org.apache.commons.math.util.MathUtils.copyOf(intArray36);
        int int38 = org.apache.commons.math.util.MathUtils.distance1(intArray29, intArray37);
        int[] intArray39 = new int[] {};
        int[] intArray45 = new int[] { (short) 100, 100, (byte) 10, (byte) 1, (byte) -1 };
        int[] intArray46 = org.apache.commons.math.util.MathUtils.copyOf(intArray45);
        int int47 = org.apache.commons.math.util.MathUtils.distance1(intArray39, intArray46);
        int[] intArray49 = org.apache.commons.math.util.MathUtils.copyOf(intArray46, 97);
        int[] intArray51 = org.apache.commons.math.util.MathUtils.copyOf(intArray46, 5200);
        int int52 = org.apache.commons.math.util.MathUtils.distance1(intArray37, intArray51);
        int[] intArray58 = new int[] { (short) 100, 100, (byte) 10, (byte) 1, (byte) -1 };
        int[] intArray59 = org.apache.commons.math.util.MathUtils.copyOf(intArray58);
        int[] intArray62 = new int[] { 99, 'a' };
        int[] intArray68 = new int[] { (short) 100, 100, (byte) 10, (byte) 1, (byte) -1 };
        int[] intArray69 = org.apache.commons.math.util.MathUtils.copyOf(intArray68);
        int int70 = org.apache.commons.math.util.MathUtils.distance1(intArray62, intArray68);
        int[] intArray72 = org.apache.commons.math.util.MathUtils.copyOf(intArray68, 770);
        double double73 = org.apache.commons.math.util.MathUtils.distance(intArray59, intArray72);
        int int74 = org.apache.commons.math.util.MathUtils.distanceInf(intArray37, intArray72);
        int int75 = org.apache.commons.math.util.MathUtils.distanceInf(intArray21, intArray72);
        double double76 = org.apache.commons.math.util.MathUtils.distance(intArray8, intArray72);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 4 + "'", int23 == 4);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertNotNull(intArray62);
        org.junit.Assert.assertNotNull(intArray68);
        org.junit.Assert.assertNotNull(intArray69);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 4 + "'", int70 == 4);
        org.junit.Assert.assertNotNull(intArray72);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 0 + "'", int74 == 0);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 0 + "'", int75 == 0);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.0d + "'", double76 == 0.0d);
    }
}

