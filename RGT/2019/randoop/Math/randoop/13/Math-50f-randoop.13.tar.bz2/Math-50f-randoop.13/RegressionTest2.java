import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        int[] intArray2 = new int[] { 99, 'a' };
        int[] intArray8 = new int[] { (short) 100, 100, (byte) 10, (byte) 1, (byte) -1 };
        int[] intArray9 = org.apache.commons.math.util.MathUtils.copyOf(intArray8);
        int int10 = org.apache.commons.math.util.MathUtils.distance1(intArray2, intArray8);
        int[] intArray16 = new int[] { (short) 100, 100, (byte) 10, (byte) 1, (byte) -1 };
        int[] intArray17 = org.apache.commons.math.util.MathUtils.copyOf(intArray16);
        double double18 = org.apache.commons.math.util.MathUtils.distance(intArray8, intArray17);
        int[] intArray19 = null;
        try {
            int int20 = org.apache.commons.math.util.MathUtils.distance1(intArray8, intArray19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyBracketing(univariateRealFunction0, (double) 52000, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        double double6 = org.apache.commons.math.util.MathUtils.linearCombination((-2.1005064588307762E8d), 9.332621544395286E157d, 245.42525248614677d, (double) 32.000004f, 0.9874056173207585d, 5.298292365610486d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.960323183182555E166d) + "'", double6 == (-1.960323183182555E166d));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        float float1 = org.apache.commons.math.util.FastMath.ulp((float) 6);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 4.7683716E-7f + "'", float1 == 4.7683716E-7f);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        double double1 = org.apache.commons.math.util.FastMath.log((double) (-1.0f));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((-0.41032129904824216d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 996176991, 2.041756729E9d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.961769910000001E8d + "'", double2 == 9.961769910000001E8d);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        float float1 = org.apache.commons.math.util.FastMath.nextUp(4.7683716E-7f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 4.768372E-7f + "'", float1 == 4.768372E-7f);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(0.02051113020245179d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0002103606059414d + "'", double1 == 1.0002103606059414d);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round(3.136634E18f, 770, 1082658816);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathIllegalArgumentException; message: invalid rounding method 1,082,658,816, valid methods: ROUND_CEILING (2), ROUND_DOWN (1), ROUND_FLOOR (3), ROUND_HALF_DOWN (5), ROUND_HALF_EVEN (6), ROUND_HALF_UP (4), ROUND_UNNECESSARY (7), ROUND_UP (0)");
        } catch (org.apache.commons.math.exception.MathIllegalArgumentException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (-35), 720L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9135298822100988993L + "'", long2 == 9135298822100988993L);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        long long1 = org.apache.commons.math.util.MathUtils.sign(870L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) 10.0f, 1.07610112E9d, 35.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(5050.000003814697d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5050.000003814698d + "'", double1 == 5050.000003814698d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CUMULATIVE_PROBABILITY_RETURNED_NAN;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (int) '#', (int) (short) 1);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_INCREMENT_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS;
        java.lang.Object[] objArray16 = new java.lang.Object[] { 0, 0.0d, localizedFormats12, 81.55795945611504d, 10.0d, localizedFormats15 };
        org.apache.commons.math.exception.NoBracketingException noBracketingException17 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, (double) (-1L), (double) ' ', (double) 100L, (double) (short) 10, objArray16);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException18 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats4, objArray16);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException19 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray16);
        java.lang.Class<?> wildcardClass20 = mathIllegalStateException19.getClass();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CUMULATIVE_PROBABILITY_RETURNED_NAN + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CUMULATIVE_PROBABILITY_RETURNED_NAN));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS));
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER + "'", localizedFormats12.equals(org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER));
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_INCREMENT_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS + "'", localizedFormats15.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_INCREMENT_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS));
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(wildcardClass20);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        double double2 = org.apache.commons.math.util.FastMath.copySign(0.5463024898437905d, 0.028563657838759995d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5463024898437905d + "'", double2 == 0.5463024898437905d);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 2, (-90.0f));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-90.0f) + "'", float2 == (-90.0f));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        int int1 = org.apache.commons.math.util.FastMath.getExponent(3.13663427E18f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 61 + "'", int1 == 61);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 2);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math.exception.MaxCountExceededException(number0);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(0, 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: must have n >= k for binomial coefficient (n, k), got k = 1, n = 0");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.setMaximalCount((-1));
        incrementor0.setMaximalCount(0);
        try {
            incrementor0.incrementCount();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MaxCountExceededException; message: illegal state: maximal count (0) exceeded");
        } catch (org.apache.commons.math.exception.MaxCountExceededException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 1, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math.exception.DimensionMismatchException(0, 5200);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        double double1 = org.apache.commons.math.util.FastMath.log1p(2.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0986122886681098d + "'", double1 == 1.0986122886681098d);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        double double1 = org.apache.commons.math.util.FastMath.atan(52.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5515679276951895d + "'", double1 == 1.5515679276951895d);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) 35.000004f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 1.08265882E9f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999506475305748d + "'", double1 == 0.9999506475305748d);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 771L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 10000L, 2.69123515971881d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.570527203285422d + "'", double2 == 1.570527203285422d);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        float float2 = org.apache.commons.math.util.FastMath.scalb((float) '4', 2041756729);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + Float.POSITIVE_INFINITY + "'", float2 == Float.POSITIVE_INFINITY);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 770, (double) (-33.0f));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        int int2 = org.apache.commons.math.util.FastMath.min(1992353982, 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (-1201819478), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction1 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver5 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(52.0d, 90.0d, 6.617416307822852E84d);
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution9 = org.apache.commons.math.analysis.solvers.AllowedSolution.LEFT_SIDE;
        try {
            double double10 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide((int) 'a', univariateRealFunction1, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver5, 6.617416307822852E84d, (-2880.000343322754d), 1.07610112E9d, allowedSolution9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + allowedSolution9 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.LEFT_SIDE + "'", allowedSolution9.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.LEFT_SIDE));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        double double2 = org.apache.commons.math.util.FastMath.scalb((double) 9.536743E-7f, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.5367431640625E-7d + "'", double2 == 9.5367431640625E-7d);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        double double2 = org.apache.commons.math.util.FastMath.IEEEremainder(9.961769910000001E8d, 4.679207401552301E62d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.961769910000001E8d + "'", double2 == 9.961769910000001E8d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(3200.0003814697266d, 0.0d, 993.8153752080916d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(97, (int) 'a');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 139);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 139.0d + "'", double1 == 139.0d);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.MathInternalError mathInternalError1 = new org.apache.commons.math.exception.MathInternalError(throwable0);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext2 = mathInternalError1.getContext();
        org.junit.Assert.assertNotNull(exceptionContext2);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math.exception.DimensionMismatchException((-1), 0);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 5, (long) (byte) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 1082658816);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        double double1 = org.apache.commons.math.util.FastMath.atan(1.201819478E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963259628248d + "'", double1 == 1.5707963259628248d);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        double[] doubleArray3 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray3);
        double[] doubleArray6 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, 100.0d);
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray3, (int) (byte) 1);
        double[] doubleArray12 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray12);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, 100.0d);
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray12);
        double double17 = org.apache.commons.math.util.MathUtils.distance1(doubleArray8, doubleArray12);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 4.768372E-7f);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(7.340835974686194d, (double) 0L, 52.0d);
        double double4 = regulaFalsiSolver3.getRelativeAccuracy();
        int int5 = regulaFalsiSolver3.getMaxEvaluations();
        int int6 = regulaFalsiSolver3.getMaxEvaluations();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 7.340835974686194d + "'", double4 == 7.340835974686194d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(56.89655172413793d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.5634712876259026E24d + "'", double1 == 2.5634712876259026E24d);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        double double1 = org.apache.commons.math.util.FastMath.log1p(1.695197441753835d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9914714639237341d + "'", double1 == 0.9914714639237341d);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        float float2 = org.apache.commons.math.util.FastMath.copySign((float) 200L, (float) 1076101120);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 200.0f + "'", float2 == 200.0f);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException(144.99655168313487d, 2005.3522829578812d, 2.2737367544323206E-13d, 0.0d);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        double[] doubleArray3 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray3);
        double[] doubleArray6 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, 100.0d);
        double[] doubleArray10 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray10);
        double[] doubleArray13 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray10, 100.0d);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray10, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray15);
        boolean boolean17 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray15);
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray6);
        int int19 = org.apache.commons.math.util.MathUtils.hash(doubleArray18);
        double[] doubleArray23 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray23);
        double[] doubleArray26 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray23, 100.0d);
        int int27 = org.apache.commons.math.util.MathUtils.hash(doubleArray26);
        double[] doubleArray31 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray31);
        double[] doubleArray36 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray36);
        double[] doubleArray39 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray36, 100.0d);
        double double40 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray31, doubleArray36);
        boolean boolean41 = org.apache.commons.math.util.MathUtils.equals(doubleArray26, doubleArray36);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection45 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException47 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.0E-15d, (java.lang.Number) (-0.8414709848078965d), 99, orderDirection45, false);
        double[] doubleArray51 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray51);
        double[] doubleArray54 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray51, 100.0d);
        int int55 = org.apache.commons.math.util.MathUtils.hash(doubleArray54);
        double[] doubleArray59 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray59);
        double[] doubleArray62 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray59, 100.0d);
        boolean boolean63 = org.apache.commons.math.util.MathUtils.equals(doubleArray54, doubleArray59);
        double[] doubleArray67 = new double[] { 9.332621544395286E157d, 9.332621544395286E157d, 770 };
        double[] doubleArray71 = new double[] { 9.332621544395286E157d, 9.332621544395286E157d, 770 };
        double[][] doubleArray72 = new double[][] { doubleArray67, doubleArray71 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray59, doubleArray72);
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray26, orderDirection45, doubleArray72);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray18, orderDirection45, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly decreasing (13.793 <= 43.103)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1201819478) + "'", int19 == (-1201819478));
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1201819478) + "'", int27 == (-1201819478));
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 21024.0d + "'", double40 == 21024.0d);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + orderDirection45 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection45.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-1201819478) + "'", int55 == (-1201819478));
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray72);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        double double1 = org.apache.commons.math.util.FastMath.cosh(82.49803802661121d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.3683149054752465E35d + "'", double1 == 3.3683149054752465E35d);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 996176991, (float) 1000L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1000.0f + "'", float2 == 1000.0f);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(0.9874056173207585d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        org.apache.commons.math.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math.exception.TooManyEvaluationsException((java.lang.Number) 99L);
        java.lang.Number number2 = tooManyEvaluationsException1.getMax();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 99L + "'", number2.equals(99L));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        double double1 = org.apache.commons.math.util.FastMath.ceil(200.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 200.0d + "'", double1 == 200.0d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) 9135298822100988993L, 9.536743E-7f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_WEIGHT;
        java.lang.Class<?> wildcardClass1 = localizedFormats0.getClass();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_WEIGHT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_WEIGHT));
        org.junit.Assert.assertNotNull(wildcardClass1);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math.exception.DimensionMismatchException(30, 30);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) (short) 10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        long long1 = org.apache.commons.math.util.FastMath.abs(996176991L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 996176991L + "'", long1 == 996176991L);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double double3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(univariateRealFunction0, (double) 1992353982, (double) 996176991);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        double double1 = org.apache.commons.math.util.FastMath.log(0.534812414758962d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6258392201887784d) + "'", double1 == (-0.6258392201887784d));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        float float2 = org.apache.commons.math.util.FastMath.scalb((float) (-90L), 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-90.0f) + "'", float2 == (-90.0f));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 0L, 1.0E-6d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        long long1 = org.apache.commons.math.util.FastMath.round(0.0d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) 1082658816, (float) 1992353982, 4.768372E-7f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) (short) -1, 2852977536870709977L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) (-35));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5422326689561365d) + "'", double1 == (-1.5422326689561365d));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        float float2 = org.apache.commons.math.util.FastMath.max(2.04175654E9f, (float) 30);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.04175654E9f + "'", float2 == 2.04175654E9f);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        double double1 = org.apache.commons.math.util.FastMath.rint((-279305.06059554237d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-279305.0d) + "'", double1 == (-279305.0d));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((int) (short) 100, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        double[] doubleArray3 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray3);
        double[] doubleArray6 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, 100.0d);
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray3, (int) (byte) 1);
        double[] doubleArray12 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray12);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, 100.0d);
        double[] doubleArray19 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray19);
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, 100.0d);
        double[] doubleArray24 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray19, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray24);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray15, doubleArray24);
        java.lang.Number number27 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection30 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException32 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number27, (java.lang.Number) 132.0d, 6, orderDirection30, false);
        boolean boolean35 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray15, orderDirection30, false, false);
        double double36 = org.apache.commons.math.util.MathUtils.distance1(doubleArray8, doubleArray15);
        double[] doubleArray39 = new double[] { 35.0f, 7.340835974686194d };
        double[] doubleArray42 = new double[] { 35.0f, 7.340835974686194d };
        double[] doubleArray45 = new double[] { 35.0f, 7.340835974686194d };
        double[] doubleArray48 = new double[] { 35.0f, 7.340835974686194d };
        double[][] doubleArray49 = new double[][] { doubleArray39, doubleArray42, doubleArray45, doubleArray48 };
        try {
            org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray8, doubleArray49);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 2 != 1");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + orderDirection30 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection30.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 18.20689655172414d + "'", double36 == 18.20689655172414d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray49);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS;
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException2 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray1);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext3 = mathArithmeticException2.getContext();
        java.util.Set<java.lang.String> strSet4 = exceptionContext3.getKeys();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS));
        org.junit.Assert.assertNotNull(exceptionContext3);
        org.junit.Assert.assertNotNull(strSet4);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(771, 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7710 + "'", int2 == 7710);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 196, 720L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 196L + "'", long2 == 196L);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        double[] doubleArray3 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray3);
        double[] doubleArray6 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, 100.0d);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = null;
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray3, orderDirection7, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NO_FEASIBLE_SOLUTION;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 10.0f, (java.lang.Number) 1, true);
        boolean boolean5 = numberIsTooSmallException4.getBoundIsAllowed();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.NO_DENSITY_FOR_THIS_DISTRIBUTION;
        java.lang.Throwable throwable11 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM;
        java.lang.Object[] objArray15 = new java.lang.Object[] { localizedFormats13, 52L };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException16 = new org.apache.commons.math.exception.MathIllegalStateException(throwable11, (org.apache.commons.math.exception.util.Localizable) localizedFormats12, objArray15);
        org.apache.commons.math.exception.NoBracketingException noBracketingException17 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats6, (double) (byte) 10, 0.0d, 11.04987562112089d, (double) (byte) 100, objArray15);
        double double18 = noBracketingException17.getFLo();
        numberIsTooSmallException4.addSuppressed((java.lang.Throwable) noBracketingException17);
        double double20 = noBracketingException17.getFLo();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_FEASIBLE_SOLUTION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_FEASIBLE_SOLUTION));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_DENSITY_FOR_THIS_DISTRIBUTION + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_DENSITY_FOR_THIS_DISTRIBUTION));
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizedFormats12.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM + "'", localizedFormats13.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM));
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 11.04987562112089d + "'", double18 == 11.04987562112089d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 11.04987562112089d + "'", double20 == 11.04987562112089d);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22025.465794806718d + "'", double1 == 22025.465794806718d);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, 32.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        long long1 = org.apache.commons.math.util.MathUtils.factorial(10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 3628800L + "'", long1 == 3628800L);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        int int1 = org.apache.commons.math.util.FastMath.getExponent(1.0986122886681098d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        double double2 = org.apache.commons.math.util.FastMath.scalb((double) 1076101120, (-33));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.125274658203125d + "'", double2 == 0.125274658203125d);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(0.0d, 9.834532502485658E-6d, 0.0d);
        double double4 = regulaFalsiSolver3.getAbsoluteAccuracy();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 9.834532502485658E-6d + "'", double4 == 9.834532502485658E-6d);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) 52000);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        double double2 = org.apache.commons.math.util.MathUtils.log(3.948148009134034E13d, (double) 2.04175654E9f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.6847407003485128d + "'", double2 == 0.6847407003485128d);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(200535.2282957881d, (double) Float.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 200535.22829578814d + "'", double2 == 200535.22829578814d);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-0.12408049872194353d), (java.lang.Number) 100L, true);
        java.lang.Number number4 = numberIsTooSmallException3.getMin();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 100L + "'", number4.equals(100L));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.setMaximalCount((-1));
        try {
            incrementor0.incrementCount();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MaxCountExceededException; message: illegal state: maximal count (-1) exceeded");
        } catch (org.apache.commons.math.exception.MaxCountExceededException e) {
        }
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        double[] doubleArray3 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray3);
        double[] doubleArray6 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, 100.0d);
        double[] doubleArray10 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray10);
        double[] doubleArray13 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray10, 100.0d);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray10, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray15);
        boolean boolean17 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray15);
        int int18 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray15, 35);
        double[] doubleArray21 = null;
        double[] doubleArray27 = new double[] { (byte) 100, 81.55795945611504d, 1.0d, 100.0d, (-1) };
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equals(doubleArray21, doubleArray27);
        double[] doubleArray32 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray32);
        double[] doubleArray35 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray32, 100.0d);
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray21, doubleArray35);
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray15, doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1077936159 + "'", int18 == 1077936159);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        double double2 = org.apache.commons.math.util.FastMath.copySign(1.971702351536336d, Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.971702351536336d) + "'", double2 == (-1.971702351536336d));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        double double4 = org.apache.commons.math.util.MathUtils.linearCombination((-0.9002915473040451d), (double) ' ', 1.69759663277E-313d, 3.6962708958568578d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-28.809329513729445d) + "'", double4 == (-28.809329513729445d));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 2);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((-33), 52000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, (double) 7710, 139.0d, 2.5634712876259026E24d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 996176991L, (double) 9135298822100988993L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        float float2 = org.apache.commons.math.util.FastMath.copySign((float) (byte) -1, (float) 35);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 4.7683716E-7f, (-0.23251381989123973d), 3.5413887082388813d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NO_DENSITY_FOR_THIS_DISTRIBUTION;
        java.lang.Throwable throwable5 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM;
        java.lang.Object[] objArray9 = new java.lang.Object[] { localizedFormats7, 52L };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException10 = new org.apache.commons.math.exception.MathIllegalStateException(throwable5, (org.apache.commons.math.exception.util.Localizable) localizedFormats6, objArray9);
        org.apache.commons.math.exception.NoBracketingException noBracketingException11 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (double) (byte) 10, 0.0d, 11.04987562112089d, (double) (byte) 100, objArray9);
        double double12 = noBracketingException11.getHi();
        double double13 = noBracketingException11.getFLo();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_DENSITY_FOR_THIS_DISTRIBUTION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_DENSITY_FOR_THIS_DISTRIBUTION));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM));
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 11.04987562112089d + "'", double13 == 11.04987562112089d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        double double2 = org.apache.commons.math.util.MathUtils.log(0.0d, 2.041756729E9d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.0d) + "'", double2 == (-0.0d));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) (byte) 10, 32.000004f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifySequence(3.58351893845611d, 29937.07084924806d, 2.2737367544323206E-13d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [29,937.071, 0]");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        double double1 = org.apache.commons.math.util.FastMath.rint(1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        float float1 = org.apache.commons.math.util.FastMath.abs(1.2676506E32f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.2676506E32f + "'", float1 == 1.2676506E32f);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifySequence((double) (-35), (double) 100.00001f, 52.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [100, 52]");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        boolean boolean3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.isSequence(200535.2282957881d, (double) (-1201819478), (-0.41032129904824216d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((-90.0f));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        double[] doubleArray3 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray3);
        double[] doubleArray6 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, 100.0d);
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray3, (int) (byte) 1);
        double[] doubleArray12 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray12);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, 100.0d);
        double[] doubleArray19 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray19);
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, 100.0d);
        double[] doubleArray24 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray19, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray24);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray15, doubleArray24);
        java.lang.Number number27 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection30 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException32 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number27, (java.lang.Number) 132.0d, 6, orderDirection30, false);
        boolean boolean35 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray15, orderDirection30, false, false);
        double double36 = org.apache.commons.math.util.MathUtils.distance1(doubleArray8, doubleArray15);
        java.lang.Number number37 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection40 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException42 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number37, (java.lang.Number) 132.0d, 6, orderDirection40, false);
        double[] doubleArray45 = new double[] { 5200, 1.3258176496434093d };
        double[] doubleArray48 = new double[] { 5200, 1.3258176496434093d };
        double[] doubleArray51 = new double[] { 5200, 1.3258176496434093d };
        double[] doubleArray54 = new double[] { 5200, 1.3258176496434093d };
        double[][] doubleArray55 = new double[][] { doubleArray45, doubleArray48, doubleArray51, doubleArray54 };
        try {
            org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray15, orderDirection40, doubleArray55);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 2 != 3");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + orderDirection30 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection30.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 18.20689655172414d + "'", double36 == 18.20689655172414d);
        org.junit.Assert.assertTrue("'" + orderDirection40 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection40.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray55);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.setMaximalCount((-1));
        incrementor0.setMaximalCount(0);
        int int5 = incrementor0.getCount();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(100.0f, (float) 9135298822100988993L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(97, (-1201819478));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1201819575 + "'", int2 == 1201819575);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        float float1 = org.apache.commons.math.util.FastMath.signum(1000.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(0, 139);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 139 + "'", int2 == 139);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        org.apache.commons.math.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math.exception.NotPositiveException((java.lang.Number) 1.000000000000007d);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext2 = notPositiveException1.getContext();
        boolean boolean3 = notPositiveException1.getBoundIsAllowed();
        org.junit.Assert.assertNotNull(exceptionContext2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, 2.0d, 11013.232874703393d, (double) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS;
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException2 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray1);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext3 = mathArithmeticException2.getContext();
        java.lang.Object obj5 = exceptionContext3.getValue("hi!");
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS));
        org.junit.Assert.assertNotNull(exceptionContext3);
        org.junit.Assert.assertNull(obj5);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 10000, (float) (-1L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1000.0f, (java.lang.Number) 1.695197441753835d, false);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException(0.0d, (double) (-126.99999f), (-0.6536436208636119d), (double) 127);
        double double5 = noBracketingException4.getHi();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-126.99999237060547d) + "'", double5 == (-126.99999237060547d));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        double double8 = org.apache.commons.math.util.MathUtils.linearCombination(0.0d, (double) 127, (-1.201819478E9d), (-2.1005064588307762E8d), 2.2737367544323206E-13d, (double) 200.0f, 3.3683149054752465E35d, (double) 996176991L);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 3.3554378072767806E44d + "'", double8 == 3.3554378072767806E44d);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver0 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        double double1 = regulaFalsiSolver0.getFunctionValueAccuracy();
        double double2 = regulaFalsiSolver0.getMax();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction4 = null;
        try {
            double double6 = regulaFalsiSolver0.solve((int) (short) 10, univariateRealFunction4, 3.141592653589793d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0E-15d + "'", double1 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) (byte) 100, 990L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1090L + "'", long2 == 1090L);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) (short) 100, (double) 1.0f);
        double double3 = regulaFalsiSolver2.getStartValue();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        double[] doubleArray0 = null;
        double[] doubleArray6 = new double[] { (byte) 100, 81.55795945611504d, 1.0d, 100.0d, (-1) };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray6);
        double[] doubleArray8 = null;
        double[] doubleArray14 = new double[] { (byte) 100, 81.55795945611504d, 1.0d, 100.0d, (-1) };
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray8, doubleArray14);
        double double16 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray6, doubleArray14);
        double[] doubleArray20 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray20);
        double[] doubleArray23 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray20, 100.0d);
        double[] doubleArray25 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray20, (int) (byte) 1);
        double[] doubleArray29 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray29);
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray29, 100.0d);
        double[] doubleArray36 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray36);
        double[] doubleArray39 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray36, 100.0d);
        double[] doubleArray41 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray36, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray41);
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray32, doubleArray41);
        java.lang.Number number44 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection47 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException49 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number44, (java.lang.Number) 132.0d, 6, orderDirection47, false);
        boolean boolean52 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray32, orderDirection47, false, false);
        double double53 = org.apache.commons.math.util.MathUtils.distance1(doubleArray25, doubleArray32);
        double[] doubleArray57 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray57);
        double[] doubleArray60 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray57, 100.0d);
        double[] doubleArray62 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray60, (double) 1.0f);
        double[] doubleArray66 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray66);
        double[] doubleArray69 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray66, 100.0d);
        double[] doubleArray71 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray66, (int) (byte) 1);
        double double72 = org.apache.commons.math.util.MathUtils.distance1(doubleArray60, doubleArray66);
        double double73 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray60);
        double double74 = org.apache.commons.math.util.MathUtils.distance1(doubleArray32, doubleArray60);
        boolean boolean75 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray14, doubleArray32);
        double[] doubleArray77 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray32, 1);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + orderDirection47 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection47.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 18.20689655172414d + "'", double53 == 18.20689655172414d);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 132.0d + "'", double72 == 132.0d);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 62.49851365652365d + "'", double73 == 62.49851365652365d);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 0.0d + "'", double74 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(doubleArray77);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10.0d, (java.lang.Number) 100.0d, (int) 'a');
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 100.0d + "'", number5.equals(100.0d));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(Double.NaN, (-0.41032129904824216d), (int) '4');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(1L, (long) 110);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-109L) + "'", long2 == (-109L));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        long long1 = org.apache.commons.math.util.FastMath.abs(0L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DIMENSION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM;
        java.lang.Object[] objArray11 = new java.lang.Object[] { localizedFormats5, (-1), 0, localizedFormats8, 10.0d, (byte) 100 };
        java.lang.Object[] objArray12 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray11);
        org.apache.commons.math.exception.NoBracketingException noBracketingException13 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, 1.201819478E9d, (double) 97L, (-1.4309082844072307d), (double) 1.4E-45f, objArray11);
        java.lang.Object[] objArray14 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray14);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DIMENSION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DIMENSION));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(objArray12);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        double double1 = org.apache.commons.math.util.FastMath.abs(3200.0003814697266d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3200.0003814697266d + "'", double1 == 3200.0003814697266d);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((float) 1992353982, (float) 1082658816);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        int int1 = incrementor0.getCount();
        try {
            incrementor0.incrementCount();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MaxCountExceededException; message: illegal state: maximal count (0) exceeded");
        } catch (org.apache.commons.math.exception.MaxCountExceededException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        int int2 = org.apache.commons.math.util.MathUtils.pow(0, 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 4L, 1.2676506E32f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 4.0f + "'", float2 == 4.0f);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(0.6300396599891174d);
        double double2 = regulaFalsiSolver1.getRelativeAccuracy();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E-14d + "'", double2 == 1.0E-14d);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 6);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_DISCARD_NEGATIVE_NUMBER_OF_ELEMENTS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM;
        java.lang.Object[] objArray8 = new java.lang.Object[] { localizedFormats2, (-1), 0, localizedFormats5, 10.0d, (byte) 100 };
        java.lang.Object[] objArray9 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray8);
        java.lang.Object[] objArray10 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray8);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException11 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1.0338699625793383E32d, objArray10);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_DISCARD_NEGATIVE_NUMBER_OF_ELEMENTS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_DISCARD_NEGATIVE_NUMBER_OF_ELEMENTS));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(objArray10);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        double double2 = org.apache.commons.math.util.FastMath.IEEEremainder(0.534812414758962d, 3.141592653589793d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.534812414758962d + "'", double2 == 0.534812414758962d);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        double double1 = org.apache.commons.math.util.FastMath.rint(1.695197441753835d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(2.041756729E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_WEIGHT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_INCREMENT_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS;
        java.lang.Object[] objArray17 = new java.lang.Object[] { 0, 0.0d, localizedFormats13, 81.55795945611504d, 10.0d, localizedFormats16 };
        org.apache.commons.math.exception.NoBracketingException noBracketingException18 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats6, (double) (-1L), (double) ' ', (double) 100L, (double) (short) 10, objArray17);
        org.apache.commons.math.exception.NoBracketingException noBracketingException19 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (-1.4309082844072307d), 22026.465794806718d, (-0.12408049872194353d), 52.0d, objArray17);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException20 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, objArray17);
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_WEIGHT + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_WEIGHT));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS));
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER + "'", localizedFormats13.equals(org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER));
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_INCREMENT_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS + "'", localizedFormats16.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_INCREMENT_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS));
        org.junit.Assert.assertNotNull(objArray17);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        double[] doubleArray3 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray3);
        double[] doubleArray6 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, 100.0d);
        double[] doubleArray10 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray10);
        double[] doubleArray13 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray10, 100.0d);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray10, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray15);
        boolean boolean17 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray15);
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray6);
        int int19 = org.apache.commons.math.util.MathUtils.hash(doubleArray18);
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray18);
        double[] doubleArray23 = new double[] { 1.5707963259628248d, 1.0E-15d };
        double[] doubleArray27 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray27);
        double[] doubleArray30 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, 100.0d);
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray27, (int) (byte) 1);
        double[] doubleArray36 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray36);
        double[] doubleArray39 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray36, 100.0d);
        double[] doubleArray43 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray43);
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray43, 100.0d);
        double[] doubleArray48 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray43, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray48);
        boolean boolean50 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray39, doubleArray48);
        java.lang.Number number51 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection54 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException56 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number51, (java.lang.Number) 132.0d, 6, orderDirection54, false);
        boolean boolean59 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray39, orderDirection54, false, false);
        double double60 = org.apache.commons.math.util.MathUtils.distance1(doubleArray32, doubleArray39);
        int int61 = org.apache.commons.math.util.MathUtils.hash(doubleArray39);
        double[] doubleArray65 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray65);
        double[] doubleArray68 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray65, 100.0d);
        double[] doubleArray69 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray65);
        double double70 = org.apache.commons.math.util.MathUtils.distance(doubleArray39, doubleArray69);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection74 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException76 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.0E-15d, (java.lang.Number) (-0.8414709848078965d), 99, orderDirection74, false);
        boolean boolean79 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray69, orderDirection74, true, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray23, orderDirection74, true);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray18, orderDirection74, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly decreasing (13.793 <= 43.103)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1201819478) + "'", int19 == (-1201819478));
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + orderDirection54 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection54.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 18.20689655172414d + "'", double60 == 18.20689655172414d);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-1201819478) + "'", int61 == (-1201819478));
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 82.49803802661121d + "'", double70 == 82.49803802661121d);
        org.junit.Assert.assertTrue("'" + orderDirection74 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection74.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 2041756729);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(4);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-33), (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: must have n >= k for binomial coefficient (n, k), got k = 100, n = -33");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(4.679207401552301E62d, 7710, 1077936159);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) ' ');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.028563657838759995d, (java.lang.Number) 97, 11);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(1082658816, 35);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1082658781 + "'", int2 == 1082658781);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 200L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 200.0f + "'", float1 == 200.0f);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 3.9999998f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7568023394671234d) + "'", double1 == (-0.7568023394671234d));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        java.lang.Number number1 = null;
        double[] doubleArray6 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray6);
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 100.0d);
        double[] doubleArray13 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray13);
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray13, 100.0d);
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray13, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray18);
        boolean boolean20 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray9, doubleArray18);
        java.lang.Number number21 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection24 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException26 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number21, (java.lang.Number) 132.0d, 6, orderDirection24, false);
        boolean boolean29 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray9, orderDirection24, false, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException31 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.000000000000007d, number1, (int) '4', orderDirection24, false);
        java.lang.Number number32 = nonMonotonousSequenceException31.getPrevious();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + orderDirection24 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection24.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNull(number32);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 52.0f, (java.lang.Number) (-1), (int) (byte) 1, orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getPrevious();
        java.lang.Number number7 = nonMonotonousSequenceException5.getPrevious();
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (-1) + "'", number6.equals((-1)));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (-1) + "'", number7.equals((-1)));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 52L, (double) 196, 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((-127.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-7.151039979174052E54d) + "'", double1 == (-7.151039979174052E54d));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(196.0d, (double) 1077936159, 10000);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 195.99999999999997d);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        java.lang.Number number0 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) (-1), (-1201819478), orderDirection3, false);
        boolean boolean6 = nonMonotonousSequenceException5.getStrict();
        java.lang.Number number7 = nonMonotonousSequenceException5.getPrevious();
        java.lang.Number number8 = nonMonotonousSequenceException5.getArgument();
        java.lang.Number number9 = nonMonotonousSequenceException5.getPrevious();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (-1) + "'", number7.equals((-1)));
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + (-1) + "'", number9.equals((-1)));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 97L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.41032129904824216d) + "'", double1 == (-0.41032129904824216d));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        java.lang.Number number0 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 132.0d, 6, orderDirection3, false);
        java.lang.String str6 = nonMonotonousSequenceException5.toString();
        int int7 = nonMonotonousSequenceException5.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = nonMonotonousSequenceException5.getDirection();
        java.lang.Number number9 = nonMonotonousSequenceException5.getPrevious();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 5 and 6 are not increasing (132 > null)" + "'", str6.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 5 and 6 are not increasing (132 > null)"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertTrue("'" + orderDirection8 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection8.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 132.0d + "'", number9.equals(132.0d));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_OVERFLOW_AFTER_MULTIPLY;
        java.lang.String str1 = localizedFormats0.getSourceString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_OVERFLOW_AFTER_MULTIPLY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_OVERFLOW_AFTER_MULTIPLY));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "overflow, numerator too large after multiply: {0}" + "'", str1.equals("overflow, numerator too large after multiply: {0}"));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 1000L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.600902709541988d + "'", double1 == 7.600902709541988d);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_STRING_FOR_IMAGINARY_CHARACTER;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_INCREMENT_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS;
        java.lang.Object[] objArray13 = new java.lang.Object[] { 0, 0.0d, localizedFormats9, 81.55795945611504d, 10.0d, localizedFormats12 };
        org.apache.commons.math.exception.NoBracketingException noBracketingException14 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, (double) (-1L), (double) ' ', (double) 100L, (double) (short) 10, objArray13);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException15 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray13);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException16 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray13);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_STRING_FOR_IMAGINARY_CHARACTER + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_STRING_FOR_IMAGINARY_CHARACTER));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER + "'", localizedFormats9.equals(org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER));
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_INCREMENT_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS + "'", localizedFormats12.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_INCREMENT_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS));
        org.junit.Assert.assertNotNull(objArray13);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(0, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifySequence(0.0d, 10.0d, 1.3383347192042695E42d);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (-33), (double) 52.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(0.0d, (-1.960323183182555E166d));
        int int3 = regulaFalsiSolver2.getEvaluations();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NO_DENSITY_FOR_THIS_DISTRIBUTION;
        java.lang.Throwable throwable5 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM;
        java.lang.Object[] objArray9 = new java.lang.Object[] { localizedFormats7, 52L };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException10 = new org.apache.commons.math.exception.MathIllegalStateException(throwable5, (org.apache.commons.math.exception.util.Localizable) localizedFormats6, objArray9);
        org.apache.commons.math.exception.NoBracketingException noBracketingException11 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (double) (byte) 10, 0.0d, 11.04987562112089d, (double) (byte) 100, objArray9);
        double double12 = noBracketingException11.getFLo();
        double double13 = noBracketingException11.getFLo();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_DENSITY_FOR_THIS_DISTRIBUTION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_DENSITY_FOR_THIS_DISTRIBUTION));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM));
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 11.04987562112089d + "'", double12 == 11.04987562112089d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 11.04987562112089d + "'", double13 == 11.04987562112089d);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 'a', 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((-2.5093711872178237d), (double) (byte) 10, (int) 'a');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        int[] intArray0 = new int[] {};
        int[] intArray6 = new int[] { (short) 100, 100, (byte) 10, (byte) 1, (byte) -1 };
        int[] intArray7 = org.apache.commons.math.util.MathUtils.copyOf(intArray6);
        int int8 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray7);
        int[] intArray10 = org.apache.commons.math.util.MathUtils.copyOf(intArray7, 97);
        int[] intArray11 = new int[] {};
        int[] intArray17 = new int[] { (short) 100, 100, (byte) 10, (byte) 1, (byte) -1 };
        int[] intArray18 = org.apache.commons.math.util.MathUtils.copyOf(intArray17);
        int int19 = org.apache.commons.math.util.MathUtils.distance1(intArray11, intArray18);
        try {
            int int20 = org.apache.commons.math.util.MathUtils.distanceInf(intArray10, intArray18);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        double[] doubleArray3 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray3);
        double[] doubleArray6 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, 100.0d);
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) 1.0f);
        double[] doubleArray12 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray12);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, 100.0d);
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray12, (int) (byte) 1);
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray12);
        double[] doubleArray22 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray22);
        double[] doubleArray25 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray22, 100.0d);
        double[] doubleArray27 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, (double) 1.0f);
        double[] doubleArray31 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray31);
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray31, 100.0d);
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray31, (int) (byte) 1);
        double double37 = org.apache.commons.math.util.MathUtils.distance1(doubleArray25, doubleArray31);
        double double38 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray25);
        double double39 = org.apache.commons.math.util.MathUtils.distance(doubleArray12, doubleArray25);
        double[] doubleArray43 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray43);
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray43, 100.0d);
        double[] doubleArray48 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray43, (int) (byte) 1);
        double[] doubleArray52 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray52);
        double[] doubleArray55 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray52, 100.0d);
        double[] doubleArray59 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray59);
        double[] doubleArray62 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray59, 100.0d);
        double[] doubleArray64 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray59, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray64);
        boolean boolean66 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray55, doubleArray64);
        java.lang.Number number67 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection70 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException72 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number67, (java.lang.Number) 132.0d, 6, orderDirection70, false);
        boolean boolean75 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray55, orderDirection70, false, false);
        double double76 = org.apache.commons.math.util.MathUtils.distance1(doubleArray48, doubleArray55);
        try {
            double double77 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray12, doubleArray48);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 132.0d + "'", double18 == 132.0d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 132.0d + "'", double37 == 132.0d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 62.49851365652365d + "'", double38 == 62.49851365652365d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 82.49803802661121d + "'", double39 == 82.49803802661121d);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + orderDirection70 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection70.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + true + "'", boolean75 == true);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 18.20689655172414d + "'", double76 == 18.20689655172414d);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        double double2 = org.apache.commons.math.util.FastMath.pow(6.691673596021348E41d, 77116.9095292137d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test180");
        org.apache.commons.math.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math.exception.TooManyEvaluationsException((java.lang.Number) 0.9999506475305748d);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test181");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((-0.6321205588285577d));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test182");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test183");
        double double2 = org.apache.commons.math.util.FastMath.hypot((double) ' ', 3.58351893845611d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 32.200024968659164d + "'", double2 == 32.200024968659164d);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test184");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(6, 4);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test185");
        double[] doubleArray0 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection1 = null;
        try {
            boolean boolean4 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray0, orderDirection1, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test186");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.9999506475305748d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8414443185301054d + "'", double1 == 0.8414443185301054d);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test187");
        double double2 = org.apache.commons.math.util.MathUtils.round((double) (-127), 5);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-127.0d) + "'", double2 == (-127.0d));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test188");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(0, 10000);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: must have n >= k for binomial coefficient (n, k), got k = 10,000, n = 0");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test189");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(0.5463024898437905d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5738845469292326d + "'", double1 == 0.5738845469292326d);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test190");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(0L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test191");
        double double2 = org.apache.commons.math.util.FastMath.IEEEremainder(9.5367431640625E-7d, (-1.4309082844072307d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.5367431640625E-7d + "'", double2 == 9.5367431640625E-7d);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test192");
        float float1 = org.apache.commons.math.util.MathUtils.sign(4.768372E-7f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test193");
        double double2 = org.apache.commons.math.util.FastMath.copySign((double) 1L, (double) '4');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test194");
        double double2 = org.apache.commons.math.util.FastMath.min((-1.971702351536336d), (-0.6258392201887784d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.971702351536336d) + "'", double2 == (-1.971702351536336d));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test195");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.NAN_VALUE_CONVERSION;
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext5 = new org.apache.commons.math.exception.util.ExceptionContext();
        java.util.Set<java.lang.String> strSet6 = exceptionContext5.getKeys();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10.0d, (java.lang.Number) 100.0d, (int) 'a');
        java.lang.Object[] objArray13 = new java.lang.Object[] { 1.0f, strSet6, 10.0f, (short) 0, 10.0d };
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException14 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 0L, objArray13);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException15 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray13);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException16 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray13);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats17 = org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats18 = org.apache.commons.math.exception.util.LocalizedFormats.NO_DENSITY_FOR_THIS_DISTRIBUTION;
        java.lang.Throwable throwable23 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats24 = org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats25 = org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM;
        java.lang.Object[] objArray27 = new java.lang.Object[] { localizedFormats25, 52L };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException28 = new org.apache.commons.math.exception.MathIllegalStateException(throwable23, (org.apache.commons.math.exception.util.Localizable) localizedFormats24, objArray27);
        org.apache.commons.math.exception.NoBracketingException noBracketingException29 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats18, (double) (byte) 10, 0.0d, 11.04987562112089d, (double) (byte) 100, objArray27);
        java.lang.Object[] objArray30 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray27);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException31 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) mathIllegalStateException16, (org.apache.commons.math.exception.util.Localizable) localizedFormats17, objArray27);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException32 = new org.apache.commons.math.exception.NullArgumentException(localizable0, objArray27);
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NAN_VALUE_CONVERSION + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NAN_VALUE_CONVERSION));
        org.junit.Assert.assertNotNull(strSet6);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertTrue("'" + localizedFormats17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET + "'", localizedFormats17.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET));
        org.junit.Assert.assertTrue("'" + localizedFormats18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_DENSITY_FOR_THIS_DISTRIBUTION + "'", localizedFormats18.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_DENSITY_FOR_THIS_DISTRIBUTION));
        org.junit.Assert.assertTrue("'" + localizedFormats24 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizedFormats24.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + localizedFormats25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM + "'", localizedFormats25.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM));
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(objArray30);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test196");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) 1082658781, (-0.9002915473040451d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-2.023212194442749d) + "'", double2 == (-2.023212194442749d));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test197");
        long long2 = org.apache.commons.math.util.MathUtils.pow(0L, 11);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test198");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_ONE;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 100L, (java.lang.Number) Double.NaN, false);
        boolean boolean5 = numberIsTooLargeException4.getBoundIsAllowed();
        org.apache.commons.math.exception.MathInternalError mathInternalError6 = new org.apache.commons.math.exception.MathInternalError((java.lang.Throwable) numberIsTooLargeException4);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_ONE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_ONE));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test199");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_POINTS;
        java.lang.Class<?> wildcardClass1 = localizedFormats0.getClass();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException5 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 132.0d, (java.lang.Number) 0.6725571839577216d, false);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_POINTS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_POINTS));
        org.junit.Assert.assertNotNull(wildcardClass1);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test200");
        int int2 = org.apache.commons.math.util.FastMath.min(100, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test201");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NO_DENSITY_FOR_THIS_DISTRIBUTION;
        java.lang.Throwable throwable5 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM;
        java.lang.Object[] objArray9 = new java.lang.Object[] { localizedFormats7, 52L };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException10 = new org.apache.commons.math.exception.MathIllegalStateException(throwable5, (org.apache.commons.math.exception.util.Localizable) localizedFormats6, objArray9);
        org.apache.commons.math.exception.NoBracketingException noBracketingException11 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (double) (byte) 10, 0.0d, 11.04987562112089d, (double) (byte) 100, objArray9);
        double double12 = noBracketingException11.getHi();
        double double13 = noBracketingException11.getFHi();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_DENSITY_FOR_THIS_DISTRIBUTION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_DENSITY_FOR_THIS_DISTRIBUTION));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM));
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 100.0d + "'", double13 == 100.0d);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test202");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((float) 3628800L, (float) 35, (float) (-33));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test203");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) '#', (double) 1090L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test204");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 10L, (-0.0d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.999999999999998d + "'", double2 == 9.999999999999998d);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test205");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((-1.201819478E9d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test206");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.0E-15d, (java.lang.Number) (-0.8414709848078965d), 99, orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getPrevious();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (-0.8414709848078965d) + "'", number6.equals((-0.8414709848078965d)));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test207");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test208");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test209");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 9, 21024.0d);
        int int3 = regulaFalsiSolver2.getMaxEvaluations();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test210");
        float float1 = org.apache.commons.math.util.FastMath.ulp(9.536743E-7f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.1368684E-13f + "'", float1 == 1.1368684E-13f);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test211");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_BINARY_DIGIT;
        java.lang.Class<?> wildcardClass1 = localizedFormats0.getClass();
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException5 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, number2, (java.lang.Number) (-11), false);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_BINARY_DIGIT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_BINARY_DIGIT));
        org.junit.Assert.assertNotNull(wildcardClass1);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test212");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) 1100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test213");
        double double1 = org.apache.commons.math.util.FastMath.signum(8.96280949311433d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test214");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double double3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(univariateRealFunction0, 3.4657359027997265d, 10.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test215");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test216");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.AT_LEAST_ONE_COLUMN;
        java.lang.String str1 = localizedFormats0.getSourceString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.AT_LEAST_ONE_COLUMN + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.AT_LEAST_ONE_COLUMN));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "matrix must have at least one column" + "'", str1.equals("matrix must have at least one column"));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test217");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 200.0f, (java.lang.Number) 1076101120, false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test218");
        int int1 = org.apache.commons.math.util.MathUtils.sign((int) ' ');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test219");
        double double2 = org.apache.commons.math.util.FastMath.atan2(22025.465794806718d, (double) (-90L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5748824832438753d + "'", double2 == 1.5748824832438753d);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test220");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 0, (float) (-8934108775301215359L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test221");
        double double4 = org.apache.commons.math.util.MathUtils.linearCombination((double) 1, (double) 990.00006f, (-8.699715755749389E31d), (double) 196);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-1.7051442881268803E34d) + "'", double4 == (-1.7051442881268803E34d));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test222");
        long long2 = org.apache.commons.math.util.FastMath.min((-196L), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-196L) + "'", long2 == (-196L));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test223");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) ' ', (long) 5);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 33554432 + "'", int2 == 33554432);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test224");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            boolean boolean3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.isBracketing(univariateRealFunction0, 10.0d, (double) 97L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test225");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED;
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = localizedFormats0.getLocalizedString(locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test226");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(6.283185307179586d, (double) 5200, (double) 5200);
        int int4 = regulaFalsiSolver3.getEvaluations();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test227");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        int int1 = incrementor0.getCount();
        int int2 = incrementor0.getMaximalCount();
        incrementor0.setMaximalCount((int) (byte) 100);
        incrementor0.setMaximalCount(2041756729);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test228");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Throwable throwable1 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM;
        java.lang.Object[] objArray5 = new java.lang.Object[] { localizedFormats3, 52L };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException6 = new org.apache.commons.math.exception.MathIllegalStateException(throwable1, (org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray5);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException7 = new org.apache.commons.math.exception.MathIllegalStateException(localizable0, objArray5);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext8 = mathIllegalStateException7.getContext();
        java.util.Set<java.lang.String> strSet9 = exceptionContext8.getKeys();
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(exceptionContext8);
        org.junit.Assert.assertNotNull(strSet9);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test229");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) (byte) 1, 0L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test230");
        java.lang.Object obj0 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_DEFINITE_MATRIX;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_32_BITS;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException4 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, (java.lang.Number) 11.0d);
        java.lang.Throwable[] throwableArray5 = notStrictlyPositiveException4.getSuppressed();
        try {
            org.apache.commons.math.util.MathUtils.checkNotNull(obj0, (org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Object[]) throwableArray5);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: not positive definite matrix");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_DEFINITE_MATRIX + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_DEFINITE_MATRIX));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_32_BITS + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_32_BITS));
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test231");
        boolean boolean3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.isSequence(0.02051113020245179d, (double) 1082658781, (-0.6163965733697803d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test232");
        double double1 = org.apache.commons.math.util.FastMath.atanh(3.7621956910836314d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test233");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1000.0f, number1, false);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test234");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 2041756729, 1.07610112E9d, 5200);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test235");
        boolean boolean3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.isSequence(0.0927837451120071d, 0.0d, 5050.000003814698d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test236");
        int int2 = org.apache.commons.math.util.FastMath.min(33554432, (-127));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-127) + "'", int2 == (-127));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test237");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_2D_INDEX;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_2D_INDEX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_2D_INDEX));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test238");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10.0d, (java.lang.Number) 100.0d, (int) 'a');
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        int int5 = nonMonotonousSequenceException3.getIndex();
        boolean boolean6 = nonMonotonousSequenceException3.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException3.getDirection();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 97 + "'", int5 == 97);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test239");
        double double1 = org.apache.commons.math.util.FastMath.floor((-1.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test240");
        double double2 = org.apache.commons.math.util.FastMath.hypot(1.0E-15d, (double) 3136633892082024448L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.1366338920820244E18d + "'", double2 == 3.1366338920820244E18d);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test241");
        double[] doubleArray0 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection1 = null;
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray0, orderDirection1, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test242");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException((double) (-90.0f), 3.5413887082388813d, 6.47985642107054E9d, (double) 99);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test243");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET;
        org.apache.commons.math.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math.exception.NotPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 4.9E-324d);
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_WEIGHT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats19 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_INCREMENT_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS;
        java.lang.Object[] objArray20 = new java.lang.Object[] { 0, 0.0d, localizedFormats16, 81.55795945611504d, 10.0d, localizedFormats19 };
        org.apache.commons.math.exception.NoBracketingException noBracketingException21 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats9, (double) (-1L), (double) ' ', (double) 100L, (double) (short) 10, objArray20);
        org.apache.commons.math.exception.NoBracketingException noBracketingException22 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats4, (-1.4309082844072307d), 22026.465794806718d, (-0.12408049872194353d), 52.0d, objArray20);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException23 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) notPositiveException2, localizable3, objArray20);
        java.lang.Object[] objArray24 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray20);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_WEIGHT + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_WEIGHT));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS + "'", localizedFormats9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS));
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER + "'", localizedFormats16.equals(org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER));
        org.junit.Assert.assertTrue("'" + localizedFormats19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_INCREMENT_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS + "'", localizedFormats19.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_INCREMENT_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS));
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(objArray24);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test244");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 990L, 5200);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test245");
        float float2 = org.apache.commons.math.util.FastMath.nextAfter((float) (byte) -1, (-2406.4227395494577d));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0000001f) + "'", float2 == (-1.0000001f));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test246");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) 771L, (float) 4);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test247");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyBracketing(univariateRealFunction0, (-2.2239800905693157d), 200535.2282957881d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test248");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(0.0d, (-0.23251381989123973d));
        double double3 = regulaFalsiSolver2.getMax();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test249");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.MathInternalError mathInternalError1 = new org.apache.commons.math.exception.MathInternalError(throwable0);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE;
        java.lang.Throwable throwable3 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM;
        java.lang.Object[] objArray7 = new java.lang.Object[] { localizedFormats5, 52L };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException8 = new org.apache.commons.math.exception.MathIllegalStateException(throwable3, (org.apache.commons.math.exception.util.Localizable) localizedFormats4, objArray7);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext9 = mathIllegalStateException8.getContext();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext10 = mathIllegalStateException8.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats20 = org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats23 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_INCREMENT_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS;
        java.lang.Object[] objArray24 = new java.lang.Object[] { 0, 0.0d, localizedFormats20, 81.55795945611504d, 10.0d, localizedFormats23 };
        org.apache.commons.math.exception.NoBracketingException noBracketingException25 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats13, (double) (-1L), (double) ' ', (double) 100L, (double) (short) 10, objArray24);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException26 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats12, objArray24);
        exceptionContext10.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats11, objArray24);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException28 = new org.apache.commons.math.exception.MathIllegalStateException(throwable0, (org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray24);
        java.lang.String str29 = mathIllegalStateException28.toString();
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM));
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(exceptionContext9);
        org.junit.Assert.assertNotNull(exceptionContext10);
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE + "'", localizedFormats11.equals(org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE + "'", localizedFormats12.equals(org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE));
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS + "'", localizedFormats13.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS));
        org.junit.Assert.assertTrue("'" + localizedFormats20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER + "'", localizedFormats20.equals(org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER));
        org.junit.Assert.assertTrue("'" + localizedFormats23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_INCREMENT_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS + "'", localizedFormats23.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_INCREMENT_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS));
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "org.apache.commons.math.exception.MathIllegalStateException: population limit has to be positive" + "'", str29.equals("org.apache.commons.math.exception.MathIllegalStateException: population limit has to be positive"));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test250");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SAMPLE_SIZE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM;
        java.lang.Object[] objArray11 = new java.lang.Object[] { localizedFormats5, (-1), 0, localizedFormats8, 10.0d, (byte) 100 };
        java.lang.Object[] objArray12 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray11);
        java.lang.Object[] objArray13 = new java.lang.Object[] { objArray11 };
        org.apache.commons.math.exception.NoBracketingException noBracketingException14 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, 0.0d, 1.5706487647081802d, (double) 1.4E-45f, 0.0d, objArray13);
        double double15 = noBracketingException14.getLo();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SAMPLE_SIZE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SAMPLE_SIZE));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test251");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 7710, (float) 1100);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1100.0f + "'", float2 == 1100.0f);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test252");
        float float2 = org.apache.commons.math.util.FastMath.copySign(9.536743E-7f, (float) 1000L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 9.536743E-7f + "'", float2 == 9.536743E-7f);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test253");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET;
        org.apache.commons.math.exception.NotPositiveException notPositiveException7 = new org.apache.commons.math.exception.NotPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, (java.lang.Number) 4.9E-324d);
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_WEIGHT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats14 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats24 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_INCREMENT_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS;
        java.lang.Object[] objArray25 = new java.lang.Object[] { 0, 0.0d, localizedFormats21, 81.55795945611504d, 10.0d, localizedFormats24 };
        org.apache.commons.math.exception.NoBracketingException noBracketingException26 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats14, (double) (-1L), (double) ' ', (double) 100L, (double) (short) 10, objArray25);
        org.apache.commons.math.exception.NoBracketingException noBracketingException27 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats9, (-1.4309082844072307d), 22026.465794806718d, (-0.12408049872194353d), 52.0d, objArray25);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException28 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) notPositiveException7, localizable8, objArray25);
        org.apache.commons.math.exception.NoBracketingException noBracketingException29 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (-279305.0d), 0.0d, 0.0d, 0.02051113020245179d, objArray25);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_WEIGHT + "'", localizedFormats9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_WEIGHT));
        org.junit.Assert.assertTrue("'" + localizedFormats14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS + "'", localizedFormats14.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS));
        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER + "'", localizedFormats21.equals(org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER));
        org.junit.Assert.assertTrue("'" + localizedFormats24 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_INCREMENT_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS + "'", localizedFormats24.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_INCREMENT_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS));
        org.junit.Assert.assertNotNull(objArray25);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test254");
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math.exception.DimensionMismatchException(1201819478, (int) '4');
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test255");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double double3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(univariateRealFunction0, 0.0d, 2.2250738585072014E-308d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test256");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(90.0d, (double) 2852977536870709977L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test257");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(3.13663427E18f, (float) 870L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test258");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(1.7763568394002505E-15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.1003275537854505E-17d + "'", double1 == 3.1003275537854505E-17d);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test259");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.0E-15d, (java.lang.Number) (-0.8414709848078965d), 99, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        java.lang.Number number7 = nonMonotonousSequenceException5.getPrevious();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (-0.8414709848078965d) + "'", number7.equals((-0.8414709848078965d)));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test260");
        org.apache.commons.math.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math.exception.NotPositiveException((java.lang.Number) 5200.0d);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test261");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1077936159, (java.lang.Number) 1.1368684E-13f, false);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test262");
        double[] doubleArray3 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray3);
        double[] doubleArray6 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, 100.0d);
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray3, (int) (byte) 1);
        double[] doubleArray12 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray12);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, 100.0d);
        double[] doubleArray19 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray19);
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, 100.0d);
        double[] doubleArray24 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray19, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray24);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray15, doubleArray24);
        java.lang.Number number27 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection30 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException32 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number27, (java.lang.Number) 132.0d, 6, orderDirection30, false);
        boolean boolean35 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray15, orderDirection30, false, false);
        double double36 = org.apache.commons.math.util.MathUtils.distance1(doubleArray8, doubleArray15);
        double[] doubleArray40 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray40);
        double[] doubleArray43 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray40, 100.0d);
        double[] doubleArray45 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray43, (double) 1.0f);
        double[] doubleArray49 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray49);
        double[] doubleArray52 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray49, 100.0d);
        double[] doubleArray54 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray49, (int) (byte) 1);
        double double55 = org.apache.commons.math.util.MathUtils.distance1(doubleArray43, doubleArray49);
        double double56 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray43);
        double double57 = org.apache.commons.math.util.MathUtils.distance1(doubleArray15, doubleArray43);
        double[] doubleArray59 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray43, (int) ' ');
        double[] doubleArray61 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray59, 0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + orderDirection30 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection30.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 18.20689655172414d + "'", double36 == 18.20689655172414d);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 132.0d + "'", double55 == 132.0d);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 62.49851365652365d + "'", double56 == 62.49851365652365d);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray61);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test263");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray5 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, (-0.7568023394671234d), 0.6300396599891174d, 2005.3522829578812d, 2);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test264");
        org.apache.commons.math.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math.exception.TooManyEvaluationsException((java.lang.Number) 4L);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test265");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 97, 2852977536870709977L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2852977536870709880L) + "'", long2 == (-2852977536870709880L));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test266");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 2, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test267");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) (-1), (long) (byte) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test268");
        double double1 = org.apache.commons.math.util.FastMath.cos(1.2018194748584073E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6944614337199259d + "'", double1 == 0.6944614337199259d);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test269");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 5);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 5.0f + "'", float1 == 5.0f);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test270");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 990.00006f, (java.lang.Number) 10, false);
        boolean boolean4 = numberIsTooSmallException3.getBoundIsAllowed();
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) numberIsTooSmallException3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test271");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(144.99655168313487d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.679207401552301E62d + "'", double1 == 4.679207401552301E62d);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test272");
        int int2 = org.apache.commons.math.util.FastMath.min(2041756729, 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test273");
        double double2 = org.apache.commons.math.util.FastMath.pow(18.20689655172414d, 200535.2282957881d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test274");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10.0d, (java.lang.Number) 100.0d, (int) 'a');
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 100.0d + "'", number4.equals(100.0d));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test275");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(99, 61);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathArithmeticException; message: arithmetic exception");
        } catch (org.apache.commons.math.exception.MathArithmeticException e) {
        }
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test276");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE;
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException3 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) (-1.201819478E9d), objArray2);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 52.0f, (java.lang.Number) (-1), (int) (byte) 1, orderDirection7, false);
        notFiniteNumberException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException9);
        java.lang.Number number11 = nonMonotonousSequenceException9.getPrevious();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + (-1) + "'", number11.equals((-1)));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test277");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 32.000004f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test278");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver0 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        double double1 = regulaFalsiSolver0.getFunctionValueAccuracy();
        double double2 = regulaFalsiSolver0.getFunctionValueAccuracy();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction4 = null;
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution8 = org.apache.commons.math.analysis.solvers.AllowedSolution.LEFT_SIDE;
        try {
            double double9 = regulaFalsiSolver0.solve(52000, univariateRealFunction4, (double) 9.536743E-7f, 6.47985642107054E9d, 27.30822632959398d, allowedSolution8);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0E-15d + "'", double1 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E-15d + "'", double2 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + allowedSolution8 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.LEFT_SIDE + "'", allowedSolution8.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.LEFT_SIDE));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test279");
        float float2 = org.apache.commons.math.util.FastMath.copySign((float) 1100, (float) 74690L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1100.0f + "'", float2 == 1100.0f);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test280");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(2, 61);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test281");
        double[] doubleArray3 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray3);
        double[] doubleArray6 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, 100.0d);
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray3, (int) (byte) 1);
        double[] doubleArray12 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray12);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, 100.0d);
        double[] doubleArray19 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray19);
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, 100.0d);
        double[] doubleArray24 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray19, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray24);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray15, doubleArray24);
        java.lang.Number number27 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection30 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException32 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number27, (java.lang.Number) 132.0d, 6, orderDirection30, false);
        boolean boolean35 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray15, orderDirection30, false, false);
        double double36 = org.apache.commons.math.util.MathUtils.distance1(doubleArray8, doubleArray15);
        int int37 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        double[] doubleArray41 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray41);
        double[] doubleArray44 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray41, 100.0d);
        double[] doubleArray45 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray41);
        double double46 = org.apache.commons.math.util.MathUtils.distance(doubleArray15, doubleArray45);
        double[] doubleArray48 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, 58.351573254317536d);
        double[] doubleArray52 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray52);
        double[] doubleArray57 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray57);
        double[] doubleArray60 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray57, 100.0d);
        double double61 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray52, doubleArray57);
        double[] doubleArray62 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray57);
        double double63 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray15, doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + orderDirection30 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection30.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 18.20689655172414d + "'", double36 == 18.20689655172414d);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1201819478) + "'", int37 == (-1201819478));
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 82.49803802661121d + "'", double46 == 82.49803802661121d);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 21024.0d + "'", double61 == 21024.0d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 9062.068965517241d + "'", double63 == 9062.068965517241d);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test282");
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math.exception.DimensionMismatchException((-1201819478), 35);
        int int3 = dimensionMismatchException2.getDimension();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext4 = dimensionMismatchException2.getContext();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 35 + "'", int3 == 35);
        org.junit.Assert.assertNotNull(exceptionContext4);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test283");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((int) '4', 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test284");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 2852977536870709977L, (-33), 30);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathIllegalArgumentException; message: invalid rounding method 30, valid methods: ROUND_CEILING (2), ROUND_DOWN (1), ROUND_FLOOR (3), ROUND_HALF_DOWN (5), ROUND_HALF_EVEN (6), ROUND_HALF_UP (4), ROUND_UNNECESSARY (7), ROUND_UP (0)");
        } catch (org.apache.commons.math.exception.MathIllegalArgumentException e) {
        }
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test285");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException(number0, (java.lang.Number) 1.4E-45f, false);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test286");
        double[] doubleArray3 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray3);
        double[] doubleArray6 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, 100.0d);
        int int7 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        double[] doubleArray11 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray11);
        double[] doubleArray16 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray16);
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, 100.0d);
        double double20 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray11, doubleArray16);
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray16);
        double[] doubleArray25 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray25);
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, 100.0d);
        double[] doubleArray32 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray32);
        double[] doubleArray35 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray32, 100.0d);
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equals(doubleArray25, doubleArray35);
        double double37 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray35);
        double[] doubleArray39 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray35, (double) 32.000004f);
        double[] doubleArray43 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray43);
        double[] doubleArray48 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray48);
        double[] doubleArray51 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray48, 100.0d);
        double double52 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray43, doubleArray48);
        double double53 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray43);
        boolean boolean54 = org.apache.commons.math.util.MathUtils.equals(doubleArray39, doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1201819478) + "'", int7 == (-1201819478));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 21024.0d + "'", double20 == 21024.0d);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 21024.0d + "'", double52 == 21024.0d);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 144.99655168313487d + "'", double53 == 144.99655168313487d);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test287");
        double double1 = org.apache.commons.math.util.FastMath.cosh(62.49851365652365d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.945917369462911E26d + "'", double1 == 6.945917369462911E26d);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test288");
        double[] doubleArray3 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray3);
        double[] doubleArray6 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, 100.0d);
        double[] doubleArray10 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray10);
        double[] doubleArray13 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray10, 100.0d);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray10, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray15);
        boolean boolean17 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray15);
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray6);
        double[] doubleArray19 = null;
        double[] doubleArray25 = new double[] { (byte) 100, 81.55795945611504d, 1.0d, 100.0d, (-1) };
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equals(doubleArray19, doubleArray25);
        double[] doubleArray27 = null;
        double[] doubleArray33 = new double[] { (byte) 100, 81.55795945611504d, 1.0d, 100.0d, (-1) };
        boolean boolean34 = org.apache.commons.math.util.MathUtils.equals(doubleArray27, doubleArray33);
        double double35 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray25, doubleArray33);
        double[] doubleArray39 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray39);
        double[] doubleArray42 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray39, 100.0d);
        double[] doubleArray46 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray46);
        double[] doubleArray49 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray46, 100.0d);
        double[] doubleArray51 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray46, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray51);
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray42, doubleArray51);
        boolean boolean54 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray25, doubleArray42);
        double[] doubleArray58 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray58);
        double[] doubleArray61 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray58, 100.0d);
        double double62 = org.apache.commons.math.util.MathUtils.distance(doubleArray42, doubleArray61);
        double[] doubleArray64 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray42, 0);
        boolean boolean65 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray18, doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test289");
        double double1 = org.apache.commons.math.util.FastMath.log1p(8.998336506481754d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.302418729804633d + "'", double1 == 2.302418729804633d);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test290");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(7.340835974686194d, (double) 0L, 52.0d);
        double double4 = regulaFalsiSolver3.getRelativeAccuracy();
        int int5 = regulaFalsiSolver3.getMaxEvaluations();
        double double6 = regulaFalsiSolver3.getStartValue();
        double double7 = regulaFalsiSolver3.getStartValue();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 7.340835974686194d + "'", double4 == 7.340835974686194d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test291");
        double[] doubleArray0 = null;
        double[] doubleArray6 = new double[] { (byte) 100, 81.55795945611504d, 1.0d, 100.0d, (-1) };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray6);
        try {
            double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray0, 5.267884728309446d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test292");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(1000L, 25937424601L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 25937425601L + "'", long2 == 25937425601L);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test293");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray5 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, 2.958103478741511E26d, (double) 0.5f, (double) 100, 1082658781);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test294");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 0, (java.lang.Number) 1, (int) (byte) -1);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test295");
        float float1 = org.apache.commons.math.util.FastMath.nextUp((float) (byte) 1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0000001f + "'", float1 == 1.0000001f);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test296");
        double[] doubleArray3 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray3);
        double[] doubleArray8 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray8);
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray8, 100.0d);
        double double12 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray3, doubleArray8);
        double[] doubleArray13 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray8);
        java.lang.Number number14 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection17 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number14, (java.lang.Number) 132.0d, 6, orderDirection17, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray8, orderDirection17, false);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 21024.0d + "'", double12 == 21024.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + orderDirection17 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection17.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test297");
        double double1 = org.apache.commons.math.util.FastMath.log(1.8189894035458565E-12d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-27.03274004183787d) + "'", double1 == (-27.03274004183787d));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test298");
        double[] doubleArray3 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray3);
        double[] doubleArray6 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, 100.0d);
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) 1.0f);
        double[] doubleArray12 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray12);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, 100.0d);
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray12, (int) (byte) 1);
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray12);
        double[] doubleArray22 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray22);
        double[] doubleArray25 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray22, 100.0d);
        double[] doubleArray27 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, (double) 1.0f);
        double[] doubleArray31 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray31);
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray31, 100.0d);
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray31, (int) (byte) 1);
        double double37 = org.apache.commons.math.util.MathUtils.distance1(doubleArray25, doubleArray31);
        double double38 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray25);
        double double39 = org.apache.commons.math.util.MathUtils.distance(doubleArray12, doubleArray25);
        double double40 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 132.0d + "'", double18 == 132.0d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 132.0d + "'", double37 == 132.0d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 62.49851365652365d + "'", double38 == 62.49851365652365d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 82.49803802661121d + "'", double39 == 82.49803802661121d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 144.99655168313487d + "'", double40 == 144.99655168313487d);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test299");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 74690L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 74690.0f + "'", float1 == 74690.0f);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test300");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((float) 127L, (float) (byte) 10, 1077936159);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test301");
        java.lang.Number number0 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) (-1), (-1201819478), orderDirection3, false);
        boolean boolean6 = nonMonotonousSequenceException5.getStrict();
        java.lang.Number number7 = nonMonotonousSequenceException5.getPrevious();
        java.lang.Throwable throwable8 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM;
        java.lang.Object[] objArray12 = new java.lang.Object[] { localizedFormats10, 52L };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException13 = new org.apache.commons.math.exception.MathIllegalStateException(throwable8, (org.apache.commons.math.exception.util.Localizable) localizedFormats9, objArray12);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext14 = mathIllegalStateException13.getContext();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) mathIllegalStateException13);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (-1) + "'", number7.equals((-1)));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizedFormats9.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM + "'", localizedFormats10.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(exceptionContext14);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test302");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test303");
        double double6 = org.apache.commons.math.util.MathUtils.linearCombination((double) 30, 0.8414443185301054d, 27.30822632959398d, 1.0E-15d, 32.0d, (-7.151039979174052E54d));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-2.288332793335697E56d) + "'", double6 == (-2.288332793335697E56d));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test304");
        double[] doubleArray0 = null;
        double[] doubleArray3 = new double[] { 5200, 139.0d };
        double[] doubleArray6 = new double[] { 5200, 139.0d };
        double[] doubleArray9 = new double[] { 5200, 139.0d };
        double[] doubleArray12 = new double[] { 5200, 139.0d };
        double[] doubleArray15 = new double[] { 5200, 139.0d };
        double[] doubleArray18 = new double[] { 5200, 139.0d };
        double[][] doubleArray19 = new double[][] { doubleArray3, doubleArray6, doubleArray9, doubleArray12, doubleArray15, doubleArray18 };
        try {
            org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray0, doubleArray19);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test305");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm((int) (byte) 100, 1992353982);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathArithmeticException; message: arithmetic exception");
        } catch (org.apache.commons.math.exception.MathArithmeticException e) {
        }
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test306");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver0 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        double double1 = regulaFalsiSolver0.getFunctionValueAccuracy();
        double double2 = regulaFalsiSolver0.getAbsoluteAccuracy();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction4 = null;
        try {
            double double6 = regulaFalsiSolver0.solve(1076101120, univariateRealFunction4, 1.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0E-15d + "'", double1 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E-6d + "'", double2 == 1.0E-6d);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test307");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_ONE;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 100L, (java.lang.Number) Double.NaN, false);
        java.lang.Number number5 = numberIsTooLargeException4.getArgument();
        boolean boolean6 = numberIsTooLargeException4.getBoundIsAllowed();
        java.lang.Number number7 = numberIsTooLargeException4.getMax();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_ONE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_ONE));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 100L + "'", number5.equals(100L));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertEquals((double) number7, Double.NaN, 0);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test308");
        double double1 = org.apache.commons.math.util.FastMath.asin(1.695197441753835d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test309");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) 3136633892082024448L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test310");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 25937425601L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test311");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyBracketing(univariateRealFunction0, (double) 'a', 5050.000003814698d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test312");
        double[] doubleArray3 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray3);
        double[] doubleArray6 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, 100.0d);
        double[] doubleArray10 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray10);
        double[] doubleArray13 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray10, 100.0d);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray10, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray15);
        boolean boolean17 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray15);
        java.lang.Number number18 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection21 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException23 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number18, (java.lang.Number) 132.0d, 6, orderDirection21, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray15, orderDirection21, true);
        double[] doubleArray29 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray29);
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray29, 100.0d);
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray29, (int) (byte) 1);
        double double35 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray15, doubleArray34);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + orderDirection21 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection21.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test313");
        byte byte1 = org.apache.commons.math.util.MathUtils.indicator((byte) 10);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 1 + "'", byte1 == (byte) 1);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test314");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(7.340835974686194d, (double) 10000);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.340835974686195d + "'", double2 == 7.340835974686195d);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test315");
        float float1 = org.apache.commons.math.util.FastMath.ulp((float) 1L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.1920929E-7f + "'", float1 == 1.1920929E-7f);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test316");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) 3136633892082024448L, 32.000004f, (-1));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test317");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((float) 0, (float) (-90L));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test318");
        int int2 = org.apache.commons.math.util.FastMath.min(6, (-1201819478));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1201819478) + "'", int2 == (-1201819478));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test319");
        double double8 = org.apache.commons.math.util.MathUtils.linearCombination((double) 200L, 1.695197441753835d, 3.136634270039147E18d, 0.5738845469292326d, (double) 3628800L, 3.1003275537854505E-17d, 1.7763568394002505E-15d, (double) 52L);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.80006593694412058E18d + "'", double8 == 1.80006593694412058E18d);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test320");
        org.apache.commons.math.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math.exception.TooManyEvaluationsException((java.lang.Number) 0.6725571839577216d);
        java.lang.String str2 = tooManyEvaluationsException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.apache.commons.math.exception.TooManyEvaluationsException: illegal state: maximal count (0.673) exceeded: evaluations" + "'", str2.equals("org.apache.commons.math.exception.TooManyEvaluationsException: illegal state: maximal count (0.673) exceeded: evaluations"));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test321");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.DEGREES_OF_FREEDOM;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM;
        java.lang.Object[] objArray9 = new java.lang.Object[] { localizedFormats3, (-1), 0, localizedFormats6, 10.0d, (byte) 100 };
        java.lang.Object[] objArray10 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray9);
        java.lang.Object[] objArray11 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray9);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException12 = new org.apache.commons.math.exception.MaxCountExceededException(localizable1, (java.lang.Number) 32.000004f, objArray9);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException13 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray9);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext14 = mathArithmeticException13.getContext();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext15 = mathArithmeticException13.getContext();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DEGREES_OF_FREEDOM + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.DEGREES_OF_FREEDOM));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM));
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(exceptionContext14);
        org.junit.Assert.assertNotNull(exceptionContext15);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test322");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) (-1), 1000.0f, 5);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test323");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (-109L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 109.0f + "'", float1 == 109.0f);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test324");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 196, 6);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 56693912375296L + "'", long2 == 56693912375296L);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test325");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(3136633892082024448L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test326");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver0 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        double double1 = regulaFalsiSolver0.getFunctionValueAccuracy();
        double double2 = regulaFalsiSolver0.getAbsoluteAccuracy();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction4 = null;
        try {
            double double7 = regulaFalsiSolver0.solve(0, univariateRealFunction4, (double) 87L, (double) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0E-15d + "'", double1 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E-6d + "'", double2 == 1.0E-6d);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test327");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (-1.0000001f), (double) (-127));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test328");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 996176991, 2.2250738585072014E-308d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test329");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.IMAGINARY_FORMAT;
        org.apache.commons.math.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math.exception.NotPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) (-126.99999237060547d));
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.IMAGINARY_FORMAT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.IMAGINARY_FORMAT));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test330");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.1752011936438014d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test331");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 52.0f, (java.lang.Number) (-1), (int) (byte) 1, orderDirection3, false);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext6 = nonMonotonousSequenceException5.getContext();
        java.lang.Throwable[] throwableArray7 = nonMonotonousSequenceException5.getSuppressed();
        boolean boolean8 = nonMonotonousSequenceException5.getStrict();
        org.junit.Assert.assertNotNull(exceptionContext6);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test332");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 1082658781, (double) 1.0000001f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0826587809999998E9d + "'", double2 == 1.0826587809999998E9d);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test333");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((int) (byte) 100, 9);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 900 + "'", int2 == 900);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test334");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver0 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        double double1 = regulaFalsiSolver0.getMin();
        double double2 = regulaFalsiSolver0.getMin();
        int int3 = regulaFalsiSolver0.getMaxEvaluations();
        double double4 = regulaFalsiSolver0.getStartValue();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction6 = null;
        try {
            double double10 = regulaFalsiSolver0.solve((int) (short) 10, univariateRealFunction6, 1.5706487647081802d, Double.NaN, 3200.0003814697266d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test335");
        int[] intArray5 = new int[] { (short) 100, 100, (byte) 10, (byte) 1, (byte) -1 };
        int[] intArray6 = org.apache.commons.math.util.MathUtils.copyOf(intArray5);
        java.lang.Class<?> wildcardClass7 = intArray5.getClass();
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test336");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.0f, (java.lang.Number) 1L, true);
        boolean boolean4 = numberIsTooSmallException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test337");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.START_POSITION;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 770);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.START_POSITION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.START_POSITION));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test338");
        int int1 = org.apache.commons.math.util.FastMath.getExponent((float) 200L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 7 + "'", int1 == 7);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test339");
        long long2 = org.apache.commons.math.util.FastMath.min(0L, (long) 7);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test340");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((-2852977536870709880L), 720L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 40L + "'", long2 == 40L);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test341");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NO_FEASIBLE_SOLUTION;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 10.0f, (java.lang.Number) 1, true);
        java.lang.String str5 = numberIsTooSmallException4.toString();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext6 = numberIsTooSmallException4.getContext();
        java.lang.Throwable throwable7 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM;
        java.lang.Object[] objArray11 = new java.lang.Object[] { localizedFormats9, 52L };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException12 = new org.apache.commons.math.exception.MathIllegalStateException(throwable7, (org.apache.commons.math.exception.util.Localizable) localizedFormats8, objArray11);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats14 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats24 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_INCREMENT_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS;
        java.lang.Object[] objArray25 = new java.lang.Object[] { 0, 0.0d, localizedFormats21, 81.55795945611504d, 10.0d, localizedFormats24 };
        org.apache.commons.math.exception.NoBracketingException noBracketingException26 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats14, (double) (-1L), (double) ' ', (double) 100L, (double) (short) 10, objArray25);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException27 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats13, objArray25);
        exceptionContext6.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats8, objArray25);
        java.lang.Object obj30 = exceptionContext6.getValue("org.apache.commons.math.exception.TooManyEvaluationsException: illegal state: maximal count (0.673) exceeded: evaluations");
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_FEASIBLE_SOLUTION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_FEASIBLE_SOLUTION));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: no feasible solution" + "'", str5.equals("org.apache.commons.math.exception.NumberIsTooSmallException: no feasible solution"));
        org.junit.Assert.assertNotNull(exceptionContext6);
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM + "'", localizedFormats9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE + "'", localizedFormats13.equals(org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE));
        org.junit.Assert.assertTrue("'" + localizedFormats14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS + "'", localizedFormats14.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS));
        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER + "'", localizedFormats21.equals(org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER));
        org.junit.Assert.assertTrue("'" + localizedFormats24 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_INCREMENT_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS + "'", localizedFormats24.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_INCREMENT_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS));
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNull(obj30);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test342");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) '#', (long) 771);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-8843210507033658501L) + "'", long2 == (-8843210507033658501L));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test343");
        double double1 = org.apache.commons.math.util.FastMath.exp(1.9721522630525295E-31d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test344");
        double double1 = org.apache.commons.math.util.FastMath.floor(1.0E-6d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test345");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 10000, (-1L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9999L + "'", long2 == 9999L);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test346");
        int int2 = org.apache.commons.math.util.MathUtils.pow(900, 2852977536870709977L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test347");
        double double1 = org.apache.commons.math.util.FastMath.log((-1.5422326689561365d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test348");
        float float2 = org.apache.commons.math.util.FastMath.nextAfter(0.0f, (double) 3.9999998f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.4E-45f + "'", float2 == 1.4E-45f);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test349");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(57.29577951308232d, (double) 33554432);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.355443453504948E7d + "'", double2 == 3.355443453504948E7d);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test350");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 2.2250738585072014E-308d, (java.lang.Number) 0.02051113020245179d, false);
        java.lang.Throwable throwable4 = null;
        try {
            numberIsTooSmallException3.addSuppressed(throwable4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test351");
        double double1 = org.apache.commons.math.util.FastMath.log10((-0.12408049872194353d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test352");
        long long2 = org.apache.commons.math.util.FastMath.min((-8843210507033658501L), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-8843210507033658501L) + "'", long2 == (-8843210507033658501L));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test353");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, 3.6129868840628745E86d, 9.615723196941646E238d, 1.0076685815103525d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test354");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(0L, (-2852977536870709880L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2852977536870709880L) + "'", long2 == (-2852977536870709880L));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test355");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 10000);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 10000L + "'", long1 == 10000L);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test356");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(5200, 770);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5970 + "'", int2 == 5970);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test357");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(1077936159, 30);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathArithmeticException; message: arithmetic exception");
        } catch (org.apache.commons.math.exception.MathArithmeticException e) {
        }
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test358");
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyInterval((double) 7710, (double) (-1.0f));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [7,710, -1]");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test359");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(200.0f, (float) 10, 0.0f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test360");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.PERMUTATION_SIZE;
        java.lang.String str1 = localizedFormats0.getSourceString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.PERMUTATION_SIZE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.PERMUTATION_SIZE));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "permutation size ({0}" + "'", str1.equals("permutation size ({0}"));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test361");
        int int1 = org.apache.commons.math.util.FastMath.getExponent((double) 97L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test362");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM;
        java.lang.Object[] objArray4 = new java.lang.Object[] { localizedFormats2, 52L };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException5 = new org.apache.commons.math.exception.MathIllegalStateException(throwable0, (org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray4);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext6 = mathIllegalStateException5.getContext();
        java.lang.Object obj8 = exceptionContext6.getValue("org.apache.commons.math.exception.MathIllegalStateException: population limit has to be positive");
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM));
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(exceptionContext6);
        org.junit.Assert.assertNull(obj8);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test363");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) ' ');
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test364");
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math.exception.DimensionMismatchException((int) ' ', 100);
        java.lang.Number number3 = dimensionMismatchException2.getArgument();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 32 + "'", number3.equals(32));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test365");
        double double2 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.midpoint(56.89655172413793d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 28.448275862068964d + "'", double2 == 28.448275862068964d);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test366");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(11, 1076101120);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathArithmeticException; message: arithmetic exception");
        } catch (org.apache.commons.math.exception.MathArithmeticException e) {
        }
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test367");
        double double1 = org.apache.commons.math.util.FastMath.asinh(3.948148009134034E13d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 32.0d + "'", double1 == 32.0d);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test368");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(1.0779361614282227E9d, 6.945917369462911E26d, (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test369");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, 3.4657359027997265d, (double) 1, (-1.4309082844072307d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test370");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, (double) (-126.99999f), (double) (-33.0f));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test371");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray5 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, (-27.03274004183787d), (double) 32.000004f, (double) ' ', 110);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test372");
        double double1 = org.apache.commons.math.util.FastMath.floor(32.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 32.0d + "'", double1 == 32.0d);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test373");
        double double1 = org.apache.commons.math.util.FastMath.rint((-1.5422326689561365d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.0d) + "'", double1 == (-2.0d));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test374");
        double double1 = org.apache.commons.math.util.FastMath.tan(18.20689655172414d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7486856123139239d) + "'", double1 == (-0.7486856123139239d));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test375");
        float float1 = org.apache.commons.math.util.FastMath.signum(35.000004f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test376");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction1 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver5 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) '4', (double) 1.1920929E-7f, 2.718281828459045d);
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution9 = org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE;
        double double10 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide(97, univariateRealFunction1, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver5, 6.47985642107054E9d, (double) 990L, 0.0d, allowedSolution9);
        double double11 = regulaFalsiSolver5.getMax();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction13 = null;
        try {
            double double16 = regulaFalsiSolver5.solve(97, univariateRealFunction13, 9.615723196941646E238d, 3201.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + allowedSolution9 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE + "'", allowedSolution9.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 6.47985642107054E9d + "'", double10 == 6.47985642107054E9d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test377");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double double4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(univariateRealFunction0, (double) 10, (double) 0, 1.1920928955078125E-7d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test378");
        double[] doubleArray3 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray3);
        double[] doubleArray6 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, 100.0d);
        double[] doubleArray10 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray10);
        double[] doubleArray13 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray10, 100.0d);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray10, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray15);
        boolean boolean17 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray15);
        double[] doubleArray21 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray21);
        double[] doubleArray24 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray21, 100.0d);
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test379");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-35), 7710);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: must have n >= k for binomial coefficient (n, k), got k = 7,710, n = -35");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test380");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 5200, (long) '#');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5200L + "'", long2 == 5200L);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test381");
        double double1 = org.apache.commons.math.util.FastMath.atanh(90.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test382");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 87L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test383");
        double double1 = org.apache.commons.math.util.FastMath.acos(3.6962708958568578d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test384");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double double4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(univariateRealFunction0, (-1.5422326689561365d), 1.9721522630525295E-31d, (double) 3628800L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test385");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray5 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, 1.570527203285422d, 0.0d, 2.718281828459045d, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test386");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double double3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(univariateRealFunction0, 0.5738845469292326d, (double) 990L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test387");
        org.apache.commons.math.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math.exception.TooManyEvaluationsException((java.lang.Number) 52L);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext2 = tooManyEvaluationsException1.getContext();
        java.lang.Object obj4 = exceptionContext2.getValue("");
        org.junit.Assert.assertNotNull(exceptionContext2);
        org.junit.Assert.assertNull(obj4);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test388");
        long long1 = org.apache.commons.math.util.MathUtils.factorial(7);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 5040L + "'", long1 == 5040L);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test389");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((float) 100, (float) 2041756729, 1992353982);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test390");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 33554432, (float) 771);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 3.3554432E7f + "'", float2 == 3.3554432E7f);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test391");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((int) (short) 100, (-127));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-12700) + "'", int2 == (-12700));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test392");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_STRING_FOR_IMAGINARY_CHARACTER;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM;
        java.lang.Object[] objArray9 = new java.lang.Object[] { localizedFormats3, (-1), 0, localizedFormats6, 10.0d, (byte) 100 };
        java.lang.Object[] objArray10 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray9);
        java.lang.Object[] objArray11 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray9);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException12 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray11);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException13 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 2, objArray11);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_STRING_FOR_IMAGINARY_CHARACTER + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_STRING_FOR_IMAGINARY_CHARACTER));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM));
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(objArray11);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test393");
        double double3 = org.apache.commons.math.util.MathUtils.reduce(4.806217383937352E-6d, 74690.00000000001d, (double) 3136633892082024448L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 48640.0d + "'", double3 == 48640.0d);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test394");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_WEIGHT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_INCREMENT_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS;
        java.lang.Object[] objArray16 = new java.lang.Object[] { 0, 0.0d, localizedFormats12, 81.55795945611504d, 10.0d, localizedFormats15 };
        org.apache.commons.math.exception.NoBracketingException noBracketingException17 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, (double) (-1L), (double) ' ', (double) 100L, (double) (short) 10, objArray16);
        org.apache.commons.math.exception.NoBracketingException noBracketingException18 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (-1.4309082844072307d), 22026.465794806718d, (-0.12408049872194353d), 52.0d, objArray16);
        java.lang.Number number19 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection22 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException24 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number19, (java.lang.Number) 132.0d, 6, orderDirection22, false);
        noBracketingException18.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException24);
        int int26 = nonMonotonousSequenceException24.getIndex();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_WEIGHT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_WEIGHT));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS));
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER + "'", localizedFormats12.equals(org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER));
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_INCREMENT_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS + "'", localizedFormats15.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_INCREMENT_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS));
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertTrue("'" + orderDirection22 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection22.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 6 + "'", int26 == 6);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test395");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) (-33.0f), 3628800.0d);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction4 = null;
        try {
            double double7 = regulaFalsiSolver2.solve(0, univariateRealFunction4, 52.0d, 5.267884728309446d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test396");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_ENOUGH_POINTS_IN_SPLINE_PARTITION;
        java.lang.String str1 = localizedFormats0.getSourceString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_ENOUGH_POINTS_IN_SPLINE_PARTITION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_ENOUGH_POINTS_IN_SPLINE_PARTITION));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "spline partition must have at least {0} points, got {1}" + "'", str1.equals("spline partition must have at least {0} points, got {1}"));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test397");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) (-12700));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-12700.0d) + "'", double1 == (-12700.0d));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test398");
        double double1 = org.apache.commons.math.util.FastMath.exp(2.69123515971881d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 14.749883135224437d + "'", double1 == 14.749883135224437d);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test399");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((int) (short) 10, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test400");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException(0.0d, (double) 3.9999998f, (-1.5422326689561365d), (double) 196);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test401");
        double double2 = org.apache.commons.math.util.FastMath.IEEEremainder(3.1366342700391465E18d, (double) (-90L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-4.0d) + "'", double2 == (-4.0d));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test402");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8813735870195429d) + "'", double1 == (-0.8813735870195429d));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test403");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 196L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9395300555699313d + "'", double1 == 0.9395300555699313d);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test404");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        int int1 = incrementor0.getCount();
        int int2 = incrementor0.getMaximalCount();
        int int3 = incrementor0.getCount();
        int int4 = incrementor0.getMaximalCount();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test405");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(1.0779361614282227E9d);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction3 = null;
        try {
            double double7 = regulaFalsiSolver1.solve(1201819575, univariateRealFunction3, 7.105427357601002E-15d, (double) 1.08265882E9f, 1.0986122886681098d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test406");
        boolean boolean3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.isSequence((double) 5, 52.0d, (-1.7051442881268803E34d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test407");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) (-127), (float) 1100, 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test408");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.125274658203125d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test409");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NO_FEASIBLE_SOLUTION;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 10.0f, (java.lang.Number) 1, true);
        java.lang.String str5 = numberIsTooSmallException4.toString();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext6 = numberIsTooSmallException4.getContext();
        java.lang.Throwable throwable7 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM;
        java.lang.Object[] objArray11 = new java.lang.Object[] { localizedFormats9, 52L };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException12 = new org.apache.commons.math.exception.MathIllegalStateException(throwable7, (org.apache.commons.math.exception.util.Localizable) localizedFormats8, objArray11);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats14 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats24 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_INCREMENT_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS;
        java.lang.Object[] objArray25 = new java.lang.Object[] { 0, 0.0d, localizedFormats21, 81.55795945611504d, 10.0d, localizedFormats24 };
        org.apache.commons.math.exception.NoBracketingException noBracketingException26 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats14, (double) (-1L), (double) ' ', (double) 100L, (double) (short) 10, objArray25);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException27 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats13, objArray25);
        exceptionContext6.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats8, objArray25);
        java.util.Set<java.lang.String> strSet29 = exceptionContext6.getKeys();
        java.lang.Object obj31 = exceptionContext6.getValue("");
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_FEASIBLE_SOLUTION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_FEASIBLE_SOLUTION));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: no feasible solution" + "'", str5.equals("org.apache.commons.math.exception.NumberIsTooSmallException: no feasible solution"));
        org.junit.Assert.assertNotNull(exceptionContext6);
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM + "'", localizedFormats9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE + "'", localizedFormats13.equals(org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE));
        org.junit.Assert.assertTrue("'" + localizedFormats14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS + "'", localizedFormats14.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS));
        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER + "'", localizedFormats21.equals(org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER));
        org.junit.Assert.assertTrue("'" + localizedFormats24 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_INCREMENT_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS + "'", localizedFormats24.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_INCREMENT_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS));
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(strSet29);
        org.junit.Assert.assertNull(obj31);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test410");
        double double2 = org.apache.commons.math.util.FastMath.IEEEremainder((double) 996176991L, (double) 1082658781);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-8.648179E7d) + "'", double2 == (-8.648179E7d));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test411");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_PARAMETERS_RELATIVE_TOLERANCE;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (int) (short) 10, 5);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_PARAMETERS_RELATIVE_TOLERANCE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_PARAMETERS_RELATIVE_TOLERANCE));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test412");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1.0338699625793383E32d, (java.lang.Number) 1.80006593694412058E18d, true);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test413");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(0.0d);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction3 = null;
        try {
            double double5 = regulaFalsiSolver1.solve(5970, univariateRealFunction3, 57.29577951308233d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test414");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((float) 5970, (float) 97L, (float) (-1201819478));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test415");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.6725571839577216d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test416");
        double double1 = org.apache.commons.math.util.FastMath.cos((-0.41032129904824216d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9169927026825043d + "'", double1 == 0.9169927026825043d);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test417");
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext0 = new org.apache.commons.math.exception.util.ExceptionContext();
        java.util.Set<java.lang.String> strSet1 = exceptionContext0.getKeys();
        java.util.Set<java.lang.String> strSet2 = exceptionContext0.getKeys();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.SINGULAR_MATRIX;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_WEIGHT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats19 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_INCREMENT_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS;
        java.lang.Object[] objArray20 = new java.lang.Object[] { 0, 0.0d, localizedFormats16, 81.55795945611504d, 10.0d, localizedFormats19 };
        org.apache.commons.math.exception.NoBracketingException noBracketingException21 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats9, (double) (-1L), (double) ' ', (double) 100L, (double) (short) 10, objArray20);
        org.apache.commons.math.exception.NoBracketingException noBracketingException22 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats4, (-1.4309082844072307d), 22026.465794806718d, (-0.12408049872194353d), 52.0d, objArray20);
        exceptionContext0.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats3, objArray20);
        exceptionContext0.setValue("", (java.lang.Object) 993.8153752080916d);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats28 = org.apache.commons.math.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_ONE;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException32 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats28, (java.lang.Number) 100L, (java.lang.Number) Double.NaN, false);
        exceptionContext0.setValue("overflow, numerator too large after multiply: {0}", (java.lang.Object) Double.NaN);
        org.junit.Assert.assertNotNull(strSet1);
        org.junit.Assert.assertNotNull(strSet2);
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SINGULAR_MATRIX + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.SINGULAR_MATRIX));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_WEIGHT + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_WEIGHT));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS + "'", localizedFormats9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS));
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER + "'", localizedFormats16.equals(org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER));
        org.junit.Assert.assertTrue("'" + localizedFormats19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_INCREMENT_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS + "'", localizedFormats19.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_INCREMENT_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS));
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertTrue("'" + localizedFormats28 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_ONE + "'", localizedFormats28.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_ONE));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test418");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((float) 5040L, (float) 1201819575);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test419");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(10.04987562112089d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11576.453445247696d + "'", double1 == 11576.453445247696d);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test420");
        double double1 = org.apache.commons.math.util.FastMath.ceil(32.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 32.0d + "'", double1 == 32.0d);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test421");
        double[] doubleArray3 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray3);
        double[] doubleArray6 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, 100.0d);
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray3, (int) (byte) 1);
        double[] doubleArray10 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray8, (-0.6163965733697803d));
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray10, orderDirection11, true);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray10, 200535.22829578814d);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray15);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test422");
        double double1 = org.apache.commons.math.util.FastMath.log(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test423");
        int int1 = org.apache.commons.math.util.MathUtils.sign(100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test424");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray5 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, 5.298292365610486d, 11013.232874703393d, 4.806217383937352E-6d, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test425");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray5 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, (-2.2239800905693157d), 1.5707963259628248d, 57.29577951308233d, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test426");
        long long1 = org.apache.commons.math.util.FastMath.abs(10000L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 10000L + "'", long1 == 10000L);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test427");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, 1.0986122886681098d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test428");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(32.200024968659164d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.822399275321542E13d + "'", double1 == 4.822399275321542E13d);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test429");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException((double) 11, 1.07610112E9d, (double) (byte) 0, 5050.000003814697d);
        double double5 = noBracketingException4.getFLo();
        double double6 = noBracketingException4.getFLo();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test430");
        int int2 = org.apache.commons.math.util.FastMath.min(0, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test431");
        double[] doubleArray0 = null;
        double[] doubleArray6 = new double[] { (byte) 100, 81.55795945611504d, 1.0d, 100.0d, (-1) };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray6);
        double[] doubleArray8 = null;
        double[] doubleArray14 = new double[] { (byte) 100, 81.55795945611504d, 1.0d, 100.0d, (-1) };
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray8, doubleArray14);
        double double16 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray6, doubleArray14);
        double[] doubleArray20 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray20);
        double[] doubleArray23 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray20, 100.0d);
        double[] doubleArray27 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray27);
        double[] doubleArray30 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, 100.0d);
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray27, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray32);
        boolean boolean34 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray23, doubleArray32);
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray23);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test432");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test433");
        java.lang.Object[] objArray0 = null;
        java.lang.Object[] objArray1 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray0);
        org.junit.Assert.assertNotNull(objArray1);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test434");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 97);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.691673596021348E41d + "'", double1 == 6.691673596021348E41d);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test435");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(11);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.99168E7d + "'", double1 == 3.99168E7d);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test436");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.BETA;
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = localizedFormats0.getLocalizedString(locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.BETA + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.BETA));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test437");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((-33), 1082658816);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test438");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((-2406.4227395494577d), 1.0986122886681098d, (double) 5970);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test439");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 35.00000000000001d + "'", double1 == 35.00000000000001d);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test440");
        double double1 = org.apache.commons.math.util.FastMath.tan((-0.12408049872194353d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.12472122473624835d) + "'", double1 == (-0.12472122473624835d));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test441");
        double double1 = org.apache.commons.math.util.MathUtils.sign(3200.0003814697266d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test442");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException((double) (-1.0f), (double) 771L, (double) 3136633892082024448L, 1.0d);
        double double5 = noBracketingException4.getFHi();
        double double6 = noBracketingException4.getLo();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.0d) + "'", double6 == (-1.0d));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test443");
        double double1 = org.apache.commons.math.util.FastMath.expm1(10.049875621120892d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 23151.906933686558d + "'", double1 == 23151.906933686558d);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test444");
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math.exception.DimensionMismatchException((-35), 5970);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test445");
        double double2 = org.apache.commons.math.util.MathUtils.log(0.0d, 3.5553481704807584d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.0d) + "'", double2 == (-0.0d));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test446");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        int int1 = incrementor0.getCount();
        incrementor0.resetCount();
        int int3 = incrementor0.getMaximalCount();
        try {
            incrementor0.incrementCount();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MaxCountExceededException; message: illegal state: maximal count (0) exceeded");
        } catch (org.apache.commons.math.exception.MaxCountExceededException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test447");
        long long2 = org.apache.commons.math.util.FastMath.min(771L, 56693912375296L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 771L + "'", long2 == 771L);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test448");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialLog((-11));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: must have n >= 0 for n!, got n = -11");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test449");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.9395300555699313d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.558778651959462d + "'", double1 == 2.558778651959462d);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test450");
        double double1 = org.apache.commons.math.util.MathUtils.sign(0.5738845469292326d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test451");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_ABSCISSA;
        org.apache.commons.math.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math.exception.NotPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) (short) 100);
        java.lang.Number number3 = notPositiveException2.getArgument();
        org.apache.commons.math.exception.MathInternalError mathInternalError4 = new org.apache.commons.math.exception.MathInternalError((java.lang.Throwable) notPositiveException2);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.DEGREES_OF_FREEDOM;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM;
        java.lang.Object[] objArray14 = new java.lang.Object[] { localizedFormats8, (-1), 0, localizedFormats11, 10.0d, (byte) 100 };
        java.lang.Object[] objArray15 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray14);
        java.lang.Object[] objArray16 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray14);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException17 = new org.apache.commons.math.exception.MaxCountExceededException(localizable6, (java.lang.Number) 32.000004f, objArray14);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException18 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, objArray14);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException22 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.028563657838759995d, (java.lang.Number) 97, 11);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext23 = nonMonotonousSequenceException22.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats24 = org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_ADDITION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats25 = org.apache.commons.math.exception.util.LocalizedFormats.RANDOMKEY_MUTATION_WRONG_CLASS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats26 = org.apache.commons.math.exception.util.LocalizedFormats.NO_DENSITY_FOR_THIS_DISTRIBUTION;
        java.lang.Throwable throwable31 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats32 = org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats33 = org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM;
        java.lang.Object[] objArray35 = new java.lang.Object[] { localizedFormats33, 52L };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException36 = new org.apache.commons.math.exception.MathIllegalStateException(throwable31, (org.apache.commons.math.exception.util.Localizable) localizedFormats32, objArray35);
        org.apache.commons.math.exception.NoBracketingException noBracketingException37 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats26, (double) (byte) 10, 0.0d, 11.04987562112089d, (double) (byte) 100, objArray35);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException38 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats25, objArray35);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats39 = org.apache.commons.math.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats40 = org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats43 = org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM;
        java.lang.Object[] objArray46 = new java.lang.Object[] { localizedFormats40, (-1), 0, localizedFormats43, 10.0d, (byte) 100 };
        java.lang.Object[] objArray47 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray46);
        java.lang.Object[] objArray48 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray46);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException49 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats39, objArray48);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException50 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats25, objArray48);
        exceptionContext23.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats24, objArray48);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException52 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) notPositiveException2, (org.apache.commons.math.exception.util.Localizable) localizedFormats5, objArray48);
        java.lang.Number number53 = notPositiveException2.getMin();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_ABSCISSA + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_ABSCISSA));
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + (short) 100 + "'", number3.equals((short) 100));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DEGREES_OF_FREEDOM + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.DEGREES_OF_FREEDOM));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY));
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM + "'", localizedFormats11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(exceptionContext23);
        org.junit.Assert.assertTrue("'" + localizedFormats24 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_ADDITION + "'", localizedFormats24.equals(org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_ADDITION));
        org.junit.Assert.assertTrue("'" + localizedFormats25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.RANDOMKEY_MUTATION_WRONG_CLASS + "'", localizedFormats25.equals(org.apache.commons.math.exception.util.LocalizedFormats.RANDOMKEY_MUTATION_WRONG_CLASS));
        org.junit.Assert.assertTrue("'" + localizedFormats26 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_DENSITY_FOR_THIS_DISTRIBUTION + "'", localizedFormats26.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_DENSITY_FOR_THIS_DISTRIBUTION));
        org.junit.Assert.assertTrue("'" + localizedFormats32 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizedFormats32.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + localizedFormats33 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM + "'", localizedFormats33.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM));
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertTrue("'" + localizedFormats39 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA + "'", localizedFormats39.equals(org.apache.commons.math.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA));
        org.junit.Assert.assertTrue("'" + localizedFormats40 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY + "'", localizedFormats40.equals(org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY));
        org.junit.Assert.assertTrue("'" + localizedFormats43 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM + "'", localizedFormats43.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM));
        org.junit.Assert.assertNotNull(objArray46);
        org.junit.Assert.assertNotNull(objArray47);
        org.junit.Assert.assertNotNull(objArray48);
        org.junit.Assert.assertTrue("'" + number53 + "' != '" + 0 + "'", number53.equals(0));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test452");
        java.lang.Number number0 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 132.0d, 6, orderDirection3, false);
        boolean boolean6 = nonMonotonousSequenceException5.getStrict();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test453");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM;
        java.lang.Object[] objArray7 = new java.lang.Object[] { localizedFormats1, (-1), 0, localizedFormats4, 10.0d, (byte) 100 };
        java.lang.Object[] objArray8 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray7);
        java.lang.Object[] objArray9 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray7);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException10 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray7);
        java.util.Locale locale11 = null;
        try {
            java.lang.String str12 = localizedFormats0.getLocalizedString(locale11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM));
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(objArray9);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test454");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 30, 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0000000000000002d + "'", double2 == 1.0000000000000002d);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test455");
        double double8 = org.apache.commons.math.util.MathUtils.linearCombination((double) 110, Double.NaN, (double) 52000, (double) (byte) -1, 1.0826587809999998E9d, 0.0d, (double) 0.5f, 56.89655172413793d);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test456");
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math.exception.DimensionMismatchException(100, (int) 'a');
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test457");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-0.8414709848078965d));
        java.lang.Number number2 = notStrictlyPositiveException1.getArgument();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + (-0.8414709848078965d) + "'", number2.equals((-0.8414709848078965d)));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test458");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(996176991);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathArithmeticException; message: arithmetic exception");
        } catch (org.apache.commons.math.exception.MathArithmeticException e) {
        }
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test459");
        float[] floatArray3 = new float[] { 2L, 100, (-1L) };
        float[] floatArray7 = new float[] { 770, 'a', (short) 1 };
        float[] floatArray13 = new float[] { 100L, (byte) 10, (short) -1, 100L, 32.000004f };
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray7, floatArray13);
        float[] floatArray18 = new float[] { 770, 'a', (short) 1 };
        float[] floatArray24 = new float[] { 100L, (byte) 10, (short) -1, 100L, 32.000004f };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray18, floatArray24);
        float[] floatArray29 = new float[] { 770, 'a', (short) 1 };
        float[] floatArray35 = new float[] { 100L, (byte) 10, (short) -1, 100L, 32.000004f };
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray29, floatArray35);
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equals(floatArray18, floatArray29);
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equals(floatArray13, floatArray18);
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray3, floatArray13);
        float[] floatArray43 = new float[] { 770, 'a', (short) 1 };
        float[] floatArray49 = new float[] { 100L, (byte) 10, (short) -1, 100L, 32.000004f };
        boolean boolean50 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray43, floatArray49);
        float[] floatArray54 = new float[] { 770, 'a', (short) 1 };
        float[] floatArray60 = new float[] { 100L, (byte) 10, (short) -1, 100L, 32.000004f };
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray54, floatArray60);
        float[] floatArray65 = new float[] { 770, 'a', (short) 1 };
        float[] floatArray71 = new float[] { 100L, (byte) 10, (short) -1, 100L, 32.000004f };
        boolean boolean72 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray65, floatArray71);
        boolean boolean73 = org.apache.commons.math.util.MathUtils.equals(floatArray54, floatArray65);
        boolean boolean74 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray43, floatArray65);
        boolean boolean75 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray13, floatArray43);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(floatArray29);
        org.junit.Assert.assertNotNull(floatArray35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(floatArray43);
        org.junit.Assert.assertNotNull(floatArray49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(floatArray54);
        org.junit.Assert.assertNotNull(floatArray60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(floatArray65);
        org.junit.Assert.assertNotNull(floatArray71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + true + "'", boolean73 == true);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test460");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) 9999L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test461");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_VALUE_CONVERSION;
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException3 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 2.04175654E9f, objArray2);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_VALUE_CONVERSION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_VALUE_CONVERSION));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test462");
        byte byte1 = org.apache.commons.math.util.MathUtils.sign((byte) 1);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 1 + "'", byte1 == (byte) 1);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test463");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 5200);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 5200.0f + "'", float1 == 5200.0f);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test464");
        long long2 = org.apache.commons.math.util.MathUtils.pow(74690L, (int) 'a');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test465");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(0.0d, 0.0d, 127);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test466");
        double double6 = org.apache.commons.math.util.MathUtils.linearCombination(0.02051113020245179d, 5.298292365610485d, (double) 4L, 1.07610112E9d, 1.1920928955078125E-7d, 3.355443453504948E7d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.304404484108674E9d + "'", double6 == 4.304404484108674E9d);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test467");
        float float1 = org.apache.commons.math.util.MathUtils.indicator(990.00006f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test468");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_WEIGHT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_INCREMENT_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS;
        java.lang.Object[] objArray16 = new java.lang.Object[] { 0, 0.0d, localizedFormats12, 81.55795945611504d, 10.0d, localizedFormats15 };
        org.apache.commons.math.exception.NoBracketingException noBracketingException17 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, (double) (-1L), (double) ' ', (double) 100L, (double) (short) 10, objArray16);
        org.apache.commons.math.exception.NoBracketingException noBracketingException18 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (-1.4309082844072307d), 22026.465794806718d, (-0.12408049872194353d), 52.0d, objArray16);
        java.lang.Object[] objArray19 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray16);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_WEIGHT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_WEIGHT));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS));
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER + "'", localizedFormats12.equals(org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER));
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_INCREMENT_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS + "'", localizedFormats15.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_INCREMENT_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS));
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(objArray19);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test469");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10.0d, (java.lang.Number) 100.0d, (int) 'a');
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection4 = nonMonotonousSequenceException3.getDirection();
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection4.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test470");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(5200, 52000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52000 + "'", int2 == 52000);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test471");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) 10000);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test472");
        double[] doubleArray3 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray3);
        double[] doubleArray6 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, 100.0d);
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) 1.0f);
        double[] doubleArray12 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray12);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, 100.0d);
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray12, (int) (byte) 1);
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray12);
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, (double) (byte) 10);
        double[] doubleArray24 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray24);
        double[] doubleArray27 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray24, 100.0d);
        double[] doubleArray31 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray31);
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray31, 100.0d);
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equals(doubleArray24, doubleArray34);
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 132.0d + "'", double18 == 132.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test473");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(771, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test474");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Throwable throwable1 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM;
        java.lang.Object[] objArray5 = new java.lang.Object[] { localizedFormats3, 52L };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException6 = new org.apache.commons.math.exception.MathIllegalStateException(throwable1, (org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray5);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext7 = mathIllegalStateException6.getContext();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext8 = mathIllegalStateException6.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats18 = org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_INCREMENT_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS;
        java.lang.Object[] objArray22 = new java.lang.Object[] { 0, 0.0d, localizedFormats18, 81.55795945611504d, 10.0d, localizedFormats21 };
        org.apache.commons.math.exception.NoBracketingException noBracketingException23 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats11, (double) (-1L), (double) ' ', (double) 100L, (double) (short) 10, objArray22);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException24 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats10, objArray22);
        exceptionContext8.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats9, objArray22);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException26 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, objArray22);
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(exceptionContext7);
        org.junit.Assert.assertNotNull(exceptionContext8);
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE + "'", localizedFormats9.equals(org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE + "'", localizedFormats10.equals(org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE));
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS + "'", localizedFormats11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS));
        org.junit.Assert.assertTrue("'" + localizedFormats18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER + "'", localizedFormats18.equals(org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER));
        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_INCREMENT_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS + "'", localizedFormats21.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_INCREMENT_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS));
        org.junit.Assert.assertNotNull(objArray22);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test475");
        int[] intArray5 = new int[] { (short) 100, 100, (byte) 10, (byte) 1, (byte) -1 };
        int[] intArray6 = org.apache.commons.math.util.MathUtils.copyOf(intArray5);
        int[] intArray12 = new int[] { (short) 100, 100, (byte) 10, (byte) 1, (byte) -1 };
        int[] intArray13 = org.apache.commons.math.util.MathUtils.copyOf(intArray12);
        int int14 = org.apache.commons.math.util.MathUtils.distance1(intArray5, intArray13);
        int[] intArray20 = new int[] { (short) 100, 100, (byte) 10, (byte) 1, (byte) -1 };
        int[] intArray21 = org.apache.commons.math.util.MathUtils.copyOf(intArray20);
        int[] intArray27 = new int[] { (short) 100, 100, (byte) 10, (byte) 1, (byte) -1 };
        int[] intArray28 = org.apache.commons.math.util.MathUtils.copyOf(intArray27);
        int int29 = org.apache.commons.math.util.MathUtils.distance1(intArray20, intArray28);
        double double30 = org.apache.commons.math.util.MathUtils.distance(intArray13, intArray28);
        int[] intArray36 = new int[] { (short) 100, 100, (byte) 10, (byte) 1, (byte) -1 };
        int[] intArray37 = org.apache.commons.math.util.MathUtils.copyOf(intArray36);
        int[] intArray40 = new int[] { 99, 'a' };
        int[] intArray46 = new int[] { (short) 100, 100, (byte) 10, (byte) 1, (byte) -1 };
        int[] intArray47 = org.apache.commons.math.util.MathUtils.copyOf(intArray46);
        int int48 = org.apache.commons.math.util.MathUtils.distance1(intArray40, intArray46);
        int[] intArray50 = org.apache.commons.math.util.MathUtils.copyOf(intArray46, 770);
        double double51 = org.apache.commons.math.util.MathUtils.distance(intArray37, intArray50);
        int int52 = org.apache.commons.math.util.MathUtils.distance1(intArray13, intArray50);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 4 + "'", int48 == 4);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test476");
        java.lang.Number number0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException(number0, number1, true);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test477");
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifySequence(57.29577951308232d, (-0.0d), (-2.2239800905693157d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [57.296, -0]");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test478");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((float) 35, (float) (short) 100, 1082658816);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test479");
        org.apache.commons.math.util.MathUtils.checkFinite((double) 30000L);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test480");
        double double1 = org.apache.commons.math.util.MathUtils.sign(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test481");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) 25937424601L, (float) 1076101120);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test482");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 1.07793613E9f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 20.798314057214018d + "'", double1 == 20.798314057214018d);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test483");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(7.340835974686194d, (double) 0L, 52.0d);
        double double4 = regulaFalsiSolver3.getRelativeAccuracy();
        int int5 = regulaFalsiSolver3.getMaxEvaluations();
        double double6 = regulaFalsiSolver3.getStartValue();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction8 = null;
        try {
            double double12 = regulaFalsiSolver3.solve((int) (short) -1, univariateRealFunction8, 0.0d, (double) 9999L, (double) 10000);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 7.340835974686194d + "'", double4 == 7.340835974686194d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test484");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.6847407003485128d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6401208592545207d + "'", double1 == 0.6401208592545207d);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test485");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 32.000004f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.174802230091695d + "'", double1 == 3.174802230091695d);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test486");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray5 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, 5.298292365610486d, 0.0d, 10.049875621120892d, 139);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test487");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) (-90L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test488");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 52.0f, (java.lang.Number) (-1), (int) (byte) 1, orderDirection3, false);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext6 = nonMonotonousSequenceException5.getContext();
        java.util.Set<java.lang.String> strSet7 = exceptionContext6.getKeys();
        java.util.Set<java.lang.String> strSet8 = exceptionContext6.getKeys();
        org.junit.Assert.assertNotNull(exceptionContext6);
        org.junit.Assert.assertNotNull(strSet7);
        org.junit.Assert.assertNotNull(strSet8);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test489");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, (-2.0d), 35.0d, 3.6129868840628745E86d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test490");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_FRACTION_TO_DIVIDE_BY;
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException2 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray1);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_FRACTION_TO_DIVIDE_BY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_FRACTION_TO_DIVIDE_BY));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test491");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(139, (-127));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test492");
        long long2 = org.apache.commons.math.util.FastMath.max(56693912375296L, 25937424601L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 56693912375296L + "'", long2 == 56693912375296L);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test493");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NO_RESULT_AVAILABLE;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, number1, (java.lang.Number) 6.617416307822852E84d, false);
        java.lang.Number number5 = numberIsTooLargeException4.getMax();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_RESULT_AVAILABLE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_RESULT_AVAILABLE));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 6.617416307822852E84d + "'", number5.equals(6.617416307822852E84d));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test494");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver0 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        int int1 = regulaFalsiSolver0.getMaxEvaluations();
        int int2 = regulaFalsiSolver0.getEvaluations();
        double double3 = regulaFalsiSolver0.getMax();
        double double4 = regulaFalsiSolver0.getFunctionValueAccuracy();
        int int5 = regulaFalsiSolver0.getMaxEvaluations();
        int int6 = regulaFalsiSolver0.getMaxEvaluations();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-15d + "'", double4 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test495");
        double double1 = org.apache.commons.math.util.FastMath.signum(2.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test496");
        double[] doubleArray3 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray3);
        double[] doubleArray6 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, 100.0d);
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray3, (int) (byte) 1);
        double[] doubleArray12 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray12);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, 100.0d);
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray12);
        double double17 = org.apache.commons.math.util.MathUtils.distance1(doubleArray8, doubleArray12);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray8);
        double[] doubleArray22 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray22);
        double[] doubleArray25 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray22, 100.0d);
        int int26 = org.apache.commons.math.util.MathUtils.hash(doubleArray25);
        double[] doubleArray30 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray30);
        double[] doubleArray35 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray35);
        double[] doubleArray38 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray35, 100.0d);
        double double39 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray30, doubleArray35);
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equals(doubleArray25, doubleArray35);
        double[] doubleArray44 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray44);
        double[] doubleArray47 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray44, 100.0d);
        double[] doubleArray51 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray51);
        double[] doubleArray54 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray51, 100.0d);
        boolean boolean55 = org.apache.commons.math.util.MathUtils.equals(doubleArray44, doubleArray54);
        double double56 = org.apache.commons.math.util.MathUtils.distance1(doubleArray25, doubleArray54);
        double[] doubleArray60 = new double[] { ' ', (byte) 100, 100 };
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray60);
        double[] doubleArray63 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray60, 100.0d);
        double[] doubleArray64 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray60);
        int int65 = org.apache.commons.math.util.MathUtils.hash(doubleArray60);
        double[] doubleArray67 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray60, 6.283185307179586d);
        double double68 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray54, doubleArray67);
        try {
            double double69 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray8, doubleArray54);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 1 != 3");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1201819478) + "'", int26 == (-1201819478));
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 21024.0d + "'", double39 == 21024.0d);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 996176991 + "'", int65 == 996176991);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 245.42525248614677d + "'", double68 == 245.42525248614677d);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test497");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(1.5748824832438753d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.3115710387071804d + "'", double1 == 2.3115710387071804d);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test498");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, (-8.699715755749389E31d), (double) 10000);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test499");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 1076101120, (double) 3136633892082024448L, (double) 33554432);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test500");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 3, (long) 32);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
    }
}

