import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(0, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 190);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(Double.POSITIVE_INFINITY, 2.154434690031884d, 0.8540775674112082d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        double double3 = org.apache.commons.math.util.MathUtils.round((double) 11, 87, 1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 11.0d + "'", double3 == 11.0d);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        double double1 = org.apache.commons.math.util.MathUtils.sign((-2.378849044627155E-271d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        double double2 = org.apache.commons.math.util.MathUtils.round((double) (short) 0, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        double double1 = org.apache.commons.math.util.FastMath.abs((-0.4868981666828701d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4868981666828701d + "'", double1 == 0.4868981666828701d);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        int int1 = org.apache.commons.math.util.MathUtils.sign(3);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(1.0000000000000142d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0000000000000047d + "'", double1 == 1.0000000000000047d);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(5300, 87);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 461100 + "'", int2 == 461100);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (-1869155406));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(53L, (long) 97);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-44L) + "'", long2 == (-44L));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(156.3608363030788d, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 156.3608363030788d + "'", double2 == 156.3608363030788d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(100, 1077936128);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1077936228 + "'", int2 == 1077936228);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) (-626350101));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog((int) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 363.7393755555636d + "'", double1 == 363.7393755555636d);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) (-10));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-11013.232874703393d) + "'", double1 == (-11013.232874703393d));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(0.0010756674403879158d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.000000578530277d + "'", double1 == 1.000000578530277d);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 438727775, 108640L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5L + "'", long2 == 5L);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 2, (float) (-1));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 3104);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 1L, (int) (short) 10);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-90L), (java.lang.Number) (-1), (int) (byte) 1, orderDirection7, false);
        java.lang.Class<?> wildcardClass10 = nonMonotonousSequenceException9.getClass();
        int int11 = nonMonotonousSequenceException9.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = nonMonotonousSequenceException9.getDirection();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException9);
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        double double1 = org.apache.commons.math.util.FastMath.log10(3.103983027882299d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.49191933793498616d + "'", double1 == 0.49191933793498616d);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        double double1 = org.apache.commons.math.util.FastMath.log((double) (-626347007L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((-0.54402111088937d), 2.302585092994046d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.5440211108893699d) + "'", double2 == (-0.5440211108893699d));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        long long2 = org.apache.commons.math.util.MathUtils.pow(0L, 970);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        int int2 = org.apache.commons.math.util.FastMath.max((-626347007), (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-90L), (java.lang.Number) (-1), (int) (byte) 1, orderDirection3, false);
        boolean boolean6 = nonMonotonousSequenceException5.getStrict();
        java.lang.String str7 = nonMonotonousSequenceException5.toString();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > -90)" + "'", str7.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > -90)"));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (short) 0, (int) ' ');
        java.lang.Class<?> wildcardClass4 = nonMonotonousSequenceException3.getClass();
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        int int2 = org.apache.commons.math.util.MathUtils.pow(190, 1000L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        double double1 = org.apache.commons.math.util.MathUtils.sign((-57.29577951308232d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 3104);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3104.0000000000005d + "'", double1 == 3104.0000000000005d);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow(6L, (-1249873867));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        double double2 = org.apache.commons.math.util.FastMath.min((-11013.232874703393d), 5.298292365610485d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-11013.232874703393d) + "'", double2 == (-11013.232874703393d));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((int) (short) 0, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 10, 0, (-1));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        double[] doubleArray3 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) (short) -1);
        double[] doubleArray9 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, (double) (short) -1);
        double[] doubleArray13 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, (double) (-1L));
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray13);
        double[] doubleArray18 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray18, (double) (short) -1);
        double[] doubleArray21 = null;
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equals(doubleArray18, doubleArray21);
        double[] doubleArray26 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, (double) (short) -1);
        double[] doubleArray32 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray32, (double) (short) -1);
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray34, (double) (-1L));
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray28, doubleArray36);
        double double38 = org.apache.commons.math.util.MathUtils.distance1(doubleArray18, doubleArray28);
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray18);
        double[] doubleArray43 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray45 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray43, (double) (short) -1);
        double[] doubleArray49 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray51 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray49, (double) (short) -1);
        double[] doubleArray53 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray51, (double) (-1L));
        boolean boolean54 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray45, doubleArray53);
        double[] doubleArray58 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray60 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray58, (double) (short) -1);
        double[] doubleArray61 = null;
        boolean boolean62 = org.apache.commons.math.util.MathUtils.equals(doubleArray58, doubleArray61);
        double[] doubleArray66 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray68 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray66, (double) (short) -1);
        double[] doubleArray72 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray74 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray72, (double) (short) -1);
        double[] doubleArray76 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray74, (double) (-1L));
        boolean boolean77 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray68, doubleArray76);
        double double78 = org.apache.commons.math.util.MathUtils.distance1(doubleArray58, doubleArray68);
        boolean boolean79 = org.apache.commons.math.util.MathUtils.equals(doubleArray45, doubleArray58);
        double[] doubleArray83 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray85 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray83, (double) (short) -1);
        double[] doubleArray87 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray85, (double) (-1L));
        boolean boolean88 = org.apache.commons.math.util.MathUtils.equals(doubleArray45, doubleArray85);
        double double89 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray18, doubleArray45);
        double double90 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 63.0d + "'", double38 == 63.0d);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + true + "'", boolean77 == true);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 63.0d + "'", double78 == 63.0d);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + true + "'", boolean88 == true);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 52.83870967741935d + "'", double89 == 52.83870967741935d);
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + 52.952809179494906d + "'", double90 == 52.952809179494906d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) (-1249873867));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 1077936228, (long) (-818408495));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-818408495L) + "'", long2 == (-818408495L));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        int[] intArray0 = new int[] {};
        int[] intArray1 = new int[] {};
        int int2 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray1);
        int[] intArray3 = new int[] {};
        int[] intArray4 = new int[] {};
        int int5 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray4);
        int int6 = org.apache.commons.math.util.MathUtils.distance1(intArray1, intArray4);
        int[] intArray7 = new int[] {};
        int[] intArray8 = new int[] {};
        int int9 = org.apache.commons.math.util.MathUtils.distance1(intArray7, intArray8);
        int[] intArray10 = new int[] {};
        int[] intArray11 = new int[] {};
        int int12 = org.apache.commons.math.util.MathUtils.distance1(intArray10, intArray11);
        int int13 = org.apache.commons.math.util.MathUtils.distance1(intArray8, intArray11);
        int[] intArray14 = new int[] {};
        int[] intArray15 = new int[] {};
        int int16 = org.apache.commons.math.util.MathUtils.distance1(intArray14, intArray15);
        double double17 = org.apache.commons.math.util.MathUtils.distance(intArray8, intArray14);
        int[] intArray18 = new int[] {};
        int[] intArray19 = new int[] {};
        int int20 = org.apache.commons.math.util.MathUtils.distance1(intArray18, intArray19);
        int[] intArray21 = new int[] {};
        int[] intArray22 = new int[] {};
        int int23 = org.apache.commons.math.util.MathUtils.distance1(intArray21, intArray22);
        int int24 = org.apache.commons.math.util.MathUtils.distance1(intArray19, intArray22);
        int[] intArray25 = new int[] {};
        int[] intArray26 = new int[] {};
        int int27 = org.apache.commons.math.util.MathUtils.distance1(intArray25, intArray26);
        int[] intArray28 = new int[] {};
        int[] intArray29 = new int[] {};
        int int30 = org.apache.commons.math.util.MathUtils.distance1(intArray28, intArray29);
        int int31 = org.apache.commons.math.util.MathUtils.distance1(intArray26, intArray29);
        int[] intArray32 = new int[] {};
        int[] intArray33 = new int[] {};
        int int34 = org.apache.commons.math.util.MathUtils.distance1(intArray32, intArray33);
        double double35 = org.apache.commons.math.util.MathUtils.distance(intArray26, intArray32);
        int int36 = org.apache.commons.math.util.MathUtils.distanceInf(intArray22, intArray32);
        int[] intArray37 = new int[] {};
        int[] intArray38 = new int[] {};
        int int39 = org.apache.commons.math.util.MathUtils.distance1(intArray37, intArray38);
        int[] intArray40 = new int[] {};
        int[] intArray41 = new int[] {};
        int int42 = org.apache.commons.math.util.MathUtils.distance1(intArray40, intArray41);
        int int43 = org.apache.commons.math.util.MathUtils.distance1(intArray38, intArray41);
        int[] intArray44 = new int[] {};
        int[] intArray45 = new int[] {};
        int int46 = org.apache.commons.math.util.MathUtils.distance1(intArray44, intArray45);
        double double47 = org.apache.commons.math.util.MathUtils.distance(intArray38, intArray44);
        int int48 = org.apache.commons.math.util.MathUtils.distance1(intArray32, intArray38);
        int[] intArray49 = new int[] {};
        int[] intArray50 = new int[] {};
        int int51 = org.apache.commons.math.util.MathUtils.distance1(intArray49, intArray50);
        int[] intArray52 = new int[] {};
        int[] intArray53 = new int[] {};
        int int54 = org.apache.commons.math.util.MathUtils.distance1(intArray52, intArray53);
        int[] intArray55 = new int[] {};
        int[] intArray56 = new int[] {};
        int int57 = org.apache.commons.math.util.MathUtils.distance1(intArray55, intArray56);
        int int58 = org.apache.commons.math.util.MathUtils.distance1(intArray53, intArray56);
        int int59 = org.apache.commons.math.util.MathUtils.distance1(intArray49, intArray56);
        double double60 = org.apache.commons.math.util.MathUtils.distance(intArray38, intArray56);
        int int61 = org.apache.commons.math.util.MathUtils.distance1(intArray8, intArray38);
        int int62 = org.apache.commons.math.util.MathUtils.distanceInf(intArray1, intArray8);
        int[] intArray63 = new int[] {};
        int[] intArray64 = new int[] {};
        int int65 = org.apache.commons.math.util.MathUtils.distance1(intArray63, intArray64);
        int[] intArray66 = new int[] {};
        int[] intArray67 = new int[] {};
        int int68 = org.apache.commons.math.util.MathUtils.distance1(intArray66, intArray67);
        int int69 = org.apache.commons.math.util.MathUtils.distance1(intArray64, intArray67);
        int[] intArray70 = new int[] {};
        int[] intArray71 = new int[] {};
        int int72 = org.apache.commons.math.util.MathUtils.distance1(intArray70, intArray71);
        double double73 = org.apache.commons.math.util.MathUtils.distance(intArray64, intArray70);
        int int74 = org.apache.commons.math.util.MathUtils.distanceInf(intArray1, intArray70);
        int[] intArray75 = new int[] {};
        int[] intArray76 = new int[] {};
        int int77 = org.apache.commons.math.util.MathUtils.distance1(intArray75, intArray76);
        int[] intArray78 = new int[] {};
        int[] intArray79 = new int[] {};
        int int80 = org.apache.commons.math.util.MathUtils.distance1(intArray78, intArray79);
        int int81 = org.apache.commons.math.util.MathUtils.distance1(intArray76, intArray79);
        int[] intArray82 = new int[] {};
        int[] intArray83 = new int[] {};
        int int84 = org.apache.commons.math.util.MathUtils.distance1(intArray82, intArray83);
        double double85 = org.apache.commons.math.util.MathUtils.distance(intArray76, intArray82);
        double double86 = org.apache.commons.math.util.MathUtils.distance(intArray1, intArray82);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertNotNull(intArray63);
        org.junit.Assert.assertNotNull(intArray64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertNotNull(intArray67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
        org.junit.Assert.assertNotNull(intArray70);
        org.junit.Assert.assertNotNull(intArray71);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 0 + "'", int72 == 0);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 0 + "'", int74 == 0);
        org.junit.Assert.assertNotNull(intArray75);
        org.junit.Assert.assertNotNull(intArray76);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 0 + "'", int77 == 0);
        org.junit.Assert.assertNotNull(intArray78);
        org.junit.Assert.assertNotNull(intArray79);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 0 + "'", int80 == 0);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 0 + "'", int81 == 0);
        org.junit.Assert.assertNotNull(intArray82);
        org.junit.Assert.assertNotNull(intArray83);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 0 + "'", int84 == 0);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 0.0d + "'", double85 == 0.0d);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 0.0d + "'", double86 == 0.0d);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        double double1 = org.apache.commons.math.util.FastMath.signum(3.7168146928204138d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) (short) 100, 800L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 900L + "'", long2 == 900L);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 1249873868L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 21.639455658129254d + "'", double1 == 21.639455658129254d);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        double double1 = org.apache.commons.math.util.FastMath.tan(1.7182818284590453d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-6.731094208094568d) + "'", double1 == (-6.731094208094568d));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        double double2 = org.apache.commons.math.util.FastMath.pow(96.99999999999999d, (-6.731094208094568d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.234989000456701E-14d + "'", double2 == 4.234989000456701E-14d);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.0d, 3103.9999999999995d, 0.863944749891274d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        double double2 = org.apache.commons.math.util.FastMath.max((-6.731094208094568d), (-0.9999999999999999d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.9999999999999999d) + "'", double2 == (-0.9999999999999999d));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 1074790313L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) (-58L), 0.010256138689425936d, 3.1039830278823013d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 11, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-58L), (float) 1249873868L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-58.0f) + "'", float2 == (-58.0f));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        double[] doubleArray0 = null;
        double[] doubleArray4 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray6 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray4, (double) (short) -1);
        double[] doubleArray7 = null;
        boolean boolean8 = org.apache.commons.math.util.MathUtils.equals(doubleArray4, doubleArray7);
        double[] doubleArray12 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray14 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, (double) (short) -1);
        double[] doubleArray18 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray18, (double) (short) -1);
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray20, (double) (-1L));
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray14, doubleArray22);
        double double24 = org.apache.commons.math.util.MathUtils.distance1(doubleArray4, doubleArray14);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray14);
        double[] doubleArray29 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray31 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray29, (double) (short) -1);
        double[] doubleArray35 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray37 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray35, (double) (short) -1);
        double[] doubleArray41 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray43 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray41, (double) (short) -1);
        double[] doubleArray45 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray43, (double) (-1L));
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray37, doubleArray45);
        double[] doubleArray48 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray45, 10.0d);
        boolean boolean49 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray31, doubleArray45);
        double double50 = org.apache.commons.math.util.MathUtils.distance1(doubleArray14, doubleArray31);
        boolean boolean51 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray31);
        int int52 = org.apache.commons.math.util.MathUtils.hash(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 63.0d + "'", double24 == 63.0d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        double double1 = org.apache.commons.math.util.FastMath.cos(1.3969986421335177d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.17292406021471557d + "'", double1 == 0.17292406021471557d);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        int[] intArray0 = new int[] {};
        int[] intArray1 = new int[] {};
        int int2 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray1);
        int[] intArray3 = new int[] {};
        int[] intArray4 = new int[] {};
        int int5 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray4);
        int int6 = org.apache.commons.math.util.MathUtils.distance1(intArray1, intArray4);
        int[] intArray7 = new int[] {};
        int[] intArray8 = new int[] {};
        int int9 = org.apache.commons.math.util.MathUtils.distance1(intArray7, intArray8);
        int[] intArray10 = new int[] {};
        int[] intArray11 = new int[] {};
        int int12 = org.apache.commons.math.util.MathUtils.distance1(intArray10, intArray11);
        int int13 = org.apache.commons.math.util.MathUtils.distance1(intArray8, intArray11);
        int[] intArray14 = new int[] {};
        int[] intArray15 = new int[] {};
        int int16 = org.apache.commons.math.util.MathUtils.distance1(intArray14, intArray15);
        int int17 = org.apache.commons.math.util.MathUtils.distance1(intArray11, intArray14);
        double double18 = org.apache.commons.math.util.MathUtils.distance(intArray4, intArray14);
        int[] intArray19 = new int[] {};
        int[] intArray20 = new int[] {};
        int int21 = org.apache.commons.math.util.MathUtils.distance1(intArray19, intArray20);
        int[] intArray22 = new int[] {};
        int[] intArray23 = new int[] {};
        int int24 = org.apache.commons.math.util.MathUtils.distance1(intArray22, intArray23);
        int int25 = org.apache.commons.math.util.MathUtils.distance1(intArray20, intArray23);
        int[] intArray26 = new int[] {};
        int[] intArray27 = new int[] {};
        int int28 = org.apache.commons.math.util.MathUtils.distance1(intArray26, intArray27);
        int int29 = org.apache.commons.math.util.MathUtils.distance1(intArray23, intArray26);
        int[] intArray30 = new int[] {};
        int[] intArray31 = new int[] {};
        int int32 = org.apache.commons.math.util.MathUtils.distance1(intArray30, intArray31);
        int[] intArray33 = new int[] {};
        int[] intArray34 = new int[] {};
        int int35 = org.apache.commons.math.util.MathUtils.distance1(intArray33, intArray34);
        int int36 = org.apache.commons.math.util.MathUtils.distance1(intArray31, intArray34);
        int[] intArray37 = new int[] {};
        int[] intArray38 = new int[] {};
        int int39 = org.apache.commons.math.util.MathUtils.distance1(intArray37, intArray38);
        double double40 = org.apache.commons.math.util.MathUtils.distance(intArray31, intArray37);
        int int41 = org.apache.commons.math.util.MathUtils.distance1(intArray23, intArray31);
        int int42 = org.apache.commons.math.util.MathUtils.distanceInf(intArray14, intArray31);
        int[] intArray43 = null;
        int int44 = org.apache.commons.math.util.MathUtils.distanceInf(intArray31, intArray43);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 35L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        double double1 = org.apache.commons.math.util.FastMath.log1p((-0.5440211108893699d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7853087663494568d) + "'", double1 == (-0.7853087663494568d));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 190L, (java.lang.Number) 9.332621544395286E157d, (int) (byte) 100, orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getArgument();
        java.lang.Number number7 = nonMonotonousSequenceException5.getPrevious();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 190L + "'", number6.equals(190L));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 9.332621544395286E157d + "'", number7.equals(9.332621544395286E157d));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(5, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 97L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 97 + "'", int1 == 97);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        double double1 = org.apache.commons.math.util.FastMath.ulp(200.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.8421709430404007E-14d + "'", double1 == 2.8421709430404007E-14d);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        double double2 = org.apache.commons.math.util.MathUtils.log(2.8421709430404007E-14d, (double) (-300));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((-1074790400), (-10));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        double double1 = org.apache.commons.math.util.FastMath.exp(96.99999999999999d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3383347192042505E42d + "'", double1 == 1.3383347192042505E42d);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(1077936128);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        int[] intArray0 = new int[] {};
        int[] intArray1 = new int[] {};
        int int2 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray1);
        int[] intArray3 = new int[] {};
        int[] intArray4 = new int[] {};
        int int5 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray4);
        int int6 = org.apache.commons.math.util.MathUtils.distance1(intArray1, intArray4);
        int[] intArray7 = new int[] {};
        int[] intArray8 = new int[] {};
        int int9 = org.apache.commons.math.util.MathUtils.distance1(intArray7, intArray8);
        int[] intArray10 = new int[] {};
        int[] intArray11 = new int[] {};
        int int12 = org.apache.commons.math.util.MathUtils.distance1(intArray10, intArray11);
        int int13 = org.apache.commons.math.util.MathUtils.distance1(intArray8, intArray11);
        int[] intArray14 = new int[] {};
        int[] intArray15 = new int[] {};
        int int16 = org.apache.commons.math.util.MathUtils.distance1(intArray14, intArray15);
        double double17 = org.apache.commons.math.util.MathUtils.distance(intArray8, intArray14);
        int[] intArray18 = new int[] {};
        int[] intArray19 = new int[] {};
        int int20 = org.apache.commons.math.util.MathUtils.distance1(intArray18, intArray19);
        double double21 = org.apache.commons.math.util.MathUtils.distance(intArray14, intArray19);
        int int22 = org.apache.commons.math.util.MathUtils.distanceInf(intArray1, intArray19);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        double double1 = org.apache.commons.math.util.FastMath.tan(4.9E-324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        double double1 = org.apache.commons.math.util.FastMath.abs(1.5370263527767281E31d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5370263527767281E31d + "'", double1 == 1.5370263527767281E31d);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 108640L, (double) 200L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5689553863119945d + "'", double2 == 1.5689553863119945d);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        double double1 = org.apache.commons.math.util.FastMath.asin(20.59253685675062d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((-719.2542281009917d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(0L, (long) (-626350111));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-626350111L) + "'", long2 == (-626350111L));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow(0, (-1074790400L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        float float2 = org.apache.commons.math.util.FastMath.max(Float.NaN, (float) (short) 0);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 1249873868L, (float) (-1074790400));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0747904E9f) + "'", float2 == (-1.0747904E9f));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((-1L), 252L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 5.220411530638642d, (java.lang.Number) (-0.0d), 438727775);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        double double1 = org.apache.commons.math.util.FastMath.abs(52.99999999999999d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 52.99999999999999d + "'", double1 == 52.99999999999999d);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(99.99999999999999d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7453292519943293d + "'", double1 == 1.7453292519943293d);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        int int1 = org.apache.commons.math.util.FastMath.abs((-447362012));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 447362012 + "'", int1 == 447362012);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (short) 0, (int) ' ');
        int int7 = nonMonotonousSequenceException6.getIndex();
        boolean boolean8 = nonMonotonousSequenceException6.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException14 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-90L), (java.lang.Number) (-1), (int) (byte) 1, orderDirection12, false);
        nonMonotonousSequenceException6.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException14);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection16 = nonMonotonousSequenceException14.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException18 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 49.51465652161667d, (java.lang.Number) 15.104412573075516d, (-818408495), orderDirection16, true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 32 + "'", int7 == 32);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection16 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection16.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) (-3), 100L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (-1074790303L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.07479027E9f + "'", float1 == 1.07479027E9f);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 260, 108640L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1412320L + "'", long2 == 1412320L);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.4210854715202004E-14d, 99.99999999999999d, (double) (-447362012L));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(35L, (-1L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.0000000000000002d, (double) 100);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(3101);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(6L, (long) (-1249873867));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 7499243202L + "'", long2 == 7499243202L);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (-626350111));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 1249873868L, 21.639455658129254d, 0.9959814340926995d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        double[] doubleArray6 = new double[] { (short) -1, (-1L), 1.0d, 100, '#', 'a' };
        double[] doubleArray10 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray10, (double) (short) -1);
        double[] doubleArray13 = null;
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equals(doubleArray10, doubleArray13);
        double[] doubleArray18 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray18, (double) (short) -1);
        double[] doubleArray24 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray26 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray24, (double) (short) -1);
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, (double) (-1L));
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray28);
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray13, doubleArray20);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection34 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException36 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-90L), (java.lang.Number) (-1), (int) (byte) 1, orderDirection34, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray20, orderDirection34, true);
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray20);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray20);
        double[] doubleArray42 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray20, 0.0d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + orderDirection34 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection34.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(doubleArray42);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 1007000L, (float) (-1074790400));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0747904E9f) + "'", float2 == (-1.0747904E9f));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        double[] doubleArray0 = null;
        double[] doubleArray4 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray6 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray4, (double) (short) -1);
        double[] doubleArray10 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray10, (double) (short) -1);
        double[] doubleArray14 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, (double) (-1L));
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray14);
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        float float3 = org.apache.commons.math.util.MathUtils.round((float) 3, 35, 0);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 3.0f + "'", float3 == 3.0f);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((-16121856000L), (long) 4);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4L + "'", long2 == 4L);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 1L, (int) (short) 10);
        int int4 = nonMonotonousSequenceException3.getIndex();
        java.lang.Class<?> wildcardClass5 = nonMonotonousSequenceException3.getClass();
        java.lang.Number number6 = nonMonotonousSequenceException3.getArgument();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0.0f + "'", number6.equals(0.0f));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(7.105427357601002E-15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        double double1 = org.apache.commons.math.util.MathUtils.sign(20.085536923187668d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((double) 62, (-626350101));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-2.956390380859375E-5d) + "'", double2 == (-2.956390380859375E-5d));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        double double1 = org.apache.commons.math.util.FastMath.log(Double.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (short) 0, (int) (short) 0);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException7 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (short) 0, (int) (short) 0);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException7);
        java.lang.String str9 = nonMonotonousSequenceException7.toString();
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= 0)" + "'", str9.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= 0)"));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) (-1444685106), (long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-144468510600L) + "'", long2 == (-144468510600L));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 190L, (double) 97, 10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        double double1 = org.apache.commons.math.util.FastMath.sinh(2.302585092994046d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.950000000000001d + "'", double1 == 4.950000000000001d);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (short) 0, (int) ' ');
        int int4 = nonMonotonousSequenceException3.getIndex();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (short) 0, (int) (short) 0);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (short) 0, (int) (short) 0);
        nonMonotonousSequenceException8.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException8);
        java.lang.String str15 = nonMonotonousSequenceException3.toString();
        java.lang.Number number16 = nonMonotonousSequenceException3.getPrevious();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 32 + "'", int4 == 32);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 31 and 32 are not strictly increasing (0 >= 0)" + "'", str15.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 31 and 32 are not strictly increasing (0 >= 0)"));
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + (short) 0 + "'", number16.equals((short) 0));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        float float1 = org.apache.commons.math.util.MathUtils.indicator(100.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((-0.5309649148733371d), (double) 62);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((-16121852896L), (long) (byte) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-16121852886L) + "'", long2 == (-16121852886L));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(0, 62);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        int int2 = org.apache.commons.math.util.FastMath.max((-1074790400), 62);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 62 + "'", int2 == 62);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(97);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 349.9541180407703d + "'", double1 == 349.9541180407703d);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 87);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 87.0f + "'", float1 == 87.0f);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(0.022985251411478155d, (int) (short) 1, (-10));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        double double1 = org.apache.commons.math.util.MathUtils.sign((-0.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) '#', 12600L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-12565L) + "'", long2 == (-12565L));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((-1074790303L), 1074790313L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2149580616L) + "'", long2 == (-2149580616L));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 438727775L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.38727775E8d + "'", double1 == 4.38727775E8d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(0, (-1444685106));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(1077936228, 3);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 60.60318297794051d + "'", double2 == 60.60318297794051d);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        double[] doubleArray3 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) (short) -1);
        double[] doubleArray6 = null;
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray6);
        double[] doubleArray11 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray13 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, (double) (short) -1);
        double[] doubleArray17 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray17, (double) (short) -1);
        double[] doubleArray21 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, (double) (-1L));
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray13, doubleArray21);
        double double23 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray13);
        int int24 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        double double25 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 63.0d + "'", double23 == 63.0d);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 438727775 + "'", int24 == 438727775);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 52.952809179494906d + "'", double25 == 52.952809179494906d);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) (-127132289328L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6363935896729996d + "'", double1 == 0.6363935896729996d);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(0, (-738962753));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        long long1 = org.apache.commons.math.util.FastMath.abs((-12565L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 12565L + "'", long1 == 12565L);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) (short) 0);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        double double1 = org.apache.commons.math.util.FastMath.abs(1.1324597669369387d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1324597669369387d + "'", double1 == 1.1324597669369387d);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (int) (byte) -1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) (-1444685106), 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.44468506E9f) + "'", float2 == (-1.44468506E9f));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(0, 5300);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) (-626347060L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1920928955078125E-7d + "'", double1 == 1.1920928955078125E-7d);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        int int2 = org.apache.commons.math.util.MathUtils.pow(10, 12565L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 1391070465);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.391070465E9d + "'", double1 == 1.391070465E9d);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        int int1 = org.apache.commons.math.util.MathUtils.hash((-0.7615941559557649d));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 184331630 + "'", int1 == 184331630);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        double[] doubleArray0 = null;
        double[] doubleArray4 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray6 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray4, (double) (short) -1);
        double[] doubleArray7 = null;
        boolean boolean8 = org.apache.commons.math.util.MathUtils.equals(doubleArray4, doubleArray7);
        double[] doubleArray12 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray14 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, (double) (short) -1);
        double[] doubleArray18 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray18, (double) (short) -1);
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray20, (double) (-1L));
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray14, doubleArray22);
        double double24 = org.apache.commons.math.util.MathUtils.distance1(doubleArray4, doubleArray14);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray14);
        double[] doubleArray29 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray31 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray29, (double) (short) -1);
        double[] doubleArray35 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray37 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray35, (double) (short) -1);
        double[] doubleArray41 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray43 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray41, (double) (short) -1);
        double[] doubleArray45 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray43, (double) (-1L));
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray37, doubleArray45);
        double[] doubleArray48 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray45, 10.0d);
        boolean boolean49 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray31, doubleArray45);
        double double50 = org.apache.commons.math.util.MathUtils.distance1(doubleArray14, doubleArray31);
        boolean boolean51 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray31);
        try {
            double double52 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 63.0d + "'", double24 == 63.0d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        double double1 = org.apache.commons.math.util.FastMath.log(4.0532396646334464E17d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 40.54346305944742d + "'", double1 == 40.54346305944742d);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-90L), (java.lang.Number) (-1), (int) (byte) 1, orderDirection3, false);
        java.lang.Class<?> wildcardClass6 = nonMonotonousSequenceException5.getClass();
        int int7 = nonMonotonousSequenceException5.getIndex();
        java.lang.String str8 = nonMonotonousSequenceException5.toString();
        int int9 = nonMonotonousSequenceException5.getIndex();
        java.lang.Class<?> wildcardClass10 = nonMonotonousSequenceException5.getClass();
        java.lang.Number number11 = nonMonotonousSequenceException5.getArgument();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > -90)" + "'", str8.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > -90)"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + (-90L) + "'", number11.equals((-90L)));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        double double1 = org.apache.commons.math.util.FastMath.abs(1.0000000000000142d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0000000000000142d + "'", double1 == 1.0000000000000142d);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        int int2 = org.apache.commons.math.util.FastMath.min(10, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) (-144468510600L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.444685106E11d + "'", double1 == 1.444685106E11d);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 90L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 90.0d + "'", double1 == 90.0d);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.5607966601082315d, (-2.378849044627155E-271d));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 3);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        double double1 = org.apache.commons.math.util.FastMath.floor((-25.672727115366417d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-26.0d) + "'", double1 == (-26.0d));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        double double1 = org.apache.commons.math.util.FastMath.expm1((-26.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9999999999948909d) + "'", double1 == (-0.9999999999948909d));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 97.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9867717342662448d + "'", double1 == 1.9867717342662448d);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) (-127132289328L), 1.7182818284590453d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.8809814453125d) + "'", double2 == (-0.8809814453125d));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 3);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        double double1 = org.apache.commons.math.util.FastMath.cos(9.332621544395286E157d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6307047736851527d) + "'", double1 == (-0.6307047736851527d));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        long long1 = org.apache.commons.math.util.FastMath.round(1.1920928955078125E-7d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((-447362012));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        long long1 = org.apache.commons.math.util.MathUtils.sign(447362012L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(970, 184331630);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(1, 184331630);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 184331631 + "'", int2 == 184331631);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(87L, (long) (-626350101));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-626350014L) + "'", long2 == (-626350014L));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialLog((-1444685106));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 5L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.0d + "'", double1 == 5.0d);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        double double1 = org.apache.commons.math.util.FastMath.abs(1.3969986421335177d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3969986421335177d + "'", double1 == 1.3969986421335177d);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        int int1 = org.apache.commons.math.util.FastMath.abs((-10));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(3104);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) (-16121852896L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2526.222805222132d) + "'", double1 == (-2526.222805222132d));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5860134523134298E15d + "'", double1 == 1.5860134523134298E15d);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.960537576151187d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        double double1 = org.apache.commons.math.util.FastMath.log1p(8.540775674112082d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.255574789713833d + "'", double1 == 2.255574789713833d);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        double double1 = org.apache.commons.math.util.FastMath.cos((-0.8813735870195429d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6360918665423811d + "'", double1 == 0.6360918665423811d);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        long long2 = org.apache.commons.math.util.MathUtils.pow((-144468510600L), 190);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        double[] doubleArray3 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) (short) -1);
        double[] doubleArray6 = null;
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray6);
        double[] doubleArray11 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray13 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, (double) (short) -1);
        double[] doubleArray17 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray17, (double) (short) -1);
        double[] doubleArray21 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, (double) (-1L));
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray13, doubleArray21);
        double double23 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray13);
        int int24 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        java.lang.Class<?> wildcardClass25 = doubleArray3.getClass();
        double[] doubleArray27 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) 1);
        double[] doubleArray31 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray33 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray31, (double) (short) -1);
        double[] doubleArray37 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray39 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray37, (double) (short) -1);
        double[] doubleArray41 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray39, (double) (-1L));
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray33, doubleArray41);
        double[] doubleArray46 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray48 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray46, (double) (short) -1);
        double[] doubleArray49 = null;
        boolean boolean50 = org.apache.commons.math.util.MathUtils.equals(doubleArray46, doubleArray49);
        double[] doubleArray54 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray56 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray54, (double) (short) -1);
        double[] doubleArray60 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray62 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray60, (double) (short) -1);
        double[] doubleArray64 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray62, (double) (-1L));
        boolean boolean65 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray56, doubleArray64);
        double double66 = org.apache.commons.math.util.MathUtils.distance1(doubleArray46, doubleArray56);
        boolean boolean67 = org.apache.commons.math.util.MathUtils.equals(doubleArray33, doubleArray46);
        double[] doubleArray71 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray73 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray71, (double) (short) -1);
        double[] doubleArray75 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray73, (double) (-1L));
        boolean boolean76 = org.apache.commons.math.util.MathUtils.equals(doubleArray33, doubleArray73);
        double[] doubleArray80 = new double[] { (-35L), 1.3043045862358962d, '#' };
        double double81 = org.apache.commons.math.util.MathUtils.distance1(doubleArray33, doubleArray80);
        double double82 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray80);
        double double83 = org.apache.commons.math.util.MathUtils.distance(doubleArray27, doubleArray80);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray80);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 63.0d + "'", double23 == 63.0d);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 438727775 + "'", int24 == 438727775);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 63.0d + "'", double66 == 63.0d);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 70.62688523139718d + "'", double81 == 70.62688523139718d);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 49.51465652161667d + "'", double82 == 49.51465652161667d);
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + 50.10708126551846d + "'", double83 == 50.10708126551846d);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) (-738962753), (-1444685106));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.17292406021471557d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.17379768466137896d + "'", double1 == 0.17379768466137896d);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-90L), (java.lang.Number) (-1), (int) (byte) 1, orderDirection3, false);
        java.lang.Class<?> wildcardClass6 = nonMonotonousSequenceException5.getClass();
        int int7 = nonMonotonousSequenceException5.getIndex();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 1L, (int) (short) 10);
        java.lang.Class<?> wildcardClass12 = nonMonotonousSequenceException11.getClass();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        java.lang.Number number14 = nonMonotonousSequenceException11.getArgument();
        java.lang.String str15 = nonMonotonousSequenceException11.toString();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 0.0f + "'", number14.equals(0.0f));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (1 >= 0)" + "'", str15.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (1 >= 0)"));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        long long1 = org.apache.commons.math.util.FastMath.round((double) (-1074790400L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1074790400L) + "'", long1 == (-1074790400L));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(3.491921712586151d, 5300);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-2.976789725572886E-254d) + "'", double2 == (-2.976789725572886E-254d));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) 0, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        double double1 = org.apache.commons.math.util.FastMath.signum(1.5518730669348417d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-35L), 108640L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-3802400L) + "'", long2 == (-3802400L));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        double double1 = org.apache.commons.math.util.FastMath.abs(2.3458247401995457E41d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.3458247401995457E41d + "'", double1 == 2.3458247401995457E41d);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test180");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 190L, (java.lang.Number) 9.332621544395286E157d, (int) (byte) 100, orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getArgument();
        int int7 = nonMonotonousSequenceException5.getIndex();
        java.lang.Number number8 = nonMonotonousSequenceException5.getArgument();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 190L + "'", number6.equals(190L));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 100 + "'", int7 == 100);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 190L + "'", number8.equals(190L));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test181");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 32L, (java.lang.Number) 1.3043045862358962d, 3104);
        java.lang.Class<?> wildcardClass4 = nonMonotonousSequenceException3.getClass();
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test182");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 190L, (java.lang.Number) 9.332621544395286E157d, (int) (byte) 100, orderDirection6, false);
        java.lang.Throwable[] throwableArray9 = nonMonotonousSequenceException8.getSuppressed();
        int int10 = nonMonotonousSequenceException8.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = nonMonotonousSequenceException8.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (short) 0, (int) ' ');
        int int16 = nonMonotonousSequenceException15.getIndex();
        boolean boolean17 = nonMonotonousSequenceException15.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection21 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException23 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-90L), (java.lang.Number) (-1), (int) (byte) 1, orderDirection21, false);
        nonMonotonousSequenceException15.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException23);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection28 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException30 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-90L), (java.lang.Number) (-1), (int) (byte) 1, orderDirection28, false);
        java.lang.Class<?> wildcardClass31 = nonMonotonousSequenceException30.getClass();
        int int32 = nonMonotonousSequenceException30.getIndex();
        java.lang.String str33 = nonMonotonousSequenceException30.toString();
        int int34 = nonMonotonousSequenceException30.getIndex();
        nonMonotonousSequenceException15.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException30);
        nonMonotonousSequenceException8.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException30);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection37 = nonMonotonousSequenceException30.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException39 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 35.00000000000001d, (java.lang.Number) (-3802400L), 0, orderDirection37, false);
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
        org.junit.Assert.assertTrue("'" + orderDirection11 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection11.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 32 + "'", int16 == 32);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + orderDirection21 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection21.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection28 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection28.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > -90)" + "'", str33.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > -90)"));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertTrue("'" + orderDirection37 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection37.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test183");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.9766588768709492d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8647722399302693d + "'", double1 == 0.8647722399302693d);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test184");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) (-125687604222L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test185");
        double double2 = org.apache.commons.math.util.FastMath.min((double) (short) 1, 0.6363935896729996d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.6363935896729996d + "'", double2 == 0.6363935896729996d);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test186");
        long long2 = org.apache.commons.math.util.FastMath.max(3578896096L, (long) (short) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3578896096L + "'", long2 == 3578896096L);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test187");
        double double2 = org.apache.commons.math.util.FastMath.pow(40.54346305944742d, (double) 52L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.091511391485423E83d + "'", double2 == 4.091511391485423E83d);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test188");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 438727775L, (-0.7023967071298747d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.3872777499999994E8d + "'", double2 == 4.3872777499999994E8d);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test189");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(0, 3);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test190");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) ' ', 0L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test191");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) Float.NaN, 1.1920928955078125E-7d, (double) 87);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test192");
        double double1 = org.apache.commons.math.util.FastMath.log1p((-0.9999546000702375d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-9.99999999999987d) + "'", double1 == (-9.99999999999987d));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test193");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.718281828459045d + "'", double1 == 2.718281828459045d);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test194");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((-626350101L), (long) 62);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 38833706262L + "'", long2 == 38833706262L);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test195");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-90L), (java.lang.Number) (-1), (int) (byte) 1, orderDirection6, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8647722399302693d, (java.lang.Number) (-1.0d), 52, orderDirection6, false);
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test196");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(10, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test197");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(5.220411530638642d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test198");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-818408495L), (long) (-3));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2455225485L + "'", long2 == 2455225485L);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test199");
        double[] doubleArray0 = null;
        double[] doubleArray4 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray6 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray4, (double) (short) -1);
        double[] doubleArray7 = null;
        boolean boolean8 = org.apache.commons.math.util.MathUtils.equals(doubleArray4, doubleArray7);
        double[] doubleArray12 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray14 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, (double) (short) -1);
        double[] doubleArray18 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray18, (double) (short) -1);
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray20, (double) (-1L));
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray14, doubleArray22);
        double double24 = org.apache.commons.math.util.MathUtils.distance1(doubleArray4, doubleArray14);
        int int25 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        double[] doubleArray26 = null;
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equals(doubleArray4, doubleArray26);
        try {
            double double28 = org.apache.commons.math.util.MathUtils.distance1(doubleArray0, doubleArray26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 63.0d + "'", double24 == 63.0d);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 438727775 + "'", int25 == 438727775);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test200");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.010308913146243432d, (java.lang.Number) 3.141591832838774d, (-738962753));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test201");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(52.0d, 1079525376);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 52.0d + "'", double2 == 52.0d);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test202");
        long long2 = org.apache.commons.math.util.MathUtils.pow(0L, 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test203");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) (-300));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test204");
        int int2 = org.apache.commons.math.util.FastMath.min((-1869155406), 3101);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1869155406) + "'", int2 == (-1869155406));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test205");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 1444685096L, 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.44468506E9f + "'", float2 == 1.44468506E9f);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test206");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 1074790400);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1074790400L + "'", long1 == 1074790400L);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test207");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(2.2250738585072014E-308d, 21.639455658129254d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 18.84955592153876d + "'", double2 == 18.84955592153876d);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test208");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) '#', 0.0010756674403879158d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.9224036063638743d) + "'", double2 == (-1.9224036063638743d));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test209");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) 5300L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test210");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test211");
        int int1 = org.apache.commons.math.util.MathUtils.sign((-1869155406));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test212");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((-0.9999546000702375d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test213");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(2, 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test214");
        int int2 = org.apache.commons.math.util.FastMath.max(0, (-3));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test215");
        double[] doubleArray3 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) (short) -1);
        double[] doubleArray9 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, (double) (short) -1);
        double[] doubleArray13 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, (double) (-1L));
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray13);
        double double15 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.8540775674112082d + "'", double15 == 0.8540775674112082d);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test216");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((-1.233403117511217d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.2334031175112168d) + "'", double1 == (-1.2334031175112168d));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test217");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 461100, 1444685096L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 166536074441400L + "'", long2 == 166536074441400L);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test218");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) Double.POSITIVE_INFINITY, number1, 1074790400);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test219");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((-1444685106));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test220");
        double[] doubleArray3 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) (short) -1);
        double[] doubleArray9 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, (double) (short) -1);
        double[] doubleArray13 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, (double) (-1L));
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray13);
        double[] doubleArray18 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray18, (double) (short) -1);
        double[] doubleArray21 = null;
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equals(doubleArray18, doubleArray21);
        double[] doubleArray26 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, (double) (short) -1);
        double[] doubleArray32 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray32, (double) (short) -1);
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray34, (double) (-1L));
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray28, doubleArray36);
        double double38 = org.apache.commons.math.util.MathUtils.distance1(doubleArray18, doubleArray28);
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray18);
        double[] doubleArray43 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray45 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray43, (double) (short) -1);
        double[] doubleArray47 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray45, (double) (-1L));
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray45);
        double[] doubleArray52 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray54 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray52, (double) (short) -1);
        double[] doubleArray58 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray60 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray58, (double) (short) -1);
        double[] doubleArray62 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray60, (double) (-1L));
        double double63 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray54, doubleArray62);
        double double64 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray45, doubleArray54);
        int int65 = org.apache.commons.math.util.MathUtils.hash(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 63.0d + "'", double38 == 63.0d);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + (-1249873867) + "'", int65 == (-1249873867));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test221");
        float float2 = org.apache.commons.math.util.MathUtils.round(52.0f, (int) '4');
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test222");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.543064498443336d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 31.11530376419202d + "'", double1 == 31.11530376419202d);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test223");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test224");
        double double1 = org.apache.commons.math.util.FastMath.expm1(3.141592653589793d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22.140692632779267d + "'", double1 == 22.140692632779267d);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test225");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.9867228626928289d, (-26.0d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.103659978354832d + "'", double2 == 3.103659978354832d);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test226");
        double double1 = org.apache.commons.math.util.FastMath.atanh(Double.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test227");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((-738962753), (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-738962718) + "'", int2 == (-738962718));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test228");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 4, (double) 940900);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test229");
        int[] intArray0 = new int[] {};
        int[] intArray1 = new int[] {};
        int int2 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray1);
        int[] intArray3 = new int[] {};
        int[] intArray4 = new int[] {};
        int int5 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray4);
        int int6 = org.apache.commons.math.util.MathUtils.distance1(intArray1, intArray4);
        int[] intArray7 = new int[] {};
        int[] intArray8 = new int[] {};
        int int9 = org.apache.commons.math.util.MathUtils.distance1(intArray7, intArray8);
        int[] intArray10 = new int[] {};
        int[] intArray11 = new int[] {};
        int int12 = org.apache.commons.math.util.MathUtils.distance1(intArray10, intArray11);
        int int13 = org.apache.commons.math.util.MathUtils.distance1(intArray8, intArray11);
        int[] intArray14 = new int[] {};
        int[] intArray15 = new int[] {};
        int int16 = org.apache.commons.math.util.MathUtils.distance1(intArray14, intArray15);
        int int17 = org.apache.commons.math.util.MathUtils.distance1(intArray11, intArray14);
        double double18 = org.apache.commons.math.util.MathUtils.distance(intArray4, intArray14);
        int[] intArray19 = new int[] {};
        int[] intArray20 = new int[] {};
        int int21 = org.apache.commons.math.util.MathUtils.distance1(intArray19, intArray20);
        int[] intArray22 = new int[] {};
        int[] intArray23 = new int[] {};
        int int24 = org.apache.commons.math.util.MathUtils.distance1(intArray22, intArray23);
        int int25 = org.apache.commons.math.util.MathUtils.distance1(intArray20, intArray23);
        int[] intArray26 = new int[] {};
        int[] intArray27 = new int[] {};
        int int28 = org.apache.commons.math.util.MathUtils.distance1(intArray26, intArray27);
        int int29 = org.apache.commons.math.util.MathUtils.distance1(intArray23, intArray26);
        int[] intArray30 = new int[] {};
        int[] intArray31 = new int[] {};
        int int32 = org.apache.commons.math.util.MathUtils.distance1(intArray30, intArray31);
        int[] intArray33 = new int[] {};
        int[] intArray34 = new int[] {};
        int int35 = org.apache.commons.math.util.MathUtils.distance1(intArray33, intArray34);
        int int36 = org.apache.commons.math.util.MathUtils.distance1(intArray31, intArray34);
        int[] intArray37 = new int[] {};
        int[] intArray38 = new int[] {};
        int int39 = org.apache.commons.math.util.MathUtils.distance1(intArray37, intArray38);
        double double40 = org.apache.commons.math.util.MathUtils.distance(intArray31, intArray37);
        int int41 = org.apache.commons.math.util.MathUtils.distance1(intArray23, intArray31);
        int int42 = org.apache.commons.math.util.MathUtils.distanceInf(intArray14, intArray31);
        int[] intArray43 = new int[] {};
        int[] intArray44 = new int[] {};
        int int45 = org.apache.commons.math.util.MathUtils.distance1(intArray43, intArray44);
        int[] intArray46 = new int[] {};
        int[] intArray47 = new int[] {};
        int int48 = org.apache.commons.math.util.MathUtils.distance1(intArray46, intArray47);
        int int49 = org.apache.commons.math.util.MathUtils.distance1(intArray44, intArray47);
        int[] intArray50 = new int[] {};
        int[] intArray51 = new int[] {};
        int int52 = org.apache.commons.math.util.MathUtils.distance1(intArray50, intArray51);
        int[] intArray53 = new int[] {};
        int[] intArray54 = new int[] {};
        int int55 = org.apache.commons.math.util.MathUtils.distance1(intArray53, intArray54);
        int int56 = org.apache.commons.math.util.MathUtils.distance1(intArray51, intArray54);
        int[] intArray57 = new int[] {};
        int[] intArray58 = new int[] {};
        int int59 = org.apache.commons.math.util.MathUtils.distance1(intArray57, intArray58);
        double double60 = org.apache.commons.math.util.MathUtils.distance(intArray51, intArray57);
        int int61 = org.apache.commons.math.util.MathUtils.distanceInf(intArray47, intArray57);
        int[] intArray62 = new int[] {};
        int[] intArray63 = new int[] {};
        int int64 = org.apache.commons.math.util.MathUtils.distance1(intArray62, intArray63);
        int[] intArray65 = new int[] {};
        int[] intArray66 = new int[] {};
        int int67 = org.apache.commons.math.util.MathUtils.distance1(intArray65, intArray66);
        int int68 = org.apache.commons.math.util.MathUtils.distance1(intArray63, intArray66);
        int int69 = org.apache.commons.math.util.MathUtils.distance1(intArray47, intArray63);
        double double70 = org.apache.commons.math.util.MathUtils.distance(intArray14, intArray63);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertNotNull(intArray54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
        org.junit.Assert.assertNotNull(intArray62);
        org.junit.Assert.assertNotNull(intArray63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
        org.junit.Assert.assertNotNull(intArray65);
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 0 + "'", int67 == 0);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.0d + "'", double70 == 0.0d);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test230");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 62, 1.5549246438031066d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.545722153207492d + "'", double2 == 1.545722153207492d);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test231");
        double double1 = org.apache.commons.math.util.MathUtils.sign(0.17292406021471557d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test232");
        double double1 = org.apache.commons.math.util.FastMath.log1p(11.591953275521519d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.533057981020253d + "'", double1 == 2.533057981020253d);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test233");
        double[] doubleArray0 = null;
        double[] doubleArray4 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray6 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray4, (double) (short) -1);
        double[] doubleArray7 = null;
        boolean boolean8 = org.apache.commons.math.util.MathUtils.equals(doubleArray4, doubleArray7);
        double[] doubleArray12 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray14 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, (double) (short) -1);
        double[] doubleArray18 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray18, (double) (short) -1);
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray20, (double) (-1L));
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray14, doubleArray22);
        double double24 = org.apache.commons.math.util.MathUtils.distance1(doubleArray4, doubleArray14);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray14);
        double[] doubleArray29 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray31 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray29, (double) (short) -1);
        double[] doubleArray35 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray37 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray35, (double) (short) -1);
        double[] doubleArray41 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray43 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray41, (double) (short) -1);
        double[] doubleArray45 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray43, (double) (-1L));
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray37, doubleArray45);
        double[] doubleArray48 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray45, 10.0d);
        boolean boolean49 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray31, doubleArray45);
        double double50 = org.apache.commons.math.util.MathUtils.distance1(doubleArray14, doubleArray31);
        boolean boolean51 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray31);
        double[] doubleArray53 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray31, 0.0d);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 63.0d + "'", double24 == 63.0d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(doubleArray53);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test234");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(3578896096L, (long) 5300);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4742037327200L + "'", long2 == 4742037327200L);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test235");
        double double1 = org.apache.commons.math.util.FastMath.rint((-4.4736201199999994E8d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-4.47362012E8d) + "'", double1 == (-4.47362012E8d));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test236");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 970, (float) 11);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 11.0f + "'", float2 == 11.0f);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test237");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) (-738962718), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-738962718L) + "'", long2 == (-738962718L));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test238");
        double double1 = org.apache.commons.math.util.FastMath.asin(52.838709677419345d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test239");
        double double1 = org.apache.commons.math.util.FastMath.log(97.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.574710978503383d + "'", double1 == 4.574710978503383d);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test240");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(940900);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2000803543578267E7d + "'", double1 == 1.2000803543578267E7d);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test241");
        double double1 = org.apache.commons.math.util.FastMath.acos(1.0795255743608363E9d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test242");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) (-626350101), 8625328718985906576L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test243");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) (-818408495L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9463876021584277d) + "'", double1 == (-0.9463876021584277d));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test244");
        int[] intArray0 = new int[] {};
        int[] intArray1 = new int[] {};
        int int2 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray1);
        int[] intArray3 = new int[] {};
        int[] intArray4 = new int[] {};
        int int5 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray4);
        int int6 = org.apache.commons.math.util.MathUtils.distance1(intArray1, intArray4);
        int[] intArray7 = new int[] {};
        int[] intArray8 = new int[] {};
        int int9 = org.apache.commons.math.util.MathUtils.distance1(intArray7, intArray8);
        double double10 = org.apache.commons.math.util.MathUtils.distance(intArray1, intArray7);
        int[] intArray11 = new int[] {};
        int[] intArray12 = new int[] {};
        int int13 = org.apache.commons.math.util.MathUtils.distance1(intArray11, intArray12);
        double double14 = org.apache.commons.math.util.MathUtils.distance(intArray7, intArray12);
        int[] intArray15 = new int[] {};
        int[] intArray16 = new int[] {};
        int int17 = org.apache.commons.math.util.MathUtils.distance1(intArray15, intArray16);
        int[] intArray18 = new int[] {};
        int[] intArray19 = new int[] {};
        int int20 = org.apache.commons.math.util.MathUtils.distance1(intArray18, intArray19);
        int int21 = org.apache.commons.math.util.MathUtils.distance1(intArray16, intArray19);
        int[] intArray22 = new int[] {};
        int[] intArray23 = new int[] {};
        int int24 = org.apache.commons.math.util.MathUtils.distance1(intArray22, intArray23);
        int[] intArray25 = new int[] {};
        int[] intArray26 = new int[] {};
        int int27 = org.apache.commons.math.util.MathUtils.distance1(intArray25, intArray26);
        int int28 = org.apache.commons.math.util.MathUtils.distance1(intArray23, intArray26);
        int[] intArray29 = new int[] {};
        int[] intArray30 = new int[] {};
        int int31 = org.apache.commons.math.util.MathUtils.distance1(intArray29, intArray30);
        double double32 = org.apache.commons.math.util.MathUtils.distance(intArray23, intArray29);
        int[] intArray33 = new int[] {};
        int[] intArray34 = new int[] {};
        int int35 = org.apache.commons.math.util.MathUtils.distance1(intArray33, intArray34);
        int[] intArray36 = new int[] {};
        int[] intArray37 = new int[] {};
        int int38 = org.apache.commons.math.util.MathUtils.distance1(intArray36, intArray37);
        int int39 = org.apache.commons.math.util.MathUtils.distance1(intArray34, intArray37);
        int[] intArray40 = new int[] {};
        int[] intArray41 = new int[] {};
        int int42 = org.apache.commons.math.util.MathUtils.distance1(intArray40, intArray41);
        int[] intArray43 = new int[] {};
        int[] intArray44 = new int[] {};
        int int45 = org.apache.commons.math.util.MathUtils.distance1(intArray43, intArray44);
        int int46 = org.apache.commons.math.util.MathUtils.distance1(intArray41, intArray44);
        int[] intArray47 = new int[] {};
        int[] intArray48 = new int[] {};
        int int49 = org.apache.commons.math.util.MathUtils.distance1(intArray47, intArray48);
        double double50 = org.apache.commons.math.util.MathUtils.distance(intArray41, intArray47);
        int int51 = org.apache.commons.math.util.MathUtils.distanceInf(intArray37, intArray47);
        int[] intArray52 = new int[] {};
        int[] intArray53 = new int[] {};
        int int54 = org.apache.commons.math.util.MathUtils.distance1(intArray52, intArray53);
        int[] intArray55 = new int[] {};
        int[] intArray56 = new int[] {};
        int int57 = org.apache.commons.math.util.MathUtils.distance1(intArray55, intArray56);
        int int58 = org.apache.commons.math.util.MathUtils.distance1(intArray53, intArray56);
        int[] intArray59 = new int[] {};
        int[] intArray60 = new int[] {};
        int int61 = org.apache.commons.math.util.MathUtils.distance1(intArray59, intArray60);
        double double62 = org.apache.commons.math.util.MathUtils.distance(intArray53, intArray59);
        int int63 = org.apache.commons.math.util.MathUtils.distance1(intArray47, intArray53);
        int[] intArray64 = new int[] {};
        int[] intArray65 = new int[] {};
        int int66 = org.apache.commons.math.util.MathUtils.distance1(intArray64, intArray65);
        int[] intArray67 = new int[] {};
        int[] intArray68 = new int[] {};
        int int69 = org.apache.commons.math.util.MathUtils.distance1(intArray67, intArray68);
        int[] intArray70 = new int[] {};
        int[] intArray71 = new int[] {};
        int int72 = org.apache.commons.math.util.MathUtils.distance1(intArray70, intArray71);
        int int73 = org.apache.commons.math.util.MathUtils.distance1(intArray68, intArray71);
        int int74 = org.apache.commons.math.util.MathUtils.distance1(intArray64, intArray71);
        double double75 = org.apache.commons.math.util.MathUtils.distance(intArray53, intArray71);
        int int76 = org.apache.commons.math.util.MathUtils.distance1(intArray23, intArray53);
        int int77 = org.apache.commons.math.util.MathUtils.distanceInf(intArray16, intArray23);
        int int78 = org.apache.commons.math.util.MathUtils.distanceInf(intArray7, intArray16);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
        org.junit.Assert.assertNotNull(intArray64);
        org.junit.Assert.assertNotNull(intArray65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
        org.junit.Assert.assertNotNull(intArray67);
        org.junit.Assert.assertNotNull(intArray68);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
        org.junit.Assert.assertNotNull(intArray70);
        org.junit.Assert.assertNotNull(intArray71);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 0 + "'", int72 == 0);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 0 + "'", int73 == 0);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 0 + "'", int74 == 0);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.0d + "'", double75 == 0.0d);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 0 + "'", int76 == 0);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 0 + "'", int77 == 0);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 0 + "'", int78 == 0);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test245");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 52);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test246");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((int) (byte) 100, 97);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 197 + "'", int2 == 197);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test247");
        double double1 = org.apache.commons.math.util.FastMath.log10(1.3383347192042505E42d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 42.12656474461542d + "'", double1 == 42.12656474461542d);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test248");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 1079525376);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test249");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((double) (short) 1, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1024.0d + "'", double2 == 1024.0d);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test250");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(0.18952113006314425d, 5.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test251");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 461100, (long) (-1));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 461100L + "'", long2 == 461100L);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test252");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(0.0d, 184331631);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test253");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((-738962753), (-447362047));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test254");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(100L, (long) 184331631);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test255");
        float float3 = org.apache.commons.math.util.MathUtils.round((-1.0747904E9f), 11, 0);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0747904E9f) + "'", float3 == (-1.0747904E9f));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test256");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) 1444685106L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 223708937 + "'", int1 == 223708937);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test257");
        double double1 = org.apache.commons.math.util.FastMath.abs(5.298342365610589d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.298342365610589d + "'", double1 == 5.298342365610589d);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test258");
        double[] doubleArray3 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) (short) -1);
        double[] doubleArray6 = null;
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray6);
        double[] doubleArray11 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray13 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, (double) (short) -1);
        double[] doubleArray17 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray17, (double) (short) -1);
        double[] doubleArray21 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, (double) (-1L));
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray13, doubleArray21);
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray13);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection27 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException29 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-90L), (java.lang.Number) (-1), (int) (byte) 1, orderDirection27, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray13, orderDirection27, true);
        double[] doubleArray35 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray37 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray35, (double) (short) -1);
        double[] doubleArray41 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray43 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray41, (double) (short) -1);
        double double44 = org.apache.commons.math.util.MathUtils.distance1(doubleArray37, doubleArray41);
        double[] doubleArray48 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray50 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray48, (double) (short) -1);
        double[] doubleArray51 = null;
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equals(doubleArray48, doubleArray51);
        double[] doubleArray56 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray58 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray56, (double) (short) -1);
        double[] doubleArray62 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray64 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray62, (double) (short) -1);
        double[] doubleArray66 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray64, (double) (-1L));
        boolean boolean67 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray58, doubleArray66);
        boolean boolean68 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray51, doubleArray58);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection72 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException74 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-90L), (java.lang.Number) (-1), (int) (byte) 1, orderDirection72, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray58, orderDirection72, true);
        boolean boolean77 = org.apache.commons.math.util.MathUtils.equals(doubleArray37, doubleArray58);
        double double78 = org.apache.commons.math.util.MathUtils.distance1(doubleArray13, doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + orderDirection27 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection27.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 63.0d + "'", double44 == 63.0d);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + orderDirection72 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection72.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + true + "'", boolean77 == true);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 0.0d + "'", double78 == 0.0d);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test259");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.3968502629920499d, 3.190909918534485E-8d, 11);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test260");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(97, 3);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 291 + "'", int2 == 291);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test261");
        double double2 = org.apache.commons.math.util.FastMath.pow(1.1752011936438014d, 5.298292365610485d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.3522044138766205d + "'", double2 == 2.3522044138766205d);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test262");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 87, (double) 11, (double) 197);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test263");
        double[] doubleArray6 = new double[] { (short) -1, (-1L), 1.0d, 100, '#', 'a' };
        double[] doubleArray10 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray10, (double) (short) -1);
        double[] doubleArray13 = null;
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equals(doubleArray10, doubleArray13);
        double[] doubleArray18 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray18, (double) (short) -1);
        double[] doubleArray24 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray26 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray24, (double) (short) -1);
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, (double) (-1L));
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray28);
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray13, doubleArray20);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection34 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException36 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-90L), (java.lang.Number) (-1), (int) (byte) 1, orderDirection34, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray20, orderDirection34, true);
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray20);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray20);
        double[] doubleArray42 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray20, (double) 1.0f);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + orderDirection34 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection34.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(doubleArray42);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test264");
        double double1 = org.apache.commons.math.util.FastMath.ceil(35.00000000000001d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 36.0d + "'", double1 == 36.0d);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test265");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.0158400256874338d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0159661439197461d + "'", double1 == 0.0159661439197461d);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test266");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(1074790400L, (long) (-3));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1074790403L + "'", long2 == 1074790403L);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test267");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((-0.5309649148733371d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test268");
        double double1 = org.apache.commons.math.util.FastMath.cosh((-1.233403117511217d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.8620958891185864d + "'", double1 == 1.8620958891185864d);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test269");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) (-3));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.8184464592320668d) + "'", double1 == (-1.8184464592320668d));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test270");
        double double2 = org.apache.commons.math.util.FastMath.max(9.332621544395286E157d, (-6.731094208094568d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.332621544395286E157d + "'", double2 == 9.332621544395286E157d);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test271");
        int int1 = org.apache.commons.math.util.MathUtils.hash(0.0d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test272");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) (byte) 10, 32L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2L + "'", long2 == 2L);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test273");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((-447362047));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test274");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-1444685106L), (long) (-738962753));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1067568483147856818L + "'", long2 == 1067568483147856818L);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test275");
        int[] intArray0 = null;
        int[] intArray1 = null;
        try {
            int int2 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test276");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test277");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-90L), (java.lang.Number) (-1), (int) (byte) 1, orderDirection6, false);
        java.lang.Class<?> wildcardClass9 = nonMonotonousSequenceException8.getClass();
        int int10 = nonMonotonousSequenceException8.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = nonMonotonousSequenceException8.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.5596856728972892d), (java.lang.Number) (-0.5063656411097588d), (int) 'a', orderDirection11, false);
        int int14 = nonMonotonousSequenceException13.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + orderDirection11 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection11.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 97 + "'", int14 == 97);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test278");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) (-626350111));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test279");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) (-127132289328L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test280");
        long long1 = org.apache.commons.math.util.FastMath.abs((-626350111L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 626350111L + "'", long1 == 626350111L);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test281");
        int[] intArray0 = new int[] {};
        int[] intArray1 = new int[] {};
        int int2 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray1);
        int[] intArray3 = new int[] {};
        int[] intArray4 = new int[] {};
        int int5 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray4);
        int int6 = org.apache.commons.math.util.MathUtils.distance1(intArray1, intArray4);
        int[] intArray7 = new int[] {};
        int[] intArray8 = new int[] {};
        int int9 = org.apache.commons.math.util.MathUtils.distance1(intArray7, intArray8);
        int[] intArray10 = new int[] {};
        int[] intArray11 = new int[] {};
        int int12 = org.apache.commons.math.util.MathUtils.distance1(intArray10, intArray11);
        int int13 = org.apache.commons.math.util.MathUtils.distance1(intArray8, intArray11);
        int[] intArray14 = new int[] {};
        int[] intArray15 = new int[] {};
        int int16 = org.apache.commons.math.util.MathUtils.distance1(intArray14, intArray15);
        double double17 = org.apache.commons.math.util.MathUtils.distance(intArray8, intArray14);
        int int18 = org.apache.commons.math.util.MathUtils.distanceInf(intArray4, intArray14);
        int[] intArray19 = new int[] {};
        int[] intArray20 = new int[] {};
        int int21 = org.apache.commons.math.util.MathUtils.distance1(intArray19, intArray20);
        int[] intArray22 = new int[] {};
        int[] intArray23 = new int[] {};
        int int24 = org.apache.commons.math.util.MathUtils.distance1(intArray22, intArray23);
        int int25 = org.apache.commons.math.util.MathUtils.distance1(intArray20, intArray23);
        int[] intArray26 = new int[] {};
        int[] intArray27 = new int[] {};
        int int28 = org.apache.commons.math.util.MathUtils.distance1(intArray26, intArray27);
        int[] intArray29 = new int[] {};
        int[] intArray30 = new int[] {};
        int int31 = org.apache.commons.math.util.MathUtils.distance1(intArray29, intArray30);
        int int32 = org.apache.commons.math.util.MathUtils.distance1(intArray27, intArray30);
        int[] intArray33 = new int[] {};
        int[] intArray34 = new int[] {};
        int int35 = org.apache.commons.math.util.MathUtils.distance1(intArray33, intArray34);
        double double36 = org.apache.commons.math.util.MathUtils.distance(intArray27, intArray33);
        int int37 = org.apache.commons.math.util.MathUtils.distanceInf(intArray23, intArray33);
        int[] intArray38 = new int[] {};
        int[] intArray39 = new int[] {};
        int int40 = org.apache.commons.math.util.MathUtils.distance1(intArray38, intArray39);
        int[] intArray41 = new int[] {};
        int[] intArray42 = new int[] {};
        int int43 = org.apache.commons.math.util.MathUtils.distance1(intArray41, intArray42);
        int int44 = org.apache.commons.math.util.MathUtils.distance1(intArray39, intArray42);
        int int45 = org.apache.commons.math.util.MathUtils.distance1(intArray23, intArray39);
        int int46 = org.apache.commons.math.util.MathUtils.distanceInf(intArray4, intArray39);
        int[] intArray47 = new int[] {};
        int[] intArray48 = new int[] {};
        int int49 = org.apache.commons.math.util.MathUtils.distance1(intArray47, intArray48);
        int[] intArray50 = new int[] {};
        int[] intArray51 = new int[] {};
        int int52 = org.apache.commons.math.util.MathUtils.distance1(intArray50, intArray51);
        int int53 = org.apache.commons.math.util.MathUtils.distance1(intArray48, intArray51);
        int[] intArray54 = new int[] {};
        int[] intArray55 = new int[] {};
        int int56 = org.apache.commons.math.util.MathUtils.distance1(intArray54, intArray55);
        double double57 = org.apache.commons.math.util.MathUtils.distance(intArray48, intArray54);
        int int58 = org.apache.commons.math.util.MathUtils.distance1(intArray39, intArray54);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertNotNull(intArray54);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test282");
        long long1 = org.apache.commons.math.util.FastMath.round((double) (-190L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-190L) + "'", long1 == (-190L));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test283");
        double double2 = org.apache.commons.math.util.MathUtils.log(1.1102230246251565E-16d, 1.1270142631252122d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.0032548259227155375d) + "'", double2 == (-0.0032548259227155375d));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test284");
        int int2 = org.apache.commons.math.util.FastMath.max(32, 438727775);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 438727775 + "'", int2 == 438727775);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test285");
        double double3 = org.apache.commons.math.util.MathUtils.round(1.0536712113928814E-8d, (-300), 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E300d + "'", double3 == 1.0E300d);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test286");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 461100L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 461100.0f + "'", float1 == 461100.0f);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test287");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(63.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.9790572078963917d + "'", double1 == 3.9790572078963917d);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test288");
        double double1 = org.apache.commons.math.util.FastMath.sin((-0.5063656411097588d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.48500216304847765d) + "'", double1 == (-0.48500216304847765d));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test289");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) (-1444685106L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-21.784304395599616d) + "'", double1 == (-21.784304395599616d));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test290");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) 291);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test291");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 970);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 970 + "'", int1 == 970);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test292");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(3578896096L, (long) (short) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test293");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test294");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 100);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 100.0f + "'", float1 == 100.0f);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test295");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 70.62688523139718d, (java.lang.Number) 1.2591291720406148d, 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 70.62688523139718d + "'", number4.equals(70.62688523139718d));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test296");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(190L, (-125687604222L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2L + "'", long2 == 2L);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test297");
        double double2 = org.apache.commons.math.util.FastMath.min(0.18952113006314425d, (double) 3104L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.18952113006314425d + "'", double2 == 0.18952113006314425d);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test298");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 3104.0f, 8.540775674112082d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test299");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (short) 0, (int) (short) 0);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException7 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (short) 0, (int) (short) 0);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException7);
        java.lang.Number number9 = nonMonotonousSequenceException7.getPrevious();
        java.lang.Number number10 = nonMonotonousSequenceException7.getArgument();
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + (short) 0 + "'", number9.equals((short) 0));
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 0L + "'", number10.equals(0L));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test300");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 97L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test301");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(8.540775674112082d, 12.21292908632666d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test302");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-10), (-1249873867));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test303");
        double[] doubleArray3 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) (short) -1);
        double[] doubleArray6 = null;
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray6);
        double[] doubleArray11 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray13 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, (double) (short) -1);
        double[] doubleArray17 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray17, (double) (short) -1);
        double[] doubleArray21 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, (double) (-1L));
        double double22 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray13, doubleArray21);
        double[] doubleArray29 = new double[] { (short) -1, (-1L), 1.0d, 100, '#', 'a' };
        double[] doubleArray33 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray35 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray33, (double) (short) -1);
        double[] doubleArray36 = null;
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equals(doubleArray33, doubleArray36);
        double[] doubleArray41 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray43 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray41, (double) (short) -1);
        double[] doubleArray47 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray49 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray47, (double) (short) -1);
        double[] doubleArray51 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray49, (double) (-1L));
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray43, doubleArray51);
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray36, doubleArray43);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection57 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException59 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-90L), (java.lang.Number) (-1), (int) (byte) 1, orderDirection57, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray43, orderDirection57, true);
        boolean boolean62 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray29, doubleArray43);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray43);
        double[] doubleArray67 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray69 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray67, (double) (short) -1);
        double[] doubleArray73 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray75 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray73, (double) (short) -1);
        double[] doubleArray77 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray75, (double) (-1L));
        boolean boolean78 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray69, doubleArray77);
        double[] doubleArray80 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray77, 10.0d);
        double double81 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray77);
        double double82 = org.apache.commons.math.util.MathUtils.distance1(doubleArray43, doubleArray77);
        boolean boolean83 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray77);
        double double84 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray77);
        double[] doubleArray88 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray90 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray88, (double) (short) -1);
        double[] doubleArray94 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray96 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray94, (double) (short) -1);
        double double97 = org.apache.commons.math.util.MathUtils.distance1(doubleArray90, doubleArray94);
        double double98 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray77, doubleArray94);
        int int99 = org.apache.commons.math.util.MathUtils.hash(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + orderDirection57 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection57.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 0.8540775674112082d + "'", double81 == 0.8540775674112082d);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 0.0d + "'", double82 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + true + "'", boolean83 == true);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 52.83870967741935d + "'", double84 == 52.83870967741935d);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertNotNull(doubleArray90);
        org.junit.Assert.assertNotNull(doubleArray94);
        org.junit.Assert.assertNotNull(doubleArray96);
        org.junit.Assert.assertTrue("'" + double97 + "' != '" + 63.0d + "'", double97 == 63.0d);
        org.junit.Assert.assertTrue("'" + double98 + "' != '" + 52.83870967741935d + "'", double98 == 52.83870967741935d);
        org.junit.Assert.assertTrue("'" + int99 + "' != '" + (-1249873867) + "'", int99 == (-1249873867));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test304");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((-0.4480736161291702d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7652143822983442d) + "'", double1 == (-0.7652143822983442d));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test305");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test306");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 626350111L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test307");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) (-626350014L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test308");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((-9.99999999999987d), (double) 291);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test309");
        double double2 = org.apache.commons.math.util.FastMath.min(63.0d, 1.0795255743608363E9d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 63.0d + "'", double2 == 63.0d);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test310");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) (byte) -1, (-626347007));
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray4);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test311");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.0d, 3.103983027882299d, (double) 97);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test312");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 62, (double) (-190L));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test313");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(4, 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test314");
        double[] doubleArray0 = null;
        double[] doubleArray4 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray6 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray4, (double) (short) -1);
        double[] doubleArray10 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray10, (double) (short) -1);
        double[] doubleArray14 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, (double) (-1L));
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray14);
        double[] doubleArray19 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray21 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, (double) (short) -1);
        double[] doubleArray22 = null;
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equals(doubleArray19, doubleArray22);
        double[] doubleArray27 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, (double) (short) -1);
        double[] doubleArray33 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray35 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray33, (double) (short) -1);
        double[] doubleArray37 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray35, (double) (-1L));
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray29, doubleArray37);
        double double39 = org.apache.commons.math.util.MathUtils.distance1(doubleArray19, doubleArray29);
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray19);
        double[] doubleArray44 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray44, (double) (short) -1);
        double[] doubleArray50 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray52 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray50, (double) (short) -1);
        double[] doubleArray54 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray52, (double) (-1L));
        boolean boolean55 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray46, doubleArray54);
        double[] doubleArray59 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray61 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray59, (double) (short) -1);
        double[] doubleArray62 = null;
        boolean boolean63 = org.apache.commons.math.util.MathUtils.equals(doubleArray59, doubleArray62);
        double[] doubleArray67 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray69 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray67, (double) (short) -1);
        double[] doubleArray73 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray75 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray73, (double) (short) -1);
        double[] doubleArray77 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray75, (double) (-1L));
        boolean boolean78 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray69, doubleArray77);
        double double79 = org.apache.commons.math.util.MathUtils.distance1(doubleArray59, doubleArray69);
        boolean boolean80 = org.apache.commons.math.util.MathUtils.equals(doubleArray46, doubleArray59);
        double[] doubleArray84 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray86 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray84, (double) (short) -1);
        double[] doubleArray88 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray86, (double) (-1L));
        boolean boolean89 = org.apache.commons.math.util.MathUtils.equals(doubleArray46, doubleArray86);
        double double90 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray19, doubleArray46);
        boolean boolean91 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray19);
        int int92 = org.apache.commons.math.util.MathUtils.hash(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 63.0d + "'", double39 == 63.0d);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 63.0d + "'", double79 == 63.0d);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + true + "'", boolean89 == true);
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + 52.83870967741935d + "'", double90 == 52.83870967741935d);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 0 + "'", int92 == 0);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test315");
        double double1 = org.apache.commons.math.util.FastMath.exp(3.141592653589793d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 23.140692632779267d + "'", double1 == 23.140692632779267d);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test316");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 11.0f, (java.lang.Number) (-11013.232874703393d), 1074790400);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test317");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow(223708937, (long) (-447362047));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test318");
        double[] doubleArray3 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) (short) -1);
        double[] doubleArray6 = null;
        try {
            double double7 = org.apache.commons.math.util.MathUtils.distance(doubleArray3, doubleArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test319");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((-16121852886L), 5L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test320");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 1L, (int) (short) 10);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (1 >= 0)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (1 >= 0)"));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test321");
        double double2 = org.apache.commons.math.util.FastMath.max(52.99999999999999d, 1.2498738669999998E9d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.2498738669999998E9d + "'", double2 == 1.2498738669999998E9d);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test322");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(42.12656474461542d, (-0.0032548259227155375d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.8557324056416817d) + "'", double2 == (-1.8557324056416817d));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test323");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test324");
        double double1 = org.apache.commons.math.util.FastMath.ulp(60.95176076419315d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.105427357601002E-15d + "'", double1 == 7.105427357601002E-15d);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test325");
        long long2 = org.apache.commons.math.util.FastMath.max(1007000L, 7499243202L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 7499243202L + "'", long2 == 7499243202L);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test326");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 52L, (-1.5707963258833084d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0020160822805979544d + "'", double2 == 0.0020160822805979544d);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test327");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 11.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 29937.07084924806d + "'", double1 == 29937.07084924806d);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test328");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(0.9797359324758174d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test329");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 108640L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.035989756936426d + "'", double1 == 5.035989756936426d);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test330");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(8625328718985906577L, (long) 970);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 8625328718985905607L + "'", long2 == 8625328718985905607L);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test331");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-90L), (java.lang.Number) (-1), (int) (byte) 1, orderDirection3, false);
        java.lang.Class<?> wildcardClass6 = nonMonotonousSequenceException5.getClass();
        int int7 = nonMonotonousSequenceException5.getIndex();
        java.lang.String str8 = nonMonotonousSequenceException5.toString();
        java.lang.Number number9 = nonMonotonousSequenceException5.getArgument();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > -90)" + "'", str8.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > -90)"));
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + (-90L) + "'", number9.equals((-90L)));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test332");
        double[] doubleArray3 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) (short) -1);
        double[] doubleArray9 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, (double) (short) -1);
        double[] doubleArray13 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, (double) (-1L));
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray13);
        double[] doubleArray18 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray18, (double) (short) -1);
        double[] doubleArray21 = null;
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equals(doubleArray18, doubleArray21);
        double[] doubleArray26 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, (double) (short) -1);
        double[] doubleArray32 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray32, (double) (short) -1);
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray34, (double) (-1L));
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray28, doubleArray36);
        double double38 = org.apache.commons.math.util.MathUtils.distance1(doubleArray18, doubleArray28);
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray18);
        double[] doubleArray43 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray45 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray43, (double) (short) -1);
        double[] doubleArray47 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray45, (double) (-1L));
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray45);
        double[] doubleArray52 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray54 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray52, (double) (short) -1);
        double[] doubleArray58 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray60 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray58, (double) (short) -1);
        double[] doubleArray62 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray60, (double) (-1L));
        double double63 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray54, doubleArray62);
        double double64 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray45, doubleArray54);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray45);
        int int66 = org.apache.commons.math.util.MathUtils.hash(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 63.0d + "'", double38 == 63.0d);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + (-1249873867) + "'", int66 == (-1249873867));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test333");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((-10), 0);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test334");
        double[] doubleArray3 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) (short) -1);
        double[] doubleArray7 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray5, (double) (-1L));
        double[] doubleArray11 = new double[] { 3.1909099185344844E-8d, 156.3608363030788d, 1079525376 };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray11);
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray11);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, 9.332621544395286E157d);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0795253760000114E9d + "'", double13 == 1.0795253760000114E9d);
        org.junit.Assert.assertNotNull(doubleArray15);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test335");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) (-1.0747904E9f));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1043332096) + "'", int1 == (-1043332096));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test336");
        int[] intArray0 = new int[] {};
        int[] intArray1 = new int[] {};
        int int2 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray1);
        int[] intArray3 = new int[] {};
        int[] intArray4 = new int[] {};
        int int5 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray4);
        int int6 = org.apache.commons.math.util.MathUtils.distance1(intArray1, intArray4);
        int[] intArray7 = new int[] {};
        int[] intArray8 = new int[] {};
        int int9 = org.apache.commons.math.util.MathUtils.distance1(intArray7, intArray8);
        int[] intArray10 = new int[] {};
        int[] intArray11 = new int[] {};
        int int12 = org.apache.commons.math.util.MathUtils.distance1(intArray10, intArray11);
        int int13 = org.apache.commons.math.util.MathUtils.distance1(intArray8, intArray11);
        int[] intArray14 = new int[] {};
        int[] intArray15 = new int[] {};
        int int16 = org.apache.commons.math.util.MathUtils.distance1(intArray14, intArray15);
        int int17 = org.apache.commons.math.util.MathUtils.distance1(intArray11, intArray14);
        double double18 = org.apache.commons.math.util.MathUtils.distance(intArray4, intArray14);
        int[] intArray19 = new int[] {};
        int[] intArray20 = new int[] {};
        int int21 = org.apache.commons.math.util.MathUtils.distance1(intArray19, intArray20);
        int[] intArray22 = new int[] {};
        int[] intArray23 = new int[] {};
        int int24 = org.apache.commons.math.util.MathUtils.distance1(intArray22, intArray23);
        int int25 = org.apache.commons.math.util.MathUtils.distance1(intArray20, intArray23);
        int[] intArray26 = new int[] {};
        int[] intArray27 = new int[] {};
        int int28 = org.apache.commons.math.util.MathUtils.distance1(intArray26, intArray27);
        int int29 = org.apache.commons.math.util.MathUtils.distance1(intArray23, intArray26);
        int[] intArray30 = new int[] {};
        int[] intArray31 = new int[] {};
        int int32 = org.apache.commons.math.util.MathUtils.distance1(intArray30, intArray31);
        int[] intArray33 = new int[] {};
        int[] intArray34 = new int[] {};
        int int35 = org.apache.commons.math.util.MathUtils.distance1(intArray33, intArray34);
        int int36 = org.apache.commons.math.util.MathUtils.distance1(intArray31, intArray34);
        int[] intArray37 = new int[] {};
        int[] intArray38 = new int[] {};
        int int39 = org.apache.commons.math.util.MathUtils.distance1(intArray37, intArray38);
        double double40 = org.apache.commons.math.util.MathUtils.distance(intArray31, intArray37);
        int int41 = org.apache.commons.math.util.MathUtils.distance1(intArray23, intArray31);
        int int42 = org.apache.commons.math.util.MathUtils.distanceInf(intArray14, intArray31);
        int[] intArray43 = new int[] {};
        int[] intArray44 = new int[] {};
        int int45 = org.apache.commons.math.util.MathUtils.distance1(intArray43, intArray44);
        int[] intArray46 = new int[] {};
        int[] intArray47 = new int[] {};
        int int48 = org.apache.commons.math.util.MathUtils.distance1(intArray46, intArray47);
        int int49 = org.apache.commons.math.util.MathUtils.distance1(intArray44, intArray47);
        int int50 = org.apache.commons.math.util.MathUtils.distanceInf(intArray31, intArray47);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test337");
        double double1 = org.apache.commons.math.util.MathUtils.sign(31.11530376419202d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test338");
        double double1 = org.apache.commons.math.util.FastMath.acosh(4.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0634370688955608d + "'", double1 == 2.0634370688955608d);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test339");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 38833706262L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 25.075701605111195d + "'", double1 == 25.075701605111195d);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test340");
        double double1 = org.apache.commons.math.util.FastMath.atan(3.174802103936399d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.265653458137023d + "'", double1 == 1.265653458137023d);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test341");
        double double1 = org.apache.commons.math.util.FastMath.atanh(1.145976303209723d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test342");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow((int) '#', (-35L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test343");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((-626347008));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test344");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm((-10), (-1869155406));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test345");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((-1249873867));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test346");
        double[] doubleArray3 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) (short) -1);
        double[] doubleArray6 = null;
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray6);
        double[] doubleArray11 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray13 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, (double) (short) -1);
        double[] doubleArray17 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray17, (double) (short) -1);
        double[] doubleArray21 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, (double) (-1L));
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray13, doubleArray21);
        double double23 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray13);
        int int24 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        java.lang.Class<?> wildcardClass25 = doubleArray3.getClass();
        double[] doubleArray27 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) 1);
        java.lang.Class<?> wildcardClass28 = doubleArray3.getClass();
        java.lang.Number number30 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection35 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException37 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-90L), (java.lang.Number) (-1), (int) (byte) 1, orderDirection35, false);
        java.lang.Class<?> wildcardClass38 = nonMonotonousSequenceException37.getClass();
        int int39 = nonMonotonousSequenceException37.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection40 = nonMonotonousSequenceException37.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException42 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 3, number30, (int) 'a', orderDirection40, true);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray3, orderDirection40, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (52 >= 10)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 63.0d + "'", double23 == 63.0d);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 438727775 + "'", int24 == 438727775);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + orderDirection35 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection35.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertTrue("'" + orderDirection40 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection40.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test347");
        double double3 = org.apache.commons.math.util.MathUtils.round(0.010256138689425936d, 62, 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.010256138689425936d + "'", double3 == 0.010256138689425936d);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test348");
        double[] doubleArray6 = new double[] { (-626347060L), 260, 0.08002277859966438d, 5L, 970, 1.391070465E9d };
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.5255778178011663E9d + "'", double7 == 1.5255778178011663E9d);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test349");
        double double1 = org.apache.commons.math.util.FastMath.atanh(5.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test350");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) (-738962718), (long) (byte) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2L + "'", long2 == 2L);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test351");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.0158400256874338d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.12585716383040657d + "'", double1 == 0.12585716383040657d);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test352");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-90L), (java.lang.Number) (-1), (int) (byte) 1, orderDirection3, false);
        java.lang.Class<?> wildcardClass6 = nonMonotonousSequenceException5.getClass();
        int int7 = nonMonotonousSequenceException5.getIndex();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 1L, (int) (short) 10);
        java.lang.Class<?> wildcardClass12 = nonMonotonousSequenceException11.getClass();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        java.lang.Number number14 = nonMonotonousSequenceException11.getArgument();
        java.lang.Throwable[] throwableArray15 = nonMonotonousSequenceException11.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection16 = nonMonotonousSequenceException11.getDirection();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 0.0f + "'", number14.equals(0.0f));
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertTrue("'" + orderDirection16 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection16.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test353");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow((-1249873867), (-10));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test354");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(1079525376L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1079525376L + "'", long2 == 1079525376L);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test355");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-90L), (java.lang.Number) (-1), (int) (byte) 1, orderDirection3, false);
        java.lang.Class<?> wildcardClass6 = nonMonotonousSequenceException5.getClass();
        int int7 = nonMonotonousSequenceException5.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = nonMonotonousSequenceException5.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = nonMonotonousSequenceException5.getDirection();
        java.lang.Throwable[] throwableArray10 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.String str11 = nonMonotonousSequenceException5.toString();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + orderDirection8 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection8.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > -90)" + "'", str11.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > -90)"));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test356");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (short) 0, (int) (short) 0);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (short) 0, (int) (short) 0);
        nonMonotonousSequenceException6.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException10);
        java.lang.Number number12 = nonMonotonousSequenceException10.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = nonMonotonousSequenceException10.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 14.154262241479262d, (java.lang.Number) (-10.0f), (-1869155406), orderDirection13, false);
        java.lang.String str16 = nonMonotonousSequenceException15.toString();
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (short) 0 + "'", number12.equals((short) 0));
        org.junit.Assert.assertTrue("'" + orderDirection13 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection13.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1,869,155,407 and -1,869,155,406 are not increasing (-10 > 14.154)" + "'", str16.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1,869,155,407 and -1,869,155,406 are not increasing (-10 > 14.154)"));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test357");
        double double1 = org.apache.commons.math.util.FastMath.floor(5.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.0d + "'", double1 == 5.0d);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test358");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(5.916079783099616d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.4322992790977875d + "'", double1 == 2.4322992790977875d);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test359");
        double double1 = org.apache.commons.math.util.FastMath.asinh(3.6661404377193025E21d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 50.346573590279974d + "'", double1 == 50.346573590279974d);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test360");
        double double1 = org.apache.commons.math.util.FastMath.log(99.99999999999999d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.605170185988091d + "'", double1 == 4.605170185988091d);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test361");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((-0.9463876021584277d), (double) 1391070465, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test362");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(1079525376L, (long) 3);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3L + "'", long2 == 3L);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test363");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) (short) 0, 3);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test364");
        double[] doubleArray3 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) (short) -1);
        double[] doubleArray9 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, (double) (short) -1);
        double[] doubleArray13 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, (double) (-1L));
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray13);
        double[] doubleArray18 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray18, (double) (short) -1);
        double[] doubleArray21 = null;
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equals(doubleArray18, doubleArray21);
        double[] doubleArray26 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, (double) (short) -1);
        double[] doubleArray32 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray32, (double) (short) -1);
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray34, (double) (-1L));
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray28, doubleArray36);
        double double38 = org.apache.commons.math.util.MathUtils.distance1(doubleArray18, doubleArray28);
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray18);
        double[] doubleArray43 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray45 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray43, (double) (short) -1);
        double[] doubleArray47 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray45, (double) (-1L));
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray45);
        double[] doubleArray52 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray54 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray52, (double) (short) -1);
        double[] doubleArray58 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray60 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray58, (double) (short) -1);
        double[] doubleArray62 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray60, (double) (-1L));
        double double63 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray54, doubleArray62);
        double double64 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray45, doubleArray54);
        java.lang.Class<?> wildcardClass65 = doubleArray54.getClass();
        java.lang.Class<?> wildcardClass66 = doubleArray54.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 63.0d + "'", double38 == 63.0d);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass65);
        org.junit.Assert.assertNotNull(wildcardClass66);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test365");
        double[] doubleArray2 = new double[] { 291, (-0.9463876021584277d) };
        double[] doubleArray6 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) (short) -1);
        double[] doubleArray12 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray14 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, (double) (short) -1);
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray14, (double) (-1L));
        double double17 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray8, doubleArray16);
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, (double) (short) 100);
        double double20 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray16);
        double[] doubleArray24 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray26 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray24, (double) (short) -1);
        double[] doubleArray27 = null;
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equals(doubleArray24, doubleArray27);
        double[] doubleArray32 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray32, (double) (short) -1);
        double[] doubleArray38 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray40 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray38, (double) (short) -1);
        double[] doubleArray42 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray40, (double) (-1L));
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray34, doubleArray42);
        double double44 = org.apache.commons.math.util.MathUtils.distance1(doubleArray24, doubleArray34);
        int int45 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        java.lang.Class<?> wildcardClass46 = doubleArray24.getClass();
        double[] doubleArray48 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray24, (double) 1);
        boolean boolean49 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 292.6238069569971d + "'", double20 == 292.6238069569971d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 63.0d + "'", double44 == 63.0d);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 438727775 + "'", int45 == 438727775);
        org.junit.Assert.assertNotNull(wildcardClass46);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test366");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) (-16121856000L), 50.10708126551846d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.6121855999999998E10d) + "'", double2 == (-1.6121855999999998E10d));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test367");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test368");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.6931471805599453d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6d + "'", double1 == 0.6d);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test369");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(Double.POSITIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test370");
        double[] doubleArray0 = null;
        double[] doubleArray4 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray6 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray4, (double) (short) -1);
        double[] doubleArray10 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray10, (double) (short) -1);
        double[] doubleArray14 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, (double) (-1L));
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray14);
        double[] doubleArray19 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray21 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, (double) (short) -1);
        double[] doubleArray22 = null;
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equals(doubleArray19, doubleArray22);
        double[] doubleArray27 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, (double) (short) -1);
        double[] doubleArray33 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray35 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray33, (double) (short) -1);
        double[] doubleArray37 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray35, (double) (-1L));
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray29, doubleArray37);
        double double39 = org.apache.commons.math.util.MathUtils.distance1(doubleArray19, doubleArray29);
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray19);
        double[] doubleArray44 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray44, (double) (short) -1);
        double[] doubleArray50 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray52 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray50, (double) (short) -1);
        double[] doubleArray54 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray52, (double) (-1L));
        boolean boolean55 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray46, doubleArray54);
        double[] doubleArray59 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray61 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray59, (double) (short) -1);
        double[] doubleArray62 = null;
        boolean boolean63 = org.apache.commons.math.util.MathUtils.equals(doubleArray59, doubleArray62);
        double[] doubleArray67 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray69 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray67, (double) (short) -1);
        double[] doubleArray73 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray75 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray73, (double) (short) -1);
        double[] doubleArray77 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray75, (double) (-1L));
        boolean boolean78 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray69, doubleArray77);
        double double79 = org.apache.commons.math.util.MathUtils.distance1(doubleArray59, doubleArray69);
        boolean boolean80 = org.apache.commons.math.util.MathUtils.equals(doubleArray46, doubleArray59);
        double[] doubleArray84 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray86 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray84, (double) (short) -1);
        double[] doubleArray88 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray86, (double) (-1L));
        boolean boolean89 = org.apache.commons.math.util.MathUtils.equals(doubleArray46, doubleArray86);
        double double90 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray19, doubleArray46);
        boolean boolean91 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray19);
        double[] doubleArray92 = null;
        try {
            double double93 = org.apache.commons.math.util.MathUtils.distance(doubleArray19, doubleArray92);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 63.0d + "'", double39 == 63.0d);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 63.0d + "'", double79 == 63.0d);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + true + "'", boolean89 == true);
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + 52.83870967741935d + "'", double90 == 52.83870967741935d);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test371");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 52L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test372");
        double double1 = org.apache.commons.math.util.FastMath.rint(1.1270142631252122d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test373");
        double double3 = org.apache.commons.math.util.MathUtils.round(14438.536437296747d, (int) ' ', 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 14438.536437296747d + "'", double3 == 14438.536437296747d);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test374");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((-626350111), 2);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test375");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) 'a');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 97 + "'", int1 == 97);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test376");
        long long1 = org.apache.commons.math.util.MathUtils.sign(32L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test377");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 100L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test378");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(1.5549246438031066d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test379");
        double double1 = org.apache.commons.math.util.FastMath.ulp(25.075701605111195d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.552713678800501E-15d + "'", double1 == 3.552713678800501E-15d);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test380");
        double double1 = org.apache.commons.math.util.MathUtils.sign(2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test381");
        double[] doubleArray3 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) (short) -1);
        double[] doubleArray9 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, (double) (short) -1);
        double double12 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray9);
        double[] doubleArray16 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, (double) (short) -1);
        double[] doubleArray19 = null;
        boolean boolean20 = org.apache.commons.math.util.MathUtils.equals(doubleArray16, doubleArray19);
        double[] doubleArray24 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray26 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray24, (double) (short) -1);
        double[] doubleArray30 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray30, (double) (short) -1);
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray32, (double) (-1L));
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray26, doubleArray34);
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray26);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection40 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException42 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-90L), (java.lang.Number) (-1), (int) (byte) 1, orderDirection40, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray26, orderDirection40, true);
        boolean boolean45 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray26);
        double[] doubleArray49 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray51 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray49, (double) (short) -1);
        double[] doubleArray53 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray51, (double) (-1L));
        double double54 = org.apache.commons.math.util.MathUtils.distance1(doubleArray26, doubleArray51);
        double[] doubleArray55 = null;
        try {
            double double56 = org.apache.commons.math.util.MathUtils.distance1(doubleArray51, doubleArray55);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 63.0d + "'", double12 == 63.0d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + orderDirection40 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection40.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test382");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 'a', 252L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-155L) + "'", long2 == (-155L));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test383");
        int int2 = org.apache.commons.math.util.MathUtils.pow(197, 32L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 728967041 + "'", int2 == 728967041);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test384");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(0L, 108640L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-108640L) + "'", long2 == (-108640L));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test385");
        double double2 = org.apache.commons.math.util.FastMath.max(0.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test386");
        double double1 = org.apache.commons.math.util.FastMath.tan(14438.536437296747d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.2271907006446047d) + "'", double1 == (-0.2271907006446047d));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test387");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 1L, (int) (short) 10);
        int int10 = nonMonotonousSequenceException9.getIndex();
        java.lang.Class<?> wildcardClass11 = nonMonotonousSequenceException9.getClass();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = nonMonotonousSequenceException9.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException14 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10L, (java.lang.Number) (-35L), 1079525376, orderDirection12, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) (-10.0f), (int) (byte) 10, orderDirection12, true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test388");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(19.9188786972913d, (double) 900L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test389");
        int int2 = org.apache.commons.math.util.FastMath.min(184331630, 3101);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3101 + "'", int2 == 3101);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test390");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) (-626347060L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.2634706E8d + "'", double1 == 6.2634706E8d);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test391");
        double double2 = org.apache.commons.math.util.FastMath.max(292.6238069569971d, 2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 292.6238069569971d + "'", double2 == 292.6238069569971d);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test392");
        double double1 = org.apache.commons.math.util.FastMath.rint(3.8834864931005E-310d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test393");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 970);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.9867717342662448d + "'", double1 == 2.9867717342662448d);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test394");
        int int1 = org.apache.commons.math.util.FastMath.abs(1077936128);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1077936128 + "'", int1 == 1077936128);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test395");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 100, (double) 2L, 4);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test396");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) -1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) -1 + "'", short1 == (short) -1);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test397");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0158400256874338d, (double) 1079525376, 197);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test398");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 184331631, (float) 35L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 35.0f + "'", float2 == 35.0f);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test399");
        double double1 = org.apache.commons.math.util.FastMath.abs(11.591953275521519d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11.591953275521519d + "'", double1 == 11.591953275521519d);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test400");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.017453292519943295d, 1.265653458137023d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0174532925199433d + "'", double2 == 0.0174532925199433d);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test401");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test402");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.027712143770207958d, (double) 35L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test403");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, (double) 8625328718985906576L, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test404");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(5.298292365610485d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test405");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) (-12565L), 4.38727775E8d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-12564.999999999998d) + "'", double2 == (-12564.999999999998d));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test406");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 1074790313L, (double) 87);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test407");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow((-3), (-626347007));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test408");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 43394118559L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2147483647 + "'", int1 == 2147483647);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test409");
        double double1 = org.apache.commons.math.util.FastMath.ulp(1.5607966601082315d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test410");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test411");
        java.lang.Number number1 = null;
        double[] doubleArray6 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) (short) -1);
        double[] doubleArray9 = null;
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray9);
        double[] doubleArray14 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray14, (double) (short) -1);
        double[] doubleArray20 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray20, (double) (short) -1);
        double[] doubleArray24 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray22, (double) (-1L));
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray16, doubleArray24);
        double double26 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray16);
        double[] doubleArray30 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray30, (double) (short) -1);
        double[] doubleArray33 = null;
        boolean boolean34 = org.apache.commons.math.util.MathUtils.equals(doubleArray30, doubleArray33);
        double[] doubleArray38 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray40 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray38, (double) (short) -1);
        double[] doubleArray44 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray44, (double) (short) -1);
        double[] doubleArray48 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray46, (double) (-1L));
        boolean boolean49 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray40, doubleArray48);
        boolean boolean50 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray33, doubleArray40);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection54 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException56 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-90L), (java.lang.Number) (-1), (int) (byte) 1, orderDirection54, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray40, orderDirection54, true);
        double double59 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray6, doubleArray40);
        double[] doubleArray63 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray65 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray63, (double) (short) -1);
        double[] doubleArray67 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray65, (double) (-1L));
        double[] doubleArray71 = new double[] { 3.1909099185344844E-8d, 156.3608363030788d, 1079525376 };
        boolean boolean72 = org.apache.commons.math.util.MathUtils.equals(doubleArray65, doubleArray71);
        boolean boolean73 = org.apache.commons.math.util.MathUtils.equals(doubleArray40, doubleArray65);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection77 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException79 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-3), (java.lang.Number) 10.0f, 970, orderDirection77, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray40, orderDirection77, true);
        java.lang.Class<?> wildcardClass82 = orderDirection77.getClass();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException84 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 4, number1, 0, orderDirection77, false);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 63.0d + "'", double26 == 63.0d);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + orderDirection54 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection54.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 52.83870967741935d + "'", double59 == 52.83870967741935d);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + true + "'", boolean73 == true);
        org.junit.Assert.assertTrue("'" + orderDirection77 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection77.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass82);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test412");
        double double1 = org.apache.commons.math.util.FastMath.cosh(1.0E300d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test413");
        double double1 = org.apache.commons.math.util.FastMath.asinh((-0.7023967071298747d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6546289196540399d) + "'", double1 == (-0.6546289196540399d));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test414");
        int int2 = org.apache.commons.math.util.FastMath.min((-626350101), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-626350101) + "'", int2 == (-626350101));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test415");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((-626350101L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test416");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow(1444685106L, (long) (-738962753));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test417");
        double double1 = org.apache.commons.math.util.FastMath.log(10.270803231912973d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.3293052323634105d + "'", double1 == 2.3293052323634105d);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test418");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-1444685106), (int) (short) 100);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test419");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 728967041, (double) 197);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.28967041E8d + "'", double2 == 7.28967041E8d);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test420");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test421");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) (-1.0f), 0.01745152065146582d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.5533465774723854d) + "'", double2 == (-1.5533465774723854d));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test422");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) 4L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 27.28991719712775d + "'", double1 == 27.28991719712775d);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test423");
        double double1 = org.apache.commons.math.util.FastMath.log((-1.5533465774723854d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test424");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (byte) -1, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test425");
        double[] doubleArray6 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) (short) -1);
        double[] doubleArray9 = null;
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray9);
        double[] doubleArray14 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray14, (double) (short) -1);
        double[] doubleArray20 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray20, (double) (short) -1);
        double[] doubleArray24 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray22, (double) (-1L));
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray16, doubleArray24);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray9, doubleArray16);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection30 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException32 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-90L), (java.lang.Number) (-1), (int) (byte) 1, orderDirection30, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray16, orderDirection30, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException36 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 900L, (java.lang.Number) 184331630, 461100, orderDirection30, false);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + orderDirection30 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection30.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test426");
        double[] doubleArray0 = null;
        double[] doubleArray4 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray6 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray4, (double) (short) -1);
        double[] doubleArray10 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray10, (double) (short) -1);
        double[] doubleArray14 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, (double) (-1L));
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray14);
        double[] doubleArray19 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray21 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, (double) (short) -1);
        double[] doubleArray22 = null;
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equals(doubleArray19, doubleArray22);
        double[] doubleArray27 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, (double) (short) -1);
        double[] doubleArray33 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray35 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray33, (double) (short) -1);
        double[] doubleArray37 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray35, (double) (-1L));
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray29, doubleArray37);
        double double39 = org.apache.commons.math.util.MathUtils.distance1(doubleArray19, doubleArray29);
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray19);
        double[] doubleArray44 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray44, (double) (short) -1);
        double[] doubleArray48 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray46, (double) (-1L));
        boolean boolean49 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray46);
        double[] doubleArray51 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray46, (double) (-1.0f));
        try {
            double double52 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 63.0d + "'", double39 == 63.0d);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNotNull(doubleArray51);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test427");
        double[] doubleArray3 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) (short) -1);
        double[] doubleArray7 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray5, (double) (-1L));
        double[] doubleArray11 = new double[] { 3.1909099185344844E-8d, 156.3608363030788d, 1079525376 };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray11);
        java.lang.Class<?> wildcardClass13 = doubleArray11.getClass();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test428");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 87, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test429");
        float float3 = org.apache.commons.math.util.MathUtils.round((float) 447362012, 260, 5);
        org.junit.Assert.assertEquals((float) float3, Float.NaN, 0);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test430");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(0.12585716383040657d, (double) 461100.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 461097.96280984493d + "'", double2 == 461097.96280984493d);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test431");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((-144468510600L), (-58L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4189586807400L + "'", long2 == 4189586807400L);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test432");
        double double2 = org.apache.commons.math.util.FastMath.min((-0.8813735870195429d), (double) 1077936228);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.8813735870195429d) + "'", double2 == (-0.8813735870195429d));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test433");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(0.6360918665423811d, 52.99999999999999d, (double) 5L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test434");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 1074790400);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test435");
        long long2 = org.apache.commons.math.util.FastMath.min(4L, (long) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4L + "'", long2 == 4L);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test436");
        long long2 = org.apache.commons.math.util.FastMath.min(1074790403L, 461100L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 461100L + "'", long2 == 461100L);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test437");
        double double2 = org.apache.commons.math.util.FastMath.min((-6.102016471589204E38d), 2.220446049250313E-16d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-6.102016471589204E38d) + "'", double2 == (-6.102016471589204E38d));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test438");
        long long2 = org.apache.commons.math.util.MathUtils.pow((-190L), (long) (short) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test439");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) (-1249873867));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test440");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) (-16121852886L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test441");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(4.38727775E8d, (-0.6546289196540399d), (-1.5707963258833084d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test442");
        int[] intArray0 = new int[] {};
        int[] intArray1 = new int[] {};
        int int2 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray1);
        int[] intArray3 = new int[] {};
        int[] intArray4 = new int[] {};
        int int5 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray4);
        int int6 = org.apache.commons.math.util.MathUtils.distance1(intArray1, intArray4);
        int[] intArray7 = new int[] {};
        int[] intArray8 = new int[] {};
        int int9 = org.apache.commons.math.util.MathUtils.distance1(intArray7, intArray8);
        int[] intArray10 = new int[] {};
        int[] intArray11 = new int[] {};
        int int12 = org.apache.commons.math.util.MathUtils.distance1(intArray10, intArray11);
        int int13 = org.apache.commons.math.util.MathUtils.distance1(intArray8, intArray11);
        int[] intArray14 = new int[] {};
        int[] intArray15 = new int[] {};
        int int16 = org.apache.commons.math.util.MathUtils.distance1(intArray14, intArray15);
        double double17 = org.apache.commons.math.util.MathUtils.distance(intArray8, intArray14);
        int int18 = org.apache.commons.math.util.MathUtils.distanceInf(intArray4, intArray14);
        int[] intArray19 = new int[] {};
        int[] intArray20 = new int[] {};
        int int21 = org.apache.commons.math.util.MathUtils.distance1(intArray19, intArray20);
        int[] intArray22 = new int[] {};
        int[] intArray23 = new int[] {};
        int int24 = org.apache.commons.math.util.MathUtils.distance1(intArray22, intArray23);
        int int25 = org.apache.commons.math.util.MathUtils.distance1(intArray20, intArray23);
        int[] intArray26 = new int[] {};
        int[] intArray27 = new int[] {};
        int int28 = org.apache.commons.math.util.MathUtils.distance1(intArray26, intArray27);
        double double29 = org.apache.commons.math.util.MathUtils.distance(intArray20, intArray26);
        int int30 = org.apache.commons.math.util.MathUtils.distance1(intArray14, intArray20);
        int[] intArray31 = new int[] {};
        int[] intArray32 = new int[] {};
        int int33 = org.apache.commons.math.util.MathUtils.distance1(intArray31, intArray32);
        int[] intArray34 = new int[] {};
        int[] intArray35 = new int[] {};
        int int36 = org.apache.commons.math.util.MathUtils.distance1(intArray34, intArray35);
        int int37 = org.apache.commons.math.util.MathUtils.distance1(intArray32, intArray35);
        int[] intArray38 = new int[] {};
        int[] intArray39 = new int[] {};
        int int40 = org.apache.commons.math.util.MathUtils.distance1(intArray38, intArray39);
        int int41 = org.apache.commons.math.util.MathUtils.distance1(intArray35, intArray38);
        double double42 = org.apache.commons.math.util.MathUtils.distance(intArray20, intArray35);
        int[] intArray43 = new int[] {};
        int[] intArray44 = new int[] {};
        int int45 = org.apache.commons.math.util.MathUtils.distance1(intArray43, intArray44);
        int[] intArray46 = new int[] {};
        int[] intArray47 = new int[] {};
        int int48 = org.apache.commons.math.util.MathUtils.distance1(intArray46, intArray47);
        int int49 = org.apache.commons.math.util.MathUtils.distance1(intArray44, intArray47);
        int[] intArray50 = new int[] {};
        int[] intArray51 = new int[] {};
        int int52 = org.apache.commons.math.util.MathUtils.distance1(intArray50, intArray51);
        int[] intArray53 = new int[] {};
        int[] intArray54 = new int[] {};
        int int55 = org.apache.commons.math.util.MathUtils.distance1(intArray53, intArray54);
        int int56 = org.apache.commons.math.util.MathUtils.distance1(intArray51, intArray54);
        int[] intArray57 = new int[] {};
        int[] intArray58 = new int[] {};
        int int59 = org.apache.commons.math.util.MathUtils.distance1(intArray57, intArray58);
        double double60 = org.apache.commons.math.util.MathUtils.distance(intArray51, intArray57);
        int int61 = org.apache.commons.math.util.MathUtils.distanceInf(intArray47, intArray57);
        int[] intArray62 = new int[] {};
        int[] intArray63 = new int[] {};
        int int64 = org.apache.commons.math.util.MathUtils.distance1(intArray62, intArray63);
        int[] intArray65 = new int[] {};
        int[] intArray66 = new int[] {};
        int int67 = org.apache.commons.math.util.MathUtils.distance1(intArray65, intArray66);
        int int68 = org.apache.commons.math.util.MathUtils.distance1(intArray63, intArray66);
        int int69 = org.apache.commons.math.util.MathUtils.distance1(intArray47, intArray63);
        int[] intArray70 = new int[] {};
        int[] intArray71 = new int[] {};
        int int72 = org.apache.commons.math.util.MathUtils.distance1(intArray70, intArray71);
        int[] intArray73 = new int[] {};
        int[] intArray74 = new int[] {};
        int int75 = org.apache.commons.math.util.MathUtils.distance1(intArray73, intArray74);
        int int76 = org.apache.commons.math.util.MathUtils.distance1(intArray71, intArray74);
        int[] intArray77 = new int[] {};
        int[] intArray78 = new int[] {};
        int int79 = org.apache.commons.math.util.MathUtils.distance1(intArray77, intArray78);
        int int80 = org.apache.commons.math.util.MathUtils.distance1(intArray74, intArray77);
        int int81 = org.apache.commons.math.util.MathUtils.distanceInf(intArray63, intArray74);
        int int82 = org.apache.commons.math.util.MathUtils.distance1(intArray20, intArray63);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertNotNull(intArray54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
        org.junit.Assert.assertNotNull(intArray62);
        org.junit.Assert.assertNotNull(intArray63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
        org.junit.Assert.assertNotNull(intArray65);
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 0 + "'", int67 == 0);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
        org.junit.Assert.assertNotNull(intArray70);
        org.junit.Assert.assertNotNull(intArray71);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 0 + "'", int72 == 0);
        org.junit.Assert.assertNotNull(intArray73);
        org.junit.Assert.assertNotNull(intArray74);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 0 + "'", int75 == 0);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 0 + "'", int76 == 0);
        org.junit.Assert.assertNotNull(intArray77);
        org.junit.Assert.assertNotNull(intArray78);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 0 + "'", int79 == 0);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 0 + "'", int80 == 0);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 0 + "'", int81 == 0);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 0 + "'", int82 == 0);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test443");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.8540775674112082d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6569142712614886d + "'", double1 == 0.6569142712614886d);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test444");
        double[] doubleArray6 = new double[] { (short) -1, (-1L), 1.0d, 100, '#', 'a' };
        double[] doubleArray10 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray10, (double) (short) -1);
        double[] doubleArray13 = null;
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equals(doubleArray10, doubleArray13);
        double[] doubleArray18 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray18, (double) (short) -1);
        double[] doubleArray24 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray26 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray24, (double) (short) -1);
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, (double) (-1L));
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray28);
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray13, doubleArray20);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection34 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException36 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-90L), (java.lang.Number) (-1), (int) (byte) 1, orderDirection34, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray20, orderDirection34, true);
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray20);
        double double40 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray20);
        double double41 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + orderDirection34 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection34.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.8540775674112082d + "'", double40 == 0.8540775674112082d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.8540775674112082d + "'", double41 == 0.8540775674112082d);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test445");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) 184331630, (double) 0L, (double) 15L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test446");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test447");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(2.3522044138766205d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.352204413876621d + "'", double1 == 2.352204413876621d);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test448");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) (-1869155406), (int) '4');
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test449");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow(0L, (-32L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test450");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 1074790313L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7384694543057034d + "'", double1 == 0.7384694543057034d);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test451");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.9797359324758174d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test452");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(1.3132616875182228d, 1391070465, (-738962753));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test453");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test454");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-90L), (java.lang.Number) (-1), (int) (byte) 1, orderDirection3, false);
        java.lang.Class<?> wildcardClass6 = nonMonotonousSequenceException5.getClass();
        int int7 = nonMonotonousSequenceException5.getIndex();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 1L, (int) (short) 10);
        java.lang.Class<?> wildcardClass12 = nonMonotonousSequenceException11.getClass();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        int int14 = nonMonotonousSequenceException11.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test455");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (short) 0, (int) (short) 0);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException7 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (short) 0, (int) (short) 0);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException7);
        java.lang.Throwable[] throwableArray9 = nonMonotonousSequenceException7.getSuppressed();
        boolean boolean10 = nonMonotonousSequenceException7.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = nonMonotonousSequenceException7.getDirection();
        int int12 = nonMonotonousSequenceException7.getIndex();
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + orderDirection11 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection11.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test456");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(3.174802103936399d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.1748021039363996d + "'", double1 == 3.1748021039363996d);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test457");
        long long2 = org.apache.commons.math.util.FastMath.min((-125687604222L), (-447362012L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-125687604222L) + "'", long2 == (-125687604222L));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test458");
        long long1 = org.apache.commons.math.util.MathUtils.sign(10L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test459");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (short) 0, (int) ' ');
        int int4 = nonMonotonousSequenceException3.getIndex();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (short) 0, (int) (short) 0);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (short) 0, (int) (short) 0);
        nonMonotonousSequenceException8.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException8);
        java.lang.String str15 = nonMonotonousSequenceException3.toString();
        java.lang.String str16 = nonMonotonousSequenceException3.toString();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 32 + "'", int4 == 32);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 31 and 32 are not strictly increasing (0 >= 0)" + "'", str15.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 31 and 32 are not strictly increasing (0 >= 0)"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 31 and 32 are not strictly increasing (0 >= 0)" + "'", str16.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 31 and 32 are not strictly increasing (0 >= 0)"));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test460");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((-0.7652143822983442d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test461");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((-0.9999999999999999d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test462");
        double double2 = org.apache.commons.math.util.MathUtils.log(0.0d, 3.7168146928204138d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.0d) + "'", double2 == (-0.0d));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test463");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) 1077936128);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test464");
        double[] doubleArray3 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) (short) -1);
        double[] doubleArray6 = null;
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray6);
        double[] doubleArray11 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray13 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, (double) (short) -1);
        double[] doubleArray17 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray17, (double) (short) -1);
        double[] doubleArray21 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, (double) (-1L));
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray13, doubleArray21);
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray13);
        int int24 = org.apache.commons.math.util.MathUtils.hash(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1249873867) + "'", int24 == (-1249873867));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test465");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-3802400L), (java.lang.Number) (-30.0d), 87);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test466");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(1.5549246438031066d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 89.09061955080085d + "'", double1 == 89.09061955080085d);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test467");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 1074790400, 1067568483147856818L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2L + "'", long2 == 2L);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test468");
        double double1 = org.apache.commons.math.util.FastMath.tanh(1.0000000000000047d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7615941559557667d + "'", double1 == 0.7615941559557667d);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test469");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(0.08002277859966438d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test470");
        double double2 = org.apache.commons.math.util.FastMath.atan2(53.0d, (double) 1.07952538E9f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.9095649975716696E-8d + "'", double2 == 4.9095649975716696E-8d);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test471");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.5581634595116061d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.44350785819144906d + "'", double1 == 0.44350785819144906d);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test472");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(0, 184331630);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 184331630 + "'", int2 == 184331630);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test473");
        long long1 = org.apache.commons.math.util.FastMath.round(1.145976303209723d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test474");
        double double2 = org.apache.commons.math.util.FastMath.min(3.1039830278823013d, (-0.013292325585375278d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.013292325585375278d) + "'", double2 == (-0.013292325585375278d));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test475");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test476");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 184331631);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 184331631L + "'", long1 == 184331631L);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test477");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 1L, (int) (short) 10);
        int int4 = nonMonotonousSequenceException3.getIndex();
        java.lang.Throwable[] throwableArray5 = nonMonotonousSequenceException3.getSuppressed();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test478");
        double[] doubleArray6 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) (short) -1);
        double[] doubleArray9 = null;
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray9);
        double[] doubleArray14 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray14, (double) (short) -1);
        double[] doubleArray20 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray20, (double) (short) -1);
        double[] doubleArray24 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray22, (double) (-1L));
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray16, doubleArray24);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray9, doubleArray16);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection30 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException32 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-90L), (java.lang.Number) (-1), (int) (byte) 1, orderDirection30, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray16, orderDirection30, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException36 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-626347007), (java.lang.Number) 63.0d, (-626350101), orderDirection30, false);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + orderDirection30 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection30.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test479");
        double[] doubleArray3 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) (short) -1);
        double[] doubleArray9 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, (double) (short) -1);
        double[] doubleArray13 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, (double) (-1L));
        double double14 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray13);
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray13, (double) (short) 100);
        double[] doubleArray23 = new double[] { (short) -1, (-1L), 1.0d, 100, '#', 'a' };
        double[] doubleArray27 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, (double) (short) -1);
        double[] doubleArray30 = null;
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equals(doubleArray27, doubleArray30);
        double[] doubleArray35 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray37 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray35, (double) (short) -1);
        double[] doubleArray41 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray43 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray41, (double) (short) -1);
        double[] doubleArray45 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray43, (double) (-1L));
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray37, doubleArray45);
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray30, doubleArray37);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection51 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException53 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-90L), (java.lang.Number) (-1), (int) (byte) 1, orderDirection51, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray37, orderDirection51, true);
        boolean boolean56 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray23, doubleArray37);
        boolean boolean57 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray16, doubleArray23);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException61 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (short) 0, (int) (short) 0);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException65 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (short) 0, (int) (short) 0);
        nonMonotonousSequenceException61.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException65);
        java.lang.Number number67 = nonMonotonousSequenceException65.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection68 = nonMonotonousSequenceException65.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection69 = nonMonotonousSequenceException65.getDirection();
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray23, orderDirection69, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (-1 >= -1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + orderDirection51 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection51.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + number67 + "' != '" + (short) 0 + "'", number67.equals((short) 0));
        org.junit.Assert.assertTrue("'" + orderDirection68 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection68.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection69 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection69.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test480");
        double double1 = org.apache.commons.math.util.FastMath.sin(1.5874010519681996d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9998621447184224d + "'", double1 == 0.9998621447184224d);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test481");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) (-626350101), 97, (-1869155406));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test482");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1074790400L), number1, 1077936128);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray4);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test483");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((int) (byte) 1, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test484");
        double double1 = org.apache.commons.math.util.FastMath.cosh(4.9095649975716696E-8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.000000000000001d + "'", double1 == 1.000000000000001d);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test485");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((-1249873867), (-447362012));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test486");
        long long1 = org.apache.commons.math.util.FastMath.abs((-90L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 90L + "'", long1 == 90L);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test487");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(8625328718985905607L, 3L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 8625328718985905607L + "'", long2 == 8625328718985905607L);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test488");
        double[] doubleArray3 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) (short) -1);
        double[] doubleArray9 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, (double) (short) -1);
        double[] doubleArray13 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, (double) (-1L));
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray13);
        double[] doubleArray18 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray18, (double) (short) -1);
        double[] doubleArray21 = null;
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equals(doubleArray18, doubleArray21);
        double[] doubleArray26 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, (double) (short) -1);
        double[] doubleArray32 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray32, (double) (short) -1);
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray34, (double) (-1L));
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray28, doubleArray36);
        double double38 = org.apache.commons.math.util.MathUtils.distance1(doubleArray18, doubleArray28);
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray18);
        double[] doubleArray43 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray45 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray43, (double) (short) -1);
        double[] doubleArray47 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray45, (double) (-1L));
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray45);
        double[] doubleArray52 = new double[] { (-35L), 1.3043045862358962d, '#' };
        double double53 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray52);
        double[] doubleArray57 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray59 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray57, (double) (short) -1);
        double[] doubleArray63 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray65 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray63, (double) (short) -1);
        double[] doubleArray67 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray65, (double) (-1L));
        boolean boolean68 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray59, doubleArray67);
        double[] doubleArray72 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray74 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray72, (double) (short) -1);
        double[] doubleArray75 = null;
        boolean boolean76 = org.apache.commons.math.util.MathUtils.equals(doubleArray72, doubleArray75);
        double[] doubleArray80 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray82 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray80, (double) (short) -1);
        double[] doubleArray86 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray88 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray86, (double) (short) -1);
        double[] doubleArray90 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray88, (double) (-1L));
        boolean boolean91 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray82, doubleArray90);
        double double92 = org.apache.commons.math.util.MathUtils.distance1(doubleArray72, doubleArray82);
        boolean boolean93 = org.apache.commons.math.util.MathUtils.equals(doubleArray59, doubleArray72);
        boolean boolean94 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray72);
        double[] doubleArray95 = null;
        try {
            double double96 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray72, doubleArray95);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 63.0d + "'", double38 == 63.0d);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 70.62688523139718d + "'", double53 == 70.62688523139718d);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertNotNull(doubleArray90);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + true + "'", boolean91 == true);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 63.0d + "'", double92 == 63.0d);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test489");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(223708937, (-1444685106));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test490");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((int) (short) 0, 11);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test491");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(5300, (-818408495));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test492");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 4);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 4.0f + "'", float1 == 4.0f);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test493");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 190, 4L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2L + "'", long2 == 2L);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test494");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(252.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.39822971502571d + "'", double1 == 4.39822971502571d);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test495");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((-4.47362012E8d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test496");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test497");
        float float3 = org.apache.commons.math.util.MathUtils.round((float) 4, 32, 1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 4.0f + "'", float3 == 4.0f);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test498");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 5300, (float) 43394118559L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 4.3394118E10f + "'", float2 == 4.3394118E10f);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test499");
        double[] doubleArray3 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) (short) -1);
        double[] doubleArray9 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, (double) (short) -1);
        double double12 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray9);
        double[] doubleArray16 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, (double) (short) -1);
        double[] doubleArray19 = null;
        boolean boolean20 = org.apache.commons.math.util.MathUtils.equals(doubleArray16, doubleArray19);
        double[] doubleArray24 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray26 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray24, (double) (short) -1);
        double[] doubleArray30 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray30, (double) (short) -1);
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray32, (double) (-1L));
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray26, doubleArray34);
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray26);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection40 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException42 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-90L), (java.lang.Number) (-1), (int) (byte) 1, orderDirection40, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray26, orderDirection40, true);
        boolean boolean45 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray26);
        double[] doubleArray49 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray51 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray49, (double) (short) -1);
        double[] doubleArray53 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray51, (double) (-1L));
        double double54 = org.apache.commons.math.util.MathUtils.distance1(doubleArray26, doubleArray51);
        double[] doubleArray55 = null;
        boolean boolean56 = org.apache.commons.math.util.MathUtils.equals(doubleArray26, doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 63.0d + "'", double12 == 63.0d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + orderDirection40 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection40.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test500");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 461100L, 3.141591832838774d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.141591832838774d + "'", double2 == 3.141591832838774d);
    }
}

