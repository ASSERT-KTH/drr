import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest3 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test001");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) (-1869155406), 32L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-59812972992L) + "'", long2 == (-59812972992L));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test002");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((-0.9999546000702375d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.017452500141688768d) + "'", double1 == (-0.017452500141688768d));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test003");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 291);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.3971446088951858E126d + "'", double1 == 2.3971446088951858E126d);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test004");
        long long2 = org.apache.commons.math.util.FastMath.min(0L, (-447362012L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-447362012L) + "'", long2 == (-447362012L));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test005");
        long long2 = org.apache.commons.math.util.FastMath.max(184331631L, (long) (-447362012));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 184331631L + "'", long2 == 184331631L);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test006");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(3103.9999999999995d, 5);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 99327.99999999999d + "'", double2 == 99327.99999999999d);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test007");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 1, (long) 184331631);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 184331631L + "'", long2 == 184331631L);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test008");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 62);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test009");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) (-1.0747904E9f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test010");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) (-1074790400L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9465229315007718d + "'", double1 == 0.9465229315007718d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test011");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-90L), (java.lang.Number) (-1), (int) (byte) 1, orderDirection3, false);
        java.lang.Class<?> wildcardClass6 = nonMonotonousSequenceException5.getClass();
        int int7 = nonMonotonousSequenceException5.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = nonMonotonousSequenceException5.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = nonMonotonousSequenceException5.getDirection();
        java.lang.Throwable[] throwableArray10 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.Number number11 = nonMonotonousSequenceException5.getArgument();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + orderDirection8 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection8.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + (-90L) + "'", number11.equals((-90L)));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test012");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.7724538509055159d, (java.lang.Number) (-626347007L), 970);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 1.7724538509055159d + "'", number4.equals(1.7724538509055159d));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test013");
        int int1 = org.apache.commons.math.util.MathUtils.hash(2.220446049250313E-16d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1018167296 + "'", int1 == 1018167296);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test014");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) 10);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test015");
        double double1 = org.apache.commons.math.util.FastMath.sinh(5.551115123125783E-17d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.551115123125783E-17d + "'", double1 == 5.551115123125783E-17d);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test016");
        float float2 = org.apache.commons.math.util.FastMath.max(1.44468506E9f, (float) 87L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 87.0f + "'", float2 == 87.0f);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test017");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 190L, (java.lang.Number) 9.332621544395286E157d, (int) (byte) 100, orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getPrevious();
        java.lang.Number number7 = nonMonotonousSequenceException5.getArgument();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 9.332621544395286E157d + "'", number6.equals(9.332621544395286E157d));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 190L + "'", number7.equals(190L));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test018");
        double double2 = org.apache.commons.math.util.FastMath.atan2(8.540775674112082d, 2.2755538259844106d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.3104110800815563d + "'", double2 == 1.3104110800815563d);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test019");
        int int1 = org.apache.commons.math.util.MathUtils.hash(3.343553526573095d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1111307499) + "'", int1 == (-1111307499));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test020");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((-1043332096), 0);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test021");
        double[] doubleArray3 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) (short) -1);
        double[] doubleArray9 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, (double) (short) -1);
        double[] doubleArray13 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, (double) (-1L));
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray13);
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray13, 10.0d);
        double[] doubleArray20 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray20, (double) (short) -1);
        double[] doubleArray26 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, (double) (short) -1);
        double[] doubleArray30 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray28, (double) (-1L));
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray22, doubleArray30);
        double[] doubleArray35 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray37 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray35, (double) (short) -1);
        double[] doubleArray38 = null;
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equals(doubleArray35, doubleArray38);
        double[] doubleArray43 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray45 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray43, (double) (short) -1);
        double[] doubleArray49 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray51 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray49, (double) (short) -1);
        double[] doubleArray53 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray51, (double) (-1L));
        boolean boolean54 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray45, doubleArray53);
        double double55 = org.apache.commons.math.util.MathUtils.distance1(doubleArray35, doubleArray45);
        boolean boolean56 = org.apache.commons.math.util.MathUtils.equals(doubleArray22, doubleArray35);
        double[] doubleArray60 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray62 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray60, (double) (short) -1);
        double[] doubleArray64 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray62, (double) (-1L));
        boolean boolean65 = org.apache.commons.math.util.MathUtils.equals(doubleArray22, doubleArray62);
        double[] doubleArray69 = new double[] { (-35L), 1.3043045862358962d, '#' };
        double double70 = org.apache.commons.math.util.MathUtils.distance1(doubleArray22, doubleArray69);
        boolean boolean71 = org.apache.commons.math.util.MathUtils.equals(doubleArray16, doubleArray22);
        int int72 = org.apache.commons.math.util.MathUtils.hash(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 63.0d + "'", double55 == 63.0d);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 70.62688523139718d + "'", double70 == 70.62688523139718d);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + (-1249873867) + "'", int72 == (-1249873867));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test022");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) (-10), 800L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-8000L) + "'", long2 == (-8000L));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test023");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.6363935896729996d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6363935896729996d + "'", double1 == 0.6363935896729996d);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test024");
        long long1 = org.apache.commons.math.util.MathUtils.sign(252L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test025");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) 1000L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test026");
        double double1 = org.apache.commons.math.util.FastMath.ulp((-1.9224036063638743d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test027");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 38833706262L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 24.382554424551248d + "'", double1 == 24.382554424551248d);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test028");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-144468510600L), (-626350111L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test029");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 800L, 92.13617560368711d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 799.9999999999999d + "'", double2 == 799.9999999999999d);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test030");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (short) 0, (int) ' ');
        int int4 = nonMonotonousSequenceException3.getIndex();
        java.lang.Class<?> wildcardClass5 = nonMonotonousSequenceException3.getClass();
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException3.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException3.getDirection();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 32 + "'", int4 == 32);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test031");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) 728967041, (long) (-738962753));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test032");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(3101, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test033");
        int[] intArray0 = new int[] {};
        int[] intArray1 = new int[] {};
        int int2 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray1);
        int[] intArray3 = new int[] {};
        int[] intArray4 = new int[] {};
        int int5 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray4);
        int int6 = org.apache.commons.math.util.MathUtils.distance1(intArray1, intArray4);
        int[] intArray7 = new int[] {};
        int[] intArray8 = new int[] {};
        int int9 = org.apache.commons.math.util.MathUtils.distance1(intArray7, intArray8);
        int[] intArray10 = new int[] {};
        int[] intArray11 = new int[] {};
        int int12 = org.apache.commons.math.util.MathUtils.distance1(intArray10, intArray11);
        int int13 = org.apache.commons.math.util.MathUtils.distance1(intArray8, intArray11);
        int[] intArray14 = new int[] {};
        int[] intArray15 = new int[] {};
        int int16 = org.apache.commons.math.util.MathUtils.distance1(intArray14, intArray15);
        double double17 = org.apache.commons.math.util.MathUtils.distance(intArray8, intArray14);
        int int18 = org.apache.commons.math.util.MathUtils.distanceInf(intArray4, intArray14);
        int[] intArray19 = new int[] {};
        int[] intArray20 = new int[] {};
        int int21 = org.apache.commons.math.util.MathUtils.distance1(intArray19, intArray20);
        int[] intArray22 = new int[] {};
        int[] intArray23 = new int[] {};
        int int24 = org.apache.commons.math.util.MathUtils.distance1(intArray22, intArray23);
        int int25 = org.apache.commons.math.util.MathUtils.distance1(intArray20, intArray23);
        int[] intArray26 = new int[] {};
        int[] intArray27 = new int[] {};
        int int28 = org.apache.commons.math.util.MathUtils.distance1(intArray26, intArray27);
        double double29 = org.apache.commons.math.util.MathUtils.distance(intArray20, intArray26);
        int int30 = org.apache.commons.math.util.MathUtils.distance1(intArray14, intArray20);
        int[] intArray31 = new int[] {};
        int[] intArray32 = new int[] {};
        int int33 = org.apache.commons.math.util.MathUtils.distance1(intArray31, intArray32);
        int[] intArray34 = new int[] {};
        int[] intArray35 = new int[] {};
        int int36 = org.apache.commons.math.util.MathUtils.distance1(intArray34, intArray35);
        int int37 = org.apache.commons.math.util.MathUtils.distance1(intArray32, intArray35);
        int[] intArray38 = new int[] {};
        int[] intArray39 = new int[] {};
        int int40 = org.apache.commons.math.util.MathUtils.distance1(intArray38, intArray39);
        int int41 = org.apache.commons.math.util.MathUtils.distance1(intArray35, intArray38);
        double double42 = org.apache.commons.math.util.MathUtils.distance(intArray20, intArray35);
        int[] intArray43 = new int[] {};
        int[] intArray44 = new int[] {};
        int int45 = org.apache.commons.math.util.MathUtils.distance1(intArray43, intArray44);
        int[] intArray46 = new int[] {};
        int[] intArray47 = new int[] {};
        int int48 = org.apache.commons.math.util.MathUtils.distance1(intArray46, intArray47);
        int int49 = org.apache.commons.math.util.MathUtils.distance1(intArray44, intArray47);
        int[] intArray50 = new int[] {};
        int[] intArray51 = new int[] {};
        int int52 = org.apache.commons.math.util.MathUtils.distance1(intArray50, intArray51);
        int[] intArray53 = new int[] {};
        int[] intArray54 = new int[] {};
        int int55 = org.apache.commons.math.util.MathUtils.distance1(intArray53, intArray54);
        int int56 = org.apache.commons.math.util.MathUtils.distance1(intArray51, intArray54);
        int[] intArray57 = new int[] {};
        int[] intArray58 = new int[] {};
        int int59 = org.apache.commons.math.util.MathUtils.distance1(intArray57, intArray58);
        int int60 = org.apache.commons.math.util.MathUtils.distance1(intArray54, intArray57);
        double double61 = org.apache.commons.math.util.MathUtils.distance(intArray47, intArray57);
        int int62 = org.apache.commons.math.util.MathUtils.distance1(intArray35, intArray57);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertNotNull(intArray54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test034");
        float float2 = org.apache.commons.math.util.FastMath.min((-58.0f), (float) 1018167296);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-58.0f) + "'", float2 == (-58.0f));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test035");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.1622776601683795d + "'", double1 == 3.1622776601683795d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test036");
        double[] doubleArray3 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) (short) -1);
        double[] doubleArray9 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, (double) (short) -1);
        double[] doubleArray13 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, (double) (-1L));
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray13);
        double[] doubleArray18 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray18, (double) (short) -1);
        double[] doubleArray21 = null;
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equals(doubleArray18, doubleArray21);
        double[] doubleArray26 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, (double) (short) -1);
        double[] doubleArray32 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray32, (double) (short) -1);
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray34, (double) (-1L));
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray28, doubleArray36);
        double double38 = org.apache.commons.math.util.MathUtils.distance1(doubleArray18, doubleArray28);
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray18);
        double[] doubleArray43 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray45 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray43, (double) (short) -1);
        double[] doubleArray47 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray45, (double) (-1L));
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray45);
        double[] doubleArray52 = new double[] { (-35L), 1.3043045862358962d, '#' };
        double double53 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray52);
        double[] doubleArray57 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray59 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray57, (double) (short) -1);
        double[] doubleArray63 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray65 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray63, (double) (short) -1);
        double[] doubleArray67 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray65, (double) (-1L));
        boolean boolean68 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray59, doubleArray67);
        double[] doubleArray72 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray74 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray72, (double) (short) -1);
        double[] doubleArray75 = null;
        boolean boolean76 = org.apache.commons.math.util.MathUtils.equals(doubleArray72, doubleArray75);
        double[] doubleArray80 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray82 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray80, (double) (short) -1);
        double[] doubleArray86 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray88 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray86, (double) (short) -1);
        double[] doubleArray90 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray88, (double) (-1L));
        boolean boolean91 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray82, doubleArray90);
        double double92 = org.apache.commons.math.util.MathUtils.distance1(doubleArray72, doubleArray82);
        boolean boolean93 = org.apache.commons.math.util.MathUtils.equals(doubleArray59, doubleArray72);
        boolean boolean94 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray72);
        java.lang.Class<?> wildcardClass95 = doubleArray72.getClass();
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray72);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (52 >= 10)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 63.0d + "'", double38 == 63.0d);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 70.62688523139718d + "'", double53 == 70.62688523139718d);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertNotNull(doubleArray90);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + true + "'", boolean91 == true);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 63.0d + "'", double92 == 63.0d);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
        org.junit.Assert.assertNotNull(wildcardClass95);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test037");
        long long1 = org.apache.commons.math.util.FastMath.abs(87L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 87L + "'", long1 == 87L);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test038");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) (-738962718L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test039");
        double[] doubleArray3 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) (short) -1);
        double[] doubleArray6 = null;
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray6);
        double[] doubleArray11 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray13 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, (double) (short) -1);
        double[] doubleArray17 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray17, (double) (short) -1);
        double[] doubleArray21 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, (double) (-1L));
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray13, doubleArray21);
        double double23 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray13);
        int int24 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        java.lang.Class<?> wildcardClass25 = doubleArray3.getClass();
        double[] doubleArray27 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) 1);
        int int28 = org.apache.commons.math.util.MathUtils.hash(doubleArray27);
        double[] doubleArray35 = new double[] { (short) -1, (-1L), 1.0d, 100, '#', 'a' };
        double[] doubleArray39 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray41 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray39, (double) (short) -1);
        double[] doubleArray42 = null;
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equals(doubleArray39, doubleArray42);
        double[] doubleArray47 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray49 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray47, (double) (short) -1);
        double[] doubleArray53 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray55 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray53, (double) (short) -1);
        double[] doubleArray57 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray55, (double) (-1L));
        boolean boolean58 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray49, doubleArray57);
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray42, doubleArray49);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection63 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException65 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-90L), (java.lang.Number) (-1), (int) (byte) 1, orderDirection63, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray49, orderDirection63, true);
        boolean boolean68 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray35, doubleArray49);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray49);
        int int70 = org.apache.commons.math.util.MathUtils.hash(doubleArray49);
        double double71 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray49);
        boolean boolean72 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray27, doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 63.0d + "'", double23 == 63.0d);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 438727775 + "'", int24 == 438727775);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 897609781 + "'", int28 == 897609781);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + orderDirection63 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection63.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + (-1249873867) + "'", int70 == (-1249873867));
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.8540775674112082d + "'", double71 == 0.8540775674112082d);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test040");
        long long1 = org.apache.commons.math.util.MathUtils.sign(1L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test041");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (short) 0, (int) ' ');
        int int4 = nonMonotonousSequenceException3.getIndex();
        boolean boolean5 = nonMonotonousSequenceException3.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-90L), (java.lang.Number) (-1), (int) (byte) 1, orderDirection9, false);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = nonMonotonousSequenceException11.getDirection();
        java.lang.Number number14 = nonMonotonousSequenceException11.getArgument();
        java.lang.String str15 = nonMonotonousSequenceException11.toString();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 32 + "'", int4 == 32);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection13 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection13.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + (-90L) + "'", number14.equals((-90L)));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > -90)" + "'", str15.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > -90)"));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test042");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(20.59253685675062d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3594075694885822d + "'", double1 == 0.3594075694885822d);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test043");
        float float2 = org.apache.commons.math.util.MathUtils.round(100.0f, (-1249873867));
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test044");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (short) 0, (int) ' ');
        int int4 = nonMonotonousSequenceException3.getIndex();
        boolean boolean5 = nonMonotonousSequenceException3.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-90L), (java.lang.Number) (-1), (int) (byte) 1, orderDirection9, false);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = nonMonotonousSequenceException11.getDirection();
        java.lang.Number number14 = nonMonotonousSequenceException11.getArgument();
        java.lang.Number number15 = nonMonotonousSequenceException11.getArgument();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 32 + "'", int4 == 32);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection13 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection13.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + (-90L) + "'", number14.equals((-90L)));
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + (-90L) + "'", number15.equals((-90L)));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test045");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) (-738962718L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1321600470 + "'", int1 == 1321600470);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test046");
        double double1 = org.apache.commons.math.util.FastMath.sin(24.382554424551248d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6817754306591001d) + "'", double1 == (-0.6817754306591001d));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test047");
        double[] doubleArray3 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) (short) -1);
        double[] doubleArray9 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, (double) (short) -1);
        double[] doubleArray15 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) (short) -1);
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray17, (double) (-1L));
        boolean boolean20 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray11, doubleArray19);
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, 10.0d);
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray19);
        double[] doubleArray27 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, (double) (short) -1);
        double[] doubleArray33 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray35 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray33, (double) (short) -1);
        double double36 = org.apache.commons.math.util.MathUtils.distance1(doubleArray29, doubleArray33);
        double[] doubleArray40 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray42 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray40, (double) (short) -1);
        double[] doubleArray43 = null;
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equals(doubleArray40, doubleArray43);
        double[] doubleArray48 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray50 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray48, (double) (short) -1);
        double[] doubleArray54 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray56 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray54, (double) (short) -1);
        double[] doubleArray58 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray56, (double) (-1L));
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray50, doubleArray58);
        boolean boolean60 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray43, doubleArray50);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection64 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException66 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-90L), (java.lang.Number) (-1), (int) (byte) 1, orderDirection64, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray50, orderDirection64, true);
        boolean boolean69 = org.apache.commons.math.util.MathUtils.equals(doubleArray29, doubleArray50);
        double[] doubleArray73 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray75 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray73, (double) (short) -1);
        double[] doubleArray79 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray81 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray79, (double) (short) -1);
        double[] doubleArray83 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray81, (double) (-1L));
        double double84 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray75, doubleArray83);
        double[] doubleArray86 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray83, (double) (short) 100);
        boolean boolean87 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray29, doubleArray83);
        double double88 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray83);
        boolean boolean89 = org.apache.commons.math.util.MathUtils.equals(doubleArray19, doubleArray83);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 63.0d + "'", double36 == 63.0d);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + orderDirection64 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection64.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 0.0d + "'", double84 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 0.8540775674112082d + "'", double88 == 0.8540775674112082d);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + true + "'", boolean89 == true);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test048");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (-144468510600L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.44468509E11f + "'", float1 == 1.44468509E11f);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test049");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.0E300d, 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test050");
        double double1 = org.apache.commons.math.util.FastMath.rint(60.95176076419315d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 61.0d + "'", double1 == 61.0d);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test051");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(1067568483147856818L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test052");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) 190, (long) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1900L + "'", long2 == 1900L);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test053");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 461100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test054");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(0L, 4L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test055");
        double double1 = org.apache.commons.math.util.FastMath.tanh(6.2634706E8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test056");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(24.382554424551248d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9416853130999966E10d + "'", double1 == 1.9416853130999966E10d);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test057");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(1.5518730669348417d, 1.5430806348152437d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5518730669348417d + "'", double2 == 1.5518730669348417d);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test058");
        int[] intArray0 = new int[] {};
        int[] intArray1 = new int[] {};
        int int2 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray1);
        int[] intArray3 = new int[] {};
        int[] intArray4 = new int[] {};
        int int5 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray4);
        int[] intArray6 = new int[] {};
        int[] intArray7 = new int[] {};
        int int8 = org.apache.commons.math.util.MathUtils.distance1(intArray6, intArray7);
        int int9 = org.apache.commons.math.util.MathUtils.distance1(intArray4, intArray7);
        int int10 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray7);
        int[] intArray11 = new int[] {};
        int[] intArray12 = new int[] {};
        int int13 = org.apache.commons.math.util.MathUtils.distance1(intArray11, intArray12);
        int[] intArray14 = new int[] {};
        int[] intArray15 = new int[] {};
        int int16 = org.apache.commons.math.util.MathUtils.distance1(intArray14, intArray15);
        int int17 = org.apache.commons.math.util.MathUtils.distance1(intArray12, intArray15);
        int[] intArray18 = new int[] {};
        int[] intArray19 = new int[] {};
        int int20 = org.apache.commons.math.util.MathUtils.distance1(intArray18, intArray19);
        int[] intArray21 = new int[] {};
        int[] intArray22 = new int[] {};
        int int23 = org.apache.commons.math.util.MathUtils.distance1(intArray21, intArray22);
        int int24 = org.apache.commons.math.util.MathUtils.distance1(intArray19, intArray22);
        int[] intArray25 = new int[] {};
        int[] intArray26 = new int[] {};
        int int27 = org.apache.commons.math.util.MathUtils.distance1(intArray25, intArray26);
        int int28 = org.apache.commons.math.util.MathUtils.distance1(intArray22, intArray25);
        double double29 = org.apache.commons.math.util.MathUtils.distance(intArray15, intArray25);
        int[] intArray30 = new int[] {};
        int[] intArray31 = new int[] {};
        int int32 = org.apache.commons.math.util.MathUtils.distance1(intArray30, intArray31);
        int[] intArray33 = new int[] {};
        int[] intArray34 = new int[] {};
        int int35 = org.apache.commons.math.util.MathUtils.distance1(intArray33, intArray34);
        int int36 = org.apache.commons.math.util.MathUtils.distance1(intArray31, intArray34);
        int[] intArray37 = new int[] {};
        int[] intArray38 = new int[] {};
        int int39 = org.apache.commons.math.util.MathUtils.distance1(intArray37, intArray38);
        int int40 = org.apache.commons.math.util.MathUtils.distance1(intArray34, intArray37);
        double double41 = org.apache.commons.math.util.MathUtils.distance(intArray15, intArray37);
        double double42 = org.apache.commons.math.util.MathUtils.distance(intArray7, intArray15);
        int[] intArray43 = new int[] {};
        int[] intArray44 = new int[] {};
        int int45 = org.apache.commons.math.util.MathUtils.distance1(intArray43, intArray44);
        int[] intArray46 = new int[] {};
        int[] intArray47 = new int[] {};
        int int48 = org.apache.commons.math.util.MathUtils.distance1(intArray46, intArray47);
        int int49 = org.apache.commons.math.util.MathUtils.distance1(intArray44, intArray47);
        int[] intArray50 = new int[] {};
        int[] intArray51 = new int[] {};
        int int52 = org.apache.commons.math.util.MathUtils.distance1(intArray50, intArray51);
        int int53 = org.apache.commons.math.util.MathUtils.distance1(intArray47, intArray50);
        double double54 = org.apache.commons.math.util.MathUtils.distance(intArray15, intArray47);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test059");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) (-3));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test060");
        double double1 = org.apache.commons.math.util.FastMath.ulp(1.7618124269860005d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test061");
        double double1 = org.apache.commons.math.util.MathUtils.sign((-0.9463876021584277d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test062");
        double[] doubleArray3 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) (short) -1);
        double[] doubleArray6 = null;
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray6);
        double[] doubleArray11 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray13 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, (double) (short) -1);
        double[] doubleArray17 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray17, (double) (short) -1);
        double[] doubleArray21 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, (double) (-1L));
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray13, doubleArray21);
        double double23 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray13);
        double[] doubleArray27 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, (double) (short) -1);
        double[] doubleArray30 = null;
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equals(doubleArray27, doubleArray30);
        double[] doubleArray35 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray37 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray35, (double) (short) -1);
        double[] doubleArray41 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray43 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray41, (double) (short) -1);
        double[] doubleArray45 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray43, (double) (-1L));
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray37, doubleArray45);
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray30, doubleArray37);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection51 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException53 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-90L), (java.lang.Number) (-1), (int) (byte) 1, orderDirection51, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray37, orderDirection51, true);
        double double56 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray37);
        double[] doubleArray60 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray62 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray60, (double) (short) -1);
        double[] doubleArray63 = null;
        boolean boolean64 = org.apache.commons.math.util.MathUtils.equals(doubleArray60, doubleArray63);
        double[] doubleArray68 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray70 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray68, (double) (short) -1);
        double[] doubleArray74 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray76 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray74, (double) (short) -1);
        double[] doubleArray78 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray76, (double) (-1L));
        boolean boolean79 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray70, doubleArray78);
        boolean boolean80 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray63, doubleArray70);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection84 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException86 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-90L), (java.lang.Number) (-1), (int) (byte) 1, orderDirection84, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray70, orderDirection84, true);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray3, orderDirection84, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not increasing (52 > 10)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 63.0d + "'", double23 == 63.0d);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + orderDirection51 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection51.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 52.83870967741935d + "'", double56 == 52.83870967741935d);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + true + "'", boolean79 == true);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertTrue("'" + orderDirection84 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection84.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test063");
        double double1 = org.apache.commons.math.util.FastMath.cos(1.7182818284590453d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.14695139943744212d) + "'", double1 == (-0.14695139943744212d));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test064");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 2455225485L, (float) (-626350014L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-6.2635002E8f) + "'", float2 == (-6.2635002E8f));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test065");
        int int1 = org.apache.commons.math.util.MathUtils.sign((-738962753));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test066");
        int int1 = org.apache.commons.math.util.MathUtils.hash(1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1072693249 + "'", int1 == 1072693249);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test067");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 1079525376, 438727775L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test068");
        double[] doubleArray3 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) (short) -1);
        double[] doubleArray7 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray5, (double) (-1L));
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray5);
        double[] doubleArray10 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray5, 2.6881171418161356E43d);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = null;
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray10, orderDirection11, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1249873867) + "'", int8 == (-1249873867));
        org.junit.Assert.assertNotNull(doubleArray10);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test069");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 1249873868L, (double) 1018167296);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test070");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) 10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test071");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) (-1.44468506E9f));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test072");
        double double1 = org.apache.commons.math.util.FastMath.asinh(1.7182818284590453d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3100528160534919d + "'", double1 == 1.3100528160534919d);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test073");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, 1.7618124269860005d, 32);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test074");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(728967041);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test075");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) '4', 1074790400L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test076");
        double[] doubleArray3 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) (short) -1);
        double[] doubleArray9 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, (double) (short) -1);
        double[] doubleArray13 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, (double) (-1L));
        double double14 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray13);
        double[] doubleArray18 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray18, (double) (short) -1);
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray20, (double) (-1L));
        double double23 = org.apache.commons.math.util.MathUtils.distance1(doubleArray13, doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test077");
        java.lang.Number number1 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-90L), (java.lang.Number) (-1), (int) (byte) 1, orderDirection6, false);
        java.lang.Class<?> wildcardClass9 = nonMonotonousSequenceException8.getClass();
        int int10 = nonMonotonousSequenceException8.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = nonMonotonousSequenceException8.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 8.540775674112082d, number1, (-1074790400), orderDirection11, true);
        int int14 = nonMonotonousSequenceException13.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + orderDirection11 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection11.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1074790400) + "'", int14 == (-1074790400));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test078");
        int int1 = org.apache.commons.math.util.MathUtils.hash(75.45612929021688d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2025509786 + "'", int1 == 2025509786);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test079");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(5L, (long) 52);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-47L) + "'", long2 == (-47L));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test080");
        java.lang.Number number1 = null;
        double[] doubleArray12 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray14 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, (double) (short) -1);
        double[] doubleArray15 = null;
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray15);
        double[] doubleArray20 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray20, (double) (short) -1);
        double[] doubleArray26 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, (double) (short) -1);
        double[] doubleArray30 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray28, (double) (-1L));
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray22, doubleArray30);
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray15, doubleArray22);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection36 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException38 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-90L), (java.lang.Number) (-1), (int) (byte) 1, orderDirection36, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray22, orderDirection36, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException42 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 1, (java.lang.Number) 0.022985251411478155d, 1, orderDirection36, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException44 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.1270142631252122d, (java.lang.Number) 260, 87, orderDirection36, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException46 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-190.0d), number1, (int) (byte) -1, orderDirection36, true);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + orderDirection36 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection36.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test081");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(1077936128, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1077936128 + "'", int2 == 1077936128);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test082");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((-0.017452500141688768d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-3.0460359017724586E-4d) + "'", double1 == (-3.0460359017724586E-4d));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test083");
        double[] doubleArray6 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) (short) -1);
        double[] doubleArray9 = null;
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray9);
        double[] doubleArray14 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray14, (double) (short) -1);
        double[] doubleArray20 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray20, (double) (short) -1);
        double[] doubleArray24 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray22, (double) (-1L));
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray16, doubleArray24);
        double double26 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray16);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray16);
        double[] doubleArray31 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray33 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray31, (double) (short) -1);
        double[] doubleArray37 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray39 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray37, (double) (short) -1);
        double[] doubleArray43 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray45 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray43, (double) (short) -1);
        double[] doubleArray47 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray45, (double) (-1L));
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray39, doubleArray47);
        double[] doubleArray50 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray47, 10.0d);
        boolean boolean51 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray33, doubleArray47);
        double double52 = org.apache.commons.math.util.MathUtils.distance1(doubleArray16, doubleArray33);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException56 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (short) 0, (int) ' ');
        int int57 = nonMonotonousSequenceException56.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection58 = nonMonotonousSequenceException56.getDirection();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray16, orderDirection58, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException62 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1), (java.lang.Number) 14.154262241479262d, 3, orderDirection58, false);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 63.0d + "'", double26 == 63.0d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 32 + "'", int57 == 32);
        org.junit.Assert.assertTrue("'" + orderDirection58 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection58.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test084");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 447362012, (float) 12600L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 12600.0f + "'", float2 == 12600.0f);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test085");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((-447362012L), 1067568483147856818L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2L + "'", long2 == 2L);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test086");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) 184331630);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test087");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 291, (long) 35);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-5290572617528898053L) + "'", long2 == (-5290572617528898053L));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test088");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 87.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 87.00000000000001d + "'", double1 == 87.00000000000001d);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test089");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(223708937, 1321600470);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test090");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((-0.4480736161291702d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test091");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow(0, (long) (-626347007));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test092");
        int int1 = org.apache.commons.math.util.MathUtils.hash(24.382554424551248d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1443758766 + "'", int1 == 1443758766);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test093");
        double double2 = org.apache.commons.math.util.FastMath.max((double) (-1), 0.6931471805599453d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.6931471805599453d + "'", double2 == 0.6931471805599453d);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test094");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test095");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 1018167296);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test096");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) 2025509786, 1249873868L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2531631750899672248L + "'", long2 == 2531631750899672248L);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test097");
        double[] doubleArray3 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) (short) -1);
        double[] doubleArray9 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, (double) (short) -1);
        double[] doubleArray13 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, (double) (-1L));
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray13);
        double[] doubleArray18 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray18, (double) (short) -1);
        double[] doubleArray21 = null;
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equals(doubleArray18, doubleArray21);
        double[] doubleArray26 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, (double) (short) -1);
        double[] doubleArray32 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray32, (double) (short) -1);
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray34, (double) (-1L));
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray28, doubleArray36);
        double double38 = org.apache.commons.math.util.MathUtils.distance1(doubleArray18, doubleArray28);
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray18);
        double[] doubleArray43 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray45 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray43, (double) (short) -1);
        double[] doubleArray47 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray45, (double) (-1L));
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray45);
        double[] doubleArray52 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray54 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray52, (double) (short) -1);
        double[] doubleArray58 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray60 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray58, (double) (short) -1);
        double[] doubleArray62 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray60, (double) (-1L));
        double double63 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray54, doubleArray62);
        double double64 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray45, doubleArray54);
        double[] doubleArray68 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray70 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray68, (double) (short) -1);
        double[] doubleArray71 = null;
        boolean boolean72 = org.apache.commons.math.util.MathUtils.equals(doubleArray68, doubleArray71);
        double[] doubleArray76 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray78 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray76, (double) (short) -1);
        double[] doubleArray82 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray84 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray82, (double) (short) -1);
        double[] doubleArray86 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray84, (double) (-1L));
        boolean boolean87 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray78, doubleArray86);
        double double88 = org.apache.commons.math.util.MathUtils.distance1(doubleArray68, doubleArray78);
        double double89 = org.apache.commons.math.util.MathUtils.distance1(doubleArray45, doubleArray78);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 63.0d + "'", double38 == 63.0d);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 63.0d + "'", double88 == 63.0d);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 0.0d + "'", double89 == 0.0d);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test098");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 2455225485L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 21.621484441632997d + "'", double1 == 21.621484441632997d);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test099");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (-1074790400L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0747904E9f + "'", float1 == 1.0747904E9f);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test100");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) (short) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9999999999999999d) + "'", double1 == (-0.9999999999999999d));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test101");
        double double1 = org.apache.commons.math.util.FastMath.acos((-0.4868981666828701d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.079331342726188d + "'", double1 == 2.079331342726188d);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test102");
        double double1 = org.apache.commons.math.util.MathUtils.sign(0.3968502629920499d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test103");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(3103.9999999999995d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 177846.0996086075d + "'", double1 == 177846.0996086075d);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test104");
        double double1 = org.apache.commons.math.util.FastMath.signum(21.621484441632997d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test105");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(2025509786);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test106");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 4);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3862943611198906d + "'", double1 == 1.3862943611198906d);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test107");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((-0.7615941559557649d), (double) 100.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 99.76937075891762d + "'", double2 == 99.76937075891762d);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test108");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 252L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 252 + "'", int1 == 252);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test109");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) (-35L), (double) 1072693249);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.NEGATIVE_INFINITY + "'", double2 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test110");
        double[] doubleArray3 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) (short) -1);
        double[] doubleArray9 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, (double) (short) -1);
        double double12 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray9);
        double[] doubleArray16 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, (double) (short) -1);
        double[] doubleArray19 = null;
        boolean boolean20 = org.apache.commons.math.util.MathUtils.equals(doubleArray16, doubleArray19);
        double[] doubleArray24 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray26 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray24, (double) (short) -1);
        double[] doubleArray30 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray30, (double) (short) -1);
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray32, (double) (-1L));
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray26, doubleArray34);
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray26);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection40 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException42 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-90L), (java.lang.Number) (-1), (int) (byte) 1, orderDirection40, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray26, orderDirection40, true);
        boolean boolean45 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray26);
        double double46 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray26);
        double double47 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 63.0d + "'", double12 == 63.0d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + orderDirection40 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection40.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.8540775674112082d + "'", double46 == 0.8540775674112082d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.8540775674112082d + "'", double47 == 0.8540775674112082d);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test111");
        double[] doubleArray6 = new double[] { (short) -1, (-1L), 1.0d, 100, '#', 'a' };
        double[] doubleArray10 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray10, (double) (short) -1);
        double[] doubleArray13 = null;
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equals(doubleArray10, doubleArray13);
        double[] doubleArray18 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray18, (double) (short) -1);
        double[] doubleArray24 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray26 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray24, (double) (short) -1);
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, (double) (-1L));
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray28);
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray13, doubleArray20);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection34 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException36 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-90L), (java.lang.Number) (-1), (int) (byte) 1, orderDirection34, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray20, orderDirection34, true);
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray20);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray20);
        double[] doubleArray42 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray20, (double) 1.0f);
        double[] doubleArray46 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray48 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray46, (double) (short) -1);
        double[] doubleArray52 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray54 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray52, (double) (short) -1);
        double double55 = org.apache.commons.math.util.MathUtils.distance1(doubleArray48, doubleArray52);
        double[] doubleArray59 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray61 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray59, (double) (short) -1);
        double[] doubleArray62 = null;
        boolean boolean63 = org.apache.commons.math.util.MathUtils.equals(doubleArray59, doubleArray62);
        double[] doubleArray67 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray69 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray67, (double) (short) -1);
        double[] doubleArray73 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray75 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray73, (double) (short) -1);
        double[] doubleArray77 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray75, (double) (-1L));
        boolean boolean78 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray69, doubleArray77);
        boolean boolean79 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray62, doubleArray69);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection83 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException85 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-90L), (java.lang.Number) (-1), (int) (byte) 1, orderDirection83, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray69, orderDirection83, true);
        boolean boolean88 = org.apache.commons.math.util.MathUtils.equals(doubleArray48, doubleArray69);
        double double89 = org.apache.commons.math.util.MathUtils.distance1(doubleArray20, doubleArray69);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray20);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + orderDirection34 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection34.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 63.0d + "'", double55 == 63.0d);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertTrue("'" + orderDirection83 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection83.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + true + "'", boolean88 == true);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 0.0d + "'", double89 == 0.0d);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test112");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.9155040003582885E22d, (java.lang.Number) 0.0010756674403879158d, 3);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test113");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 5L, 62, 32);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test114");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 1077936128, (long) (-738962718));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1077936128L + "'", long2 == 1077936128L);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test115");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 1391070465);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1391070465L + "'", long1 == 1391070465L);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test116");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 15L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test117");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 252L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test118");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(1.1102230246251565E-16d, (double) (-738962718L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.1102230246251564E-16d + "'", double2 == 1.1102230246251564E-16d);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test119");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((-1111307499));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test120");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((int) '4', 5300);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test121");
        double double2 = org.apache.commons.math.util.FastMath.max(1025.8352504981494d, 11.591953275521519d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1025.8352504981494d + "'", double2 == 1025.8352504981494d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test122");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((-1111307499), 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1111307509) + "'", int2 == (-1111307509));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test123");
        double double2 = org.apache.commons.math.util.MathUtils.round(0.0d, 4);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test124");
        int int2 = org.apache.commons.math.util.FastMath.max(1072693249, (-818408495));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1072693249 + "'", int2 == 1072693249);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test125");
        int int1 = org.apache.commons.math.util.FastMath.abs(62);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 62 + "'", int1 == 62);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test126");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, (-0.48500216304847765d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test127");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) (-1111307499));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-21.521950266645902d) + "'", double1 == (-21.521950266645902d));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test128");
        double double1 = org.apache.commons.math.util.FastMath.asin(50.346573590279974d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test129");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.18838862103418857d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2073026073820454d + "'", double1 == 1.2073026073820454d);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test130");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(970);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5705.334861832116d + "'", double1 == 5705.334861832116d);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test131");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(52.838709677419345d, (double) 1072693249, 10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test132");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.960537576151187d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.960537576151187d + "'", double1 == 0.960537576151187d);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test133");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.2073026073820454d, (-26.0d));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test134");
        int int2 = org.apache.commons.math.util.MathUtils.pow(2, 190);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test135");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 800L, 223708937, 62);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test136");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-5290572617528898053L), 1444685096L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test137");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (short) 0, (int) ' ');
        int int4 = nonMonotonousSequenceException3.getIndex();
        boolean boolean5 = nonMonotonousSequenceException3.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-90L), (java.lang.Number) (-1), (int) (byte) 1, orderDirection9, false);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = nonMonotonousSequenceException11.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException17 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (short) 0, (int) ' ');
        int int18 = nonMonotonousSequenceException17.getIndex();
        boolean boolean19 = nonMonotonousSequenceException17.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection23 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException25 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-90L), (java.lang.Number) (-1), (int) (byte) 1, orderDirection23, false);
        nonMonotonousSequenceException17.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException25);
        int int27 = nonMonotonousSequenceException17.getIndex();
        nonMonotonousSequenceException11.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException17);
        int int29 = nonMonotonousSequenceException11.getIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 32 + "'", int4 == 32);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection13 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection13.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 32 + "'", int18 == 32);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + orderDirection23 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection23.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 32 + "'", int27 == 32);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test138");
        double double1 = org.apache.commons.math.util.FastMath.asin(32.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test139");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (-1.0f), 0.0d, 52.952809179494906d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test140");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) (-626347008), (double) 166536074441400L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-3.7610290148723483E-6d) + "'", double2 == (-3.7610290148723483E-6d));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test141");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(897609781);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test142");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 1412320L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test143");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(4.9095649975716696E-8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test144");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1072693249, 184331631L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-384827391) + "'", int2 == (-384827391));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test145");
        int[] intArray0 = new int[] {};
        int[] intArray1 = new int[] {};
        int int2 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray1);
        int[] intArray3 = new int[] {};
        int[] intArray4 = new int[] {};
        int int5 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray4);
        int int6 = org.apache.commons.math.util.MathUtils.distance1(intArray1, intArray4);
        int[] intArray7 = new int[] {};
        int[] intArray8 = new int[] {};
        int int9 = org.apache.commons.math.util.MathUtils.distance1(intArray7, intArray8);
        int[] intArray10 = new int[] {};
        int[] intArray11 = new int[] {};
        int int12 = org.apache.commons.math.util.MathUtils.distance1(intArray10, intArray11);
        int int13 = org.apache.commons.math.util.MathUtils.distance1(intArray8, intArray11);
        int[] intArray14 = new int[] {};
        int[] intArray15 = new int[] {};
        int int16 = org.apache.commons.math.util.MathUtils.distance1(intArray14, intArray15);
        double double17 = org.apache.commons.math.util.MathUtils.distance(intArray8, intArray14);
        int int18 = org.apache.commons.math.util.MathUtils.distanceInf(intArray4, intArray14);
        int[] intArray19 = new int[] {};
        int[] intArray20 = new int[] {};
        int int21 = org.apache.commons.math.util.MathUtils.distance1(intArray19, intArray20);
        int[] intArray22 = new int[] {};
        int[] intArray23 = new int[] {};
        int int24 = org.apache.commons.math.util.MathUtils.distance1(intArray22, intArray23);
        int int25 = org.apache.commons.math.util.MathUtils.distance1(intArray20, intArray23);
        int[] intArray26 = new int[] {};
        int[] intArray27 = new int[] {};
        int int28 = org.apache.commons.math.util.MathUtils.distance1(intArray26, intArray27);
        double double29 = org.apache.commons.math.util.MathUtils.distance(intArray20, intArray26);
        int int30 = org.apache.commons.math.util.MathUtils.distance1(intArray14, intArray20);
        int[] intArray31 = new int[] {};
        int[] intArray32 = new int[] {};
        int int33 = org.apache.commons.math.util.MathUtils.distance1(intArray31, intArray32);
        int[] intArray34 = new int[] {};
        int[] intArray35 = new int[] {};
        int int36 = org.apache.commons.math.util.MathUtils.distance1(intArray34, intArray35);
        int int37 = org.apache.commons.math.util.MathUtils.distance1(intArray32, intArray35);
        int[] intArray38 = new int[] {};
        int[] intArray39 = new int[] {};
        int int40 = org.apache.commons.math.util.MathUtils.distance1(intArray38, intArray39);
        int int41 = org.apache.commons.math.util.MathUtils.distance1(intArray35, intArray38);
        double double42 = org.apache.commons.math.util.MathUtils.distance(intArray20, intArray35);
        int[] intArray43 = null;
        int int44 = org.apache.commons.math.util.MathUtils.distanceInf(intArray20, intArray43);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test146");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow((int) (byte) 100, (-1074790400));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test147");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 1077936228, 5.035989756936426d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0777279384547204d + "'", double2 == 0.0777279384547204d);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test148");
        double double2 = org.apache.commons.math.util.FastMath.min((double) (-59812972992L), (double) 53L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-5.9812972992E10d) + "'", double2 == (-5.9812972992E10d));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test149");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(0, 5);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-5) + "'", int2 == (-5));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test150");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(3.174802103936399d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4697344922755988d + "'", double1 == 1.4697344922755988d);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test151");
        int int2 = org.apache.commons.math.util.MathUtils.pow(197, 35);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1939549635) + "'", int2 == (-1939549635));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test152");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((-3.0460359017724586E-4d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-3.046035901772458E-4d) + "'", double1 == (-3.046035901772458E-4d));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test153");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(5.298292365610485d, 2.0d, (double) 12565L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test154");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(728967041, (-738962718));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test155");
        long long2 = org.apache.commons.math.util.FastMath.max(252L, (long) '4');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 252L + "'", long2 == 252L);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test156");
        double double1 = org.apache.commons.math.util.FastMath.acosh((-0.013292325585375278d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test157");
        double[] doubleArray3 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) (short) -1);
        double[] doubleArray9 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, (double) (short) -1);
        double[] doubleArray13 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, (double) (-1L));
        double double14 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray13);
        double[] doubleArray18 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray18, (double) (short) -1);
        double[] doubleArray24 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray26 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray24, (double) (short) -1);
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, (double) (-1L));
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray28);
        double[] doubleArray33 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray35 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray33, (double) (short) -1);
        double[] doubleArray36 = null;
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equals(doubleArray33, doubleArray36);
        double[] doubleArray41 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray43 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray41, (double) (short) -1);
        double[] doubleArray47 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray49 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray47, (double) (short) -1);
        double[] doubleArray51 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray49, (double) (-1L));
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray43, doubleArray51);
        double double53 = org.apache.commons.math.util.MathUtils.distance1(doubleArray33, doubleArray43);
        boolean boolean54 = org.apache.commons.math.util.MathUtils.equals(doubleArray20, doubleArray33);
        double[] doubleArray58 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray60 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray58, (double) (short) -1);
        double[] doubleArray62 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray60, (double) (-1L));
        boolean boolean63 = org.apache.commons.math.util.MathUtils.equals(doubleArray20, doubleArray60);
        boolean boolean64 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray60);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException68 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (short) 0, (int) ' ');
        int int69 = nonMonotonousSequenceException68.getIndex();
        boolean boolean70 = nonMonotonousSequenceException68.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection74 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException76 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-90L), (java.lang.Number) (-1), (int) (byte) 1, orderDirection74, false);
        nonMonotonousSequenceException68.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException76);
        java.lang.Number number78 = nonMonotonousSequenceException68.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection79 = nonMonotonousSequenceException68.getDirection();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray5, orderDirection79, false);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 63.0d + "'", double53 == 63.0d);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 32 + "'", int69 == 32);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertTrue("'" + orderDirection74 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection74.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number78 + "' != '" + (short) 0 + "'", number78.equals((short) 0));
        org.junit.Assert.assertTrue("'" + orderDirection79 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection79.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test158");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 4L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 4.0f + "'", float1 == 4.0f);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test159");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(9.869604401089356d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9666.844563044142d + "'", double1 == 9666.844563044142d);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test160");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(0L, (long) 1391070465);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test161");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 447362012L, 97);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test162");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(52, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test163");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((-300), 252);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-552) + "'", int2 == (-552));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test164");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 62, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test165");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(190L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test166");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.0E300d, (-2.976789725572886E-254d));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test167");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(1.0986122886681098d, 0.3968502629920499d, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test168");
        int int2 = org.apache.commons.math.util.MathUtils.pow(184331630, 32);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test169");
        double double1 = org.apache.commons.math.util.FastMath.sin(1.249873866232524E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3226363798354875d + "'", double1 == 0.3226363798354875d);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test170");
        double double1 = org.apache.commons.math.util.FastMath.tan(15.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8559934009085187d) + "'", double1 == (-0.8559934009085187d));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test171");
        double[] doubleArray6 = new double[] { (short) -1, (-1L), 1.0d, 100, '#', 'a' };
        double[] doubleArray10 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray10, (double) (short) -1);
        double[] doubleArray13 = null;
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equals(doubleArray10, doubleArray13);
        double[] doubleArray18 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray18, (double) (short) -1);
        double[] doubleArray24 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray26 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray24, (double) (short) -1);
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, (double) (-1L));
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray28);
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray13, doubleArray20);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection34 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException36 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-90L), (java.lang.Number) (-1), (int) (byte) 1, orderDirection34, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray20, orderDirection34, true);
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray20);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray20);
        double[] doubleArray44 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray44, (double) (short) -1);
        double[] doubleArray50 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray52 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray50, (double) (short) -1);
        double[] doubleArray54 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray52, (double) (-1L));
        boolean boolean55 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray46, doubleArray54);
        double[] doubleArray57 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray54, 10.0d);
        double double58 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray54);
        double double59 = org.apache.commons.math.util.MathUtils.distance1(doubleArray20, doubleArray54);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection63 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException65 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 190L, (java.lang.Number) 9.332621544395286E157d, (int) (byte) 100, orderDirection63, false);
        java.lang.Throwable[] throwableArray66 = nonMonotonousSequenceException65.getSuppressed();
        int int67 = nonMonotonousSequenceException65.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection68 = nonMonotonousSequenceException65.getDirection();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray20, orderDirection68, false);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + orderDirection34 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection34.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.8540775674112082d + "'", double58 == 0.8540775674112082d);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection63 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection63.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray66);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 100 + "'", int67 == 100);
        org.junit.Assert.assertTrue("'" + orderDirection68 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection68.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test172");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(1.9416853130999966E10d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2687.7752379971807d + "'", double1 == 2687.7752379971807d);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test173");
        double double1 = org.apache.commons.math.util.FastMath.tanh(4.431288727929859E22d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test174");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(0.022985251411478155d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.000264172521592d + "'", double1 == 1.000264172521592d);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test175");
        int[] intArray0 = new int[] {};
        int[] intArray1 = new int[] {};
        int int2 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray1);
        int[] intArray3 = new int[] {};
        int[] intArray4 = new int[] {};
        int int5 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray4);
        int[] intArray6 = new int[] {};
        int[] intArray7 = new int[] {};
        int int8 = org.apache.commons.math.util.MathUtils.distance1(intArray6, intArray7);
        int int9 = org.apache.commons.math.util.MathUtils.distance1(intArray4, intArray7);
        int[] intArray10 = new int[] {};
        int[] intArray11 = new int[] {};
        int int12 = org.apache.commons.math.util.MathUtils.distance1(intArray10, intArray11);
        int[] intArray13 = new int[] {};
        int[] intArray14 = new int[] {};
        int int15 = org.apache.commons.math.util.MathUtils.distance1(intArray13, intArray14);
        int int16 = org.apache.commons.math.util.MathUtils.distance1(intArray11, intArray14);
        int[] intArray17 = new int[] {};
        int[] intArray18 = new int[] {};
        int int19 = org.apache.commons.math.util.MathUtils.distance1(intArray17, intArray18);
        double double20 = org.apache.commons.math.util.MathUtils.distance(intArray11, intArray17);
        int int21 = org.apache.commons.math.util.MathUtils.distanceInf(intArray7, intArray17);
        int[] intArray22 = new int[] {};
        int[] intArray23 = new int[] {};
        int int24 = org.apache.commons.math.util.MathUtils.distance1(intArray22, intArray23);
        int[] intArray25 = new int[] {};
        int[] intArray26 = new int[] {};
        int int27 = org.apache.commons.math.util.MathUtils.distance1(intArray25, intArray26);
        int int28 = org.apache.commons.math.util.MathUtils.distance1(intArray23, intArray26);
        int int29 = org.apache.commons.math.util.MathUtils.distance1(intArray7, intArray23);
        int[] intArray30 = new int[] {};
        int[] intArray31 = new int[] {};
        int int32 = org.apache.commons.math.util.MathUtils.distance1(intArray30, intArray31);
        int[] intArray33 = new int[] {};
        int[] intArray34 = new int[] {};
        int int35 = org.apache.commons.math.util.MathUtils.distance1(intArray33, intArray34);
        int int36 = org.apache.commons.math.util.MathUtils.distance1(intArray31, intArray34);
        int[] intArray37 = new int[] {};
        int[] intArray38 = new int[] {};
        int int39 = org.apache.commons.math.util.MathUtils.distance1(intArray37, intArray38);
        int[] intArray40 = new int[] {};
        int[] intArray41 = new int[] {};
        int int42 = org.apache.commons.math.util.MathUtils.distance1(intArray40, intArray41);
        int int43 = org.apache.commons.math.util.MathUtils.distance1(intArray38, intArray41);
        int[] intArray44 = new int[] {};
        int[] intArray45 = new int[] {};
        int int46 = org.apache.commons.math.util.MathUtils.distance1(intArray44, intArray45);
        double double47 = org.apache.commons.math.util.MathUtils.distance(intArray38, intArray44);
        int[] intArray48 = new int[] {};
        int[] intArray49 = new int[] {};
        int int50 = org.apache.commons.math.util.MathUtils.distance1(intArray48, intArray49);
        int[] intArray51 = new int[] {};
        int[] intArray52 = new int[] {};
        int int53 = org.apache.commons.math.util.MathUtils.distance1(intArray51, intArray52);
        int int54 = org.apache.commons.math.util.MathUtils.distance1(intArray49, intArray52);
        int[] intArray55 = new int[] {};
        int[] intArray56 = new int[] {};
        int int57 = org.apache.commons.math.util.MathUtils.distance1(intArray55, intArray56);
        int[] intArray58 = new int[] {};
        int[] intArray59 = new int[] {};
        int int60 = org.apache.commons.math.util.MathUtils.distance1(intArray58, intArray59);
        int int61 = org.apache.commons.math.util.MathUtils.distance1(intArray56, intArray59);
        int[] intArray62 = new int[] {};
        int[] intArray63 = new int[] {};
        int int64 = org.apache.commons.math.util.MathUtils.distance1(intArray62, intArray63);
        double double65 = org.apache.commons.math.util.MathUtils.distance(intArray56, intArray62);
        int int66 = org.apache.commons.math.util.MathUtils.distanceInf(intArray52, intArray62);
        int[] intArray67 = new int[] {};
        int[] intArray68 = new int[] {};
        int int69 = org.apache.commons.math.util.MathUtils.distance1(intArray67, intArray68);
        int[] intArray70 = new int[] {};
        int[] intArray71 = new int[] {};
        int int72 = org.apache.commons.math.util.MathUtils.distance1(intArray70, intArray71);
        int int73 = org.apache.commons.math.util.MathUtils.distance1(intArray68, intArray71);
        int[] intArray74 = new int[] {};
        int[] intArray75 = new int[] {};
        int int76 = org.apache.commons.math.util.MathUtils.distance1(intArray74, intArray75);
        double double77 = org.apache.commons.math.util.MathUtils.distance(intArray68, intArray74);
        int int78 = org.apache.commons.math.util.MathUtils.distance1(intArray62, intArray68);
        int[] intArray79 = new int[] {};
        int[] intArray80 = new int[] {};
        int int81 = org.apache.commons.math.util.MathUtils.distance1(intArray79, intArray80);
        int[] intArray82 = new int[] {};
        int[] intArray83 = new int[] {};
        int int84 = org.apache.commons.math.util.MathUtils.distance1(intArray82, intArray83);
        int[] intArray85 = new int[] {};
        int[] intArray86 = new int[] {};
        int int87 = org.apache.commons.math.util.MathUtils.distance1(intArray85, intArray86);
        int int88 = org.apache.commons.math.util.MathUtils.distance1(intArray83, intArray86);
        int int89 = org.apache.commons.math.util.MathUtils.distance1(intArray79, intArray86);
        double double90 = org.apache.commons.math.util.MathUtils.distance(intArray68, intArray86);
        int int91 = org.apache.commons.math.util.MathUtils.distance1(intArray38, intArray68);
        int int92 = org.apache.commons.math.util.MathUtils.distanceInf(intArray31, intArray38);
        int int93 = org.apache.commons.math.util.MathUtils.distance1(intArray23, intArray31);
        double double94 = org.apache.commons.math.util.MathUtils.distance(intArray1, intArray23);
        java.lang.Class<?> wildcardClass95 = intArray1.getClass();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
        org.junit.Assert.assertNotNull(intArray62);
        org.junit.Assert.assertNotNull(intArray63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
        org.junit.Assert.assertNotNull(intArray67);
        org.junit.Assert.assertNotNull(intArray68);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
        org.junit.Assert.assertNotNull(intArray70);
        org.junit.Assert.assertNotNull(intArray71);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 0 + "'", int72 == 0);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 0 + "'", int73 == 0);
        org.junit.Assert.assertNotNull(intArray74);
        org.junit.Assert.assertNotNull(intArray75);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 0 + "'", int76 == 0);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 0.0d + "'", double77 == 0.0d);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 0 + "'", int78 == 0);
        org.junit.Assert.assertNotNull(intArray79);
        org.junit.Assert.assertNotNull(intArray80);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 0 + "'", int81 == 0);
        org.junit.Assert.assertNotNull(intArray82);
        org.junit.Assert.assertNotNull(intArray83);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 0 + "'", int84 == 0);
        org.junit.Assert.assertNotNull(intArray85);
        org.junit.Assert.assertNotNull(intArray86);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 0 + "'", int87 == 0);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 0 + "'", int88 == 0);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 0 + "'", int89 == 0);
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + 0.0d + "'", double90 == 0.0d);
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 0 + "'", int91 == 0);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 0 + "'", int92 == 0);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 0 + "'", int93 == 0);
        org.junit.Assert.assertTrue("'" + double94 + "' != '" + 0.0d + "'", double94 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass95);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test176");
        int int1 = org.apache.commons.math.util.MathUtils.hash(0.8517779466253769d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-319948472) + "'", int1 == (-319948472));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test177");
        int int2 = org.apache.commons.math.util.FastMath.min(1074790400, (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test178");
        double[] doubleArray3 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) (short) -1);
        double[] doubleArray9 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, (double) (short) -1);
        double[] doubleArray13 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, (double) (-1L));
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray13);
        double[] doubleArray18 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray18, (double) (short) -1);
        double[] doubleArray21 = null;
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equals(doubleArray18, doubleArray21);
        double[] doubleArray26 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, (double) (short) -1);
        double[] doubleArray32 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray32, (double) (short) -1);
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray34, (double) (-1L));
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray28, doubleArray36);
        double double38 = org.apache.commons.math.util.MathUtils.distance1(doubleArray18, doubleArray28);
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray18);
        double[] doubleArray43 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray45 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray43, (double) (short) -1);
        double[] doubleArray47 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray45, (double) (-1L));
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray45);
        double[] doubleArray52 = new double[] { (-35L), 1.3043045862358962d, '#' };
        double double53 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray52);
        double[] doubleArray57 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray59 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray57, (double) (short) -1);
        double[] doubleArray63 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray65 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray63, (double) (short) -1);
        double[] doubleArray67 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray65, (double) (-1L));
        boolean boolean68 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray59, doubleArray67);
        double[] doubleArray72 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray74 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray72, (double) (short) -1);
        double[] doubleArray75 = null;
        boolean boolean76 = org.apache.commons.math.util.MathUtils.equals(doubleArray72, doubleArray75);
        double[] doubleArray80 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray82 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray80, (double) (short) -1);
        double[] doubleArray86 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray88 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray86, (double) (short) -1);
        double[] doubleArray90 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray88, (double) (-1L));
        boolean boolean91 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray82, doubleArray90);
        double double92 = org.apache.commons.math.util.MathUtils.distance1(doubleArray72, doubleArray82);
        boolean boolean93 = org.apache.commons.math.util.MathUtils.equals(doubleArray59, doubleArray72);
        boolean boolean94 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray72);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray72);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (52 >= 10)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 63.0d + "'", double38 == 63.0d);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 70.62688523139718d + "'", double53 == 70.62688523139718d);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertNotNull(doubleArray90);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + true + "'", boolean91 == true);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 63.0d + "'", double92 == 63.0d);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test179");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) 62, 447362012L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 27736444744L + "'", long2 == 27736444744L);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test180");
        long long2 = org.apache.commons.math.util.FastMath.min(5L, (-1074790400L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1074790400L) + "'", long2 == (-1074790400L));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test181");
        int int2 = org.apache.commons.math.util.FastMath.min((-1444685106), 1018167296);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1444685106) + "'", int2 == (-1444685106));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test182");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 1.07479027E9f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test183");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((-1074790303L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test184");
        double double2 = org.apache.commons.math.util.FastMath.pow(1.0795253760000114E9d, (double) 1444685096L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test185");
        long long1 = org.apache.commons.math.util.MathUtils.factorial((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test186");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 12565L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.19884766788940153d + "'", double1 == 0.19884766788940153d);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test187");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test188");
        int int1 = org.apache.commons.math.util.FastMath.abs((-1111307509));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1111307509 + "'", int1 == 1111307509);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test189");
        double double1 = org.apache.commons.math.util.MathUtils.sign(5.298342365610589d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test190");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (short) 0, (int) (short) 0);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException7 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (short) 0, (int) (short) 0);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException7);
        java.lang.Throwable[] throwableArray9 = nonMonotonousSequenceException7.getSuppressed();
        boolean boolean10 = nonMonotonousSequenceException7.getStrict();
        int int11 = nonMonotonousSequenceException7.getIndex();
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test191");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 10);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 10.0f + "'", float1 == 10.0f);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test192");
        double double1 = org.apache.commons.math.util.FastMath.sin((-0.013292325585375278d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.013291934161038601d) + "'", double1 == (-0.013291934161038601d));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test193");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((-1.0747904E9d), 0.0d, 291);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test194");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0f, (float) 52L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test195");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(32, (-5));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 160 + "'", int2 == 160);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test196");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(1.0795255743608363E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test197");
        double double1 = org.apache.commons.math.util.FastMath.atanh(50.346573590279974d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test198");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(0, (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test199");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) 1079525376);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test200");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(4.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 27.28991719712775d + "'", double1 == 27.28991719712775d);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test201");
        double[] doubleArray3 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) (short) -1);
        double[] doubleArray9 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, (double) (short) -1);
        double double12 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray9);
        double[] doubleArray16 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, (double) (short) -1);
        double[] doubleArray19 = null;
        boolean boolean20 = org.apache.commons.math.util.MathUtils.equals(doubleArray16, doubleArray19);
        double[] doubleArray24 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray26 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray24, (double) (short) -1);
        double[] doubleArray30 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray30, (double) (short) -1);
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray32, (double) (-1L));
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray26, doubleArray34);
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray26);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection40 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException42 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-90L), (java.lang.Number) (-1), (int) (byte) 1, orderDirection40, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray26, orderDirection40, true);
        boolean boolean45 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray26);
        double[] doubleArray49 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray51 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray49, (double) (short) -1);
        double[] doubleArray52 = null;
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equals(doubleArray49, doubleArray52);
        double[] doubleArray57 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray59 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray57, (double) (short) -1);
        double[] doubleArray63 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray65 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray63, (double) (short) -1);
        double[] doubleArray67 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray65, (double) (-1L));
        boolean boolean68 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray59, doubleArray67);
        double double69 = org.apache.commons.math.util.MathUtils.distance1(doubleArray49, doubleArray59);
        double double70 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray59);
        double double71 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray59);
        double[] doubleArray72 = null;
        boolean boolean73 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray59, doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 63.0d + "'", double12 == 63.0d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + orderDirection40 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection40.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 63.0d + "'", double69 == 63.0d);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.0d + "'", double70 == 0.0d);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.8540775674112082d + "'", double71 == 0.8540775674112082d);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test202");
        double double1 = org.apache.commons.math.util.FastMath.log(1.3043045862358962d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2656700146310344d + "'", double1 == 0.2656700146310344d);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test203");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 291);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 291.0d + "'", double1 == 291.0d);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test204");
        int[] intArray0 = new int[] {};
        int[] intArray1 = new int[] {};
        int int2 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray1);
        int[] intArray3 = new int[] {};
        int[] intArray4 = new int[] {};
        int int5 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray4);
        int int6 = org.apache.commons.math.util.MathUtils.distance1(intArray1, intArray4);
        int[] intArray7 = new int[] {};
        int[] intArray8 = new int[] {};
        int int9 = org.apache.commons.math.util.MathUtils.distance1(intArray7, intArray8);
        int[] intArray10 = new int[] {};
        int[] intArray11 = new int[] {};
        int int12 = org.apache.commons.math.util.MathUtils.distance1(intArray10, intArray11);
        int int13 = org.apache.commons.math.util.MathUtils.distance1(intArray8, intArray11);
        int[] intArray14 = new int[] {};
        int[] intArray15 = new int[] {};
        int int16 = org.apache.commons.math.util.MathUtils.distance1(intArray14, intArray15);
        int int17 = org.apache.commons.math.util.MathUtils.distance1(intArray11, intArray14);
        double double18 = org.apache.commons.math.util.MathUtils.distance(intArray4, intArray14);
        int[] intArray19 = new int[] {};
        int[] intArray20 = new int[] {};
        int int21 = org.apache.commons.math.util.MathUtils.distance1(intArray19, intArray20);
        int[] intArray22 = new int[] {};
        int[] intArray23 = new int[] {};
        int int24 = org.apache.commons.math.util.MathUtils.distance1(intArray22, intArray23);
        int int25 = org.apache.commons.math.util.MathUtils.distance1(intArray20, intArray23);
        int[] intArray26 = new int[] {};
        int[] intArray27 = new int[] {};
        int int28 = org.apache.commons.math.util.MathUtils.distance1(intArray26, intArray27);
        int int29 = org.apache.commons.math.util.MathUtils.distance1(intArray23, intArray26);
        int[] intArray30 = new int[] {};
        int[] intArray31 = new int[] {};
        int int32 = org.apache.commons.math.util.MathUtils.distance1(intArray30, intArray31);
        int[] intArray33 = new int[] {};
        int[] intArray34 = new int[] {};
        int int35 = org.apache.commons.math.util.MathUtils.distance1(intArray33, intArray34);
        int int36 = org.apache.commons.math.util.MathUtils.distance1(intArray31, intArray34);
        int[] intArray37 = new int[] {};
        int[] intArray38 = new int[] {};
        int int39 = org.apache.commons.math.util.MathUtils.distance1(intArray37, intArray38);
        double double40 = org.apache.commons.math.util.MathUtils.distance(intArray31, intArray37);
        int int41 = org.apache.commons.math.util.MathUtils.distance1(intArray23, intArray31);
        int int42 = org.apache.commons.math.util.MathUtils.distanceInf(intArray14, intArray31);
        int[] intArray43 = new int[] {};
        int[] intArray44 = new int[] {};
        int int45 = org.apache.commons.math.util.MathUtils.distance1(intArray43, intArray44);
        int[] intArray46 = new int[] {};
        int[] intArray47 = new int[] {};
        int int48 = org.apache.commons.math.util.MathUtils.distance1(intArray46, intArray47);
        int int49 = org.apache.commons.math.util.MathUtils.distance1(intArray44, intArray47);
        int[] intArray50 = new int[] {};
        int[] intArray51 = new int[] {};
        int int52 = org.apache.commons.math.util.MathUtils.distance1(intArray50, intArray51);
        int[] intArray53 = new int[] {};
        int[] intArray54 = new int[] {};
        int int55 = org.apache.commons.math.util.MathUtils.distance1(intArray53, intArray54);
        int int56 = org.apache.commons.math.util.MathUtils.distance1(intArray51, intArray54);
        int[] intArray57 = new int[] {};
        int[] intArray58 = new int[] {};
        int int59 = org.apache.commons.math.util.MathUtils.distance1(intArray57, intArray58);
        double double60 = org.apache.commons.math.util.MathUtils.distance(intArray51, intArray57);
        int int61 = org.apache.commons.math.util.MathUtils.distanceInf(intArray47, intArray57);
        int[] intArray62 = new int[] {};
        int[] intArray63 = new int[] {};
        int int64 = org.apache.commons.math.util.MathUtils.distance1(intArray62, intArray63);
        int[] intArray65 = new int[] {};
        int[] intArray66 = new int[] {};
        int int67 = org.apache.commons.math.util.MathUtils.distance1(intArray65, intArray66);
        int int68 = org.apache.commons.math.util.MathUtils.distance1(intArray63, intArray66);
        int int69 = org.apache.commons.math.util.MathUtils.distance1(intArray47, intArray63);
        int[] intArray70 = new int[] {};
        int[] intArray71 = new int[] {};
        int int72 = org.apache.commons.math.util.MathUtils.distance1(intArray70, intArray71);
        int[] intArray73 = new int[] {};
        int[] intArray74 = new int[] {};
        int int75 = org.apache.commons.math.util.MathUtils.distance1(intArray73, intArray74);
        int int76 = org.apache.commons.math.util.MathUtils.distance1(intArray71, intArray74);
        int[] intArray77 = new int[] {};
        int[] intArray78 = new int[] {};
        int int79 = org.apache.commons.math.util.MathUtils.distance1(intArray77, intArray78);
        int int80 = org.apache.commons.math.util.MathUtils.distance1(intArray74, intArray77);
        int int81 = org.apache.commons.math.util.MathUtils.distanceInf(intArray63, intArray74);
        int int82 = org.apache.commons.math.util.MathUtils.distance1(intArray14, intArray63);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertNotNull(intArray54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
        org.junit.Assert.assertNotNull(intArray62);
        org.junit.Assert.assertNotNull(intArray63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
        org.junit.Assert.assertNotNull(intArray65);
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 0 + "'", int67 == 0);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
        org.junit.Assert.assertNotNull(intArray70);
        org.junit.Assert.assertNotNull(intArray71);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 0 + "'", int72 == 0);
        org.junit.Assert.assertNotNull(intArray73);
        org.junit.Assert.assertNotNull(intArray74);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 0 + "'", int75 == 0);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 0 + "'", int76 == 0);
        org.junit.Assert.assertNotNull(intArray77);
        org.junit.Assert.assertNotNull(intArray78);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 0 + "'", int79 == 0);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 0 + "'", int80 == 0);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 0 + "'", int81 == 0);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 0 + "'", int82 == 0);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test205");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.8557324056416817d), (java.lang.Number) (-1.0747904E9d), (-384827391));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test206");
        double double1 = org.apache.commons.math.util.FastMath.exp(2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 15.154262241479262d + "'", double1 == 15.154262241479262d);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test207");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(1079525376, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test208");
        int int2 = org.apache.commons.math.util.FastMath.min(0, (-319948472));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-319948472) + "'", int2 == (-319948472));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test209");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm((-10), (-626347007));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test210");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) (-384827391));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test211");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(2.3978952727983707d, (-9.99999999999987d), (double) 0L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test212");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(0, (-626347008));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test213");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow(0, (-1249873867));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test214");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (-190L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 190.0f + "'", float1 == 190.0f);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test215");
        float float3 = org.apache.commons.math.util.MathUtils.round((float) (-626347008), 940900, 0);
        org.junit.Assert.assertEquals((float) float3, Float.NaN, 0);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test216");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) (-1939549635), 4.38727775E8d, 0.6931471805599453d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test217");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(1074790313L, (long) 3104);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3336149131552L + "'", long2 == 3336149131552L);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test218");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-626350014L), (-1074790303L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 673194921331114242L + "'", long2 == 673194921331114242L);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test219");
        double double1 = org.apache.commons.math.util.FastMath.cosh(416.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.319927837136307E180d + "'", double1 == 2.319927837136307E180d);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test220");
        float float2 = org.apache.commons.math.util.FastMath.max(1.0747904E9f, (float) 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test221");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(0.0d, 252, (-626350101));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test222");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 970, (double) 8625328718985905607L, 940900);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test223");
        double[] doubleArray3 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) (short) -1);
        double[] doubleArray9 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, (double) (short) -1);
        double[] doubleArray13 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, (double) (-1L));
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray13);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException18 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (short) 0, (int) (short) 0);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException22 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (short) 0, (int) (short) 0);
        nonMonotonousSequenceException18.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException22);
        java.lang.Throwable[] throwableArray24 = nonMonotonousSequenceException22.getSuppressed();
        boolean boolean25 = nonMonotonousSequenceException22.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection26 = nonMonotonousSequenceException22.getDirection();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray5, orderDirection26, false);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(throwableArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + orderDirection26 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection26.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test224");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) (byte) 100, 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10000 + "'", int2 == 10000);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test225");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((-300));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test226");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 2455225485L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5513634997088186d) + "'", double1 == (-0.5513634997088186d));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test227");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((-0.5063656411097588d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7970546072131425d) + "'", double1 == (-0.7970546072131425d));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test228");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 12600L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 12600 + "'", int1 == 12600);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test229");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 100L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5729.5779513082325d + "'", double1 == 5729.5779513082325d);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test230");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(2.0d, (-1111307509));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-6.359114106063704E234d) + "'", double2 == (-6.359114106063704E234d));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test231");
        long long1 = org.apache.commons.math.util.MathUtils.sign((-155L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test232");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 1077936128L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6303192792669902d + "'", double1 == 0.6303192792669902d);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test233");
        double[] doubleArray3 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) (short) -1);
        double[] doubleArray9 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, (double) (short) -1);
        double[] doubleArray13 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, (double) (-1L));
        double double14 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray13);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test234");
        double[] doubleArray3 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) (short) -1);
        double[] doubleArray9 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, (double) (short) -1);
        double[] doubleArray13 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, (double) (-1L));
        double double14 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray13);
        double[] doubleArray18 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray18, (double) (short) -1);
        double[] doubleArray24 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray26 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray24, (double) (short) -1);
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, (double) (-1L));
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray28);
        double[] doubleArray33 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray35 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray33, (double) (short) -1);
        double[] doubleArray36 = null;
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equals(doubleArray33, doubleArray36);
        double[] doubleArray41 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray43 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray41, (double) (short) -1);
        double[] doubleArray47 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray49 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray47, (double) (short) -1);
        double[] doubleArray51 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray49, (double) (-1L));
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray43, doubleArray51);
        double double53 = org.apache.commons.math.util.MathUtils.distance1(doubleArray33, doubleArray43);
        boolean boolean54 = org.apache.commons.math.util.MathUtils.equals(doubleArray20, doubleArray33);
        double[] doubleArray58 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray60 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray58, (double) (short) -1);
        double[] doubleArray62 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray60, (double) (-1L));
        boolean boolean63 = org.apache.commons.math.util.MathUtils.equals(doubleArray20, doubleArray60);
        boolean boolean64 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray60);
        double[] doubleArray68 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray70 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray68, (double) (short) -1);
        double[] doubleArray74 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray76 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray74, (double) (short) -1);
        double[] doubleArray78 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray76, (double) (-1L));
        double double79 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray70, doubleArray78);
        double[] doubleArray81 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray78, (double) (short) 100);
        boolean boolean82 = org.apache.commons.math.util.MathUtils.equals(doubleArray60, doubleArray81);
        double[] doubleArray84 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray60, (double) 1391070465);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 63.0d + "'", double53 == 63.0d);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 0.0d + "'", double79 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(doubleArray84);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test235");
        double double2 = org.apache.commons.math.util.FastMath.min(1.000264172521592d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test236");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(Double.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test237");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 0, (-0.8559934009085187d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test238");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow((-738962753), (-12565L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test239");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.7384694543057034d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6731568624132899d + "'", double1 == 0.6731568624132899d);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test240");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.2993561521932179d, (-4.4736201199999994E8d), 0.0010756674403879158d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test241");
        int[] intArray0 = new int[] {};
        int[] intArray1 = new int[] {};
        int int2 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray1);
        int[] intArray3 = new int[] {};
        int[] intArray4 = new int[] {};
        int int5 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray4);
        int int6 = org.apache.commons.math.util.MathUtils.distance1(intArray1, intArray4);
        int[] intArray7 = new int[] {};
        int[] intArray8 = new int[] {};
        int int9 = org.apache.commons.math.util.MathUtils.distance1(intArray7, intArray8);
        int[] intArray10 = new int[] {};
        int[] intArray11 = new int[] {};
        int int12 = org.apache.commons.math.util.MathUtils.distance1(intArray10, intArray11);
        int int13 = org.apache.commons.math.util.MathUtils.distance1(intArray8, intArray11);
        int[] intArray14 = new int[] {};
        int[] intArray15 = new int[] {};
        int int16 = org.apache.commons.math.util.MathUtils.distance1(intArray14, intArray15);
        double double17 = org.apache.commons.math.util.MathUtils.distance(intArray8, intArray14);
        int int18 = org.apache.commons.math.util.MathUtils.distanceInf(intArray4, intArray14);
        int[] intArray19 = new int[] {};
        int[] intArray20 = new int[] {};
        int int21 = org.apache.commons.math.util.MathUtils.distance1(intArray19, intArray20);
        int[] intArray22 = new int[] {};
        int[] intArray23 = new int[] {};
        int int24 = org.apache.commons.math.util.MathUtils.distance1(intArray22, intArray23);
        int int25 = org.apache.commons.math.util.MathUtils.distance1(intArray20, intArray23);
        int[] intArray26 = new int[] {};
        int[] intArray27 = new int[] {};
        int int28 = org.apache.commons.math.util.MathUtils.distance1(intArray26, intArray27);
        int[] intArray29 = new int[] {};
        int[] intArray30 = new int[] {};
        int int31 = org.apache.commons.math.util.MathUtils.distance1(intArray29, intArray30);
        int int32 = org.apache.commons.math.util.MathUtils.distance1(intArray27, intArray30);
        int[] intArray33 = new int[] {};
        int[] intArray34 = new int[] {};
        int int35 = org.apache.commons.math.util.MathUtils.distance1(intArray33, intArray34);
        double double36 = org.apache.commons.math.util.MathUtils.distance(intArray27, intArray33);
        int int37 = org.apache.commons.math.util.MathUtils.distanceInf(intArray23, intArray33);
        int[] intArray38 = new int[] {};
        int[] intArray39 = new int[] {};
        int int40 = org.apache.commons.math.util.MathUtils.distance1(intArray38, intArray39);
        int[] intArray41 = new int[] {};
        int[] intArray42 = new int[] {};
        int int43 = org.apache.commons.math.util.MathUtils.distance1(intArray41, intArray42);
        int int44 = org.apache.commons.math.util.MathUtils.distance1(intArray39, intArray42);
        int int45 = org.apache.commons.math.util.MathUtils.distance1(intArray23, intArray39);
        int int46 = org.apache.commons.math.util.MathUtils.distance1(intArray14, intArray23);
        int[] intArray47 = new int[] {};
        int[] intArray48 = new int[] {};
        int int49 = org.apache.commons.math.util.MathUtils.distance1(intArray47, intArray48);
        int[] intArray50 = new int[] {};
        int[] intArray51 = new int[] {};
        int int52 = org.apache.commons.math.util.MathUtils.distance1(intArray50, intArray51);
        int int53 = org.apache.commons.math.util.MathUtils.distance1(intArray48, intArray51);
        int[] intArray54 = new int[] {};
        int[] intArray55 = new int[] {};
        int int56 = org.apache.commons.math.util.MathUtils.distance1(intArray54, intArray55);
        int[] intArray57 = new int[] {};
        int[] intArray58 = new int[] {};
        int int59 = org.apache.commons.math.util.MathUtils.distance1(intArray57, intArray58);
        int int60 = org.apache.commons.math.util.MathUtils.distance1(intArray55, intArray58);
        int[] intArray61 = new int[] {};
        int[] intArray62 = new int[] {};
        int int63 = org.apache.commons.math.util.MathUtils.distance1(intArray61, intArray62);
        int int64 = org.apache.commons.math.util.MathUtils.distance1(intArray58, intArray61);
        int int65 = org.apache.commons.math.util.MathUtils.distance1(intArray51, intArray61);
        int[] intArray66 = new int[] {};
        int[] intArray67 = new int[] {};
        int int68 = org.apache.commons.math.util.MathUtils.distance1(intArray66, intArray67);
        int[] intArray69 = new int[] {};
        int[] intArray70 = new int[] {};
        int int71 = org.apache.commons.math.util.MathUtils.distance1(intArray69, intArray70);
        int int72 = org.apache.commons.math.util.MathUtils.distance1(intArray67, intArray70);
        int[] intArray73 = new int[] {};
        int[] intArray74 = new int[] {};
        int int75 = org.apache.commons.math.util.MathUtils.distance1(intArray73, intArray74);
        int[] intArray76 = new int[] {};
        int[] intArray77 = new int[] {};
        int int78 = org.apache.commons.math.util.MathUtils.distance1(intArray76, intArray77);
        int int79 = org.apache.commons.math.util.MathUtils.distance1(intArray74, intArray77);
        int[] intArray80 = new int[] {};
        int[] intArray81 = new int[] {};
        int int82 = org.apache.commons.math.util.MathUtils.distance1(intArray80, intArray81);
        double double83 = org.apache.commons.math.util.MathUtils.distance(intArray74, intArray80);
        int int84 = org.apache.commons.math.util.MathUtils.distanceInf(intArray70, intArray80);
        int[] intArray85 = new int[] {};
        int[] intArray86 = new int[] {};
        int int87 = org.apache.commons.math.util.MathUtils.distance1(intArray85, intArray86);
        int[] intArray88 = new int[] {};
        int[] intArray89 = new int[] {};
        int int90 = org.apache.commons.math.util.MathUtils.distance1(intArray88, intArray89);
        int int91 = org.apache.commons.math.util.MathUtils.distance1(intArray86, intArray89);
        int int92 = org.apache.commons.math.util.MathUtils.distance1(intArray70, intArray86);
        int int93 = org.apache.commons.math.util.MathUtils.distance1(intArray51, intArray70);
        int int94 = org.apache.commons.math.util.MathUtils.distanceInf(intArray14, intArray70);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertNotNull(intArray54);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertNotNull(intArray62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertNotNull(intArray67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
        org.junit.Assert.assertNotNull(intArray69);
        org.junit.Assert.assertNotNull(intArray70);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 0 + "'", int71 == 0);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 0 + "'", int72 == 0);
        org.junit.Assert.assertNotNull(intArray73);
        org.junit.Assert.assertNotNull(intArray74);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 0 + "'", int75 == 0);
        org.junit.Assert.assertNotNull(intArray76);
        org.junit.Assert.assertNotNull(intArray77);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 0 + "'", int78 == 0);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 0 + "'", int79 == 0);
        org.junit.Assert.assertNotNull(intArray80);
        org.junit.Assert.assertNotNull(intArray81);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 0 + "'", int82 == 0);
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + 0.0d + "'", double83 == 0.0d);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 0 + "'", int84 == 0);
        org.junit.Assert.assertNotNull(intArray85);
        org.junit.Assert.assertNotNull(intArray86);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 0 + "'", int87 == 0);
        org.junit.Assert.assertNotNull(intArray88);
        org.junit.Assert.assertNotNull(intArray89);
        org.junit.Assert.assertTrue("'" + int90 + "' != '" + 0 + "'", int90 == 0);
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 0 + "'", int91 == 0);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 0 + "'", int92 == 0);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 0 + "'", int93 == 0);
        org.junit.Assert.assertTrue("'" + int94 + "' != '" + 0 + "'", int94 == 0);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test242");
        double double1 = org.apache.commons.math.util.FastMath.sinh(3.038015112528436E37d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test243");
        long long2 = org.apache.commons.math.util.FastMath.min(0L, 900L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test244");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) (-90L), (double) (-1249873867));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.2498738679394162E9d) + "'", double2 == (-1.2498738679394162E9d));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test245");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(3.174802103936399d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11.940141468803501d + "'", double1 == 11.940141468803501d);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test246");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) (-1074790400L), (double) (-10.0f));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test247");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 291);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 291L + "'", long1 == 291L);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test248");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(2559.6567728894133d, 252);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.8524250341456984E79d + "'", double2 == 1.8524250341456984E79d);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test249");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(160, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-160) + "'", int2 == (-160));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test250");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 1.07952538E9f, 0.9999474062706148d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test251");
        int[] intArray0 = new int[] {};
        int[] intArray1 = new int[] {};
        int int2 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray1);
        int[] intArray3 = new int[] {};
        int[] intArray4 = new int[] {};
        int int5 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray4);
        int int6 = org.apache.commons.math.util.MathUtils.distance1(intArray1, intArray4);
        int[] intArray7 = new int[] {};
        int[] intArray8 = new int[] {};
        int int9 = org.apache.commons.math.util.MathUtils.distance1(intArray7, intArray8);
        int[] intArray10 = new int[] {};
        int[] intArray11 = new int[] {};
        int int12 = org.apache.commons.math.util.MathUtils.distance1(intArray10, intArray11);
        int int13 = org.apache.commons.math.util.MathUtils.distance1(intArray8, intArray11);
        int[] intArray14 = new int[] {};
        int[] intArray15 = new int[] {};
        int int16 = org.apache.commons.math.util.MathUtils.distance1(intArray14, intArray15);
        double double17 = org.apache.commons.math.util.MathUtils.distance(intArray8, intArray14);
        int int18 = org.apache.commons.math.util.MathUtils.distanceInf(intArray4, intArray14);
        java.lang.Class<?> wildcardClass19 = intArray14.getClass();
        int[] intArray20 = new int[] {};
        int[] intArray21 = new int[] {};
        int int22 = org.apache.commons.math.util.MathUtils.distance1(intArray20, intArray21);
        int[] intArray23 = new int[] {};
        int[] intArray24 = new int[] {};
        int int25 = org.apache.commons.math.util.MathUtils.distance1(intArray23, intArray24);
        int int26 = org.apache.commons.math.util.MathUtils.distance1(intArray21, intArray24);
        int[] intArray27 = new int[] {};
        int[] intArray28 = new int[] {};
        int int29 = org.apache.commons.math.util.MathUtils.distance1(intArray27, intArray28);
        int[] intArray30 = new int[] {};
        int[] intArray31 = new int[] {};
        int int32 = org.apache.commons.math.util.MathUtils.distance1(intArray30, intArray31);
        int int33 = org.apache.commons.math.util.MathUtils.distance1(intArray28, intArray31);
        int[] intArray34 = new int[] {};
        int[] intArray35 = new int[] {};
        int int36 = org.apache.commons.math.util.MathUtils.distance1(intArray34, intArray35);
        int int37 = org.apache.commons.math.util.MathUtils.distance1(intArray31, intArray34);
        double double38 = org.apache.commons.math.util.MathUtils.distance(intArray24, intArray34);
        int[] intArray39 = new int[] {};
        int[] intArray40 = new int[] {};
        int int41 = org.apache.commons.math.util.MathUtils.distance1(intArray39, intArray40);
        int[] intArray42 = new int[] {};
        int[] intArray43 = new int[] {};
        int int44 = org.apache.commons.math.util.MathUtils.distance1(intArray42, intArray43);
        int int45 = org.apache.commons.math.util.MathUtils.distance1(intArray40, intArray43);
        int[] intArray46 = new int[] {};
        int[] intArray47 = new int[] {};
        int int48 = org.apache.commons.math.util.MathUtils.distance1(intArray46, intArray47);
        double double49 = org.apache.commons.math.util.MathUtils.distance(intArray40, intArray46);
        int int50 = org.apache.commons.math.util.MathUtils.distance1(intArray24, intArray40);
        int int51 = org.apache.commons.math.util.MathUtils.distance1(intArray14, intArray24);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test252");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test253");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow(184331631, (-1074790400L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test254");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 100L, (-1074790400));
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test255");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (-2149580616L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-2147483648) + "'", int1 == (-2147483648));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test256");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(70.62688523139718d, (-0.6546289196540399d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5118468524217406d + "'", double2 == 1.5118468524217406d);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test257");
        double double2 = org.apache.commons.math.util.MathUtils.log(4.584967478670572d, 0.6363935896729996d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.2967842769426509d) + "'", double2 == (-0.2967842769426509d));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test258");
        int int2 = org.apache.commons.math.util.FastMath.min(0, 260);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test259");
        float float1 = org.apache.commons.math.util.FastMath.abs(100.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 100.0f + "'", float1 == 100.0f);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test260");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) (-160));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-159.99999999999997d) + "'", double1 == (-159.99999999999997d));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test261");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (short) 0, 3104);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3104 + "'", int2 == 3104);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test262");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (-447362047), 190L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-447362047L) + "'", long2 == (-447362047L));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test263");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) '#', (-108640L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 108640L + "'", long2 == 108640L);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test264");
        int int1 = org.apache.commons.math.util.FastMath.abs((-626347008));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 626347008 + "'", int1 == 626347008);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test265");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((int) '4', 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test266");
        double[] doubleArray3 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) (short) -1);
        double[] doubleArray9 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, (double) (short) -1);
        double[] doubleArray13 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, (double) (-1L));
        double double14 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray13);
        double[] doubleArray18 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray18, (double) (short) -1);
        double[] doubleArray24 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray26 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray24, (double) (short) -1);
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, (double) (-1L));
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray28);
        double[] doubleArray33 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray35 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray33, (double) (short) -1);
        double[] doubleArray36 = null;
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equals(doubleArray33, doubleArray36);
        double[] doubleArray41 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray43 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray41, (double) (short) -1);
        double[] doubleArray47 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray49 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray47, (double) (short) -1);
        double[] doubleArray51 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray49, (double) (-1L));
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray43, doubleArray51);
        double double53 = org.apache.commons.math.util.MathUtils.distance1(doubleArray33, doubleArray43);
        boolean boolean54 = org.apache.commons.math.util.MathUtils.equals(doubleArray20, doubleArray33);
        double[] doubleArray58 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray60 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray58, (double) (short) -1);
        double[] doubleArray62 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray60, (double) (-1L));
        boolean boolean63 = org.apache.commons.math.util.MathUtils.equals(doubleArray20, doubleArray60);
        boolean boolean64 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray60);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException68 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (short) 0, (int) ' ');
        int int69 = nonMonotonousSequenceException68.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection70 = nonMonotonousSequenceException68.getDirection();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray5, orderDirection70, true);
        double[] doubleArray74 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray5, 0.863944749891274d);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 63.0d + "'", double53 == 63.0d);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 32 + "'", int69 == 32);
        org.junit.Assert.assertTrue("'" + orderDirection70 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection70.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray74);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test267");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 190);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 190L + "'", long1 == 190L);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test268");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((-0.9999999999999999d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test269");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((-0.8813735870195429d), 1.5430806348152437d, 461100);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test270");
        double double1 = org.apache.commons.math.util.FastMath.atanh(1.5118468524217406d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test271");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 4.584967478670572d, (java.lang.Number) 87.0f, (int) (byte) 100);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test272");
        double double2 = org.apache.commons.math.util.FastMath.min(1.2000803543578267E7d, (-0.013291934161038601d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.013291934161038601d) + "'", double2 == (-0.013291934161038601d));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test273");
        double double1 = org.apache.commons.math.util.FastMath.floor(52.99999999999999d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 52.0d + "'", double1 == 52.0d);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test274");
        int[] intArray0 = null;
        int[] intArray1 = new int[] {};
        int[] intArray2 = new int[] {};
        int int3 = org.apache.commons.math.util.MathUtils.distance1(intArray1, intArray2);
        int[] intArray4 = new int[] {};
        int[] intArray5 = new int[] {};
        int int6 = org.apache.commons.math.util.MathUtils.distance1(intArray4, intArray5);
        int int7 = org.apache.commons.math.util.MathUtils.distance1(intArray2, intArray5);
        int[] intArray8 = new int[] {};
        int[] intArray9 = new int[] {};
        int int10 = org.apache.commons.math.util.MathUtils.distance1(intArray8, intArray9);
        int[] intArray11 = new int[] {};
        int[] intArray12 = new int[] {};
        int int13 = org.apache.commons.math.util.MathUtils.distance1(intArray11, intArray12);
        int int14 = org.apache.commons.math.util.MathUtils.distance1(intArray9, intArray12);
        int[] intArray15 = new int[] {};
        int[] intArray16 = new int[] {};
        int int17 = org.apache.commons.math.util.MathUtils.distance1(intArray15, intArray16);
        double double18 = org.apache.commons.math.util.MathUtils.distance(intArray9, intArray15);
        int int19 = org.apache.commons.math.util.MathUtils.distanceInf(intArray5, intArray15);
        try {
            double double20 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test275");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.8620958891185864d, (java.lang.Number) 4.091511391485423E83d, (-1111307499));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test276");
        double double1 = org.apache.commons.math.util.FastMath.acosh(7.07423775202844E15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 37.188383274966554d + "'", double1 == 37.188383274966554d);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test277");
        double double2 = org.apache.commons.math.util.MathUtils.round(0.0d, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test278");
        double[] doubleArray3 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) (short) -1);
        double[] doubleArray7 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray5, (double) (-1L));
        double[] doubleArray14 = new double[] { (short) -1, (-1L), 1.0d, 100, '#', 'a' };
        double[] doubleArray18 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray18, (double) (short) -1);
        double[] doubleArray21 = null;
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equals(doubleArray18, doubleArray21);
        double[] doubleArray26 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, (double) (short) -1);
        double[] doubleArray32 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray32, (double) (short) -1);
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray34, (double) (-1L));
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray28, doubleArray36);
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray21, doubleArray28);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection42 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException44 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-90L), (java.lang.Number) (-1), (int) (byte) 1, orderDirection42, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray28, orderDirection42, true);
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray14, doubleArray28);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray28);
        double[] doubleArray50 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray28, (double) 1.0f);
        double[] doubleArray54 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray56 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray54, (double) (short) -1);
        double[] doubleArray60 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray62 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray60, (double) (short) -1);
        double double63 = org.apache.commons.math.util.MathUtils.distance1(doubleArray56, doubleArray60);
        double[] doubleArray67 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray69 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray67, (double) (short) -1);
        double[] doubleArray70 = null;
        boolean boolean71 = org.apache.commons.math.util.MathUtils.equals(doubleArray67, doubleArray70);
        double[] doubleArray75 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray77 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray75, (double) (short) -1);
        double[] doubleArray81 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray83 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray81, (double) (short) -1);
        double[] doubleArray85 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray83, (double) (-1L));
        boolean boolean86 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray77, doubleArray85);
        boolean boolean87 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray70, doubleArray77);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection91 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException93 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-90L), (java.lang.Number) (-1), (int) (byte) 1, orderDirection91, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray77, orderDirection91, true);
        boolean boolean96 = org.apache.commons.math.util.MathUtils.equals(doubleArray56, doubleArray77);
        double double97 = org.apache.commons.math.util.MathUtils.distance1(doubleArray28, doubleArray77);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray28);
        double double99 = org.apache.commons.math.util.MathUtils.distance(doubleArray5, doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + orderDirection42 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection42.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 63.0d + "'", double63 == 63.0d);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + true + "'", boolean86 == true);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertTrue("'" + orderDirection91 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection91.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + true + "'", boolean96 == true);
        org.junit.Assert.assertTrue("'" + double97 + "' != '" + 0.0d + "'", double97 == 0.0d);
        org.junit.Assert.assertTrue("'" + double99 + "' != '" + 0.0d + "'", double99 == 0.0d);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test279");
        long long1 = org.apache.commons.math.util.FastMath.round((-0.4480736161291702d));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test280");
        double double1 = org.apache.commons.math.util.FastMath.atan(12.21292908632666d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4890981413871636d + "'", double1 == 1.4890981413871636d);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test281");
        double double1 = org.apache.commons.math.util.FastMath.ceil(3.491921712586151d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.0d + "'", double1 == 4.0d);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test282");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) (-1249873867), (long) 52);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1249873815L) + "'", long2 == (-1249873815L));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test283");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 2455225485L, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test284");
        double double1 = org.apache.commons.math.util.FastMath.ulp(22.140692632779267d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.552713678800501E-15d + "'", double1 == 3.552713678800501E-15d);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test285");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(1077936228, (-384827391));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1462763619 + "'", int2 == 1462763619);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test286");
        float float3 = org.apache.commons.math.util.MathUtils.round((float) 4L, 626347008, (int) (byte) 0);
        org.junit.Assert.assertEquals((float) float3, Float.NaN, 0);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test287");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 1443758766, (long) 11);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1443758777L + "'", long2 == 1443758777L);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test288");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) (-6.2635002E8f), 3.6661404377193025E21d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test289");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) 1079525376);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1104156176 + "'", int1 == 1104156176);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test290");
        double[] doubleArray3 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) (short) -1);
        double[] doubleArray9 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, (double) (short) -1);
        double[] doubleArray13 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, (double) (-1L));
        double double14 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray13);
        double[] doubleArray18 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray18, (double) (short) -1);
        double[] doubleArray24 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray26 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray24, (double) (short) -1);
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, (double) (-1L));
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray28);
        double[] doubleArray33 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray35 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray33, (double) (short) -1);
        double[] doubleArray36 = null;
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equals(doubleArray33, doubleArray36);
        double[] doubleArray41 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray43 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray41, (double) (short) -1);
        double[] doubleArray47 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray49 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray47, (double) (short) -1);
        double[] doubleArray51 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray49, (double) (-1L));
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray43, doubleArray51);
        double double53 = org.apache.commons.math.util.MathUtils.distance1(doubleArray33, doubleArray43);
        boolean boolean54 = org.apache.commons.math.util.MathUtils.equals(doubleArray20, doubleArray33);
        double[] doubleArray58 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray60 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray58, (double) (short) -1);
        double[] doubleArray62 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray60, (double) (-1L));
        boolean boolean63 = org.apache.commons.math.util.MathUtils.equals(doubleArray20, doubleArray60);
        boolean boolean64 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray60);
        double[] doubleArray68 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray70 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray68, (double) (short) -1);
        double[] doubleArray74 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray76 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray74, (double) (short) -1);
        double[] doubleArray78 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray76, (double) (-1L));
        double double79 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray70, doubleArray78);
        double[] doubleArray81 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray78, (double) (short) 100);
        boolean boolean82 = org.apache.commons.math.util.MathUtils.equals(doubleArray60, doubleArray81);
        double double83 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray60);
        double[] doubleArray87 = new double[] { 97, (-1249873868L), (byte) 1 };
        double double88 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray87);
        double[] doubleArray90 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray87, 0.0d);
        double double91 = org.apache.commons.math.util.MathUtils.distance(doubleArray60, doubleArray87);
        double double92 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray87);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 63.0d + "'", double53 == 63.0d);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 0.0d + "'", double79 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + 0.8540775674112082d + "'", double83 == 0.8540775674112082d);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 1.2498738680000038E9d + "'", double88 == 1.2498738680000038E9d);
        org.junit.Assert.assertNotNull(doubleArray90);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 1.2498738678387134E9d + "'", double91 == 1.2498738678387134E9d);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 1.2498738680000038E9d + "'", double92 == 1.2498738680000038E9d);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test291");
        double double1 = org.apache.commons.math.util.FastMath.log10((-0.7853087663494568d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test292");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) 35);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test293");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round(90.0f, (-1111307499), (-738962718));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test294");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.0d, (double) 5, 97);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test295");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 11.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-225.95084645419513d) + "'", double1 == (-225.95084645419513d));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test296");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(1025.8352504981494d, (double) (-8000L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-8003.102035918916d) + "'", double2 == (-8003.102035918916d));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test297");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(3.552713678800501E-15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.200655107570901E-17d + "'", double1 == 6.200655107570901E-17d);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test298");
        double double1 = org.apache.commons.math.util.FastMath.acosh(60.60318297794051d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.797426520729394d + "'", double1 == 4.797426520729394d);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test299");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(1077936128L, (long) '#');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test300");
        long long2 = org.apache.commons.math.util.FastMath.max(5300L, (long) 1018167296);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1018167296L + "'", long2 == 1018167296L);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test301");
        double[] doubleArray3 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) (short) -1);
        double[] doubleArray9 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, (double) (short) -1);
        double[] doubleArray13 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, (double) (-1L));
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray13);
        double[] doubleArray18 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray18, (double) (short) -1);
        double[] doubleArray21 = null;
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equals(doubleArray18, doubleArray21);
        double[] doubleArray26 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, (double) (short) -1);
        double[] doubleArray32 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray32, (double) (short) -1);
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray34, (double) (-1L));
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray28, doubleArray36);
        double double38 = org.apache.commons.math.util.MathUtils.distance1(doubleArray18, doubleArray28);
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray18);
        double[] doubleArray43 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray45 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray43, (double) (short) -1);
        double[] doubleArray49 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray51 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray49, (double) (short) -1);
        double[] doubleArray53 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray51, (double) (-1L));
        boolean boolean54 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray45, doubleArray53);
        double[] doubleArray58 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray60 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray58, (double) (short) -1);
        double[] doubleArray61 = null;
        boolean boolean62 = org.apache.commons.math.util.MathUtils.equals(doubleArray58, doubleArray61);
        double[] doubleArray66 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray68 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray66, (double) (short) -1);
        double[] doubleArray72 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray74 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray72, (double) (short) -1);
        double[] doubleArray76 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray74, (double) (-1L));
        boolean boolean77 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray68, doubleArray76);
        double double78 = org.apache.commons.math.util.MathUtils.distance1(doubleArray58, doubleArray68);
        boolean boolean79 = org.apache.commons.math.util.MathUtils.equals(doubleArray45, doubleArray58);
        double[] doubleArray83 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray85 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray83, (double) (short) -1);
        double[] doubleArray87 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray85, (double) (-1L));
        boolean boolean88 = org.apache.commons.math.util.MathUtils.equals(doubleArray45, doubleArray85);
        double double89 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray18, doubleArray45);
        double[] doubleArray91 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray45, (-4.4736201199999994E8d));
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 63.0d + "'", double38 == 63.0d);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + true + "'", boolean77 == true);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 63.0d + "'", double78 == 63.0d);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + true + "'", boolean88 == true);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 52.83870967741935d + "'", double89 == 52.83870967741935d);
        org.junit.Assert.assertNotNull(doubleArray91);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test302");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(11.591953275521519d, 184331630);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.69213545324579E-198d + "'", double2 == 9.69213545324579E-198d);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test303");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(190);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test304");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, 0.0d, (double) (-1939549635));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test305");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(62.41570623524872d, 4.0532396646334464E17d, (double) 626350111L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test306");
        int int2 = org.apache.commons.math.util.FastMath.max(184331630, 461100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 184331630 + "'", int2 == 184331630);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test307");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, 8.540775674112082d, (double) 190);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test308");
        double[] doubleArray3 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) (short) -1);
        double[] doubleArray9 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, (double) (short) -1);
        double[] doubleArray13 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, (double) (-1L));
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray13);
        double[] doubleArray18 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray18, (double) (short) -1);
        double[] doubleArray21 = null;
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equals(doubleArray18, doubleArray21);
        double[] doubleArray26 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, (double) (short) -1);
        double[] doubleArray32 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray32, (double) (short) -1);
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray34, (double) (-1L));
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray28, doubleArray36);
        double double38 = org.apache.commons.math.util.MathUtils.distance1(doubleArray18, doubleArray28);
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray18);
        double[] doubleArray43 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray45 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray43, (double) (short) -1);
        double[] doubleArray47 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray45, (double) (-1L));
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray45);
        double[] doubleArray52 = new double[] { (-35L), 1.3043045862358962d, '#' };
        double double53 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray52);
        java.lang.Class<?> wildcardClass54 = doubleArray5.getClass();
        double[] doubleArray56 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray5, 32.0d);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 63.0d + "'", double38 == 63.0d);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 70.62688523139718d + "'", double53 == 70.62688523139718d);
        org.junit.Assert.assertNotNull(wildcardClass54);
        org.junit.Assert.assertNotNull(doubleArray56);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test309");
        double double1 = org.apache.commons.math.util.FastMath.cos(22.140692632779267d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9888391103323168d) + "'", double1 == (-0.9888391103323168d));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test310");
        double[] doubleArray3 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) (short) -1);
        double[] doubleArray9 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, (double) (short) -1);
        double double12 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray9);
        double[] doubleArray16 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, (double) (short) -1);
        double[] doubleArray19 = null;
        boolean boolean20 = org.apache.commons.math.util.MathUtils.equals(doubleArray16, doubleArray19);
        double[] doubleArray24 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray26 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray24, (double) (short) -1);
        double[] doubleArray30 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray30, (double) (short) -1);
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray32, (double) (-1L));
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray26, doubleArray34);
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray26);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection40 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException42 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-90L), (java.lang.Number) (-1), (int) (byte) 1, orderDirection40, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray26, orderDirection40, true);
        boolean boolean45 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray26);
        double double46 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray26);
        int int47 = org.apache.commons.math.util.MathUtils.hash(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 63.0d + "'", double12 == 63.0d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + orderDirection40 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection40.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.8540775674112082d + "'", double46 == 0.8540775674112082d);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1249873867) + "'", int47 == (-1249873867));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test311");
        double[] doubleArray3 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) (short) -1);
        double[] doubleArray9 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, (double) (short) -1);
        double[] doubleArray13 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, (double) (-1L));
        double double14 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray13);
        double[] doubleArray18 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray18, (double) (short) -1);
        double[] doubleArray24 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray26 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray24, (double) (short) -1);
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, (double) (-1L));
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray28);
        double[] doubleArray33 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray35 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray33, (double) (short) -1);
        double[] doubleArray36 = null;
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equals(doubleArray33, doubleArray36);
        double[] doubleArray41 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray43 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray41, (double) (short) -1);
        double[] doubleArray47 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray49 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray47, (double) (short) -1);
        double[] doubleArray51 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray49, (double) (-1L));
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray43, doubleArray51);
        double double53 = org.apache.commons.math.util.MathUtils.distance1(doubleArray33, doubleArray43);
        boolean boolean54 = org.apache.commons.math.util.MathUtils.equals(doubleArray20, doubleArray33);
        double[] doubleArray58 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray60 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray58, (double) (short) -1);
        double[] doubleArray62 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray60, (double) (-1L));
        boolean boolean63 = org.apache.commons.math.util.MathUtils.equals(doubleArray20, doubleArray60);
        boolean boolean64 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray60);
        double[] doubleArray68 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray70 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray68, (double) (short) -1);
        double[] doubleArray74 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray76 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray74, (double) (short) -1);
        double[] doubleArray78 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray76, (double) (-1L));
        double double79 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray70, doubleArray78);
        double[] doubleArray81 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray78, (double) (short) 100);
        boolean boolean82 = org.apache.commons.math.util.MathUtils.equals(doubleArray60, doubleArray81);
        double double83 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray60);
        double[] doubleArray87 = new double[] { 97, (-1249873868L), (byte) 1 };
        double double88 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray87);
        double[] doubleArray90 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray87, 0.0d);
        double double91 = org.apache.commons.math.util.MathUtils.distance(doubleArray60, doubleArray87);
        int int92 = org.apache.commons.math.util.MathUtils.hash(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 63.0d + "'", double53 == 63.0d);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 0.0d + "'", double79 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + 0.8540775674112082d + "'", double83 == 0.8540775674112082d);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 1.2498738680000038E9d + "'", double88 == 1.2498738680000038E9d);
        org.junit.Assert.assertNotNull(doubleArray90);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 1.2498738678387134E9d + "'", double91 == 1.2498738678387134E9d);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + (-1249873867) + "'", int92 == (-1249873867));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test312");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(626347008, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 626347007 + "'", int2 == 626347007);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test313");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.5596856728972892d), (java.lang.Number) 200L, 1077936128);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException7 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 1L, (int) (short) 10);
        int int8 = nonMonotonousSequenceException7.getIndex();
        java.lang.Class<?> wildcardClass9 = nonMonotonousSequenceException7.getClass();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = nonMonotonousSequenceException7.getDirection();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException7);
        java.lang.Throwable[] throwableArray12 = nonMonotonousSequenceException3.getSuppressed();
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray12);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test314");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(3.8834864931005E-310d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.225073858507205E-308d + "'", double1 == 2.225073858507205E-308d);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test315");
        float float2 = org.apache.commons.math.util.FastMath.max(0.0f, (float) 1000L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1000.0f + "'", float2 == 1000.0f);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test316");
        int int2 = org.apache.commons.math.util.FastMath.max(0, (-319948472));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test317");
        double double2 = org.apache.commons.math.util.MathUtils.log(0.0d, (-719.2542281009917d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test318");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test319");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 1.07479027E9f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.158094644731777E10d + "'", double1 == 6.158094644731777E10d);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test320");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((-30.422048691765244d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-3.121735853711036d) + "'", double1 == (-3.121735853711036d));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test321");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((-0.14695139943744212d), (double) 2025509786, 87);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test322");
        double[] doubleArray3 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) (short) -1);
        double[] doubleArray7 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray5, (double) (-1L));
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray5);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1249873867) + "'", int8 == (-1249873867));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test323");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(1.5860134523134298E15d, 5.220411530638642d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test324");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(291, (-552));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 53544 + "'", int2 == 53544);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test325");
        long long1 = org.apache.commons.math.util.FastMath.abs(38833706262L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 38833706262L + "'", long1 == 38833706262L);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test326");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (-1444685106L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1444685056) + "'", int1 == (-1444685056));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test327");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((-1.6121855999999998E10d), 3.1039830278823013d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test328");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 4);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test329");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(2.3458247401995457E41d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test330");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 3L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.017874927409903d + "'", double1 == 10.017874927409903d);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test331");
        long long2 = org.apache.commons.math.util.FastMath.max(3578896096L, (-190L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3578896096L + "'", long2 == 3578896096L);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test332");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((-626350101), (-3));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-626350098) + "'", int2 == (-626350098));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test333");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 7499243202L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test334");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-90L), (java.lang.Number) (-1), (int) (byte) 1, orderDirection3, false);
        java.lang.Class<?> wildcardClass6 = nonMonotonousSequenceException5.getClass();
        int int7 = nonMonotonousSequenceException5.getIndex();
        java.lang.String str8 = nonMonotonousSequenceException5.toString();
        int int9 = nonMonotonousSequenceException5.getIndex();
        java.lang.Number number10 = nonMonotonousSequenceException5.getPrevious();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > -90)" + "'", str8.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > -90)"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + (-1) + "'", number10.equals((-1)));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test335");
        double double1 = org.apache.commons.math.util.FastMath.ceil(1.249873866232524E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.249873867E9d + "'", double1 == 1.249873867E9d);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test336");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 97.0d, (java.lang.Number) 200L, 4);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray4);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test337");
        int[] intArray0 = new int[] {};
        int[] intArray1 = new int[] {};
        int int2 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray1);
        int[] intArray3 = new int[] {};
        int[] intArray4 = new int[] {};
        int int5 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray4);
        int int6 = org.apache.commons.math.util.MathUtils.distance1(intArray1, intArray4);
        int[] intArray7 = new int[] {};
        int[] intArray8 = new int[] {};
        int int9 = org.apache.commons.math.util.MathUtils.distance1(intArray7, intArray8);
        int[] intArray10 = new int[] {};
        int[] intArray11 = new int[] {};
        int int12 = org.apache.commons.math.util.MathUtils.distance1(intArray10, intArray11);
        int int13 = org.apache.commons.math.util.MathUtils.distance1(intArray8, intArray11);
        int[] intArray14 = new int[] {};
        int[] intArray15 = new int[] {};
        int int16 = org.apache.commons.math.util.MathUtils.distance1(intArray14, intArray15);
        int int17 = org.apache.commons.math.util.MathUtils.distance1(intArray11, intArray14);
        int int18 = org.apache.commons.math.util.MathUtils.distance1(intArray4, intArray14);
        java.lang.Class<?> wildcardClass19 = intArray14.getClass();
        int[] intArray20 = new int[] {};
        int int21 = org.apache.commons.math.util.MathUtils.distanceInf(intArray14, intArray20);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test338");
        int[] intArray0 = null;
        int[] intArray1 = new int[] {};
        int[] intArray2 = new int[] {};
        int int3 = org.apache.commons.math.util.MathUtils.distance1(intArray1, intArray2);
        int[] intArray4 = new int[] {};
        int[] intArray5 = new int[] {};
        int int6 = org.apache.commons.math.util.MathUtils.distance1(intArray4, intArray5);
        int int7 = org.apache.commons.math.util.MathUtils.distance1(intArray2, intArray5);
        int[] intArray8 = new int[] {};
        int[] intArray9 = new int[] {};
        int int10 = org.apache.commons.math.util.MathUtils.distance1(intArray8, intArray9);
        double double11 = org.apache.commons.math.util.MathUtils.distance(intArray2, intArray8);
        try {
            int int12 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test339");
        double double1 = org.apache.commons.math.util.FastMath.atanh((-8.18408496E8d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test340");
        double double2 = org.apache.commons.math.util.MathUtils.round(4.9095649975716696E-8d, 970);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.9095649975716696E-8d + "'", double2 == 4.9095649975716696E-8d);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test341");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (short) 0, (int) ' ');
        int int4 = nonMonotonousSequenceException3.getIndex();
        boolean boolean5 = nonMonotonousSequenceException3.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-90L), (java.lang.Number) (-1), (int) (byte) 1, orderDirection9, false);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = nonMonotonousSequenceException11.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException17 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (short) 0, (int) ' ');
        int int18 = nonMonotonousSequenceException17.getIndex();
        boolean boolean19 = nonMonotonousSequenceException17.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection23 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException25 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-90L), (java.lang.Number) (-1), (int) (byte) 1, orderDirection23, false);
        nonMonotonousSequenceException17.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException25);
        int int27 = nonMonotonousSequenceException17.getIndex();
        nonMonotonousSequenceException11.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException17);
        boolean boolean29 = nonMonotonousSequenceException11.getStrict();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 32 + "'", int4 == 32);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection13 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection13.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 32 + "'", int18 == 32);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + orderDirection23 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection23.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 32 + "'", int27 == 32);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test342");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) (-1111307509), (-108640L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 120732447777760L + "'", long2 == 120732447777760L);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test343");
        long long2 = org.apache.commons.math.util.FastMath.max(0L, (long) (short) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test344");
        double double1 = org.apache.commons.math.util.MathUtils.sign(1.6515326554570007E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test345");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 363.7393755555636d + "'", double1 == 363.7393755555636d);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test346");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) (short) 1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test347");
        int[] intArray0 = new int[] {};
        int[] intArray1 = new int[] {};
        int int2 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray1);
        int[] intArray3 = new int[] {};
        int[] intArray4 = new int[] {};
        int int5 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray4);
        int int6 = org.apache.commons.math.util.MathUtils.distance1(intArray1, intArray4);
        int[] intArray7 = new int[] {};
        int[] intArray8 = new int[] {};
        int int9 = org.apache.commons.math.util.MathUtils.distance1(intArray7, intArray8);
        int[] intArray10 = new int[] {};
        int[] intArray11 = new int[] {};
        int int12 = org.apache.commons.math.util.MathUtils.distance1(intArray10, intArray11);
        int int13 = org.apache.commons.math.util.MathUtils.distance1(intArray8, intArray11);
        int[] intArray14 = new int[] {};
        int[] intArray15 = new int[] {};
        int int16 = org.apache.commons.math.util.MathUtils.distance1(intArray14, intArray15);
        double double17 = org.apache.commons.math.util.MathUtils.distance(intArray8, intArray14);
        int int18 = org.apache.commons.math.util.MathUtils.distanceInf(intArray4, intArray14);
        int[] intArray19 = new int[] {};
        int[] intArray20 = new int[] {};
        int int21 = org.apache.commons.math.util.MathUtils.distance1(intArray19, intArray20);
        int[] intArray22 = new int[] {};
        int[] intArray23 = new int[] {};
        int int24 = org.apache.commons.math.util.MathUtils.distance1(intArray22, intArray23);
        int int25 = org.apache.commons.math.util.MathUtils.distance1(intArray20, intArray23);
        int int26 = org.apache.commons.math.util.MathUtils.distance1(intArray4, intArray20);
        int[] intArray27 = new int[] {};
        int[] intArray28 = new int[] {};
        int int29 = org.apache.commons.math.util.MathUtils.distance1(intArray27, intArray28);
        int[] intArray30 = new int[] {};
        int[] intArray31 = new int[] {};
        int int32 = org.apache.commons.math.util.MathUtils.distance1(intArray30, intArray31);
        int int33 = org.apache.commons.math.util.MathUtils.distance1(intArray28, intArray31);
        int[] intArray34 = new int[] {};
        int[] intArray35 = new int[] {};
        int int36 = org.apache.commons.math.util.MathUtils.distance1(intArray34, intArray35);
        int int37 = org.apache.commons.math.util.MathUtils.distance1(intArray31, intArray34);
        int int38 = org.apache.commons.math.util.MathUtils.distanceInf(intArray20, intArray31);
        int[] intArray39 = new int[] {};
        int[] intArray40 = new int[] {};
        int int41 = org.apache.commons.math.util.MathUtils.distance1(intArray39, intArray40);
        int[] intArray42 = new int[] {};
        int[] intArray43 = new int[] {};
        int int44 = org.apache.commons.math.util.MathUtils.distance1(intArray42, intArray43);
        int int45 = org.apache.commons.math.util.MathUtils.distance1(intArray40, intArray43);
        int int46 = org.apache.commons.math.util.MathUtils.distanceInf(intArray31, intArray40);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test348");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 461100, (long) (-626350111));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-625889011L) + "'", long2 == (-625889011L));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test349");
        double[] doubleArray6 = new double[] { (short) -1, (-1L), 1.0d, 100, '#', 'a' };
        double[] doubleArray10 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray10, (double) (short) -1);
        double[] doubleArray13 = null;
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equals(doubleArray10, doubleArray13);
        double[] doubleArray18 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray18, (double) (short) -1);
        double[] doubleArray24 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray26 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray24, (double) (short) -1);
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, (double) (-1L));
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray28);
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray13, doubleArray20);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection34 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException36 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-90L), (java.lang.Number) (-1), (int) (byte) 1, orderDirection34, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray20, orderDirection34, true);
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray20);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray20);
        double[] doubleArray42 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray20, (double) 1.0f);
        double[] doubleArray46 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray48 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray46, (double) (short) -1);
        double[] doubleArray49 = null;
        boolean boolean50 = org.apache.commons.math.util.MathUtils.equals(doubleArray46, doubleArray49);
        double[] doubleArray54 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray56 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray54, (double) (short) -1);
        double[] doubleArray60 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray62 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray60, (double) (short) -1);
        double[] doubleArray64 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray62, (double) (-1L));
        boolean boolean65 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray56, doubleArray64);
        boolean boolean66 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray49, doubleArray56);
        java.lang.Number number68 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection73 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException75 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-90L), (java.lang.Number) (-1), (int) (byte) 1, orderDirection73, false);
        java.lang.Class<?> wildcardClass76 = nonMonotonousSequenceException75.getClass();
        int int77 = nonMonotonousSequenceException75.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection78 = nonMonotonousSequenceException75.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException80 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 3, number68, (int) 'a', orderDirection78, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray56, orderDirection78, true);
        boolean boolean83 = org.apache.commons.math.util.MathUtils.equals(doubleArray20, doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + orderDirection34 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection34.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + orderDirection73 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection73.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass76);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 1 + "'", int77 == 1);
        org.junit.Assert.assertTrue("'" + orderDirection78 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection78.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + true + "'", boolean83 == true);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test350");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(52.99999999999999d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.756285754221072d + "'", double1 == 3.756285754221072d);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test351");
        double double2 = org.apache.commons.math.util.FastMath.max(50.346573590279974d, (double) 438727775L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.38727775E8d + "'", double2 == 4.38727775E8d);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test352");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 1074790400);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test353");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-90L), (java.lang.Number) (-1), (int) (byte) 1, orderDirection6, false);
        java.lang.Class<?> wildcardClass9 = nonMonotonousSequenceException8.getClass();
        int int10 = nonMonotonousSequenceException8.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = nonMonotonousSequenceException8.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.5596856728972892d), (java.lang.Number) (-0.5063656411097588d), (int) 'a', orderDirection11, false);
        java.lang.Throwable[] throwableArray14 = nonMonotonousSequenceException13.getSuppressed();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + orderDirection11 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection11.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray14);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test354");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5063656411097588d) + "'", double1 == (-0.5063656411097588d));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test355");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 3104);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test356");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (short) 0, (int) ' ');
        int int4 = nonMonotonousSequenceException3.getIndex();
        boolean boolean5 = nonMonotonousSequenceException3.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-90L), (java.lang.Number) (-1), (int) (byte) 1, orderDirection9, false);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        int int13 = nonMonotonousSequenceException3.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection17 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-90L), (java.lang.Number) (-1), (int) (byte) 1, orderDirection17, false);
        java.lang.Class<?> wildcardClass20 = nonMonotonousSequenceException19.getClass();
        int int21 = nonMonotonousSequenceException19.getIndex();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException25 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 1L, (int) (short) 10);
        java.lang.Class<?> wildcardClass26 = nonMonotonousSequenceException25.getClass();
        nonMonotonousSequenceException19.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException25);
        java.lang.Class<?> wildcardClass28 = nonMonotonousSequenceException19.getClass();
        int int29 = nonMonotonousSequenceException19.getIndex();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException19);
        java.lang.String str31 = nonMonotonousSequenceException3.toString();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 32 + "'", int4 == 32);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 32 + "'", int13 == 32);
        org.junit.Assert.assertTrue("'" + orderDirection17 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection17.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 31 and 32 are not strictly increasing (0 >= 0)" + "'", str31.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 31 and 32 are not strictly increasing (0 >= 0)"));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test357");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 461100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test358");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 1L, (int) (short) 10);
        int int4 = nonMonotonousSequenceException3.getIndex();
        java.lang.Class<?> wildcardClass5 = nonMonotonousSequenceException3.getClass();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException3.getDirection();
        java.lang.Throwable[] throwableArray7 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Number number8 = nonMonotonousSequenceException3.getArgument();
        java.lang.Class<?> wildcardClass9 = nonMonotonousSequenceException3.getClass();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 0.0f + "'", number8.equals(0.0f));
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test359");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 190L, (java.lang.Number) 9.332621544395286E157d, (int) (byte) 100, orderDirection6, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-125687604222L), (java.lang.Number) 2.0634370688955608d, (int) '#', orderDirection6, true);
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test360");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(1.0d, 292.6238069569971d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test361");
        int int1 = org.apache.commons.math.util.MathUtils.sign((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test362");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (-626350101), (double) 461100, (-6.731094208094568d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test363");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((int) (short) 100, 5);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.528752E7d + "'", double2 == 7.528752E7d);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test364");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(89.09061955080085d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5104.516494466587d + "'", double1 == 5104.516494466587d);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test365");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(1074790400, 1079525376);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test366");
        double double1 = org.apache.commons.math.util.FastMath.tan(1.5118468524217406d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 16.944025291760045d + "'", double1 == 16.944025291760045d);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test367");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 184331631L, (-3.046035901772458E-4d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.8433163099999997E8d + "'", double2 == 1.8433163099999997E8d);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test368");
        float float2 = org.apache.commons.math.util.MathUtils.round(1.44468506E9f, 626347007);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test369");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((-1.2334031175112168d), 1.2498738678387134E9d, (-30.422048691765244d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test370");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, (-2.976789725572886E-254d), 14.154262241479262d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test371");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((-2.378849044627155E-271d), 0.0174532925199433d, (double) 0L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test372");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.105427357601002E-15d + "'", double1 == 7.105427357601002E-15d);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test373");
        double double2 = org.apache.commons.math.util.FastMath.min((-30.0d), (double) (-738962718L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-7.38962718E8d) + "'", double2 == (-7.38962718E8d));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test374");
        double double1 = org.apache.commons.math.util.FastMath.log10(12600.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.1003705451175625d + "'", double1 == 4.1003705451175625d);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test375");
        double[] doubleArray3 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) (short) -1);
        double[] doubleArray7 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray5, (double) (-1L));
        double[] doubleArray11 = new double[] { 3.1909099185344844E-8d, 156.3608363030788d, 1079525376 };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray11);
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray11);
        double[] doubleArray17 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray17, (double) (short) -1);
        double[] doubleArray23 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray25 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray23, (double) (short) -1);
        double[] doubleArray27 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, (double) (-1L));
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray27);
        double double29 = org.apache.commons.math.util.MathUtils.distance(doubleArray11, doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0795253760000114E9d + "'", double13 == 1.0795253760000114E9d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.0795253760000114E9d + "'", double29 == 1.0795253760000114E9d);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test376");
        double[] doubleArray3 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) (short) -1);
        double[] doubleArray9 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, (double) (short) -1);
        double[] doubleArray13 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, (double) (-1L));
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray13);
        double[] doubleArray18 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray18, (double) (short) -1);
        double[] doubleArray21 = null;
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equals(doubleArray18, doubleArray21);
        double[] doubleArray26 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, (double) (short) -1);
        double[] doubleArray32 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray32, (double) (short) -1);
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray34, (double) (-1L));
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray28, doubleArray36);
        double double38 = org.apache.commons.math.util.MathUtils.distance1(doubleArray18, doubleArray28);
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray18);
        double[] doubleArray43 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray45 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray43, (double) (short) -1);
        double[] doubleArray47 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray45, (double) (-1L));
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray45);
        double[] doubleArray50 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray45, (double) (-1.0f));
        double[] doubleArray54 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray56 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray54, (double) (short) -1);
        double[] doubleArray57 = null;
        boolean boolean58 = org.apache.commons.math.util.MathUtils.equals(doubleArray54, doubleArray57);
        double[] doubleArray62 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray64 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray62, (double) (short) -1);
        double[] doubleArray68 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray70 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray68, (double) (short) -1);
        double[] doubleArray72 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray70, (double) (-1L));
        boolean boolean73 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray64, doubleArray72);
        boolean boolean74 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray57, doubleArray64);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection78 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException80 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-90L), (java.lang.Number) (-1), (int) (byte) 1, orderDirection78, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray64, orderDirection78, true);
        double double83 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray45, doubleArray64);
        int int84 = org.apache.commons.math.util.MathUtils.hash(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 63.0d + "'", double38 == 63.0d);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + true + "'", boolean73 == true);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertTrue("'" + orderDirection78 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection78.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + 0.0d + "'", double83 == 0.0d);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + (-1249873867) + "'", int84 == (-1249873867));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test377");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(3.103983027882299d, 3.103659978354832d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.1039830278822986d + "'", double2 == 3.1039830278822986d);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test378");
        int int1 = org.apache.commons.math.util.FastMath.abs((-626347007));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 626347007 + "'", int1 == 626347007);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test379");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((-4.47362012E8d), 87, 12600);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test380");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 3578896096L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test381");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 7499243202L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.499243202E9d + "'", double1 == 7.499243202E9d);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test382");
        int int2 = org.apache.commons.math.util.FastMath.min((-1939549635), 87);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1939549635) + "'", int2 == (-1939549635));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test383");
        double[] doubleArray3 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) (short) -1);
        double[] doubleArray9 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, (double) (short) -1);
        double[] doubleArray13 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, (double) (-1L));
        double double14 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray13);
        double[] doubleArray21 = new double[] { (short) -1, (-1L), 1.0d, 100, '#', 'a' };
        double[] doubleArray25 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray27 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, (double) (short) -1);
        double[] doubleArray28 = null;
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equals(doubleArray25, doubleArray28);
        double[] doubleArray33 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray35 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray33, (double) (short) -1);
        double[] doubleArray39 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray41 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray39, (double) (short) -1);
        double[] doubleArray43 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray41, (double) (-1L));
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray35, doubleArray43);
        boolean boolean45 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray28, doubleArray35);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection49 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException51 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-90L), (java.lang.Number) (-1), (int) (byte) 1, orderDirection49, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray35, orderDirection49, true);
        boolean boolean54 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray21, doubleArray35);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray35);
        double[] doubleArray59 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray61 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray59, (double) (short) -1);
        double[] doubleArray65 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray67 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray65, (double) (short) -1);
        double[] doubleArray69 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray67, (double) (-1L));
        boolean boolean70 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray61, doubleArray69);
        double[] doubleArray72 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray69, 10.0d);
        double double73 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray69);
        double double74 = org.apache.commons.math.util.MathUtils.distance1(doubleArray35, doubleArray69);
        boolean boolean75 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray69);
        double double76 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + orderDirection49 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection49.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.8540775674112082d + "'", double73 == 0.8540775674112082d);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 0.0d + "'", double74 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + true + "'", boolean75 == true);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.8540775674112082d + "'", double76 == 0.8540775674112082d);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test384");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 1321600470);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3216004700000002E9d + "'", double1 == 1.3216004700000002E9d);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test385");
        double double1 = org.apache.commons.math.util.FastMath.tan(3.1039830278823013d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.03762736848356599d) + "'", double1 == (-0.03762736848356599d));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test386");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, (double) 3104.0f, 9.869604401089356d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test387");
        int int1 = org.apache.commons.math.util.MathUtils.sign((-319948472));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test388");
        long long1 = org.apache.commons.math.util.FastMath.round(0.6d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test389");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test390");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(92.50245035569947d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.617819417918984d + "'", double1 == 9.617819417918984d);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test391");
        long long1 = org.apache.commons.math.util.FastMath.round((-57.29577951308232d));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-57L) + "'", long1 == (-57L));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test392");
        double[] doubleArray6 = new double[] { (short) -1, (-1L), 1.0d, 100, '#', 'a' };
        double[] doubleArray10 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray10, (double) (short) -1);
        double[] doubleArray13 = null;
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equals(doubleArray10, doubleArray13);
        double[] doubleArray18 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray18, (double) (short) -1);
        double[] doubleArray24 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray26 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray24, (double) (short) -1);
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, (double) (-1L));
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray28);
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray13, doubleArray20);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection34 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException36 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-90L), (java.lang.Number) (-1), (int) (byte) 1, orderDirection34, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray20, orderDirection34, true);
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray20);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray20);
        double[] doubleArray42 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray20, (-0.8813735870195429d));
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + orderDirection34 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection34.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(doubleArray42);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test393");
        int int2 = org.apache.commons.math.util.MathUtils.pow(12600, 0L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test394");
        double double1 = org.apache.commons.math.util.FastMath.atan((-0.017452500141688768d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.01745072851449906d) + "'", double1 == (-0.01745072851449906d));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test395");
        double[] doubleArray3 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) (short) -1);
        int int6 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 438727775 + "'", int6 == 438727775);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test396");
        double double1 = org.apache.commons.math.util.FastMath.log(3.103659978354832d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.132582053264905d + "'", double1 == 1.132582053264905d);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test397");
        double double1 = org.apache.commons.math.util.FastMath.ceil(4.091511391485423E83d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.091511391485423E83d + "'", double1 == 4.091511391485423E83d);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test398");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) (-1249873867), (-0.48500216304847765d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test399");
        int int1 = org.apache.commons.math.util.FastMath.round((-58.0f));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-58) + "'", int1 == (-58));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test400");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((-1074790400), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1074790400) + "'", int2 == (-1074790400));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test401");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 52);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test402");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 1111307509, (-626350014L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1737657523L + "'", long2 == 1737657523L);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test403");
        double[] doubleArray6 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) (short) -1);
        double[] doubleArray9 = null;
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray9);
        double[] doubleArray14 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray14, (double) (short) -1);
        double[] doubleArray20 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray20, (double) (short) -1);
        double[] doubleArray24 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray22, (double) (-1L));
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray16, doubleArray24);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray9, doubleArray16);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection30 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException32 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-90L), (java.lang.Number) (-1), (int) (byte) 1, orderDirection30, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray16, orderDirection30, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException36 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 900L, (java.lang.Number) 1.5430806348152437d, (-1869155406), orderDirection30, true);
        java.lang.Number number37 = nonMonotonousSequenceException36.getPrevious();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + orderDirection30 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection30.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number37 + "' != '" + 1.5430806348152437d + "'", number37.equals(1.5430806348152437d));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test404");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-552), (float) 728967041);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 7.2896704E8f + "'", float2 == 7.2896704E8f);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test405");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (-738962718));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 738962718L + "'", long1 == 738962718L);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test406");
        double[] doubleArray3 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) (short) -1);
        double[] doubleArray9 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, (double) (short) -1);
        double[] doubleArray13 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, (double) (-1L));
        double double14 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray13);
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray13, (double) (short) 100);
        double[] doubleArray20 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray20, (double) (short) -1);
        double[] doubleArray24 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray22, (double) (-1L));
        double[] doubleArray28 = new double[] { 3.1909099185344844E-8d, 156.3608363030788d, 1079525376 };
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equals(doubleArray22, doubleArray28);
        double[] doubleArray33 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray35 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray33, (double) (short) -1);
        double[] doubleArray39 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray41 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray39, (double) (short) -1);
        double[] doubleArray45 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray47 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray45, (double) (short) -1);
        double double48 = org.apache.commons.math.util.MathUtils.distance1(doubleArray41, doubleArray45);
        double double49 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray33, doubleArray45);
        double[] doubleArray53 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray55 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray53, (double) (short) -1);
        double[] doubleArray59 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray61 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray59, (double) (short) -1);
        double[] doubleArray63 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray61, (double) (-1L));
        boolean boolean64 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray55, doubleArray63);
        double[] doubleArray66 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray63, 10.0d);
        double double67 = org.apache.commons.math.util.MathUtils.distance1(doubleArray45, doubleArray66);
        double double68 = org.apache.commons.math.util.MathUtils.distance1(doubleArray28, doubleArray45);
        double double69 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray13, doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 63.0d + "'", double48 == 63.0d);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 52.0d + "'", double67 == 52.0d);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 1.0795255743608363E9d + "'", double68 == 1.0795255743608363E9d);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 1.079525376E9d + "'", double69 == 1.079525376E9d);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test407");
        double[] doubleArray6 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) (short) -1);
        double[] doubleArray9 = null;
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray9);
        double[] doubleArray14 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray14, (double) (short) -1);
        double[] doubleArray20 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray20, (double) (short) -1);
        double[] doubleArray24 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray22, (double) (-1L));
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray16, doubleArray24);
        double double26 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray16);
        double[] doubleArray30 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray30, (double) (short) -1);
        double[] doubleArray33 = null;
        boolean boolean34 = org.apache.commons.math.util.MathUtils.equals(doubleArray30, doubleArray33);
        double[] doubleArray38 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray40 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray38, (double) (short) -1);
        double[] doubleArray44 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray44, (double) (short) -1);
        double[] doubleArray48 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray46, (double) (-1L));
        boolean boolean49 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray40, doubleArray48);
        boolean boolean50 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray33, doubleArray40);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection54 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException56 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-90L), (java.lang.Number) (-1), (int) (byte) 1, orderDirection54, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray40, orderDirection54, true);
        double double59 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray6, doubleArray40);
        double[] doubleArray63 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray65 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray63, (double) (short) -1);
        double[] doubleArray67 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray65, (double) (-1L));
        double[] doubleArray71 = new double[] { 3.1909099185344844E-8d, 156.3608363030788d, 1079525376 };
        boolean boolean72 = org.apache.commons.math.util.MathUtils.equals(doubleArray65, doubleArray71);
        boolean boolean73 = org.apache.commons.math.util.MathUtils.equals(doubleArray40, doubleArray65);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection77 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException79 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-3), (java.lang.Number) 10.0f, 970, orderDirection77, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray40, orderDirection77, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException83 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.010256138689425936d, (java.lang.Number) 160, 100, orderDirection77, false);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 63.0d + "'", double26 == 63.0d);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + orderDirection54 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection54.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 52.83870967741935d + "'", double59 == 52.83870967741935d);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + true + "'", boolean73 == true);
        org.junit.Assert.assertTrue("'" + orderDirection77 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection77.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test408");
        int int2 = org.apache.commons.math.util.FastMath.min(447362012, 1077936228);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 447362012 + "'", int2 == 447362012);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test409");
        double double2 = org.apache.commons.math.util.FastMath.pow((-0.7970546072131425d), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test410");
        float float1 = org.apache.commons.math.util.MathUtils.sign((-1.0747904E9f));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test411");
        int int2 = org.apache.commons.math.util.FastMath.max((-447362047), (-738962753));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-447362047) + "'", int2 == (-447362047));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test412");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(20.085536923187668d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.35055875134051623d + "'", double1 == 0.35055875134051623d);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test413");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(0.9866689310383728d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test414");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.027712143770207958d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.02770859692329688d + "'", double1 == 0.02770859692329688d);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test415");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) 90L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1079410688 + "'", int1 == 1079410688);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test416");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) 438727775, (int) (byte) -1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test417");
        double double1 = org.apache.commons.math.util.FastMath.sinh(4.691649480399091E41d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test418");
        double double2 = org.apache.commons.math.util.MathUtils.log(11.940141468803501d, (double) 1391070465L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 8.489571692727287d + "'", double2 == 8.489571692727287d);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test419");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, 0.960537576151187d, (double) 673194921331114242L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test420");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(2.319927837136307E180d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test421");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(2559.6567728894133d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 13.679196181398032d + "'", double1 == 13.679196181398032d);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test422");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (short) 0, (int) (short) 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection5 = nonMonotonousSequenceException3.getDirection();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0L + "'", number4.equals(0L));
        org.junit.Assert.assertTrue("'" + orderDirection5 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection5.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test423");
        long long1 = org.apache.commons.math.util.MathUtils.sign(3578896096L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test424");
        double[] doubleArray3 = new double[] { 97, (-1249873868L), (byte) 1 };
        double double4 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double[] doubleArray6 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, 0.0d);
        double[] doubleArray10 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray10, (double) (short) -1);
        double[] doubleArray16 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, (double) (short) -1);
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray18, (double) (-1L));
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray20);
        double[] doubleArray23 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray20, 10.0d);
        double[] doubleArray27 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, (double) (short) -1);
        double[] doubleArray33 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray35 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray33, (double) (short) -1);
        double[] doubleArray37 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray35, (double) (-1L));
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray29, doubleArray37);
        double[] doubleArray42 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray44 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray42, (double) (short) -1);
        double[] doubleArray45 = null;
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equals(doubleArray42, doubleArray45);
        double[] doubleArray50 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray52 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray50, (double) (short) -1);
        double[] doubleArray56 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray58 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray56, (double) (short) -1);
        double[] doubleArray60 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray58, (double) (-1L));
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray52, doubleArray60);
        double double62 = org.apache.commons.math.util.MathUtils.distance1(doubleArray42, doubleArray52);
        boolean boolean63 = org.apache.commons.math.util.MathUtils.equals(doubleArray29, doubleArray42);
        double[] doubleArray67 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray69 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray67, (double) (short) -1);
        double[] doubleArray71 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray69, (double) (-1L));
        boolean boolean72 = org.apache.commons.math.util.MathUtils.equals(doubleArray29, doubleArray69);
        double[] doubleArray76 = new double[] { (-35L), 1.3043045862358962d, '#' };
        double double77 = org.apache.commons.math.util.MathUtils.distance1(doubleArray29, doubleArray76);
        boolean boolean78 = org.apache.commons.math.util.MathUtils.equals(doubleArray23, doubleArray29);
        double double79 = org.apache.commons.math.util.MathUtils.distance(doubleArray6, doubleArray23);
        int int80 = org.apache.commons.math.util.MathUtils.hash(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.2498738680000038E9d + "'", double4 == 1.2498738680000038E9d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 63.0d + "'", double62 == 63.0d);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 70.62688523139718d + "'", double77 == 70.62688523139718d);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 8.540775674112082d + "'", double79 == 8.540775674112082d);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + (-1953992327) + "'", int80 == (-1953992327));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test425");
        int int2 = org.apache.commons.math.util.FastMath.min((-626350101), (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-626350101) + "'", int2 == (-626350101));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test426");
        double double1 = org.apache.commons.math.util.FastMath.tan((-0.9999999999948909d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5574077246374007d) + "'", double1 == (-1.5574077246374007d));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test427");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) -1 + "'", short1 == (short) -1);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test428");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) 0, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test429");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((-1.0f));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test430");
        double double3 = org.apache.commons.math.util.MathUtils.round((-1.5596856728972892d), 10, 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.5596856729d) + "'", double3 == (-1.5596856729d));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test431");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) 5, 4189586807400L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 20947934037000L + "'", long2 == 20947934037000L);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test432");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 90L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.192925985263684d + "'", double1 == 5.192925985263684d);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test433");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 2025509786, (double) (-626350098));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.8707001224293311d + "'", double2 == 1.8707001224293311d);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test434");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(1, (-447362012));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test435");
        int int2 = org.apache.commons.math.util.FastMath.max((-738962718), 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test436");
        int[] intArray0 = new int[] {};
        int[] intArray1 = new int[] {};
        int int2 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray1);
        int[] intArray3 = new int[] {};
        int[] intArray4 = new int[] {};
        int int5 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray4);
        int int6 = org.apache.commons.math.util.MathUtils.distance1(intArray1, intArray4);
        int[] intArray7 = new int[] {};
        int[] intArray8 = new int[] {};
        int int9 = org.apache.commons.math.util.MathUtils.distance1(intArray7, intArray8);
        int[] intArray10 = new int[] {};
        int[] intArray11 = new int[] {};
        int int12 = org.apache.commons.math.util.MathUtils.distance1(intArray10, intArray11);
        int int13 = org.apache.commons.math.util.MathUtils.distance1(intArray8, intArray11);
        int[] intArray14 = new int[] {};
        int[] intArray15 = new int[] {};
        int int16 = org.apache.commons.math.util.MathUtils.distance1(intArray14, intArray15);
        int int17 = org.apache.commons.math.util.MathUtils.distance1(intArray11, intArray14);
        double double18 = org.apache.commons.math.util.MathUtils.distance(intArray4, intArray14);
        int[] intArray19 = new int[] {};
        int[] intArray20 = new int[] {};
        int int21 = org.apache.commons.math.util.MathUtils.distance1(intArray19, intArray20);
        int[] intArray22 = new int[] {};
        int[] intArray23 = new int[] {};
        int int24 = org.apache.commons.math.util.MathUtils.distance1(intArray22, intArray23);
        int int25 = org.apache.commons.math.util.MathUtils.distance1(intArray20, intArray23);
        int[] intArray26 = new int[] {};
        int[] intArray27 = new int[] {};
        int int28 = org.apache.commons.math.util.MathUtils.distance1(intArray26, intArray27);
        double double29 = org.apache.commons.math.util.MathUtils.distance(intArray20, intArray26);
        int int30 = org.apache.commons.math.util.MathUtils.distance1(intArray4, intArray20);
        int[] intArray31 = new int[] {};
        int[] intArray32 = new int[] {};
        int int33 = org.apache.commons.math.util.MathUtils.distance1(intArray31, intArray32);
        int[] intArray34 = new int[] {};
        int[] intArray35 = new int[] {};
        int int36 = org.apache.commons.math.util.MathUtils.distance1(intArray34, intArray35);
        int int37 = org.apache.commons.math.util.MathUtils.distance1(intArray32, intArray35);
        int[] intArray38 = new int[] {};
        int[] intArray39 = new int[] {};
        int int40 = org.apache.commons.math.util.MathUtils.distance1(intArray38, intArray39);
        int int41 = org.apache.commons.math.util.MathUtils.distance1(intArray35, intArray38);
        int[] intArray42 = new int[] {};
        int[] intArray43 = new int[] {};
        int int44 = org.apache.commons.math.util.MathUtils.distance1(intArray42, intArray43);
        int[] intArray45 = new int[] {};
        int[] intArray46 = new int[] {};
        int int47 = org.apache.commons.math.util.MathUtils.distance1(intArray45, intArray46);
        int int48 = org.apache.commons.math.util.MathUtils.distance1(intArray43, intArray46);
        int[] intArray49 = new int[] {};
        int[] intArray50 = new int[] {};
        int int51 = org.apache.commons.math.util.MathUtils.distance1(intArray49, intArray50);
        double double52 = org.apache.commons.math.util.MathUtils.distance(intArray43, intArray49);
        int int53 = org.apache.commons.math.util.MathUtils.distance1(intArray35, intArray43);
        double double54 = org.apache.commons.math.util.MathUtils.distance(intArray4, intArray43);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test437");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(10.270803231912973d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 588.473677397939d + "'", double1 == 588.473677397939d);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test438");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) (-16121856000L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test439");
        int int1 = org.apache.commons.math.util.MathUtils.hash(0.9999474062706148d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1944379305) + "'", int1 == (-1944379305));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test440");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (-160), (-3802400L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-160L) + "'", long2 == (-160L));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test441");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (short) 0, (int) ' ');
        int int4 = nonMonotonousSequenceException3.getIndex();
        boolean boolean5 = nonMonotonousSequenceException3.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-90L), (java.lang.Number) (-1), (int) (byte) 1, orderDirection9, false);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection16 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException18 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-90L), (java.lang.Number) (-1), (int) (byte) 1, orderDirection16, false);
        java.lang.Class<?> wildcardClass19 = nonMonotonousSequenceException18.getClass();
        int int20 = nonMonotonousSequenceException18.getIndex();
        java.lang.String str21 = nonMonotonousSequenceException18.toString();
        int int22 = nonMonotonousSequenceException18.getIndex();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException18);
        java.lang.Throwable[] throwableArray24 = nonMonotonousSequenceException3.getSuppressed();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 32 + "'", int4 == 32);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection16 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection16.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > -90)" + "'", str21.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not increasing (-1 > -90)"));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(throwableArray24);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test442");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 4.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.06981317007977318d + "'", double1 == 0.06981317007977318d);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test443");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) (-1.44468506E9f), 53.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test444");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(12600.0d, 2.181441423123706E7d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 12600.000000000002d + "'", double2 == 12600.000000000002d);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test445");
        double double1 = org.apache.commons.math.util.FastMath.signum(63.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test446");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-1074790400L), 4.3394118E10f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 4.3394118E10f + "'", float2 == 4.3394118E10f);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test447");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 291, (-16121852896L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test448");
        double double1 = org.apache.commons.math.util.FastMath.signum(1.3383347192042505E42d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test449");
        int int1 = org.apache.commons.math.util.FastMath.round(7.2896704E8f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 728967040 + "'", int1 == 728967040);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test450");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-160), (float) 626350111L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 6.2635008E8f + "'", float2 == 6.2635008E8f);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test451");
        int int1 = org.apache.commons.math.util.FastMath.abs(184331630);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 184331630 + "'", int1 == 184331630);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test452");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 38833706262L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 3.8833705E10f + "'", float1 == 3.8833705E10f);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test453");
        double double2 = org.apache.commons.math.util.MathUtils.log(0.0d, (double) 87L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.0d) + "'", double2 == (-0.0d));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test454");
        float float2 = org.apache.commons.math.util.MathUtils.round(0.0f, (int) '4');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test455");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.249873866232524E9d, 11013.232920103324d, (double) 52.0f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test456");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((-160), (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-108) + "'", int2 == (-108));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test457");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) 8625328718985906576L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test458");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (-1111307509), (long) 197);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 197L + "'", long2 == 197L);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test459");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(7.07423775202844E15d, (double) (-1));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.074237752028439E15d + "'", double2 == 7.074237752028439E15d);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test460");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.233403117511217d), number1, (-10));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test461");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 5, (long) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5L + "'", long2 == 5L);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test462");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (-160), 35L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-160L) + "'", long2 == (-160L));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test463");
        long long2 = org.apache.commons.math.util.MathUtils.pow((-1444685106L), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test464");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.5596856728972892d), (java.lang.Number) 200L, 1077936128);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException7 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 1L, (int) (short) 10);
        int int8 = nonMonotonousSequenceException7.getIndex();
        java.lang.Class<?> wildcardClass9 = nonMonotonousSequenceException7.getClass();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = nonMonotonousSequenceException7.getDirection();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException7);
        java.lang.Number number12 = nonMonotonousSequenceException3.getArgument();
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (-1.5596856728972892d) + "'", number12.equals((-1.5596856728972892d)));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test465");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (-626350098), (long) 2025509786);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2025509786L + "'", long2 == 2025509786L);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test466");
        double double2 = org.apache.commons.math.util.FastMath.atan2(4.091511391485423E83d, (double) (-300));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test467");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(0.010256138689425936d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.000052594651435d + "'", double1 == 1.000052594651435d);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test468");
        double double1 = org.apache.commons.math.util.MathUtils.sign(22.140692632779267d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test469");
        long long1 = org.apache.commons.math.util.FastMath.round((-0.0032548259227155375d));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test470");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(897609781, 897609781);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 897609781 + "'", int2 == 897609781);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test471");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) 0, 2025509786);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2025509786 + "'", int2 == 2025509786);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test472");
        float float1 = org.apache.commons.math.util.FastMath.abs(11.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 11.0f + "'", float1 == 11.0f);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test473");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow(11, (-3802400L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test474");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) (-626347008), 1462763619);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test475");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-160), (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-5600) + "'", int2 == (-5600));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test476");
        float float2 = org.apache.commons.math.util.MathUtils.round((-58.0f), 1104156176);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test477");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test478");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((int) ' ', (-5600));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-179200) + "'", int2 == (-179200));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test479");
        double double2 = org.apache.commons.math.util.FastMath.max(99.76937075891762d, 1.265653458137023d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 99.76937075891762d + "'", double2 == 99.76937075891762d);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test480");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(96.99999999999999d, (-818408495), (-58));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test481");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) ' ');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 32L + "'", long1 == 32L);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test482");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.010256138689425936d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0103089131462435d + "'", double1 == 1.0103089131462435d);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test483");
        double double1 = org.apache.commons.math.util.FastMath.ulp(3.390353940384959E10d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.814697265625E-6d + "'", double1 == 3.814697265625E-6d);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test484");
        double[] doubleArray3 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) (short) -1);
        double[] doubleArray6 = null;
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray6);
        double[] doubleArray11 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray13 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, (double) (short) -1);
        double[] doubleArray17 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray17, (double) (short) -1);
        double[] doubleArray21 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, (double) (-1L));
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray13, doubleArray21);
        double double23 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray13);
        int int24 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        java.lang.Class<?> wildcardClass25 = doubleArray3.getClass();
        double[] doubleArray27 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) 1);
        double[] doubleArray31 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray33 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray31, (double) (short) -1);
        double[] doubleArray37 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray39 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray37, (double) (short) -1);
        double[] doubleArray41 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray39, (double) (-1L));
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray33, doubleArray41);
        double[] doubleArray46 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray48 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray46, (double) (short) -1);
        double[] doubleArray49 = null;
        boolean boolean50 = org.apache.commons.math.util.MathUtils.equals(doubleArray46, doubleArray49);
        double[] doubleArray54 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray56 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray54, (double) (short) -1);
        double[] doubleArray60 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray62 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray60, (double) (short) -1);
        double[] doubleArray64 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray62, (double) (-1L));
        boolean boolean65 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray56, doubleArray64);
        double double66 = org.apache.commons.math.util.MathUtils.distance1(doubleArray46, doubleArray56);
        boolean boolean67 = org.apache.commons.math.util.MathUtils.equals(doubleArray33, doubleArray46);
        double[] doubleArray71 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray73 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray71, (double) (short) -1);
        double[] doubleArray75 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray73, (double) (-1L));
        boolean boolean76 = org.apache.commons.math.util.MathUtils.equals(doubleArray33, doubleArray73);
        double[] doubleArray80 = new double[] { (-35L), 1.3043045862358962d, '#' };
        double double81 = org.apache.commons.math.util.MathUtils.distance1(doubleArray33, doubleArray80);
        double double82 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray80);
        double double83 = org.apache.commons.math.util.MathUtils.distance(doubleArray27, doubleArray80);
        double[] doubleArray85 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, (double) (-3));
        int int86 = org.apache.commons.math.util.MathUtils.hash(doubleArray85);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 63.0d + "'", double23 == 63.0d);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 438727775 + "'", int24 == 438727775);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 63.0d + "'", double66 == 63.0d);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 70.62688523139718d + "'", double81 == 70.62688523139718d);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 49.51465652161667d + "'", double82 == 49.51465652161667d);
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + 50.10708126551846d + "'", double83 == 50.10708126551846d);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + (-1820298589) + "'", int86 == (-1820298589));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test485");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(8625328718985906576L, (long) 252);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test486");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(0L, 2455225485L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test487");
        int[] intArray0 = new int[] {};
        int[] intArray1 = new int[] {};
        int int2 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray1);
        int[] intArray3 = new int[] {};
        int[] intArray4 = new int[] {};
        int int5 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray4);
        int int6 = org.apache.commons.math.util.MathUtils.distance1(intArray1, intArray4);
        int[] intArray7 = new int[] {};
        int[] intArray8 = new int[] {};
        int int9 = org.apache.commons.math.util.MathUtils.distance1(intArray7, intArray8);
        int[] intArray10 = new int[] {};
        int[] intArray11 = new int[] {};
        int int12 = org.apache.commons.math.util.MathUtils.distance1(intArray10, intArray11);
        int int13 = org.apache.commons.math.util.MathUtils.distance1(intArray8, intArray11);
        int[] intArray14 = new int[] {};
        int[] intArray15 = new int[] {};
        int int16 = org.apache.commons.math.util.MathUtils.distance1(intArray14, intArray15);
        double double17 = org.apache.commons.math.util.MathUtils.distance(intArray8, intArray14);
        int int18 = org.apache.commons.math.util.MathUtils.distanceInf(intArray4, intArray14);
        java.lang.Class<?> wildcardClass19 = intArray14.getClass();
        int[] intArray20 = new int[] {};
        int[] intArray21 = new int[] {};
        int int22 = org.apache.commons.math.util.MathUtils.distance1(intArray20, intArray21);
        int[] intArray23 = new int[] {};
        int[] intArray24 = new int[] {};
        int int25 = org.apache.commons.math.util.MathUtils.distance1(intArray23, intArray24);
        int int26 = org.apache.commons.math.util.MathUtils.distance1(intArray21, intArray24);
        int[] intArray27 = new int[] {};
        int[] intArray28 = new int[] {};
        int int29 = org.apache.commons.math.util.MathUtils.distance1(intArray27, intArray28);
        int[] intArray30 = new int[] {};
        int[] intArray31 = new int[] {};
        int int32 = org.apache.commons.math.util.MathUtils.distance1(intArray30, intArray31);
        int int33 = org.apache.commons.math.util.MathUtils.distance1(intArray28, intArray31);
        int[] intArray34 = new int[] {};
        int[] intArray35 = new int[] {};
        int int36 = org.apache.commons.math.util.MathUtils.distance1(intArray34, intArray35);
        int int37 = org.apache.commons.math.util.MathUtils.distance1(intArray31, intArray34);
        double double38 = org.apache.commons.math.util.MathUtils.distance(intArray24, intArray34);
        int[] intArray39 = new int[] {};
        int[] intArray40 = new int[] {};
        int int41 = org.apache.commons.math.util.MathUtils.distance1(intArray39, intArray40);
        int[] intArray42 = new int[] {};
        int[] intArray43 = new int[] {};
        int int44 = org.apache.commons.math.util.MathUtils.distance1(intArray42, intArray43);
        int int45 = org.apache.commons.math.util.MathUtils.distance1(intArray40, intArray43);
        int[] intArray46 = new int[] {};
        int[] intArray47 = new int[] {};
        int int48 = org.apache.commons.math.util.MathUtils.distance1(intArray46, intArray47);
        int int49 = org.apache.commons.math.util.MathUtils.distance1(intArray43, intArray46);
        int[] intArray50 = new int[] {};
        int[] intArray51 = new int[] {};
        int int52 = org.apache.commons.math.util.MathUtils.distance1(intArray50, intArray51);
        int[] intArray53 = new int[] {};
        int[] intArray54 = new int[] {};
        int int55 = org.apache.commons.math.util.MathUtils.distance1(intArray53, intArray54);
        int int56 = org.apache.commons.math.util.MathUtils.distance1(intArray51, intArray54);
        int[] intArray57 = new int[] {};
        int[] intArray58 = new int[] {};
        int int59 = org.apache.commons.math.util.MathUtils.distance1(intArray57, intArray58);
        double double60 = org.apache.commons.math.util.MathUtils.distance(intArray51, intArray57);
        int int61 = org.apache.commons.math.util.MathUtils.distance1(intArray43, intArray51);
        int int62 = org.apache.commons.math.util.MathUtils.distanceInf(intArray34, intArray51);
        int int63 = org.apache.commons.math.util.MathUtils.distance1(intArray14, intArray51);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertNotNull(intArray54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test488");
        double double2 = org.apache.commons.math.util.FastMath.min(2979.3805346802806d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test489");
        double double1 = org.apache.commons.math.util.FastMath.acosh(2.4322992790977875d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5367645732874604d + "'", double1 == 1.5367645732874604d);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test490");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) (-3802400L), (-1.5707963267948966d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test491");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow(447362012L, (-1939549635));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test492");
        double double2 = org.apache.commons.math.util.MathUtils.round(4.234989000456701E-14d, 260);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.234989000456701E-14d + "'", double2 == 4.234989000456701E-14d);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test493");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 3336149131552L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test494");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((-2526.222805222132d), 184331630, 1443758766);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test495");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 461100);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, 0L);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 461100);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger7);
        java.math.BigInteger bigInteger11 = null;
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, 0L);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, 461100);
        java.math.BigInteger bigInteger16 = null;
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, 0L);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, 461100);
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, bigInteger18);
        java.math.BigInteger bigInteger22 = null;
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, 0L);
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger24, 461100);
        java.math.BigInteger bigInteger27 = null;
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger27, 0L);
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, 461100);
        java.math.BigInteger bigInteger32 = org.apache.commons.math.util.MathUtils.pow(bigInteger26, bigInteger29);
        java.math.BigInteger bigInteger33 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, bigInteger32);
        java.math.BigInteger bigInteger34 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger32);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertNotNull(bigInteger32);
        org.junit.Assert.assertNotNull(bigInteger33);
        org.junit.Assert.assertNotNull(bigInteger34);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test496");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (-1111307509), (long) (-5));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-5L) + "'", long2 == (-5L));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test497");
        double[] doubleArray6 = new double[] { (short) -1, (-1L), 1.0d, 100, '#', 'a' };
        double[] doubleArray10 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray10, (double) (short) -1);
        double[] doubleArray13 = null;
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equals(doubleArray10, doubleArray13);
        double[] doubleArray18 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray18, (double) (short) -1);
        double[] doubleArray24 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray26 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray24, (double) (short) -1);
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, (double) (-1L));
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray28);
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray13, doubleArray20);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection34 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException36 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-90L), (java.lang.Number) (-1), (int) (byte) 1, orderDirection34, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray20, orderDirection34, true);
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray20);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray20);
        double[] doubleArray42 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray20, (double) 1.0f);
        double[] doubleArray46 = new double[] { '4', 10.0d, 0.0d };
        double[] doubleArray48 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray46, (double) (short) -1);
        double[] doubleArray50 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray48, (double) (-1L));
        double[] doubleArray54 = new double[] { 3.1909099185344844E-8d, 156.3608363030788d, 1079525376 };
        boolean boolean55 = org.apache.commons.math.util.MathUtils.equals(doubleArray48, doubleArray54);
        java.lang.Class<?> wildcardClass56 = doubleArray54.getClass();
        boolean boolean57 = org.apache.commons.math.util.MathUtils.equals(doubleArray20, doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + orderDirection34 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection34.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(wildcardClass56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test498");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(1104156176, (-738962753));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test499");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 190L, (java.lang.Number) 9.332621544395286E157d, (int) (byte) 100, orderDirection3, false);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        int int7 = nonMonotonousSequenceException5.getIndex();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (short) 0, (int) ' ');
        int int12 = nonMonotonousSequenceException11.getIndex();
        boolean boolean13 = nonMonotonousSequenceException11.getStrict();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        java.lang.Number number15 = nonMonotonousSequenceException11.getPrevious();
        java.lang.String str16 = nonMonotonousSequenceException11.toString();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 100 + "'", int7 == 100);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 32 + "'", int12 == 32);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + (short) 0 + "'", number15.equals((short) 0));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 31 and 32 are not strictly increasing (0 >= 0)" + "'", str16.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 31 and 32 are not strictly increasing (0 >= 0)"));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test500");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 15L, (float) 11);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 11.0f + "'", float2 == 11.0f);
    }
}

