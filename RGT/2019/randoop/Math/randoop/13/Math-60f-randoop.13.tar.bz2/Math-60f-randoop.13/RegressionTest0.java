import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        float float2 = org.apache.commons.math.util.FastMath.max((float) '4', (float) (-1));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5707963267948966d) + "'", double1 == (-1.5707963267948966d));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5729.5779513082325d + "'", double1 == 5729.5779513082325d);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        double double0 = org.apache.commons.math.special.Gamma.GAMMA;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.5772156649015329d + "'", double0 == 0.5772156649015329d);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        double double1 = org.apache.commons.math.util.FastMath.asin(10.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.641588833612779d + "'", double1 == 4.641588833612779d);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.105427357601002E-15d + "'", double1 == 7.105427357601002E-15d);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(7.105427357601002E-15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 32.577917486317425d + "'", double1 == 32.577917486317425d);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        double double1 = org.apache.commons.math.special.Gamma.trigamma((double) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.019416865714155625d + "'", double1 == 0.019416865714155625d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8813735870195429d) + "'", double1 == (-0.8813735870195429d));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.5772156649015329d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1712659507785417d + "'", double1 == 1.1712659507785417d);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.298342365610589d + "'", double1 == 5.298342365610589d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        double double1 = org.apache.commons.math.util.FastMath.log10(5.298342365610589d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7241400178893855d + "'", double1 == 0.7241400178893855d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 10);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 10.0f, (double) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.7853981633974483d + "'", double2 == 0.7853981633974483d);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        double double1 = org.apache.commons.math.util.FastMath.asinh((-1.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8813735870195429d) + "'", double1 == (-0.8813735870195429d));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        double double1 = org.apache.commons.math.util.FastMath.ceil(Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.993222846126381d + "'", double1 == 2.993222846126381d);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        double double1 = org.apache.commons.math.util.FastMath.log(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (byte) 10);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 10.0f + "'", float1 == 10.0f);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0000000000000002d + "'", double1 == 1.0000000000000002d);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.930067261567154E14d + "'", double1 == 7.930067261567154E14d);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.5772156649015329d, (double) (short) 1, 0.0d);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(0.7241400178893855d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.6859233825834674d + "'", double1 == 2.6859233825834674d);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 'a');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9251475365964139d) + "'", double1 == (-0.9251475365964139d));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        try {
            long long4 = randomDataImpl1.nextLong((long) 10, (long) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 10 is larger than, or equal to, the maximum (1): lower bound (10) must be strictly less than upper bound (1)");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        try {
            double double3 = randomDataImpl1.nextExponential((double) (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): mean (-1)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        try {
            double double4 = randomDataImpl1.nextBeta((double) 0.0f, 2.6859233825834674d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.5 p = 0.473");
        } catch (org.apache.commons.math.exception.MathUserException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        try {
            randomDataImpl1.setSecureAlgorithm("05299f0e072343e00952d77e9bba14e42f77765c61bcdb705583", "05299f0e072343e00952d77e9bba14e42f77765c61bcdb705583");
            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: 05299f0e072343e00952d77e9bba14e42f77765c61bcdb705583");
        } catch (java.security.NoSuchProviderException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        long long2 = org.apache.commons.math.util.FastMath.min(0L, (long) (short) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1.0d, (java.lang.Number) 7.930067261567154E14d, true);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        double double2 = org.apache.commons.math.util.FastMath.min(100.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 'a', 32.577917486317425d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 32.577917486317425d + "'", double2 == 32.577917486317425d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        float float2 = org.apache.commons.math.util.FastMath.min(100.0f, (float) (byte) 100);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(10.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.000000000000002d + "'", double1 == 10.000000000000002d);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        try {
            double double4 = randomDataImpl1.nextGamma(Double.NaN, (double) 'a');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument � p = 0.702");
        } catch (org.apache.commons.math.exception.MathUserException e) {
        }
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.7853981633974483d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8686709614860095d + "'", double1 == 0.8686709614860095d);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        double double1 = org.apache.commons.math.util.FastMath.cosh(10.000000000000002d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11013.232920103343d + "'", double1 == 11013.232920103343d);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        double double1 = org.apache.commons.math.special.Gamma.trigamma((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

//    @Test
//    public void test044() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test044");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextExponential(0.5772156649015329d);
//        double double6 = randomDataImpl1.nextF((double) (byte) 1, 1.0d);
//        try {
//            int int10 = randomDataImpl1.nextHypergeometric(10, 0, (int) (short) 100);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100 is larger than the maximum (10): sample size (100) must be less than or equal to population size (10)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.501014399273528d + "'", double3 == 0.501014399273528d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.7833775195675755d + "'", double6 == 0.7833775195675755d);
//    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        double double1 = org.apache.commons.math.util.FastMath.log(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

//    @Test
//    public void test046() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test046");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextExponential(0.5772156649015329d);
//        try {
//            long long5 = randomDataImpl1.nextPoisson((double) 0L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): mean (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.48044580044050206d + "'", double3 == 0.48044580044050206d);
//    }

//    @Test
//    public void test047() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test047");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextExponential(0.5772156649015329d);
//        double double6 = randomDataImpl1.nextF((double) (byte) 1, 1.0d);
//        try {
//            long long9 = randomDataImpl1.nextSecureLong(0L, 0L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 0 is larger than, or equal to, the maximum (0): lower bound (0) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.4793770325266012d + "'", double3 == 0.4793770325266012d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.03205974986296661d + "'", double6 == 0.03205974986296661d);
//    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        double double2 = org.apache.commons.math.util.FastMath.max((double) (byte) 0, (double) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        try {
            double double4 = randomDataImpl1.nextUniform(0.49708625100776777d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 0.497 is larger than, or equal to, the maximum (0): lower bound (0.497) must be strictly less than upper bound (0)");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        try {
            int int4 = randomDataImpl1.nextZipf((int) (byte) -1, 0.019416865714155625d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): dimension (-1)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

//    @Test
//    public void test054() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test054");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT((double) 10L);
//        try {
//            randomDataImpl1.setSecureAlgorithm("05299f0e072343e00952d77e9bba14e42f77765c61bcdb705583", "");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: missing provider");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-0.33047305301114277d) + "'", double3 == (-0.33047305301114277d));
//    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3440585709080678E43d + "'", double1 == 1.3440585709080678E43d);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        java.lang.Object[] objArray5 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException6 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray5);
        org.apache.commons.math.exception.util.Localizable localizable7 = maxIterationsExceededException6.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException11 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable7, (java.lang.Number) (short) -1, (java.lang.Number) 1.0d, false);
        java.lang.Object[] objArray17 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException18 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray17);
        java.lang.Object[] objArray19 = maxIterationsExceededException18.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException11, "", objArray19);
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException("", objArray19);
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException21);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(localizable7);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(objArray19);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (byte) -1, (long) (-1));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getGeneralPattern();
        java.lang.Object[] objArray5 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException(localizable2, objArray5);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable9 = notStrictlyPositiveException8.getGeneralPattern();
        java.lang.Object[] objArray12 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException(localizable9, objArray12);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException16 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable17 = notStrictlyPositiveException16.getGeneralPattern();
        java.lang.Number number18 = notStrictlyPositiveException16.getArgument();
        java.lang.Object[] objArray19 = new java.lang.Object[] { 0, number18 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException20 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, localizable9, objArray19);
        java.lang.String str21 = mathIllegalArgumentException20.toString();
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + (-1L) + "'", number18.equals((-1L)));
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.apache.commons.math.exception.MathIllegalArgumentException: 0 is smaller than, or equal to, the minimum (-1): 0 is smaller than, or equal to, the minimum (-1)" + "'", str21.equals("org.apache.commons.math.exception.MathIllegalArgumentException: 0 is smaller than, or equal to, the minimum (-1): 0 is smaller than, or equal to, the minimum (-1)"));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        double double1 = org.apache.commons.math.util.FastMath.asin(1.3440585709080678E43d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test060() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test060");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextExponential(0.5772156649015329d);
//        double double6 = randomDataImpl1.nextF((double) (byte) 1, 1.0d);
//        try {
//            long long8 = randomDataImpl1.nextPoisson((double) (short) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): mean (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.23232301059235455d + "'", double3 == 0.23232301059235455d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.8119598821362809d + "'", double6 == 0.8119598821362809d);
//    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) Double.NaN, (java.lang.Number) 10.000000000000002d, true);
        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException3);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.017453292519943295d) + "'", double1 == (-0.017453292519943295d));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        double double1 = org.apache.commons.math.util.FastMath.cos(10.000000000000002d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8390715290764514d) + "'", double1 == (-0.8390715290764514d));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        double double1 = org.apache.commons.math.util.FastMath.cosh(4.641588833612779d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 51.859317725494705d + "'", double1 == 51.859317725494705d);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        double double1 = org.apache.commons.math.util.FastMath.log(2.6859233825834674d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9880245729672786d + "'", double1 == 0.9880245729672786d);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        double double0 = org.apache.commons.math.distribution.NormalDistributionImpl.DEFAULT_INVERSE_ABSOLUTE_ACCURACY;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-9d + "'", double0 == 1.0E-9d);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.019416865714155625d, 2.6859233825834674d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.524528573772329E-5d + "'", double2 == 2.524528573772329E-5d);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.8686709614860095d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3276384114812847d + "'", double1 == 1.3276384114812847d);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        try {
            int int4 = randomDataImpl1.nextPascal((int) (byte) 0, (double) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MathException; message: Discrete cumulative probability function returned NaN for argument 1,073,741,822");
        } catch (org.apache.commons.math.MathException e) {
        }
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        try {
            int[] intArray4 = randomDataImpl1.nextPermutation((int) ' ', (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        double double1 = org.apache.commons.math.util.FastMath.rint((-0.18072043342406346d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.019416865714155625d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.000188513259658d + "'", double1 == 1.000188513259658d);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        int int2 = org.apache.commons.math.util.FastMath.max(0, (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 100L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        double double1 = org.apache.commons.math.util.FastMath.expm1(7.930067261567154E14d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.ConvergenceException convergenceException1 = new org.apache.commons.math.ConvergenceException(throwable0);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((-0.18072043342406346d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5653738965860751d) + "'", double1 == (-0.5653738965860751d));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException3 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable4 = notStrictlyPositiveException3.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException6 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable7 = notStrictlyPositiveException6.getGeneralPattern();
        java.lang.Object[] objArray10 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException(localizable7, objArray10);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException13 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable14 = notStrictlyPositiveException13.getGeneralPattern();
        java.lang.Object[] objArray17 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException(localizable14, objArray17);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException21 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable22 = notStrictlyPositiveException21.getGeneralPattern();
        java.lang.Number number23 = notStrictlyPositiveException21.getArgument();
        java.lang.Object[] objArray24 = new java.lang.Object[] { 0, number23 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException25 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, localizable14, objArray24);
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException(localizable4, objArray24);
        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException(throwable0, "8", objArray24);
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertTrue("'" + localizable14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable14.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertTrue("'" + localizable22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable22.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + (-1L) + "'", number23.equals((-1L)));
        org.junit.Assert.assertNotNull(objArray24);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        double double1 = org.apache.commons.math.util.FastMath.expm1(Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

//    @Test
//    public void test082() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test082");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextExponential(0.5772156649015329d);
//        double double6 = randomDataImpl1.nextF((double) (byte) 1, 1.0d);
//        try {
//            double double9 = randomDataImpl1.nextUniform((double) 100L, (double) 100);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100 is larger than, or equal to, the maximum (100): lower bound (100) must be strictly less than upper bound (100)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.09164546708856158d + "'", double3 == 0.09164546708856158d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.11183160221338705d + "'", double6 == 0.11183160221338705d);
//    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((-0.9251475365964139d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test084() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test084");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextExponential(0.5772156649015329d);
//        double double6 = randomDataImpl1.nextF((double) (byte) 1, 1.0d);
//        try {
//            double double9 = randomDataImpl1.nextGaussian(0.5772156649015329d, (double) (-1L));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): standard deviation (-1)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.1488750763921319d + "'", double3 == 0.1488750763921319d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.2530211948167747d + "'", double6 == 2.2530211948167747d);
//    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (short) 0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        double double2 = org.apache.commons.math.util.FastMath.atan2(32.577917486317425d, (double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.2729698034198502d + "'", double2 == 1.2729698034198502d);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.6881171418161356E43d + "'", double1 == 2.6881171418161356E43d);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(0.1452060591311662d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.862009352569276d + "'", double1 == 1.862009352569276d);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.49708625100776777d, 32.577917486317425d, (-0.8813735870195429d), 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: Continued fraction convergents failed to converge (in less than 32.578 iterations) for value {1}");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        double double1 = org.apache.commons.math.special.Gamma.digamma(1.0E-9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0000000005772156E9d) + "'", double1 == (-1.0000000005772156E9d));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (byte) 10, (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP((double) 100.0f, (double) 1, (double) 10, (int) '4');
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 3.941866060050484E-159d + "'", double4 == 3.941866060050484E-159d);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        long long2 = org.apache.commons.math.util.FastMath.max(0L, (long) (short) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        double double1 = org.apache.commons.math.util.FastMath.atan(1.000188513259658d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7854924111435233d + "'", double1 == 0.7854924111435233d);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        double double2 = org.apache.commons.math.util.FastMath.min(0.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(5729.5779513082325d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 75.6939756606048d + "'", double1 == 75.6939756606048d);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        java.lang.Object[] objArray4 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray4);
        org.apache.commons.math.exception.util.Localizable localizable6 = maxIterationsExceededException5.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) (short) -1, (java.lang.Number) 1.0d, false);
        java.lang.Object[] objArray16 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException17 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray16);
        java.lang.Object[] objArray18 = maxIterationsExceededException17.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException10, "", objArray18);
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException19);
        org.apache.commons.math.exception.util.Localizable localizable21 = convergenceException20.getSpecificPattern();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(localizable6);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNull(localizable21);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 100.0f);
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable3 = notStrictlyPositiveException1.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNull(localizable3);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        try {
            double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(7.930067261567154E14d, Double.POSITIVE_INFINITY);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.ConvergenceException; message: Continued fraction diverged to NaN for value ∞");
        } catch (org.apache.commons.math.ConvergenceException e) {
        }
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        java.lang.Object[] objArray4 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray4);
        org.apache.commons.math.exception.util.Localizable localizable6 = maxIterationsExceededException5.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) (short) -1, (java.lang.Number) 1.0d, false);
        java.lang.Object[] objArray16 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException17 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray16);
        java.lang.Object[] objArray18 = maxIterationsExceededException17.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException10, "", objArray18);
        boolean boolean20 = numberIsTooLargeException10.getBoundIsAllowed();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException23 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable24 = notStrictlyPositiveException23.getGeneralPattern();
        java.lang.Object[] objArray27 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException28 = new org.apache.commons.math.MathException(localizable24, objArray27);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException30 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable31 = notStrictlyPositiveException30.getGeneralPattern();
        java.lang.Object[] objArray34 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException(localizable31, objArray34);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException38 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable39 = notStrictlyPositiveException38.getGeneralPattern();
        java.lang.Number number40 = notStrictlyPositiveException38.getArgument();
        java.lang.Object[] objArray41 = new java.lang.Object[] { 0, number40 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException42 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable24, localizable31, objArray41);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException44 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable45 = notStrictlyPositiveException44.getGeneralPattern();
        java.lang.Object[] objArray48 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException49 = new org.apache.commons.math.MathException(localizable45, objArray48);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException51 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable52 = notStrictlyPositiveException51.getGeneralPattern();
        java.lang.Object[] objArray55 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException56 = new org.apache.commons.math.MathException(localizable52, objArray55);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException59 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable60 = notStrictlyPositiveException59.getGeneralPattern();
        java.lang.Number number61 = notStrictlyPositiveException59.getArgument();
        java.lang.Object[] objArray62 = new java.lang.Object[] { 0, number61 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException63 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable45, localizable52, objArray62);
        org.apache.commons.math.ConvergenceException convergenceException64 = new org.apache.commons.math.ConvergenceException(localizable31, objArray62);
        org.apache.commons.math.MathException mathException65 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException10, "05299f0e072343e00952d77e9bba14e42f77765c61bcdb705583", objArray62);
        boolean boolean66 = numberIsTooLargeException10.getBoundIsAllowed();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(localizable6);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + localizable24 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable24.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertTrue("'" + localizable31 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable31.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertTrue("'" + localizable39 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable39.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number40 + "' != '" + (-1L) + "'", number40.equals((-1L)));
        org.junit.Assert.assertNotNull(objArray41);
        org.junit.Assert.assertTrue("'" + localizable45 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable45.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray48);
        org.junit.Assert.assertTrue("'" + localizable52 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable52.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray55);
        org.junit.Assert.assertTrue("'" + localizable60 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable60.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number61 + "' != '" + (-1L) + "'", number61.equals((-1L)));
        org.junit.Assert.assertNotNull(objArray62);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 1, (float) 100);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException("ba60b8479229f1074dd7b69d928c0b7ea2fb09935124de838877991337e128f083394c4b7bc21959a8365e11f7be6c786fcd", objArray1);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.08291229141526311d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.08272307916163937d + "'", double1 == 0.08272307916163937d);
    }

//    @Test
//    public void test105() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test105");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextExponential(0.5772156649015329d);
//        double double6 = randomDataImpl1.nextF((double) (byte) 1, 1.0d);
//        java.lang.String str8 = randomDataImpl1.nextSecureHexString((int) (byte) 1);
//        long long11 = randomDataImpl1.nextSecureLong(0L, (long) 1);
//        try {
//            double double14 = randomDataImpl1.nextWeibull(0.2614783751513923d, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): scale (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.5921092628183473d + "'", double3 == 2.5921092628183473d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.04230205436022282d + "'", double6 == 0.04230205436022282d);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1" + "'", str8.equals("1"));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
//    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.7241400178893855d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7241400178893855d + "'", double1 == 0.7241400178893855d);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        int int1 = org.apache.commons.math.util.FastMath.abs(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 10L, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(1.000188513259658d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0000942521880916d + "'", double1 == 1.0000942521880916d);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (short) 10, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.8390715290764514d), (java.lang.Number) 2.524528573772329E-5d, false);
    }

//    @Test
//    public void test112() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test112");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextExponential(0.5772156649015329d);
//        double double6 = randomDataImpl1.nextF((double) (byte) 1, 1.0d);
//        java.lang.String str8 = randomDataImpl1.nextSecureHexString((int) (byte) 1);
//        long long11 = randomDataImpl1.nextSecureLong(0L, (long) 1);
//        double double14 = randomDataImpl1.nextGaussian((double) (byte) 1, 4042.186843756581d);
//        try {
//            randomDataImpl1.setSecureAlgorithm("1", "hi!");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: hi!");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.235732544794556d + "'", double3 == 0.235732544794556d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.379254926712719d + "'", double6 == 1.379254926712719d);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2" + "'", str8.equals("2"));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 3101.442717271519d + "'", double14 == 3101.442717271519d);
//    }

//    @Test
//    public void test113() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test113");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextExponential(0.5772156649015329d);
//        double double6 = randomDataImpl1.nextF((double) (byte) 1, 1.0d);
//        long long8 = randomDataImpl1.nextPoisson(10.000000000000002d);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution9 = null;
//        try {
//            int int10 = randomDataImpl1.nextInversionDeviate(integerDistribution9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.305781452216496d + "'", double3 == 0.305781452216496d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.3127164587893847d + "'", double6 == 0.3127164587893847d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 13L + "'", long8 == 13L);
//    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        float float2 = org.apache.commons.math.util.FastMath.max((float) ' ', (float) (short) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

//    @Test
//    public void test115() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test115");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextSecureHexString((int) '4');
//        long long6 = randomDataImpl1.nextSecureLong((long) (-1), (long) '4');
//        randomDataImpl1.reSeed((long) (short) 100);
//        try {
//            java.lang.String str10 = randomDataImpl1.nextHexString(0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): length (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2ca09a16b71ff777c4ff7da3f9c2dcebdf1eec350251ce0fd3b2" + "'", str3.equals("2ca09a16b71ff777c4ff7da3f9c2dcebdf1eec350251ce0fd3b2"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 37L + "'", long6 == 37L);
//    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5063656411097588d) + "'", double1 == (-0.5063656411097588d));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(2.6881171418161356E43d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.688117141816135E43d + "'", double2 == 2.688117141816135E43d);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP((double) (byte) 0, 0.7241400178893855d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) (-1.0f));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        double double2 = org.apache.commons.math.util.FastMath.pow(4042.186843756581d, 100.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

//    @Test
//    public void test121() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test121");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.7241400178893855d, 5729.5779513082325d, (double) 1.0f);
//        double double4 = normalDistributionImpl3.sample();
//        normalDistributionImpl3.reseedRandomGenerator((long) '4');
//        try {
//            double double9 = normalDistributionImpl3.cumulativeProbability(100.0d, 3.941866060050484E-159d);
//            org.junit.Assert.fail("Expected anonymous exception");
//        } catch (java.lang.IllegalArgumentException e) {
//            if (!e.getClass().isAnonymousClass()) {
//                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
//            }
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 8246.273512319176d + "'", double4 == 8246.273512319176d);
//    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.49708625100776777d, 1.0000000000000002d, 5.298342365610589d, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.5848500137377979d + "'", double4 == 0.5848500137377979d);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) (short) -1, 0.9880245729672786d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.9999999999999999d) + "'", double2 == (-0.9999999999999999d));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.019416865714155625d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 10L, 0.18355825835313155d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

//    @Test
//    public void test126() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test126");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextSecureHexString((int) '4');
//        java.lang.String str5 = randomDataImpl1.nextHexString((int) (short) 100);
//        try {
//            double double7 = randomDataImpl1.nextChiSquare((-0.5063656411097588d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.253 is smaller than, or equal to, the minimum (0): alpha");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "f9f19e104ab29c8526c8ec7223e61e9671fce09700d04fa689a5" + "'", str3.equals("f9f19e104ab29c8526c8ec7223e61e9671fce09700d04fa689a5"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "de55861d625ec74158d5ac33d1610c200b99d8271aea69184dd65c0f4d557cc098e293253c93f7cd665f50c5411090a71127" + "'", str5.equals("de55861d625ec74158d5ac33d1610c200b99d8271aea69184dd65c0f4d557cc098e293253c93f7cd665f50c5411090a71127"));
//    }

//    @Test
//    public void test127() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test127");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT((double) 10L);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl7 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.7241400178893855d, 5729.5779513082325d, (double) 1.0f);
//        double double10 = normalDistributionImpl7.cumulativeProbability(1.0000000000000002d, 32.577917486317425d);
//        double double11 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        try {
//            java.lang.String str13 = randomDataImpl1.nextHexString((int) (short) -1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): length (-1)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2835413257506674d + "'", double3 == 0.2835413257506674d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.002198713597520441d + "'", double10 == 0.002198713597520441d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 233.30209132612163d + "'", double11 == 233.30209132612163d);
//    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        float float2 = org.apache.commons.math.util.FastMath.max(0.0f, (float) (short) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

//    @Test
//    public void test129() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test129");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT((double) 10L);
//        try {
//            int int6 = randomDataImpl1.nextPascal(0, (-1.0000000005772156E9d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: -1,000,000,000.577 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.7482873865988556d + "'", double3 == 0.7482873865988556d);
//    }

//    @Test
//    public void test130() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test130");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextExponential(0.5772156649015329d);
//        double double6 = randomDataImpl1.nextUniform(1.000188513259658d, 7.930067261567154E14d);
//        try {
//            double double9 = randomDataImpl1.nextCauchy(0.1452060591311662d, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): scale (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.13368207187934192d + "'", double3 == 0.13368207187934192d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.0201650102919784E14d + "'", double6 == 2.0201650102919784E14d);
//    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (byte) 10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 10L + "'", long1 == 10L);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.18355825835313155d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.517113498406427d + "'", double1 == 10.517113498406427d);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        double double1 = org.apache.commons.math.util.FastMath.floor(1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

//    @Test
//    public void test134() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test134");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextExponential(0.5772156649015329d);
//        double double6 = randomDataImpl1.nextCauchy(0.19323284172500138d, 11013.232920103343d);
//        try {
//            java.lang.String str8 = randomDataImpl1.nextHexString((int) (short) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): length (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.12283383379148081d + "'", double3 == 0.12283383379148081d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 12594.698897370648d + "'", double6 == 12594.698897370648d);
//    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 0.0f, 0.0031724211906162063d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        java.lang.Throwable throwable1 = null;
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException(throwable1, "", objArray3);
        java.lang.Object[] objArray9 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException10 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray9);
        org.apache.commons.math.exception.util.Localizable localizable11 = maxIterationsExceededException10.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException15 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable11, (java.lang.Number) (short) -1, (java.lang.Number) 1.0d, false);
        java.lang.Object[] objArray21 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException22 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray21);
        java.lang.Object[] objArray23 = maxIterationsExceededException22.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException15, "", objArray23);
        org.apache.commons.math.ConvergenceException convergenceException25 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException24);
        convergenceException4.addSuppressed((java.lang.Throwable) convergenceException24);
        org.apache.commons.math.exception.util.Localizable localizable27 = convergenceException4.getGeneralPattern();
        java.lang.Object[] objArray32 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException33 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray32);
        org.apache.commons.math.exception.util.Localizable localizable34 = maxIterationsExceededException33.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException38 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable34, (java.lang.Number) (short) -1, (java.lang.Number) 1.0d, false);
        java.lang.Object[] objArray44 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException45 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray44);
        java.lang.Object[] objArray46 = maxIterationsExceededException45.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException47 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException38, "", objArray46);
        boolean boolean48 = numberIsTooLargeException38.getBoundIsAllowed();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException51 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable52 = notStrictlyPositiveException51.getGeneralPattern();
        java.lang.Object[] objArray55 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException56 = new org.apache.commons.math.MathException(localizable52, objArray55);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException58 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable59 = notStrictlyPositiveException58.getGeneralPattern();
        java.lang.Object[] objArray62 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException63 = new org.apache.commons.math.MathException(localizable59, objArray62);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException66 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable67 = notStrictlyPositiveException66.getGeneralPattern();
        java.lang.Number number68 = notStrictlyPositiveException66.getArgument();
        java.lang.Object[] objArray69 = new java.lang.Object[] { 0, number68 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException70 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable52, localizable59, objArray69);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException72 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable73 = notStrictlyPositiveException72.getGeneralPattern();
        java.lang.Object[] objArray76 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException77 = new org.apache.commons.math.MathException(localizable73, objArray76);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException79 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable80 = notStrictlyPositiveException79.getGeneralPattern();
        java.lang.Object[] objArray83 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException84 = new org.apache.commons.math.MathException(localizable80, objArray83);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException87 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable88 = notStrictlyPositiveException87.getGeneralPattern();
        java.lang.Number number89 = notStrictlyPositiveException87.getArgument();
        java.lang.Object[] objArray90 = new java.lang.Object[] { 0, number89 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException91 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable73, localizable80, objArray90);
        org.apache.commons.math.ConvergenceException convergenceException92 = new org.apache.commons.math.ConvergenceException(localizable59, objArray90);
        org.apache.commons.math.MathException mathException93 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException38, "05299f0e072343e00952d77e9bba14e42f77765c61bcdb705583", objArray90);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException94 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable27, objArray90);
        int int95 = maxIterationsExceededException94.getMaxIterations();
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(localizable11);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNotNull(localizable27);
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(localizable34);
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertNotNull(objArray46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + localizable52 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable52.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray55);
        org.junit.Assert.assertTrue("'" + localizable59 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable59.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray62);
        org.junit.Assert.assertTrue("'" + localizable67 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable67.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number68 + "' != '" + (-1L) + "'", number68.equals((-1L)));
        org.junit.Assert.assertNotNull(objArray69);
        org.junit.Assert.assertTrue("'" + localizable73 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable73.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray76);
        org.junit.Assert.assertTrue("'" + localizable80 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable80.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray83);
        org.junit.Assert.assertTrue("'" + localizable88 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable88.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number89 + "' != '" + (-1L) + "'", number89.equals((-1L)));
        org.junit.Assert.assertNotNull(objArray90);
        org.junit.Assert.assertTrue("'" + int95 + "' != '" + 0 + "'", int95 == 0);
    }

//    @Test
//    public void test137() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test137");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextExponential(0.5772156649015329d);
//        double double6 = randomDataImpl1.nextF((double) (byte) 1, 1.0d);
//        java.lang.String str8 = randomDataImpl1.nextSecureHexString((int) (byte) 1);
//        long long11 = randomDataImpl1.nextSecureLong(0L, (long) 1);
//        try {
//            int[] intArray14 = randomDataImpl1.nextPermutation(10, (int) 'a');
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 97 is larger than the maximum (10): permutation size (97) exceeds permuation domain (10)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.431878944214831d + "'", double3 == 1.431878944214831d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.7950977649814526d + "'", double6 == 1.7950977649814526d);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "e" + "'", str8.equals("e"));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
//    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        double double1 = org.apache.commons.math.util.FastMath.asinh(2.6859233825834674d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7141516006622417d + "'", double1 == 1.7141516006622417d);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        java.lang.Object[] objArray4 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray4);
        org.apache.commons.math.exception.util.Localizable localizable6 = maxIterationsExceededException5.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable6, (java.lang.Number) (byte) 100);
        java.lang.String str9 = notStrictlyPositiveException8.toString();
        java.lang.Number number10 = notStrictlyPositiveException8.getMin();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(localizable6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0): " + "'", str9.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0): "));
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 0 + "'", number10.equals(0));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(0.4999509311395951d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5724612960652946d + "'", double1 == 0.5724612960652946d);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        double double1 = org.apache.commons.math.util.FastMath.atan(1.0000942521880916d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7854452872706951d + "'", double1 == 0.7854452872706951d);
    }

//    @Test
//    public void test142() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test142");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextSecureHexString((int) '4');
//        long long6 = randomDataImpl1.nextSecureLong((long) (-1), (long) '4');
//        randomDataImpl1.reSeed((long) (short) 100);
//        try {
//            int int11 = randomDataImpl1.nextBinomial((int) (short) 100, (double) 100L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 100 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1b31425e415ebc80aa8dafde94d6b066a628403abc1aa291e613" + "'", str3.equals("1b31425e415ebc80aa8dafde94d6b066a628403abc1aa291e613"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 41L + "'", long6 == 41L);
//    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 100);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 100.0f + "'", float1 == 100.0f);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.19323284172500138d, 0.08291229141526311d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.3369944980913211d + "'", double2 == 0.3369944980913211d);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (byte) 1, 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getGeneralPattern();
        java.lang.Object[] objArray5 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException(localizable2, objArray5);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable9 = notStrictlyPositiveException8.getGeneralPattern();
        java.lang.Object[] objArray12 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException(localizable9, objArray12);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException16 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable17 = notStrictlyPositiveException16.getGeneralPattern();
        java.lang.Number number18 = notStrictlyPositiveException16.getArgument();
        java.lang.Object[] objArray19 = new java.lang.Object[] { 0, number18 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException20 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, localizable9, objArray19);
        java.lang.Number number22 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException24 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable9, (java.lang.Number) 5.298342365610589d, number22, false);
        boolean boolean25 = numberIsTooSmallException24.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + (-1L) + "'", number18.equals((-1L)));
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        double double1 = org.apache.commons.math.util.FastMath.cosh(7.930067261567154E14d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7853981633974483d) + "'", double1 == (-0.7853981633974483d));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        org.apache.commons.math.distribution.IntegerDistribution integerDistribution2 = null;
        try {
            int int3 = randomDataImpl1.nextInversionDeviate(integerDistribution2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        double double1 = org.apache.commons.math.util.FastMath.log(2.524528573772329E-5d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-10.586871123130669d) + "'", double1 == (-10.586871123130669d));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        double double1 = org.apache.commons.math.util.FastMath.log(9.001943858154728d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.1974405382543956d + "'", double1 == 2.1974405382543956d);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        double double1 = org.apache.commons.math.special.Erf.erf(0.19323284172500138d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.21535625129876d + "'", double1 == 0.21535625129876d);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.5772156649015329d, 1.0000942521880916d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.18797288921263233d + "'", double2 == 0.18797288921263233d);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(1.2729698034198502d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 72.93579718355548d + "'", double1 == 72.93579718355548d);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(1.0d, 2.1974405382543956d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.11108711804441163d + "'", double2 == 0.11108711804441163d);
    }

//    @Test
//    public void test157() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test157");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextExponential(0.5772156649015329d);
//        double double6 = randomDataImpl1.nextCauchy(0.19323284172500138d, 11013.232920103343d);
//        try {
//            int int9 = randomDataImpl1.nextInt((int) 'a', (int) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 97 is larger than, or equal to, the maximum (-1): lower bound (97) must be strictly less than upper bound (-1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.9498949064134302d + "'", double3 == 0.9498949064134302d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 41377.10511016983d + "'", double6 == 41377.10511016983d);
//    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        double double0 = org.apache.commons.math.util.FastMath.PI;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.141592653589793d + "'", double0 == 3.141592653589793d);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getGeneralPattern();
        java.lang.Object[] objArray5 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException(localizable2, objArray5);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable9 = notStrictlyPositiveException8.getGeneralPattern();
        java.lang.Object[] objArray12 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException(localizable9, objArray12);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException16 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable17 = notStrictlyPositiveException16.getGeneralPattern();
        java.lang.Number number18 = notStrictlyPositiveException16.getArgument();
        java.lang.Object[] objArray19 = new java.lang.Object[] { 0, number18 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException20 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, localizable9, objArray19);
        java.lang.Number number22 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException24 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable9, (java.lang.Number) 5.298342365610589d, number22, false);
        java.lang.Object[] objArray30 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException31 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray30);
        org.apache.commons.math.MathException mathException32 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException24, "org.apache.commons.math.exception.NotStrictlyPositiveException: -1 is smaller than, or equal to, the minimum (0)", objArray30);
        java.lang.Object[] objArray37 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException38 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray37);
        org.apache.commons.math.exception.util.Localizable localizable39 = maxIterationsExceededException38.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException41 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable39, (java.lang.Number) (byte) 100);
        java.lang.Object[] objArray42 = null;
        org.apache.commons.math.MathException mathException43 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException32, localizable39, objArray42);
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + (-1L) + "'", number18.equals((-1L)));
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertNotNull(localizable39);
    }

//    @Test
//    public void test160() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test160");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextSecureHexString((int) '4');
//        try {
//            double double6 = randomDataImpl1.nextCauchy(2.524528573772329E-5d, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): scale (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "82662b4e1a69fc931a6115a2d7638bd9672a1e58c2bdc96f0d62" + "'", str3.equals("82662b4e1a69fc931a6115a2d7638bd9672a1e58c2bdc96f0d62"));
//    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException4 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable5 = notStrictlyPositiveException4.getGeneralPattern();
        java.lang.Object[] objArray8 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException(localizable5, objArray8);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException11 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable12 = notStrictlyPositiveException11.getGeneralPattern();
        java.lang.Object[] objArray15 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException(localizable12, objArray15);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException19 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable20 = notStrictlyPositiveException19.getGeneralPattern();
        java.lang.Number number21 = notStrictlyPositiveException19.getArgument();
        java.lang.Object[] objArray22 = new java.lang.Object[] { 0, number21 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException23 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable12, objArray22);
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException(localizable2, objArray22);
        org.apache.commons.math.exception.util.Localizable localizable25 = mathException24.getGeneralPattern();
        java.lang.Object[] objArray31 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException32 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray31);
        org.apache.commons.math.exception.util.Localizable localizable33 = maxIterationsExceededException32.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException37 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable33, (java.lang.Number) (short) -1, (java.lang.Number) 1.0d, false);
        java.lang.Object[] objArray43 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException44 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray43);
        java.lang.Object[] objArray45 = maxIterationsExceededException44.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException37, "", objArray45);
        org.apache.commons.math.MathException mathException47 = new org.apache.commons.math.MathException("", objArray45);
        org.apache.commons.math.ConvergenceException convergenceException48 = new org.apache.commons.math.ConvergenceException(localizable25, objArray45);
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertTrue("'" + localizable20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable20.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + (-1L) + "'", number21.equals((-1L)));
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertTrue("'" + localizable25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable25.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(localizable33);
        org.junit.Assert.assertNotNull(objArray43);
        org.junit.Assert.assertNotNull(objArray45);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 284);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.342124518290157d + "'", double1 == 6.342124518290157d);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.08291229141526311d, 4.641588833612779d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.017861012128359798d + "'", double2 == 0.017861012128359798d);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.49708625100776777d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7050434390927751d + "'", double1 == 0.7050434390927751d);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(7.930067261567154E14d, 0.0d, 0.1452060591311662d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): standard deviation (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.1452060591311662d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0105609365269927d + "'", double1 == 1.0105609365269927d);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        double double1 = org.apache.commons.math.util.FastMath.expm1(5652.686218477152d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

//    @Test
//    public void test169() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test169");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT((double) 10L);
//        double double5 = randomDataImpl1.nextExponential((double) 6L);
//        try {
//            int int8 = randomDataImpl1.nextPascal(10, (double) 13L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 13 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.1833419105982268d + "'", double3 == 1.1833419105982268d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.418624798662863d + "'", double5 == 4.418624798662863d);
//    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        java.lang.Object[] objArray5 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException6 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray5);
        org.apache.commons.math.exception.util.Localizable localizable7 = maxIterationsExceededException6.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException11 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable7, (java.lang.Number) (short) -1, (java.lang.Number) 1.0d, false);
        java.lang.Object[] objArray17 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException18 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray17);
        java.lang.Object[] objArray19 = maxIterationsExceededException18.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException11, "", objArray19);
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0): ", objArray19);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(localizable7);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(objArray19);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.0031724211906162063d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.1469366995820881d + "'", double1 == 0.1469366995820881d);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getGeneralPattern();
        java.lang.Number number3 = notStrictlyPositiveException1.getArgument();
        java.lang.Object[] objArray4 = notStrictlyPositiveException1.getArguments();
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + (-1L) + "'", number3.equals((-1L)));
        org.junit.Assert.assertNotNull(objArray4);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        double double2 = org.apache.commons.math.util.FastMath.min(0.0d, (double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.1452060591311662d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.1446963233687307d + "'", double1 == 0.1446963233687307d);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(1.3440585709080678E43d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3213016811096636E45d + "'", double1 == 1.3213016811096636E45d);
    }

//    @Test
//    public void test178() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test178");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextSecureHexString((int) '4');
//        java.lang.String str5 = randomDataImpl1.nextHexString((int) (short) 100);
//        int int8 = randomDataImpl1.nextSecureInt((int) (byte) 1, (int) '#');
//        try {
//            double double10 = randomDataImpl1.nextChiSquare((double) (byte) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): alpha");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "11fc11de13ab5d5361ee33155a8121dff246d5227dc37ea27568" + "'", str3.equals("11fc11de13ab5d5361ee33155a8121dff246d5227dc37ea27568"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "aa718c645a2454440e8838bec67d0bc1f0e4b52c5ceb6d9165fa48eeedf656661a4802432726a6c58d54535f31a26dba3979" + "'", str5.equals("aa718c645a2454440e8838bec67d0bc1f0e4b52c5ceb6d9165fa48eeedf656661a4802432726a6c58d54535f31a26dba3979"));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 21 + "'", int8 == 21);
//    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (byte) 10, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        double double1 = org.apache.commons.math.util.FastMath.acos(7.930067261567154E14d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        double double1 = org.apache.commons.math.util.FastMath.ceil(2.6859233825834674d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getGeneralPattern();
        java.lang.Number number3 = notStrictlyPositiveException1.getArgument();
        java.lang.Number number4 = notStrictlyPositiveException1.getArgument();
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + (-1L) + "'", number3.equals((-1L)));
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-1L) + "'", number4.equals((-1L)));
    }

//    @Test
//    public void test183() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test183");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextSecureHexString((int) '4');
//        long long6 = randomDataImpl1.nextSecureLong((long) (-1), (long) '4');
//        randomDataImpl1.reSeed((long) (short) 100);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution9 = null;
//        try {
//            int int10 = randomDataImpl1.nextInversionDeviate(integerDistribution9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "f9d135f9568cd71ac4cbe8662295d0a7d85bf86173f68d13f1fa" + "'", str3.equals("f9d135f9568cd71ac4cbe8662295d0a7d85bf86173f68d13f1fa"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 19L + "'", long6 == 19L);
//    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        java.lang.Object[] objArray4 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray4);
        org.apache.commons.math.exception.util.Localizable localizable6 = maxIterationsExceededException5.getGeneralPattern();
        java.lang.Throwable[] throwableArray7 = maxIterationsExceededException5.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable8 = maxIterationsExceededException5.getGeneralPattern();
        java.lang.String str9 = maxIterationsExceededException5.getPattern();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(localizable6);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(localizable8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        double double1 = org.apache.commons.math.util.FastMath.tanh(11013.232920103343d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        double double1 = org.apache.commons.math.util.FastMath.sin(1.0309090578119309d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8577666349869324d + "'", double1 == 0.8577666349869324d);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) Double.NaN, (java.lang.Number) 10.000000000000002d, true);
        java.lang.Number number4 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 10.000000000000002d + "'", number4.equals(10.000000000000002d));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException4 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable2, (java.lang.Number) 10);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException6 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable7 = notStrictlyPositiveException6.getGeneralPattern();
        java.lang.Object[] objArray10 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException(localizable7, objArray10);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException13 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable14 = notStrictlyPositiveException13.getGeneralPattern();
        java.lang.Object[] objArray17 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException(localizable14, objArray17);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException21 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable22 = notStrictlyPositiveException21.getGeneralPattern();
        java.lang.Number number23 = notStrictlyPositiveException21.getArgument();
        java.lang.Object[] objArray24 = new java.lang.Object[] { 0, number23 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException25 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, localizable14, objArray24);
        java.lang.Number number27 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException29 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable14, (java.lang.Number) 5.298342365610589d, number27, false);
        java.lang.Object[] objArray34 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException35 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray34);
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException4, localizable14, objArray34);
        boolean boolean37 = notStrictlyPositiveException4.getBoundIsAllowed();
        boolean boolean38 = notStrictlyPositiveException4.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertTrue("'" + localizable14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable14.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertTrue("'" + localizable22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable22.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + (-1L) + "'", number23.equals((-1L)));
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        double double1 = org.apache.commons.math.util.FastMath.floor(3.941866060050484E-159d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.49708625100776777d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        float float2 = org.apache.commons.math.util.FastMath.max((float) '4', (float) 284);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 284.0f + "'", float2 == 284.0f);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ((double) 0, 0.9686837504552075d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 284.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 284.0d + "'", double1 == 284.0d);
    }

//    @Test
//    public void test194() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test194");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextExponential(0.5772156649015329d);
//        double double6 = randomDataImpl1.nextUniform(1.000188513259658d, 7.930067261567154E14d);
//        randomDataImpl1.reSeedSecure();
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution8 = null;
//        try {
//            int int9 = randomDataImpl1.nextInversionDeviate(integerDistribution8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.4343309367814006d + "'", double3 == 1.4343309367814006d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 7.090178179560715E14d + "'", double6 == 7.090178179560715E14d);
//    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 0, Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY);
        double[] doubleArray5 = normalDistributionImpl3.sample(10);
        try {
            double double7 = normalDistributionImpl3.inverseCumulativeProbability(1.0000000000000002d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 1 out of [0, 1] range");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (byte) -1, (long) 'a');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 97L + "'", long2 == 97L);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 0.2614783751513923d, (java.lang.Number) 1.1712659507785417d, (java.lang.Number) 0.21535625129876d);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 10, (long) (short) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        double double1 = org.apache.commons.math.util.FastMath.signum(1.7141516006622417d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

//    @Test
//    public void test200() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test200");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.7241400178893855d, 5729.5779513082325d, (double) 1.0f);
//        double double4 = normalDistributionImpl3.sample();
//        try {
//            double double7 = normalDistributionImpl3.cumulativeProbability(2.6881171418161356E43d, 0.7854452872706951d);
//            org.junit.Assert.fail("Expected anonymous exception");
//        } catch (java.lang.IllegalArgumentException e) {
//            if (!e.getClass().isAnonymousClass()) {
//                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
//            }
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-4461.781661417607d) + "'", double4 == (-4461.781661417607d));
//    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(0.7854452872706951d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.16635096647323788d + "'", double1 == 0.16635096647323788d);
    }

//    @Test
//    public void test202() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test202");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextExponential(0.5772156649015329d);
//        try {
//            int int6 = randomDataImpl1.nextInt((int) '#', (int) (short) -1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 35 is larger than, or equal to, the maximum (-1): lower bound (35) must be strictly less than upper bound (-1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.8544733273304799d + "'", double3 == 1.8544733273304799d);
//    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 0, (long) '4');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52L + "'", long2 == 52L);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 'a');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.574710978503383d + "'", double1 == 4.574710978503383d);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        java.lang.Object[] objArray4 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray4);
        org.apache.commons.math.exception.util.Localizable localizable6 = maxIterationsExceededException5.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) (short) -1, (java.lang.Number) 1.0d, false);
        java.lang.Object[] objArray16 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException17 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray16);
        java.lang.Object[] objArray18 = maxIterationsExceededException17.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException10, "", objArray18);
        boolean boolean20 = numberIsTooLargeException10.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable21 = numberIsTooLargeException10.getSpecificPattern();
        java.lang.Object[] objArray26 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException27 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray26);
        org.apache.commons.math.exception.util.Localizable localizable28 = maxIterationsExceededException27.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException32 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable28, (java.lang.Number) (short) -1, (java.lang.Number) 1.0d, false);
        java.lang.Object[] objArray38 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException39 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray38);
        java.lang.Object[] objArray40 = maxIterationsExceededException39.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException32, "", objArray40);
        boolean boolean42 = numberIsTooLargeException32.getBoundIsAllowed();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException45 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable46 = notStrictlyPositiveException45.getGeneralPattern();
        java.lang.Object[] objArray49 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException(localizable46, objArray49);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException52 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable53 = notStrictlyPositiveException52.getGeneralPattern();
        java.lang.Object[] objArray56 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException57 = new org.apache.commons.math.MathException(localizable53, objArray56);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException60 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable61 = notStrictlyPositiveException60.getGeneralPattern();
        java.lang.Number number62 = notStrictlyPositiveException60.getArgument();
        java.lang.Object[] objArray63 = new java.lang.Object[] { 0, number62 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException64 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable46, localizable53, objArray63);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException66 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable67 = notStrictlyPositiveException66.getGeneralPattern();
        java.lang.Object[] objArray70 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException71 = new org.apache.commons.math.MathException(localizable67, objArray70);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException73 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable74 = notStrictlyPositiveException73.getGeneralPattern();
        java.lang.Object[] objArray77 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException78 = new org.apache.commons.math.MathException(localizable74, objArray77);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException81 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable82 = notStrictlyPositiveException81.getGeneralPattern();
        java.lang.Number number83 = notStrictlyPositiveException81.getArgument();
        java.lang.Object[] objArray84 = new java.lang.Object[] { 0, number83 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException85 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable67, localizable74, objArray84);
        org.apache.commons.math.ConvergenceException convergenceException86 = new org.apache.commons.math.ConvergenceException(localizable53, objArray84);
        org.apache.commons.math.MathException mathException87 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException32, "05299f0e072343e00952d77e9bba14e42f77765c61bcdb705583", objArray84);
        org.apache.commons.math.ConvergenceException convergenceException88 = new org.apache.commons.math.ConvergenceException(localizable21, objArray84);
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(localizable6);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(localizable21);
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(localizable28);
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(objArray40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + localizable46 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable46.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertTrue("'" + localizable53 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable53.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray56);
        org.junit.Assert.assertTrue("'" + localizable61 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable61.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number62 + "' != '" + (-1L) + "'", number62.equals((-1L)));
        org.junit.Assert.assertNotNull(objArray63);
        org.junit.Assert.assertTrue("'" + localizable67 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable67.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray70);
        org.junit.Assert.assertTrue("'" + localizable74 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable74.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray77);
        org.junit.Assert.assertTrue("'" + localizable82 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable82.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number83 + "' != '" + (-1L) + "'", number83.equals((-1L)));
        org.junit.Assert.assertNotNull(objArray84);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.7854924111435233d, 0.31285066809386347d, (-0.8833654229914927d), (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: maximal number of iterations (100) exceeded");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5872139151569291d) + "'", double1 == (-0.5872139151569291d));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        double double1 = org.apache.commons.math.util.FastMath.tanh((-0.18072043342406346d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.17877836497716262d) + "'", double1 == (-0.17877836497716262d));
    }

//    @Test
//    public void test209() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test209");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT((double) 10L);
//        randomDataImpl1.reSeed();
//        double double6 = randomDataImpl1.nextChiSquare(0.5848500137377979d);
//        try {
//            int int10 = randomDataImpl1.nextHypergeometric((-1), (int) (short) 100, 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): population size (-1)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-0.41619590349930097d) + "'", double3 == (-0.41619590349930097d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.03625596997179335d + "'", double6 == 0.03625596997179335d);
//    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        java.lang.Throwable throwable0 = null;
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException(throwable0, "", objArray2);
        java.lang.Object[] objArray4 = convergenceException3.getArguments();
        org.junit.Assert.assertNotNull(objArray4);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray5 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException6 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray5);
        java.lang.Object[] objArray7 = maxIterationsExceededException6.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException(localizable0, objArray7);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(objArray7);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        double double1 = org.apache.commons.math.util.FastMath.sinh(2.993222846126381d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.949874371066198d + "'", double1 == 9.949874371066198d);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.1469366995820881d, (double) (-1L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.14693669958208808d + "'", double2 == 0.14693669958208808d);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        double double1 = org.apache.commons.math.util.FastMath.log10(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.2729698034198502d, number1, (java.lang.Number) 0.250069889408776d);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.5187754889940697d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5423601290137174d + "'", double1 == 0.5423601290137174d);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(9.001943858154728d, (double) (short) 10, (-0.5063656411097588d), 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: maximal number of iterations (0) exceeded");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        double double1 = org.apache.commons.math.util.FastMath.ceil(4042.186843756581d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4043.0d + "'", double1 == 4043.0d);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.5724612960652946d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6511762777390735d + "'", double1 == 0.6511762777390735d);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        double double2 = org.apache.commons.math.util.FastMath.max(0.10441471190359707d, 0.7241400178893855d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.7241400178893855d + "'", double2 == 0.7241400178893855d);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        double double1 = org.apache.commons.math.util.FastMath.tan(1.0E-9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0E-9d + "'", double1 == 1.0E-9d);
    }

//    @Test
//    public void test222() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test222");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT((double) 10L);
//        randomDataImpl1.reSeed();
//        double double6 = randomDataImpl1.nextChiSquare(0.5848500137377979d);
//        int int9 = randomDataImpl1.nextSecureInt((int) (byte) -1, 20);
//        double double11 = randomDataImpl1.nextExponential(3.141592653589793d);
//        try {
//            long long14 = randomDataImpl1.nextLong((long) 0, (long) (short) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 0 is larger than, or equal to, the maximum (0): lower bound (0) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.04254237884829251d + "'", double3 == 0.04254237884829251d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.15363136716311485d + "'", double6 == 0.15363136716311485d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 6.0248998988842d + "'", double11 == 6.0248998988842d);
//    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 284);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.185912937677754E123d + "'", double1 == 2.185912937677754E123d);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        java.lang.Object[] objArray4 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray4);
        org.apache.commons.math.exception.util.Localizable localizable6 = maxIterationsExceededException5.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) (short) -1, (java.lang.Number) 1.0d, false);
        java.lang.Object[] objArray16 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException17 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray16);
        java.lang.Object[] objArray18 = maxIterationsExceededException17.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException10, "", objArray18);
        boolean boolean20 = numberIsTooLargeException10.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable21 = numberIsTooLargeException10.getSpecificPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException25 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable21, (java.lang.Number) (-0.17877836497716262d), (java.lang.Number) 2.185912937677754E123d, false);
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(localizable6);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(localizable21);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        double double1 = org.apache.commons.math.util.FastMath.ulp(1.862009352569276d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(7.613135436994995E14d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3135192566529642E-15d + "'", double1 == 1.3135192566529642E-15d);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 8L, 10.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

//    @Test
//    public void test228() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test228");
//        double double0 = org.apache.commons.math.util.FastMath.random();
//        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.22110618141455785d + "'", double0 == 0.22110618141455785d);
//    }

//    @Test
//    public void test229() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test229");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextExponential(0.5772156649015329d);
//        double double6 = randomDataImpl1.nextF((double) (byte) 1, 1.0d);
//        java.lang.String str8 = randomDataImpl1.nextSecureHexString((int) (byte) 1);
//        try {
//            randomDataImpl1.setSecureAlgorithm("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0): ", "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0): ");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0): ");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.45954778412924246d + "'", double3 == 0.45954778412924246d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 54.56992133609129d + "'", double6 == 54.56992133609129d);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "8" + "'", str8.equals("8"));
//    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.17453292519943295d + "'", double1 == 0.17453292519943295d);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.1469366995820881d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        try {
            double double4 = randomDataImpl1.nextBeta(0.6511762777390735d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.5 p = 0.446");
        } catch (org.apache.commons.math.exception.MathUserException e) {
        }
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 61);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 61.0d + "'", double1 == 61.0d);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        double double1 = org.apache.commons.math.util.FastMath.ceil(45.887426936904006d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 46.0d + "'", double1 == 46.0d);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        int int2 = org.apache.commons.math.util.FastMath.max((int) '4', (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

//    @Test
//    public void test236() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test236");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextSecureHexString((int) '4');
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution4 = null;
//        try {
//            int int5 = randomDataImpl1.nextInversionDeviate(integerDistribution4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ba75583e0a6f25753e01aaae657934bbd91526258aae611a3b99" + "'", str3.equals("ba75583e0a6f25753e01aaae657934bbd91526258aae611a3b99"));
//    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.1446963233687307d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.989549739220151d + "'", double1 == 0.989549739220151d);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        double double1 = org.apache.commons.math.util.FastMath.asinh(1.0105609365269927d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8888216151907569d + "'", double1 == 0.8888216151907569d);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        double double1 = org.apache.commons.math.special.Erf.erf(5729.5779513082325d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1);
        java.lang.Class<?> wildcardClass2 = maxIterationsExceededException1.getClass();
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

//    @Test
//    public void test241() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test241");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextExponential(0.5772156649015329d);
//        org.apache.commons.math.distribution.ContinuousDistribution continuousDistribution4 = null;
//        try {
//            double double5 = randomDataImpl1.nextInversionDeviate(continuousDistribution4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.47795037088260056d + "'", double3 == 0.47795037088260056d);
//    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        double double1 = org.apache.commons.math.util.FastMath.log(0.5724612960652946d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5578101509651948d) + "'", double1 == (-0.5578101509651948d));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 3, 11013.232920103343d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        double double1 = org.apache.commons.math.util.FastMath.signum(1.3276384114812847d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(8.023043150857964d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.001918421812002d + "'", double1 == 2.001918421812002d);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException4 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable2, (java.lang.Number) 10);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException6 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable7 = notStrictlyPositiveException6.getGeneralPattern();
        java.lang.Number number8 = notStrictlyPositiveException6.getMin();
        notStrictlyPositiveException4.addSuppressed((java.lang.Throwable) notStrictlyPositiveException6);
        java.lang.Number number10 = notStrictlyPositiveException4.getArgument();
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 0 + "'", number8.equals(0));
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 10 + "'", number10.equals(10));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        long long1 = org.apache.commons.math.util.FastMath.round(0.7050434390927751d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) (short) 100);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ((-0.7853981633974483d), 5.298342365610589d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        double double2 = org.apache.commons.math.util.FastMath.pow(2.0d, (double) 43L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 8.796093022208E12d + "'", double2 == 8.796093022208E12d);
    }

//    @Test
//    public void test251() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test251");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT((double) 10L);
//        randomDataImpl1.reSeed();
//        double double6 = randomDataImpl1.nextChiSquare(0.5848500137377979d);
//        int int9 = randomDataImpl1.nextSecureInt((int) (byte) -1, 20);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution10 = null;
//        try {
//            int int11 = randomDataImpl1.nextInversionDeviate(integerDistribution10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.9012195486132026d + "'", double3 == 2.9012195486132026d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 5.609448591012339d + "'", double6 == 5.609448591012339d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
//    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1.0d, (java.lang.Number) 1.0d, true);
        boolean boolean4 = numberIsTooSmallException3.getBoundIsAllowed();
        java.lang.Number number5 = numberIsTooSmallException3.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException3.getSpecificPattern();
        org.apache.commons.math.MathException mathException7 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1.0d + "'", number5.equals(1.0d));
        org.junit.Assert.assertNull(localizable6);
    }

//    @Test
//    public void test253() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test253");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT((double) 10L);
//        randomDataImpl1.reSeed();
//        randomDataImpl1.reSeed();
//        try {
//            double double8 = randomDataImpl1.nextF((double) 97L, 1.3440585709080678E43d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 2 p = 0.012");
//        } catch (org.apache.commons.math.exception.MathUserException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-2.6495487203386383d) + "'", double3 == (-2.6495487203386383d));
//    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException4 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable5 = notStrictlyPositiveException4.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException7 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable8 = notStrictlyPositiveException7.getGeneralPattern();
        java.lang.Object[] objArray11 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException(localizable8, objArray11);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException14 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable15 = notStrictlyPositiveException14.getGeneralPattern();
        java.lang.Object[] objArray18 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException(localizable15, objArray18);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException22 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable23 = notStrictlyPositiveException22.getGeneralPattern();
        java.lang.Number number24 = notStrictlyPositiveException22.getArgument();
        java.lang.Object[] objArray25 = new java.lang.Object[] { 0, number24 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException26 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, localizable15, objArray25);
        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException(localizable5, objArray25);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, objArray25);
        java.lang.Class<?> wildcardClass29 = objArray25.getClass();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, "0a9413bf82824a5a7eef9e7859fd80f805dc34e275b134cf0f335342f3b7330b3e2c0817167d7998592ba04445b5e5bc0b99", objArray25);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertTrue("'" + localizable15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable15.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertTrue("'" + localizable23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable23.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + (-1L) + "'", number24.equals((-1L)));
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(wildcardClass29);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 2.6859233825834674d, (java.lang.Number) (-0.9251475365964139d), false);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(0.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        long long1 = org.apache.commons.math.util.FastMath.round(0.07714563080407891d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

//    @Test
//    public void test258() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test258");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextExponential(0.5772156649015329d);
//        double double6 = randomDataImpl1.nextF((double) (byte) 1, 1.0d);
//        java.lang.String str8 = randomDataImpl1.nextSecureHexString((int) (byte) 1);
//        long long11 = randomDataImpl1.nextSecureLong(0L, (long) 1);
//        double double14 = randomDataImpl1.nextGaussian((double) (byte) 1, 4042.186843756581d);
//        try {
//            double double17 = randomDataImpl1.nextUniform((double) 52L, 0.07382423751494867d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 52 is larger than, or equal to, the maximum (0.074): lower bound (52) must be strictly less than upper bound (0.074)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.07452981289634329d + "'", double3 == 0.07452981289634329d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 80.52636172047528d + "'", double6 == 80.52636172047528d);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "7" + "'", str8.equals("7"));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1287.4794023247873d + "'", double14 == 1287.4794023247873d);
//    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        double double1 = org.apache.commons.math.util.FastMath.asin(1.2852543175387054d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (-0.18072043342406346d), (java.lang.Number) 8.023043150857964d, (java.lang.Number) 0.250069889408776d);
        org.apache.commons.math.exception.util.Localizable localizable4 = outOfRangeException3.getSpecificPattern();
        java.lang.Number number5 = outOfRangeException3.getLo();
        org.junit.Assert.assertNull(localizable4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 8.023043150857964d + "'", number5.equals(8.023043150857964d));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        double double1 = org.apache.commons.math.util.FastMath.log10(1.0E-9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-9.0d) + "'", double1 == (-9.0d));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        double double1 = org.apache.commons.math.util.FastMath.expm1(1.3440585709080678E43d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

//    @Test
//    public void test263() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test263");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextSecureHexString((int) '4');
//        java.lang.String str5 = randomDataImpl1.nextHexString((int) (short) 100);
//        try {
//            double double7 = randomDataImpl1.nextExponential(0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): mean (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "f65f82b0a4bb35a9dc92086c1f6d12918c9feea4be7a41e4c108" + "'", str3.equals("f65f82b0a4bb35a9dc92086c1f6d12918c9feea4be7a41e4c108"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1d402e64bca6ff7666277821cc383a84d3dfcfac55487d009befa1849fd3008942516f9f20eb87e2d76044457533d6bd781f" + "'", str5.equals("1d402e64bca6ff7666277821cc383a84d3dfcfac55487d009befa1849fd3008942516f9f20eb87e2d76044457533d6bd781f"));
//    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.0536427460421095d, (double) 52L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0010315909041076798d + "'", double2 == 0.0010315909041076798d);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        int int2 = org.apache.commons.math.util.FastMath.min(284, 284);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 284 + "'", int2 == 284);
    }

//    @Test
//    public void test266() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test266");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextExponential(0.5772156649015329d);
//        double double6 = randomDataImpl1.nextF((double) (byte) 1, 1.0d);
//        randomDataImpl1.reSeedSecure();
//        double double9 = randomDataImpl1.nextExponential(35.966820416383136d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.971303484757032d + "'", double3 == 0.971303484757032d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 40.43867114883232d + "'", double6 == 40.43867114883232d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 19.486370353109457d + "'", double9 == 19.486370353109457d);
//    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        double double1 = org.apache.commons.math.util.FastMath.atanh(1.2852543175387054d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test268() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test268");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT((double) 10L);
//        randomDataImpl1.reSeed();
//        double double6 = randomDataImpl1.nextChiSquare(0.5848500137377979d);
//        int int9 = randomDataImpl1.nextSecureInt((int) (byte) -1, 20);
//        double double11 = randomDataImpl1.nextExponential(3.141592653589793d);
//        try {
//            double double14 = randomDataImpl1.nextF(1.0309090578119309d, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): degrees of freedom (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-0.8162689284305203d) + "'", double3 == (-0.8162689284305203d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.007452316138405644d + "'", double6 == 0.007452316138405644d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.7252630011525525d + "'", double11 == 1.7252630011525525d);
//    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.03982859541332048d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        double double1 = org.apache.commons.math.special.Erf.erf((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

//    @Test
//    public void test271() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test271");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.7241400178893855d, 5729.5779513082325d, (double) 1.0f);
//        double double4 = normalDistributionImpl3.sample();
//        normalDistributionImpl3.reseedRandomGenerator((long) '4');
//        double double7 = normalDistributionImpl3.getMean();
//        try {
//            double double9 = normalDistributionImpl3.inverseCumulativeProbability((double) 100L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 100 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-1034.4176905779113d) + "'", double4 == (-1034.4176905779113d));
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.7241400178893855d + "'", double7 == 0.7241400178893855d);
//    }

//    @Test
//    public void test272() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test272");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextExponential(0.5772156649015329d);
//        double double6 = randomDataImpl1.nextF((double) (byte) 1, 1.0d);
//        long long8 = randomDataImpl1.nextPoisson(10.000000000000002d);
//        try {
//            java.lang.String str10 = randomDataImpl1.nextHexString(0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): length (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.895787395264432d + "'", double3 == 0.895787395264432d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 5.02315783903724d + "'", double6 == 5.02315783903724d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 15L + "'", long8 == 15L);
//    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0);
    }

//    @Test
//    public void test274() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test274");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT((double) 10L);
//        double double6 = randomDataImpl1.nextBeta(0.20378364545839303d, (double) 6L);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution7 = null;
//        try {
//            int int8 = randomDataImpl1.nextInversionDeviate(integerDistribution7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.1494211911879522d) + "'", double3 == (-1.1494211911879522d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0016665232622797982d + "'", double6 == 0.0016665232622797982d);
//    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getGeneralPattern();
        java.lang.Object[] objArray5 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException(localizable2, objArray5);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable9 = notStrictlyPositiveException8.getGeneralPattern();
        java.lang.Object[] objArray12 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException(localizable9, objArray12);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException16 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable17 = notStrictlyPositiveException16.getGeneralPattern();
        java.lang.Number number18 = notStrictlyPositiveException16.getArgument();
        java.lang.Object[] objArray19 = new java.lang.Object[] { 0, number18 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException20 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, localizable9, objArray19);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException24 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable2, (java.lang.Number) 2.0d, (java.lang.Number) (-0.5063656411097588d), true);
        java.lang.Number number25 = numberIsTooLargeException24.getMax();
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + (-1L) + "'", number18.equals((-1L)));
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + (-0.5063656411097588d) + "'", number25.equals((-0.5063656411097588d)));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        double double1 = org.apache.commons.math.util.FastMath.cos(1.3213016811096636E45d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9043003119960416d) + "'", double1 == (-0.9043003119960416d));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        long long1 = org.apache.commons.math.util.FastMath.round(1.2711138659223065d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        double double1 = org.apache.commons.math.util.FastMath.tanh((-9.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.999999969540041d) + "'", double1 == (-0.999999969540041d));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.07382423751494867d, 0.002198713597520441d, 16.320112620161648d, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: maximal number of iterations (-1) exceeded");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

//    @Test
//    public void test280() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test280");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT((double) 10L);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl7 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.7241400178893855d, 5729.5779513082325d, (double) 1.0f);
//        double double10 = normalDistributionImpl7.cumulativeProbability(1.0000000000000002d, 32.577917486317425d);
//        double double11 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        try {
//            int int15 = randomDataImpl1.nextHypergeometric(8, (int) '4', 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 52 is larger than the maximum (8): number of successes (52) must be less than or equal to population size (8)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.1207268390531389d) + "'", double3 == (-1.1207268390531389d));
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.002198713597520441d + "'", double10 == 0.002198713597520441d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1001.3020913261416d + "'", double11 == 1001.3020913261416d);
//    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 61, (long) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 61L + "'", long2 == 61L);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 10L, 2.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.373400766945016d + "'", double2 == 1.373400766945016d);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        double double1 = org.apache.commons.math.util.FastMath.asin(1.0E-9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0E-9d + "'", double1 == 1.0E-9d);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        double double2 = org.apache.commons.math.util.FastMath.min(5.298342365610589d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

//    @Test
//    public void test286() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test286");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT((double) 10L);
//        randomDataImpl1.reSeed();
//        double double6 = randomDataImpl1.nextChiSquare(0.5848500137377979d);
//        int int9 = randomDataImpl1.nextSecureInt((int) (byte) -1, 20);
//        double double11 = randomDataImpl1.nextExponential(3.141592653589793d);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution12 = null;
//        try {
//            int int13 = randomDataImpl1.nextInversionDeviate(integerDistribution12);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0555484185758959d) + "'", double3 == (-1.0555484185758959d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0025408635833119235d + "'", double6 == 0.0025408635833119235d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 16 + "'", int9 == 16);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 6.651169560722194d + "'", double11 == 6.651169560722194d);
//    }

//    @Test
//    public void test287() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test287");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.7241400178893855d, 5729.5779513082325d, (double) 1.0f);
//        double double4 = normalDistributionImpl3.sample();
//        normalDistributionImpl3.reseedRandomGenerator((long) '4');
//        double double7 = normalDistributionImpl3.getMean();
//        normalDistributionImpl3.reseedRandomGenerator((long) 1);
//        try {
//            double double11 = normalDistributionImpl3.inverseCumulativeProbability(Double.NaN);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.724 p = �");
//        } catch (org.apache.commons.math.exception.MathUserException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-5738.457998722245d) + "'", double4 == (-5738.457998722245d));
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.7241400178893855d + "'", double7 == 0.7241400178893855d);
//    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable3 = notStrictlyPositiveException2.getGeneralPattern();
        java.lang.Object[] objArray6 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException7 = new org.apache.commons.math.MathException(localizable3, objArray6);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException9 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable10 = notStrictlyPositiveException9.getGeneralPattern();
        java.lang.Object[] objArray13 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException(localizable10, objArray13);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException17 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable18 = notStrictlyPositiveException17.getGeneralPattern();
        java.lang.Number number19 = notStrictlyPositiveException17.getArgument();
        java.lang.Object[] objArray20 = new java.lang.Object[] { 0, number19 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException21 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, localizable10, objArray20);
        java.lang.Object[] objArray27 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException28 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray27);
        org.apache.commons.math.exception.util.Localizable localizable29 = maxIterationsExceededException28.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException33 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable29, (java.lang.Number) (short) -1, (java.lang.Number) 1.0d, false);
        java.lang.Object[] objArray39 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException40 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray39);
        java.lang.Object[] objArray41 = maxIterationsExceededException40.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException33, "", objArray41);
        boolean boolean43 = numberIsTooLargeException33.getBoundIsAllowed();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException46 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable47 = notStrictlyPositiveException46.getGeneralPattern();
        java.lang.Object[] objArray50 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException51 = new org.apache.commons.math.MathException(localizable47, objArray50);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException53 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable54 = notStrictlyPositiveException53.getGeneralPattern();
        java.lang.Object[] objArray57 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException58 = new org.apache.commons.math.MathException(localizable54, objArray57);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException61 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable62 = notStrictlyPositiveException61.getGeneralPattern();
        java.lang.Number number63 = notStrictlyPositiveException61.getArgument();
        java.lang.Object[] objArray64 = new java.lang.Object[] { 0, number63 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException65 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable47, localizable54, objArray64);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException67 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable68 = notStrictlyPositiveException67.getGeneralPattern();
        java.lang.Object[] objArray71 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException72 = new org.apache.commons.math.MathException(localizable68, objArray71);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException74 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable75 = notStrictlyPositiveException74.getGeneralPattern();
        java.lang.Object[] objArray78 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException79 = new org.apache.commons.math.MathException(localizable75, objArray78);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException82 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable83 = notStrictlyPositiveException82.getGeneralPattern();
        java.lang.Number number84 = notStrictlyPositiveException82.getArgument();
        java.lang.Object[] objArray85 = new java.lang.Object[] { 0, number84 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException86 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable68, localizable75, objArray85);
        org.apache.commons.math.ConvergenceException convergenceException87 = new org.apache.commons.math.ConvergenceException(localizable54, objArray85);
        org.apache.commons.math.MathException mathException88 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException33, "05299f0e072343e00952d77e9bba14e42f77765c61bcdb705583", objArray85);
        org.apache.commons.math.ConvergenceException convergenceException89 = new org.apache.commons.math.ConvergenceException("1", objArray85);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException90 = new org.apache.commons.math.MaxIterationsExceededException(6, localizable3, objArray85);
        int int91 = maxIterationsExceededException90.getMaxIterations();
        org.junit.Assert.assertTrue("'" + localizable3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable3.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertTrue("'" + localizable10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable10.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertTrue("'" + localizable18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable18.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + (-1L) + "'", number19.equals((-1L)));
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(localizable29);
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertNotNull(objArray41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + localizable47 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable47.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray50);
        org.junit.Assert.assertTrue("'" + localizable54 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable54.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray57);
        org.junit.Assert.assertTrue("'" + localizable62 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable62.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number63 + "' != '" + (-1L) + "'", number63.equals((-1L)));
        org.junit.Assert.assertNotNull(objArray64);
        org.junit.Assert.assertTrue("'" + localizable68 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable68.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray71);
        org.junit.Assert.assertTrue("'" + localizable75 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable75.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray78);
        org.junit.Assert.assertTrue("'" + localizable83 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable83.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number84 + "' != '" + (-1L) + "'", number84.equals((-1L)));
        org.junit.Assert.assertNotNull(objArray85);
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 6 + "'", int91 == 6);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.49708625100776777d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 28.480944236725758d + "'", double1 == 28.480944236725758d);
    }

//    @Test
//    public void test290() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test290");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT((double) 10L);
//        double double6 = randomDataImpl1.nextBeta(0.20378364545839303d, (double) 6L);
//        try {
//            java.lang.String str8 = randomDataImpl1.nextSecureHexString(0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): length (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.8172474477401608d) + "'", double3 == (-1.8172474477401608d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.039924333086604126d + "'", double6 == 0.039924333086604126d);
//    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(3.627790532677618d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 207.85708647994426d + "'", double1 == 207.85708647994426d);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.20378364545839303d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 100.0f);
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getGeneralPattern();
        java.lang.Object[] objArray7 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException8 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray7);
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException(localizable2, objArray7);
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray7);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(10.000000000000002d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.154434690031884d + "'", double1 == 2.154434690031884d);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 13);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        double double1 = org.apache.commons.math.util.FastMath.ulp(1.1006710821571968d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        long long1 = org.apache.commons.math.util.FastMath.abs(100L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 100L + "'", long1 == 100L);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(7.613135436994995E14d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.532590689920738E16d + "'", double1 == 2.532590689920738E16d);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        double double2 = org.apache.commons.math.util.FastMath.min(0.7853981633974483d, (-0.9999999999999999d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.9999999999999999d) + "'", double2 == (-0.9999999999999999d));
    }

//    @Test
//    public void test301() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test301");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextExponential(0.5772156649015329d);
//        double double6 = randomDataImpl1.nextUniform(1.000188513259658d, 7.930067261567154E14d);
//        long long9 = randomDataImpl1.nextLong(6L, 43L);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.4606335169367413d + "'", double3 == 1.4606335169367413d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 7.774290469738962E14d + "'", double6 == 7.774290469738962E14d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 42L + "'", long9 == 42L);
//    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable3 = notStrictlyPositiveException2.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException5 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable3, (java.lang.Number) 10);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException7 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable8 = notStrictlyPositiveException7.getGeneralPattern();
        java.lang.Object[] objArray11 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException(localizable8, objArray11);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException14 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable15 = notStrictlyPositiveException14.getGeneralPattern();
        java.lang.Object[] objArray18 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException(localizable15, objArray18);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException22 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable23 = notStrictlyPositiveException22.getGeneralPattern();
        java.lang.Number number24 = notStrictlyPositiveException22.getArgument();
        java.lang.Object[] objArray25 = new java.lang.Object[] { 0, number24 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException26 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, localizable15, objArray25);
        java.lang.Number number28 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException30 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable15, (java.lang.Number) 5.298342365610589d, number28, false);
        java.lang.Object[] objArray35 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException36 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray35);
        org.apache.commons.math.ConvergenceException convergenceException37 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException5, localizable15, objArray35);
        mathException0.addSuppressed((java.lang.Throwable) convergenceException37);
        org.junit.Assert.assertTrue("'" + localizable3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable3.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertTrue("'" + localizable15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable15.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertTrue("'" + localizable23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable23.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + (-1L) + "'", number24.equals((-1L)));
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(objArray35);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        java.lang.Object[] objArray4 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray4);
        org.apache.commons.math.exception.util.Localizable localizable6 = maxIterationsExceededException5.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable6, (java.lang.Number) (byte) 100);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException12 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable13 = notStrictlyPositiveException12.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException15 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable16 = notStrictlyPositiveException15.getGeneralPattern();
        java.lang.Object[] objArray19 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException(localizable16, objArray19);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException22 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable23 = notStrictlyPositiveException22.getGeneralPattern();
        java.lang.Object[] objArray26 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException(localizable23, objArray26);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException30 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable31 = notStrictlyPositiveException30.getGeneralPattern();
        java.lang.Number number32 = notStrictlyPositiveException30.getArgument();
        java.lang.Object[] objArray33 = new java.lang.Object[] { 0, number32 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException34 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable16, localizable23, objArray33);
        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException(localizable13, objArray33);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException36 = new org.apache.commons.math.MaxIterationsExceededException(13, "a34c55f0739f9aae49d9f5e9d2529ed6155d671dabbf6861d2367d831c61d6ebb9b0eb8a6890f16189205c7299dda5e03249", objArray33);
        org.apache.commons.math.ConvergenceException convergenceException37 = new org.apache.commons.math.ConvergenceException(localizable6, objArray33);
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(localizable6);
        org.junit.Assert.assertTrue("'" + localizable13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable13.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable16.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertTrue("'" + localizable23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable23.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertTrue("'" + localizable31 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable31.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number32 + "' != '" + (-1L) + "'", number32.equals((-1L)));
        org.junit.Assert.assertNotNull(objArray33);
    }

//    @Test
//    public void test304() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test304");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextExponential(0.5772156649015329d);
//        double double6 = randomDataImpl1.nextF((double) (byte) 1, 1.0d);
//        java.lang.String str8 = randomDataImpl1.nextSecureHexString((int) (byte) 1);
//        try {
//            double double11 = randomDataImpl1.nextBeta(0.10441471190359707d, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.5 p = 0.441");
//        } catch (org.apache.commons.math.exception.MathUserException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.6545350645899917d + "'", double3 == 0.6545350645899917d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 3.9077943497170065d + "'", double6 == 3.9077943497170065d);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "5" + "'", str8.equals("5"));
//    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) 1.1006710821571968d, (java.lang.Number) 0.1469366995820881d, (java.lang.Number) 0.16635096647323788d);
        java.lang.Number number5 = outOfRangeException4.getLo();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.1469366995820881d + "'", number5.equals(0.1469366995820881d));
    }

//    @Test
//    public void test306() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test306");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT((double) 10L);
//        double double5 = randomDataImpl1.nextExponential((double) 6L);
//        try {
//            double double7 = randomDataImpl1.nextT(0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): degrees of freedom (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-0.4750575647920131d) + "'", double3 == (-0.4750575647920131d));
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 6.376612700028503d + "'", double5 == 6.376612700028503d);
//    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (byte) 1, 279L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.03982859541332048d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.03905588746769781d + "'", double1 == 0.03905588746769781d);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.7241400178893855d, 5729.5779513082325d, (double) 1.0f);
        double double5 = normalDistributionImpl3.density((-0.8813735870195429d));
        normalDistributionImpl3.reseedRandomGenerator((long) ' ');
        try {
            double double9 = normalDistributionImpl3.inverseCumulativeProbability((double) 'a');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 97 out of [0, 1] range");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 6.962856045056186E-5d + "'", double5 == 6.962856045056186E-5d);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1.0d, (java.lang.Number) 1.0d, true);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooSmallException3.getSpecificPattern();
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException3);
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException3.getSpecificPattern();
        org.junit.Assert.assertNull(localizable4);
        org.junit.Assert.assertNull(localizable6);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1.0d, (java.lang.Number) 1.0d, true);
        boolean boolean4 = numberIsTooSmallException3.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException3.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException7 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable8 = notStrictlyPositiveException7.getGeneralPattern();
        java.lang.Object[] objArray11 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException(localizable8, objArray11);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException14 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable15 = notStrictlyPositiveException14.getGeneralPattern();
        java.lang.Object[] objArray18 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException(localizable15, objArray18);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException22 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable23 = notStrictlyPositiveException22.getGeneralPattern();
        java.lang.Number number24 = notStrictlyPositiveException22.getArgument();
        java.lang.Object[] objArray25 = new java.lang.Object[] { 0, number24 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException26 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, localizable15, objArray25);
        java.lang.Object[] objArray31 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException32 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray31);
        org.apache.commons.math.exception.util.Localizable localizable33 = maxIterationsExceededException32.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException37 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable33, (java.lang.Number) (short) -1, (java.lang.Number) 1.0d, false);
        java.lang.Object[] objArray43 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException44 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray43);
        java.lang.Object[] objArray45 = maxIterationsExceededException44.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException37, "", objArray45);
        boolean boolean47 = numberIsTooLargeException37.getBoundIsAllowed();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException50 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable51 = notStrictlyPositiveException50.getGeneralPattern();
        java.lang.Object[] objArray54 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException55 = new org.apache.commons.math.MathException(localizable51, objArray54);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException57 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable58 = notStrictlyPositiveException57.getGeneralPattern();
        java.lang.Object[] objArray61 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException62 = new org.apache.commons.math.MathException(localizable58, objArray61);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException65 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable66 = notStrictlyPositiveException65.getGeneralPattern();
        java.lang.Number number67 = notStrictlyPositiveException65.getArgument();
        java.lang.Object[] objArray68 = new java.lang.Object[] { 0, number67 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException69 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable51, localizable58, objArray68);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException71 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable72 = notStrictlyPositiveException71.getGeneralPattern();
        java.lang.Object[] objArray75 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException76 = new org.apache.commons.math.MathException(localizable72, objArray75);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException78 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable79 = notStrictlyPositiveException78.getGeneralPattern();
        java.lang.Object[] objArray82 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException83 = new org.apache.commons.math.MathException(localizable79, objArray82);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException86 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable87 = notStrictlyPositiveException86.getGeneralPattern();
        java.lang.Number number88 = notStrictlyPositiveException86.getArgument();
        java.lang.Object[] objArray89 = new java.lang.Object[] { 0, number88 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException90 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable72, localizable79, objArray89);
        org.apache.commons.math.ConvergenceException convergenceException91 = new org.apache.commons.math.ConvergenceException(localizable58, objArray89);
        org.apache.commons.math.MathException mathException92 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException37, "05299f0e072343e00952d77e9bba14e42f77765c61bcdb705583", objArray89);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException93 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable15, objArray89);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException94 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, objArray89);
        org.apache.commons.math.exception.util.Localizable localizable95 = mathIllegalArgumentException94.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertTrue("'" + localizable15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable15.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertTrue("'" + localizable23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable23.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + (-1L) + "'", number24.equals((-1L)));
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(localizable33);
        org.junit.Assert.assertNotNull(objArray43);
        org.junit.Assert.assertNotNull(objArray45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + localizable51 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable51.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray54);
        org.junit.Assert.assertTrue("'" + localizable58 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable58.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray61);
        org.junit.Assert.assertTrue("'" + localizable66 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable66.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number67 + "' != '" + (-1L) + "'", number67.equals((-1L)));
        org.junit.Assert.assertNotNull(objArray68);
        org.junit.Assert.assertTrue("'" + localizable72 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable72.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray75);
        org.junit.Assert.assertTrue("'" + localizable79 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable79.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray82);
        org.junit.Assert.assertTrue("'" + localizable87 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable87.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number88 + "' != '" + (-1L) + "'", number88.equals((-1L)));
        org.junit.Assert.assertNotNull(objArray89);
        org.junit.Assert.assertNull(localizable95);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable3 = notStrictlyPositiveException2.getGeneralPattern();
        java.lang.Object[] objArray6 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException7 = new org.apache.commons.math.MathException(localizable3, objArray6);
        java.lang.Object[] objArray12 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException13 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray12);
        org.apache.commons.math.exception.util.Localizable localizable14 = maxIterationsExceededException13.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException18 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable14, (java.lang.Number) (short) -1, (java.lang.Number) 1.0d, false);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException20 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable21 = notStrictlyPositiveException20.getGeneralPattern();
        java.lang.Object[] objArray24 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException(localizable21, objArray24);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException27 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable28 = notStrictlyPositiveException27.getGeneralPattern();
        java.lang.Object[] objArray31 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException32 = new org.apache.commons.math.MathException(localizable28, objArray31);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException35 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable36 = notStrictlyPositiveException35.getGeneralPattern();
        java.lang.Number number37 = notStrictlyPositiveException35.getArgument();
        java.lang.Object[] objArray38 = new java.lang.Object[] { 0, number37 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException39 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable21, localizable28, objArray38);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException41 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable42 = notStrictlyPositiveException41.getGeneralPattern();
        java.lang.Object[] objArray45 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException46 = new org.apache.commons.math.MathException(localizable42, objArray45);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException48 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable49 = notStrictlyPositiveException48.getGeneralPattern();
        java.lang.Object[] objArray52 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException53 = new org.apache.commons.math.MathException(localizable49, objArray52);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException56 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable57 = notStrictlyPositiveException56.getGeneralPattern();
        java.lang.Number number58 = notStrictlyPositiveException56.getArgument();
        java.lang.Object[] objArray59 = new java.lang.Object[] { 0, number58 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException60 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable42, localizable49, objArray59);
        org.apache.commons.math.ConvergenceException convergenceException61 = new org.apache.commons.math.ConvergenceException(localizable28, objArray59);
        java.lang.Object[] objArray67 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException68 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray67);
        org.apache.commons.math.exception.util.Localizable localizable69 = maxIterationsExceededException68.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException73 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable69, (java.lang.Number) (short) -1, (java.lang.Number) 1.0d, false);
        java.lang.Object[] objArray79 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException80 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray79);
        java.lang.Object[] objArray81 = maxIterationsExceededException80.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException82 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException73, "", objArray81);
        org.apache.commons.math.MathException mathException83 = new org.apache.commons.math.MathException("", objArray81);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException84 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable14, localizable28, objArray81);
        java.lang.Object[] objArray85 = mathIllegalArgumentException84.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException86 = new org.apache.commons.math.MaxIterationsExceededException(10, localizable3, objArray85);
        org.apache.commons.math.MathException mathException87 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException86);
        org.junit.Assert.assertTrue("'" + localizable3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable3.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(localizable14);
        org.junit.Assert.assertTrue("'" + localizable21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable21.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertTrue("'" + localizable28 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable28.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertTrue("'" + localizable36 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable36.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number37 + "' != '" + (-1L) + "'", number37.equals((-1L)));
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertTrue("'" + localizable42 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable42.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray45);
        org.junit.Assert.assertTrue("'" + localizable49 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable49.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray52);
        org.junit.Assert.assertTrue("'" + localizable57 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable57.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number58 + "' != '" + (-1L) + "'", number58.equals((-1L)));
        org.junit.Assert.assertNotNull(objArray59);
        org.junit.Assert.assertNotNull(objArray67);
        org.junit.Assert.assertNotNull(localizable69);
        org.junit.Assert.assertNotNull(objArray79);
        org.junit.Assert.assertNotNull(objArray81);
        org.junit.Assert.assertNotNull(objArray85);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 61L, (double) (-1L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 61.0d + "'", double2 == 61.0d);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        double double1 = org.apache.commons.math.util.FastMath.log((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable1 = mathException0.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + localizable1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable1.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
    }

//    @Test
//    public void test316() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test316");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextExponential(0.5772156649015329d);
//        double double6 = randomDataImpl1.nextCauchy(0.19323284172500138d, 11013.232920103343d);
//        long long9 = randomDataImpl1.nextLong((long) (-1), (long) 284);
//        try {
//            int int12 = randomDataImpl1.nextSecureInt(52, (int) (short) 10);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 52 is larger than, or equal to, the maximum (10): lower bound (52) must be strictly less than upper bound (10)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.39697152187275225d + "'", double3 == 0.39697152187275225d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-13129.026049549402d) + "'", double6 == (-13129.026049549402d));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 124L + "'", long9 == 124L);
//    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) (byte) 100, 1.3440585709080678E43d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.00000000000001d + "'", double2 == 100.00000000000001d);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.49708625100776777d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5425251449676736d + "'", double1 == 0.5425251449676736d);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(0.3824362445485816d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.880271694974504d + "'", double1 == 7.880271694974504d);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        double double2 = org.apache.commons.math.util.FastMath.pow(61.0d, (-5571.853811290455d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.31285066809386347d, 1.2852543175387054d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9406341874643835d + "'", double2 == 0.9406341874643835d);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 100.0f);
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getGeneralPattern();
        boolean boolean3 = notStrictlyPositiveException1.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.0536427460421095d, (double) 3, 2.220446049250313E-16d, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: Continued fraction convergents failed to converge (in less than 3 iterations) for value {1}");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        int int2 = org.apache.commons.math.util.FastMath.min(0, (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 6L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999877116507956d + "'", double1 == 0.9999877116507956d);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.7241400178893855d, 5729.5779513082325d, (double) 1.0f);
        double double4 = normalDistributionImpl3.getStandardDeviation();
        double double6 = normalDistributionImpl3.inverseCumulativeProbability(0.971303484757032d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 5729.5779513082325d + "'", double4 == 5729.5779513082325d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 10888.302091325902d + "'", double6 == 10888.302091325902d);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        double double1 = org.apache.commons.math.util.FastMath.expm1(46.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.496119420602448E19d + "'", double1 == 9.496119420602448E19d);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.0031724211906162063d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0000000000000002d + "'", double1 == 1.0000000000000002d);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        int int2 = org.apache.commons.math.util.FastMath.min((int) ' ', 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(10);
        java.lang.String str2 = maxIterationsExceededException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.apache.commons.math.MaxIterationsExceededException: maximal number of iterations (10) exceeded" + "'", str2.equals("org.apache.commons.math.MaxIterationsExceededException: maximal number of iterations (10) exceeded"));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 61L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.105427357601002E-15d + "'", double1 == 7.105427357601002E-15d);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((-0.1764938974788445d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-10.11235543535243d) + "'", double1 == (-10.11235543535243d));
    }

//    @Test
//    public void test334() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test334");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT((double) 10L);
//        double double5 = randomDataImpl1.nextExponential((double) 6L);
//        try {
//            randomDataImpl1.setSecureAlgorithm("7e9d4f32b073cb6826d0dc6e66d1af1360491d1175d1413fda52", "a34c55f0739f9aae49d9f5e9d2529ed6155d671dabbf6861d2367d831c61d6ebb9b0eb8a6890f16189205c7299dda5e03249");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: a34c55f0739f9aae49d9f5e9d2529ed6155d671dabbf6861d2367d831c61d6ebb9b0eb8a6890f16189205c7299dda5e03249");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-0.03608695006822743d) + "'", double3 == (-0.03608695006822743d));
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.4549742390354795d + "'", double5 == 0.4549742390354795d);
//    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        java.lang.Object[] objArray6 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException7 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray6);
        org.apache.commons.math.exception.util.Localizable localizable8 = maxIterationsExceededException7.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException12 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable8, (java.lang.Number) (short) -1, (java.lang.Number) 1.0d, false);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException14 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable15 = notStrictlyPositiveException14.getGeneralPattern();
        java.lang.Object[] objArray18 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException(localizable15, objArray18);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException21 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable22 = notStrictlyPositiveException21.getGeneralPattern();
        java.lang.Object[] objArray25 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException(localizable22, objArray25);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException29 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable30 = notStrictlyPositiveException29.getGeneralPattern();
        java.lang.Number number31 = notStrictlyPositiveException29.getArgument();
        java.lang.Object[] objArray32 = new java.lang.Object[] { 0, number31 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException33 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable15, localizable22, objArray32);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException35 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable36 = notStrictlyPositiveException35.getGeneralPattern();
        java.lang.Object[] objArray39 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException40 = new org.apache.commons.math.MathException(localizable36, objArray39);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException42 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable43 = notStrictlyPositiveException42.getGeneralPattern();
        java.lang.Object[] objArray46 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException47 = new org.apache.commons.math.MathException(localizable43, objArray46);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException50 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable51 = notStrictlyPositiveException50.getGeneralPattern();
        java.lang.Number number52 = notStrictlyPositiveException50.getArgument();
        java.lang.Object[] objArray53 = new java.lang.Object[] { 0, number52 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException54 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable36, localizable43, objArray53);
        org.apache.commons.math.ConvergenceException convergenceException55 = new org.apache.commons.math.ConvergenceException(localizable22, objArray53);
        java.lang.Object[] objArray61 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException62 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray61);
        org.apache.commons.math.exception.util.Localizable localizable63 = maxIterationsExceededException62.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException67 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable63, (java.lang.Number) (short) -1, (java.lang.Number) 1.0d, false);
        java.lang.Object[] objArray73 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException74 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray73);
        java.lang.Object[] objArray75 = maxIterationsExceededException74.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException76 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException67, "", objArray75);
        org.apache.commons.math.MathException mathException77 = new org.apache.commons.math.MathException("", objArray75);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException78 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, localizable22, objArray75);
        java.lang.Object[] objArray79 = mathIllegalArgumentException78.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException80 = new org.apache.commons.math.MaxIterationsExceededException((int) ' ', "340726b388127493d6e5109e5c0f71fab8b0e44502d739711457", objArray79);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(localizable8);
        org.junit.Assert.assertTrue("'" + localizable15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable15.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertTrue("'" + localizable22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable22.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertTrue("'" + localizable30 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable30.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number31 + "' != '" + (-1L) + "'", number31.equals((-1L)));
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertTrue("'" + localizable36 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable36.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertTrue("'" + localizable43 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable43.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray46);
        org.junit.Assert.assertTrue("'" + localizable51 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable51.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number52 + "' != '" + (-1L) + "'", number52.equals((-1L)));
        org.junit.Assert.assertNotNull(objArray53);
        org.junit.Assert.assertNotNull(objArray61);
        org.junit.Assert.assertNotNull(localizable63);
        org.junit.Assert.assertNotNull(objArray73);
        org.junit.Assert.assertNotNull(objArray75);
        org.junit.Assert.assertNotNull(objArray79);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 13L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
    }

//    @Test
//    public void test338() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test338");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextExponential(0.5772156649015329d);
//        double double6 = randomDataImpl1.nextUniform(1.000188513259658d, 7.930067261567154E14d);
//        try {
//            long long9 = randomDataImpl1.nextSecureLong(57L, (long) 52);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 57 is larger than, or equal to, the maximum (52): lower bound (57) must be strictly less than upper bound (52)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.6946182465993432d + "'", double3 == 0.6946182465993432d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.4761676081338384E14d + "'", double6 == 1.4761676081338384E14d);
//    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.0d, (double) 19);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.9E-324d + "'", double2 == 4.9E-324d);
    }

//    @Test
//    public void test340() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test340");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextExponential(0.5772156649015329d);
//        double double6 = randomDataImpl1.nextUniform(1.000188513259658d, 7.930067261567154E14d);
//        int int9 = randomDataImpl1.nextSecureInt((int) (short) 1, (int) (byte) 10);
//        double double11 = randomDataImpl1.nextChiSquare(4.641588833612779d);
//        randomDataImpl1.reSeedSecure((long) 52);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.7043462875874329d + "'", double3 == 0.7043462875874329d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 5.397476518613372E14d + "'", double6 == 5.397476518613372E14d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.972221734488155d + "'", double11 == 0.972221734488155d);
//    }

//    @Test
//    public void test341() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test341");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextExponential(0.5772156649015329d);
//        double double6 = randomDataImpl1.nextCauchy(0.19323284172500138d, 11013.232920103343d);
//        try {
//            double double9 = randomDataImpl1.nextWeibull((double) 100, Double.NEGATIVE_INFINITY);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -∞ is smaller than, or equal to, the minimum (0): scale (-∞)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.701375745685848d + "'", double3 == 0.701375745685848d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 14997.466258945538d + "'", double6 == 14997.466258945538d);
//    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        double double1 = org.apache.commons.math.special.Gamma.logGamma((double) (byte) 0);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        double double1 = org.apache.commons.math.special.Erf.erf(1560.8713124921853d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(1.2729698034198502d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.27296980341985d + "'", double2 == 1.27296980341985d);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ((double) 5, 0.14693669958208808d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9999994948902197d + "'", double2 == 0.9999994948902197d);
    }

//    @Test
//    public void test346() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test346");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT((double) 10L);
//        double double5 = randomDataImpl1.nextT(6.342124518290157d);
//        randomDataImpl1.reSeed();
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.1804612711887845d) + "'", double3 == (-1.1804612711887845d));
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-0.25414070878837436d) + "'", double5 == (-0.25414070878837436d));
//    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.7241400178893855d, 5729.5779513082325d, (double) 1.0f);
        double double5 = normalDistributionImpl3.density((-0.8813735870195429d));
        double double6 = normalDistributionImpl3.getMean();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 6.962856045056186E-5d + "'", double5 == 6.962856045056186E-5d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.7241400178893855d + "'", double6 == 0.7241400178893855d);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.014602538937188877d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.734723475976807E-18d + "'", double1 == 1.734723475976807E-18d);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (-0.18072043342406346d), (java.lang.Number) 8.023043150857964d, (java.lang.Number) 0.250069889408776d);
        org.apache.commons.math.exception.util.Localizable localizable4 = outOfRangeException3.getSpecificPattern();
        java.lang.Number number5 = outOfRangeException3.getArgument();
        org.junit.Assert.assertNull(localizable4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-0.18072043342406346d) + "'", number5.equals((-0.18072043342406346d)));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(10.000000000000002d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.1622776601683795d + "'", double1 == 3.1622776601683795d);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        double double1 = org.apache.commons.math.util.FastMath.acosh(3.141592653589793d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.8115262724608532d + "'", double1 == 1.8115262724608532d);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(7.930067261567154E14d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.5435938534266416E16d + "'", double1 == 4.5435938534266416E16d);
    }

//    @Test
//    public void test353() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test353");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextExponential(0.5772156649015329d);
//        double double6 = randomDataImpl1.nextUniform(1.000188513259658d, 7.930067261567154E14d);
//        randomDataImpl1.reSeedSecure();
//        try {
//            java.lang.String str9 = randomDataImpl1.nextSecureHexString((int) (byte) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): length (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.6077812175424853d + "'", double3 == 0.6077812175424853d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 7.565257345261515E14d + "'", double6 == 7.565257345261515E14d);
//    }

//    @Test
//    public void test354() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test354");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.7241400178893855d, 5729.5779513082325d, (double) 1.0f);
//        double double4 = normalDistributionImpl3.sample();
//        normalDistributionImpl3.reseedRandomGenerator((long) '4');
//        double double7 = normalDistributionImpl3.getMean();
//        normalDistributionImpl3.reseedRandomGenerator((long) 1);
//        normalDistributionImpl3.reseedRandomGenerator((long) (byte) 0);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 6665.260726501785d + "'", double4 == 6665.260726501785d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.7241400178893855d + "'", double7 == 0.7241400178893855d);
//    }

//    @Test
//    public void test355() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test355");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextExponential(0.5772156649015329d);
//        double double6 = randomDataImpl1.nextCauchy(0.19323284172500138d, 11013.232920103343d);
//        long long9 = randomDataImpl1.nextLong((long) (-1), (long) 284);
//        long long11 = randomDataImpl1.nextPoisson((double) (byte) 1);
//        try {
//            long long14 = randomDataImpl1.nextLong(10L, (long) (short) -1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 10 is larger than, or equal to, the maximum (-1): lower bound (10) must be strictly less than upper bound (-1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.6165919246611032d + "'", double3 == 0.6165919246611032d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 81251.60646425975d + "'", double6 == 81251.60646425975d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 147L + "'", long9 == 147L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
//    }

//    @Test
//    public void test356() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test356");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT((double) 10L);
//        int int6 = randomDataImpl1.nextInt(4, (int) '4');
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-0.40922283418245425d) + "'", double3 == (-0.40922283418245425d));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 23 + "'", int6 == 23);
//    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0.0d, (java.lang.Number) 0.019416865714155625d, true);
        boolean boolean4 = numberIsTooLargeException3.getBoundIsAllowed();
        boolean boolean5 = numberIsTooLargeException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

//    @Test
//    public void test358() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test358");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextSecureHexString((int) '4');
//        try {
//            int int6 = randomDataImpl1.nextInt((int) ' ', 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 32 is larger than, or equal to, the maximum (0): lower bound (32) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0b7755279345c162b5e20830cc8128e14f6645a1ac46c4eb4a62" + "'", str3.equals("0b7755279345c162b5e20830cc8128e14f6645a1ac46c4eb4a62"));
//    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(12104.755054344712d, 0.0d, 0.014602538937188877d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): standard deviation (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 10.0f, (java.lang.Number) 0.5772156649015329d, (java.lang.Number) (short) -1);
        java.lang.Number number4 = outOfRangeException3.getLo();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.5772156649015329d + "'", number4.equals(0.5772156649015329d));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.0d, 4.8851119809000325E14d, 0.31285066809386347d, 284);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(3.2931430675399556d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.354352118349556d + "'", double1 == 0.354352118349556d);
    }

//    @Test
//    public void test363() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test363");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT((double) 10L);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl7 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.7241400178893855d, 5729.5779513082325d, (double) 1.0f);
//        double double10 = normalDistributionImpl7.cumulativeProbability(1.0000000000000002d, 32.577917486317425d);
//        double double11 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        randomDataImpl1.reSeedSecure((long) ' ');
//        try {
//            long long16 = randomDataImpl1.nextLong((long) '4', 9L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 52 is larger than, or equal to, the maximum (9): lower bound (52) must be strictly less than upper bound (9)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.34985282975436105d + "'", double3 == 0.34985282975436105d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.002198713597520441d + "'", double10 == 0.002198713597520441d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 13251.30209132612d + "'", double11 == 13251.30209132612d);
//    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        double double2 = org.apache.commons.math.util.FastMath.max(0.014602538937188877d, 0.7043462875874329d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.7043462875874329d + "'", double2 == 0.7043462875874329d);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        double double1 = org.apache.commons.math.util.FastMath.expm1(1.4130122174770463d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.108311913428225d + "'", double1 == 3.108311913428225d);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((-2164.2137316548624d), 0.6511762777390735d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-2164.213731654862d) + "'", double2 == (-2164.213731654862d));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        java.lang.Object[] objArray5 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException6 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray5);
        org.apache.commons.math.exception.util.Localizable localizable7 = maxIterationsExceededException6.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException11 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable7, (java.lang.Number) (short) -1, (java.lang.Number) 1.0d, false);
        java.lang.Object[] objArray17 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException18 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray17);
        java.lang.Object[] objArray19 = maxIterationsExceededException18.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException11, "", objArray19);
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException("hi!", objArray19);
        java.lang.String str22 = mathException21.toString();
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(localizable7);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.apache.commons.math.MathException: hi!" + "'", str22.equals("org.apache.commons.math.MathException: hi!"));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.7241400178893855d, 5729.5779513082325d, (double) 1.0f);
        double double4 = normalDistributionImpl3.getStandardDeviation();
        double[] doubleArray6 = normalDistributionImpl3.sample(284);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 5729.5779513082325d + "'", double4 == 5729.5779513082325d);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getGeneralPattern();
        java.lang.Object[] objArray5 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException(localizable2, objArray5);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable9 = notStrictlyPositiveException8.getGeneralPattern();
        java.lang.Object[] objArray12 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException(localizable9, objArray12);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException16 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable17 = notStrictlyPositiveException16.getGeneralPattern();
        java.lang.Number number18 = notStrictlyPositiveException16.getArgument();
        java.lang.Object[] objArray19 = new java.lang.Object[] { 0, number18 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException20 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, localizable9, objArray19);
        java.lang.Number number22 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException24 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable9, (java.lang.Number) 5.298342365610589d, number22, false);
        java.lang.Object[] objArray30 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException31 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray30);
        org.apache.commons.math.MathException mathException32 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException24, "org.apache.commons.math.exception.NotStrictlyPositiveException: -1 is smaller than, or equal to, the minimum (0)", objArray30);
        boolean boolean33 = numberIsTooSmallException24.getBoundIsAllowed();
        java.lang.Number number34 = numberIsTooSmallException24.getMin();
        java.lang.Number number35 = numberIsTooSmallException24.getMin();
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + (-1L) + "'", number18.equals((-1L)));
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNull(number34);
        org.junit.Assert.assertNull(number35);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (-1));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        double double1 = org.apache.commons.math.util.FastMath.log((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

//    @Test
//    public void test372() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test372");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextExponential(0.5772156649015329d);
//        double double6 = randomDataImpl1.nextF((double) (byte) 1, 1.0d);
//        long long8 = randomDataImpl1.nextPoisson(10.000000000000002d);
//        randomDataImpl1.reSeedSecure();
//        java.lang.String str11 = randomDataImpl1.nextSecureHexString(10);
//        double double14 = randomDataImpl1.nextF((double) 23, 72.93579718355548d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.3273817120025671d + "'", double3 == 0.3273817120025671d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 127.86804180196543d + "'", double6 == 127.86804180196543d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 10L + "'", long8 == 10L);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "cde6519172" + "'", str11.equals("cde6519172"));
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.9290047307600733d + "'", double14 == 0.9290047307600733d);
//    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.7241400178893855d, 4042.186843756581d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.7241400178893856d + "'", double2 == 0.7241400178893856d);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        double double1 = org.apache.commons.math.util.FastMath.ceil(4.5435938534266416E16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.5435938534266416E16d + "'", double1 == 4.5435938534266416E16d);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        double double1 = org.apache.commons.math.util.FastMath.atanh(6.342124518290157d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        int int2 = org.apache.commons.math.util.FastMath.max(1, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0.0d, (java.lang.Number) 0.019416865714155625d, true);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooLargeException3.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException8 = new org.apache.commons.math.exception.OutOfRangeException(localizable4, (java.lang.Number) 100L, (java.lang.Number) 11013.232920103343d, (java.lang.Number) 2.1974405382543956d);
        java.lang.Number number9 = outOfRangeException8.getHi();
        java.lang.Throwable[] throwableArray10 = outOfRangeException8.getSuppressed();
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 2.1974405382543956d + "'", number9.equals(2.1974405382543956d));
        org.junit.Assert.assertNotNull(throwableArray10);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 13);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 13.0d + "'", double1 == 13.0d);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 0, Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY);
        double double4 = normalDistributionImpl3.getStandardDeviation();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + Double.POSITIVE_INFINITY + "'", double4 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(0);
    }

//    @Test
//    public void test381() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test381");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT((double) 10L);
//        double double5 = randomDataImpl1.nextT(6.342124518290157d);
//        try {
//            int int8 = randomDataImpl1.nextZipf(0, 0.03982859541332048d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): dimension (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.016652550488960458d + "'", double3 == 0.016652550488960458d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.6324656594171086d + "'", double5 == 0.6324656594171086d);
//    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.3830263845524403d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0742558192087117d + "'", double1 == 1.0742558192087117d);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getGeneralPattern();
        java.lang.Object[] objArray7 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException8 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray7);
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException(localizable2, objArray7);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException13 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1.0d, (java.lang.Number) 1.0d, true);
        org.apache.commons.math.exception.util.Localizable localizable14 = numberIsTooSmallException13.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException16 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable17 = notStrictlyPositiveException16.getGeneralPattern();
        java.lang.Object[] objArray20 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException(localizable17, objArray20);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException23 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable24 = notStrictlyPositiveException23.getGeneralPattern();
        java.lang.Object[] objArray27 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException28 = new org.apache.commons.math.MathException(localizable24, objArray27);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException31 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable32 = notStrictlyPositiveException31.getGeneralPattern();
        java.lang.Number number33 = notStrictlyPositiveException31.getArgument();
        java.lang.Object[] objArray34 = new java.lang.Object[] { 0, number33 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException35 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable17, localizable24, objArray34);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException37 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable38 = notStrictlyPositiveException37.getGeneralPattern();
        java.lang.Object[] objArray41 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException42 = new org.apache.commons.math.MathException(localizable38, objArray41);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException44 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable45 = notStrictlyPositiveException44.getGeneralPattern();
        java.lang.Object[] objArray48 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException49 = new org.apache.commons.math.MathException(localizable45, objArray48);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException52 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable53 = notStrictlyPositiveException52.getGeneralPattern();
        java.lang.Number number54 = notStrictlyPositiveException52.getArgument();
        java.lang.Object[] objArray55 = new java.lang.Object[] { 0, number54 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException56 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable38, localizable45, objArray55);
        org.apache.commons.math.ConvergenceException convergenceException57 = new org.apache.commons.math.ConvergenceException(localizable24, objArray55);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException58 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, localizable14, objArray55);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException60 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable61 = notStrictlyPositiveException60.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException63 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable61, (java.lang.Number) 10);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException65 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable66 = notStrictlyPositiveException65.getGeneralPattern();
        java.lang.Object[] objArray69 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException70 = new org.apache.commons.math.MathException(localizable66, objArray69);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException72 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable73 = notStrictlyPositiveException72.getGeneralPattern();
        java.lang.Object[] objArray76 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException77 = new org.apache.commons.math.MathException(localizable73, objArray76);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException80 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable81 = notStrictlyPositiveException80.getGeneralPattern();
        java.lang.Number number82 = notStrictlyPositiveException80.getArgument();
        java.lang.Object[] objArray83 = new java.lang.Object[] { 0, number82 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException84 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable66, localizable73, objArray83);
        java.lang.Number number86 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException88 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable73, (java.lang.Number) 5.298342365610589d, number86, false);
        java.lang.Object[] objArray93 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException94 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray93);
        org.apache.commons.math.ConvergenceException convergenceException95 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException63, localizable73, objArray93);
        java.lang.Throwable[] throwableArray96 = convergenceException95.getSuppressed();
        org.apache.commons.math.MathException mathException97 = new org.apache.commons.math.MathException(localizable2, (java.lang.Object[]) throwableArray96);
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertTrue("'" + localizable14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable14.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertTrue("'" + localizable24 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable24.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertTrue("'" + localizable32 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable32.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number33 + "' != '" + (-1L) + "'", number33.equals((-1L)));
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertTrue("'" + localizable38 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable38.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray41);
        org.junit.Assert.assertTrue("'" + localizable45 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable45.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray48);
        org.junit.Assert.assertTrue("'" + localizable53 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable53.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number54 + "' != '" + (-1L) + "'", number54.equals((-1L)));
        org.junit.Assert.assertNotNull(objArray55);
        org.junit.Assert.assertTrue("'" + localizable61 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable61.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable66 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable66.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray69);
        org.junit.Assert.assertTrue("'" + localizable73 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable73.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray76);
        org.junit.Assert.assertTrue("'" + localizable81 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable81.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number82 + "' != '" + (-1L) + "'", number82.equals((-1L)));
        org.junit.Assert.assertNotNull(objArray83);
        org.junit.Assert.assertNotNull(objArray93);
        org.junit.Assert.assertNotNull(throwableArray96);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getGeneralPattern();
        java.lang.Object[] objArray5 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException(localizable2, objArray5);
        java.lang.Object[] objArray11 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException12 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray11);
        org.apache.commons.math.exception.util.Localizable localizable13 = maxIterationsExceededException12.getGeneralPattern();
        java.lang.Throwable[] throwableArray14 = maxIterationsExceededException12.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable15 = maxIterationsExceededException12.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException18 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable19 = notStrictlyPositiveException18.getGeneralPattern();
        java.lang.Object[] objArray22 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException23 = new org.apache.commons.math.MathException(localizable19, objArray22);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException25 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable26 = notStrictlyPositiveException25.getGeneralPattern();
        java.lang.Object[] objArray29 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException30 = new org.apache.commons.math.MathException(localizable26, objArray29);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException33 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable34 = notStrictlyPositiveException33.getGeneralPattern();
        java.lang.Number number35 = notStrictlyPositiveException33.getArgument();
        java.lang.Object[] objArray36 = new java.lang.Object[] { 0, number35 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException37 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable19, localizable26, objArray36);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException39 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable40 = notStrictlyPositiveException39.getGeneralPattern();
        java.lang.Object[] objArray43 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException(localizable40, objArray43);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException46 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable47 = notStrictlyPositiveException46.getGeneralPattern();
        java.lang.Object[] objArray50 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException51 = new org.apache.commons.math.MathException(localizable47, objArray50);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException54 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable55 = notStrictlyPositiveException54.getGeneralPattern();
        java.lang.Number number56 = notStrictlyPositiveException54.getArgument();
        java.lang.Object[] objArray57 = new java.lang.Object[] { 0, number56 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException58 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable40, localizable47, objArray57);
        org.apache.commons.math.ConvergenceException convergenceException59 = new org.apache.commons.math.ConvergenceException(localizable26, objArray57);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException61 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable62 = notStrictlyPositiveException61.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException64 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable62, (java.lang.Number) 10);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException66 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable67 = notStrictlyPositiveException66.getGeneralPattern();
        java.lang.Object[] objArray70 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException71 = new org.apache.commons.math.MathException(localizable67, objArray70);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException73 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable74 = notStrictlyPositiveException73.getGeneralPattern();
        java.lang.Object[] objArray77 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException78 = new org.apache.commons.math.MathException(localizable74, objArray77);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException81 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable82 = notStrictlyPositiveException81.getGeneralPattern();
        java.lang.Number number83 = notStrictlyPositiveException81.getArgument();
        java.lang.Object[] objArray84 = new java.lang.Object[] { 0, number83 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException85 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable67, localizable74, objArray84);
        java.lang.Number number87 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException89 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable74, (java.lang.Number) 5.298342365610589d, number87, false);
        java.lang.Object[] objArray94 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException95 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray94);
        org.apache.commons.math.ConvergenceException convergenceException96 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException64, localizable74, objArray94);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException97 = new org.apache.commons.math.MaxIterationsExceededException(284, localizable26, objArray94);
        org.apache.commons.math.ConvergenceException convergenceException98 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException6, localizable15, objArray94);
        java.lang.Class<?> wildcardClass99 = mathException6.getClass();
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(localizable13);
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertNotNull(localizable15);
        org.junit.Assert.assertTrue("'" + localizable19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable19.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertTrue("'" + localizable26 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable26.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertTrue("'" + localizable34 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable34.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number35 + "' != '" + (-1L) + "'", number35.equals((-1L)));
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertTrue("'" + localizable40 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable40.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray43);
        org.junit.Assert.assertTrue("'" + localizable47 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable47.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray50);
        org.junit.Assert.assertTrue("'" + localizable55 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable55.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number56 + "' != '" + (-1L) + "'", number56.equals((-1L)));
        org.junit.Assert.assertNotNull(objArray57);
        org.junit.Assert.assertTrue("'" + localizable62 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable62.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable67 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable67.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray70);
        org.junit.Assert.assertTrue("'" + localizable74 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable74.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray77);
        org.junit.Assert.assertTrue("'" + localizable82 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable82.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number83 + "' != '" + (-1L) + "'", number83.equals((-1L)));
        org.junit.Assert.assertNotNull(objArray84);
        org.junit.Assert.assertNotNull(objArray94);
        org.junit.Assert.assertNotNull(wildcardClass99);
    }

//    @Test
//    public void test386() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test386");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextExponential(0.5772156649015329d);
//        double double6 = randomDataImpl1.nextF((double) (byte) 1, 1.0d);
//        java.lang.String str8 = randomDataImpl1.nextSecureHexString((int) (byte) 1);
//        long long11 = randomDataImpl1.nextSecureLong(0L, (long) 1);
//        double double14 = randomDataImpl1.nextGaussian((double) (byte) 1, 4042.186843756581d);
//        try {
//            long long17 = randomDataImpl1.nextLong(0L, (long) (byte) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 0 is larger than, or equal to, the maximum (0): lower bound (0) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.44019959612790033d + "'", double3 == 0.44019959612790033d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.046951322528855095d + "'", double6 == 0.046951322528855095d);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "f" + "'", str8.equals("f"));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 645.3461431269354d + "'", double14 == 645.3461431269354d);
//    }

//    @Test
//    public void test387() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test387");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextExponential(0.5772156649015329d);
//        double double6 = randomDataImpl1.nextF((double) (byte) 1, 1.0d);
//        java.lang.String str8 = randomDataImpl1.nextSecureHexString((int) (byte) 1);
//        try {
//            int int12 = randomDataImpl1.nextHypergeometric((int) (byte) 1, (int) 'a', 284);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 97 is larger than the maximum (1): number of successes (97) must be less than or equal to population size (1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.5366179926200104d + "'", double3 == 0.5366179926200104d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 115.39052603522703d + "'", double6 == 115.39052603522703d);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "7" + "'", str8.equals("7"));
//    }

//    @Test
//    public void test388() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test388");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextExponential(0.5772156649015329d);
//        double double6 = randomDataImpl1.nextCauchy(0.19323284172500138d, 11013.232920103343d);
//        long long9 = randomDataImpl1.nextLong((long) (-1), (long) 284);
//        try {
//            double double12 = randomDataImpl1.nextWeibull(0.0d, 0.7241400178893855d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): shape (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.5393757728001419d + "'", double3 == 0.5393757728001419d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 46.490025110902934d + "'", double6 == 46.490025110902934d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 186L + "'", long9 == 186L);
//    }

//    @Test
//    public void test389() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test389");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT((double) 10L);
//        double double5 = randomDataImpl1.nextExponential((double) 6L);
//        try {
//            int int8 = randomDataImpl1.nextInt(0, 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 0 is larger than, or equal to, the maximum (0): lower bound (0) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-0.2777493536855524d) + "'", double3 == (-0.2777493536855524d));
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 6.940106144303065d + "'", double5 == 6.940106144303065d);
//    }

//    @Test
//    public void test390() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test390");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT((double) 10L);
//        randomDataImpl1.reSeed();
//        double double6 = randomDataImpl1.nextChiSquare(0.5848500137377979d);
//        int int9 = randomDataImpl1.nextSecureInt((int) (byte) -1, 20);
//        double double11 = randomDataImpl1.nextExponential(3.141592653589793d);
//        int int14 = randomDataImpl1.nextBinomial(0, 0.0d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-0.29629496840409586d) + "'", double3 == (-0.29629496840409586d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05488747802741582d + "'", double6 == 0.05488747802741582d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.941686022558121d + "'", double11 == 1.941686022558121d);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.7241400178893855d, 5729.5779513082325d, (double) 1.0f);
        double double4 = normalDistributionImpl3.getStandardDeviation();
        double[] doubleArray6 = normalDistributionImpl3.sample(4);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 5729.5779513082325d + "'", double4 == 5729.5779513082325d);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        double double1 = org.apache.commons.math.util.FastMath.expm1(1.000188513259658d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7187943089303614d + "'", double1 == 1.7187943089303614d);
    }

//    @Test
//    public void test394() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test394");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT((double) 10L);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl7 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.7241400178893855d, 5729.5779513082325d, (double) 1.0f);
//        double double10 = normalDistributionImpl7.cumulativeProbability(1.0000000000000002d, 32.577917486317425d);
//        double double11 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        randomDataImpl1.reSeedSecure((long) ' ');
//        try {
//            double double15 = randomDataImpl1.nextExponential(0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): mean (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-0.2605019807251674d) + "'", double3 == (-0.2605019807251674d));
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.002198713597520441d + "'", double10 == 0.002198713597520441d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-7108.853811290343d) + "'", double11 == (-7108.853811290343d));
//    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        int int2 = org.apache.commons.math.util.FastMath.max(100, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

//    @Test
//    public void test396() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test396");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextSecureHexString((int) '4');
//        long long6 = randomDataImpl1.nextSecureLong((long) (-1), (long) '4');
//        randomDataImpl1.reSeed((long) (short) 100);
//        try {
//            randomDataImpl1.setSecureAlgorithm("f9f8f812d1", "8");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: 8");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "b7f07bd82f0e77f95aba7917612c989c2d72fa5cd8d95d57befc" + "'", str3.equals("b7f07bd82f0e77f95aba7917612c989c2d72fa5cd8d95d57befc"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
//    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2005.3522829578812d + "'", double1 == 2005.3522829578812d);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        double double1 = org.apache.commons.math.util.FastMath.tan(6665.260726501785d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.563679679041324d) + "'", double1 == (-2.563679679041324d));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 7, 100L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 7L + "'", long2 == 7L);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        double double1 = org.apache.commons.math.util.FastMath.ceil(5088.340316698749d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5089.0d + "'", double1 == 5089.0d);
    }

//    @Test
//    public void test401() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test401");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextExponential(0.5772156649015329d);
//        double double6 = randomDataImpl1.nextF((double) (byte) 1, 1.0d);
//        long long8 = randomDataImpl1.nextPoisson(10.000000000000002d);
//        randomDataImpl1.reSeedSecure();
//        double double11 = randomDataImpl1.nextChiSquare((double) 52);
//        randomDataImpl1.reSeed((long) 6);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.5126247503705206d + "'", double3 == 0.5126247503705206d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.1512161953218819d + "'", double6 == 0.1512161953218819d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 8L + "'", long8 == 8L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 61.377187852187404d + "'", double11 == 61.377187852187404d);
//    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException4 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable2, (java.lang.Number) 10);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException6 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable7 = notStrictlyPositiveException6.getGeneralPattern();
        java.lang.Object[] objArray10 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException(localizable7, objArray10);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException13 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable14 = notStrictlyPositiveException13.getGeneralPattern();
        java.lang.Object[] objArray17 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException(localizable14, objArray17);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException21 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable22 = notStrictlyPositiveException21.getGeneralPattern();
        java.lang.Number number23 = notStrictlyPositiveException21.getArgument();
        java.lang.Object[] objArray24 = new java.lang.Object[] { 0, number23 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException25 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, localizable14, objArray24);
        java.lang.Number number27 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException29 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable14, (java.lang.Number) 5.298342365610589d, number27, false);
        java.lang.Object[] objArray34 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException35 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray34);
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException4, localizable14, objArray34);
        java.lang.Throwable[] throwableArray37 = convergenceException36.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.ConvergenceException convergenceException40 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException39);
        java.lang.String str41 = convergenceException40.getPattern();
        java.lang.Object[] objArray42 = convergenceException40.getArguments();
        org.apache.commons.math.MathException mathException43 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException36, "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0): ", objArray42);
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertTrue("'" + localizable14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable14.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertTrue("'" + localizable22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable22.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + (-1L) + "'", number23.equals((-1L)));
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(throwableArray37);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "{0}" + "'", str41.equals("{0}"));
        org.junit.Assert.assertNotNull(objArray42);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        double double2 = org.apache.commons.math.util.FastMath.atan2(3.627790532677618d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

//    @Test
//    public void test404() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test404");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.7241400178893855d, 5729.5779513082325d, (double) 1.0f);
//        double double4 = normalDistributionImpl3.getStandardDeviation();
//        double double5 = normalDistributionImpl3.sample();
//        double[] doubleArray7 = normalDistributionImpl3.sample(20);
//        double double9 = normalDistributionImpl3.inverseCumulativeProbability(0.0d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 5729.5779513082325d + "'", double4 == 5729.5779513082325d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4683.4947847980275d + "'", double5 == 4683.4947847980275d);
//        org.junit.Assert.assertNotNull(doubleArray7);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + Double.NEGATIVE_INFINITY + "'", double9 == Double.NEGATIVE_INFINITY);
//    }

//    @Test
//    public void test405() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test405");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextExponential(0.5772156649015329d);
//        double double6 = randomDataImpl1.nextF((double) (byte) 1, 1.0d);
//        long long8 = randomDataImpl1.nextPoisson(10.000000000000002d);
//        randomDataImpl1.reSeedSecure();
//        double double11 = randomDataImpl1.nextChiSquare((double) 52);
//        try {
//            int int14 = randomDataImpl1.nextPascal((int) (byte) 0, (double) 100.0f);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 100 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.17912081404049468d + "'", double3 == 0.17912081404049468d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.146383515881853d + "'", double6 == 0.146383515881853d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 8L + "'", long8 == 8L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 52.321703888463745d + "'", double11 == 52.321703888463745d);
//    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        double double2 = org.apache.commons.math.util.FastMath.min(1.3213016811096636E45d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 0, Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY);
        double double5 = normalDistributionImpl3.cumulativeProbability(6.342124518290157d);
        normalDistributionImpl3.reseedRandomGenerator(0L);
        try {
            double double9 = normalDistributionImpl3.inverseCumulativeProbability(Double.POSITIVE_INFINITY);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: ∞ out of [0, 1] range");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.5d + "'", double5 == 0.5d);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.7804384644833656d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.013621220814443558d + "'", double1 == 0.013621220814443558d);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.ConvergenceException convergenceException1 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException0);
        java.lang.String str2 = convergenceException1.getPattern();
        java.lang.Object[] objArray3 = convergenceException1.getArguments();
        java.lang.String str4 = convergenceException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{0}" + "'", str2.equals("{0}"));
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.ConvergenceException: convergence failed" + "'", str4.equals("org.apache.commons.math.ConvergenceException: convergence failed"));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        float float2 = org.apache.commons.math.util.FastMath.min((float) '#', 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(46.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.5830478710159466d + "'", double1 == 3.5830478710159466d);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (-1));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.014602538937188877d, (double) 6L, 0.052371959612836624d);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        int int2 = org.apache.commons.math.util.FastMath.min((int) '4', (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (-0.8390715290764514d), (java.lang.Number) 0.019416865714155625d, (java.lang.Number) (byte) -1);
        java.lang.Number number4 = outOfRangeException3.getHi();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (byte) -1 + "'", number4.equals((byte) -1));
    }

//    @Test
//    public void test416() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test416");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT((double) 10L);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl7 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.7241400178893855d, 5729.5779513082325d, (double) 1.0f);
//        double double10 = normalDistributionImpl7.cumulativeProbability(1.0000000000000002d, 32.577917486317425d);
//        double double11 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        randomDataImpl1.reSeedSecure((long) ' ');
//        try {
//            int int17 = randomDataImpl1.nextHypergeometric((int) '#', (int) 'a', 13);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 97 is larger than the maximum (35): number of successes (97) must be less than or equal to population size (35)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.45502772324741775d + "'", double3 == 0.45502772324741775d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.002198713597520441d + "'", double10 == 0.002198713597520441d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 3760.3020913261216d + "'", double11 == 3760.3020913261216d);
//    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.09728253468786653d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1021717313803565d + "'", double1 == 1.1021717313803565d);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        double double1 = org.apache.commons.math.special.Erf.erf(6.342124518290157d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        double double1 = org.apache.commons.math.util.FastMath.ceil(5652.686218477152d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5653.0d + "'", double1 == 5653.0d);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (-0.8390715290764514d), (java.lang.Number) 0.019416865714155625d, (java.lang.Number) (byte) -1);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException5 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable6 = notStrictlyPositiveException5.getGeneralPattern();
        java.lang.Object[] objArray11 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException12 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray11);
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException(localizable6, objArray11);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException17 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1.0d, (java.lang.Number) 1.0d, true);
        org.apache.commons.math.exception.util.Localizable localizable18 = numberIsTooSmallException17.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException20 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable21 = notStrictlyPositiveException20.getGeneralPattern();
        java.lang.Object[] objArray24 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException(localizable21, objArray24);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException27 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable28 = notStrictlyPositiveException27.getGeneralPattern();
        java.lang.Object[] objArray31 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException32 = new org.apache.commons.math.MathException(localizable28, objArray31);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException35 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable36 = notStrictlyPositiveException35.getGeneralPattern();
        java.lang.Number number37 = notStrictlyPositiveException35.getArgument();
        java.lang.Object[] objArray38 = new java.lang.Object[] { 0, number37 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException39 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable21, localizable28, objArray38);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException41 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable42 = notStrictlyPositiveException41.getGeneralPattern();
        java.lang.Object[] objArray45 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException46 = new org.apache.commons.math.MathException(localizable42, objArray45);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException48 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable49 = notStrictlyPositiveException48.getGeneralPattern();
        java.lang.Object[] objArray52 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException53 = new org.apache.commons.math.MathException(localizable49, objArray52);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException56 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable57 = notStrictlyPositiveException56.getGeneralPattern();
        java.lang.Number number58 = notStrictlyPositiveException56.getArgument();
        java.lang.Object[] objArray59 = new java.lang.Object[] { 0, number58 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException60 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable42, localizable49, objArray59);
        org.apache.commons.math.ConvergenceException convergenceException61 = new org.apache.commons.math.ConvergenceException(localizable28, objArray59);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException62 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, localizable18, objArray59);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException66 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable67 = notStrictlyPositiveException66.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException69 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable70 = notStrictlyPositiveException69.getGeneralPattern();
        java.lang.Object[] objArray73 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException74 = new org.apache.commons.math.MathException(localizable70, objArray73);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException76 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable77 = notStrictlyPositiveException76.getGeneralPattern();
        java.lang.Object[] objArray80 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException81 = new org.apache.commons.math.MathException(localizable77, objArray80);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException84 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable85 = notStrictlyPositiveException84.getGeneralPattern();
        java.lang.Number number86 = notStrictlyPositiveException84.getArgument();
        java.lang.Object[] objArray87 = new java.lang.Object[] { 0, number86 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException88 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable70, localizable77, objArray87);
        org.apache.commons.math.MathException mathException89 = new org.apache.commons.math.MathException(localizable67, objArray87);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException90 = new org.apache.commons.math.MaxIterationsExceededException(13, "a34c55f0739f9aae49d9f5e9d2529ed6155d671dabbf6861d2367d831c61d6ebb9b0eb8a6890f16189205c7299dda5e03249", objArray87);
        org.apache.commons.math.ConvergenceException convergenceException91 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3, localizable18, objArray87);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertTrue("'" + localizable18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable18.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizable21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable21.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertTrue("'" + localizable28 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable28.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertTrue("'" + localizable36 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable36.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number37 + "' != '" + (-1L) + "'", number37.equals((-1L)));
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertTrue("'" + localizable42 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable42.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray45);
        org.junit.Assert.assertTrue("'" + localizable49 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable49.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray52);
        org.junit.Assert.assertTrue("'" + localizable57 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable57.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number58 + "' != '" + (-1L) + "'", number58.equals((-1L)));
        org.junit.Assert.assertNotNull(objArray59);
        org.junit.Assert.assertTrue("'" + localizable67 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable67.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable70 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable70.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray73);
        org.junit.Assert.assertTrue("'" + localizable77 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable77.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray80);
        org.junit.Assert.assertTrue("'" + localizable85 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable85.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number86 + "' != '" + (-1L) + "'", number86.equals((-1L)));
        org.junit.Assert.assertNotNull(objArray87);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.07382423751494867d, 61.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.122989523030726E-70d + "'", double2 == 9.122989523030726E-70d);
    }

//    @Test
//    public void test422() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test422");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT((double) 10L);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl7 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.7241400178893855d, 5729.5779513082325d, (double) 1.0f);
//        double double10 = normalDistributionImpl7.cumulativeProbability(1.0000000000000002d, 32.577917486317425d);
//        double double11 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        double double13 = randomDataImpl1.nextT(0.49708625100776777d);
//        long long15 = randomDataImpl1.nextPoisson(0.7854924111435233d);
//        java.lang.String str17 = randomDataImpl1.nextHexString(52);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.6390099350493297d + "'", double3 == 1.6390099350493297d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.002198713597520441d + "'", double10 == 0.002198713597520441d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-672.8538112903434d) + "'", double11 == (-672.8538112903434d));
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-30.735170217788653d) + "'", double13 == (-30.735170217788653d));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "7b011d94a719a0ab9d143e049f1b3e4f9cc151b4aa12fcbcf88e" + "'", str17.equals("7b011d94a719a0ab9d143e049f1b3e4f9cc151b4aa12fcbcf88e"));
//    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        double double1 = org.apache.commons.math.special.Gamma.digamma(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

//    @Test
//    public void test424() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test424");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.7241400178893855d, 5729.5779513082325d, (double) 1.0f);
//        double double4 = normalDistributionImpl3.getStandardDeviation();
//        double double5 = normalDistributionImpl3.sample();
//        double double8 = normalDistributionImpl3.cumulativeProbability(0.43820761657943896d, 0.5187754889940697d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 5729.5779513082325d + "'", double4 == 5729.5779513082325d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4499.454388795798d + "'", double5 == 4499.454388795798d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 5.609825189822892E-6d + "'", double8 == 5.609825189822892E-6d);
//    }

//    @Test
//    public void test425() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test425");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextExponential(0.5772156649015329d);
//        double double6 = randomDataImpl1.nextF((double) (byte) 1, 1.0d);
//        int int9 = randomDataImpl1.nextSecureInt((int) '#', (int) 'a');
//        try {
//            double double12 = randomDataImpl1.nextUniform(61.377187852187404d, 0.2184900773038401d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 61.377 is larger than, or equal to, the maximum (0.218): lower bound (61.377) must be strictly less than upper bound (0.218)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.04248630776961446d + "'", double3 == 0.04248630776961446d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.0054535752575844d + "'", double6 == 2.0054535752575844d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 52 + "'", int9 == 52);
//    }

//    @Test
//    public void test426() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test426");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT((double) 10L);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl7 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.7241400178893855d, 5729.5779513082325d, (double) 1.0f);
//        double double10 = normalDistributionImpl7.cumulativeProbability(1.0000000000000002d, 32.577917486317425d);
//        double double11 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        double double13 = randomDataImpl1.nextT(0.49708625100776777d);
//        double double16 = randomDataImpl1.nextBeta(4.5435938534266416E16d, 5578.334491566705d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.6073498962466648d + "'", double3 == 1.6073498962466648d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.002198713597520441d + "'", double10 == 0.002198713597520441d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 7210.302091325977d + "'", double11 == 7210.302091325977d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.307139214973909d + "'", double13 == 1.307139214973909d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
//    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.03905588746769781d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.03907575771822817d + "'", double1 == 0.03907575771822817d);
    }

//    @Test
//    public void test428() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test428");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.7241400178893855d, 5729.5779513082325d, (double) 1.0f);
//        double double4 = normalDistributionImpl3.getStandardDeviation();
//        double double5 = normalDistributionImpl3.sample();
//        double[] doubleArray7 = normalDistributionImpl3.sample(20);
//        double double8 = normalDistributionImpl3.getStandardDeviation();
//        double double9 = normalDistributionImpl3.sample();
//        double double12 = normalDistributionImpl3.cumulativeProbability(1.7141516006622417d, 11.363121841068297d);
//        double double14 = normalDistributionImpl3.cumulativeProbability(12104.755054344712d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 5729.5779513082325d + "'", double4 == 5729.5779513082325d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-12352.21109622818d) + "'", double5 == (-12352.21109622818d));
//        org.junit.Assert.assertNotNull(doubleArray7);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 5729.5779513082325d + "'", double8 == 5729.5779513082325d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-5692.998374363383d) + "'", double9 == (-5692.998374363383d));
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 6.718435087020858E-4d + "'", double12 == 6.718435087020858E-4d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.9826804312789398d + "'", double14 == 0.9826804312789398d);
//    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1.0d, (java.lang.Number) 1.0d, true);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooSmallException3.getSpecificPattern();
        java.lang.Number number5 = numberIsTooSmallException3.getMin();
        java.lang.Number number6 = numberIsTooSmallException3.getMin();
        org.junit.Assert.assertNull(localizable4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1.0d + "'", number5.equals(1.0d));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 1.0d + "'", number6.equals(1.0d));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 100.0f);
        java.lang.String str2 = notStrictlyPositiveException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str2.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        double double1 = org.apache.commons.math.util.FastMath.ceil(10888.302091325902d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10889.0d + "'", double1 == 10889.0d);
    }

//    @Test
//    public void test432() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test432");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextSecureHexString((int) '4');
//        randomDataImpl1.reSeedSecure();
//        try {
//            int int8 = randomDataImpl1.nextHypergeometric(0, (int) ' ', 1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): population size (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "a4fe54de963e4a733243635a1baf7ccaa8b95aa3030c9fbdf5f3" + "'", str3.equals("a4fe54de963e4a733243635a1baf7ccaa8b95aa3030c9fbdf5f3"));
//    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 20);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.4258259770489514E8d + "'", double1 == 2.4258259770489514E8d);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5440211108893698d) + "'", double1 == (-0.5440211108893698d));
    }

//    @Test
//    public void test435() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test435");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextExponential(0.5772156649015329d);
//        double double6 = randomDataImpl1.nextUniform(1.000188513259658d, 7.930067261567154E14d);
//        randomDataImpl1.reSeedSecure();
//        try {
//            double double10 = randomDataImpl1.nextGamma(0.0d, (-0.24143681260328675d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): alpha");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.3487878353655873d + "'", double3 == 1.3487878353655873d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 3.100787385537287E14d + "'", double6 == 3.100787385537287E14d);
//    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getGeneralPattern();
        java.lang.Number number3 = notStrictlyPositiveException1.getMin();
        org.apache.commons.math.exception.util.Localizable localizable4 = notStrictlyPositiveException1.getSpecificPattern();
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException1);
        org.apache.commons.math.exception.util.Localizable localizable6 = convergenceException5.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
        org.junit.Assert.assertNull(localizable4);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getGeneralPattern();
        java.lang.Object[] objArray5 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException(localizable2, objArray5);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable9 = notStrictlyPositiveException8.getGeneralPattern();
        java.lang.Object[] objArray12 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException(localizable9, objArray12);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException16 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable17 = notStrictlyPositiveException16.getGeneralPattern();
        java.lang.Number number18 = notStrictlyPositiveException16.getArgument();
        java.lang.Object[] objArray19 = new java.lang.Object[] { 0, number18 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException20 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, localizable9, objArray19);
        java.lang.Object[] objArray25 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException26 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray25);
        org.apache.commons.math.exception.util.Localizable localizable27 = maxIterationsExceededException26.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException31 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable27, (java.lang.Number) (short) -1, (java.lang.Number) 1.0d, false);
        java.lang.Object[] objArray37 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException38 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray37);
        java.lang.Object[] objArray39 = maxIterationsExceededException38.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException40 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException31, "", objArray39);
        boolean boolean41 = numberIsTooLargeException31.getBoundIsAllowed();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException44 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable45 = notStrictlyPositiveException44.getGeneralPattern();
        java.lang.Object[] objArray48 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException49 = new org.apache.commons.math.MathException(localizable45, objArray48);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException51 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable52 = notStrictlyPositiveException51.getGeneralPattern();
        java.lang.Object[] objArray55 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException56 = new org.apache.commons.math.MathException(localizable52, objArray55);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException59 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable60 = notStrictlyPositiveException59.getGeneralPattern();
        java.lang.Number number61 = notStrictlyPositiveException59.getArgument();
        java.lang.Object[] objArray62 = new java.lang.Object[] { 0, number61 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException63 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable45, localizable52, objArray62);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException65 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable66 = notStrictlyPositiveException65.getGeneralPattern();
        java.lang.Object[] objArray69 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException70 = new org.apache.commons.math.MathException(localizable66, objArray69);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException72 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable73 = notStrictlyPositiveException72.getGeneralPattern();
        java.lang.Object[] objArray76 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException77 = new org.apache.commons.math.MathException(localizable73, objArray76);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException80 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable81 = notStrictlyPositiveException80.getGeneralPattern();
        java.lang.Number number82 = notStrictlyPositiveException80.getArgument();
        java.lang.Object[] objArray83 = new java.lang.Object[] { 0, number82 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException84 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable66, localizable73, objArray83);
        org.apache.commons.math.ConvergenceException convergenceException85 = new org.apache.commons.math.ConvergenceException(localizable52, objArray83);
        org.apache.commons.math.MathException mathException86 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException31, "05299f0e072343e00952d77e9bba14e42f77765c61bcdb705583", objArray83);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException87 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable9, objArray83);
        org.apache.commons.math.MathException mathException88 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException87);
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + (-1L) + "'", number18.equals((-1L)));
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(localizable27);
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + localizable45 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable45.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray48);
        org.junit.Assert.assertTrue("'" + localizable52 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable52.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray55);
        org.junit.Assert.assertTrue("'" + localizable60 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable60.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number61 + "' != '" + (-1L) + "'", number61.equals((-1L)));
        org.junit.Assert.assertNotNull(objArray62);
        org.junit.Assert.assertTrue("'" + localizable66 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable66.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray69);
        org.junit.Assert.assertTrue("'" + localizable73 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable73.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray76);
        org.junit.Assert.assertTrue("'" + localizable81 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable81.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number82 + "' != '" + (-1L) + "'", number82.equals((-1L)));
        org.junit.Assert.assertNotNull(objArray83);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 100, (java.lang.Number) (byte) -1, (java.lang.Number) 0.0d);
        java.lang.Number number4 = outOfRangeException3.getHi();
        java.lang.Number number5 = outOfRangeException3.getLo();
        java.lang.Number number6 = outOfRangeException3.getHi();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.0d + "'", number4.equals(0.0d));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (byte) -1 + "'", number5.equals((byte) -1));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0.0d + "'", number6.equals(0.0d));
    }

//    @Test
//    public void test439() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test439");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT((double) 10L);
//        randomDataImpl1.reSeed();
//        double double6 = randomDataImpl1.nextChiSquare(0.5848500137377979d);
//        int int9 = randomDataImpl1.nextSecureInt((int) (byte) -1, 20);
//        double double11 = randomDataImpl1.nextExponential(3.141592653589793d);
//        double double14 = randomDataImpl1.nextGamma(1.3135192566529642E-15d, 65.82838642403674d);
//        randomDataImpl1.reSeed();
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-2.4857819716816723d) + "'", double3 == (-2.4857819716816723d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0263075346092196E-6d + "'", double6 == 1.0263075346092196E-6d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 8 + "'", int9 == 8);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.6564629488648077d + "'", double11 == 0.6564629488648077d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.957406298024531E-9d + "'", double14 == 1.957406298024531E-9d);
//    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.7241400178893855d, 5729.5779513082325d, (double) 1.0f);
        double double6 = normalDistributionImpl3.cumulativeProbability(1.0000000000000002d, 32.577917486317425d);
        double double8 = normalDistributionImpl3.density(0.08272307916163937d);
        try {
            double double11 = normalDistributionImpl3.cumulativeProbability((double) 13, (double) 9L);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.002198713597520441d + "'", double6 == 0.002198713597520441d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 6.962856274788661E-5d + "'", double8 == 6.962856274788661E-5d);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        double double0 = org.apache.commons.math.util.FastMath.E;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.718281828459045d + "'", double0 == 2.718281828459045d);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        double double1 = org.apache.commons.math.util.FastMath.exp(1.7141516006622417d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.551963231767113d + "'", double1 == 5.551963231767113d);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        long long2 = org.apache.commons.math.util.FastMath.min(42L, (long) 3);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3L + "'", long2 == 3L);
    }

//    @Test
//    public void test444() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test444");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextExponential(0.5772156649015329d);
//        double double6 = randomDataImpl1.nextF((double) (byte) 1, 1.0d);
//        long long8 = randomDataImpl1.nextPoisson(10.000000000000002d);
//        randomDataImpl1.reSeedSecure();
//        long long12 = randomDataImpl1.nextLong((long) (byte) -1, (long) (byte) 100);
//        try {
//            randomDataImpl1.setSecureAlgorithm("aab68184b529e425968563fc3dfebdc0b868469b30ebe87d0d76", "org.apache.commons.math.MathException: hi!");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: org.apache.commons.math.MathException: hi!");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.9990248858953574d + "'", double3 == 2.9990248858953574d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 11.529677802937792d + "'", double6 == 11.529677802937792d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 16L + "'", long8 == 16L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 98L + "'", long12 == 98L);
//    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(40.43867114883232d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 108.24688577006226d + "'", double1 == 108.24688577006226d);
    }

//    @Test
//    public void test446() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test446");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextExponential(0.5772156649015329d);
//        double double6 = randomDataImpl1.nextF((double) (byte) 1, 1.0d);
//        java.lang.String str8 = randomDataImpl1.nextSecureHexString((int) (byte) 1);
//        long long11 = randomDataImpl1.nextSecureLong(0L, (long) 1);
//        randomDataImpl1.reSeed((long) 1);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.1114137530493142d + "'", double3 == 2.1114137530493142d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0039914680332875d + "'", double6 == 1.0039914680332875d);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "b" + "'", str8.equals("b"));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
//    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(1.3440585709080678E43d, 2.0d, 0.5187754889940697d);
        normalDistributionImpl3.reseedRandomGenerator(57L);
    }

//    @Test
//    public void test448() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test448");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT((double) 10L);
//        double double5 = randomDataImpl1.nextExponential((double) 6L);
//        double double8 = randomDataImpl1.nextWeibull(0.09480071340362801d, 0.3369944980913211d);
//        double double10 = randomDataImpl1.nextT(1.3210166206161171d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-2.365680820173755d) + "'", double3 == (-2.365680820173755d));
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.9041801869615227d + "'", double5 == 0.9041801869615227d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 9.442170872037618E-10d + "'", double8 == 9.442170872037618E-10d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-6.548526865840674d) + "'", double10 == (-6.548526865840674d));
//    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 0.7854924111435233d, (java.lang.Number) (-5571.853811290455d), false);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException4 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable5 = notStrictlyPositiveException4.getGeneralPattern();
        java.lang.Object[] objArray8 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException(localizable5, objArray8);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException11 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable12 = notStrictlyPositiveException11.getGeneralPattern();
        java.lang.Object[] objArray15 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException(localizable12, objArray15);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException19 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable20 = notStrictlyPositiveException19.getGeneralPattern();
        java.lang.Number number21 = notStrictlyPositiveException19.getArgument();
        java.lang.Object[] objArray22 = new java.lang.Object[] { 0, number21 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException23 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable12, objArray22);
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException(localizable2, objArray22);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException28 = new org.apache.commons.math.exception.OutOfRangeException(localizable2, (java.lang.Number) 35.966820416383136d, (java.lang.Number) 0.5442670269146703d, (java.lang.Number) 0.6511762777390735d);
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertTrue("'" + localizable20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable20.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + (-1L) + "'", number21.equals((-1L)));
        org.junit.Assert.assertNotNull(objArray22);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.3273817120025671d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5721727990760895d + "'", double1 == 0.5721727990760895d);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9155040003582885E22d + "'", double1 == 1.9155040003582885E22d);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.154434690031884d + "'", double1 == 2.154434690031884d);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP((-2260.3728442653687d), 65.82838642403674d, (-0.999999969540041d), (int) (byte) 0);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        double double1 = org.apache.commons.math.util.FastMath.cos(2.688117141816135E43d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9726256390084616d) + "'", double1 == (-0.9726256390084616d));
    }

//    @Test
//    public void test456() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test456");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextExponential(0.5772156649015329d);
//        double double6 = randomDataImpl1.nextF((double) (byte) 1, 1.0d);
//        int int9 = randomDataImpl1.nextSecureInt((int) '#', (int) 'a');
//        try {
//            double double11 = randomDataImpl1.nextT((-0.1764938974788445d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.176 is smaller than, or equal to, the minimum (0): degrees of freedom (-0.176)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.016956054177114332d + "'", double3 == 0.016956054177114332d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.021299945043480914d + "'", double6 == 0.021299945043480914d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 54 + "'", int9 == 54);
//    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (byte) 10, (long) 19);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 19L + "'", long2 == 19L);
    }

//    @Test
//    public void test458() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test458");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT((double) 10L);
//        randomDataImpl1.reSeed();
//        double double7 = randomDataImpl1.nextUniform((-104.14857733269706d), 2729.302091326176d);
//        randomDataImpl1.reSeedSecure();
//        try {
//            double double11 = randomDataImpl1.nextF((-1.9947036344657987d), 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1.995 is smaller than, or equal to, the minimum (0): degrees of freedom (-1.995)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.882702866898744d + "'", double3 == 0.882702866898744d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2165.2762547863485d + "'", double7 == 2165.2762547863485d);
//    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        double double2 = org.apache.commons.math.util.FastMath.pow(9.496119420602448E19d, (-2.7947645127697087d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.4704928552226072E-56d + "'", double2 == 1.4704928552226072E-56d);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(7.105427357601002E-15d, 2.185912937677754E123d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

//    @Test
//    public void test461() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test461");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextExponential(0.5772156649015329d);
//        double double6 = randomDataImpl1.nextCauchy(0.19323284172500138d, 11013.232920103343d);
//        long long9 = randomDataImpl1.nextLong((long) (-1), (long) 284);
//        try {
//            long long12 = randomDataImpl1.nextSecureLong(50L, (long) 5);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 50 is larger than, or equal to, the maximum (5): lower bound (50) must be strictly less than upper bound (5)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.13214050330914245d + "'", double3 == 0.13214050330914245d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-15890.094924518082d) + "'", double6 == (-15890.094924518082d));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 275L + "'", long9 == 275L);
//    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ((double) 'a', 1.4322219803232506E-9d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(284.0d, 284.0d, (double) '4');
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 1L, 0.0d, (-5692.998374363383d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): standard deviation (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        double double1 = org.apache.commons.math.util.FastMath.acos(996.4052362930596d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test467() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test467");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextSecureHexString((int) '4');
//        java.lang.String str5 = randomDataImpl1.nextHexString((int) (short) 100);
//        try {
//            int int8 = randomDataImpl1.nextPascal((int) (short) 0, 6.962856274788661E-5d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MathException; message: Discrete cumulative probability function returned NaN for argument 1,073,741,822");
//        } catch (org.apache.commons.math.MathException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "af29eeedc2f9c157791b17dc24856f40830be289c0a9a49b855d" + "'", str3.equals("af29eeedc2f9c157791b17dc24856f40830be289c0a9a49b855d"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "f3ad3f4f6bab2980e06b472ce2fb4b27196b1ad00669c10d6f7084ec6fe299d6df2c8df3b25a0aad7b49f5c41a86a3e909b8" + "'", str5.equals("f3ad3f4f6bab2980e06b472ce2fb4b27196b1ad00669c10d6f7084ec6fe299d6df2c8df3b25a0aad7b49f5c41a86a3e909b8"));
//    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(7.613135436994995E14d, (-0.6479483385593062d), 0.9686837504552075d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.648 is smaller than, or equal to, the minimum (0): standard deviation (-0.648)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        java.lang.Object[] objArray4 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray4);
        java.lang.Object[] objArray6 = maxIterationsExceededException5.getArguments();
        java.lang.String str7 = maxIterationsExceededException5.toString();
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException5);
        java.lang.String str9 = maxIterationsExceededException5.getPattern();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.MaxIterationsExceededException: " + "'", str7.equals("org.apache.commons.math.MaxIterationsExceededException: "));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException3 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable4 = notStrictlyPositiveException3.getGeneralPattern();
        java.lang.Object[] objArray7 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException(localizable4, objArray7);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException10 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable11 = notStrictlyPositiveException10.getGeneralPattern();
        java.lang.Object[] objArray14 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException(localizable11, objArray14);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException18 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable19 = notStrictlyPositiveException18.getGeneralPattern();
        java.lang.Number number20 = notStrictlyPositiveException18.getArgument();
        java.lang.Object[] objArray21 = new java.lang.Object[] { 0, number20 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException22 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, localizable11, objArray21);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException26 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable4, (java.lang.Number) 2.0d, (java.lang.Number) (-0.5063656411097588d), true);
        java.lang.Object[] objArray32 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException33 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray32);
        org.apache.commons.math.exception.util.Localizable localizable34 = maxIterationsExceededException33.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException38 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable34, (java.lang.Number) (short) -1, (java.lang.Number) 1.0d, false);
        java.lang.Object[] objArray44 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException45 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray44);
        java.lang.Object[] objArray46 = maxIterationsExceededException45.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException47 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException38, "", objArray46);
        boolean boolean48 = numberIsTooLargeException38.getBoundIsAllowed();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException51 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable52 = notStrictlyPositiveException51.getGeneralPattern();
        java.lang.Object[] objArray55 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException56 = new org.apache.commons.math.MathException(localizable52, objArray55);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException58 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable59 = notStrictlyPositiveException58.getGeneralPattern();
        java.lang.Object[] objArray62 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException63 = new org.apache.commons.math.MathException(localizable59, objArray62);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException66 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable67 = notStrictlyPositiveException66.getGeneralPattern();
        java.lang.Number number68 = notStrictlyPositiveException66.getArgument();
        java.lang.Object[] objArray69 = new java.lang.Object[] { 0, number68 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException70 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable52, localizable59, objArray69);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException72 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable73 = notStrictlyPositiveException72.getGeneralPattern();
        java.lang.Object[] objArray76 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException77 = new org.apache.commons.math.MathException(localizable73, objArray76);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException79 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable80 = notStrictlyPositiveException79.getGeneralPattern();
        java.lang.Object[] objArray83 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException84 = new org.apache.commons.math.MathException(localizable80, objArray83);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException87 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable88 = notStrictlyPositiveException87.getGeneralPattern();
        java.lang.Number number89 = notStrictlyPositiveException87.getArgument();
        java.lang.Object[] objArray90 = new java.lang.Object[] { 0, number89 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException91 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable73, localizable80, objArray90);
        org.apache.commons.math.ConvergenceException convergenceException92 = new org.apache.commons.math.ConvergenceException(localizable59, objArray90);
        org.apache.commons.math.MathException mathException93 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException38, "05299f0e072343e00952d77e9bba14e42f77765c61bcdb705583", objArray90);
        org.apache.commons.math.ConvergenceException convergenceException94 = new org.apache.commons.math.ConvergenceException("1", objArray90);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException95 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable4, objArray90);
        org.apache.commons.math.MathException mathException96 = new org.apache.commons.math.MathException("297b7abebbff2acfd73ac0b441f73ac1563f66b5695f83b12f6e", objArray90);
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertTrue("'" + localizable19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable19.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + (-1L) + "'", number20.equals((-1L)));
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(localizable34);
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertNotNull(objArray46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + localizable52 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable52.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray55);
        org.junit.Assert.assertTrue("'" + localizable59 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable59.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray62);
        org.junit.Assert.assertTrue("'" + localizable67 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable67.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number68 + "' != '" + (-1L) + "'", number68.equals((-1L)));
        org.junit.Assert.assertNotNull(objArray69);
        org.junit.Assert.assertTrue("'" + localizable73 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable73.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray76);
        org.junit.Assert.assertTrue("'" + localizable80 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable80.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray83);
        org.junit.Assert.assertTrue("'" + localizable88 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable88.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number89 + "' != '" + (-1L) + "'", number89.equals((-1L)));
        org.junit.Assert.assertNotNull(objArray90);
    }

//    @Test
//    public void test471() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test471");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextSecureHexString((int) '4');
//        long long6 = randomDataImpl1.nextSecureLong((long) (-1), (long) '4');
//        int int9 = randomDataImpl1.nextSecureInt(1, (int) (short) 100);
//        int int12 = randomDataImpl1.nextZipf((int) 'a', 3697.517657265949d);
//        double double15 = randomDataImpl1.nextWeibull(0.07382423751494867d, 127.86804180196543d);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "3f1954d023d7debc3939d8436833319afb4184c39f76a071e6f3" + "'", str3.equals("3f1954d023d7debc3939d8436833319afb4184c39f76a071e6f3"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 28L + "'", long6 == 28L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 4.7103192753878196E-4d + "'", double15 == 4.7103192753878196E-4d);
//    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException4 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable2, (java.lang.Number) 10);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException6 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable7 = notStrictlyPositiveException6.getGeneralPattern();
        java.lang.Object[] objArray10 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException(localizable7, objArray10);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException13 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable14 = notStrictlyPositiveException13.getGeneralPattern();
        java.lang.Object[] objArray17 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException(localizable14, objArray17);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException21 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable22 = notStrictlyPositiveException21.getGeneralPattern();
        java.lang.Number number23 = notStrictlyPositiveException21.getArgument();
        java.lang.Object[] objArray24 = new java.lang.Object[] { 0, number23 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException25 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, localizable14, objArray24);
        java.lang.Number number27 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException29 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable14, (java.lang.Number) 5.298342365610589d, number27, false);
        java.lang.Object[] objArray34 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException35 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray34);
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException4, localizable14, objArray34);
        java.lang.Throwable[] throwableArray37 = convergenceException36.getSuppressed();
        java.lang.Object[] objArray39 = null;
        org.apache.commons.math.ConvergenceException convergenceException40 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException36, "91b5182935a315311584e93090e41671e62a82e916a9cea12a5b", objArray39);
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertTrue("'" + localizable14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable14.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertTrue("'" + localizable22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable22.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + (-1L) + "'", number23.equals((-1L)));
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(throwableArray37);
    }

//    @Test
//    public void test473() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test473");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT((double) 10L);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl7 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.7241400178893855d, 5729.5779513082325d, (double) 1.0f);
//        double double10 = normalDistributionImpl7.cumulativeProbability(1.0000000000000002d, 32.577917486317425d);
//        double double11 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        randomDataImpl1.reSeedSecure((long) ' ');
//        int int16 = randomDataImpl1.nextBinomial((int) (byte) 100, 0.017861012128359798d);
//        randomDataImpl1.reSeedSecure();
//        double double19 = randomDataImpl1.nextT(7.310671115207338d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.46045670759395957d + "'", double3 == 0.46045670759395957d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.002198713597520441d + "'", double10 == 0.002198713597520441d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4985.302091326222d + "'", double11 == 4985.302091326222d);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.05337875323005945d + "'", double19 == 0.05337875323005945d);
//    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.3824362445485816d, 3.855673680380682E-6d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.009570573801096228d + "'", double2 == 0.009570573801096228d);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        double double2 = org.apache.commons.math.util.FastMath.min(1.0309090578119309d, 0.971303484757032d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.971303484757032d + "'", double2 == 0.971303484757032d);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (byte) 1, (float) (byte) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        long long1 = org.apache.commons.math.util.FastMath.round((double) (short) 0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 10L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP((-1.0000000005772156E9d), 4.8851119809000325E14d, 0.0d, (int) (short) 1);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        double double1 = org.apache.commons.math.util.FastMath.log1p((-0.25414070878837436d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.29321831424771366d) + "'", double1 == (-0.29321831424771366d));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.8686709614860095d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test482() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test482");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT((double) 10L);
//        double double5 = randomDataImpl1.nextExponential((double) 6L);
//        try {
//            long long7 = randomDataImpl1.nextPoisson(0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): mean (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0007407435059434d + "'", double3 == 2.0007407435059434d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 7.280627953128139d + "'", double5 == 7.280627953128139d);
//    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 2.993222846126381d);
        org.apache.commons.math.exception.util.Localizable localizable3 = notStrictlyPositiveException2.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + localizable3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable3.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        double double2 = org.apache.commons.math.util.FastMath.max(1.4322219803232506E-9d, 0.8686709614860095d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.8686709614860095d + "'", double2 == 0.8686709614860095d);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        java.lang.Object[] objArray4 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray4);
        org.apache.commons.math.exception.util.Localizable localizable6 = maxIterationsExceededException5.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable6, (java.lang.Number) (byte) 100);
        boolean boolean9 = notStrictlyPositiveException8.getBoundIsAllowed();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(localizable6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 19L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.6368929184641337d + "'", double1 == 3.6368929184641337d);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException4 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable5 = notStrictlyPositiveException4.getGeneralPattern();
        java.lang.Object[] objArray8 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException(localizable5, objArray8);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException11 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable12 = notStrictlyPositiveException11.getGeneralPattern();
        java.lang.Object[] objArray15 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException(localizable12, objArray15);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException19 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable20 = notStrictlyPositiveException19.getGeneralPattern();
        java.lang.Number number21 = notStrictlyPositiveException19.getArgument();
        java.lang.Object[] objArray22 = new java.lang.Object[] { 0, number21 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException23 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable12, objArray22);
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException(localizable2, objArray22);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException28 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable2, (java.lang.Number) 0.2184900773038401d, (java.lang.Number) 20, true);
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertTrue("'" + localizable20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable20.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + (-1L) + "'", number21.equals((-1L)));
        org.junit.Assert.assertNotNull(objArray22);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        int int2 = org.apache.commons.math.util.FastMath.max(5, 61);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 61 + "'", int2 == 61);
    }

//    @Test
//    public void test489() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test489");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT((double) 10L);
//        randomDataImpl1.reSeed();
//        double double6 = randomDataImpl1.nextChiSquare(0.5848500137377979d);
//        int int9 = randomDataImpl1.nextSecureInt((int) (byte) -1, 20);
//        try {
//            double double12 = randomDataImpl1.nextF((double) 1, 2.185912937677754E123d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 4 p = 0.082");
//        } catch (org.apache.commons.math.exception.MathUserException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.3552380931263905d + "'", double3 == 1.3552380931263905d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.696612610262527d + "'", double6 == 1.696612610262527d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.017861012128359798d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.552934364872805d + "'", double1 == 1.552934364872805d);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        java.lang.Object[] objArray4 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray4);
        org.apache.commons.math.exception.util.Localizable localizable6 = maxIterationsExceededException5.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable6, (java.lang.Number) (byte) 100);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException10 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable11 = notStrictlyPositiveException10.getGeneralPattern();
        java.lang.Object[] objArray16 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException17 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray16);
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException(localizable11, objArray16);
        java.lang.Object[] objArray24 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException25 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray24);
        org.apache.commons.math.exception.util.Localizable localizable26 = maxIterationsExceededException25.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException30 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable26, (java.lang.Number) (short) -1, (java.lang.Number) 1.0d, false);
        java.lang.Object[] objArray36 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException37 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray36);
        java.lang.Object[] objArray38 = maxIterationsExceededException37.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException30, "", objArray38);
        boolean boolean40 = numberIsTooLargeException30.getBoundIsAllowed();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException43 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable44 = notStrictlyPositiveException43.getGeneralPattern();
        java.lang.Object[] objArray47 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException48 = new org.apache.commons.math.MathException(localizable44, objArray47);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException50 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable51 = notStrictlyPositiveException50.getGeneralPattern();
        java.lang.Object[] objArray54 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException55 = new org.apache.commons.math.MathException(localizable51, objArray54);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException58 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable59 = notStrictlyPositiveException58.getGeneralPattern();
        java.lang.Number number60 = notStrictlyPositiveException58.getArgument();
        java.lang.Object[] objArray61 = new java.lang.Object[] { 0, number60 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException62 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable44, localizable51, objArray61);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException64 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable65 = notStrictlyPositiveException64.getGeneralPattern();
        java.lang.Object[] objArray68 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException69 = new org.apache.commons.math.MathException(localizable65, objArray68);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException71 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable72 = notStrictlyPositiveException71.getGeneralPattern();
        java.lang.Object[] objArray75 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException76 = new org.apache.commons.math.MathException(localizable72, objArray75);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException79 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable80 = notStrictlyPositiveException79.getGeneralPattern();
        java.lang.Number number81 = notStrictlyPositiveException79.getArgument();
        java.lang.Object[] objArray82 = new java.lang.Object[] { 0, number81 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException83 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable65, localizable72, objArray82);
        org.apache.commons.math.ConvergenceException convergenceException84 = new org.apache.commons.math.ConvergenceException(localizable51, objArray82);
        org.apache.commons.math.MathException mathException85 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException30, "05299f0e072343e00952d77e9bba14e42f77765c61bcdb705583", objArray82);
        org.apache.commons.math.ConvergenceException convergenceException86 = new org.apache.commons.math.ConvergenceException("1", objArray82);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException87 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, localizable11, objArray82);
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(localizable6);
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(localizable26);
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + localizable44 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable44.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray47);
        org.junit.Assert.assertTrue("'" + localizable51 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable51.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray54);
        org.junit.Assert.assertTrue("'" + localizable59 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable59.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number60 + "' != '" + (-1L) + "'", number60.equals((-1L)));
        org.junit.Assert.assertNotNull(objArray61);
        org.junit.Assert.assertTrue("'" + localizable65 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable65.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray68);
        org.junit.Assert.assertTrue("'" + localizable72 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable72.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray75);
        org.junit.Assert.assertTrue("'" + localizable80 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable80.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number81 + "' != '" + (-1L) + "'", number81.equals((-1L)));
        org.junit.Assert.assertNotNull(objArray82);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 11L, 0.7854924111435233d);
        double double4 = normalDistributionImpl2.cumulativeProbability((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1752011936438014d + "'", double1 == 1.1752011936438014d);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        double double2 = org.apache.commons.math.util.FastMath.min((-2164.213731654862d), 1560.8713124921853d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-2164.213731654862d) + "'", double2 == (-2164.213731654862d));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.7241400178893855d, 5729.5779513082325d, (double) 1.0f);
        double double5 = normalDistributionImpl3.density((-0.8813735870195429d));
        double double6 = normalDistributionImpl3.getStandardDeviation();
        double double7 = normalDistributionImpl3.getMean();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 6.962856045056186E-5d + "'", double5 == 6.962856045056186E-5d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 5729.5779513082325d + "'", double6 == 5729.5779513082325d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.7241400178893855d + "'", double7 == 0.7241400178893855d);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(3.2931430675399556d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.057476189267798225d + "'", double1 == 0.057476189267798225d);
    }

//    @Test
//    public void test498() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test498");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT((double) 10L);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl7 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.7241400178893855d, 5729.5779513082325d, (double) 1.0f);
//        double double10 = normalDistributionImpl7.cumulativeProbability(1.0000000000000002d, 32.577917486317425d);
//        double double11 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        double double13 = randomDataImpl1.nextT(0.49708625100776777d);
//        double double16 = randomDataImpl1.nextCauchy((double) 0.0f, (double) 7);
//        try {
//            int int19 = randomDataImpl1.nextInt(5, 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 5 is larger than, or equal to, the maximum (0): lower bound (5) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.5526661867768619d) + "'", double3 == (-1.5526661867768619d));
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.002198713597520441d + "'", double10 == 0.002198713597520441d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 273.3020913261271d + "'", double11 == 273.3020913261271d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 26.85171878576505d + "'", double13 == 26.85171878576505d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 4.947224058767649d + "'", double16 == 4.947224058767649d);
//    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        double double1 = org.apache.commons.math.util.FastMath.tanh((-10.11235543535243d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.999999996707319d) + "'", double1 == (-0.999999996707319d));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1.0d, (java.lang.Number) 1.0d, true);
        boolean boolean4 = numberIsTooSmallException3.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException3.getGeneralPattern();
        boolean boolean6 = numberIsTooSmallException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }
}

