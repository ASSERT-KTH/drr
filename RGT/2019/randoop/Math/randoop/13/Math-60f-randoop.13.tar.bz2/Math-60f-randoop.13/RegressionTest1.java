import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable3 = notStrictlyPositiveException1.getSpecificPattern();
        java.lang.String str4 = notStrictlyPositiveException1.toString();
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException1);
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNull(localizable3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: -1 is smaller than, or equal to, the minimum (0)" + "'", str4.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: -1 is smaller than, or equal to, the minimum (0)"));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(9.122989523030726E-70d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.698674677407565E-24d + "'", double1 == 9.698674677407565E-24d);
    }

//    @Test
//    public void test003() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test003");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT((double) 10L);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl7 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.7241400178893855d, 5729.5779513082325d, (double) 1.0f);
//        double double10 = normalDistributionImpl7.cumulativeProbability(1.0000000000000002d, 32.577917486317425d);
//        double double11 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        randomDataImpl1.reSeedSecure((long) ' ');
//        randomDataImpl1.reSeed((long) (byte) 1);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.5332919121760782d) + "'", double3 == (-1.5332919121760782d));
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.002198713597520441d + "'", double10 == 0.002198713597520441d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-7002.853811290343d) + "'", double11 == (-7002.853811290343d));
//    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (short) -1, (long) (short) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        double double1 = org.apache.commons.math.special.Gamma.digamma((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5772156677920679d) + "'", double1 == (-0.5772156677920679d));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(6.342124518290157d, 2.1974405382543956d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.342124518290156d + "'", double2 == 6.342124518290156d);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.04404681809261452d, (java.lang.Number) 3.141592653589793d, false);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 23, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        double double1 = org.apache.commons.math.util.FastMath.asin(9.698674677407565E-24d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.698674677407565E-24d + "'", double1 == 9.698674677407565E-24d);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        java.lang.Throwable throwable1 = null;
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException(throwable1, "", objArray3);
        java.lang.Object[] objArray9 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException10 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray9);
        org.apache.commons.math.exception.util.Localizable localizable11 = maxIterationsExceededException10.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException15 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable11, (java.lang.Number) (short) -1, (java.lang.Number) 1.0d, false);
        java.lang.Object[] objArray21 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException22 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray21);
        java.lang.Object[] objArray23 = maxIterationsExceededException22.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException15, "", objArray23);
        org.apache.commons.math.ConvergenceException convergenceException25 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException24);
        convergenceException4.addSuppressed((java.lang.Throwable) convergenceException24);
        org.apache.commons.math.exception.util.Localizable localizable27 = convergenceException4.getGeneralPattern();
        java.lang.Object[] objArray32 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException33 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray32);
        org.apache.commons.math.exception.util.Localizable localizable34 = maxIterationsExceededException33.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException38 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable34, (java.lang.Number) (short) -1, (java.lang.Number) 1.0d, false);
        java.lang.Object[] objArray44 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException45 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray44);
        java.lang.Object[] objArray46 = maxIterationsExceededException45.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException47 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException38, "", objArray46);
        boolean boolean48 = numberIsTooLargeException38.getBoundIsAllowed();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException51 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable52 = notStrictlyPositiveException51.getGeneralPattern();
        java.lang.Object[] objArray55 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException56 = new org.apache.commons.math.MathException(localizable52, objArray55);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException58 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable59 = notStrictlyPositiveException58.getGeneralPattern();
        java.lang.Object[] objArray62 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException63 = new org.apache.commons.math.MathException(localizable59, objArray62);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException66 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable67 = notStrictlyPositiveException66.getGeneralPattern();
        java.lang.Number number68 = notStrictlyPositiveException66.getArgument();
        java.lang.Object[] objArray69 = new java.lang.Object[] { 0, number68 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException70 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable52, localizable59, objArray69);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException72 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable73 = notStrictlyPositiveException72.getGeneralPattern();
        java.lang.Object[] objArray76 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException77 = new org.apache.commons.math.MathException(localizable73, objArray76);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException79 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable80 = notStrictlyPositiveException79.getGeneralPattern();
        java.lang.Object[] objArray83 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException84 = new org.apache.commons.math.MathException(localizable80, objArray83);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException87 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable88 = notStrictlyPositiveException87.getGeneralPattern();
        java.lang.Number number89 = notStrictlyPositiveException87.getArgument();
        java.lang.Object[] objArray90 = new java.lang.Object[] { 0, number89 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException91 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable73, localizable80, objArray90);
        org.apache.commons.math.ConvergenceException convergenceException92 = new org.apache.commons.math.ConvergenceException(localizable59, objArray90);
        org.apache.commons.math.MathException mathException93 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException38, "05299f0e072343e00952d77e9bba14e42f77765c61bcdb705583", objArray90);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException94 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable27, objArray90);
        java.lang.String str95 = maxIterationsExceededException94.getPattern();
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(localizable11);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNotNull(localizable27);
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(localizable34);
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertNotNull(objArray46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + localizable52 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable52.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray55);
        org.junit.Assert.assertTrue("'" + localizable59 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable59.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray62);
        org.junit.Assert.assertTrue("'" + localizable67 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable67.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number68 + "' != '" + (-1L) + "'", number68.equals((-1L)));
        org.junit.Assert.assertNotNull(objArray69);
        org.junit.Assert.assertTrue("'" + localizable73 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable73.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray76);
        org.junit.Assert.assertTrue("'" + localizable80 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable80.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray83);
        org.junit.Assert.assertTrue("'" + localizable88 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable88.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number89 + "' != '" + (-1L) + "'", number89.equals((-1L)));
        org.junit.Assert.assertNotNull(objArray90);
        org.junit.Assert.assertTrue("'" + str95 + "' != '" + "" + "'", str95.equals(""));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1.0d, (java.lang.Number) 1.0d, true);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooSmallException3.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException8 = new org.apache.commons.math.exception.OutOfRangeException(localizable4, (java.lang.Number) (-3010.222163511784d), (java.lang.Number) 0.08272307916163937d, (java.lang.Number) (-0.7619000024949298d));
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException12 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) 1, (java.lang.Number) 100.0f, true);
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 61L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 61.0d + "'", double1 == 61.0d);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException4 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable2, (java.lang.Number) 10);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException6 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable7 = notStrictlyPositiveException6.getGeneralPattern();
        java.lang.Object[] objArray10 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException(localizable7, objArray10);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException13 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable14 = notStrictlyPositiveException13.getGeneralPattern();
        java.lang.Object[] objArray17 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException(localizable14, objArray17);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException21 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable22 = notStrictlyPositiveException21.getGeneralPattern();
        java.lang.Number number23 = notStrictlyPositiveException21.getArgument();
        java.lang.Object[] objArray24 = new java.lang.Object[] { 0, number23 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException25 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, localizable14, objArray24);
        java.lang.Number number27 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException29 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable14, (java.lang.Number) 5.298342365610589d, number27, false);
        java.lang.Object[] objArray34 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException35 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray34);
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException4, localizable14, objArray34);
        java.lang.Number number37 = notStrictlyPositiveException4.getArgument();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException39 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable40 = notStrictlyPositiveException39.getGeneralPattern();
        java.lang.Object[] objArray45 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException46 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray45);
        org.apache.commons.math.MathException mathException47 = new org.apache.commons.math.MathException(localizable40, objArray45);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException49 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable50 = notStrictlyPositiveException49.getGeneralPattern();
        java.lang.Object[] objArray53 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException54 = new org.apache.commons.math.MathException(localizable50, objArray53);
        org.apache.commons.math.MathException mathException55 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException4, localizable40, objArray53);
        org.apache.commons.math.MathException mathException56 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException55);
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertTrue("'" + localizable14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable14.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertTrue("'" + localizable22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable22.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + (-1L) + "'", number23.equals((-1L)));
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertTrue("'" + number37 + "' != '" + 10 + "'", number37.equals(10));
        org.junit.Assert.assertTrue("'" + localizable40 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable40.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray45);
        org.junit.Assert.assertTrue("'" + localizable50 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable50.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray53);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.21535625129876d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.21535625129875996d + "'", double2 == 0.21535625129875996d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException4 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable2, (java.lang.Number) 10);
        java.lang.Object[] objArray10 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException11 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray10);
        java.lang.Object[] objArray12 = maxIterationsExceededException11.getArguments();
        java.lang.Object[] objArray13 = maxIterationsExceededException11.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException4, "0a9413bf82824a5a7eef9e7859fd80f805dc34e275b134cf0f335342f3b7330b3e2c0817167d7998592ba04445b5e5bc0b99", objArray13);
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(objArray13);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.9880245729672786d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.5560199723869865d + "'", double1 == 2.5560199723869865d);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP((-0.6479483385593062d), 1.340858830181238E-15d, 1.0309090578119309d, (int) (byte) -1);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((-1.5332919121760782d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-87.85115532923295d) + "'", double1 == (-87.85115532923295d));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(6.342124518290156d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.38159594654045d + "'", double1 == 5.38159594654045d);
    }

//    @Test
//    public void test020() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test020");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.7241400178893855d, 5729.5779513082325d, (double) 1.0f);
//        double double4 = normalDistributionImpl3.sample();
//        normalDistributionImpl3.reseedRandomGenerator((long) '4');
//        normalDistributionImpl3.reseedRandomGenerator(183L);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-7324.106818925002d) + "'", double4 == (-7324.106818925002d));
//    }

//    @Test
//    public void test021() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test021");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextSecureHexString((int) '4');
//        java.lang.String str5 = randomDataImpl1.nextHexString((int) (short) 100);
//        int int8 = randomDataImpl1.nextSecureInt((int) (byte) 1, (int) '#');
//        int int11 = randomDataImpl1.nextPascal(100, 0.250069889408776d);
//        try {
//            int int15 = randomDataImpl1.nextHypergeometric(0, 3, 32);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): population size (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "7beb144b03846ca7b5a8651aaa03850f87ac7d434146ca813207" + "'", str3.equals("7beb144b03846ca7b5a8651aaa03850f87ac7d434146ca813207"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "59668db92626cc1b085c06a0cba7f587012bd4023b2231d1724ba7b14595409c987db6f15fcd3fc4e0cc72d03001d34b82ae" + "'", str5.equals("59668db92626cc1b085c06a0cba7f587012bd4023b2231d1724ba7b14595409c987db6f15fcd3fc4e0cc72d03001d34b82ae"));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 263 + "'", int11 == 263);
//    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

//    @Test
//    public void test023() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test023");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT((double) 10L);
//        double double6 = randomDataImpl1.nextBeta(0.20378364545839303d, (double) 6L);
//        long long8 = randomDataImpl1.nextPoisson(0.07714563080407891d);
//        double double11 = randomDataImpl1.nextWeibull(1.2285876451802997d, 1.3135192566529642E-15d);
//        java.lang.String str13 = randomDataImpl1.nextSecureHexString(3);
//        try {
//            long long15 = randomDataImpl1.nextPoisson((-0.5988144256764266d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.599 is smaller than, or equal to, the minimum (0): mean (-0.599)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-0.7947716368792107d) + "'", double3 == (-0.7947716368792107d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.013341561040496542d + "'", double6 == 0.013341561040496542d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0663409950277755E-15d + "'", double11 == 1.0663409950277755E-15d);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "490" + "'", str13.equals("490"));
//    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getGeneralPattern();
        java.lang.Object[] objArray7 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException8 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray7);
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException(localizable2, objArray7);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException13 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1.0d, (java.lang.Number) 1.0d, true);
        org.apache.commons.math.exception.util.Localizable localizable14 = numberIsTooSmallException13.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException16 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable17 = notStrictlyPositiveException16.getGeneralPattern();
        java.lang.Object[] objArray20 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException(localizable17, objArray20);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException23 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable24 = notStrictlyPositiveException23.getGeneralPattern();
        java.lang.Object[] objArray27 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException28 = new org.apache.commons.math.MathException(localizable24, objArray27);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException31 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable32 = notStrictlyPositiveException31.getGeneralPattern();
        java.lang.Number number33 = notStrictlyPositiveException31.getArgument();
        java.lang.Object[] objArray34 = new java.lang.Object[] { 0, number33 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException35 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable17, localizable24, objArray34);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException37 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable38 = notStrictlyPositiveException37.getGeneralPattern();
        java.lang.Object[] objArray41 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException42 = new org.apache.commons.math.MathException(localizable38, objArray41);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException44 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable45 = notStrictlyPositiveException44.getGeneralPattern();
        java.lang.Object[] objArray48 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException49 = new org.apache.commons.math.MathException(localizable45, objArray48);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException52 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable53 = notStrictlyPositiveException52.getGeneralPattern();
        java.lang.Number number54 = notStrictlyPositiveException52.getArgument();
        java.lang.Object[] objArray55 = new java.lang.Object[] { 0, number54 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException56 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable38, localizable45, objArray55);
        org.apache.commons.math.ConvergenceException convergenceException57 = new org.apache.commons.math.ConvergenceException(localizable24, objArray55);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException58 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, localizable14, objArray55);
        org.apache.commons.math.exception.util.Localizable localizable59 = mathIllegalArgumentException58.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertTrue("'" + localizable14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable14.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertTrue("'" + localizable24 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable24.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertTrue("'" + localizable32 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable32.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number33 + "' != '" + (-1L) + "'", number33.equals((-1L)));
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertTrue("'" + localizable38 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable38.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray41);
        org.junit.Assert.assertTrue("'" + localizable45 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable45.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray48);
        org.junit.Assert.assertTrue("'" + localizable53 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable53.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number54 + "' != '" + (-1L) + "'", number54.equals((-1L)));
        org.junit.Assert.assertNotNull(objArray55);
        org.junit.Assert.assertTrue("'" + localizable59 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable59.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
    }

//    @Test
//    public void test025() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test025");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextSecureHexString((int) '4');
//        long long6 = randomDataImpl1.nextSecureLong((long) (-1), (long) '4');
//        int int9 = randomDataImpl1.nextSecureInt(1, (int) (short) 100);
//        int int12 = randomDataImpl1.nextPascal((int) '4', 0.9999994948902197d);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "48eaf93eee1a28557e4184458fd132473c5170a31c7d63c85bcf" + "'", str3.equals("48eaf93eee1a28557e4184458fd132473c5170a31c7d63c85bcf"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 45L + "'", long6 == 45L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 92 + "'", int9 == 92);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        double double2 = org.apache.commons.math.util.FastMath.min(0.16635096647323788d, 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.16635096647323788d + "'", double2 == 0.16635096647323788d);
    }

//    @Test
//    public void test027() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test027");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT((double) 10L);
//        java.lang.String str5 = randomDataImpl1.nextSecureHexString(20);
//        double double8 = randomDataImpl1.nextBeta((double) 28L, 0.49708625100776777d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.6107992316908502d) + "'", double3 == (-1.6107992316908502d));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "3982aabd80e6ba1392f9" + "'", str5.equals("3982aabd80e6ba1392f9"));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.9971705093168025d + "'", double8 == 0.9971705093168025d);
//    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ((-0.9999999999999999d), 0.0d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 11L, 0.7854924111435233d);
        double double5 = normalDistributionImpl2.cumulativeProbability((-0.6479483385593062d), (-0.29321831424771366d));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.MathException mathException1 = new org.apache.commons.math.MathException(throwable0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.989549739220151d);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeed();
        org.apache.commons.math.distribution.ContinuousDistribution continuousDistribution2 = null;
        try {
            double double3 = randomDataImpl0.nextInversionDeviate(continuousDistribution2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test033() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test033");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT((double) 10L);
//        double double6 = randomDataImpl1.nextBeta(0.20378364545839303d, (double) 6L);
//        long long8 = randomDataImpl1.nextPoisson(0.07714563080407891d);
//        double double11 = randomDataImpl1.nextGaussian(1.1712659507785417d, (double) 100L);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.464498764448041d) + "'", double3 == (-1.464498764448041d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 3.468925545158771E-6d + "'", double6 == 3.468925545158771E-6d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-22.031446833501377d) + "'", double11 == (-22.031446833501377d));
//    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        double double1 = org.apache.commons.math.util.FastMath.expm1(40.864993425801046d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.5903776604969133E17d + "'", double1 == 5.5903776604969133E17d);
    }

//    @Test
//    public void test035() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test035");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT((double) 10L);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl7 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.7241400178893855d, 5729.5779513082325d, (double) 1.0f);
//        double double10 = normalDistributionImpl7.cumulativeProbability(1.0000000000000002d, 32.577917486317425d);
//        double double11 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        double double13 = randomDataImpl1.nextT(0.49708625100776777d);
//        long long15 = randomDataImpl1.nextPoisson(0.7854924111435233d);
//        try {
//            randomDataImpl1.setSecureAlgorithm("org.apache.commons.math.exception.MathIllegalArgumentException: 0 is smaller than, or equal to, the minimum (-1): 0 is smaller than, or equal to, the minimum (-1)", "98fb2814226fd7ea893b3674ff008a58b86644b3fa279321290b");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: 98fb2814226fd7ea893b3674ff008a58b86644b3fa279321290b");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.5001916261610955d) + "'", double3 == (-1.5001916261610955d));
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.002198713597520441d + "'", double10 == 0.002198713597520441d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 8714.302091325946d + "'", double11 == 8714.302091325946d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-9.241842702207478d) + "'", double13 == (-9.241842702207478d));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1L + "'", long15 == 1L);
//    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) Double.NaN, (java.lang.Number) 10.000000000000002d, true);
        boolean boolean4 = numberIsTooLargeException3.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooLargeException3.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(localizable5);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.002198713597520441d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.8374791585101126E-5d + "'", double1 == 3.8374791585101126E-5d);
    }

//    @Test
//    public void test038() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test038");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextExponential(0.5772156649015329d);
//        double double6 = randomDataImpl1.nextCauchy(0.19323284172500138d, 11013.232920103343d);
//        long long9 = randomDataImpl1.nextLong((long) (-1), (long) 284);
//        long long12 = randomDataImpl1.nextLong((long) 19, (long) ' ');
//        double double15 = randomDataImpl1.nextCauchy(0.0d, (double) 10L);
//        try {
//            double double17 = randomDataImpl1.nextChiSquare((-0.6100323741395379d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.305 is smaller than, or equal to, the minimum (0): alpha");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.4651191679900715d + "'", double3 == 1.4651191679900715d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-88397.95426961643d) + "'", double6 == (-88397.95426961643d));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 181L + "'", long9 == 181L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 20L + "'", long12 == 20L);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 5.56704947051021d + "'", double15 == 5.56704947051021d);
//    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (byte) 1, 92);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        double double2 = org.apache.commons.math.util.FastMath.max(0.0d, 7.310671115207338d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.310671115207338d + "'", double2 == 7.310671115207338d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        float float2 = org.apache.commons.math.util.FastMath.max(0.0f, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        int int1 = org.apache.commons.math.util.FastMath.round(0.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

//    @Test
//    public void test043() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test043");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextSecureHexString((int) '4');
//        long long6 = randomDataImpl1.nextSecureLong((long) (-1), (long) '4');
//        int int9 = randomDataImpl1.nextSecureInt(1, (int) (short) 100);
//        int int12 = randomDataImpl1.nextZipf((int) 'a', 3697.517657265949d);
//        randomDataImpl1.reSeedSecure();
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "27bb5ef6073ed248dce2c15acb96776f20781216b66612c445c0" + "'", str3.equals("27bb5ef6073ed248dce2c15acb96776f20781216b66612c445c0"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 14L + "'", long6 == 14L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 12 + "'", int9 == 12);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        int int1 = org.apache.commons.math.util.FastMath.round(1.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        double double1 = org.apache.commons.math.util.FastMath.tanh(7.613135436994995E14d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 61);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5544043524868913d + "'", double1 == 1.5544043524868913d);
    }

//    @Test
//    public void test047() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test047");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT((double) 10L);
//        double double6 = randomDataImpl1.nextBeta(0.20378364545839303d, (double) 6L);
//        long long8 = randomDataImpl1.nextPoisson(0.07714563080407891d);
//        double double11 = randomDataImpl1.nextWeibull(1.2285876451802997d, 1.3135192566529642E-15d);
//        java.lang.String str13 = randomDataImpl1.nextSecureHexString(3);
//        java.lang.String str15 = randomDataImpl1.nextSecureHexString(5);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-0.335188706425137d) + "'", double3 == (-0.335188706425137d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 3.628083796374703E-6d + "'", double6 == 3.628083796374703E-6d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.6106002385198853E-15d + "'", double11 == 1.6106002385198853E-15d);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "fcb" + "'", str13.equals("fcb"));
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "303d6" + "'", str15.equals("303d6"));
//    }

//    @Test
//    public void test048() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test048");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextSecureHexString((int) '4');
//        java.lang.String str5 = randomDataImpl1.nextHexString((int) (short) 100);
//        int int8 = randomDataImpl1.nextSecureInt((int) (byte) 1, (int) '#');
//        try {
//            double double11 = randomDataImpl1.nextCauchy(5308.302091326228d, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): scale (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "87668a67e9db842f9c1330c93dea48d07581db92886be2ed3a9d" + "'", str3.equals("87668a67e9db842f9c1330c93dea48d07581db92886be2ed3a9d"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "b75320df44ed94cd392855137f0c74b4712d3bff5d8ba3428674b27df38db2fe07823fe89369268fb7f250911ad135d022f3" + "'", str5.equals("b75320df44ed94cd392855137f0c74b4712d3bff5d8ba3428674b27df38db2fe07823fe89369268fb7f250911ad135d022f3"));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
//    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) Double.NaN, (java.lang.Number) 10.000000000000002d, true);
        boolean boolean4 = numberIsTooLargeException3.getBoundIsAllowed();
        java.lang.Number number5 = numberIsTooLargeException3.getMax();
        java.lang.Number number6 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 10.000000000000002d + "'", number5.equals(10.000000000000002d));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 10.000000000000002d + "'", number6.equals(10.000000000000002d));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        double double1 = org.apache.commons.math.util.FastMath.floor((-0.5653738965860751d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException4 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable2, (java.lang.Number) 10);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException6 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable7 = notStrictlyPositiveException6.getGeneralPattern();
        java.lang.Object[] objArray10 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException(localizable7, objArray10);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException13 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable14 = notStrictlyPositiveException13.getGeneralPattern();
        java.lang.Object[] objArray17 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException(localizable14, objArray17);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException21 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable22 = notStrictlyPositiveException21.getGeneralPattern();
        java.lang.Number number23 = notStrictlyPositiveException21.getArgument();
        java.lang.Object[] objArray24 = new java.lang.Object[] { 0, number23 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException25 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, localizable14, objArray24);
        java.lang.Number number27 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException29 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable14, (java.lang.Number) 5.298342365610589d, number27, false);
        java.lang.Object[] objArray34 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException35 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray34);
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException4, localizable14, objArray34);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException40 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable14, (java.lang.Number) (-32165.974075073518d), (java.lang.Number) 35.966820416383136d, false);
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertTrue("'" + localizable14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable14.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertTrue("'" + localizable22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable22.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + (-1L) + "'", number23.equals((-1L)));
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(objArray34);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (byte) 1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getGeneralPattern();
        java.lang.Object[] objArray5 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException(localizable2, objArray5);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable9 = notStrictlyPositiveException8.getGeneralPattern();
        java.lang.Object[] objArray12 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException(localizable9, objArray12);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException16 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable17 = notStrictlyPositiveException16.getGeneralPattern();
        java.lang.Number number18 = notStrictlyPositiveException16.getArgument();
        java.lang.Object[] objArray19 = new java.lang.Object[] { 0, number18 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException20 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, localizable9, objArray19);
        java.lang.Object[] objArray25 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException26 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray25);
        org.apache.commons.math.exception.util.Localizable localizable27 = maxIterationsExceededException26.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException31 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable27, (java.lang.Number) (short) -1, (java.lang.Number) 1.0d, false);
        java.lang.Object[] objArray37 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException38 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray37);
        java.lang.Object[] objArray39 = maxIterationsExceededException38.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException40 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException31, "", objArray39);
        boolean boolean41 = numberIsTooLargeException31.getBoundIsAllowed();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException44 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable45 = notStrictlyPositiveException44.getGeneralPattern();
        java.lang.Object[] objArray48 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException49 = new org.apache.commons.math.MathException(localizable45, objArray48);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException51 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable52 = notStrictlyPositiveException51.getGeneralPattern();
        java.lang.Object[] objArray55 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException56 = new org.apache.commons.math.MathException(localizable52, objArray55);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException59 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable60 = notStrictlyPositiveException59.getGeneralPattern();
        java.lang.Number number61 = notStrictlyPositiveException59.getArgument();
        java.lang.Object[] objArray62 = new java.lang.Object[] { 0, number61 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException63 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable45, localizable52, objArray62);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException65 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable66 = notStrictlyPositiveException65.getGeneralPattern();
        java.lang.Object[] objArray69 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException70 = new org.apache.commons.math.MathException(localizable66, objArray69);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException72 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable73 = notStrictlyPositiveException72.getGeneralPattern();
        java.lang.Object[] objArray76 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException77 = new org.apache.commons.math.MathException(localizable73, objArray76);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException80 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable81 = notStrictlyPositiveException80.getGeneralPattern();
        java.lang.Number number82 = notStrictlyPositiveException80.getArgument();
        java.lang.Object[] objArray83 = new java.lang.Object[] { 0, number82 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException84 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable66, localizable73, objArray83);
        org.apache.commons.math.ConvergenceException convergenceException85 = new org.apache.commons.math.ConvergenceException(localizable52, objArray83);
        org.apache.commons.math.MathException mathException86 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException31, "05299f0e072343e00952d77e9bba14e42f77765c61bcdb705583", objArray83);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException87 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable9, objArray83);
        org.apache.commons.math.exception.util.Localizable localizable88 = mathIllegalArgumentException87.getGeneralPattern();
        java.lang.Number number90 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException92 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable88, (java.lang.Number) 5.5903776604969133E17d, number90, true);
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + (-1L) + "'", number18.equals((-1L)));
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(localizable27);
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + localizable45 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable45.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray48);
        org.junit.Assert.assertTrue("'" + localizable52 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable52.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray55);
        org.junit.Assert.assertTrue("'" + localizable60 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable60.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number61 + "' != '" + (-1L) + "'", number61.equals((-1L)));
        org.junit.Assert.assertNotNull(objArray62);
        org.junit.Assert.assertTrue("'" + localizable66 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable66.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray69);
        org.junit.Assert.assertTrue("'" + localizable73 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable73.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray76);
        org.junit.Assert.assertTrue("'" + localizable81 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable81.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number82 + "' != '" + (-1L) + "'", number82.equals((-1L)));
        org.junit.Assert.assertNotNull(objArray83);
        org.junit.Assert.assertTrue("'" + localizable88 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable88.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        double double1 = org.apache.commons.math.util.FastMath.log10(6.962856045056186E-5d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-4.157212583638726d) + "'", double1 == (-4.157212583638726d));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.1452060591311662d);
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

//    @Test
//    public void test056() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test056");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextExponential(0.5772156649015329d);
//        double double6 = randomDataImpl1.nextF((double) (byte) 1, 1.0d);
//        long long8 = randomDataImpl1.nextPoisson(10.000000000000002d);
//        randomDataImpl1.reSeedSecure();
//        int int13 = randomDataImpl1.nextHypergeometric(92, (int) (byte) 10, 13);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.3696394932578302d + "'", double3 == 0.3696394932578302d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 866.6902505351673d + "'", double6 == 866.6902505351673d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9L + "'", long8 == 9L);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getGeneralPattern();
        java.lang.Object[] objArray5 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException(localizable2, objArray5);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable9 = notStrictlyPositiveException8.getGeneralPattern();
        java.lang.Object[] objArray12 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException(localizable9, objArray12);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException16 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable17 = notStrictlyPositiveException16.getGeneralPattern();
        java.lang.Number number18 = notStrictlyPositiveException16.getArgument();
        java.lang.Object[] objArray19 = new java.lang.Object[] { 0, number18 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException20 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, localizable9, objArray19);
        java.lang.Number number22 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException24 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable9, (java.lang.Number) 5.298342365610589d, number22, false);
        java.lang.Object[] objArray30 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException31 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray30);
        org.apache.commons.math.MathException mathException32 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException24, "org.apache.commons.math.exception.NotStrictlyPositiveException: -1 is smaller than, or equal to, the minimum (0)", objArray30);
        java.lang.Number number33 = numberIsTooSmallException24.getMin();
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + (-1L) + "'", number18.equals((-1L)));
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertNull(number33);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(10.000000000000002d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.10516633568161556d + "'", double1 == 0.10516633568161556d);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.ConvergenceException convergenceException1 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException0);
        java.lang.String str2 = convergenceException1.getPattern();
        java.lang.Object[] objArray3 = convergenceException1.getArguments();
        java.lang.Object[] objArray4 = convergenceException1.getArguments();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{0}" + "'", str2.equals("{0}"));
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertNotNull(objArray4);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(10);
        java.lang.Object[] objArray2 = maxIterationsExceededException1.getArguments();
        java.lang.Object[] objArray9 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException10 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray9);
        org.apache.commons.math.exception.util.Localizable localizable11 = maxIterationsExceededException10.getGeneralPattern();
        java.lang.Object[] objArray16 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException17 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray16);
        org.apache.commons.math.exception.util.Localizable localizable18 = maxIterationsExceededException17.getGeneralPattern();
        java.lang.Throwable[] throwableArray19 = maxIterationsExceededException17.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException20 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, (java.lang.Object[]) throwableArray19);
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException("1", (java.lang.Object[]) throwableArray19);
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException1, "7b011d94a719a0ab9d143e049f1b3e4f9cc151b4aa12fcbcf88e", (java.lang.Object[]) throwableArray19);
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(localizable11);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(localizable18);
        org.junit.Assert.assertNotNull(throwableArray19);
    }

//    @Test
//    public void test061() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test061");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextExponential(0.5772156649015329d);
//        double double6 = randomDataImpl1.nextF((double) (byte) 1, 1.0d);
//        long long8 = randomDataImpl1.nextPoisson(10.000000000000002d);
//        randomDataImpl1.reSeedSecure();
//        java.lang.String str11 = randomDataImpl1.nextSecureHexString(10);
//        try {
//            int int14 = randomDataImpl1.nextPascal((int) (byte) -1, (-1.9947036344657987d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: -1 is smaller than the minimum (0): number of successes (-1)");
//        } catch (org.apache.commons.math.exception.NotPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.34317962492908566d + "'", double3 == 0.34317962492908566d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.08855133323900945d + "'", double6 == 0.08855133323900945d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 5L + "'", long8 == 5L);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "876010fec6" + "'", str11.equals("876010fec6"));
//    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getGeneralPattern();
        java.lang.Object[] objArray5 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException(localizable2, objArray5);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable9 = notStrictlyPositiveException8.getGeneralPattern();
        java.lang.Object[] objArray12 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException(localizable9, objArray12);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException16 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable17 = notStrictlyPositiveException16.getGeneralPattern();
        java.lang.Number number18 = notStrictlyPositiveException16.getArgument();
        java.lang.Object[] objArray19 = new java.lang.Object[] { 0, number18 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException20 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, localizable9, objArray19);
        java.lang.Object[] objArray25 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException26 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray25);
        org.apache.commons.math.exception.util.Localizable localizable27 = maxIterationsExceededException26.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException31 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable27, (java.lang.Number) (short) -1, (java.lang.Number) 1.0d, false);
        java.lang.Object[] objArray37 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException38 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray37);
        java.lang.Object[] objArray39 = maxIterationsExceededException38.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException40 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException31, "", objArray39);
        boolean boolean41 = numberIsTooLargeException31.getBoundIsAllowed();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException44 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable45 = notStrictlyPositiveException44.getGeneralPattern();
        java.lang.Object[] objArray48 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException49 = new org.apache.commons.math.MathException(localizable45, objArray48);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException51 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable52 = notStrictlyPositiveException51.getGeneralPattern();
        java.lang.Object[] objArray55 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException56 = new org.apache.commons.math.MathException(localizable52, objArray55);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException59 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable60 = notStrictlyPositiveException59.getGeneralPattern();
        java.lang.Number number61 = notStrictlyPositiveException59.getArgument();
        java.lang.Object[] objArray62 = new java.lang.Object[] { 0, number61 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException63 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable45, localizable52, objArray62);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException65 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable66 = notStrictlyPositiveException65.getGeneralPattern();
        java.lang.Object[] objArray69 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException70 = new org.apache.commons.math.MathException(localizable66, objArray69);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException72 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable73 = notStrictlyPositiveException72.getGeneralPattern();
        java.lang.Object[] objArray76 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException77 = new org.apache.commons.math.MathException(localizable73, objArray76);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException80 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable81 = notStrictlyPositiveException80.getGeneralPattern();
        java.lang.Number number82 = notStrictlyPositiveException80.getArgument();
        java.lang.Object[] objArray83 = new java.lang.Object[] { 0, number82 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException84 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable66, localizable73, objArray83);
        org.apache.commons.math.ConvergenceException convergenceException85 = new org.apache.commons.math.ConvergenceException(localizable52, objArray83);
        org.apache.commons.math.MathException mathException86 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException31, "05299f0e072343e00952d77e9bba14e42f77765c61bcdb705583", objArray83);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException87 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable9, objArray83);
        java.lang.Number number90 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException91 = new org.apache.commons.math.exception.OutOfRangeException(localizable9, (java.lang.Number) (-0.13147441609958888d), (java.lang.Number) 0.18355825835313155d, number90);
        java.lang.Throwable[] throwableArray92 = outOfRangeException91.getSuppressed();
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + (-1L) + "'", number18.equals((-1L)));
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(localizable27);
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + localizable45 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable45.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray48);
        org.junit.Assert.assertTrue("'" + localizable52 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable52.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray55);
        org.junit.Assert.assertTrue("'" + localizable60 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable60.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number61 + "' != '" + (-1L) + "'", number61.equals((-1L)));
        org.junit.Assert.assertNotNull(objArray62);
        org.junit.Assert.assertTrue("'" + localizable66 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable66.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray69);
        org.junit.Assert.assertTrue("'" + localizable73 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable73.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray76);
        org.junit.Assert.assertTrue("'" + localizable81 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable81.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number82 + "' != '" + (-1L) + "'", number82.equals((-1L)));
        org.junit.Assert.assertNotNull(objArray83);
        org.junit.Assert.assertNotNull(throwableArray92);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) Double.NaN, (java.lang.Number) 10.000000000000002d, true);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooLargeException3.getGeneralPattern();
        boolean boolean5 = numberIsTooLargeException3.getBoundIsAllowed();
        java.lang.String str6 = numberIsTooLargeException3.toString();
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NumberIsTooLargeException: � is larger than the maximum (10)" + "'", str6.equals("org.apache.commons.math.exception.NumberIsTooLargeException: � is larger than the maximum (10)"));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getGeneralPattern();
        java.lang.Number number3 = notStrictlyPositiveException1.getMin();
        org.apache.commons.math.exception.util.Localizable localizable4 = notStrictlyPositiveException1.getSpecificPattern();
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException1);
        java.lang.Object[] objArray11 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException12 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray11);
        org.apache.commons.math.exception.util.Localizable localizable13 = maxIterationsExceededException12.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException17 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable13, (java.lang.Number) (short) -1, (java.lang.Number) 1.0d, false);
        java.lang.Object[] objArray23 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException24 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray23);
        java.lang.Object[] objArray25 = maxIterationsExceededException24.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException26 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException17, "", objArray25);
        boolean boolean27 = numberIsTooLargeException17.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable28 = numberIsTooLargeException17.getSpecificPattern();
        java.lang.Object[] objArray29 = numberIsTooLargeException17.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException5, "15772cea5a", objArray29);
        java.lang.Object[] objArray36 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException37 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray36);
        org.apache.commons.math.exception.util.Localizable localizable38 = maxIterationsExceededException37.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException42 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable38, (java.lang.Number) (short) -1, (java.lang.Number) 1.0d, false);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException44 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable45 = notStrictlyPositiveException44.getGeneralPattern();
        java.lang.Object[] objArray48 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException49 = new org.apache.commons.math.MathException(localizable45, objArray48);
        java.lang.Object[] objArray54 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException55 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray54);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException56 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable38, localizable45, objArray54);
        org.apache.commons.math.MathException mathException57 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException5, "org.apache.commons.math.exception.MathIllegalArgumentException: 0 is smaller than, or equal to, the minimum (-1): 0 is smaller than, or equal to, the minimum (-1)", objArray54);
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
        org.junit.Assert.assertNull(localizable4);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(localizable13);
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(localizable28);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertNotNull(localizable38);
        org.junit.Assert.assertTrue("'" + localizable45 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable45.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray48);
        org.junit.Assert.assertNotNull(objArray54);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getGeneralPattern();
        java.lang.Number number3 = notStrictlyPositiveException1.getMin();
        org.apache.commons.math.exception.util.Localizable localizable4 = notStrictlyPositiveException1.getSpecificPattern();
        boolean boolean5 = notStrictlyPositiveException1.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable9 = notStrictlyPositiveException8.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException11 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable12 = notStrictlyPositiveException11.getGeneralPattern();
        java.lang.Object[] objArray15 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException(localizable12, objArray15);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException18 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable19 = notStrictlyPositiveException18.getGeneralPattern();
        java.lang.Object[] objArray22 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException23 = new org.apache.commons.math.MathException(localizable19, objArray22);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException26 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable27 = notStrictlyPositiveException26.getGeneralPattern();
        java.lang.Number number28 = notStrictlyPositiveException26.getArgument();
        java.lang.Object[] objArray29 = new java.lang.Object[] { 0, number28 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException30 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable19, objArray29);
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException(localizable9, objArray29);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException32 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, objArray29);
        notStrictlyPositiveException1.addSuppressed((java.lang.Throwable) mathIllegalArgumentException32);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException37 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1.0d, (java.lang.Number) 1.0d, true);
        org.apache.commons.math.exception.util.Localizable localizable38 = numberIsTooSmallException37.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException40 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable41 = notStrictlyPositiveException40.getGeneralPattern();
        java.lang.Object[] objArray44 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException45 = new org.apache.commons.math.MathException(localizable41, objArray44);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException47 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable48 = notStrictlyPositiveException47.getGeneralPattern();
        java.lang.Object[] objArray51 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException52 = new org.apache.commons.math.MathException(localizable48, objArray51);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException55 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable56 = notStrictlyPositiveException55.getGeneralPattern();
        java.lang.Number number57 = notStrictlyPositiveException55.getArgument();
        java.lang.Object[] objArray58 = new java.lang.Object[] { 0, number57 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException59 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable41, localizable48, objArray58);
        java.lang.Number number61 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException63 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable48, (java.lang.Number) 5.298342365610589d, number61, false);
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl68 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.7241400178893855d, 5729.5779513082325d, (double) 1.0f);
        double double70 = normalDistributionImpl68.density((-0.8813735870195429d));
        normalDistributionImpl68.reseedRandomGenerator((long) ' ');
        double double73 = normalDistributionImpl68.getStandardDeviation();
        java.lang.Object[] objArray75 = new java.lang.Object[] { 0.9999994948902197d, normalDistributionImpl68, "98fb2814226fd7ea893b3674ff008a58b86644b3fa279321290b" };
        org.apache.commons.math.ConvergenceException convergenceException76 = new org.apache.commons.math.ConvergenceException(localizable48, objArray75);
        org.apache.commons.math.ConvergenceException convergenceException77 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException1, localizable38, objArray75);
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
        org.junit.Assert.assertNull(localizable4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertTrue("'" + localizable19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable19.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertTrue("'" + localizable27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable27.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number28 + "' != '" + (-1L) + "'", number28.equals((-1L)));
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertTrue("'" + localizable38 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable38.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizable41 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable41.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertTrue("'" + localizable48 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable48.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray51);
        org.junit.Assert.assertTrue("'" + localizable56 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable56.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number57 + "' != '" + (-1L) + "'", number57.equals((-1L)));
        org.junit.Assert.assertNotNull(objArray58);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 6.962856045056186E-5d + "'", double70 == 6.962856045056186E-5d);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 5729.5779513082325d + "'", double73 == 5729.5779513082325d);
        org.junit.Assert.assertNotNull(objArray75);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        java.lang.Throwable throwable0 = null;
        java.lang.Object[] objArray5 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException6 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray5);
        org.apache.commons.math.exception.util.Localizable localizable7 = maxIterationsExceededException6.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException9 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable7, (java.lang.Number) (byte) 100);
        java.lang.Object[] objArray14 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException15 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray14);
        org.apache.commons.math.exception.util.Localizable localizable16 = maxIterationsExceededException15.getGeneralPattern();
        java.lang.Object[] objArray21 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException22 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray21);
        org.apache.commons.math.exception.util.Localizable localizable23 = maxIterationsExceededException22.getGeneralPattern();
        java.lang.Throwable[] throwableArray24 = maxIterationsExceededException22.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException25 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable16, (java.lang.Object[]) throwableArray24);
        org.apache.commons.math.ConvergenceException convergenceException26 = new org.apache.commons.math.ConvergenceException(throwable0, localizable7, (java.lang.Object[]) throwableArray24);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(localizable7);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(localizable16);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(localizable23);
        org.junit.Assert.assertNotNull(throwableArray24);
    }

//    @Test
//    public void test067() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test067");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextExponential(0.5772156649015329d);
//        double double6 = randomDataImpl1.nextF((double) (byte) 1, 1.0d);
//        java.lang.String str8 = randomDataImpl1.nextSecureHexString((int) (byte) 1);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution9 = null;
//        try {
//            int int10 = randomDataImpl1.nextInversionDeviate(integerDistribution9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.3618404789260187d + "'", double3 == 0.3618404789260187d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0037483465293384846d + "'", double6 == 0.0037483465293384846d);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "d" + "'", str8.equals("d"));
//    }

//    @Test
//    public void test068() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test068");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextExponential(0.5772156649015329d);
//        double double6 = randomDataImpl1.nextCauchy(0.19323284172500138d, 11013.232920103343d);
//        long long9 = randomDataImpl1.nextLong((long) (-1), (long) 284);
//        try {
//            randomDataImpl1.setSecureAlgorithm("3f1954d023d7debc3939d8436833319afb4184c39f76a071e6f3", "297b7abebbff2acfd73ac0b441f73ac1563f66b5695f83b12f6e");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: 297b7abebbff2acfd73ac0b441f73ac1563f66b5695f83b12f6e");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.36445958814695756d + "'", double3 == 0.36445958814695756d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4226.176537595758d + "'", double6 == 4226.176537595758d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2L + "'", long9 == 2L);
//    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.0536427460421095d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.362425382459675E-4d + "'", double1 == 9.362425382459675E-4d);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        double double2 = org.apache.commons.math.util.FastMath.pow(1.862009352569276d, (-0.29321831424771366d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.8333671450930542d + "'", double2 == 0.8333671450930542d);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        double double2 = org.apache.commons.math.util.FastMath.max(0.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        double double2 = org.apache.commons.math.util.FastMath.max((-0.5578101509651948d), (-7324.106818925002d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.5578101509651948d) + "'", double2 == (-0.5578101509651948d));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (-0.18072043342406346d), (java.lang.Number) 8.023043150857964d, (java.lang.Number) 0.250069889408776d);
        org.apache.commons.math.exception.util.Localizable localizable4 = outOfRangeException3.getSpecificPattern();
        java.lang.Throwable throwable5 = null;
        try {
            outOfRangeException3.addSuppressed(throwable5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(localizable4);
    }

//    @Test
//    public void test075() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test075");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT((double) 10L);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl7 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.7241400178893855d, 5729.5779513082325d, (double) 1.0f);
//        double double10 = normalDistributionImpl7.cumulativeProbability(1.0000000000000002d, 32.577917486317425d);
//        double double11 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        double double13 = randomDataImpl1.nextT(0.49708625100776777d);
//        double double16 = randomDataImpl1.nextCauchy(0.3830263845524403d, 0.5d);
//        try {
//            double double19 = randomDataImpl1.nextWeibull((-0.7546882591742721d), 11.363121841068297d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.755 is smaller than, or equal to, the minimum (0): shape (-0.755)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.12942372091143525d + "'", double3 == 0.12942372091143525d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.002198713597520441d + "'", double10 == 0.002198713597520441d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 6191.302091326122d + "'", double11 == 6191.302091326122d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-9.910891959402402d) + "'", double13 == (-9.910891959402402d));
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 2.462590958578433d + "'", double16 == 2.462590958578433d);
//    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.49708625100776777d, 0.0d, 1.72815954203808E-9d, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException3 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable4 = notStrictlyPositiveException3.getGeneralPattern();
        java.lang.Object[] objArray7 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException(localizable4, objArray7);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException10 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable11 = notStrictlyPositiveException10.getGeneralPattern();
        java.lang.Object[] objArray14 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException(localizable11, objArray14);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException18 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable19 = notStrictlyPositiveException18.getGeneralPattern();
        java.lang.Number number20 = notStrictlyPositiveException18.getArgument();
        java.lang.Object[] objArray21 = new java.lang.Object[] { 0, number20 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException22 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, localizable11, objArray21);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException26 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable4, (java.lang.Number) 2.0d, (java.lang.Number) (-0.5063656411097588d), true);
        java.lang.Object[] objArray31 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException32 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray31);
        org.apache.commons.math.exception.util.Localizable localizable33 = maxIterationsExceededException32.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException37 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable33, (java.lang.Number) (short) -1, (java.lang.Number) 1.0d, false);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException39 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable40 = notStrictlyPositiveException39.getGeneralPattern();
        java.lang.Object[] objArray43 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException(localizable40, objArray43);
        java.lang.Object[] objArray49 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException50 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray49);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException51 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable33, localizable40, objArray49);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException52 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, objArray49);
        org.apache.commons.math.MathException mathException53 = new org.apache.commons.math.MathException(throwable0, "1", objArray49);
        org.apache.commons.math.exception.util.Localizable localizable54 = mathException53.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertTrue("'" + localizable19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable19.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + (-1L) + "'", number20.equals((-1L)));
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(localizable33);
        org.junit.Assert.assertTrue("'" + localizable40 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable40.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray43);
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertNull(localizable54);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        double double1 = org.apache.commons.math.util.FastMath.log10(5308.302091326228d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.7249556302554714d + "'", double1 == 3.7249556302554714d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable1 = convergenceException0.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + localizable1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable1.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        double double1 = org.apache.commons.math.util.FastMath.expm1(1.281090320965418d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.600563355886622d + "'", double1 == 2.600563355886622d);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(630.3020913261216d, 1.6299344642368392d, (double) 46, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: maximal number of iterations (0) exceeded");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable3 = notStrictlyPositiveException2.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException5 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable3, (java.lang.Number) 10);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable9 = notStrictlyPositiveException8.getGeneralPattern();
        java.lang.Object[] objArray12 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException(localizable9, objArray12);
        java.lang.Object[] objArray18 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException19 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray18);
        org.apache.commons.math.exception.util.Localizable localizable20 = maxIterationsExceededException19.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException24 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable20, (java.lang.Number) (short) -1, (java.lang.Number) 1.0d, false);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException26 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable27 = notStrictlyPositiveException26.getGeneralPattern();
        java.lang.Object[] objArray30 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException(localizable27, objArray30);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException33 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable34 = notStrictlyPositiveException33.getGeneralPattern();
        java.lang.Object[] objArray37 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException38 = new org.apache.commons.math.MathException(localizable34, objArray37);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException41 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable42 = notStrictlyPositiveException41.getGeneralPattern();
        java.lang.Number number43 = notStrictlyPositiveException41.getArgument();
        java.lang.Object[] objArray44 = new java.lang.Object[] { 0, number43 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException45 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable27, localizable34, objArray44);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException47 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable48 = notStrictlyPositiveException47.getGeneralPattern();
        java.lang.Object[] objArray51 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException52 = new org.apache.commons.math.MathException(localizable48, objArray51);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException54 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable55 = notStrictlyPositiveException54.getGeneralPattern();
        java.lang.Object[] objArray58 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException59 = new org.apache.commons.math.MathException(localizable55, objArray58);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException62 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable63 = notStrictlyPositiveException62.getGeneralPattern();
        java.lang.Number number64 = notStrictlyPositiveException62.getArgument();
        java.lang.Object[] objArray65 = new java.lang.Object[] { 0, number64 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException66 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable48, localizable55, objArray65);
        org.apache.commons.math.ConvergenceException convergenceException67 = new org.apache.commons.math.ConvergenceException(localizable34, objArray65);
        java.lang.Object[] objArray73 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException74 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray73);
        org.apache.commons.math.exception.util.Localizable localizable75 = maxIterationsExceededException74.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException79 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable75, (java.lang.Number) (short) -1, (java.lang.Number) 1.0d, false);
        java.lang.Object[] objArray85 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException86 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray85);
        java.lang.Object[] objArray87 = maxIterationsExceededException86.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException88 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException79, "", objArray87);
        org.apache.commons.math.MathException mathException89 = new org.apache.commons.math.MathException("", objArray87);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException90 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable20, localizable34, objArray87);
        java.lang.Object[] objArray91 = mathIllegalArgumentException90.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException92 = new org.apache.commons.math.MaxIterationsExceededException(10, localizable9, objArray91);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException93 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 100, localizable3, objArray91);
        org.junit.Assert.assertTrue("'" + localizable3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable3.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(localizable20);
        org.junit.Assert.assertTrue("'" + localizable27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable27.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertTrue("'" + localizable34 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable34.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertTrue("'" + localizable42 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable42.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number43 + "' != '" + (-1L) + "'", number43.equals((-1L)));
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertTrue("'" + localizable48 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable48.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray51);
        org.junit.Assert.assertTrue("'" + localizable55 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable55.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray58);
        org.junit.Assert.assertTrue("'" + localizable63 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable63.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number64 + "' != '" + (-1L) + "'", number64.equals((-1L)));
        org.junit.Assert.assertNotNull(objArray65);
        org.junit.Assert.assertNotNull(objArray73);
        org.junit.Assert.assertNotNull(localizable75);
        org.junit.Assert.assertNotNull(objArray85);
        org.junit.Assert.assertNotNull(objArray87);
        org.junit.Assert.assertNotNull(objArray91);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP((-1.6107992316908502d), (double) 72L, (-0.28424013404743426d), 8);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

//    @Test
//    public void test084() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test084");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextExponential(0.5772156649015329d);
//        double double6 = randomDataImpl1.nextF((double) (byte) 1, 1.0d);
//        double double8 = randomDataImpl1.nextT(0.7241400178893856d);
//        double double11 = randomDataImpl1.nextGaussian(4.574710978503383d, 0.7241400178893856d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.24067606901161576d + "'", double3 == 0.24067606901161576d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 21.11488371358904d + "'", double6 == 21.11488371358904d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.8354835806667962d) + "'", double8 == (-1.8354835806667962d));
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.412350780585043d + "'", double11 == 4.412350780585043d);
//    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (byte) 10, (float) 9);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 9.0f + "'", float2 == 9.0f);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        double double1 = org.apache.commons.math.util.FastMath.asinh(28.480944236725758d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.042690477562768d + "'", double1 == 4.042690477562768d);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP((double) 46, (double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0464947441174824E-16d + "'", double2 == 1.0464947441174824E-16d);
    }

//    @Test
//    public void test088() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test088");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextSecureHexString((int) '4');
//        java.lang.String str5 = randomDataImpl1.nextHexString(13);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "f81da5ef47528a8be6a75293d6b265c9e01335ddd9d43aa191bf" + "'", str3.equals("f81da5ef47528a8be6a75293d6b265c9e01335ddd9d43aa191bf"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "c584872d8894a" + "'", str5.equals("c584872d8894a"));
//    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        double double1 = org.apache.commons.math.util.FastMath.acos(2.1114137530493142d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        double double1 = org.apache.commons.math.util.FastMath.asinh((-4801.85381129044d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-9.169904524423604d) + "'", double1 == (-9.169904524423604d));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        double double1 = org.apache.commons.math.util.FastMath.cosh(45.887426936904006d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.2425435763453436E19d + "'", double1 == 4.2425435763453436E19d);
    }

//    @Test
//    public void test093() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test093");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT((double) 10L);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl7 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.7241400178893855d, 5729.5779513082325d, (double) 1.0f);
//        double double10 = normalDistributionImpl7.cumulativeProbability(1.0000000000000002d, 32.577917486317425d);
//        double double11 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        randomDataImpl1.reSeedSecure((long) ' ');
//        try {
//            double double16 = randomDataImpl1.nextGamma(0.19323284172500138d, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): beta");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.4493868335957198d + "'", double3 == 0.4493868335957198d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.002198713597520441d + "'", double10 == 0.002198713597520441d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 3380.3020913261894d + "'", double11 == 3380.3020913261894d);
//    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.9151783217832619d, 1.2285876451802997d, 2.688117141816135E43d, 20);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.36542829151243467d + "'", double4 == 0.36542829151243467d);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        java.lang.Throwable throwable0 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray8);
        org.apache.commons.math.exception.util.Localizable localizable10 = maxIterationsExceededException9.getGeneralPattern();
        java.lang.Object[] objArray15 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException16 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray15);
        org.apache.commons.math.exception.util.Localizable localizable17 = maxIterationsExceededException16.getGeneralPattern();
        java.lang.Throwable[] throwableArray18 = maxIterationsExceededException16.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable10, (java.lang.Object[]) throwableArray18);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException20 = new org.apache.commons.math.MaxIterationsExceededException(13, "0a9413bf82824a5a7eef9e7859fd80f805dc34e275b134cf0f335342f3b7330b3e2c0817167d7998592ba04445b5e5bc0b99", (java.lang.Object[]) throwableArray18);
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException(throwable0, "d", (java.lang.Object[]) throwableArray18);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(localizable10);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(localizable17);
        org.junit.Assert.assertNotNull(throwableArray18);
    }

//    @Test
//    public void test096() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test096");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.7241400178893855d, 5729.5779513082325d, (double) 1.0f);
//        double double4 = normalDistributionImpl3.sample();
//        normalDistributionImpl3.reseedRandomGenerator((long) '4');
//        double double7 = normalDistributionImpl3.getMean();
//        normalDistributionImpl3.reseedRandomGenerator((long) 1);
//        double double11 = normalDistributionImpl3.cumulativeProbability((-0.9251475365964139d));
//        try {
//            double double14 = normalDistributionImpl3.cumulativeProbability(4683.4947847980275d, 0.0d);
//            org.junit.Assert.fail("Expected anonymous exception");
//        } catch (java.lang.IllegalArgumentException e) {
//            if (!e.getClass().isAnonymousClass()) {
//                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
//            }
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 2990.330323943424d + "'", double4 == 2990.330323943424d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.7241400178893855d + "'", double7 == 0.7241400178893855d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.4998851624788895d + "'", double11 == 0.4998851624788895d);
//    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        double double1 = org.apache.commons.math.util.FastMath.tan(10.000000000000002d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6483608274590892d + "'", double1 == 0.6483608274590892d);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        java.lang.Object[] objArray4 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray4);
        org.apache.commons.math.exception.util.Localizable localizable6 = maxIterationsExceededException5.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) (short) -1, (java.lang.Number) 1.0d, false);
        java.lang.Object[] objArray16 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException17 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray16);
        java.lang.Object[] objArray18 = maxIterationsExceededException17.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException10, "", objArray18);
        boolean boolean20 = numberIsTooLargeException10.getBoundIsAllowed();
        boolean boolean21 = numberIsTooLargeException10.getBoundIsAllowed();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(localizable6);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 0.011858093457390717d, (java.lang.Number) 0.5772156649015329d, (java.lang.Number) (-6557.380407102772d));
    }

//    @Test
//    public void test100() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test100");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextExponential(0.5772156649015329d);
//        long long6 = randomDataImpl1.nextSecureLong((long) 44, 183L);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2607128880621448d + "'", double3 == 0.2607128880621448d);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 93L + "'", long6 == 93L);
//    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 20, (java.lang.Number) (-0.5653738965860751d), (java.lang.Number) 12104.755054344712d);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        double double1 = org.apache.commons.math.util.FastMath.atanh(61.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test103() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test103");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.7241400178893855d, 5729.5779513082325d, (double) 1.0f);
//        double double4 = normalDistributionImpl3.sample();
//        normalDistributionImpl3.reseedRandomGenerator((long) '4');
//        double double8 = normalDistributionImpl3.cumulativeProbability(0.971303484757032d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 2278.2009115061223d + "'", double4 == 2278.2009115061223d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.5000172096370643d + "'", double8 == 0.5000172096370643d);
//    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        java.lang.Throwable throwable0 = null;
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException(throwable0, "", objArray2);
        java.lang.Object[] objArray8 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray8);
        org.apache.commons.math.exception.util.Localizable localizable10 = maxIterationsExceededException9.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException14 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable10, (java.lang.Number) (short) -1, (java.lang.Number) 1.0d, false);
        java.lang.Object[] objArray20 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException21 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray20);
        java.lang.Object[] objArray22 = maxIterationsExceededException21.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException14, "", objArray22);
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException23);
        convergenceException3.addSuppressed((java.lang.Throwable) convergenceException23);
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException23);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(localizable10);
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(objArray22);
    }

//    @Test
//    public void test105() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test105");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextSecureHexString((int) '4');
//        long long6 = randomDataImpl1.nextSecureLong((long) (-1), (long) '4');
//        int int9 = randomDataImpl1.nextSecureInt(1, (int) (short) 100);
//        int int12 = randomDataImpl1.nextZipf((int) 'a', 3697.517657265949d);
//        try {
//            java.lang.String str14 = randomDataImpl1.nextSecureHexString((int) (short) -1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): length (-1)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "6f5b84393d36b77a45efb49203adc63099560b7657e52baa0269" + "'", str3.equals("6f5b84393d36b77a45efb49203adc63099560b7657e52baa0269"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 44L + "'", long6 == 44L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 48 + "'", int9 == 48);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable3 = notStrictlyPositiveException1.getSpecificPattern();
        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException1);
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException1);
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException6);
        java.lang.String str8 = convergenceException7.getPattern();
        notStrictlyPositiveException1.addSuppressed((java.lang.Throwable) convergenceException7);
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNull(localizable3);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "{0}" + "'", str8.equals("{0}"));
    }

//    @Test
//    public void test107() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test107");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextExponential(0.5772156649015329d);
//        double double6 = randomDataImpl1.nextUniform(1.000188513259658d, 7.930067261567154E14d);
//        randomDataImpl1.reSeedSecure();
//        randomDataImpl1.reSeed((long) 5);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.3413982611649174d + "'", double3 == 0.3413982611649174d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.654017291980331E14d + "'", double6 == 4.654017291980331E14d);
//    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        java.lang.Object[] objArray4 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray4);
        org.apache.commons.math.exception.util.Localizable localizable6 = maxIterationsExceededException5.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) (short) -1, (java.lang.Number) 1.0d, false);
        java.lang.Object[] objArray16 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException17 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray16);
        java.lang.Object[] objArray18 = maxIterationsExceededException17.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException10, "", objArray18);
        boolean boolean20 = numberIsTooLargeException10.getBoundIsAllowed();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException23 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable24 = notStrictlyPositiveException23.getGeneralPattern();
        java.lang.Object[] objArray27 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException28 = new org.apache.commons.math.MathException(localizable24, objArray27);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException30 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable31 = notStrictlyPositiveException30.getGeneralPattern();
        java.lang.Object[] objArray34 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException(localizable31, objArray34);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException38 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable39 = notStrictlyPositiveException38.getGeneralPattern();
        java.lang.Number number40 = notStrictlyPositiveException38.getArgument();
        java.lang.Object[] objArray41 = new java.lang.Object[] { 0, number40 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException42 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable24, localizable31, objArray41);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException44 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable45 = notStrictlyPositiveException44.getGeneralPattern();
        java.lang.Object[] objArray48 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException49 = new org.apache.commons.math.MathException(localizable45, objArray48);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException51 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable52 = notStrictlyPositiveException51.getGeneralPattern();
        java.lang.Object[] objArray55 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException56 = new org.apache.commons.math.MathException(localizable52, objArray55);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException59 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable60 = notStrictlyPositiveException59.getGeneralPattern();
        java.lang.Number number61 = notStrictlyPositiveException59.getArgument();
        java.lang.Object[] objArray62 = new java.lang.Object[] { 0, number61 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException63 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable45, localizable52, objArray62);
        org.apache.commons.math.ConvergenceException convergenceException64 = new org.apache.commons.math.ConvergenceException(localizable31, objArray62);
        org.apache.commons.math.MathException mathException65 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException10, "05299f0e072343e00952d77e9bba14e42f77765c61bcdb705583", objArray62);
        org.apache.commons.math.exception.util.Localizable localizable66 = numberIsTooLargeException10.getSpecificPattern();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(localizable6);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + localizable24 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable24.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertTrue("'" + localizable31 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable31.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertTrue("'" + localizable39 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable39.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number40 + "' != '" + (-1L) + "'", number40.equals((-1L)));
        org.junit.Assert.assertNotNull(objArray41);
        org.junit.Assert.assertTrue("'" + localizable45 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable45.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray48);
        org.junit.Assert.assertTrue("'" + localizable52 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable52.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray55);
        org.junit.Assert.assertTrue("'" + localizable60 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable60.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number61 + "' != '" + (-1L) + "'", number61.equals((-1L)));
        org.junit.Assert.assertNotNull(objArray62);
        org.junit.Assert.assertNotNull(localizable66);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        java.lang.Object[] objArray4 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray4);
        java.lang.Object[] objArray6 = maxIterationsExceededException5.getArguments();
        java.lang.String str7 = maxIterationsExceededException5.toString();
        java.lang.Class<?> wildcardClass8 = maxIterationsExceededException5.getClass();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.MaxIterationsExceededException: " + "'", str7.equals("org.apache.commons.math.MaxIterationsExceededException: "));
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

//    @Test
//    public void test110() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test110");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.7241400178893855d, 5729.5779513082325d, (double) 1.0f);
//        double double4 = normalDistributionImpl3.getStandardDeviation();
//        double double5 = normalDistributionImpl3.sample();
//        double[] doubleArray7 = normalDistributionImpl3.sample(20);
//        double double9 = normalDistributionImpl3.inverseCumulativeProbability(2.220446049250313E-16d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 5729.5779513082325d + "'", double4 == 5729.5779513082325d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4877.226759918838d + "'", double5 == 4877.226759918838d);
//        org.junit.Assert.assertNotNull(doubleArray7);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-46475.85381129035d) + "'", double9 == (-46475.85381129035d));
//    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ((-0.28424013404743426d), (double) 43L, 1.000188513259658d, (int) '#');
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.18355825835313155d, (double) 20L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.419663610149634E-11d + "'", double2 == 3.419663610149634E-11d);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.7854924111435233d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

//    @Test
//    public void test114() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test114");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT((double) 10L);
//        double double6 = randomDataImpl1.nextBeta(0.20378364545839303d, (double) 6L);
//        long long8 = randomDataImpl1.nextPoisson(0.07714563080407891d);
//        double double11 = randomDataImpl1.nextWeibull(1.2285876451802997d, 1.3135192566529642E-15d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl15 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.7241400178893855d, 5729.5779513082325d, (double) 1.0f);
//        double double16 = normalDistributionImpl15.getStandardDeviation();
//        double double17 = normalDistributionImpl15.sample();
//        double[] doubleArray19 = normalDistributionImpl15.sample(20);
//        double double20 = normalDistributionImpl15.getStandardDeviation();
//        double double21 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl15);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.3723218049989616d + "'", double3 == 1.3723218049989616d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.04349159926205832d + "'", double6 == 0.04349159926205832d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 2.485950019435391E-16d + "'", double11 == 2.485950019435391E-16d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 5729.5779513082325d + "'", double16 == 5729.5779513082325d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1592.555077400728d + "'", double17 == 1592.555077400728d);
//        org.junit.Assert.assertNotNull(doubleArray19);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 5729.5779513082325d + "'", double20 == 5729.5779513082325d);
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + (-2322.8538112903434d) + "'", double21 == (-2322.8538112903434d));
//    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        double double1 = org.apache.commons.math.util.FastMath.sin((-0.13147441609958888d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.13109597600383877d) + "'", double1 == (-0.13109597600383877d));
    }

//    @Test
//    public void test116() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test116");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextSecureHexString((int) '4');
//        double double6 = randomDataImpl1.nextBeta((double) 183L, 5.298342365610589d);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "c05380d0d874a48511381bc5b9f2e207f5adf0dd2d8a1d040e6b" + "'", str3.equals("c05380d0d874a48511381bc5b9f2e207f5adf0dd2d8a1d040e6b"));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.986567241904216d + "'", double6 == 0.986567241904216d);
//    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((-0.8833654229914927d), (double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.8833654229914928d) + "'", double2 == (-0.8833654229914928d));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (byte) 10, (float) 20);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

//    @Test
//    public void test119() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test119");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT((double) 10L);
//        randomDataImpl1.reSeed();
//        double double6 = randomDataImpl1.nextChiSquare(0.5848500137377979d);
//        int int9 = randomDataImpl1.nextSecureInt((int) (byte) -1, 20);
//        double double11 = randomDataImpl1.nextExponential(3.141592653589793d);
//        java.lang.String str13 = randomDataImpl1.nextHexString((int) (short) 1);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.4670883312231038d + "'", double3 == 1.4670883312231038d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.9231566265383089d + "'", double6 == 1.9231566265383089d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 17 + "'", int9 == 17);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 3.2315205206436697d + "'", double11 == 3.2315205206436697d);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "d" + "'", str13.equals("d"));
//    }

//    @Test
//    public void test120() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test120");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT((double) 10L);
//        randomDataImpl1.reSeed();
//        double double6 = randomDataImpl1.nextChiSquare(0.5848500137377979d);
//        double double8 = randomDataImpl1.nextExponential((double) 13L);
//        double double11 = randomDataImpl1.nextWeibull(0.052371959612836624d, 0.1446963233687307d);
//        try {
//            int int14 = randomDataImpl1.nextPascal((int) (short) 10, 5652.686218477152d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 5,652.686 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.4799783184564084d + "'", double3 == 1.4799783184564084d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.9500845927972197d + "'", double6 == 1.9500845927972197d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 25.921528630437106d + "'", double8 == 25.921528630437106d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 8.912252234550653d + "'", double11 == 8.912252234550653d);
//    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        double double2 = org.apache.commons.math.util.FastMath.min(0.986567241904216d, 1.5707963267948966d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.986567241904216d + "'", double2 == 0.986567241904216d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        double double1 = org.apache.commons.math.util.FastMath.signum(1.1006710821571968d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

//    @Test
//    public void test123() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test123");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT((double) 10L);
//        randomDataImpl1.reSeed();
//        double double7 = randomDataImpl1.nextUniform((-104.14857733269706d), 2729.302091326176d);
//        try {
//            int int10 = randomDataImpl1.nextSecureInt((int) (short) 100, 46);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100 is larger than, or equal to, the maximum (46): lower bound (100) must be strictly less than upper bound (46)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.4524337728527443d + "'", double3 == 1.4524337728527443d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2478.5055414419985d + "'", double7 == 2478.5055414419985d);
//    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.8333671450930542d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6723872170167876d + "'", double1 == 0.6723872170167876d);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 57L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test126() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test126");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT((double) 10L);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl7 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.7241400178893855d, 5729.5779513082325d, (double) 1.0f);
//        double double10 = normalDistributionImpl7.cumulativeProbability(1.0000000000000002d, 32.577917486317425d);
//        double double11 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        double double13 = randomDataImpl1.nextT(0.49708625100776777d);
//        double double16 = randomDataImpl1.nextCauchy((double) 0.0f, (double) 7);
//        double double19 = randomDataImpl1.nextGaussian(0.8491230067936573d, 0.7854452872706951d);
//        randomDataImpl1.reSeed((long) 4);
//        randomDataImpl1.reSeed();
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.028653589997601d + "'", double3 == 1.028653589997601d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.002198713597520441d + "'", double10 == 0.002198713597520441d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 5790.302091326122d + "'", double11 == 5790.302091326122d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-1.1662762125914088d) + "'", double13 == (-1.1662762125914088d));
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 4.1187376053663165d + "'", double16 == 4.1187376053663165d);
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 2.4133380543868626d + "'", double19 == 2.4133380543868626d);
//    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 7614.30209132597d);
        java.lang.Number number3 = notStrictlyPositiveException2.getMin();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.3479747020271566d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3550398415388412d + "'", double1 == 0.3550398415388412d);
    }

//    @Test
//    public void test129() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test129");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT((double) 10L);
//        randomDataImpl1.reSeed();
//        double double6 = randomDataImpl1.nextChiSquare(0.5848500137377979d);
//        int int9 = randomDataImpl1.nextSecureInt((int) (byte) -1, 20);
//        double double11 = randomDataImpl1.nextExponential(3.141592653589793d);
//        try {
//            int int14 = randomDataImpl1.nextSecureInt(0, 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 0 is larger than, or equal to, the maximum (0): lower bound (0) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0135585365490154d + "'", double3 == 1.0135585365490154d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.090211610841866d + "'", double6 == 1.090211610841866d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 2.4663683396668854d + "'", double11 == 2.4663683396668854d);
//    }

//    @Test
//    public void test130() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test130");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT((double) 10L);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl7 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.7241400178893855d, 5729.5779513082325d, (double) 1.0f);
//        double double10 = normalDistributionImpl7.cumulativeProbability(1.0000000000000002d, 32.577917486317425d);
//        double double11 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        double double13 = randomDataImpl1.nextT(0.49708625100776777d);
//        double double16 = randomDataImpl1.nextCauchy((double) 0.0f, (double) 7);
//        double double19 = randomDataImpl1.nextGaussian(0.8491230067936573d, 0.7854452872706951d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl23 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.19453209082334608d, 1.1021717313803565d, 0.9041801869615227d);
//        double double24 = normalDistributionImpl23.getMean();
//        double double25 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl23);
//        try {
//            double double27 = normalDistributionImpl23.inverseCumulativeProbability((double) 11L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 11 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0014126684008515d + "'", double3 == 1.0014126684008515d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.002198713597520441d + "'", double10 == 0.002198713597520441d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 611.3020913261338d + "'", double11 == 611.3020913261338d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.5672982966815509d + "'", double13 == 0.5672982966815509d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 3.473346289213282d + "'", double16 == 3.473346289213282d);
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.680856793666734d + "'", double19 == 0.680856793666734d);
//        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.19453209082334608d + "'", double24 == 0.19453209082334608d);
//        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.2967038222037024d + "'", double25 == 1.2967038222037024d);
//    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        double double1 = org.apache.commons.math.util.FastMath.acosh(1.6299344642368392d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0705754890866386d + "'", double1 == 1.0705754890866386d);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 1L, (float) 74L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        double double2 = org.apache.commons.math.util.FastMath.max(0.0d, 0.24067606901161576d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.24067606901161576d + "'", double2 == 0.24067606901161576d);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        double double1 = org.apache.commons.math.util.FastMath.atan(1.2852543175387054d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9095797466712211d + "'", double1 == 0.9095797466712211d);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        double double1 = org.apache.commons.math.util.FastMath.cos((-1.8354835806667962d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.2616074264028443d) + "'", double1 == (-0.2616074264028443d));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException4 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable2, (java.lang.Number) 10);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException6 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable7 = notStrictlyPositiveException6.getGeneralPattern();
        java.lang.Object[] objArray10 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException(localizable7, objArray10);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException13 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable14 = notStrictlyPositiveException13.getGeneralPattern();
        java.lang.Object[] objArray17 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException(localizable14, objArray17);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException21 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable22 = notStrictlyPositiveException21.getGeneralPattern();
        java.lang.Number number23 = notStrictlyPositiveException21.getArgument();
        java.lang.Object[] objArray24 = new java.lang.Object[] { 0, number23 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException25 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, localizable14, objArray24);
        java.lang.Number number27 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException29 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable14, (java.lang.Number) 5.298342365610589d, number27, false);
        java.lang.Object[] objArray34 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException35 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray34);
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException4, localizable14, objArray34);
        java.lang.Number number37 = notStrictlyPositiveException4.getArgument();
        java.lang.Object[] objArray38 = notStrictlyPositiveException4.getArguments();
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertTrue("'" + localizable14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable14.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertTrue("'" + localizable22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable22.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + (-1L) + "'", number23.equals((-1L)));
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertTrue("'" + number37 + "' != '" + 10 + "'", number37.equals(10));
        org.junit.Assert.assertNotNull(objArray38);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.3273817120025671d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9468875377682411d + "'", double1 == 0.9468875377682411d);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        double double1 = org.apache.commons.math.util.FastMath.sinh(4.574710978503383d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 48.49484536082474d + "'", double1 == 48.49484536082474d);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        double double1 = org.apache.commons.math.util.FastMath.log1p(1.4130122174770463d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8808758498199012d + "'", double1 == 0.8808758498199012d);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 11L, 0.7854924111435233d);
        double double4 = normalDistributionImpl2.cumulativeProbability(3697.517657265949d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

//    @Test
//    public void test141() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test141");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.7241400178893855d, 5729.5779513082325d, (double) 1.0f);
//        double double4 = normalDistributionImpl3.getStandardDeviation();
//        double double5 = normalDistributionImpl3.sample();
//        normalDistributionImpl3.reseedRandomGenerator(8L);
//        double[] doubleArray9 = normalDistributionImpl3.sample(20);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 5729.5779513082325d + "'", double4 == 5729.5779513082325d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 7466.55781747604d + "'", double5 == 7466.55781747604d);
//        org.junit.Assert.assertNotNull(doubleArray9);
//    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        java.lang.Object[] objArray4 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray4);
        org.apache.commons.math.exception.util.Localizable localizable6 = maxIterationsExceededException5.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) (short) -1, (java.lang.Number) 1.0d, false);
        java.lang.Object[] objArray16 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException17 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray16);
        java.lang.Object[] objArray18 = maxIterationsExceededException17.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException10, "", objArray18);
        boolean boolean20 = numberIsTooLargeException10.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable21 = numberIsTooLargeException10.getSpecificPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException25 = new org.apache.commons.math.exception.OutOfRangeException(localizable21, (java.lang.Number) 75.6939756606048d, (java.lang.Number) 0.8179912516250313d, (java.lang.Number) 0.014602538937188877d);
        java.lang.String str26 = outOfRangeException25.toString();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(localizable6);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(localizable21);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "org.apache.commons.math.exception.OutOfRangeException: 75.694 out of [0.818, 0.015] range: " + "'", str26.equals("org.apache.commons.math.exception.OutOfRangeException: 75.694 out of [0.818, 0.015] range: "));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        double double1 = org.apache.commons.math.util.FastMath.signum((-3588.889672940672d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 100);
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException1);
        org.apache.commons.math.exception.util.Localizable localizable3 = mathException2.getSpecificPattern();
        java.lang.String str4 = mathException2.toString();
        org.junit.Assert.assertNull(localizable3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.MathException: maximal number of iterations (100) exceeded" + "'", str4.equals("org.apache.commons.math.MathException: maximal number of iterations (100) exceeded"));
    }

//    @Test
//    public void test145() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test145");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextExponential(0.5772156649015329d);
//        double double6 = randomDataImpl1.nextUniform(1.000188513259658d, 7.930067261567154E14d);
//        int int9 = randomDataImpl1.nextSecureInt((int) (short) 1, (int) (byte) 10);
//        double double11 = randomDataImpl1.nextChiSquare(4.641588833612779d);
//        int[] intArray14 = randomDataImpl1.nextPermutation(44, 9);
//        randomDataImpl1.reSeedSecure();
//        double double18 = randomDataImpl1.nextBeta(3.941866060050484E-159d, 0.9826804312789398d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.16518047999346241d + "'", double3 == 0.16518047999346241d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.53555641055531E14d + "'", double6 == 4.53555641055531E14d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 9.48894089406262d + "'", double11 == 9.48894089406262d);
//        org.junit.Assert.assertNotNull(intArray14);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
//    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ((double) 14, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.ConvergenceException convergenceException1 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException0);
        java.lang.String str2 = convergenceException0.getPattern();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "convergence failed" + "'", str2.equals("convergence failed"));
    }

//    @Test
//    public void test148() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test148");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextExponential(0.5772156649015329d);
//        double double6 = randomDataImpl1.nextUniform(1.000188513259658d, 7.930067261567154E14d);
//        int int9 = randomDataImpl1.nextSecureInt((int) (short) 1, (int) (byte) 10);
//        double double11 = randomDataImpl1.nextChiSquare(4.641588833612779d);
//        double double14 = randomDataImpl1.nextGamma(1.0263075346092196E-6d, (double) 183L);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution15 = null;
//        try {
//            int int16 = randomDataImpl1.nextInversionDeviate(integerDistribution15);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.16752577565829865d + "'", double3 == 0.16752577565829865d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.6681008086082016E14d + "'", double6 == 2.6681008086082016E14d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 2.803758983701491d + "'", double11 == 2.803758983701491d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.6176244885832946E-9d + "'", double14 == 1.6176244885832946E-9d);
//    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(1.4865406938425747d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.025945029572433925d + "'", double1 == 0.025945029572433925d);
    }

//    @Test
//    public void test150() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test150");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextExponential(0.5772156649015329d);
//        double double6 = randomDataImpl1.nextF((double) (byte) 1, 1.0d);
//        long long8 = randomDataImpl1.nextPoisson(10.000000000000002d);
//        randomDataImpl1.reSeedSecure();
//        double double11 = randomDataImpl1.nextChiSquare((double) 52);
//        double double14 = randomDataImpl1.nextUniform((double) 74L, 12104.755054344712d);
//        java.lang.String str16 = randomDataImpl1.nextHexString((int) (short) 10);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.15413486047306554d + "'", double3 == 0.15413486047306554d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.028109861364109555d + "'", double6 == 0.028109861364109555d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 14L + "'", long8 == 14L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 64.42516256000114d + "'", double11 == 64.42516256000114d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1996.112980260333d + "'", double14 == 1996.112980260333d);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "ae83b73133" + "'", str16.equals("ae83b73133"));
//    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, (-12352.21109622818d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 48.49484536082474d, (java.lang.Number) 0.0034813858640041495d, false);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 74L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-5.737022539278999d) + "'", double1 == (-5.737022539278999d));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (-0.18072043342406346d), (java.lang.Number) 8.023043150857964d, (java.lang.Number) 0.250069889408776d);
        java.lang.Object[] objArray4 = outOfRangeException3.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable5 = outOfRangeException3.getSpecificPattern();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNull(localizable5);
    }

//    @Test
//    public void test155() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test155");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT((double) 10L);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl7 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.7241400178893855d, 5729.5779513082325d, (double) 1.0f);
//        double double10 = normalDistributionImpl7.cumulativeProbability(1.0000000000000002d, 32.577917486317425d);
//        double double11 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        double double13 = randomDataImpl1.nextT(0.49708625100776777d);
//        double double16 = randomDataImpl1.nextCauchy((double) 0.0f, (double) 7);
//        double double19 = randomDataImpl1.nextGaussian(0.8491230067936573d, 0.7854452872706951d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl23 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.19453209082334608d, 1.1021717313803565d, 0.9041801869615227d);
//        double double24 = normalDistributionImpl23.getMean();
//        double double25 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl23);
//        long long27 = randomDataImpl1.nextPoisson((double) 10.0f);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.7352195594470117d + "'", double3 == 0.7352195594470117d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.002198713597520441d + "'", double10 == 0.002198713597520441d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 8876.302091325942d + "'", double11 == 8876.302091325942d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.4673384405536164d + "'", double13 == 0.4673384405536164d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 25.16549223052724d + "'", double16 == 25.16549223052724d);
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.08269630276245565d + "'", double19 == 0.08269630276245565d);
//        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.19453209082334608d + "'", double24 == 0.19453209082334608d);
//        org.junit.Assert.assertTrue("'" + double25 + "' != '" + (-0.9076396405570104d) + "'", double25 == (-0.9076396405570104d));
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 6L + "'", long27 == 6L);
//    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        java.lang.Object[] objArray4 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray4);
        org.apache.commons.math.exception.util.Localizable localizable6 = maxIterationsExceededException5.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) (short) -1, (java.lang.Number) 1.0d, false);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException12 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable13 = notStrictlyPositiveException12.getGeneralPattern();
        java.lang.Object[] objArray16 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException(localizable13, objArray16);
        java.lang.Object[] objArray22 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException23 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray22);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException24 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, localizable13, objArray22);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException28 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) 100, (java.lang.Number) (-0.5063656411097588d), (java.lang.Number) (-10.586871123130669d));
        java.lang.Number number29 = outOfRangeException28.getHi();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(localizable6);
        org.junit.Assert.assertTrue("'" + localizable13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable13.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertTrue("'" + number29 + "' != '" + (-10.586871123130669d) + "'", number29.equals((-10.586871123130669d)));
    }

//    @Test
//    public void test157() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test157");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT((double) 10L);
//        double double5 = randomDataImpl1.nextExponential((double) 6L);
//        int int9 = randomDataImpl1.nextHypergeometric((int) (short) 100, 19, (int) (byte) 100);
//        double double11 = randomDataImpl1.nextExponential(7466.55781747604d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.7752007349477611d + "'", double3 == 0.7752007349477611d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 8.621881058849441d + "'", double5 == 8.621881058849441d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 19 + "'", int9 == 19);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1837.9646657144744d + "'", double11 == 1837.9646657144744d);
//    }

//    @Test
//    public void test158() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test158");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextExponential(0.5772156649015329d);
//        double double6 = randomDataImpl1.nextCauchy(0.19323284172500138d, 11013.232920103343d);
//        long long9 = randomDataImpl1.nextLong((long) (-1), (long) 284);
//        long long12 = randomDataImpl1.nextLong((long) 19, (long) ' ');
//        double double15 = randomDataImpl1.nextCauchy(0.0d, (double) 10L);
//        randomDataImpl1.reSeed();
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2965667969050154d + "'", double3 == 0.2965667969050154d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 3899.833897408454d + "'", double6 == 3899.833897408454d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 185L + "'", long9 == 185L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 22L + "'", long12 == 22L);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-10.430310221995045d) + "'", double15 == (-10.430310221995045d));
//    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, 0.7804384644833656d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        double double1 = org.apache.commons.math.util.FastMath.cosh(3697.517657265949d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        double double2 = org.apache.commons.math.util.FastMath.max(1.0d, 0.43820761657943896d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

//    @Test
//    public void test162() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test162");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT((double) 10L);
//        java.lang.String str5 = randomDataImpl1.nextSecureHexString(20);
//        randomDataImpl1.reSeed();
//        double double9 = randomDataImpl1.nextCauchy((-12352.21109622818d), 5.5903776604969133E17d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2511611121136206d + "'", double3 == 0.2511611121136206d);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "af250c27273208d82cda" + "'", str5.equals("af250c27273208d82cda"));
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.74914391408308224E17d + "'", double9 == 1.74914391408308224E17d);
//    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.7241400178893855d, 5729.5779513082325d, (double) 1.0f);
        double double5 = normalDistributionImpl3.density((-0.8813735870195429d));
        double double6 = normalDistributionImpl3.getStandardDeviation();
        normalDistributionImpl3.reseedRandomGenerator(0L);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 6.962856045056186E-5d + "'", double5 == 6.962856045056186E-5d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 5729.5779513082325d + "'", double6 == 5729.5779513082325d);
    }

//    @Test
//    public void test164() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test164");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextExponential(0.5772156649015329d);
//        double double6 = randomDataImpl1.nextCauchy(0.19323284172500138d, 11013.232920103343d);
//        long long9 = randomDataImpl1.nextLong((long) (-1), (long) 284);
//        long long11 = randomDataImpl1.nextPoisson((double) (byte) 1);
//        int int14 = randomDataImpl1.nextSecureInt(0, 19);
//        double double17 = randomDataImpl1.nextUniform((double) (byte) 0, 0.4999509311395951d);
//        double double20 = randomDataImpl1.nextUniform(0.0d, 0.46045670759395957d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.30308614008410467d + "'", double3 == 0.30308614008410467d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-6789.04978320541d) + "'", double6 == (-6789.04978320541d));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 120L + "'", long9 == 120L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 3 + "'", int14 == 3);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.022565796660426546d + "'", double17 == 0.022565796660426546d);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.09337262448433814d + "'", double20 == 0.09337262448433814d);
//    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.7854452872706951d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 45.00269999905135d + "'", double1 == 45.00269999905135d);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(7.774290469738962E14d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3568696570336148E13d + "'", double1 == 1.3568696570336148E13d);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 3, (long) 'a');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3L + "'", long2 == 3L);
    }

//    @Test
//    public void test168() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test168");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextSecureHexString((int) '4');
//        java.lang.String str5 = randomDataImpl1.nextHexString((int) (short) 100);
//        int int8 = randomDataImpl1.nextSecureInt((int) (byte) 1, (int) '#');
//        java.lang.String str10 = randomDataImpl1.nextHexString((int) (byte) 10);
//        long long13 = randomDataImpl1.nextLong(3L, (long) 9);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ffcf6ec0192cb66ace0f6347582c4b70ff4d1a060f126e827eb8" + "'", str3.equals("ffcf6ec0192cb66ace0f6347582c4b70ff4d1a060f126e827eb8"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "827dbd173bdf2ecf1b5ab52e24b8c54a3b4a697c76921ef6909764a450bd368ff46e04789a56f9aba54b26ed8939f6eb78dc" + "'", str5.equals("827dbd173bdf2ecf1b5ab52e24b8c54a3b4a697c76921ef6909764a450bd368ff46e04789a56f9aba54b26ed8939f6eb78dc"));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "48aa772520" + "'", str10.equals("48aa772520"));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 8L + "'", long13 == 8L);
//    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        double double1 = org.apache.commons.math.util.FastMath.signum((-0.2616074264028443d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

//    @Test
//    public void test170() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test170");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) (short) 10, (int) '#');
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 25 + "'", int4 == 25);
//    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        double double1 = org.apache.commons.math.util.FastMath.atan((-7324.106818925002d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5706597913758333d) + "'", double1 == (-1.5706597913758333d));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        double double1 = org.apache.commons.math.special.Gamma.logGamma((-10.11235543535243d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getGeneralPattern();
        java.lang.Object[] objArray5 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException(localizable2, objArray5);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable9 = notStrictlyPositiveException8.getGeneralPattern();
        java.lang.Object[] objArray12 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException(localizable9, objArray12);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException16 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable17 = notStrictlyPositiveException16.getGeneralPattern();
        java.lang.Number number18 = notStrictlyPositiveException16.getArgument();
        java.lang.Object[] objArray19 = new java.lang.Object[] { 0, number18 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException20 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, localizable9, objArray19);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException22 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable23 = notStrictlyPositiveException22.getGeneralPattern();
        java.lang.Object[] objArray26 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException(localizable23, objArray26);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException29 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable30 = notStrictlyPositiveException29.getGeneralPattern();
        java.lang.Object[] objArray33 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException34 = new org.apache.commons.math.MathException(localizable30, objArray33);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException37 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable38 = notStrictlyPositiveException37.getGeneralPattern();
        java.lang.Number number39 = notStrictlyPositiveException37.getArgument();
        java.lang.Object[] objArray40 = new java.lang.Object[] { 0, number39 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException41 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable23, localizable30, objArray40);
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException(localizable9, objArray40);
        java.lang.Number number43 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException44 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable9, number43);
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + (-1L) + "'", number18.equals((-1L)));
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertTrue("'" + localizable23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable23.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertTrue("'" + localizable30 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable30.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertTrue("'" + localizable38 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable38.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number39 + "' != '" + (-1L) + "'", number39.equals((-1L)));
        org.junit.Assert.assertNotNull(objArray40);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 9L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test175() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test175");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT((double) 10L);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl7 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.7241400178893855d, 5729.5779513082325d, (double) 1.0f);
//        double double10 = normalDistributionImpl7.cumulativeProbability(1.0000000000000002d, 32.577917486317425d);
//        double double11 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        randomDataImpl1.reSeedSecure((long) ' ');
//        int int16 = randomDataImpl1.nextBinomial((int) (byte) 100, 0.017861012128359798d);
//        try {
//            randomDataImpl1.setSecureAlgorithm("org.apache.commons.math.MathException: hi!", "1");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: 1");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.32685230846272734d + "'", double3 == 0.32685230846272734d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.002198713597520441d + "'", double10 == 0.002198713597520441d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-1109.8538112903657d) + "'", double11 == (-1109.8538112903657d));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 3 + "'", int16 == 3);
//    }

//    @Test
//    public void test176() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test176");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextExponential(0.5772156649015329d);
//        double double6 = randomDataImpl1.nextUniform(1.000188513259658d, 7.930067261567154E14d);
//        double double9 = randomDataImpl1.nextBeta(5.085984129905464E14d, (double) 1);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.34345334891952733d + "'", double3 == 0.34345334891952733d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 7.461834968267408E14d + "'", double6 == 7.461834968267408E14d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
//    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        double double1 = org.apache.commons.math.util.FastMath.tanh(7.462495812747164E-4d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.462494427488261E-4d + "'", double1 == 7.462494427488261E-4d);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getSpecificPattern();
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException1);
        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException3);
        org.junit.Assert.assertNull(localizable2);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (byte) 100, (float) 13L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 13.0f + "'", float2 == 13.0f);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.3092272477570279d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0481929396714582d + "'", double1 == 1.0481929396714582d);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.022303542527125512d, (-0.8529498273620102d), 0.5892487773871758d, 25);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

//    @Test
//    public void test182() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test182");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextExponential(0.5772156649015329d);
//        double double6 = randomDataImpl1.nextUniform(1.000188513259658d, 7.930067261567154E14d);
//        int int9 = randomDataImpl1.nextSecureInt((int) (short) 1, (int) (byte) 10);
//        double double11 = randomDataImpl1.nextChiSquare(4.641588833612779d);
//        try {
//            long long13 = randomDataImpl1.nextPoisson((double) (-1));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): mean (-1)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.35100243981402895d + "'", double3 == 0.35100243981402895d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.000770675232162E14d + "'", double6 == 4.000770675232162E14d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 3.3431306169604644d + "'", double11 == 3.3431306169604644d);
//    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 100, (java.lang.Number) (byte) -1, (java.lang.Number) 0.0d);
        java.lang.Number number4 = outOfRangeException3.getHi();
        java.lang.Number number5 = outOfRangeException3.getLo();
        java.lang.Object[] objArray11 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException12 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray11);
        org.apache.commons.math.exception.util.Localizable localizable13 = maxIterationsExceededException12.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException17 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable13, (java.lang.Number) (short) -1, (java.lang.Number) 1.0d, false);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException19 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable20 = notStrictlyPositiveException19.getGeneralPattern();
        java.lang.Object[] objArray23 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException(localizable20, objArray23);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException26 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable27 = notStrictlyPositiveException26.getGeneralPattern();
        java.lang.Object[] objArray30 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException(localizable27, objArray30);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException34 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable35 = notStrictlyPositiveException34.getGeneralPattern();
        java.lang.Number number36 = notStrictlyPositiveException34.getArgument();
        java.lang.Object[] objArray37 = new java.lang.Object[] { 0, number36 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException38 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable20, localizable27, objArray37);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException40 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable41 = notStrictlyPositiveException40.getGeneralPattern();
        java.lang.Object[] objArray44 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException45 = new org.apache.commons.math.MathException(localizable41, objArray44);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException47 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable48 = notStrictlyPositiveException47.getGeneralPattern();
        java.lang.Object[] objArray51 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException52 = new org.apache.commons.math.MathException(localizable48, objArray51);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException55 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable56 = notStrictlyPositiveException55.getGeneralPattern();
        java.lang.Number number57 = notStrictlyPositiveException55.getArgument();
        java.lang.Object[] objArray58 = new java.lang.Object[] { 0, number57 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException59 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable41, localizable48, objArray58);
        org.apache.commons.math.ConvergenceException convergenceException60 = new org.apache.commons.math.ConvergenceException(localizable27, objArray58);
        java.lang.Object[] objArray66 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException67 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray66);
        org.apache.commons.math.exception.util.Localizable localizable68 = maxIterationsExceededException67.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException72 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable68, (java.lang.Number) (short) -1, (java.lang.Number) 1.0d, false);
        java.lang.Object[] objArray78 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException79 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray78);
        java.lang.Object[] objArray80 = maxIterationsExceededException79.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException81 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException72, "", objArray80);
        org.apache.commons.math.MathException mathException82 = new org.apache.commons.math.MathException("", objArray80);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException83 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable13, localizable27, objArray80);
        org.apache.commons.math.ConvergenceException convergenceException84 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3, "1", objArray80);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.0d + "'", number4.equals(0.0d));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (byte) -1 + "'", number5.equals((byte) -1));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(localizable13);
        org.junit.Assert.assertTrue("'" + localizable20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable20.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertTrue("'" + localizable27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable27.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertTrue("'" + localizable35 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable35.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number36 + "' != '" + (-1L) + "'", number36.equals((-1L)));
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertTrue("'" + localizable41 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable41.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertTrue("'" + localizable48 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable48.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray51);
        org.junit.Assert.assertTrue("'" + localizable56 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable56.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number57 + "' != '" + (-1L) + "'", number57.equals((-1L)));
        org.junit.Assert.assertNotNull(objArray58);
        org.junit.Assert.assertNotNull(objArray66);
        org.junit.Assert.assertNotNull(localizable68);
        org.junit.Assert.assertNotNull(objArray78);
        org.junit.Assert.assertNotNull(objArray80);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        double double1 = org.apache.commons.math.util.FastMath.sinh((-0.5578101509651948d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5871908451524052d) + "'", double1 == (-0.5871908451524052d));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        double double1 = org.apache.commons.math.special.Gamma.trigamma((double) 57L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.017698653061426962d + "'", double1 == 0.017698653061426962d);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        double double1 = org.apache.commons.math.util.FastMath.exp((-0.8833654229914927d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.41338933803183986d + "'", double1 == 0.41338933803183986d);
    }

//    @Test
//    public void test187() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test187");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT((double) 10L);
//        double double6 = randomDataImpl1.nextBeta(0.20378364545839303d, (double) 6L);
//        long long8 = randomDataImpl1.nextPoisson(0.07714563080407891d);
//        randomDataImpl1.reSeed((long) (byte) -1);
//        double double12 = randomDataImpl1.nextExponential(18.710508041611977d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-0.01991839767642201d) + "'", double3 == (-0.01991839767642201d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.5388459764145712E-5d + "'", double6 == 2.5388459764145712E-5d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 24.571709218454245d + "'", double12 == 24.571709218454245d);
//    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException("215c4ed0254b86c8c9c6efa912d8c5c0d3864819dcda2588a1e4", objArray1);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 92, (java.lang.Number) (-2260.3728442653687d), false);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        double double1 = org.apache.commons.math.special.Erf.erf(1.3568696570336148E13d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.2511611121136206d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 57L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.54983443527075d + "'", double1 == 7.54983443527075d);
    }

//    @Test
//    public void test193() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test193");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextExponential(0.5772156649015329d);
//        double double6 = randomDataImpl1.nextCauchy(0.19323284172500138d, 11013.232920103343d);
//        java.lang.String str8 = randomDataImpl1.nextSecureHexString(25);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.41460043086451753d + "'", double3 == 0.41460043086451753d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 806536.7897708708d + "'", double6 == 806536.7897708708d);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0dcb0e0a550756fc245dab4fb" + "'", str8.equals("0dcb0e0a550756fc245dab4fb"));
//    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        double double1 = org.apache.commons.math.util.FastMath.expm1(1.2711138659223065d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.564821084469547d + "'", double1 == 2.564821084469547d);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        double double1 = org.apache.commons.math.util.FastMath.expm1(2.524528573772329E-5d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.524560440263087E-5d + "'", double1 == 2.524560440263087E-5d);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException4 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable5 = notStrictlyPositiveException4.getGeneralPattern();
        java.lang.Object[] objArray8 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException(localizable5, objArray8);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException11 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable12 = notStrictlyPositiveException11.getGeneralPattern();
        java.lang.Object[] objArray15 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException(localizable12, objArray15);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException19 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable20 = notStrictlyPositiveException19.getGeneralPattern();
        java.lang.Number number21 = notStrictlyPositiveException19.getArgument();
        java.lang.Object[] objArray22 = new java.lang.Object[] { 0, number21 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException23 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable12, objArray22);
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException(localizable2, objArray22);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException28 = new org.apache.commons.math.exception.OutOfRangeException(localizable2, (java.lang.Number) (-0.9251475365964139d), (java.lang.Number) (-2.563679679041324d), (java.lang.Number) 100.0f);
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertTrue("'" + localizable20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable20.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + (-1L) + "'", number21.equals((-1L)));
        org.junit.Assert.assertNotNull(objArray22);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(1.0000000000000002d, 2.4258259770489514E8d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 6L, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.0d + "'", double2 == 6.0d);
    }

//    @Test
//    public void test199() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test199");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextSecureHexString((int) '4');
//        randomDataImpl1.reSeedSecure();
//        double double7 = randomDataImpl1.nextF(7.105427357601002E-15d, 0.014602538937188877d);
//        double double10 = randomDataImpl1.nextCauchy(0.8491230067936573d, 0.7050434390927751d);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "5b880bce0b9a49286f03fe066934afd3ce5fe93a115276e641e1" + "'", str3.equals("5b880bce0b9a49286f03fe066934afd3ce5fe93a115276e641e1"));
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.4745275595266572E-9d + "'", double7 == 1.4745275595266572E-9d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.988151319953612d + "'", double10 == 0.988151319953612d);
//    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        java.lang.Object[] objArray4 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray4);
        org.apache.commons.math.exception.util.Localizable localizable6 = maxIterationsExceededException5.getGeneralPattern();
        java.lang.Object[] objArray11 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException12 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray11);
        org.apache.commons.math.exception.util.Localizable localizable13 = maxIterationsExceededException12.getGeneralPattern();
        java.lang.Throwable[] throwableArray14 = maxIterationsExceededException12.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, (java.lang.Object[]) throwableArray14);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException17 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable18 = notStrictlyPositiveException17.getGeneralPattern();
        java.lang.Object[] objArray23 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException24 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray23);
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException(localizable18, objArray23);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException26 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, objArray23);
        org.apache.commons.math.exception.util.Localizable localizable28 = null;
        org.apache.commons.math.exception.util.Localizable localizable29 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException31 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable32 = notStrictlyPositiveException31.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException34 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable35 = notStrictlyPositiveException34.getGeneralPattern();
        java.lang.Object[] objArray38 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException(localizable35, objArray38);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException41 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable42 = notStrictlyPositiveException41.getGeneralPattern();
        java.lang.Object[] objArray45 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException46 = new org.apache.commons.math.MathException(localizable42, objArray45);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException49 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable50 = notStrictlyPositiveException49.getGeneralPattern();
        java.lang.Number number51 = notStrictlyPositiveException49.getArgument();
        java.lang.Object[] objArray52 = new java.lang.Object[] { 0, number51 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException53 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable35, localizable42, objArray52);
        org.apache.commons.math.MathException mathException54 = new org.apache.commons.math.MathException(localizable32, objArray52);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException55 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable29, objArray52);
        java.lang.Class<?> wildcardClass56 = objArray52.getClass();
        org.apache.commons.math.MathException mathException57 = new org.apache.commons.math.MathException(localizable28, objArray52);
        org.apache.commons.math.MathException mathException58 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException26, "297b7abebbff2acfd73ac0b441f73ac1563f66b5695f83b12f6e", objArray52);
        org.apache.commons.math.exception.util.Localizable localizable59 = mathException58.getSpecificPattern();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(localizable6);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(localizable13);
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertTrue("'" + localizable18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable18.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertTrue("'" + localizable32 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable32.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable35 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable35.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertTrue("'" + localizable42 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable42.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray45);
        org.junit.Assert.assertTrue("'" + localizable50 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable50.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number51 + "' != '" + (-1L) + "'", number51.equals((-1L)));
        org.junit.Assert.assertNotNull(objArray52);
        org.junit.Assert.assertNotNull(wildcardClass56);
        org.junit.Assert.assertNull(localizable59);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 100);
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException1);
        org.apache.commons.math.exception.util.Localizable localizable3 = maxIterationsExceededException1.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException5 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable3, (java.lang.Number) 0.013621220814443558d);
        org.junit.Assert.assertTrue("'" + localizable3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAX_ITERATIONS_EXCEEDED + "'", localizable3.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAX_ITERATIONS_EXCEEDED));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 7L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999983369439447d + "'", double1 == 0.9999983369439447d);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException2);
        java.lang.String str4 = convergenceException3.getPattern();
        java.lang.Object[] objArray5 = convergenceException3.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException6 = new org.apache.commons.math.MaxIterationsExceededException(19, "3f1954d023d7debc3939d8436833319afb4184c39f76a071e6f3", objArray5);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "{0}" + "'", str4.equals("{0}"));
        org.junit.Assert.assertNotNull(objArray5);
    }

//    @Test
//    public void test204() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test204");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextExponential(0.5772156649015329d);
//        double double6 = randomDataImpl1.nextF((double) (byte) 1, 1.0d);
//        int int9 = randomDataImpl1.nextSecureInt((int) '#', (int) 'a');
//        try {
//            java.lang.String str11 = randomDataImpl1.nextSecureHexString(0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): length (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.1860651677018167d + "'", double3 == 0.1860651677018167d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.52604243402974d + "'", double6 == 4.52604243402974d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 70 + "'", int9 == 70);
//    }

//    @Test
//    public void test205() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test205");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextExponential(0.5772156649015329d);
//        double double6 = randomDataImpl1.nextCauchy(0.19323284172500138d, 11013.232920103343d);
//        long long9 = randomDataImpl1.nextLong((long) (-1), (long) 284);
//        long long11 = randomDataImpl1.nextPoisson((double) (byte) 1);
//        int int14 = randomDataImpl1.nextSecureInt(0, 19);
//        randomDataImpl1.reSeed();
//        double double18 = randomDataImpl1.nextF(5.085984129905464E14d, (double) '4');
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution19 = null;
//        try {
//            int int20 = randomDataImpl1.nextInversionDeviate(integerDistribution19);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.18907076045395993d + "'", double3 == 0.18907076045395993d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 20203.444560643777d + "'", double6 == 20203.444560643777d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 15L + "'", long9 == 15L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.4070465394012217d + "'", double18 == 1.4070465394012217d);
//    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 28L, (float) '4');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 52.0f + "'", float2 == 52.0f);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(1.373400766945016d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1115587674351077d + "'", double1 == 1.1115587674351077d);
    }

//    @Test
//    public void test208() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test208");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull(4.9E-324d, 0.31285066809386347d);
//        long long6 = randomDataImpl0.nextSecureLong((long) (byte) 1, (long) 20);
//        int int9 = randomDataImpl0.nextInt((int) (byte) 1, (int) (short) 100);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + Double.POSITIVE_INFINITY + "'", double3 == Double.POSITIVE_INFINITY);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 17L + "'", long6 == 17L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 71 + "'", int9 == 71);
//    }

//    @Test
//    public void test209() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test209");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT((double) 10L);
//        double double5 = randomDataImpl1.nextExponential((double) 6L);
//        int int8 = randomDataImpl1.nextZipf((int) '4', 0.3550398415388412d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.5896792337362293d + "'", double3 == 0.5896792337362293d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 10.77184266787364d + "'", double5 == 10.77184266787364d);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 15 + "'", int8 == 15);
//    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 17);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 17L + "'", long1 == 17L);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 100);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 100L + "'", long1 == 100L);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(61.377187852187404d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3516.653822311964d + "'", double1 == 3516.653822311964d);
    }

//    @Test
//    public void test214() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test214");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT((double) 10L);
//        randomDataImpl1.reSeed();
//        double double6 = randomDataImpl1.nextChiSquare(0.5848500137377979d);
//        int int9 = randomDataImpl1.nextSecureInt((int) (byte) -1, 20);
//        java.lang.String str11 = randomDataImpl1.nextSecureHexString(4);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.38259332177191024d + "'", double3 == 0.38259332177191024d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.353796204956057d + "'", double6 == 0.353796204956057d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 5 + "'", int9 == 5);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "7ba6" + "'", str11.equals("7ba6"));
//    }

//    @Test
//    public void test215() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test215");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.7241400178893855d, 5729.5779513082325d, (double) 1.0f);
//        double double4 = normalDistributionImpl3.getStandardDeviation();
//        double double5 = normalDistributionImpl3.sample();
//        normalDistributionImpl3.reseedRandomGenerator(8L);
//        double double9 = normalDistributionImpl3.inverseCumulativeProbability(0.0d);
//        try {
//            double[] doubleArray11 = normalDistributionImpl3.sample(0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): number of samples (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 5729.5779513082325d + "'", double4 == 5729.5779513082325d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 11206.221077723887d + "'", double5 == 11206.221077723887d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + Double.NEGATIVE_INFINITY + "'", double9 == Double.NEGATIVE_INFINITY);
//    }

//    @Test
//    public void test216() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test216");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextSecureHexString((int) '4');
//        long long6 = randomDataImpl1.nextSecureLong((long) (-1), (long) '4');
//        int int9 = randomDataImpl1.nextSecureInt(1, (int) (short) 100);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution10 = null;
//        try {
//            int int11 = randomDataImpl1.nextInversionDeviate(integerDistribution10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "467fed1e9d950b24d0b3b82f6bce28dce73ba1cb1f30356fd3bd" + "'", str3.equals("467fed1e9d950b24d0b3b82f6bce28dce73ba1cb1f30356fd3bd"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 34L + "'", long6 == 34L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 73 + "'", int9 == 73);
//    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) Double.NaN, (java.lang.Number) 10.000000000000002d, true);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooLargeException3.getGeneralPattern();
        boolean boolean5 = numberIsTooLargeException3.getBoundIsAllowed();
        java.lang.Object[] objArray6 = numberIsTooLargeException3.getArguments();
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(objArray6);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        int int2 = org.apache.commons.math.util.FastMath.min(32, 9);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9 + "'", int2 == 9);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        double double2 = org.apache.commons.math.util.FastMath.min(1.3135192566529642E-15d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable3 = notStrictlyPositiveException2.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException5 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable3, (java.lang.Number) 10);
        java.lang.Object[] objArray10 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException11 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray10);
        org.apache.commons.math.exception.util.Localizable localizable12 = maxIterationsExceededException11.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException16 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable12, (java.lang.Number) (short) -1, (java.lang.Number) 1.0d, false);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException18 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable19 = notStrictlyPositiveException18.getGeneralPattern();
        java.lang.Object[] objArray22 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException23 = new org.apache.commons.math.MathException(localizable19, objArray22);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException25 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable26 = notStrictlyPositiveException25.getGeneralPattern();
        java.lang.Object[] objArray29 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException30 = new org.apache.commons.math.MathException(localizable26, objArray29);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException33 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable34 = notStrictlyPositiveException33.getGeneralPattern();
        java.lang.Number number35 = notStrictlyPositiveException33.getArgument();
        java.lang.Object[] objArray36 = new java.lang.Object[] { 0, number35 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException37 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable19, localizable26, objArray36);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException39 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable40 = notStrictlyPositiveException39.getGeneralPattern();
        java.lang.Object[] objArray43 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException(localizable40, objArray43);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException46 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable47 = notStrictlyPositiveException46.getGeneralPattern();
        java.lang.Object[] objArray50 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException51 = new org.apache.commons.math.MathException(localizable47, objArray50);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException54 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable55 = notStrictlyPositiveException54.getGeneralPattern();
        java.lang.Number number56 = notStrictlyPositiveException54.getArgument();
        java.lang.Object[] objArray57 = new java.lang.Object[] { 0, number56 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException58 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable40, localizable47, objArray57);
        org.apache.commons.math.ConvergenceException convergenceException59 = new org.apache.commons.math.ConvergenceException(localizable26, objArray57);
        java.lang.Object[] objArray65 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException66 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray65);
        org.apache.commons.math.exception.util.Localizable localizable67 = maxIterationsExceededException66.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException71 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable67, (java.lang.Number) (short) -1, (java.lang.Number) 1.0d, false);
        java.lang.Object[] objArray77 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException78 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray77);
        java.lang.Object[] objArray79 = maxIterationsExceededException78.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException80 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException71, "", objArray79);
        org.apache.commons.math.MathException mathException81 = new org.apache.commons.math.MathException("", objArray79);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException82 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable26, objArray79);
        java.lang.Object[] objArray83 = mathIllegalArgumentException82.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException84 = new org.apache.commons.math.MaxIterationsExceededException((int) ' ', localizable3, objArray83);
        org.apache.commons.math.exception.util.Localizable localizable85 = null;
        java.lang.Object[] objArray86 = null;
        org.apache.commons.math.MathException mathException87 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException84, localizable85, objArray86);
        int int88 = maxIterationsExceededException84.getMaxIterations();
        java.lang.Object[] objArray89 = maxIterationsExceededException84.getArguments();
        org.junit.Assert.assertTrue("'" + localizable3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable3.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(localizable12);
        org.junit.Assert.assertTrue("'" + localizable19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable19.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertTrue("'" + localizable26 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable26.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertTrue("'" + localizable34 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable34.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number35 + "' != '" + (-1L) + "'", number35.equals((-1L)));
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertTrue("'" + localizable40 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable40.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray43);
        org.junit.Assert.assertTrue("'" + localizable47 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable47.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray50);
        org.junit.Assert.assertTrue("'" + localizable55 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable55.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number56 + "' != '" + (-1L) + "'", number56.equals((-1L)));
        org.junit.Assert.assertNotNull(objArray57);
        org.junit.Assert.assertNotNull(objArray65);
        org.junit.Assert.assertNotNull(localizable67);
        org.junit.Assert.assertNotNull(objArray77);
        org.junit.Assert.assertNotNull(objArray79);
        org.junit.Assert.assertNotNull(objArray83);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 32 + "'", int88 == 32);
        org.junit.Assert.assertNotNull(objArray89);
    }

//    @Test
//    public void test221() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test221");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.7241400178893855d, 5729.5779513082325d, (double) 1.0f);
//        double double4 = normalDistributionImpl3.sample();
//        normalDistributionImpl3.reseedRandomGenerator((long) '4');
//        double double7 = normalDistributionImpl3.getMean();
//        normalDistributionImpl3.reseedRandomGenerator((long) 1);
//        double double11 = normalDistributionImpl3.cumulativeProbability((-0.9251475365964139d));
//        double double13 = normalDistributionImpl3.density(0.0d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4396.513056356549d + "'", double4 == 4396.513056356549d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.7241400178893855d + "'", double7 == 0.7241400178893855d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.4998851624788895d + "'", double11 == 0.4998851624788895d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 6.962856262808886E-5d + "'", double13 == 6.962856262808886E-5d);
//    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 20, (java.lang.Number) 3697.517657265949d, number2);
        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        double double1 = org.apache.commons.math.special.Gamma.digamma(7.462494427488261E-4d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1340.6104902941308d) + "'", double1 == (-1340.6104902941308d));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) (short) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9999999999999999d) + "'", double1 == (-0.9999999999999999d));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        java.lang.Object[] objArray4 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray4);
        org.apache.commons.math.exception.util.Localizable localizable6 = maxIterationsExceededException5.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) (short) -1, (java.lang.Number) 1.0d, false);
        java.lang.Object[] objArray16 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException17 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray16);
        java.lang.Object[] objArray18 = maxIterationsExceededException17.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException10, "", objArray18);
        boolean boolean20 = numberIsTooLargeException10.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable21 = numberIsTooLargeException10.getSpecificPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException25 = new org.apache.commons.math.exception.OutOfRangeException(localizable21, (java.lang.Number) 75.6939756606048d, (java.lang.Number) 0.8179912516250313d, (java.lang.Number) 0.014602538937188877d);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException27 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable21, (java.lang.Number) (-3140.0846468601217d));
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(localizable6);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(localizable21);
    }

//    @Test
//    public void test226() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test226");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT((double) 10L);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl7 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.7241400178893855d, 5729.5779513082325d, (double) 1.0f);
//        double double10 = normalDistributionImpl7.cumulativeProbability(1.0000000000000002d, 32.577917486317425d);
//        double double11 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        double double13 = randomDataImpl1.nextT(0.49708625100776777d);
//        double double16 = randomDataImpl1.nextCauchy((double) 0.0f, (double) 7);
//        double double19 = randomDataImpl1.nextGaussian(0.8491230067936573d, 0.7854452872706951d);
//        randomDataImpl1.reSeed((long) 4);
//        double double23 = randomDataImpl1.nextT(2.532590689920738E16d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.7222889907112955d + "'", double3 == 1.7222889907112955d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.002198713597520441d + "'", double10 == 0.002198713597520441d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 3466.3020913261216d + "'", double11 == 3466.3020913261216d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-1.1867058270208286d) + "'", double13 == (-1.1867058270208286d));
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + (-53.006034453474214d) + "'", double16 == (-53.006034453474214d));
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.401020089482079d + "'", double19 == 1.401020089482079d);
//        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
//    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(4.5435938534266416E16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.6032875162292895E18d + "'", double1 == 2.6032875162292895E18d);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.9041801869615227d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9041801869615227d + "'", double1 == 0.9041801869615227d);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.5724612960652946d, 1.0309090578119309d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5724612960652947d + "'", double2 == 0.5724612960652947d);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable3 = notStrictlyPositiveException2.getGeneralPattern();
        java.lang.Object[] objArray6 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException7 = new org.apache.commons.math.MathException(localizable3, objArray6);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException9 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable10 = notStrictlyPositiveException9.getGeneralPattern();
        java.lang.Object[] objArray13 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException(localizable10, objArray13);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException17 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable18 = notStrictlyPositiveException17.getGeneralPattern();
        java.lang.Number number19 = notStrictlyPositiveException17.getArgument();
        java.lang.Object[] objArray20 = new java.lang.Object[] { 0, number19 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException21 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, localizable10, objArray20);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException25 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable3, (java.lang.Number) 2.0d, (java.lang.Number) (-0.5063656411097588d), true);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException28 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable29 = notStrictlyPositiveException28.getGeneralPattern();
        java.lang.Object[] objArray32 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException(localizable29, objArray32);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException35 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable36 = notStrictlyPositiveException35.getGeneralPattern();
        java.lang.Object[] objArray39 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException40 = new org.apache.commons.math.MathException(localizable36, objArray39);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException43 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable44 = notStrictlyPositiveException43.getGeneralPattern();
        java.lang.Number number45 = notStrictlyPositiveException43.getArgument();
        java.lang.Object[] objArray46 = new java.lang.Object[] { 0, number45 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException47 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable29, localizable36, objArray46);
        org.apache.commons.math.ConvergenceException convergenceException48 = new org.apache.commons.math.ConvergenceException("15772cea5a", objArray46);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException49 = new org.apache.commons.math.MaxIterationsExceededException(8, localizable3, objArray46);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException53 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable3, (java.lang.Number) 0.014602538937188877d, (java.lang.Number) 72.93579718355548d, true);
        boolean boolean54 = numberIsTooLargeException53.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + localizable3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable3.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertTrue("'" + localizable10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable10.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertTrue("'" + localizable18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable18.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + (-1L) + "'", number19.equals((-1L)));
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertTrue("'" + localizable29 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable29.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertTrue("'" + localizable36 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable36.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertTrue("'" + localizable44 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable44.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number45 + "' != '" + (-1L) + "'", number45.equals((-1L)));
        org.junit.Assert.assertNotNull(objArray46);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.9826804312789398d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9941931562599201d + "'", double1 == 0.9941931562599201d);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException3 = new org.apache.commons.math.MaxIterationsExceededException(0, "0a9413bf82824a5a7eef9e7859fd80f805dc34e275b134cf0f335342f3b7330b3e2c0817167d7998592ba04445b5e5bc0b99", objArray2);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1.0d, (java.lang.Number) 1.0d, true);
        boolean boolean4 = numberIsTooSmallException3.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException3.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException7 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable8 = notStrictlyPositiveException7.getGeneralPattern();
        java.lang.Object[] objArray11 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException(localizable8, objArray11);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException14 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable15 = notStrictlyPositiveException14.getGeneralPattern();
        java.lang.Object[] objArray18 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException(localizable15, objArray18);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException22 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable23 = notStrictlyPositiveException22.getGeneralPattern();
        java.lang.Number number24 = notStrictlyPositiveException22.getArgument();
        java.lang.Object[] objArray25 = new java.lang.Object[] { 0, number24 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException26 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, localizable15, objArray25);
        java.lang.Object[] objArray31 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException32 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray31);
        org.apache.commons.math.exception.util.Localizable localizable33 = maxIterationsExceededException32.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException37 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable33, (java.lang.Number) (short) -1, (java.lang.Number) 1.0d, false);
        java.lang.Object[] objArray43 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException44 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray43);
        java.lang.Object[] objArray45 = maxIterationsExceededException44.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException37, "", objArray45);
        boolean boolean47 = numberIsTooLargeException37.getBoundIsAllowed();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException50 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable51 = notStrictlyPositiveException50.getGeneralPattern();
        java.lang.Object[] objArray54 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException55 = new org.apache.commons.math.MathException(localizable51, objArray54);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException57 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable58 = notStrictlyPositiveException57.getGeneralPattern();
        java.lang.Object[] objArray61 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException62 = new org.apache.commons.math.MathException(localizable58, objArray61);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException65 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable66 = notStrictlyPositiveException65.getGeneralPattern();
        java.lang.Number number67 = notStrictlyPositiveException65.getArgument();
        java.lang.Object[] objArray68 = new java.lang.Object[] { 0, number67 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException69 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable51, localizable58, objArray68);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException71 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable72 = notStrictlyPositiveException71.getGeneralPattern();
        java.lang.Object[] objArray75 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException76 = new org.apache.commons.math.MathException(localizable72, objArray75);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException78 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable79 = notStrictlyPositiveException78.getGeneralPattern();
        java.lang.Object[] objArray82 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException83 = new org.apache.commons.math.MathException(localizable79, objArray82);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException86 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable87 = notStrictlyPositiveException86.getGeneralPattern();
        java.lang.Number number88 = notStrictlyPositiveException86.getArgument();
        java.lang.Object[] objArray89 = new java.lang.Object[] { 0, number88 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException90 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable72, localizable79, objArray89);
        org.apache.commons.math.ConvergenceException convergenceException91 = new org.apache.commons.math.ConvergenceException(localizable58, objArray89);
        org.apache.commons.math.MathException mathException92 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException37, "05299f0e072343e00952d77e9bba14e42f77765c61bcdb705583", objArray89);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException93 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable15, objArray89);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException94 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, objArray89);
        org.apache.commons.math.exception.util.Localizable localizable95 = mathIllegalArgumentException94.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertTrue("'" + localizable15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable15.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertTrue("'" + localizable23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable23.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + (-1L) + "'", number24.equals((-1L)));
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(localizable33);
        org.junit.Assert.assertNotNull(objArray43);
        org.junit.Assert.assertNotNull(objArray45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + localizable51 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable51.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray54);
        org.junit.Assert.assertTrue("'" + localizable58 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable58.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray61);
        org.junit.Assert.assertTrue("'" + localizable66 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable66.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number67 + "' != '" + (-1L) + "'", number67.equals((-1L)));
        org.junit.Assert.assertNotNull(objArray68);
        org.junit.Assert.assertTrue("'" + localizable72 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable72.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray75);
        org.junit.Assert.assertTrue("'" + localizable79 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable79.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray82);
        org.junit.Assert.assertTrue("'" + localizable87 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable87.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number88 + "' != '" + (-1L) + "'", number88.equals((-1L)));
        org.junit.Assert.assertNotNull(objArray89);
        org.junit.Assert.assertTrue("'" + localizable95 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable95.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.22848769257323895d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.23048098385476554d + "'", double1 == 0.23048098385476554d);
    }

//    @Test
//    public void test235() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test235");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextSecureHexString((int) '4');
//        java.lang.String str5 = randomDataImpl1.nextHexString((int) (short) 100);
//        int int8 = randomDataImpl1.nextSecureInt((int) (byte) 1, (int) '#');
//        java.lang.String str10 = randomDataImpl1.nextHexString((int) (byte) 10);
//        int int13 = randomDataImpl1.nextInt(0, 52);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "6b61cec6bde06f40e406654d338154a1aae0b92425b20898a920" + "'", str3.equals("6b61cec6bde06f40e406654d338154a1aae0b92425b20898a920"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "cd117faa618c4a6f2028d3cee112f5d6f52c480f3d0daab6a36c6f692c25f35a8e52a7347496d1cd0d4282716936b17abc49" + "'", str5.equals("cd117faa618c4a6f2028d3cee112f5d6f52c480f3d0daab6a36c6f692c25f35a8e52a7347496d1cd0d4282716936b17abc49"));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 22 + "'", int8 == 22);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ba7b39c693" + "'", str10.equals("ba7b39c693"));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 8 + "'", int13 == 8);
//    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.8888216151907569d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.4322618215356195d + "'", double1 == 2.4322618215356195d);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        double double1 = org.apache.commons.math.util.FastMath.ulp(1.8115262724608532d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        double double1 = org.apache.commons.math.util.FastMath.log(8.621881058849441d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.154303281153177d + "'", double1 == 2.154303281153177d);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        long long1 = org.apache.commons.math.util.FastMath.round(0.0d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getSpecificPattern();
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException1);
        boolean boolean4 = notStrictlyPositiveException1.getBoundIsAllowed();
        java.lang.Number number6 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.19453209082334608d, number6, false);
        notStrictlyPositiveException1.addSuppressed((java.lang.Throwable) numberIsTooSmallException8);
        org.junit.Assert.assertNull(localizable2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException4 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable2, (java.lang.Number) 10);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException6 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable7 = notStrictlyPositiveException6.getGeneralPattern();
        java.lang.Object[] objArray10 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException(localizable7, objArray10);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException13 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable14 = notStrictlyPositiveException13.getGeneralPattern();
        java.lang.Object[] objArray17 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException(localizable14, objArray17);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException21 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable22 = notStrictlyPositiveException21.getGeneralPattern();
        java.lang.Number number23 = notStrictlyPositiveException21.getArgument();
        java.lang.Object[] objArray24 = new java.lang.Object[] { 0, number23 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException25 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, localizable14, objArray24);
        java.lang.Number number27 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException29 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable14, (java.lang.Number) 5.298342365610589d, number27, false);
        java.lang.Object[] objArray34 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException35 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray34);
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException4, localizable14, objArray34);
        java.lang.Throwable[] throwableArray37 = convergenceException36.getSuppressed();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException39 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 10.000000000000002d);
        convergenceException36.addSuppressed((java.lang.Throwable) notStrictlyPositiveException39);
        java.lang.Number number41 = notStrictlyPositiveException39.getMin();
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertTrue("'" + localizable14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable14.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertTrue("'" + localizable22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable22.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + (-1L) + "'", number23.equals((-1L)));
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(throwableArray37);
        org.junit.Assert.assertTrue("'" + number41 + "' != '" + 0 + "'", number41.equals(0));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 0, Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY);
        double double5 = normalDistributionImpl3.density(0.47441078820588456d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 5);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6989700043360189d + "'", double1 == 0.6989700043360189d);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        double double1 = org.apache.commons.math.util.FastMath.asin(1.0481929396714582d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.022303542527125512d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2778988549948382d + "'", double1 == 1.2778988549948382d);
    }

//    @Test
//    public void test246() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test246");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextExponential(0.5772156649015329d);
//        double double6 = randomDataImpl1.nextF((double) (byte) 1, 1.0d);
//        int int9 = randomDataImpl1.nextSecureInt((int) '#', (int) 'a');
//        double double11 = randomDataImpl1.nextExponential(0.3696394932578302d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.2717122597405943d + "'", double3 == 1.2717122597405943d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.06043989787707446d + "'", double6 == 0.06043989787707446d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 72 + "'", int9 == 72);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.13576936662693737d + "'", double11 == 0.13576936662693737d);
//    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(2.600563355886622d, 2.524528573772329E-5d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.968912538602635E-13d + "'", double2 == 2.968912538602635E-13d);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        long long2 = org.apache.commons.math.util.FastMath.min(14L, 72L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 14L + "'", long2 == 14L);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.7241400178893855d, 5729.5779513082325d, (double) 1.0f);
        double double5 = normalDistributionImpl3.density((-0.8813735870195429d));
        normalDistributionImpl3.reseedRandomGenerator((long) ' ');
        double double8 = normalDistributionImpl3.getStandardDeviation();
        double double10 = normalDistributionImpl3.cumulativeProbability(3.7249556302554714d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 6.962856045056186E-5d + "'", double5 == 6.962856045056186E-5d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 5729.5779513082325d + "'", double8 == 5729.5779513082325d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.5002089424699174d + "'", double10 == 0.5002089424699174d);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0.0d, (java.lang.Number) 0.019416865714155625d, true);
        boolean boolean4 = numberIsTooLargeException3.getBoundIsAllowed();
        java.lang.Number number5 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.019416865714155625d + "'", number5.equals(0.019416865714155625d));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException1 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException0);
        org.apache.commons.math.exception.util.Localizable localizable2 = mathException1.getSpecificPattern();
        org.junit.Assert.assertNull(localizable2);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        int int2 = org.apache.commons.math.util.FastMath.min(17, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17 + "'", int2 == 17);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        double double2 = org.apache.commons.math.util.FastMath.max((-0.999999996707319d), 5.551963231767113d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.551963231767113d + "'", double2 == 5.551963231767113d);
    }

//    @Test
//    public void test255() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test255");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT((double) 10L);
//        randomDataImpl1.reSeed();
//        double double7 = randomDataImpl1.nextUniform((-104.14857733269706d), 2729.302091326176d);
//        long long9 = randomDataImpl1.nextPoisson(2.220446049250313E-16d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.219976371268932d) + "'", double3 == (-1.219976371268932d));
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 250.68969495070098d + "'", double7 == 250.68969495070098d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
//    }

//    @Test
//    public void test256() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test256");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT((double) 10L);
//        randomDataImpl1.reSeed();
//        try {
//            double double7 = randomDataImpl1.nextGaussian(0.21535625129876d, (-2.2567561164357515d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -2.257 is smaller than, or equal to, the minimum (0): standard deviation (-2.257)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.2111334419181026d) + "'", double3 == (-1.2111334419181026d));
//    }

//    @Test
//    public void test257() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test257");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextExponential(0.5772156649015329d);
//        double double6 = randomDataImpl1.nextCauchy(0.19323284172500138d, 11013.232920103343d);
//        long long9 = randomDataImpl1.nextLong((long) (-1), (long) 284);
//        long long11 = randomDataImpl1.nextPoisson((double) (byte) 1);
//        int int14 = randomDataImpl1.nextSecureInt(0, 19);
//        randomDataImpl1.reSeed();
//        double double18 = randomDataImpl1.nextGamma(250.68969495070098d, 0.8778438789091079d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.213005566938829d + "'", double3 == 1.213005566938829d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 12781.275150418365d + "'", double6 == 12781.275150418365d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 117L + "'", long9 == 117L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2L + "'", long11 == 2L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 14 + "'", int14 == 14);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 204.00018674527905d + "'", double18 == 204.00018674527905d);
//    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        double double1 = org.apache.commons.math.util.FastMath.cosh(10.77184266787364d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 23829.87888817307d + "'", double1 == 23829.87888817307d);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 0, Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY);
        double[] doubleArray5 = normalDistributionImpl3.sample(10);
        double double6 = normalDistributionImpl3.getStandardDeviation();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.0d, (java.lang.Number) 1.5199633180839576E-15d, false);
        java.lang.Object[] objArray4 = numberIsTooSmallException3.getArguments();
        org.junit.Assert.assertNotNull(objArray4);
    }

//    @Test
//    public void test262() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test262");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextExponential(0.5772156649015329d);
//        double double6 = randomDataImpl1.nextCauchy(0.19323284172500138d, 11013.232920103343d);
//        long long9 = randomDataImpl1.nextLong((long) (-1), (long) 284);
//        long long11 = randomDataImpl1.nextPoisson((double) (byte) 1);
//        int int14 = randomDataImpl1.nextSecureInt(0, 19);
//        randomDataImpl1.reSeed();
//        randomDataImpl1.reSeedSecure();
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.2198115531480396d + "'", double3 == 1.2198115531480396d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-473.53587691630247d) + "'", double6 == (-473.53587691630247d));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 152L + "'", long9 == 152L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 5 + "'", int14 == 5);
//    }

//    @Test
//    public void test263() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test263");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextSecureHexString((int) '4');
//        double double6 = randomDataImpl1.nextCauchy((-4801.85381129044d), 4.8851119809000325E14d);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution7 = null;
//        try {
//            int int8 = randomDataImpl1.nextInversionDeviate(integerDistribution7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2249078e5521ef442316aa485afd752523c4e4dd8deaa2115e66" + "'", str3.equals("2249078e5521ef442316aa485afd752523c4e4dd8deaa2115e66"));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.2708899445121895E15d) + "'", double6 == (-1.2708899445121895E15d));
//    }

//    @Test
//    public void test264() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test264");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextSecureHexString((int) '4');
//        long long6 = randomDataImpl1.nextSecureLong((long) (-1), (long) '4');
//        randomDataImpl1.reSeed((long) (short) 100);
//        randomDataImpl1.reSeed((long) 2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1ba81a656dffb9179b2b5fb2311573e159920ba5f10cb0dd1f42" + "'", str3.equals("1ba81a656dffb9179b2b5fb2311573e159920ba5f10cb0dd1f42"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 46L + "'", long6 == 46L);
//    }

//    @Test
//    public void test265() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test265");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextSecureHexString((int) '4');
//        long long6 = randomDataImpl1.nextSecureLong((long) (-1), (long) '4');
//        int int9 = randomDataImpl1.nextSecureInt(1, (int) (short) 100);
//        int int12 = randomDataImpl1.nextZipf((int) 'a', 3697.517657265949d);
//        double double15 = randomDataImpl1.nextF(61.377187852187404d, (double) 15);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "c8b4afb4985c00be62b7c719eda3376c32487351644b062e7cdb" + "'", str3.equals("c8b4afb4985c00be62b7c719eda3376c32487351644b062e7cdb"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 31L + "'", long6 == 31L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.7895261781069459d + "'", double15 == 0.7895261781069459d);
//    }

//    @Test
//    public void test266() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test266");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextExponential(0.5772156649015329d);
//        double double6 = randomDataImpl1.nextF((double) (byte) 1, 1.0d);
//        java.lang.String str8 = randomDataImpl1.nextSecureHexString((int) (byte) 1);
//        long long11 = randomDataImpl1.nextSecureLong(0L, (long) 1);
//        double double14 = randomDataImpl1.nextCauchy(1.0E-9d, (double) 52);
//        try {
//            int int17 = randomDataImpl1.nextBinomial(0, 1.028653589997601d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 1.029 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.1494042347214541d + "'", double3 == 1.1494042347214541d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 11.315947632324926d + "'", double6 == 11.315947632324926d);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "8" + "'", str8.equals("8"));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 47.631078239783115d + "'", double14 == 47.631078239783115d);
//    }

//    @Test
//    public void test267() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test267");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.7241400178893855d, 5729.5779513082325d, (double) 1.0f);
//        double double4 = normalDistributionImpl3.sample();
//        normalDistributionImpl3.reseedRandomGenerator((long) '4');
//        double double7 = normalDistributionImpl3.getMean();
//        double double9 = normalDistributionImpl3.cumulativeProbability(0.019416865714155625d);
//        double[] doubleArray11 = normalDistributionImpl3.sample((int) '#');
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 13719.884182788617d + "'", double4 == 13719.884182788617d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.7241400178893855d + "'", double7 == 0.7241400178893855d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.4999509311395951d + "'", double9 == 0.4999509311395951d);
//        org.junit.Assert.assertNotNull(doubleArray11);
//    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 25, (long) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 25L + "'", long2 == 25L);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.36542829151243467d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6045066513384568d + "'", double1 == 0.6045066513384568d);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        double double1 = org.apache.commons.math.util.FastMath.log10(10.77184266787364d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0322900015373468d + "'", double1 == 1.0322900015373468d);
    }

//    @Test
//    public void test271() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test271");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.7241400178893855d, 5729.5779513082325d, (double) 1.0f);
//        double double4 = normalDistributionImpl3.getStandardDeviation();
//        double double5 = normalDistributionImpl3.sample();
//        double[] doubleArray7 = normalDistributionImpl3.sample(20);
//        try {
//            double double9 = normalDistributionImpl3.inverseCumulativeProbability(5652.686218477152d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 5,652.686 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 5729.5779513082325d + "'", double4 == 5729.5779513082325d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-6284.441846478465d) + "'", double5 == (-6284.441846478465d));
//        org.junit.Assert.assertNotNull(doubleArray7);
//    }

//    @Test
//    public void test272() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test272");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT((double) 10L);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl7 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.7241400178893855d, 5729.5779513082325d, (double) 1.0f);
//        double double10 = normalDistributionImpl7.cumulativeProbability(1.0000000000000002d, 32.577917486317425d);
//        double double11 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        int int14 = randomDataImpl1.nextZipf(9, (double) 46);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.19180121652547d) + "'", double3 == (-1.19180121652547d));
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.002198713597520441d + "'", double10 == 0.002198713597520441d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-2283.853811290389d) + "'", double11 == (-2283.853811290389d));
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable3 = notStrictlyPositiveException2.getGeneralPattern();
        java.lang.Object[] objArray6 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException7 = new org.apache.commons.math.MathException(localizable3, objArray6);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException9 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable10 = notStrictlyPositiveException9.getGeneralPattern();
        java.lang.Object[] objArray13 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException(localizable10, objArray13);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException17 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable18 = notStrictlyPositiveException17.getGeneralPattern();
        java.lang.Number number19 = notStrictlyPositiveException17.getArgument();
        java.lang.Object[] objArray20 = new java.lang.Object[] { 0, number19 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException21 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, localizable10, objArray20);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException25 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable3, (java.lang.Number) 2.0d, (java.lang.Number) (-0.5063656411097588d), true);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException28 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable29 = notStrictlyPositiveException28.getGeneralPattern();
        java.lang.Object[] objArray32 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException(localizable29, objArray32);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException35 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable36 = notStrictlyPositiveException35.getGeneralPattern();
        java.lang.Object[] objArray39 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException40 = new org.apache.commons.math.MathException(localizable36, objArray39);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException43 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable44 = notStrictlyPositiveException43.getGeneralPattern();
        java.lang.Number number45 = notStrictlyPositiveException43.getArgument();
        java.lang.Object[] objArray46 = new java.lang.Object[] { 0, number45 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException47 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable29, localizable36, objArray46);
        org.apache.commons.math.ConvergenceException convergenceException48 = new org.apache.commons.math.ConvergenceException("15772cea5a", objArray46);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException49 = new org.apache.commons.math.MaxIterationsExceededException(8, localizable3, objArray46);
        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException49);
        org.junit.Assert.assertTrue("'" + localizable3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable3.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertTrue("'" + localizable10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable10.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertTrue("'" + localizable18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable18.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + (-1L) + "'", number19.equals((-1L)));
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertTrue("'" + localizable29 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable29.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertTrue("'" + localizable36 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable36.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertTrue("'" + localizable44 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable44.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number45 + "' != '" + (-1L) + "'", number45.equals((-1L)));
        org.junit.Assert.assertNotNull(objArray46);
    }

//    @Test
//    public void test275() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test275");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextExponential(0.5772156649015329d);
//        try {
//            int[] intArray6 = randomDataImpl1.nextPermutation(17, 32);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 32 is larger than the maximum (17): permutation size (32) exceeds permuation domain (17)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.506463200111852d + "'", double3 == 1.506463200111852d);
//    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getGeneralPattern();
        java.lang.Number number3 = notStrictlyPositiveException1.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable4 = notStrictlyPositiveException1.getSpecificPattern();
        java.lang.Number number5 = notStrictlyPositiveException1.getMin();
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + (-1L) + "'", number3.equals((-1L)));
        org.junit.Assert.assertNull(localizable4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0 + "'", number5.equals(0));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ((double) (-1), 2.001918421812002d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((-1.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9999999999999999d) + "'", double1 == (-0.9999999999999999d));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, 0.9209616397327581d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((-1.1867058270208286d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test281() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test281");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.7241400178893855d, 5729.5779513082325d, (double) 1.0f);
//        double double4 = normalDistributionImpl3.getStandardDeviation();
//        double double5 = normalDistributionImpl3.sample();
//        normalDistributionImpl3.reseedRandomGenerator(61L);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 5729.5779513082325d + "'", double4 == 5729.5779513082325d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-410.5917262690598d) + "'", double5 == (-410.5917262690598d));
//    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 'a');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3796077390275217d + "'", double1 == 0.3796077390275217d);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        double double1 = org.apache.commons.math.util.FastMath.abs((-1.6107992316908502d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6107992316908502d + "'", double1 == 1.6107992316908502d);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 8, (java.lang.Number) 0.4673384405536164d, true);
    }

//    @Test
//    public void test285() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test285");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextExponential(0.5772156649015329d);
//        double double6 = randomDataImpl1.nextF((double) (byte) 1, 1.0d);
//        java.lang.String str8 = randomDataImpl1.nextSecureHexString((int) (byte) 1);
//        long long11 = randomDataImpl1.nextSecureLong(0L, (long) 1);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl15 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 0, Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY);
//        double[] doubleArray17 = normalDistributionImpl15.sample(10);
//        double double19 = normalDistributionImpl15.density(0.18797288921263233d);
//        double double20 = normalDistributionImpl15.getStandardDeviation();
//        double double21 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl15);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.8115015841752946d + "'", double3 == 1.8115015841752946d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05161508016413996d + "'", double6 == 0.05161508016413996d);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0" + "'", str8.equals("0"));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
//        org.junit.Assert.assertNotNull(doubleArray17);
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + Double.POSITIVE_INFINITY + "'", double20 == Double.POSITIVE_INFINITY);
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
//    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.7050434390927751d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8396686483921947d + "'", double1 == 0.8396686483921947d);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException3 = new org.apache.commons.math.MaxIterationsExceededException(100, "340726b388127493d6e5109e5c0f71fab8b0e44502d739711457", objArray2);
        java.lang.Object[] objArray4 = maxIterationsExceededException3.getArguments();
        int int5 = maxIterationsExceededException3.getMaxIterations();
        int int6 = maxIterationsExceededException3.getMaxIterations();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 100 + "'", int5 == 100);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
    }

//    @Test
//    public void test288() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test288");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT((double) 10L);
//        java.lang.String str5 = randomDataImpl1.nextSecureHexString(20);
//        randomDataImpl1.reSeed();
//        randomDataImpl1.reSeedSecure((long) 44);
//        try {
//            double double10 = randomDataImpl1.nextExponential((-0.25414070878837436d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.254 is smaller than, or equal to, the minimum (0): mean (-0.254)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.9448027899041223d) + "'", double3 == (-1.9448027899041223d));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "be7f305673a215da2b4b" + "'", str5.equals("be7f305673a215da2b4b"));
//    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 50L, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable3 = notStrictlyPositiveException2.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException5 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable3, (java.lang.Number) 10);
        java.lang.Object[] objArray10 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException11 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray10);
        org.apache.commons.math.exception.util.Localizable localizable12 = maxIterationsExceededException11.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException16 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable12, (java.lang.Number) (short) -1, (java.lang.Number) 1.0d, false);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException18 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable19 = notStrictlyPositiveException18.getGeneralPattern();
        java.lang.Object[] objArray22 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException23 = new org.apache.commons.math.MathException(localizable19, objArray22);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException25 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable26 = notStrictlyPositiveException25.getGeneralPattern();
        java.lang.Object[] objArray29 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException30 = new org.apache.commons.math.MathException(localizable26, objArray29);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException33 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable34 = notStrictlyPositiveException33.getGeneralPattern();
        java.lang.Number number35 = notStrictlyPositiveException33.getArgument();
        java.lang.Object[] objArray36 = new java.lang.Object[] { 0, number35 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException37 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable19, localizable26, objArray36);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException39 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable40 = notStrictlyPositiveException39.getGeneralPattern();
        java.lang.Object[] objArray43 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException(localizable40, objArray43);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException46 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable47 = notStrictlyPositiveException46.getGeneralPattern();
        java.lang.Object[] objArray50 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException51 = new org.apache.commons.math.MathException(localizable47, objArray50);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException54 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable55 = notStrictlyPositiveException54.getGeneralPattern();
        java.lang.Number number56 = notStrictlyPositiveException54.getArgument();
        java.lang.Object[] objArray57 = new java.lang.Object[] { 0, number56 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException58 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable40, localizable47, objArray57);
        org.apache.commons.math.ConvergenceException convergenceException59 = new org.apache.commons.math.ConvergenceException(localizable26, objArray57);
        java.lang.Object[] objArray65 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException66 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray65);
        org.apache.commons.math.exception.util.Localizable localizable67 = maxIterationsExceededException66.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException71 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable67, (java.lang.Number) (short) -1, (java.lang.Number) 1.0d, false);
        java.lang.Object[] objArray77 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException78 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray77);
        java.lang.Object[] objArray79 = maxIterationsExceededException78.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException80 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException71, "", objArray79);
        org.apache.commons.math.MathException mathException81 = new org.apache.commons.math.MathException("", objArray79);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException82 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable26, objArray79);
        java.lang.Object[] objArray83 = mathIllegalArgumentException82.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException84 = new org.apache.commons.math.MaxIterationsExceededException((int) ' ', localizable3, objArray83);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException88 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable3, (java.lang.Number) (-2.7947645127697087d), (java.lang.Number) 0.5187754889940697d, true);
        org.junit.Assert.assertTrue("'" + localizable3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable3.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(localizable12);
        org.junit.Assert.assertTrue("'" + localizable19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable19.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertTrue("'" + localizable26 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable26.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertTrue("'" + localizable34 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable34.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number35 + "' != '" + (-1L) + "'", number35.equals((-1L)));
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertTrue("'" + localizable40 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable40.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray43);
        org.junit.Assert.assertTrue("'" + localizable47 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable47.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray50);
        org.junit.Assert.assertTrue("'" + localizable55 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable55.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number56 + "' != '" + (-1L) + "'", number56.equals((-1L)));
        org.junit.Assert.assertNotNull(objArray57);
        org.junit.Assert.assertNotNull(objArray65);
        org.junit.Assert.assertNotNull(localizable67);
        org.junit.Assert.assertNotNull(objArray77);
        org.junit.Assert.assertNotNull(objArray79);
        org.junit.Assert.assertNotNull(objArray83);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        int int2 = org.apache.commons.math.util.FastMath.min(13, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(19);
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException1);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        double double1 = org.apache.commons.math.util.FastMath.ulp(61.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.105427357601002E-15d + "'", double1 == 7.105427357601002E-15d);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        double double1 = org.apache.commons.math.util.FastMath.acosh(1.4704928552226072E-56d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(7.54983443527075d, 1.3723218049989616d, 1.3210166206161171d, 20);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.9998223776173619d + "'", double4 == 0.9998223776173619d);
    }

//    @Test
//    public void test296() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test296");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextExponential(0.5772156649015329d);
//        double double6 = randomDataImpl1.nextF((double) (byte) 1, 1.0d);
//        int int9 = randomDataImpl1.nextSecureInt((int) '#', (int) 'a');
//        double double12 = randomDataImpl1.nextUniform(0.5126247503705206d, (double) 19);
//        randomDataImpl1.reSeedSecure();
//        try {
//            int int16 = randomDataImpl1.nextZipf((int) (byte) 0, (-1.1804612711887845d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): dimension (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.1405144089062167d + "'", double3 == 0.1405144089062167d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 6.800518306133072d + "'", double6 == 6.800518306133072d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 57 + "'", int9 == 57);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 12.655459080777879d + "'", double12 == 12.655459080777879d);
//    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 8L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
    }

//    @Test
//    public void test298() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test298");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.7241400178893855d, 5729.5779513082325d, (double) 1.0f);
//        double double4 = normalDistributionImpl3.sample();
//        double double5 = normalDistributionImpl3.sample();
//        double[] doubleArray7 = normalDistributionImpl3.sample(5);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 7719.961493360139d + "'", double4 == 7719.961493360139d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-2856.852052836902d) + "'", double5 == (-2856.852052836902d));
//        org.junit.Assert.assertNotNull(doubleArray7);
//    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.0034813858640041495d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

//    @Test
//    public void test300() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test300");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextExponential(0.5772156649015329d);
//        double double6 = randomDataImpl1.nextUniform(1.000188513259658d, 7.930067261567154E14d);
//        int int9 = randomDataImpl1.nextSecureInt((int) (short) 1, (int) (byte) 10);
//        double double11 = randomDataImpl1.nextChiSquare(4.641588833612779d);
//        double double14 = randomDataImpl1.nextGamma(1.0263075346092196E-6d, (double) 183L);
//        randomDataImpl1.reSeedSecure();
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.14481778416800764d + "'", double3 == 0.14481778416800764d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 6.243122127738171E14d + "'", double6 == 6.243122127738171E14d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 8 + "'", int9 == 8);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 5.915494023444669d + "'", double11 == 5.915494023444669d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.84179461062253E-9d + "'", double14 == 1.84179461062253E-9d);
//    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 2278.2009115061223d, (java.lang.Number) 0.05161508016413996d, true);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        java.lang.Object[] objArray4 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray4);
        org.apache.commons.math.exception.util.Localizable localizable6 = maxIterationsExceededException5.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) (short) -1, (java.lang.Number) 1.0d, false);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException12 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable13 = notStrictlyPositiveException12.getGeneralPattern();
        java.lang.Object[] objArray16 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException(localizable13, objArray16);
        java.lang.Object[] objArray22 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException23 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray22);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException24 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, localizable13, objArray22);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException28 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) 100, (java.lang.Number) (-0.5063656411097588d), (java.lang.Number) (-10.586871123130669d));
        java.lang.Object[] objArray32 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException33 = new org.apache.commons.math.MaxIterationsExceededException(100, "340726b388127493d6e5109e5c0f71fab8b0e44502d739711457", objArray32);
        java.lang.String str34 = maxIterationsExceededException33.getPattern();
        java.lang.Throwable[] throwableArray35 = maxIterationsExceededException33.getSuppressed();
        org.apache.commons.math.MathException mathException36 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException28, "7b011d94a719a0ab9d143e049f1b3e4f9cc151b4aa12fcbcf88e", (java.lang.Object[]) throwableArray35);
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(localizable6);
        org.junit.Assert.assertTrue("'" + localizable13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable13.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "340726b388127493d6e5109e5c0f71fab8b0e44502d739711457" + "'", str34.equals("340726b388127493d6e5109e5c0f71fab8b0e44502d739711457"));
        org.junit.Assert.assertNotNull(throwableArray35);
    }

//    @Test
//    public void test303() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test303");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextExponential(0.5772156649015329d);
//        double double6 = randomDataImpl1.nextUniform(1.000188513259658d, 7.930067261567154E14d);
//        int int9 = randomDataImpl1.nextSecureInt((int) (short) 1, (int) (byte) 10);
//        double double11 = randomDataImpl1.nextChiSquare(4.641588833612779d);
//        double double13 = randomDataImpl1.nextChiSquare(0.49708625100776777d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.1374882208073337d + "'", double3 == 0.1374882208073337d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 7.67507026736071E14d + "'", double6 == 7.67507026736071E14d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 3.478914809596976d + "'", double11 == 3.478914809596976d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 7.556836906104176E-4d + "'", double13 == 7.556836906104176E-4d);
//    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.03905588746769781d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.816538285997172E-4d + "'", double1 == 6.816538285997172E-4d);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.09480071340362801d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        double double1 = org.apache.commons.math.util.FastMath.asin(1.000188513259658d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.986567241904216d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.16409106893607125d + "'", double1 == 0.16409106893607125d);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        double double1 = org.apache.commons.math.util.FastMath.signum(6.962856274788661E-5d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.7241400178893855d, 5729.5779513082325d, (double) 1.0f);
        double double5 = normalDistributionImpl3.density((-0.8813735870195429d));
        normalDistributionImpl3.reseedRandomGenerator((long) ' ');
        double double8 = normalDistributionImpl3.sample();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 6.962856045056186E-5d + "'", double5 == 6.962856045056186E-5d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 7011.241278176402d + "'", double8 == 7011.241278176402d);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7763568394002505E-15d + "'", double1 == 1.7763568394002505E-15d);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.5188330375900803d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.49799284859409754d + "'", double1 == 0.49799284859409754d);
    }

//    @Test
//    public void test312() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test312");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT((double) 10L);
//        randomDataImpl1.reSeed();
//        double double6 = randomDataImpl1.nextChiSquare(0.5848500137377979d);
//        double double9 = randomDataImpl1.nextWeibull(12104.755054344712d, 0.22848769257323895d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.594699324170785d + "'", double3 == 0.594699324170785d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.5437236289408142d + "'", double6 == 0.5437236289408142d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.2284853250104423d + "'", double9 == 0.2284853250104423d);
//    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 52L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.211102550927978d + "'", double1 == 7.211102550927978d);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 1, 46L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.33647199302181036d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6955307045099575d + "'", double1 == 0.6955307045099575d);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 100, (java.lang.Number) (byte) -1, (java.lang.Number) 0.0d);
        java.lang.Number number4 = outOfRangeException3.getHi();
        java.lang.Object[] objArray5 = outOfRangeException3.getArguments();
        java.lang.Number number6 = outOfRangeException3.getLo();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.0d + "'", number4.equals(0.0d));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (byte) -1 + "'", number6.equals((byte) -1));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        int int1 = org.apache.commons.math.util.FastMath.abs(61);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 61 + "'", int1 == 61);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getGeneralPattern();
        java.lang.Object[] objArray5 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException(localizable2, objArray5);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable9 = notStrictlyPositiveException8.getGeneralPattern();
        java.lang.Object[] objArray12 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException(localizable9, objArray12);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException16 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable17 = notStrictlyPositiveException16.getGeneralPattern();
        java.lang.Number number18 = notStrictlyPositiveException16.getArgument();
        java.lang.Object[] objArray19 = new java.lang.Object[] { 0, number18 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException20 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, localizable9, objArray19);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException22 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 10.0f);
        java.lang.Throwable[] throwableArray23 = notStrictlyPositiveException22.getSuppressed();
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException(localizable9, (java.lang.Object[]) throwableArray23);
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + (-1L) + "'", number18.equals((-1L)));
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(throwableArray23);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException(number0, (java.lang.Number) 1.3440585709080678E43d, false);
    }

//    @Test
//    public void test320() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test320");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT((double) 10L);
//        java.lang.String str5 = randomDataImpl1.nextSecureHexString(20);
//        randomDataImpl1.reSeed();
//        randomDataImpl1.reSeedSecure((long) 44);
//        int[] intArray11 = randomDataImpl1.nextPermutation((int) (byte) 100, 23);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.6754036684699086d + "'", double3 == 0.6754036684699086d);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "227f11bf4e9aaf869e03" + "'", str5.equals("227f11bf4e9aaf869e03"));
//        org.junit.Assert.assertNotNull(intArray11);
//    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.2337897130744893d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3348227287444174d + "'", double1 == 1.3348227287444174d);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(3.1995206040617275E14d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0366188328447316E16d + "'", double1 == 1.0366188328447316E16d);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 8L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999997749296758d + "'", double1 == 0.9999997749296758d);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getGeneralPattern();
        java.lang.Object[] objArray5 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException(localizable2, objArray5);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable9 = notStrictlyPositiveException8.getGeneralPattern();
        java.lang.Object[] objArray12 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException(localizable9, objArray12);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException16 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable17 = notStrictlyPositiveException16.getGeneralPattern();
        java.lang.Number number18 = notStrictlyPositiveException16.getArgument();
        java.lang.Object[] objArray19 = new java.lang.Object[] { 0, number18 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException20 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, localizable9, objArray19);
        java.lang.Number number22 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException24 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable9, (java.lang.Number) 5.298342365610589d, number22, false);
        java.lang.Object[] objArray30 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException31 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray30);
        org.apache.commons.math.MathException mathException32 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException24, "org.apache.commons.math.exception.NotStrictlyPositiveException: -1 is smaller than, or equal to, the minimum (0)", objArray30);
        boolean boolean33 = numberIsTooSmallException24.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable34 = numberIsTooSmallException24.getSpecificPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException36 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable34, (java.lang.Number) 4877.226759918838d);
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + (-1L) + "'", number18.equals((-1L)));
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + localizable34 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable34.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

//    @Test
//    public void test325() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test325");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.7241400178893855d, 5729.5779513082325d, (double) 1.0f);
//        double double4 = normalDistributionImpl3.sample();
//        normalDistributionImpl3.reseedRandomGenerator((long) '4');
//        double double7 = normalDistributionImpl3.getMean();
//        double double9 = normalDistributionImpl3.cumulativeProbability((double) 93L);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-3290.1223937621376d) + "'", double4 == (-3290.1223937621376d));
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.7241400178893855d + "'", double7 == 0.7241400178893855d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.5064247578072077d + "'", double9 == 0.5064247578072077d);
//    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 3.468925545158771E-6d, (java.lang.Number) 0.5721727990760895d, false);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(3.5830478710159466d, 42.72809819051249d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.3188631345446657E-15d + "'", double2 == 1.3188631345446657E-15d);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 100);
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException1);
        int int3 = maxIterationsExceededException1.getMaxIterations();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getGeneralPattern();
        java.lang.Object[] objArray7 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException8 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray7);
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException(localizable2, objArray7);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException11 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable2, (java.lang.Number) 0.8686709614860095d);
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException18 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray17);
        org.apache.commons.math.exception.util.Localizable localizable19 = maxIterationsExceededException18.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException23 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable19, (java.lang.Number) (short) -1, (java.lang.Number) 1.0d, false);
        java.lang.Object[] objArray29 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray29);
        java.lang.Object[] objArray31 = maxIterationsExceededException30.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException23, "", objArray31);
        java.lang.Throwable[] throwableArray33 = convergenceException32.getSuppressed();
        java.lang.Object[] objArray34 = convergenceException32.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException35 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, localizable12, objArray34);
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(localizable19);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(throwableArray33);
        org.junit.Assert.assertNotNull(objArray34);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        java.lang.Object[] objArray4 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray4);
        org.apache.commons.math.exception.util.Localizable localizable6 = maxIterationsExceededException5.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) (short) -1, (java.lang.Number) 1.0d, false);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException12 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable13 = notStrictlyPositiveException12.getGeneralPattern();
        java.lang.Object[] objArray16 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException(localizable13, objArray16);
        java.lang.Object[] objArray22 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException23 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray22);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException24 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, localizable13, objArray22);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException28 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) 100, (java.lang.Number) (-0.5063656411097588d), (java.lang.Number) (-10.586871123130669d));
        java.lang.Number number29 = outOfRangeException28.getLo();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(localizable6);
        org.junit.Assert.assertTrue("'" + localizable13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable13.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertTrue("'" + number29 + "' != '" + (-0.5063656411097588d) + "'", number29.equals((-0.5063656411097588d)));
    }

//    @Test
//    public void test331() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test331");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT((double) 10L);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl7 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.7241400178893855d, 5729.5779513082325d, (double) 1.0f);
//        double double10 = normalDistributionImpl7.cumulativeProbability(1.0000000000000002d, 32.577917486317425d);
//        double double11 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        double double13 = randomDataImpl1.nextT(0.49708625100776777d);
//        double double16 = randomDataImpl1.nextCauchy((double) 0.0f, (double) 7);
//        double double19 = randomDataImpl1.nextGaussian(0.8491230067936573d, 0.7854452872706951d);
//        java.lang.String str21 = randomDataImpl1.nextHexString(5);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.4896642413862153d) + "'", double3 == (-1.4896642413862153d));
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.002198713597520441d + "'", double10 == 0.002198713597520441d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 2068.302091326163d + "'", double11 == 2068.302091326163d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-750.667535186644d) + "'", double13 == (-750.667535186644d));
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + (-1.9461370290560611d) + "'", double16 == (-1.9461370290560611d));
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.19559864324671972d + "'", double19 == 0.19559864324671972d);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "85de6" + "'", str21.equals("85de6"));
//    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        double double1 = org.apache.commons.math.util.FastMath.cosh(100.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3440585709080678E43d + "'", double1 == 1.3440585709080678E43d);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        double double2 = org.apache.commons.math.util.FastMath.atan2((-2260.3728442653687d), 2005.3522829578812d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.8451107285563898d) + "'", double2 == (-0.8451107285563898d));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        double double1 = org.apache.commons.math.util.FastMath.tanh(3.830948999863572d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.999059614934352d + "'", double1 == 0.999059614934352d);
    }

//    @Test
//    public void test335() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test335");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT((double) 10L);
//        double double5 = randomDataImpl1.nextT(6.342124518290157d);
//        try {
//            double double7 = randomDataImpl1.nextExponential((-0.28424013404743426d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.284 is smaller than, or equal to, the minimum (0): mean (-0.284)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.5480596691740405d) + "'", double3 == (-1.5480596691740405d));
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-0.3356607987218524d) + "'", double5 == (-0.3356607987218524d));
//    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        int int2 = org.apache.commons.math.util.FastMath.min(6, 61);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
    }

//    @Test
//    public void test337() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test337");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextExponential(0.5772156649015329d);
//        double double6 = randomDataImpl1.nextUniform(1.000188513259658d, 7.930067261567154E14d);
//        int int9 = randomDataImpl1.nextSecureInt((int) (short) 1, (int) (byte) 10);
//        try {
//            double double11 = randomDataImpl1.nextExponential((-2.9076396405570106d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -2.908 is smaller than, or equal to, the minimum (0): mean (-2.908)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.4729742392451497d + "'", double3 == 1.4729742392451497d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.554892674994802E14d + "'", double6 == 2.554892674994802E14d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
//    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException4 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable2, (java.lang.Number) 10);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException8 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0.0d, (java.lang.Number) 0.019416865714155625d, true);
        org.apache.commons.math.exception.util.Localizable localizable9 = numberIsTooLargeException8.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException13 = new org.apache.commons.math.exception.OutOfRangeException(localizable9, (java.lang.Number) 100L, (java.lang.Number) 11013.232920103343d, (java.lang.Number) 2.1974405382543956d);
        java.lang.Object[] objArray16 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException17 = new org.apache.commons.math.MaxIterationsExceededException(100, "340726b388127493d6e5109e5c0f71fab8b0e44502d739711457", objArray16);
        java.lang.Object[] objArray18 = maxIterationsExceededException17.getArguments();
        int int19 = maxIterationsExceededException17.getMaxIterations();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException22 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable23 = notStrictlyPositiveException22.getGeneralPattern();
        java.lang.Object[] objArray26 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException(localizable23, objArray26);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException29 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable30 = notStrictlyPositiveException29.getGeneralPattern();
        java.lang.Object[] objArray33 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException34 = new org.apache.commons.math.MathException(localizable30, objArray33);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException37 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable38 = notStrictlyPositiveException37.getGeneralPattern();
        java.lang.Number number39 = notStrictlyPositiveException37.getArgument();
        java.lang.Object[] objArray40 = new java.lang.Object[] { 0, number39 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException41 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable23, localizable30, objArray40);
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException17, "a34c55f0739f9aae49d9f5e9d2529ed6155d671dabbf6861d2367d831c61d6ebb9b0eb8a6890f16189205c7299dda5e03249", objArray40);
        org.apache.commons.math.ConvergenceException convergenceException43 = new org.apache.commons.math.ConvergenceException(localizable9, objArray40);
        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException(localizable2, objArray40);
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 100 + "'", int19 == 100);
        org.junit.Assert.assertTrue("'" + localizable23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable23.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertTrue("'" + localizable30 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable30.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertTrue("'" + localizable38 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable38.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number39 + "' != '" + (-1L) + "'", number39.equals((-1L)));
        org.junit.Assert.assertNotNull(objArray40);
    }

//    @Test
//    public void test339() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test339");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT((double) 10L);
//        double double5 = randomDataImpl1.nextExponential((double) 6L);
//        double double8 = randomDataImpl1.nextWeibull(0.09480071340362801d, 0.3369944980913211d);
//        double double10 = randomDataImpl1.nextChiSquare((double) 28L);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-2.344413012062088d) + "'", double3 == (-2.344413012062088d));
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 53.41926918917005d + "'", double5 == 53.41926918917005d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.007347110102269669d + "'", double8 == 0.007347110102269669d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 20.08978547656331d + "'", double10 == 20.08978547656331d);
//    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0.38819289479692876d, (java.lang.Number) 1.5707963267948966d, false);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1);
        org.apache.commons.math.exception.util.Localizable localizable2 = maxIterationsExceededException1.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAX_ITERATIONS_EXCEEDED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAX_ITERATIONS_EXCEEDED));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray6 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException7 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray6);
        org.apache.commons.math.exception.util.Localizable localizable8 = maxIterationsExceededException7.getGeneralPattern();
        java.lang.Object[] objArray13 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException14 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray13);
        org.apache.commons.math.exception.util.Localizable localizable15 = maxIterationsExceededException14.getGeneralPattern();
        java.lang.Throwable[] throwableArray16 = maxIterationsExceededException14.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, (java.lang.Object[]) throwableArray16);
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException("1", (java.lang.Object[]) throwableArray16);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, (java.lang.Object[]) throwableArray16);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(localizable8);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(localizable15);
        org.junit.Assert.assertNotNull(throwableArray16);
    }

//    @Test
//    public void test343() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test343");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT((double) 10L);
//        double double6 = randomDataImpl1.nextBeta(0.20378364545839303d, (double) 6L);
//        try {
//            int int10 = randomDataImpl1.nextHypergeometric((int) (short) 0, 44, 10);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): population size (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-2.0449326824036467d) + "'", double3 == (-2.0449326824036467d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0012904166841125036d + "'", double6 == 0.0012904166841125036d);
//    }

//    @Test
//    public void test344() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test344");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT((double) 10L);
//        randomDataImpl1.reSeed();
//        long long6 = randomDataImpl1.nextPoisson(0.11108711804441163d);
//        double double9 = randomDataImpl1.nextWeibull(0.19453209082334608d, 1.2852543175387054d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-2.1094767872538136d) + "'", double3 == (-2.1094767872538136d));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.219448599186749E-10d + "'", double9 == 1.219448599186749E-10d);
//    }

//    @Test
//    public void test345() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test345");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextExponential(0.5772156649015329d);
//        double double6 = randomDataImpl1.nextF((double) (byte) 1, 1.0d);
//        int int9 = randomDataImpl1.nextSecureInt((int) '#', (int) 'a');
//        double double12 = randomDataImpl1.nextUniform(0.5126247503705206d, (double) 19);
//        randomDataImpl1.reSeedSecure(46L);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0377900033069563d + "'", double3 == 2.0377900033069563d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.4769889153605536d + "'", double6 == 0.4769889153605536d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 40 + "'", int9 == 40);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 11.830230013419913d + "'", double12 == 11.830230013419913d);
//    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getGeneralPattern();
        java.lang.Object[] objArray5 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException(localizable2, objArray5);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable9 = notStrictlyPositiveException8.getGeneralPattern();
        java.lang.Object[] objArray12 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException(localizable9, objArray12);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException16 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable17 = notStrictlyPositiveException16.getGeneralPattern();
        java.lang.Number number18 = notStrictlyPositiveException16.getArgument();
        java.lang.Object[] objArray19 = new java.lang.Object[] { 0, number18 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException20 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, localizable9, objArray19);
        java.lang.Number number22 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException24 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable9, (java.lang.Number) 5.298342365610589d, number22, false);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException28 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable9, (java.lang.Number) (-10.586871123130669d), (java.lang.Number) 3.0747759198632254d, true);
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + (-1L) + "'", number18.equals((-1L)));
        org.junit.Assert.assertNotNull(objArray19);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        double double1 = org.apache.commons.math.special.Erf.erf(10862.302091325904d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException4 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable2, (java.lang.Number) 10);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException6 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable7 = notStrictlyPositiveException6.getGeneralPattern();
        java.lang.Object[] objArray10 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException(localizable7, objArray10);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException13 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable14 = notStrictlyPositiveException13.getGeneralPattern();
        java.lang.Object[] objArray17 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException(localizable14, objArray17);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException21 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable22 = notStrictlyPositiveException21.getGeneralPattern();
        java.lang.Number number23 = notStrictlyPositiveException21.getArgument();
        java.lang.Object[] objArray24 = new java.lang.Object[] { 0, number23 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException25 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, localizable14, objArray24);
        java.lang.Number number27 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException29 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable14, (java.lang.Number) 5.298342365610589d, number27, false);
        java.lang.Object[] objArray34 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException35 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray34);
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException4, localizable14, objArray34);
        java.lang.Throwable[] throwableArray37 = convergenceException36.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException38 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException36);
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertTrue("'" + localizable14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable14.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertTrue("'" + localizable22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable22.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + (-1L) + "'", number23.equals((-1L)));
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(throwableArray37);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        java.lang.Object[] objArray4 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray4);
        java.lang.Object[] objArray6 = maxIterationsExceededException5.getArguments();
        java.lang.String str7 = maxIterationsExceededException5.toString();
        int int8 = maxIterationsExceededException5.getMaxIterations();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.MaxIterationsExceededException: " + "'", str7.equals("org.apache.commons.math.MaxIterationsExceededException: "));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        double double1 = org.apache.commons.math.util.FastMath.cos(16.109096451700278d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9206191201897189d) + "'", double1 == (-0.9206191201897189d));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.9941931562599201d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5451794596098501d + "'", double1 == 0.5451794596098501d);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        double double2 = org.apache.commons.math.util.FastMath.max(0.01763325232887933d, 0.3479747020271566d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.3479747020271566d + "'", double2 == 0.3479747020271566d);
    }

//    @Test
//    public void test354() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test354");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextExponential(0.5772156649015329d);
//        double double6 = randomDataImpl1.nextF((double) (byte) 1, 1.0d);
//        int int9 = randomDataImpl1.nextSecureInt((int) '#', (int) 'a');
//        try {
//            randomDataImpl1.setSecureAlgorithm("96c11804a6b9231b8000", "aab68184b529e425968563fc3dfebdc0b868469b30ebe87d0d76");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: aab68184b529e425968563fc3dfebdc0b868469b30ebe87d0d76");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.017480302992518116d + "'", double3 == 0.017480302992518116d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.22889419478511347d + "'", double6 == 0.22889419478511347d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 58 + "'", int9 == 58);
//    }

//    @Test
//    public void test355() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test355");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT((double) 10L);
//        double double6 = randomDataImpl1.nextBeta(0.20378364545839303d, (double) 6L);
//        double double8 = randomDataImpl1.nextExponential(7.613135436994995E14d);
//        randomDataImpl1.reSeedSecure(28L);
//        try {
//            double double13 = randomDataImpl1.nextF((-7002.853811290343d), 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -7,002.854 is smaller than, or equal to, the minimum (0): degrees of freedom (-7,002.854)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.104295988503153d + "'", double3 == 2.104295988503153d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.024798230563359E-5d + "'", double6 == 1.024798230563359E-5d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 9.643825285601265E14d + "'", double8 == 9.643825285601265E14d);
//    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 97L, 0.6754036684699086d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5638335149006428d + "'", double2 == 1.5638335149006428d);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.7241400178893855d, 5729.5779513082325d, (double) 1.0f);
        double double5 = normalDistributionImpl3.cumulativeProbability((-4.3488532832641695d));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.4996467748115489d + "'", double5 == 0.4996467748115489d);
    }

//    @Test
//    public void test358() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test358");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextExponential(0.5772156649015329d);
//        double double6 = randomDataImpl1.nextUniform(1.000188513259658d, 7.930067261567154E14d);
//        int int9 = randomDataImpl1.nextSecureInt((int) (short) 1, (int) (byte) 10);
//        double double11 = randomDataImpl1.nextChiSquare(4.641588833612779d);
//        double double14 = randomDataImpl1.nextGamma(1.0263075346092196E-6d, (double) 183L);
//        double double17 = randomDataImpl1.nextCauchy(0.18355825835313155d, 1.3213016811096636E45d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.005924569891474116d + "'", double3 == 0.005924569891474116d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.2201508154566814E14d + "'", double6 == 1.2201508154566814E14d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.5073870279794856d + "'", double11 == 1.5073870279794856d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.9E-324d + "'", double14 == 4.9E-324d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0507467327306049E45d + "'", double17 == 1.0507467327306049E45d);
//    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getGeneralPattern();
        java.lang.Object[] objArray5 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException(localizable2, objArray5);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable9 = notStrictlyPositiveException8.getGeneralPattern();
        java.lang.Object[] objArray12 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException(localizable9, objArray12);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException16 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable17 = notStrictlyPositiveException16.getGeneralPattern();
        java.lang.Number number18 = notStrictlyPositiveException16.getArgument();
        java.lang.Object[] objArray19 = new java.lang.Object[] { 0, number18 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException20 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, localizable9, objArray19);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException22 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable23 = notStrictlyPositiveException22.getGeneralPattern();
        java.lang.Object[] objArray26 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException(localizable23, objArray26);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException29 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable30 = notStrictlyPositiveException29.getGeneralPattern();
        java.lang.Object[] objArray33 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException34 = new org.apache.commons.math.MathException(localizable30, objArray33);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException37 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable38 = notStrictlyPositiveException37.getGeneralPattern();
        java.lang.Number number39 = notStrictlyPositiveException37.getArgument();
        java.lang.Object[] objArray40 = new java.lang.Object[] { 0, number39 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException41 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable23, localizable30, objArray40);
        java.lang.Number number43 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException45 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable30, (java.lang.Number) 5.298342365610589d, number43, false);
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl50 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.7241400178893855d, 5729.5779513082325d, (double) 1.0f);
        double double52 = normalDistributionImpl50.density((-0.8813735870195429d));
        normalDistributionImpl50.reseedRandomGenerator((long) ' ');
        double double55 = normalDistributionImpl50.getStandardDeviation();
        java.lang.Object[] objArray57 = new java.lang.Object[] { 0.9999994948902197d, normalDistributionImpl50, "98fb2814226fd7ea893b3674ff008a58b86644b3fa279321290b" };
        org.apache.commons.math.ConvergenceException convergenceException58 = new org.apache.commons.math.ConvergenceException(localizable30, objArray57);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException60 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 10.0f);
        java.lang.Throwable[] throwableArray61 = notStrictlyPositiveException60.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException62 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, localizable30, (java.lang.Object[]) throwableArray61);
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + (-1L) + "'", number18.equals((-1L)));
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertTrue("'" + localizable23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable23.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertTrue("'" + localizable30 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable30.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertTrue("'" + localizable38 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable38.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number39 + "' != '" + (-1L) + "'", number39.equals((-1L)));
        org.junit.Assert.assertNotNull(objArray40);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 6.962856045056186E-5d + "'", double52 == 6.962856045056186E-5d);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 5729.5779513082325d + "'", double55 == 5729.5779513082325d);
        org.junit.Assert.assertNotNull(objArray57);
        org.junit.Assert.assertNotNull(throwableArray61);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable3 = notStrictlyPositiveException1.getSpecificPattern();
        java.lang.String str4 = notStrictlyPositiveException1.toString();
        java.lang.Object[] objArray5 = notStrictlyPositiveException1.getArguments();
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNull(localizable3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: -1 is smaller than, or equal to, the minimum (0)" + "'", str4.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: -1 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertNotNull(objArray5);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException4 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable2, (java.lang.Number) 10);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException8 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable2, (java.lang.Number) 0.22810373611241697d, (java.lang.Number) 5.208311099775715d, true);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException12 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable13 = notStrictlyPositiveException12.getGeneralPattern();
        java.lang.Object[] objArray16 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException(localizable13, objArray16);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException19 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable20 = notStrictlyPositiveException19.getGeneralPattern();
        java.lang.Object[] objArray23 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException(localizable20, objArray23);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException27 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable28 = notStrictlyPositiveException27.getGeneralPattern();
        java.lang.Number number29 = notStrictlyPositiveException27.getArgument();
        java.lang.Object[] objArray30 = new java.lang.Object[] { 0, number29 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException31 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable13, localizable20, objArray30);
        java.lang.Number number33 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException35 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable20, (java.lang.Number) 5.298342365610589d, number33, false);
        java.lang.Object[] objArray41 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException42 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray41);
        org.apache.commons.math.MathException mathException43 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException35, "org.apache.commons.math.exception.NotStrictlyPositiveException: -1 is smaller than, or equal to, the minimum (0)", objArray41);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException44 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "96c11804a6b9231b8000", objArray41);
        org.apache.commons.math.MathException mathException45 = new org.apache.commons.math.MathException(localizable2, objArray41);
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable13.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertTrue("'" + localizable20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable20.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertTrue("'" + localizable28 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable28.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number29 + "' != '" + (-1L) + "'", number29.equals((-1L)));
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertNotNull(objArray41);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.ConvergenceException convergenceException1 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException0);
        java.lang.String str2 = convergenceException1.getPattern();
        java.lang.Object[] objArray3 = convergenceException1.getArguments();
        java.lang.Object[] objArray5 = null;
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException1, "15772cea5a", objArray5);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{0}" + "'", str2.equals("{0}"));
        org.junit.Assert.assertNotNull(objArray3);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getGeneralPattern();
        java.lang.Object[] objArray5 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException(localizable2, objArray5);
        java.lang.Object[] objArray11 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException12 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray11);
        org.apache.commons.math.exception.util.Localizable localizable13 = maxIterationsExceededException12.getGeneralPattern();
        java.lang.Throwable[] throwableArray14 = maxIterationsExceededException12.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable15 = maxIterationsExceededException12.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException18 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable19 = notStrictlyPositiveException18.getGeneralPattern();
        java.lang.Object[] objArray22 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException23 = new org.apache.commons.math.MathException(localizable19, objArray22);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException25 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable26 = notStrictlyPositiveException25.getGeneralPattern();
        java.lang.Object[] objArray29 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException30 = new org.apache.commons.math.MathException(localizable26, objArray29);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException33 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable34 = notStrictlyPositiveException33.getGeneralPattern();
        java.lang.Number number35 = notStrictlyPositiveException33.getArgument();
        java.lang.Object[] objArray36 = new java.lang.Object[] { 0, number35 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException37 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable19, localizable26, objArray36);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException39 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable40 = notStrictlyPositiveException39.getGeneralPattern();
        java.lang.Object[] objArray43 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException(localizable40, objArray43);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException46 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable47 = notStrictlyPositiveException46.getGeneralPattern();
        java.lang.Object[] objArray50 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException51 = new org.apache.commons.math.MathException(localizable47, objArray50);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException54 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable55 = notStrictlyPositiveException54.getGeneralPattern();
        java.lang.Number number56 = notStrictlyPositiveException54.getArgument();
        java.lang.Object[] objArray57 = new java.lang.Object[] { 0, number56 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException58 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable40, localizable47, objArray57);
        org.apache.commons.math.ConvergenceException convergenceException59 = new org.apache.commons.math.ConvergenceException(localizable26, objArray57);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException61 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable62 = notStrictlyPositiveException61.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException64 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable62, (java.lang.Number) 10);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException66 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable67 = notStrictlyPositiveException66.getGeneralPattern();
        java.lang.Object[] objArray70 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException71 = new org.apache.commons.math.MathException(localizable67, objArray70);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException73 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable74 = notStrictlyPositiveException73.getGeneralPattern();
        java.lang.Object[] objArray77 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException78 = new org.apache.commons.math.MathException(localizable74, objArray77);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException81 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable82 = notStrictlyPositiveException81.getGeneralPattern();
        java.lang.Number number83 = notStrictlyPositiveException81.getArgument();
        java.lang.Object[] objArray84 = new java.lang.Object[] { 0, number83 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException85 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable67, localizable74, objArray84);
        java.lang.Number number87 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException89 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable74, (java.lang.Number) 5.298342365610589d, number87, false);
        java.lang.Object[] objArray94 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException95 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray94);
        org.apache.commons.math.ConvergenceException convergenceException96 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException64, localizable74, objArray94);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException97 = new org.apache.commons.math.MaxIterationsExceededException(284, localizable26, objArray94);
        org.apache.commons.math.ConvergenceException convergenceException98 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException6, localizable15, objArray94);
        org.apache.commons.math.ConvergenceException convergenceException99 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException6);
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(localizable13);
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertNotNull(localizable15);
        org.junit.Assert.assertTrue("'" + localizable19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable19.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertTrue("'" + localizable26 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable26.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertTrue("'" + localizable34 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable34.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number35 + "' != '" + (-1L) + "'", number35.equals((-1L)));
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertTrue("'" + localizable40 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable40.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray43);
        org.junit.Assert.assertTrue("'" + localizable47 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable47.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray50);
        org.junit.Assert.assertTrue("'" + localizable55 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable55.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number56 + "' != '" + (-1L) + "'", number56.equals((-1L)));
        org.junit.Assert.assertNotNull(objArray57);
        org.junit.Assert.assertTrue("'" + localizable62 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable62.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable67 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable67.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray70);
        org.junit.Assert.assertTrue("'" + localizable74 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable74.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray77);
        org.junit.Assert.assertTrue("'" + localizable82 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable82.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number83 + "' != '" + (-1L) + "'", number83.equals((-1L)));
        org.junit.Assert.assertNotNull(objArray84);
        org.junit.Assert.assertNotNull(objArray94);
    }

//    @Test
//    public void test364() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test364");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextExponential(0.5772156649015329d);
//        double double6 = randomDataImpl1.nextF((double) (byte) 1, 1.0d);
//        randomDataImpl1.reSeedSecure();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl11 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.7241400178893855d, 5729.5779513082325d, (double) 1.0f);
//        double double13 = normalDistributionImpl11.density((-0.8813735870195429d));
//        normalDistributionImpl11.reseedRandomGenerator((long) ' ');
//        double double16 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl11);
//        double double19 = randomDataImpl1.nextCauchy((double) (byte) -1, 0.22110618141455785d);
//        double double21 = randomDataImpl1.nextExponential(2729.302091326176d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.3439079891548433d + "'", double3 == 1.3439079891548433d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.4069526015411893d + "'", double6 == 0.4069526015411893d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 6.962856045056186E-5d + "'", double13 == 6.962856045056186E-5d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1688.3020913261216d + "'", double16 == 1688.3020913261216d);
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-1.4013613691324849d) + "'", double19 == (-1.4013613691324849d));
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 894.0075466831381d + "'", double21 == 894.0075466831381d);
//    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        double double2 = org.apache.commons.math.util.FastMath.max(0.8396686483921947d, 1.2729698034198502d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.2729698034198502d + "'", double2 == 1.2729698034198502d);
    }

//    @Test
//    public void test366() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test366");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.7241400178893855d, 5729.5779513082325d, (double) 1.0f);
//        double double4 = normalDistributionImpl3.sample();
//        normalDistributionImpl3.reseedRandomGenerator((long) '4');
//        double double7 = normalDistributionImpl3.getMean();
//        normalDistributionImpl3.reseedRandomGenerator((long) 1);
//        double double11 = normalDistributionImpl3.cumulativeProbability((-0.9251475365964139d));
//        normalDistributionImpl3.reseedRandomGenerator((long) 100);
//        double double16 = normalDistributionImpl3.cumulativeProbability(1.4322219803232506E-9d, (double) 50L);
//        double double18 = normalDistributionImpl3.density(0.2614783751513923d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-5052.700243598763d) + "'", double4 == (-5052.700243598763d));
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.7241400178893855d + "'", double7 == 0.7241400178893855d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.4998851624788895d + "'", double11 == 0.4998851624788895d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0034813858640041495d + "'", double16 == 0.0034813858640041495d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 6.96285629571875E-5d + "'", double18 == 6.96285629571875E-5d);
//    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 0, Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY);
        double double5 = normalDistributionImpl3.cumulativeProbability(6.342124518290157d);
        double double6 = normalDistributionImpl3.getStandardDeviation();
        double double8 = normalDistributionImpl3.density(0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.5d + "'", double5 == 0.5d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(10888.302091325902d, 0.1469366995820881d, 10888.302091325902d, 6);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.6955307045099575d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7529815382045247d + "'", double1 == 0.7529815382045247d);
    }

//    @Test
//    public void test370() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test370");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextExponential(0.5772156649015329d);
//        double double6 = randomDataImpl1.nextF((double) (byte) 1, 1.0d);
//        int int9 = randomDataImpl1.nextSecureInt((int) '#', (int) 'a');
//        double double12 = randomDataImpl1.nextUniform(0.5126247503705206d, (double) 19);
//        randomDataImpl1.reSeed();
//        randomDataImpl1.reSeed((long) (byte) 0);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.2519068075192272d + "'", double3 == 1.2519068075192272d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.9224319361848893d + "'", double6 == 0.9224319361848893d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 57 + "'", int9 == 57);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 7.9062295986952975d + "'", double12 == 7.9062295986952975d);
//    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        long long1 = org.apache.commons.math.util.FastMath.round(0.41338933803183986d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException4 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable2, (java.lang.Number) 10);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException6 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable7 = notStrictlyPositiveException6.getSpecificPattern();
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException6);
        boolean boolean9 = notStrictlyPositiveException6.getBoundIsAllowed();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException12 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable13 = notStrictlyPositiveException12.getSpecificPattern();
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException12);
        java.lang.Object[] objArray19 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException20 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray19);
        org.apache.commons.math.exception.util.Localizable localizable21 = maxIterationsExceededException20.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException25 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable21, (java.lang.Number) (short) -1, (java.lang.Number) 1.0d, false);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException27 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable28 = notStrictlyPositiveException27.getGeneralPattern();
        java.lang.Object[] objArray31 = new java.lang.Object[] { (-1), (-1.0f) };
        org.apache.commons.math.MathException mathException32 = new org.apache.commons.math.MathException(localizable28, objArray31);
        java.lang.Object[] objArray37 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException38 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray37);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException39 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable21, localizable28, objArray37);
        java.lang.Object[] objArray44 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException45 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray44);
        org.apache.commons.math.exception.util.Localizable localizable46 = maxIterationsExceededException45.getGeneralPattern();
        java.lang.Object[] objArray51 = new java.lang.Object[] { (byte) 100, 100L };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException52 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray51);
        org.apache.commons.math.exception.util.Localizable localizable53 = maxIterationsExceededException52.getGeneralPattern();
        java.lang.Throwable[] throwableArray54 = maxIterationsExceededException52.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException55 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable46, (java.lang.Object[]) throwableArray54);
        org.apache.commons.math.ConvergenceException convergenceException56 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException12, localizable21, (java.lang.Object[]) throwableArray54);
        org.apache.commons.math.exception.util.Localizable localizable57 = notStrictlyPositiveException12.getSpecificPattern();
        java.lang.Throwable[] throwableArray58 = notStrictlyPositiveException12.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException59 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException6, "3f1954d023d7debc3939d8436833319afb4184c39f76a071e6f3", (java.lang.Object[]) throwableArray58);
        org.apache.commons.math.MathException mathException60 = new org.apache.commons.math.MathException(localizable2, (java.lang.Object[]) throwableArray58);
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNull(localizable7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(localizable13);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(localizable21);
        org.junit.Assert.assertTrue("'" + localizable28 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable28.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertNotNull(localizable46);
        org.junit.Assert.assertNotNull(objArray51);
        org.junit.Assert.assertNotNull(localizable53);
        org.junit.Assert.assertNotNull(throwableArray54);
        org.junit.Assert.assertNull(localizable57);
        org.junit.Assert.assertNotNull(throwableArray58);
    }
}

