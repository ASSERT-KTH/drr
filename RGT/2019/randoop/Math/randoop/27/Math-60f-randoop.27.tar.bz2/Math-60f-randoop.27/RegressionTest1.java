import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.37468860172840396d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test002() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test002");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) 'a');
//        int int5 = randomDataImpl0.nextSecureInt(8, (int) 'a');
//        org.apache.commons.math.distribution.ContinuousDistribution continuousDistribution6 = null;
//        try {
//            double double7 = randomDataImpl0.nextInversionDeviate(continuousDistribution6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 97L + "'", long2 == 97L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 30 + "'", int5 == 30);
//    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (-1.0d), (java.lang.Number) (byte) -1, (java.lang.Number) 4.9E-324d);
        java.lang.Number number4 = outOfRangeException3.getArgument();
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3);
        java.lang.Object[] objArray6 = mathException5.getArguments();
        java.lang.String str7 = mathException5.getPattern();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-1.0d) + "'", number4.equals((-1.0d)));
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "{0}" + "'", str7.equals("{0}"));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, localizable3, objArray7);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray7);
        java.lang.Object[] objArray10 = maxIterationsExceededException9.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable11 = maxIterationsExceededException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable13, objArray17);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, objArray17);
        java.lang.Object[] objArray23 = new java.lang.Object[] { (-1L), 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException("", objArray23);
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException(localizable11, objArray23);
        org.apache.commons.math.exception.util.Localizable localizable28 = null;
        org.apache.commons.math.exception.util.Localizable localizable29 = null;
        java.lang.Object[] objArray33 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException34 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable28, localizable29, objArray33);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException35 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray33);
        java.lang.Object[] objArray36 = maxIterationsExceededException35.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable37 = maxIterationsExceededException35.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException41 = new org.apache.commons.math.exception.OutOfRangeException(localizable37, (java.lang.Number) 10L, (java.lang.Number) 97L, (java.lang.Number) 10);
        java.lang.Object[] objArray42 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException43 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable37, objArray42);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException47 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable11, (java.lang.Number) (-0.3562132405380027d), (java.lang.Number) 1.0d, false);
        java.lang.Object[] objArray51 = new java.lang.Object[] { (-1L), 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException52 = new org.apache.commons.math.ConvergenceException("", objArray51);
        org.apache.commons.math.MathException mathException53 = new org.apache.commons.math.MathException(localizable11, objArray51);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(localizable11);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertNotNull(localizable37);
        org.junit.Assert.assertNotNull(objArray51);
    }

//    @Test
//    public void test005() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test005");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGamma((double) (short) 1, 2.722936728502507d);
//        randomDataImpl0.reSeed();
//        double double6 = randomDataImpl0.nextExponential(1.8190200166118848d);
//        double double8 = randomDataImpl0.nextExponential(108.8399875855036d);
//        try {
//            int[] intArray11 = randomDataImpl0.nextPermutation(0, (int) (byte) 1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 1 is larger than the maximum (0): permutation size (1) exceeds permuation domain (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 6.373556225080807d + "'", double3 == 6.373556225080807d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.18411152818151058d + "'", double6 == 0.18411152818151058d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 19.183785620605583d + "'", double8 == 19.183785620605583d);
//    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        double double1 = org.apache.commons.math.util.FastMath.acos(Double.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, localizable3, objArray7);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray7);
        java.lang.Object[] objArray10 = maxIterationsExceededException9.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable11 = maxIterationsExceededException9.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException15 = new org.apache.commons.math.exception.OutOfRangeException(localizable11, (java.lang.Number) 10L, (java.lang.Number) 97L, (java.lang.Number) 10);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException19 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable11, (java.lang.Number) 0.10143992966509834d, (java.lang.Number) (-1.362665681324511d), true);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException23 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable11, (java.lang.Number) 100, (java.lang.Number) 104.2221698016779d, true);
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        java.lang.Object[] objArray29 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException30 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable24, localizable25, objArray29);
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException(localizable11, objArray29);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException35 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable11, (java.lang.Number) 3, (java.lang.Number) 62.13648399124318d, false);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(localizable11);
        org.junit.Assert.assertNotNull(objArray29);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        double double1 = org.apache.commons.math.special.Gamma.digamma(8.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.015641475065075d + "'", double1 == 2.015641475065075d);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (-1.0d), (java.lang.Number) (byte) -1, (java.lang.Number) 4.9E-324d);
        java.lang.String str5 = outOfRangeException4.toString();
        org.apache.commons.math.exception.util.Localizable localizable6 = outOfRangeException4.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable9, localizable10, objArray14);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException16 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray14);
        java.lang.Object[] objArray17 = maxIterationsExceededException16.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable18 = maxIterationsExceededException16.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException22 = new org.apache.commons.math.exception.OutOfRangeException(localizable18, (java.lang.Number) 10L, (java.lang.Number) 97L, (java.lang.Number) 10);
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        java.lang.Object[] objArray30 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException31 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable25, localizable26, objArray30);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException32 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray30);
        java.lang.Object[] objArray33 = maxIterationsExceededException32.getArguments();
        org.apache.commons.math.MathException mathException34 = new org.apache.commons.math.MathException(localizable18, objArray33);
        org.apache.commons.math.exception.util.Localizable localizable36 = null;
        org.apache.commons.math.exception.util.Localizable localizable37 = null;
        java.lang.Object[] objArray41 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException42 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable36, localizable37, objArray41);
        org.apache.commons.math.ConvergenceException convergenceException43 = new org.apache.commons.math.ConvergenceException("", objArray41);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException44 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable18, objArray41);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException48 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (-1.0d), (java.lang.Number) (byte) -1, (java.lang.Number) 4.9E-324d);
        java.lang.Number number49 = outOfRangeException48.getArgument();
        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException48);
        java.lang.Throwable[] throwableArray51 = mathException50.getSuppressed();
        org.apache.commons.math.MathException mathException52 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException4, localizable18, (java.lang.Object[]) throwableArray51);
        org.apache.commons.math.exception.util.Localizable localizable55 = null;
        org.apache.commons.math.exception.util.Localizable localizable56 = null;
        java.lang.Object[] objArray60 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException61 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable55, localizable56, objArray60);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException62 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray60);
        java.lang.Object[] objArray63 = maxIterationsExceededException62.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable64 = maxIterationsExceededException62.getGeneralPattern();
        java.lang.Object[] objArray65 = maxIterationsExceededException62.getArguments();
        org.apache.commons.math.MathException mathException66 = new org.apache.commons.math.MathException(localizable18, objArray65);
        org.apache.commons.math.ConvergenceException convergenceException67 = new org.apache.commons.math.ConvergenceException("24945e41", objArray65);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.OutOfRangeException: -1 out of [-1, 0] range" + "'", str5.equals("org.apache.commons.math.exception.OutOfRangeException: -1 out of [-1, 0] range"));
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(localizable18);
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertNotNull(objArray41);
        org.junit.Assert.assertTrue("'" + number49 + "' != '" + (-1.0d) + "'", number49.equals((-1.0d)));
        org.junit.Assert.assertNotNull(throwableArray51);
        org.junit.Assert.assertNotNull(objArray60);
        org.junit.Assert.assertNotNull(objArray63);
        org.junit.Assert.assertNotNull(localizable64);
        org.junit.Assert.assertNotNull(objArray65);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        long long2 = org.apache.commons.math.util.FastMath.min(8L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        long long2 = org.apache.commons.math.util.FastMath.min(10L, 8L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 8L + "'", long2 == 8L);
    }

//    @Test
//    public void test012() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test012");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextWeibull(Double.POSITIVE_INFINITY, (double) 52L);
//        java.lang.String str6 = randomDataImpl0.nextSecureHexString(32);
//        try {
//            java.lang.String str8 = randomDataImpl0.nextSecureHexString((-1));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): length (-1)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 52.0d + "'", double4 == 52.0d);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "988397b72e61c2be79a7a678badfa438" + "'", str6.equals("988397b72e61c2be79a7a678badfa438"));
//    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.9206068701998329d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(100.364233162726d, (double) (short) 10, (double) 137291920L, (int) 'a');
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

//    @Test
//    public void test015() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test015");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextWeibull(Double.POSITIVE_INFINITY, (double) 52L);
//        int int7 = randomDataImpl0.nextPascal((int) (byte) 10, 0.0d);
//        double double10 = randomDataImpl0.nextGaussian(0.21068150841353378d, 0.5809401805942233d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl11 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double13 = normalDistributionImpl11.density(57.9674416413573d);
//        double double14 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl11);
//        try {
//            randomDataImpl0.setSecureAlgorithm("hi!", "");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: missing provider");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 52.0d + "'", double4 == 52.0d);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2147483647 + "'", int7 == 2147483647);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.5143122818730748d + "'", double10 == 0.5143122818730748d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-0.8268319059631867d) + "'", double14 == (-0.8268319059631867d));
//    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        double double1 = org.apache.commons.math.util.FastMath.ulp((-20.72326583694641d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.552713678800501E-15d + "'", double1 == 3.552713678800501E-15d);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number0);
        boolean boolean2 = notStrictlyPositiveException1.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable3 = notStrictlyPositiveException1.getGeneralPattern();
        java.lang.Number number4 = notStrictlyPositiveException1.getMin();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + localizable3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable3.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0 + "'", number4.equals(0));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        double double2 = org.apache.commons.math.util.FastMath.min(99.07256892495049d, (double) 52L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 52.0d + "'", double2 == 52.0d);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeed();
        double double4 = randomDataImpl0.nextWeibull(Double.POSITIVE_INFINITY, (double) 52L);
        int int7 = randomDataImpl0.nextPascal((int) (byte) 10, 0.0d);
        try {
            int int10 = randomDataImpl0.nextPascal(85, (double) 96L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 96 out of [0, 1] range");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 52.0d + "'", double4 == 52.0d);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2147483647 + "'", int7 == 2147483647);
    }

//    @Test
//    public void test020() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test020");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        int int4 = randomDataImpl0.nextSecureInt((int) (byte) 0, (int) (short) 10);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution5 = null;
//        try {
//            int int6 = randomDataImpl0.nextInversionDeviate(integerDistribution5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 9 + "'", int4 == 9);
//    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.36399733513383165d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.38097342691654756d + "'", double1 == 0.38097342691654756d);
    }

//    @Test
//    public void test022() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test022");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy(485.1720550638632d, 2.718281828459045d);
//        try {
//            int int7 = randomDataImpl1.nextBinomial((int) (short) 100, 57.967441641357304d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 57.967 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 484.5429866718624d + "'", double4 == 484.5429866718624d);
//    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.0d, 0.5000000000000001d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        double double1 = org.apache.commons.math.util.FastMath.log10(6.798157121994732E43d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 43.83239119796795d + "'", double1 == 43.83239119796795d);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        double double1 = org.apache.commons.math.special.Gamma.logGamma((-1.0038848218538872d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, localizable3, objArray7);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray7);
        java.lang.Object[] objArray10 = maxIterationsExceededException9.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable11 = maxIterationsExceededException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable13, objArray17);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, objArray17);
        java.lang.Object[] objArray23 = new java.lang.Object[] { (-1L), 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException("", objArray23);
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException(localizable11, objArray23);
        java.lang.Throwable[] throwableArray26 = mathException25.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable27 = mathException25.getGeneralPattern();
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(localizable11);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNotNull(throwableArray26);
        org.junit.Assert.assertNotNull(localizable27);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeed();
        double double4 = randomDataImpl0.nextWeibull(Double.POSITIVE_INFINITY, (double) 52L);
        long long7 = randomDataImpl0.nextSecureLong(0L, (long) 2);
        randomDataImpl0.reSeed();
        try {
            double double11 = randomDataImpl0.nextUniform(100.1711455688407d, 0.10143992966509834d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100.171 is larger than, or equal to, the maximum (0.101): lower bound (100.171) must be strictly less than upper bound (0.101)");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 52.0d + "'", double4 == 52.0d);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 1.832792237721146E45d, (java.lang.Number) 0.36399733513383165d, false);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        double double1 = org.apache.commons.math.util.FastMath.tanh(492.5966152977087d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

//    @Test
//    public void test031() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test031");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextWeibull(Double.POSITIVE_INFINITY, (double) 52L);
//        double double6 = randomDataImpl0.nextChiSquare((double) 91L);
//        double double9 = randomDataImpl0.nextUniform(0.5809401805942233d, (double) 'a');
//        int int12 = randomDataImpl0.nextSecureInt(0, (int) (byte) 10);
//        double double15 = randomDataImpl0.nextUniform((double) 10, (double) 100L);
//        double double18 = randomDataImpl0.nextUniform(0.0d, 2.47859127706984d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 52.0d + "'", double4 == 52.0d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 74.37583811291029d + "'", double6 == 74.37583811291029d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 95.9066831389964d + "'", double9 == 95.9066831389964d);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 80.29822162322193d + "'", double15 == 80.29822162322193d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.34461267552064323d + "'", double18 == 0.34461267552064323d);
//    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 43L, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, localizable3, objArray7);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray7);
        java.lang.Object[] objArray10 = maxIterationsExceededException9.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable11 = maxIterationsExceededException9.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException15 = new org.apache.commons.math.exception.OutOfRangeException(localizable11, (java.lang.Number) 10L, (java.lang.Number) 97L, (java.lang.Number) 10);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException19 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable11, (java.lang.Number) 0.10143992966509834d, (java.lang.Number) (-1.362665681324511d), true);
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException24 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 70.20706553972083d, (java.lang.Number) 243.0849990894393d, (java.lang.Number) (-1.0d));
        java.lang.Number number25 = outOfRangeException24.getArgument();
        java.lang.Object[] objArray28 = null;
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException("org.apache.commons.math.MaxIterationsExceededException: hi!", objArray28);
        java.lang.Object[] objArray34 = new java.lang.Object[] { (-1L), 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException("", objArray34);
        org.apache.commons.math.MathException mathException36 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException29, "org.apache.commons.math.MaxIterationsExceededException: hi!", objArray34);
        java.lang.Throwable[] throwableArray37 = mathException29.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException38 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException24, "org.apache.commons.math.MaxIterationsExceededException: hi!", (java.lang.Object[]) throwableArray37);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException39 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable20, (java.lang.Object[]) throwableArray37);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(localizable11);
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + 70.20706553972083d + "'", number25.equals(70.20706553972083d));
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(throwableArray37);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        double double2 = org.apache.commons.math.util.FastMath.pow(5.514901997689139E40d, 7.5013186234692295d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.123407363781739E305d + "'", double2 == 4.123407363781739E305d);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double2 = normalDistributionImpl0.density(57.9674416413573d);
        double[] doubleArray4 = normalDistributionImpl0.sample((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (-1.0d), (java.lang.Number) (byte) -1, (java.lang.Number) 4.9E-324d);
        java.lang.String str4 = outOfRangeException3.toString();
        org.apache.commons.math.exception.util.Localizable localizable5 = outOfRangeException3.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, localizable9, objArray13);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException15 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray13);
        java.lang.Object[] objArray16 = maxIterationsExceededException15.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable17 = maxIterationsExceededException15.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException21 = new org.apache.commons.math.exception.OutOfRangeException(localizable17, (java.lang.Number) 10L, (java.lang.Number) 97L, (java.lang.Number) 10);
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        java.lang.Object[] objArray29 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException30 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable24, localizable25, objArray29);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException31 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray29);
        java.lang.Object[] objArray32 = maxIterationsExceededException31.getArguments();
        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException(localizable17, objArray32);
        org.apache.commons.math.exception.util.Localizable localizable35 = null;
        org.apache.commons.math.exception.util.Localizable localizable36 = null;
        java.lang.Object[] objArray40 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException41 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable35, localizable36, objArray40);
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException("", objArray40);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException43 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable17, objArray40);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException47 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (-1.0d), (java.lang.Number) (byte) -1, (java.lang.Number) 4.9E-324d);
        java.lang.Number number48 = outOfRangeException47.getArgument();
        org.apache.commons.math.MathException mathException49 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException47);
        java.lang.Throwable[] throwableArray50 = mathException49.getSuppressed();
        org.apache.commons.math.MathException mathException51 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3, localizable17, (java.lang.Object[]) throwableArray50);
        org.apache.commons.math.exception.util.Localizable localizable52 = null;
        java.lang.Object[] objArray53 = null;
        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException51, localizable52, objArray53);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.OutOfRangeException: -1 out of [-1, 0] range" + "'", str4.equals("org.apache.commons.math.exception.OutOfRangeException: -1 out of [-1, 0] range"));
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(localizable17);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(objArray40);
        org.junit.Assert.assertTrue("'" + number48 + "' != '" + (-1.0d) + "'", number48.equals((-1.0d)));
        org.junit.Assert.assertNotNull(throwableArray50);
    }

//    @Test
//    public void test037() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test037");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextWeibull(Double.POSITIVE_INFINITY, (double) 52L);
//        double double7 = randomDataImpl0.nextF((double) 81L, (double) 1L);
//        int int10 = randomDataImpl0.nextSecureInt((int) (byte) -1, 100);
//        double double13 = randomDataImpl0.nextBeta(0.7178896490901561d, 0.10968186267255918d);
//        java.lang.String str15 = randomDataImpl0.nextSecureHexString((int) '4');
//        try {
//            int[] intArray18 = randomDataImpl0.nextPermutation(0, 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): permutation size (0");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 52.0d + "'", double4 == 52.0d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.4362376990034906d + "'", double7 == 0.4362376990034906d);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 36 + "'", int10 == 36);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.9941959975292727d + "'", double13 == 0.9941959975292727d);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "72c1b43b31526397b800382d3a4d5f08aeb801056e15410715a7" + "'", str15.equals("72c1b43b31526397b800382d3a4d5f08aeb801056e15410715a7"));
//    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        double double1 = org.apache.commons.math.util.FastMath.floor(107.61001763972789d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 107.0d + "'", double1 == 107.0d);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 953576077L, (java.lang.Number) 1.5430806348152437d, (java.lang.Number) 105.25636095684777d);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 113L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9722220547535925d + "'", double1 == 1.9722220547535925d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        double double1 = org.apache.commons.math.special.Gamma.digamma((-0.02525729994412125d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 38.9729669732286d + "'", double1 == 38.9729669732286d);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, localizable3, objArray7);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray7);
        java.lang.Object[] objArray10 = maxIterationsExceededException9.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable11 = maxIterationsExceededException9.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException15 = new org.apache.commons.math.exception.OutOfRangeException(localizable11, (java.lang.Number) 10L, (java.lang.Number) 97L, (java.lang.Number) 10);
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException15);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(localizable11);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (-1.0d), (java.lang.Number) (byte) -1, (java.lang.Number) 4.9E-324d);
        java.lang.Number number4 = outOfRangeException3.getHi();
        java.lang.Number number5 = outOfRangeException3.getArgument();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 4.9E-324d + "'", number4.equals(4.9E-324d));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-1.0d) + "'", number5.equals((-1.0d)));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0f, (float) 43L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

//    @Test
//    public void test045() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test045");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextGaussian((double) 100, (double) (short) 10);
//        double double6 = randomDataImpl0.nextT(1.7724538509055159d);
//        double double8 = randomDataImpl0.nextChiSquare(40.34361551018096d);
//        double double10 = randomDataImpl0.nextT(1.8190200166118848d);
//        java.lang.String str12 = randomDataImpl0.nextHexString(97);
//        try {
//            randomDataImpl0.setSecureAlgorithm("org.apache.commons.math.exception.MathIllegalArgumentException: hi!", "");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: missing provider");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 98.32737678997862d + "'", double4 == 98.32737678997862d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-0.5370360846658385d) + "'", double6 == (-0.5370360846658385d));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 42.70256045923808d + "'", double8 == 42.70256045923808d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-0.18489586879856015d) + "'", double10 == (-0.18489586879856015d));
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2c6e96244f4b76ec6b7e7045a8743a2d3ef3d957b3313cd96470c46ac79ee580f8783708d48ca355c7e002b66fb1b0218" + "'", str12.equals("2c6e96244f4b76ec6b7e7045a8743a2d3ef3d957b3313cd96470c46ac79ee580f8783708d48ca355c7e002b66fb1b0218"));
//    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        long long1 = org.apache.commons.math.util.FastMath.abs(0L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        double double1 = org.apache.commons.math.util.FastMath.asin(1.0E-9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0E-9d + "'", double1 == 1.0E-9d);
    }

//    @Test
//    public void test048() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test048");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextWeibull(Double.POSITIVE_INFINITY, (double) 52L);
//        java.lang.String str6 = randomDataImpl0.nextSecureHexString(32);
//        try {
//            double double9 = randomDataImpl0.nextGaussian(0.5809401805942233d, (double) (byte) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): standard deviation (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 52.0d + "'", double4 == 52.0d);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "fd0dd88d767dac8a22d3ec55ab84ec12" + "'", str6.equals("fd0dd88d767dac8a22d3ec55ab84ec12"));
//    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (-1.0d), (java.lang.Number) (byte) -1, (java.lang.Number) 4.9E-324d);
        java.lang.String str4 = outOfRangeException3.toString();
        org.apache.commons.math.exception.util.Localizable localizable5 = outOfRangeException3.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, localizable9, objArray13);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException15 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray13);
        java.lang.Object[] objArray16 = maxIterationsExceededException15.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable17 = maxIterationsExceededException15.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException21 = new org.apache.commons.math.exception.OutOfRangeException(localizable17, (java.lang.Number) 10L, (java.lang.Number) 97L, (java.lang.Number) 10);
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        java.lang.Object[] objArray29 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException30 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable24, localizable25, objArray29);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException31 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray29);
        java.lang.Object[] objArray32 = maxIterationsExceededException31.getArguments();
        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException(localizable17, objArray32);
        org.apache.commons.math.exception.util.Localizable localizable35 = null;
        org.apache.commons.math.exception.util.Localizable localizable36 = null;
        java.lang.Object[] objArray40 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException41 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable35, localizable36, objArray40);
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException("", objArray40);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException43 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable17, objArray40);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException47 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (-1.0d), (java.lang.Number) (byte) -1, (java.lang.Number) 4.9E-324d);
        java.lang.Number number48 = outOfRangeException47.getArgument();
        org.apache.commons.math.MathException mathException49 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException47);
        java.lang.Throwable[] throwableArray50 = mathException49.getSuppressed();
        org.apache.commons.math.MathException mathException51 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3, localizable17, (java.lang.Object[]) throwableArray50);
        java.lang.Number number53 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException55 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable17, (java.lang.Number) 0.23477947239890198d, number53, true);
        java.lang.Object[] objArray56 = numberIsTooSmallException55.getArguments();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.OutOfRangeException: -1 out of [-1, 0] range" + "'", str4.equals("org.apache.commons.math.exception.OutOfRangeException: -1 out of [-1, 0] range"));
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(localizable17);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(objArray40);
        org.junit.Assert.assertTrue("'" + number48 + "' != '" + (-1.0d) + "'", number48.equals((-1.0d)));
        org.junit.Assert.assertNotNull(throwableArray50);
        org.junit.Assert.assertNotNull(objArray56);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(97.95853185248363d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7096989112455796d + "'", double1 == 1.7096989112455796d);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 85);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 85.0f + "'", float1 == 85.0f);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, localizable3, objArray7);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray7);
        java.lang.Object[] objArray10 = maxIterationsExceededException9.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable11 = maxIterationsExceededException9.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException15 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable11, (java.lang.Number) 0.0f, (java.lang.Number) 10.0f, false);
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        java.lang.Object[] objArray24 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException25 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable19, localizable20, objArray24);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException26 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray24);
        java.lang.Object[] objArray27 = maxIterationsExceededException26.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable28 = maxIterationsExceededException26.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException32 = new org.apache.commons.math.exception.OutOfRangeException(localizable28, (java.lang.Number) 10L, (java.lang.Number) 97L, (java.lang.Number) 10);
        org.apache.commons.math.exception.util.Localizable localizable35 = null;
        org.apache.commons.math.exception.util.Localizable localizable36 = null;
        java.lang.Object[] objArray40 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException41 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable35, localizable36, objArray40);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException42 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray40);
        java.lang.Object[] objArray43 = maxIterationsExceededException42.getArguments();
        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException(localizable28, objArray43);
        org.apache.commons.math.exception.util.Localizable localizable46 = null;
        org.apache.commons.math.exception.util.Localizable localizable47 = null;
        java.lang.Object[] objArray51 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException52 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable46, localizable47, objArray51);
        org.apache.commons.math.ConvergenceException convergenceException53 = new org.apache.commons.math.ConvergenceException("", objArray51);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException54 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable28, objArray51);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException56 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable28, (java.lang.Number) 32);
        org.apache.commons.math.exception.util.Localizable localizable59 = null;
        org.apache.commons.math.exception.util.Localizable localizable60 = null;
        java.lang.Object[] objArray64 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException65 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable59, localizable60, objArray64);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException66 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray64);
        java.lang.Object[] objArray67 = maxIterationsExceededException66.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable68 = maxIterationsExceededException66.getGeneralPattern();
        java.lang.Number number70 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException71 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number70);
        java.lang.Object[] objArray72 = notStrictlyPositiveException71.getArguments();
        org.apache.commons.math.MathException mathException73 = new org.apache.commons.math.MathException("", objArray72);
        org.apache.commons.math.ConvergenceException convergenceException74 = new org.apache.commons.math.ConvergenceException(localizable68, objArray72);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException75 = new org.apache.commons.math.MaxIterationsExceededException(56, localizable28, objArray72);
        org.apache.commons.math.MathException mathException76 = new org.apache.commons.math.MathException(localizable11, objArray72);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(localizable11);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(localizable28);
        org.junit.Assert.assertNotNull(objArray40);
        org.junit.Assert.assertNotNull(objArray43);
        org.junit.Assert.assertNotNull(objArray51);
        org.junit.Assert.assertNotNull(objArray64);
        org.junit.Assert.assertNotNull(objArray67);
        org.junit.Assert.assertNotNull(localizable68);
        org.junit.Assert.assertNotNull(objArray72);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, localizable4, objArray8);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException10 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray8);
        java.lang.Object[] objArray11 = maxIterationsExceededException10.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable12 = maxIterationsExceededException10.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        java.lang.Object[] objArray18 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable13, localizable14, objArray18);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException20 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, objArray18);
        java.lang.Object[] objArray24 = new java.lang.Object[] { (-1L), 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException25 = new org.apache.commons.math.ConvergenceException("", objArray24);
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException(localizable12, objArray24);
        java.lang.Throwable[] throwableArray27 = mathException26.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException("", (java.lang.Object[]) throwableArray27);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(localizable12);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(throwableArray27);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 32, (float) (short) 100);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 32.0f + "'", float2 == 32.0f);
    }

//    @Test
//    public void test055() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test055");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) 'a');
//        double double5 = randomDataImpl0.nextGaussian(0.7772446417474868d, 1.2297043139906967d);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 98L + "'", long2 == 98L);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.9235786153365809d + "'", double5 == 0.9235786153365809d);
//    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, localizable3, objArray7);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray7);
        java.lang.Object[] objArray10 = maxIterationsExceededException9.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable11 = maxIterationsExceededException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        java.lang.Object[] objArray19 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException20 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable14, localizable15, objArray19);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException21 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray19);
        java.lang.Object[] objArray22 = maxIterationsExceededException21.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable23 = maxIterationsExceededException21.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        java.lang.Object[] objArray29 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException30 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable24, localizable25, objArray29);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException31 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable23, objArray29);
        java.lang.Object[] objArray35 = new java.lang.Object[] { (-1L), 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException("", objArray35);
        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException(localizable23, objArray35);
        org.apache.commons.math.MathException mathException38 = new org.apache.commons.math.MathException(localizable11, objArray35);
        java.lang.Object[] objArray40 = null;
        org.apache.commons.math.MathException mathException41 = new org.apache.commons.math.MathException("org.apache.commons.math.MaxIterationsExceededException: hi!", objArray40);
        java.lang.Object[] objArray46 = new java.lang.Object[] { (-1L), 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException47 = new org.apache.commons.math.ConvergenceException("", objArray46);
        org.apache.commons.math.MathException mathException48 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException41, "org.apache.commons.math.MaxIterationsExceededException: hi!", objArray46);
        java.lang.Throwable[] throwableArray49 = mathException41.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException50 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, (java.lang.Object[]) throwableArray49);
        org.apache.commons.math.exception.util.Localizable localizable51 = mathIllegalArgumentException50.getGeneralPattern();
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(localizable11);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(localizable23);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertNotNull(objArray46);
        org.junit.Assert.assertNotNull(throwableArray49);
        org.junit.Assert.assertNotNull(localizable51);
    }

//    @Test
//    public void test057() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test057");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextExponential((double) 'a');
//        double double5 = randomDataImpl0.nextBeta(70.20706553972083d, (double) 100);
//        long long8 = randomDataImpl0.nextSecureLong((long) (short) 10, (long) ' ');
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 214.22105791566383d + "'", double2 == 214.22105791566383d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.3967012726638302d + "'", double5 == 0.3967012726638302d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 30L + "'", long8 == 30L);
//    }

//    @Test
//    public void test058() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test058");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) 'a');
//        long long4 = randomDataImpl0.nextPoisson(7.79128589555284d);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 93L + "'", long2 == 93L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 7L + "'", long4 == 7L);
//    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        double double1 = org.apache.commons.math.util.FastMath.acos(107.61001763972789d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 70.20706553972083d, (java.lang.Number) 243.0849990894393d, (java.lang.Number) (-1.0d));
        org.apache.commons.math.exception.util.Localizable localizable4 = outOfRangeException3.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) 1, (java.lang.Number) 3.001814241240583d, true);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        java.lang.Object[] objArray16 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable12, objArray16);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException18 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray16);
        java.lang.Object[] objArray19 = maxIterationsExceededException18.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable20 = maxIterationsExceededException18.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable21 = null;
        org.apache.commons.math.exception.util.Localizable localizable22 = null;
        java.lang.Object[] objArray26 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException27 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable21, localizable22, objArray26);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable20, objArray26);
        java.lang.Object[] objArray32 = new java.lang.Object[] { (-1L), 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException33 = new org.apache.commons.math.ConvergenceException("", objArray32);
        org.apache.commons.math.MathException mathException34 = new org.apache.commons.math.MathException(localizable20, objArray32);
        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException(localizable4, objArray32);
        org.apache.commons.math.MathException mathException36 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException35);
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(localizable20);
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(objArray32);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, localizable4, objArray8);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException10 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray8);
        java.lang.Object[] objArray11 = maxIterationsExceededException10.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable12 = maxIterationsExceededException10.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        java.lang.Object[] objArray20 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException21 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable15, localizable16, objArray20);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException22 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray20);
        java.lang.Object[] objArray23 = maxIterationsExceededException22.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable24 = maxIterationsExceededException22.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        java.lang.Object[] objArray30 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException31 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable25, localizable26, objArray30);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException32 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable24, objArray30);
        java.lang.Object[] objArray36 = new java.lang.Object[] { (-1L), 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException37 = new org.apache.commons.math.ConvergenceException("", objArray36);
        org.apache.commons.math.MathException mathException38 = new org.apache.commons.math.MathException(localizable24, objArray36);
        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException(localizable12, objArray36);
        org.apache.commons.math.exception.util.Localizable localizable40 = null;
        org.apache.commons.math.exception.util.Localizable localizable43 = null;
        org.apache.commons.math.exception.util.Localizable localizable44 = null;
        java.lang.Object[] objArray48 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException49 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable43, localizable44, objArray48);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException50 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray48);
        java.lang.Object[] objArray51 = maxIterationsExceededException50.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException52 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable40, objArray51);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException53 = new org.apache.commons.math.MaxIterationsExceededException(2147483647, localizable12, objArray51);
        java.lang.Throwable throwable54 = null;
        try {
            maxIterationsExceededException53.addSuppressed(throwable54);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(localizable12);
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNotNull(localizable24);
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertNotNull(objArray48);
        org.junit.Assert.assertNotNull(objArray51);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 32, (float) 1068183553L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 32.0f + "'", float2 == 32.0f);
    }

//    @Test
//    public void test063() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test063");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy(485.1720550638632d, 2.718281828459045d);
//        double double7 = randomDataImpl1.nextCauchy(0.0d, 243.0849990894393d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl8 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        normalDistributionImpl8.reseedRandomGenerator(0L);
//        double double12 = normalDistributionImpl8.cumulativeProbability(0.0d);
//        double double13 = normalDistributionImpl8.getStandardDeviation();
//        double double14 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl8);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 478.94478481160064d + "'", double4 == 478.94478481160064d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-145.45058971167282d) + "'", double7 == (-145.45058971167282d));
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.5d + "'", double12 == 0.5d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-0.8615140635745313d) + "'", double14 == (-0.8615140635745313d));
//    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 94);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(1.3357478088661466E7d, 1.5675703110361978d);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (-1.0d), (java.lang.Number) (byte) -1, (java.lang.Number) 4.9E-324d);
        java.lang.String str4 = outOfRangeException3.toString();
        org.apache.commons.math.exception.util.Localizable localizable5 = outOfRangeException3.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, localizable9, objArray13);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException15 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray13);
        java.lang.Object[] objArray16 = maxIterationsExceededException15.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable17 = maxIterationsExceededException15.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException21 = new org.apache.commons.math.exception.OutOfRangeException(localizable17, (java.lang.Number) 10L, (java.lang.Number) 97L, (java.lang.Number) 10);
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        java.lang.Object[] objArray29 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException30 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable24, localizable25, objArray29);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException31 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray29);
        java.lang.Object[] objArray32 = maxIterationsExceededException31.getArguments();
        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException(localizable17, objArray32);
        org.apache.commons.math.exception.util.Localizable localizable35 = null;
        org.apache.commons.math.exception.util.Localizable localizable36 = null;
        java.lang.Object[] objArray40 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException41 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable35, localizable36, objArray40);
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException("", objArray40);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException43 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable17, objArray40);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException47 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (-1.0d), (java.lang.Number) (byte) -1, (java.lang.Number) 4.9E-324d);
        java.lang.Number number48 = outOfRangeException47.getArgument();
        org.apache.commons.math.MathException mathException49 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException47);
        java.lang.Throwable[] throwableArray50 = mathException49.getSuppressed();
        org.apache.commons.math.MathException mathException51 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3, localizable17, (java.lang.Object[]) throwableArray50);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException53 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable17, (java.lang.Number) 1.5430806348152437d);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException57 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable17, (java.lang.Number) 0.8025330637390305d, (java.lang.Number) 112.7108697633803d, true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.OutOfRangeException: -1 out of [-1, 0] range" + "'", str4.equals("org.apache.commons.math.exception.OutOfRangeException: -1 out of [-1, 0] range"));
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(localizable17);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(objArray40);
        org.junit.Assert.assertTrue("'" + number48 + "' != '" + (-1.0d) + "'", number48.equals((-1.0d)));
        org.junit.Assert.assertNotNull(throwableArray50);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 85);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 85.0d + "'", double1 == 85.0d);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        double double2 = org.apache.commons.math.util.FastMath.max((-1.8449919524961895d), 99.46117141569913d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 99.46117141569913d + "'", double2 == 99.46117141569913d);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (-1.0d), (java.lang.Number) (byte) -1, (java.lang.Number) 4.9E-324d);
        java.lang.String str5 = outOfRangeException4.toString();
        org.apache.commons.math.exception.util.Localizable localizable6 = outOfRangeException4.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable9, localizable10, objArray14);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException16 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray14);
        java.lang.Object[] objArray17 = maxIterationsExceededException16.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable18 = maxIterationsExceededException16.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException22 = new org.apache.commons.math.exception.OutOfRangeException(localizable18, (java.lang.Number) 10L, (java.lang.Number) 97L, (java.lang.Number) 10);
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        java.lang.Object[] objArray30 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException31 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable25, localizable26, objArray30);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException32 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray30);
        java.lang.Object[] objArray33 = maxIterationsExceededException32.getArguments();
        org.apache.commons.math.MathException mathException34 = new org.apache.commons.math.MathException(localizable18, objArray33);
        org.apache.commons.math.exception.util.Localizable localizable36 = null;
        org.apache.commons.math.exception.util.Localizable localizable37 = null;
        java.lang.Object[] objArray41 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException42 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable36, localizable37, objArray41);
        org.apache.commons.math.ConvergenceException convergenceException43 = new org.apache.commons.math.ConvergenceException("", objArray41);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException44 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable18, objArray41);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException48 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (-1.0d), (java.lang.Number) (byte) -1, (java.lang.Number) 4.9E-324d);
        java.lang.Number number49 = outOfRangeException48.getArgument();
        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException48);
        java.lang.Throwable[] throwableArray51 = mathException50.getSuppressed();
        org.apache.commons.math.MathException mathException52 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException4, localizable18, (java.lang.Object[]) throwableArray51);
        org.apache.commons.math.ConvergenceException convergenceException53 = new org.apache.commons.math.ConvergenceException("org.apache.commons.math.MaxIterationsExceededException: hi!", (java.lang.Object[]) throwableArray51);
        java.lang.String str54 = convergenceException53.toString();
        org.apache.commons.math.exception.util.Localizable localizable55 = convergenceException53.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.OutOfRangeException: -1 out of [-1, 0] range" + "'", str5.equals("org.apache.commons.math.exception.OutOfRangeException: -1 out of [-1, 0] range"));
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(localizable18);
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertNotNull(objArray41);
        org.junit.Assert.assertTrue("'" + number49 + "' != '" + (-1.0d) + "'", number49.equals((-1.0d)));
        org.junit.Assert.assertNotNull(throwableArray51);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "org.apache.commons.math.ConvergenceException: org.apache.commons.math.MaxIterationsExceededException: hi!" + "'", str54.equals("org.apache.commons.math.ConvergenceException: org.apache.commons.math.MaxIterationsExceededException: hi!"));
        org.junit.Assert.assertNull(localizable55);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(55.01184692959797d, 0.4171792897727079d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 55.011846929597965d + "'", double2 == 55.011846929597965d);
    }

//    @Test
//    public void test071() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test071");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextGaussian((double) 100, (double) (short) 10);
//        double double6 = randomDataImpl0.nextT(1.7724538509055159d);
//        double double8 = randomDataImpl0.nextChiSquare(40.34361551018096d);
//        double double10 = randomDataImpl0.nextT(1.8190200166118848d);
//        java.lang.String str12 = randomDataImpl0.nextHexString(97);
//        double double15 = randomDataImpl0.nextUniform(9.982499865612837E-8d, 275.69661220080457d);
//        try {
//            double double17 = randomDataImpl0.nextExponential(0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): mean (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 87.21991414837188d + "'", double4 == 87.21991414837188d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-0.124716538424952d) + "'", double6 == (-0.124716538424952d));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 32.57748864658276d + "'", double8 == 32.57748864658276d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.156204723742449d + "'", double10 == 4.156204723742449d);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "9457667e7c0af42a55e5bdf0b1ae800e49d78afb013430f814a87fc2ae7f0da7ad1f4219c07c18094fb0a09dfe837abd3" + "'", str12.equals("9457667e7c0af42a55e5bdf0b1ae800e49d78afb013430f814a87fc2ae7f0da7ad1f4219c07c18094fb0a09dfe837abd3"));
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 95.05208341179905d + "'", double15 == 95.05208341179905d);
//    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 309.97881155475915d, number1, (java.lang.Number) 0.7178896490901561d);
        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.21224354715455565d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.19247281395723778d + "'", double1 == 0.19247281395723778d);
    }

//    @Test
//    public void test074() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test074");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        int int4 = randomDataImpl0.nextSecureInt((int) (byte) 0, (int) (short) 10);
//        double double7 = randomDataImpl0.nextGaussian((double) 100L, 10.0d);
//        double double10 = randomDataImpl0.nextF(0.9999999334750783d, 0.5772156649015329d);
//        try {
//            int int13 = randomDataImpl0.nextPascal((int) (byte) 1, 7.483314773547883d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 7.483 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 9 + "'", int4 == 9);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 97.09621181927771d + "'", double7 == 97.09621181927771d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 134.12989594199664d + "'", double10 == 134.12989594199664d);
//    }

//    @Test
//    public void test075() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test075");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy(485.1720550638632d, 2.718281828459045d);
//        try {
//            double double7 = randomDataImpl1.nextBeta((double) 10L, (-0.4981406165014857d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.5 p = 0.584");
//        } catch (org.apache.commons.math.exception.MathUserException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 484.1707891148999d + "'", double4 == 484.1707891148999d);
//    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP((-1.5707963267948966d), 0.0d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(1);
    }

//    @Test
//    public void test078() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test078");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        int int4 = randomDataImpl0.nextSecureInt((int) (byte) 0, (int) (short) 10);
//        double double7 = randomDataImpl0.nextGaussian((double) 100L, 10.0d);
//        double double9 = randomDataImpl0.nextChiSquare(485.1720550638632d);
//        int int12 = randomDataImpl0.nextInt(59, 100);
//        double double15 = randomDataImpl0.nextGaussian(0.8985966235562164d, 0.21224354715455565d);
//        double double18 = randomDataImpl0.nextWeibull(0.5491895702039902d, (double) 43L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 88.228467967785d + "'", double7 == 88.228467967785d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 550.926932386207d + "'", double9 == 550.926932386207d);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 94 + "'", int12 == 94);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.2319022154174122d + "'", double15 == 1.2319022154174122d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 178.80902646850777d + "'", double18 == 178.80902646850777d);
//    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 94L);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) ' ');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 32 + "'", int1 == 32);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.09855426050315531d, (double) 6L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.163310891497025E-7d + "'", double2 == 9.163310891497025E-7d);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ((double) (byte) 0, (-0.5917507542640686d), (-1986.3253837962368d), 84);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, localizable3, objArray7);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray7);
        java.lang.Object[] objArray10 = maxIterationsExceededException9.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable11 = maxIterationsExceededException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable13, objArray17);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, objArray17);
        java.lang.Object[] objArray23 = new java.lang.Object[] { (-1L), 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException("", objArray23);
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException(localizable11, objArray23);
        org.apache.commons.math.exception.util.Localizable localizable26 = mathException25.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException30 = new org.apache.commons.math.exception.OutOfRangeException(localizable26, (java.lang.Number) 1068183553L, (java.lang.Number) (-1), (java.lang.Number) 4.4145372766281294d);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(localizable11);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNotNull(localizable26);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((-1.5707963267948966d), 0.018379497154688493d, 0.2076448279847295d);
    }

//    @Test
//    public void test086() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test086");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextGaussian((double) 100, (double) (short) 10);
//        double double6 = randomDataImpl0.nextT(1.7724538509055159d);
//        double double8 = randomDataImpl0.nextChiSquare(40.34361551018096d);
//        double double10 = randomDataImpl0.nextT(1.8190200166118848d);
//        java.lang.String str12 = randomDataImpl0.nextHexString(97);
//        double double15 = randomDataImpl0.nextUniform(9.982499865612837E-8d, 275.69661220080457d);
//        double double17 = randomDataImpl0.nextExponential(1.3357478088661466E7d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 98.48507878978961d + "'", double4 == 98.48507878978961d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.3460674049065823d + "'", double6 == 0.3460674049065823d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 40.71910392424495d + "'", double8 == 40.71910392424495d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.8430633190417073d + "'", double10 == 0.8430633190417073d);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "04ec2928f6e67ff9e81bf0e5b7235394c0004308742dade088e04d88af3b29b4797f263790e36ca8443d54dbb19139aa8" + "'", str12.equals("04ec2928f6e67ff9e81bf0e5b7235394c0004308742dade088e04d88af3b29b4797f263790e36ca8443d54dbb19139aa8"));
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 71.48115017799994d + "'", double15 == 71.48115017799994d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 2832156.171790785d + "'", double17 == 2832156.171790785d);
//    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP((double) 113L, (double) 81L, (double) 11, (int) 'a');
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.3564912893824143E-4d + "'", double4 == 1.3564912893824143E-4d);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 59, (long) (-1));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

//    @Test
//    public void test089() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test089");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        int int4 = randomDataImpl0.nextSecureInt((int) (byte) 0, (int) (short) 10);
//        double double7 = randomDataImpl0.nextGaussian((double) 100L, 10.0d);
//        double double10 = randomDataImpl0.nextF(0.9999999334750783d, 0.5772156649015329d);
//        try {
//            int int13 = randomDataImpl0.nextZipf(85, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): exponent (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 3 + "'", int4 == 3);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 96.55267415227867d + "'", double7 == 96.55267415227867d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.3648398557661257d + "'", double10 == 0.3648398557661257d);
//    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double2 = normalDistributionImpl0.density(57.9674416413573d);
        double double3 = normalDistributionImpl0.getStandardDeviation();
        double double5 = normalDistributionImpl0.density(0.1961667065943087d);
        double double7 = normalDistributionImpl0.density(485.1720550638632d);
        try {
            double double9 = normalDistributionImpl0.inverseCumulativeProbability((double) 1068183553L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 1,068,183,553 out of [0, 1] range");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.3913397299909444d + "'", double5 == 0.3913397299909444d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (byte) 0, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException2 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, objArray1);
        org.apache.commons.math.MathException mathException3 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException2);
    }

//    @Test
//    public void test093() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test093");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextExponential((double) 'a');
//        randomDataImpl0.reSeed(97L);
//        double double6 = randomDataImpl0.nextExponential((double) 2);
//        double double9 = randomDataImpl0.nextGaussian(1.2096001481343446d, 4.123407363781739E305d);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 106.08533214669335d + "'", double2 == 106.08533214669335d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.6506892372005573d + "'", double6 == 0.6506892372005573d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 3.7414268257852804E304d + "'", double9 == 3.7414268257852804E304d);
//    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 91L, 6.186562584014371d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 91.0d + "'", double2 == 91.0d);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        double double1 = org.apache.commons.math.util.FastMath.atan(6.186554122391093d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.410541561702735d + "'", double1 == 1.410541561702735d);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable1 = convergenceException0.getSpecificPattern();
        org.junit.Assert.assertNull(localizable1);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 100.0f, (java.lang.Number) 2147483647, false);
        java.lang.Number number4 = numberIsTooSmallException3.getMin();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 2147483647 + "'", number4.equals(2147483647));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        normalDistributionImpl0.reseedRandomGenerator(0L);
        double double4 = normalDistributionImpl0.cumulativeProbability(0.0d);
        double double5 = normalDistributionImpl0.getStandardDeviation();
        double double8 = normalDistributionImpl0.cumulativeProbability(1.410541561702735d, 88.228467967785d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.5d + "'", double4 == 0.5d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.07918991661691699d + "'", double8 == 0.07918991661691699d);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, localizable4, objArray8);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException10 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray8);
        java.lang.Object[] objArray11 = maxIterationsExceededException10.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable12 = maxIterationsExceededException10.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        java.lang.Object[] objArray18 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable13, localizable14, objArray18);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException20 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, objArray18);
        java.lang.Object[] objArray24 = new java.lang.Object[] { (-1L), 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException25 = new org.apache.commons.math.ConvergenceException("", objArray24);
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException(localizable12, objArray24);
        java.lang.Number number28 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException29 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number28);
        java.lang.Object[] objArray30 = notStrictlyPositiveException29.getArguments();
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException("", objArray30);
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException(localizable12, objArray30);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException36 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (-1.0d), (java.lang.Number) (byte) -1, (java.lang.Number) 4.9E-324d);
        java.lang.Number number37 = outOfRangeException36.getArgument();
        org.apache.commons.math.MathException mathException38 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException36);
        java.lang.Throwable[] throwableArray39 = mathException38.getSuppressed();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException40 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 100, localizable12, (java.lang.Object[]) throwableArray39);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(localizable12);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertTrue("'" + number37 + "' != '" + (-1.0d) + "'", number37.equals((-1.0d)));
        org.junit.Assert.assertNotNull(throwableArray39);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        double double2 = org.apache.commons.math.util.FastMath.min(1.9053343882104803d, 63.54970114954832d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.9053343882104803d + "'", double2 == 1.9053343882104803d);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) (byte) 10, (double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

//    @Test
//    public void test102() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test102");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGamma((double) (short) 1, 2.722936728502507d);
//        randomDataImpl0.reSeed();
//        double double7 = randomDataImpl0.nextCauchy((-20.72326583694641d), 1.2319022154174122d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.063728425177075d + "'", double3 == 2.063728425177075d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-20.601531680511d) + "'", double7 == (-20.601531680511d));
//    }

//    @Test
//    public void test103() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test103");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextExponential((double) 'a');
//        int int5 = randomDataImpl0.nextZipf((int) (byte) 10, 73.0d);
//        try {
//            int int8 = randomDataImpl0.nextInt(85, 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 85 is larger than, or equal to, the maximum (0): lower bound (85) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 62.140531713611125d + "'", double2 == 62.140531713611125d);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.2076448279847295d, (java.lang.Number) 1.0E-9d, true);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooSmallException3.getSpecificPattern();
        org.junit.Assert.assertNull(localizable4);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, localizable3, objArray7);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray7);
        java.lang.Object[] objArray10 = maxIterationsExceededException9.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable11 = maxIterationsExceededException9.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException15 = new org.apache.commons.math.exception.OutOfRangeException(localizable11, (java.lang.Number) 10L, (java.lang.Number) 97L, (java.lang.Number) 10);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException19 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable11, (java.lang.Number) 0.10143992966509834d, (java.lang.Number) (-1.362665681324511d), true);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException23 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable11, (java.lang.Number) 0.23477947239890198d, (java.lang.Number) 0.10143992966509834d, false);
        java.lang.Number number24 = numberIsTooLargeException23.getMax();
        boolean boolean25 = numberIsTooLargeException23.getBoundIsAllowed();
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(localizable11);
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + 0.10143992966509834d + "'", number24.equals(0.10143992966509834d));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(6.537792819726184d, 0.8427007929497151d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.537792819726183d + "'", double2 == 6.537792819726183d);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.16553633867115672d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.15318135761866306d + "'", double1 == 0.15318135761866306d);
    }

//    @Test
//    public void test108() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test108");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGamma((double) (short) 1, 2.722936728502507d);
//        double double6 = randomDataImpl0.nextBeta(2.6881171418161356E43d, 0.1961667065943087d);
//        try {
//            randomDataImpl0.setSecureAlgorithm("org.apache.commons.math.exception.OutOfRangeException: -1 out of [-1, 0] range", "org.apache.commons.math.MaxIterationsExceededException: hi!");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: org.apache.commons.math.MaxIterationsExceededException: hi!");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.1483062401481607d + "'", double3 == 2.1483062401481607d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.9999999983822d + "'", double6 == 0.9999999983822d);
//    }

//    @Test
//    public void test109() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test109");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextExponential((double) 'a');
//        randomDataImpl0.reSeed(97L);
//        int int7 = randomDataImpl0.nextZipf(85, (double) '#');
//        double double10 = randomDataImpl0.nextCauchy((double) 100L, Double.NaN);
//        randomDataImpl0.reSeedSecure((long) 10);
//        try {
//            double double15 = randomDataImpl0.nextF(0.0d, 52.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): degrees of freedom (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 59.489300466348304d + "'", double2 == 59.489300466348304d);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
//    }

//    @Test
//    public void test110() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test110");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGamma((double) (short) 1, 2.722936728502507d);
//        randomDataImpl0.reSeed();
//        double double7 = randomDataImpl0.nextWeibull((double) 6L, 0.17084659589147716d);
//        double double9 = randomDataImpl0.nextExponential((double) 52L);
//        double double11 = randomDataImpl0.nextChiSquare(0.011614302437156073d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.1327803030438632d + "'", double3 == 2.1327803030438632d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.16403043066223777d + "'", double7 == 0.16403043066223777d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 157.64392591012006d + "'", double9 == 157.64392591012006d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0E-323d + "'", double11 == 1.0E-323d);
//    }

//    @Test
//    public void test111() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test111");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        int int4 = randomDataImpl0.nextSecureInt((int) (byte) 0, (int) (short) 10);
//        double double7 = randomDataImpl0.nextGaussian((double) 100L, 10.0d);
//        try {
//            int int10 = randomDataImpl0.nextBinomial((int) 'a', 113.99656702335484d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 113.997 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 7 + "'", int4 == 7);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 102.86289244261178d + "'", double7 == 102.86289244261178d);
//    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        long long2 = org.apache.commons.math.util.FastMath.min(29L, 1920001583L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 29L + "'", long2 == 29L);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 81L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 81.0d + "'", double1 == 81.0d);
    }

//    @Test
//    public void test114() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test114");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextWeibull(Double.POSITIVE_INFINITY, (double) 52L);
//        long long7 = randomDataImpl0.nextSecureLong(0L, (long) 2);
//        long long9 = randomDataImpl0.nextPoisson((double) 1.1589608E8f);
//        int int12 = randomDataImpl0.nextSecureInt(0, 2147483647);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 52.0d + "'", double4 == 52.0d);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 115893068L + "'", long9 == 115893068L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-650886522) + "'", int12 == (-650886522));
//    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException3 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number2);
        java.lang.Object[] objArray4 = notStrictlyPositiveException3.getArguments();
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException("", objArray4);
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException("org.apache.commons.math.ConvergenceException: 1 out of [-1, 100] range", objArray4);
        org.junit.Assert.assertNotNull(objArray4);
    }

//    @Test
//    public void test116() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test116");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextCauchy(485.1720550638632d, 2.718281828459045d);
//        randomDataImpl1.reSeedSecure();
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 490.2325661921036d + "'", double4 == 490.2325661921036d);
//    }

//    @Test
//    public void test117() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test117");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextWeibull(Double.POSITIVE_INFINITY, (double) 52L);
//        long long7 = randomDataImpl0.nextSecureLong(0L, (long) 2);
//        long long9 = randomDataImpl0.nextPoisson((double) 1.1589608E8f);
//        try {
//            long long12 = randomDataImpl0.nextSecureLong((long) (short) 100, 36L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100 is larger than, or equal to, the maximum (36): lower bound (100) must be strictly less than upper bound (36)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 52.0d + "'", double4 == 52.0d);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 115901489L + "'", long9 == 115901489L);
//    }
//}

