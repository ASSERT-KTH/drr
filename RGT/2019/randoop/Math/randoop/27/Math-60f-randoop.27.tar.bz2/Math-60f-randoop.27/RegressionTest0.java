import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(4.9E-324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) (short) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5574077246549023d) + "'", double1 == (-1.5574077246549023d));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        long long2 = org.apache.commons.math.util.FastMath.min(100L, (long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        float float1 = org.apache.commons.math.util.FastMath.abs(0.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (short) 0, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.0d, 0.0d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        double double1 = org.apache.commons.math.util.FastMath.exp((-1.5574077246549023d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.21068150841353378d + "'", double1 == 0.21068150841353378d);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        double double1 = org.apache.commons.math.special.Erf.erf((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8427007929497151d + "'", double1 == 0.8427007929497151d);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((-1.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        long long1 = org.apache.commons.math.util.FastMath.round(100.0d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 100L + "'", long1 == 100L);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        int int1 = org.apache.commons.math.util.FastMath.abs(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.21068150841353378d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2076448279847295d + "'", double1 == 0.2076448279847295d);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        try {
            double double3 = randomDataImpl0.nextUniform(0.0d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 0 is larger than, or equal to, the maximum (0): lower bound (0) must be strictly less than upper bound (0)");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        double double1 = org.apache.commons.math.util.FastMath.asin(4.9E-324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) '4');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 52L + "'", long1 == 52L);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ((-1.0d), (double) 81L);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (short) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(265.73825046500843d, (double) 100L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

//    @Test
//    public void test025() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test025");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextExponential((double) 'a');
//        try {
//            java.lang.String str4 = randomDataImpl0.nextHexString((-1));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): length (-1)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 428.9040440942284d + "'", double2 == 428.9040440942284d);
//    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 'a');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 97L + "'", long1 == 97L);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (short) 0, (long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, localizable3, objArray7);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray7);
        java.lang.Object[] objArray10 = maxIterationsExceededException9.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable11 = maxIterationsExceededException9.getGeneralPattern();
        java.lang.Class<?> wildcardClass12 = maxIterationsExceededException9.getClass();
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(localizable11);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

//    @Test
//    public void test029() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test029");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextExponential((double) 'a');
//        try {
//            int int5 = randomDataImpl0.nextPascal((int) (byte) 10, (double) (byte) 10);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 10 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.755085308525871d + "'", double2 == 3.755085308525871d);
//    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeed();
        try {
            int int4 = randomDataImpl0.nextPascal(0, 10.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 10 out of [0, 1] range");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.428182669496151d) + "'", double1 == (-0.428182669496151d));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeed();
        double double4 = randomDataImpl0.nextWeibull(Double.POSITIVE_INFINITY, (double) 52L);
        try {
            double double6 = randomDataImpl0.nextExponential(0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): mean (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 52.0d + "'", double4 == 52.0d);
    }

//    @Test
//    public void test033() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test033");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextExponential((double) 'a');
//        try {
//            int int5 = randomDataImpl0.nextBinomial((-1), (double) (-1.0f));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: -1 is smaller than the minimum (0): number of trials (-1)");
//        } catch (org.apache.commons.math.exception.NotPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.596852344232413d + "'", double2 == 2.596852344232413d);
//    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        double double1 = org.apache.commons.math.special.Gamma.logGamma((double) 0L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (byte) 0);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 35.0d + "'", double1 == 35.0d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(104.2221698016779d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.8190200166118848d + "'", double1 == 1.8190200166118848d);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) (short) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.1752011936438014d) + "'", double1 == (-1.1752011936438014d));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(100.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 359.1342053695754d + "'", double1 == 359.1342053695754d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) '#', (double) 100L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 35.00000000000001d + "'", double2 == 35.00000000000001d);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 10, 100L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (byte) 100, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

//    @Test
//    public void test044() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test044");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextExponential((double) 'a');
//        randomDataImpl0.reSeed(97L);
//        try {
//            int int7 = randomDataImpl0.nextInt((int) (byte) 100, (int) '4');
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100 is larger than, or equal to, the maximum (52): lower bound (100) must be strictly less than upper bound (52)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 121.49757850426738d + "'", double2 == 121.49757850426738d);
//    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        try {
            double[] doubleArray2 = normalDistributionImpl0.sample((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): number of samples (-1)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 81L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        double double1 = org.apache.commons.math.special.Erf.erf(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

//    @Test
//    public void test048() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test048");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int int3 = randomDataImpl0.nextZipf(10, 1.8146000362165722d);
//        try {
//            int int6 = randomDataImpl0.nextBinomial(0, 359.1342053695754d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 359.134 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        java.lang.Object[] objArray3 = new java.lang.Object[] { (-1L), 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException("", objArray3);
        java.lang.Object[] objArray8 = new java.lang.Object[] { (-1L), 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException("", objArray8);
        convergenceException4.addSuppressed((java.lang.Throwable) convergenceException9);
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertNotNull(objArray8);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException2 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, objArray1);
        org.apache.commons.math.exception.util.Localizable localizable3 = mathIllegalArgumentException2.getGeneralPattern();
        org.junit.Assert.assertNull(localizable3);
    }

//    @Test
//    public void test051() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test051");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextExponential((double) 'a');
//        double double4 = randomDataImpl0.nextExponential(0.2076448279847295d);
//        try {
//            double double7 = randomDataImpl0.nextGamma(52.0d, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): beta");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 127.77786090877201d + "'", double2 == 127.77786090877201d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.18032879252260756d + "'", double4 == 0.18032879252260756d);
//    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) 0, (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32 + "'", int2 == 32);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        double double1 = org.apache.commons.math.util.FastMath.exp(100.92781056272442d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.798157121994732E43d + "'", double1 == 6.798157121994732E43d);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        double double2 = org.apache.commons.math.util.FastMath.min(0.0d, (double) 0L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (short) -1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        double double1 = org.apache.commons.math.util.FastMath.sinh(1.8190200166118848d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.001814241240583d + "'", double1 == 3.001814241240583d);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 0.0f, (double) 100.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

//    @Test
//    public void test058() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test058");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) 'a');
//        try {
//            int[] intArray5 = randomDataImpl0.nextPermutation(0, 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): permutation size (0");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 99L + "'", long2 == 99L);
//    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        int int2 = org.apache.commons.math.util.FastMath.min(1, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        double double1 = org.apache.commons.math.util.FastMath.log((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        long long2 = org.apache.commons.math.util.FastMath.max(0L, (long) '4');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52L + "'", long2 == 52L);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        double double1 = org.apache.commons.math.util.FastMath.atanh(35.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test064() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test064");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform(4.9E-324d, 0.3639973351338316d);
//        try {
//            long long6 = randomDataImpl0.nextLong(1L, (long) (short) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 1 is larger than, or equal to, the maximum (0): lower bound (1) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.06349018448423882d + "'", double3 == 0.06349018448423882d);
//    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        double double2 = org.apache.commons.math.util.FastMath.min((double) (-1L), (double) (short) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

//    @Test
//    public void test066() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test066");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform(4.9E-324d, 0.3639973351338316d);
//        try {
//            int int6 = randomDataImpl0.nextBinomial((int) (byte) 0, 1.8146000362165722d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 1.815 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.062316324383274425d + "'", double3 == 0.062316324383274425d);
//    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        double double1 = org.apache.commons.math.special.Gamma.logGamma((double) 97L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 345.37940706226686d + "'", double1 == 345.37940706226686d);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        double double1 = org.apache.commons.math.util.FastMath.ulp(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(0.06433798016957738d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 243.0849990894393d + "'", double1 == 243.0849990894393d);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(0.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.3639973351338316d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): standard deviation (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.3978952727983707d + "'", double1 == 2.3978952727983707d);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        double double0 = org.apache.commons.math.distribution.NormalDistributionImpl.DEFAULT_INVERSE_ABSOLUTE_ACCURACY;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-9d + "'", double0 == 1.0E-9d);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 97L, (java.lang.Number) 0.23477947239890198d, (java.lang.Number) (-1.1752011936438014d));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        long long2 = org.apache.commons.math.util.FastMath.min(81L, (long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 81L + "'", long2 == 81L);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        double double0 = org.apache.commons.math.util.FastMath.PI;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.141592653589793d + "'", double0 == 3.141592653589793d);
    }

//    @Test
//    public void test079() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test079");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int int3 = randomDataImpl0.nextZipf(10, 1.8146000362165722d);
//        try {
//            int[] intArray6 = randomDataImpl0.nextPermutation((int) ' ', (int) 'a');
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 97 is larger than the maximum (32): permutation size (97) exceeds permuation domain (32)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2 + "'", int3 == 2);
//    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) (short) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

//    @Test
//    public void test081() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test081");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        int int4 = randomDataImpl0.nextSecureInt((int) (byte) 0, (int) (short) 10);
//        try {
//            java.lang.String str6 = randomDataImpl0.nextHexString((-1));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): length (-1)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
//    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 0, 662.1393811619379d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        double double2 = org.apache.commons.math.util.FastMath.min((double) (short) 0, (double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

//    @Test
//    public void test085() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test085");
//        double double0 = org.apache.commons.math.util.FastMath.random();
//        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.5809401805942233d + "'", double0 == 0.5809401805942233d);
//    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, localizable3, objArray7);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray7);
        java.lang.Object[] objArray10 = maxIterationsExceededException9.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable11 = maxIterationsExceededException9.getGeneralPattern();
        int int12 = maxIterationsExceededException9.getMaxIterations();
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(localizable11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

//    @Test
//    public void test087() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test087");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform(4.9E-324d, 0.3639973351338316d);
//        try {
//            double double6 = randomDataImpl0.nextF(104.2221698016779d, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): degrees of freedom (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.24843917361231158d + "'", double3 == 0.24843917361231158d);
//    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (short) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeed();
        try {
            randomDataImpl0.setSecureAlgorithm("hi!", "org.apache.commons.math.exception.OutOfRangeException: -1 out of [-1, 0] range");
            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: org.apache.commons.math.exception.OutOfRangeException: -1 out of [-1, 0] range");
        } catch (java.security.NoSuchProviderException e) {
        }
    }

//    @Test
//    public void test090() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test090");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        int int4 = randomDataImpl0.nextSecureInt((int) (byte) 0, (int) (short) 10);
//        double double7 = randomDataImpl0.nextGaussian((double) 100L, 10.0d);
//        try {
//            int int10 = randomDataImpl0.nextInt(0, 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 0 is larger than, or equal to, the maximum (0): lower bound (0) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 102.8526702517172d + "'", double7 == 102.8526702517172d);
//    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.06433798016957738d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.062352991014519736d + "'", double1 == 0.062352991014519736d);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        long long2 = org.apache.commons.math.util.FastMath.min(100L, (long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        double double1 = org.apache.commons.math.util.FastMath.asinh(243.0849990894393d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.186562584014371d + "'", double1 == 6.186562584014371d);
    }

//    @Test
//    public void test094() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test094");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextWeibull(Double.POSITIVE_INFINITY, (double) 52L);
//        long long7 = randomDataImpl0.nextLong(0L, (long) (byte) 1);
//        try {
//            randomDataImpl0.setSecureAlgorithm("", "");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: missing provider");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 52.0d + "'", double4 == 52.0d);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
//    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, localizable3, objArray7);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray7);
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        java.lang.Object[] objArray18 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable13, localizable14, objArray18);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException20 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray18);
        java.lang.Object[] objArray21 = maxIterationsExceededException20.getArguments();
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException9, localizable10, objArray21);
        java.lang.String str23 = maxIterationsExceededException9.toString();
        java.lang.Class<?> wildcardClass24 = maxIterationsExceededException9.getClass();
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.apache.commons.math.MaxIterationsExceededException: hi!" + "'", str23.equals("org.apache.commons.math.MaxIterationsExceededException: hi!"));
        org.junit.Assert.assertNotNull(wildcardClass24);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        double double1 = org.apache.commons.math.util.FastMath.log(6.798157121994732E43d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.92781056272442d + "'", double1 == 100.92781056272442d);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(0.7178896490901561d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.722936728502507d + "'", double1 == 2.722936728502507d);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        double double1 = org.apache.commons.math.util.FastMath.cosh((-1.5574077246549023d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.47859127706984d + "'", double1 == 2.47859127706984d);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeed();
        double double4 = randomDataImpl0.nextWeibull(Double.POSITIVE_INFINITY, (double) 52L);
        int int7 = randomDataImpl0.nextPascal((int) (byte) 10, 0.0d);
        randomDataImpl0.reSeedSecure((long) '#');
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 52.0d + "'", double4 == 52.0d);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2147483647 + "'", int7 == 2147483647);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        double double1 = org.apache.commons.math.util.FastMath.log10((-1.1752011936438014d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (short) 1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (-1.0d), (java.lang.Number) (byte) -1, (java.lang.Number) 4.9E-324d);
        java.lang.String str4 = outOfRangeException3.toString();
        org.apache.commons.math.exception.util.Localizable localizable5 = outOfRangeException3.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        java.lang.Object[] objArray15 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException16 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable10, localizable11, objArray15);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException17 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray15);
        java.lang.Object[] objArray18 = maxIterationsExceededException17.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable19 = maxIterationsExceededException17.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        org.apache.commons.math.exception.util.Localizable localizable21 = null;
        java.lang.Object[] objArray25 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException26 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable20, localizable21, objArray25);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException27 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable19, objArray25);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException28 = new org.apache.commons.math.MaxIterationsExceededException((int) '#', "", objArray25);
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException(localizable5, objArray25);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.OutOfRangeException: -1 out of [-1, 0] range" + "'", str4.equals("org.apache.commons.math.exception.OutOfRangeException: -1 out of [-1, 0] range"));
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(localizable19);
        org.junit.Assert.assertNotNull(objArray25);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(57.9674416413573d, (double) 2147483647);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 57.967441641357304d + "'", double2 == 57.967441641357304d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        double double1 = org.apache.commons.math.util.FastMath.exp(6.186562584014371d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 486.1720550638632d + "'", double1 == 486.1720550638632d);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 953576077L, (float) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(10);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 52L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 52.0d + "'", double1 == 52.0d);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        double double1 = org.apache.commons.math.util.FastMath.tan(35.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.473814720414451d + "'", double1 == 0.473814720414451d);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (-1), (long) '4');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        long long2 = org.apache.commons.math.util.FastMath.min(81L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.062352991014519736d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.06048625084551451d + "'", double1 == 0.06048625084551451d);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        double double1 = org.apache.commons.math.special.Erf.erf(6.186562584014371d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 'a');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.594700892207039d + "'", double1 == 4.594700892207039d);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        double double0 = org.apache.commons.math.util.FastMath.E;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.718281828459045d + "'", double0 == 2.718281828459045d);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        long long1 = org.apache.commons.math.util.FastMath.round(0.473814720414451d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        double double1 = org.apache.commons.math.util.FastMath.expm1(6.186562584014371d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 485.1720550638632d + "'", double1 == 485.1720550638632d);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (-1), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        long long1 = org.apache.commons.math.util.FastMath.round(0.0d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

//    @Test
//    public void test121() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test121");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        int int4 = randomDataImpl0.nextSecureInt((int) (byte) 0, (int) (short) 10);
//        double double7 = randomDataImpl0.nextGaussian((double) 100L, 10.0d);
//        try {
//            int int10 = randomDataImpl0.nextPascal((int) (byte) 10, 2.3978952727983707d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 2.398 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 9 + "'", int4 == 9);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 91.3952259340877d + "'", double7 == 91.3952259340877d);
//    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.5542337861184903d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9833541737601599d + "'", double1 == 0.9833541737601599d);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        double double2 = org.apache.commons.math.util.FastMath.max(0.06048625084551451d, 485.1720550638632d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 485.1720550638632d + "'", double2 == 485.1720550638632d);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        double double1 = org.apache.commons.math.util.FastMath.asin(1.8146000362165722d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(3.141592653589793d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7724538509055159d + "'", double1 == 1.7724538509055159d);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double2 = normalDistributionImpl0.density(57.9674416413573d);
        try {
            double double4 = normalDistributionImpl0.inverseCumulativeProbability((double) 'a');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 97 out of [0, 1] range");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(70.20706553972083d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 227.06909087323695d + "'", double1 == 227.06909087323695d);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 953576077L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        int int1 = org.apache.commons.math.util.FastMath.round((-1.0f));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 953576077L, 2.47859127706984d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.8036482179291442E22d + "'", double2 == 1.8036482179291442E22d);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        double double1 = org.apache.commons.math.util.FastMath.log(0.23477947239890198d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.4491086207491168d) + "'", double1 == (-1.4491086207491168d));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, localizable3, objArray7);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray7);
        java.lang.Object[] objArray10 = maxIterationsExceededException9.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable11 = maxIterationsExceededException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable13, objArray17);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, objArray17);
        java.lang.Object[] objArray23 = new java.lang.Object[] { (-1L), 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException("", objArray23);
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException(localizable11, objArray23);
        java.lang.Number number27 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException28 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number27);
        java.lang.Object[] objArray29 = notStrictlyPositiveException28.getArguments();
        org.apache.commons.math.MathException mathException30 = new org.apache.commons.math.MathException("", objArray29);
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException(localizable11, objArray29);
        org.apache.commons.math.exception.util.Localizable localizable34 = null;
        org.apache.commons.math.exception.util.Localizable localizable35 = null;
        java.lang.Object[] objArray39 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException40 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable34, localizable35, objArray39);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException41 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray39);
        java.lang.Object[] objArray42 = maxIterationsExceededException41.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable43 = maxIterationsExceededException41.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable44 = null;
        org.apache.commons.math.exception.util.Localizable localizable45 = null;
        java.lang.Object[] objArray49 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException50 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable44, localizable45, objArray49);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException51 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable43, objArray49);
        java.lang.Object[] objArray55 = new java.lang.Object[] { (-1L), 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException56 = new org.apache.commons.math.ConvergenceException("", objArray55);
        org.apache.commons.math.MathException mathException57 = new org.apache.commons.math.MathException(localizable43, objArray55);
        org.apache.commons.math.exception.util.Localizable localizable60 = null;
        org.apache.commons.math.exception.util.Localizable localizable61 = null;
        java.lang.Object[] objArray65 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException66 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable60, localizable61, objArray65);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException67 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray65);
        java.lang.Object[] objArray68 = maxIterationsExceededException67.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable69 = maxIterationsExceededException67.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException73 = new org.apache.commons.math.exception.OutOfRangeException(localizable69, (java.lang.Number) 10L, (java.lang.Number) 97L, (java.lang.Number) 10);
        java.lang.Object[] objArray74 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException75 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable43, localizable69, objArray74);
        convergenceException31.addSuppressed((java.lang.Throwable) mathIllegalArgumentException75);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(localizable11);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertNotNull(localizable43);
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertNotNull(objArray55);
        org.junit.Assert.assertNotNull(objArray65);
        org.junit.Assert.assertNotNull(objArray68);
        org.junit.Assert.assertNotNull(localizable69);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        double double0 = org.apache.commons.math.special.Gamma.GAMMA;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.5772156649015329d + "'", double0 == 0.5772156649015329d);
    }

//    @Test
//    public void test136() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test136");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextExponential((double) 'a');
//        randomDataImpl0.reSeed(97L);
//        double double6 = randomDataImpl0.nextChiSquare(100.92781056272442d);
//        try {
//            double double9 = randomDataImpl0.nextF((double) (-1L), 1.7724538509055159d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): degrees of freedom (-1)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 90.93385027714407d + "'", double2 == 90.93385027714407d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 108.8399875855036d + "'", double6 == 108.8399875855036d);
//    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(70.20706553972083d, 0.0d, 57.9674416413573d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): standard deviation (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        int int2 = org.apache.commons.math.util.FastMath.min(32, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.5772156649015329d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5491895702039902d + "'", double1 == 0.5491895702039902d);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ((double) '4', 4.9E-324d, 0.0d, 100);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(Double.POSITIVE_INFINITY, (double) 85, 4.9E-324d, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: maximal number of iterations (-1) exceeded");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        double double1 = org.apache.commons.math.util.FastMath.cosh((-1.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5430806348152437d + "'", double1 == 1.5430806348152437d);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        double double2 = org.apache.commons.math.util.FastMath.max(2.718281828459045d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.718281828459045d + "'", double2 == 2.718281828459045d);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ((double) (short) 10, 0.0d, 70.20706553972083d, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 'a', (float) (short) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        double double1 = org.apache.commons.math.util.FastMath.signum(70.20706553972083d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, localizable3, objArray7);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray7);
        java.lang.Object[] objArray10 = maxIterationsExceededException9.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable11 = maxIterationsExceededException9.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException15 = new org.apache.commons.math.exception.OutOfRangeException(localizable11, (java.lang.Number) 10L, (java.lang.Number) 97L, (java.lang.Number) 10);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException19 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable11, (java.lang.Number) 0.10143992966509834d, (java.lang.Number) (-1.362665681324511d), true);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException23 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (-1.0d), (java.lang.Number) (byte) -1, (java.lang.Number) 4.9E-324d);
        java.lang.String str24 = outOfRangeException23.toString();
        org.apache.commons.math.exception.util.Localizable localizable25 = outOfRangeException23.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable28 = null;
        org.apache.commons.math.exception.util.Localizable localizable29 = null;
        java.lang.Object[] objArray33 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException34 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable28, localizable29, objArray33);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException35 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray33);
        java.lang.Object[] objArray36 = maxIterationsExceededException35.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable37 = maxIterationsExceededException35.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException41 = new org.apache.commons.math.exception.OutOfRangeException(localizable37, (java.lang.Number) 10L, (java.lang.Number) 97L, (java.lang.Number) 10);
        org.apache.commons.math.exception.util.Localizable localizable44 = null;
        org.apache.commons.math.exception.util.Localizable localizable45 = null;
        java.lang.Object[] objArray49 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException50 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable44, localizable45, objArray49);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException51 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray49);
        java.lang.Object[] objArray52 = maxIterationsExceededException51.getArguments();
        org.apache.commons.math.MathException mathException53 = new org.apache.commons.math.MathException(localizable37, objArray52);
        org.apache.commons.math.exception.util.Localizable localizable55 = null;
        org.apache.commons.math.exception.util.Localizable localizable56 = null;
        java.lang.Object[] objArray60 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException61 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable55, localizable56, objArray60);
        org.apache.commons.math.ConvergenceException convergenceException62 = new org.apache.commons.math.ConvergenceException("", objArray60);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException63 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable37, objArray60);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException67 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (-1.0d), (java.lang.Number) (byte) -1, (java.lang.Number) 4.9E-324d);
        java.lang.Number number68 = outOfRangeException67.getArgument();
        org.apache.commons.math.MathException mathException69 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException67);
        java.lang.Throwable[] throwableArray70 = mathException69.getSuppressed();
        org.apache.commons.math.MathException mathException71 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException23, localizable37, (java.lang.Object[]) throwableArray70);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException72 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, (java.lang.Object[]) throwableArray70);
        java.lang.Class<?> wildcardClass73 = mathIllegalArgumentException72.getClass();
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(localizable11);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "org.apache.commons.math.exception.OutOfRangeException: -1 out of [-1, 0] range" + "'", str24.equals("org.apache.commons.math.exception.OutOfRangeException: -1 out of [-1, 0] range"));
        org.junit.Assert.assertTrue("'" + localizable25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable25.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertNotNull(localizable37);
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertNotNull(objArray52);
        org.junit.Assert.assertNotNull(objArray60);
        org.junit.Assert.assertTrue("'" + number68 + "' != '" + (-1.0d) + "'", number68.equals((-1.0d)));
        org.junit.Assert.assertNotNull(throwableArray70);
        org.junit.Assert.assertNotNull(wildcardClass73);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(359.1342053695754d, (double) 0.0f, 1.8036482179291442E22d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): standard deviation (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 97L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 97 + "'", int1 == 97);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) (byte) 1, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(104.2221698016779d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.009641065706572877d + "'", double1 == 0.009641065706572877d);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(0.9833541737601599d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.009837992849466293d + "'", double1 == 0.009837992849466293d);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.9833541737601599d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (-1.0d), (java.lang.Number) (byte) -1, (java.lang.Number) 4.9E-324d);
        java.lang.Number number4 = outOfRangeException3.getArgument();
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3);
        java.lang.Number number6 = outOfRangeException3.getHi();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-1.0d) + "'", number4.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 4.9E-324d + "'", number6.equals(4.9E-324d));
    }

//    @Test
//    public void test155() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test155");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        long long4 = randomDataImpl0.nextLong((long) 2, 52L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 29L + "'", long4 == 29L);
//    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, localizable3, objArray7);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray7);
        java.lang.Object[] objArray10 = maxIterationsExceededException9.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable11 = maxIterationsExceededException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable13, objArray17);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, objArray17);
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        java.lang.Object[] objArray29 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException30 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable24, localizable25, objArray29);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException31 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray29);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException32 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, "", objArray29);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException33 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, objArray29);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(localizable11);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(objArray29);
    }

//    @Test
//    public void test158() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test158");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int int3 = randomDataImpl0.nextZipf(10, 1.8146000362165722d);
//        randomDataImpl0.reSeed();
//        try {
//            double double7 = randomDataImpl0.nextCauchy((double) 81L, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): scale (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        double double2 = org.apache.commons.math.util.FastMath.max(2.3978952727983707d, 0.062352991014519736d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.3978952727983707d + "'", double2 == 2.3978952727983707d);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        double double1 = org.apache.commons.math.util.FastMath.asin(72.9875457391492d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test161() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test161");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextWeibull(Double.POSITIVE_INFINITY, (double) 52L);
//        double double7 = randomDataImpl0.nextF((double) 81L, (double) 1L);
//        try {
//            randomDataImpl0.setSecureAlgorithm("hi!", "");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: missing provider");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 52.0d + "'", double4 == 52.0d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.396136364860645d + "'", double7 == 4.396136364860645d);
//    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 97L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, localizable3, objArray7);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray7);
        java.lang.Object[] objArray10 = maxIterationsExceededException9.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable11 = maxIterationsExceededException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable13, objArray17);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, objArray17);
        org.apache.commons.math.exception.util.Localizable localizable22 = null;
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable22, localizable23, objArray27);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException29 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray27);
        java.lang.Object[] objArray30 = maxIterationsExceededException29.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable31 = maxIterationsExceededException29.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException35 = new org.apache.commons.math.exception.OutOfRangeException(localizable31, (java.lang.Number) 10L, (java.lang.Number) 97L, (java.lang.Number) 10);
        org.apache.commons.math.exception.util.Localizable localizable38 = null;
        org.apache.commons.math.exception.util.Localizable localizable39 = null;
        java.lang.Object[] objArray43 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException44 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable38, localizable39, objArray43);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException45 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray43);
        java.lang.Object[] objArray46 = maxIterationsExceededException45.getArguments();
        org.apache.commons.math.MathException mathException47 = new org.apache.commons.math.MathException(localizable31, objArray46);
        java.lang.Object[] objArray48 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException49 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable31, objArray48);
        java.lang.Object[] objArray50 = null;
        org.apache.commons.math.MathException mathException51 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException19, localizable31, objArray50);
        org.apache.commons.math.exception.util.Localizable localizable52 = mathIllegalArgumentException19.getSpecificPattern();
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(localizable11);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertNotNull(localizable31);
        org.junit.Assert.assertNotNull(objArray43);
        org.junit.Assert.assertNotNull(objArray46);
        org.junit.Assert.assertNull(localizable52);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        double double2 = org.apache.commons.math.util.FastMath.min((double) '#', (double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 35.0d + "'", double2 == 35.0d);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(58.12552300962247d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 58.125523009622476d + "'", double1 == 58.125523009622476d);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 8);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.0d + "'", double1 == 8.0d);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        normalDistributionImpl0.reseedRandomGenerator(0L);
        double double4 = normalDistributionImpl0.density((-0.428182669496151d));
        double double6 = normalDistributionImpl0.density((double) 100);
        double double7 = normalDistributionImpl0.getMean();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.3639973351338316d + "'", double4 == 0.3639973351338316d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.06048625084551451d, Double.NaN);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

//    @Test
//    public void test169() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test169");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextWeibull(Double.POSITIVE_INFINITY, (double) 52L);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        normalDistributionImpl5.reseedRandomGenerator(0L);
//        double double8 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        try {
//            long long11 = randomDataImpl0.nextLong((long) (byte) 100, 10L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100 is larger than, or equal to, the maximum (10): lower bound (100) must be strictly less than upper bound (10)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 52.0d + "'", double4 == 52.0d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.24046448431044465d + "'", double8 == 0.24046448431044465d);
//    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        double double1 = org.apache.commons.math.util.FastMath.abs(72.9875457391492d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 72.9875457391492d + "'", double1 == 72.9875457391492d);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        int int1 = org.apache.commons.math.util.FastMath.round(0.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        double double1 = org.apache.commons.math.util.FastMath.asinh(345.37940706226686d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.537792819726184d + "'", double1 == 6.537792819726184d);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        double double1 = org.apache.commons.math.util.FastMath.log(Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (-1));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 81L, (float) 56);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 56.0f + "'", float2 == 56.0f);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        double double2 = org.apache.commons.math.util.FastMath.pow(104.2404951098071d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.5809401805942233d, 3.001814241240583d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.018379497154688493d + "'", double2 == 0.018379497154688493d);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        int int2 = org.apache.commons.math.util.FastMath.min(97, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        double double1 = org.apache.commons.math.special.Erf.erf(35.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 100.0f, 0.21068150841353378d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 99.99999999999999d + "'", double2 == 99.99999999999999d);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        double double1 = org.apache.commons.math.util.FastMath.acos(6.798157121994732E43d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        double double1 = org.apache.commons.math.special.Gamma.digamma((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.251752586176186d + "'", double1 == 2.251752586176186d);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(502.4048767883503d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.94970992593418d + "'", double1 == 7.94970992593418d);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.2076448279847295d, (double) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.20764482798472947d + "'", double2 == 0.20764482798472947d);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, localizable3, objArray7);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray7);
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        java.lang.Object[] objArray18 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable13, localizable14, objArray18);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException20 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray18);
        java.lang.Object[] objArray21 = maxIterationsExceededException20.getArguments();
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException9, localizable10, objArray21);
        int int23 = maxIterationsExceededException9.getMaxIterations();
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
    }

//    @Test
//    public void test187() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test187");
//        org.apache.commons.math.exception.util.Localizable localizable2 = null;
//        org.apache.commons.math.exception.util.Localizable localizable3 = null;
//        java.lang.Object[] objArray7 = new java.lang.Object[] { 1L, (byte) -1, 100L };
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, localizable3, objArray7);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray7);
//        java.lang.Object[] objArray10 = maxIterationsExceededException9.getArguments();
//        org.apache.commons.math.exception.util.Localizable localizable11 = maxIterationsExceededException9.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable12 = null;
//        org.apache.commons.math.exception.util.Localizable localizable13 = null;
//        java.lang.Object[] objArray17 = new java.lang.Object[] { 1L, (byte) -1, 100L };
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable13, objArray17);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, objArray17);
//        org.apache.commons.math.exception.util.Localizable localizable22 = null;
//        org.apache.commons.math.exception.util.Localizable localizable23 = null;
//        java.lang.Object[] objArray27 = new java.lang.Object[] { 1L, (byte) -1, 100L };
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable22, localizable23, objArray27);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException29 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray27);
//        java.lang.Object[] objArray30 = maxIterationsExceededException29.getArguments();
//        org.apache.commons.math.exception.util.Localizable localizable31 = maxIterationsExceededException29.getGeneralPattern();
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException35 = new org.apache.commons.math.exception.OutOfRangeException(localizable31, (java.lang.Number) 10L, (java.lang.Number) 97L, (java.lang.Number) 10);
//        org.apache.commons.math.exception.util.Localizable localizable38 = null;
//        org.apache.commons.math.exception.util.Localizable localizable39 = null;
//        java.lang.Object[] objArray43 = new java.lang.Object[] { 1L, (byte) -1, 100L };
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException44 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable38, localizable39, objArray43);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException45 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray43);
//        java.lang.Object[] objArray46 = maxIterationsExceededException45.getArguments();
//        org.apache.commons.math.MathException mathException47 = new org.apache.commons.math.MathException(localizable31, objArray46);
//        java.lang.Object[] objArray48 = null;
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException49 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable31, objArray48);
//        java.lang.Object[] objArray50 = null;
//        org.apache.commons.math.MathException mathException51 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException19, localizable31, objArray50);
//        org.apache.commons.math.exception.util.Localizable localizable55 = null;
//        java.lang.Object[] objArray56 = null;
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException57 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable55, objArray56);
//        org.apache.commons.math.exception.util.Localizable localizable58 = mathIllegalArgumentException57.getGeneralPattern();
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException62 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.2076448279847295d, (java.lang.Number) 1.0E-9d, true);
//        java.lang.Number number63 = null;
//        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException64 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number63);
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl65 = new org.apache.commons.math.random.RandomDataImpl();
//        int int68 = randomDataImpl65.nextZipf(10, 1.8146000362165722d);
//        randomDataImpl65.reSeed();
//        java.lang.Object[] objArray70 = new java.lang.Object[] { 1, 0.21068150841353378d, mathIllegalArgumentException57, numberIsTooSmallException62, number63, randomDataImpl65 };
//        org.apache.commons.math.MathException mathException71 = new org.apache.commons.math.MathException("", objArray70);
//        org.apache.commons.math.ConvergenceException convergenceException72 = new org.apache.commons.math.ConvergenceException(localizable31, objArray70);
//        java.lang.Number number75 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException76 = new org.apache.commons.math.exception.OutOfRangeException(localizable31, (java.lang.Number) 0.06433798016957738d, (java.lang.Number) 82.46601179378642d, number75);
//        org.junit.Assert.assertNotNull(objArray7);
//        org.junit.Assert.assertNotNull(objArray10);
//        org.junit.Assert.assertNotNull(localizable11);
//        org.junit.Assert.assertNotNull(objArray17);
//        org.junit.Assert.assertNotNull(objArray27);
//        org.junit.Assert.assertNotNull(objArray30);
//        org.junit.Assert.assertNotNull(localizable31);
//        org.junit.Assert.assertNotNull(objArray43);
//        org.junit.Assert.assertNotNull(objArray46);
//        org.junit.Assert.assertNull(localizable58);
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 6 + "'", int68 == 6);
//        org.junit.Assert.assertNotNull(objArray70);
//    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        double double1 = org.apache.commons.math.util.FastMath.acosh(485.1720550638632d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.877649699236337d + "'", double1 == 6.877649699236337d);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        double double1 = org.apache.commons.math.util.FastMath.acosh(243.0849990894393d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.186554122391093d + "'", double1 == 6.186554122391093d);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        int int2 = org.apache.commons.math.util.FastMath.max(0, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, localizable3, objArray7);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray7);
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        java.lang.Object[] objArray18 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable13, localizable14, objArray18);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException20 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray18);
        java.lang.Object[] objArray21 = maxIterationsExceededException20.getArguments();
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException9, localizable10, objArray21);
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException9);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(objArray21);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.5d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        double double2 = org.apache.commons.math.util.FastMath.min(0.009837992849466293d, (double) 6);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.009837992849466293d + "'", double2 == 0.009837992849466293d);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.23477947239890198d, 0.5491895702039902d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.868684713990688d + "'", double2 == 0.868684713990688d);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        double double1 = org.apache.commons.math.util.FastMath.asinh(63.54970114954832d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.8450313730170675d + "'", double1 == 4.8450313730170675d);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        normalDistributionImpl0.reseedRandomGenerator(0L);
        try {
            double double5 = normalDistributionImpl0.cumulativeProbability((double) 97, (double) '4');
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 100L, (java.lang.Number) 6.798157121994732E43d, true);
        java.lang.Number number4 = numberIsTooLargeException3.getMax();
        java.lang.Number number5 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 6.798157121994732E43d + "'", number4.equals(6.798157121994732E43d));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 6.798157121994732E43d + "'", number5.equals(6.798157121994732E43d));
    }

//    @Test
//    public void test198() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test198");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextExponential((double) 'a');
//        randomDataImpl0.reSeed(97L);
//        int int7 = randomDataImpl0.nextBinomial((int) (short) 0, 0.5d);
//        try {
//            double double10 = randomDataImpl0.nextGamma((double) 953576077L, (double) 0L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): beta");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.565864894865067d + "'", double2 == 9.565864894865067d);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        normalDistributionImpl0.reseedRandomGenerator(0L);
        double double4 = normalDistributionImpl0.cumulativeProbability(0.0d);
        double double5 = normalDistributionImpl0.getStandardDeviation();
        try {
            double double7 = normalDistributionImpl0.inverseCumulativeProbability((double) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 100 out of [0, 1] range");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.5d + "'", double4 == 0.5d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, localizable3, objArray7);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray7);
        java.lang.Object[] objArray10 = maxIterationsExceededException9.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable11 = maxIterationsExceededException9.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException15 = new org.apache.commons.math.exception.OutOfRangeException(localizable11, (java.lang.Number) 10L, (java.lang.Number) 97L, (java.lang.Number) 10);
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        java.lang.Object[] objArray23 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException24 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable18, localizable19, objArray23);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException25 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray23);
        java.lang.Object[] objArray26 = maxIterationsExceededException25.getArguments();
        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException(localizable11, objArray26);
        org.apache.commons.math.exception.util.Localizable localizable29 = null;
        org.apache.commons.math.exception.util.Localizable localizable30 = null;
        java.lang.Object[] objArray34 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException35 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable29, localizable30, objArray34);
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException("", objArray34);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException37 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, objArray34);
        java.lang.Number number38 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException41 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable11, number38, (java.lang.Number) 7.94970992593418d, true);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(localizable11);
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(objArray34);
    }

//    @Test
//    public void test201() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test201");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextExponential((double) 'a');
//        double double4 = randomDataImpl0.nextExponential(0.2076448279847295d);
//        try {
//            double double7 = randomDataImpl0.nextF(4.211696124154628d, (-1.1752011936438014d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1.175 is smaller than, or equal to, the minimum (0): degrees of freedom (-1.175)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 16.635853466611366d + "'", double2 == 16.635853466611366d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0679562390851727d + "'", double4 == 0.0679562390851727d);
//    }

//    @Test
//    public void test202() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test202");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((-1.4491086207491168d), 104.2404951098071d, (-2.8988930058234654d));
//        double double4 = normalDistributionImpl3.sample();
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 105.58215609079406d + "'", double4 == 105.58215609079406d);
//    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        int int3 = randomDataImpl0.nextZipf(10, 1.8146000362165722d);
        long long5 = randomDataImpl0.nextPoisson(0.23477947239890198d);
        try {
            java.lang.String str7 = randomDataImpl0.nextSecureHexString((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): length (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        long long2 = org.apache.commons.math.util.FastMath.max(0L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, localizable3, objArray7);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray7);
        java.lang.Object[] objArray10 = maxIterationsExceededException9.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable11 = maxIterationsExceededException9.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException15 = new org.apache.commons.math.exception.OutOfRangeException(localizable11, (java.lang.Number) 10L, (java.lang.Number) 97L, (java.lang.Number) 10);
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        java.lang.Object[] objArray23 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException24 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable18, localizable19, objArray23);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException25 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray23);
        java.lang.Object[] objArray26 = maxIterationsExceededException25.getArguments();
        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException(localizable11, objArray26);
        java.lang.Number number29 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException31 = new org.apache.commons.math.exception.OutOfRangeException(localizable11, (java.lang.Number) 0.5849938397131408d, number29, (java.lang.Number) 56.2926043147719d);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(localizable11);
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNotNull(objArray26);
    }

//    @Test
//    public void test206() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test206");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextGaussian((double) 100, (double) (short) 10);
//        randomDataImpl0.reSeed((long) 10);
//        try {
//            double double9 = randomDataImpl0.nextWeibull(6.186554122391093d, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): scale (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 107.12418134797925d + "'", double4 == 107.12418134797925d);
//    }

//    @Test
//    public void test207() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test207");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextExponential((double) 'a');
//        double double5 = randomDataImpl0.nextF(477.01029567022215d, 359.1342053695754d);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 50.65806784738128d + "'", double2 == 50.65806784738128d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.8128892741384737d + "'", double5 == 0.8128892741384737d);
//    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        double double1 = org.apache.commons.math.util.FastMath.rint(35.00000000000001d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 35.0d + "'", double1 == 35.0d);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        float float2 = org.apache.commons.math.util.FastMath.min((float) '#', (float) (byte) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

//    @Test
//    public void test210() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test210");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextExponential((double) 'a');
//        randomDataImpl0.reSeed(97L);
//        int int7 = randomDataImpl0.nextBinomial((int) (short) 0, 0.5d);
//        try {
//            double double10 = randomDataImpl0.nextUniform((-2.8988930058234654d), Double.NEGATIVE_INFINITY);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: -2.899 is larger than, or equal to, the maximum (-∞): lower bound (-2.899) must be strictly less than upper bound (-∞)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 51.24579273568782d + "'", double2 == 51.24579273568782d);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, localizable3, objArray7);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray7);
        java.lang.Object[] objArray10 = maxIterationsExceededException9.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable11 = maxIterationsExceededException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        java.lang.Object[] objArray19 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException20 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable14, localizable15, objArray19);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException21 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray19);
        java.lang.Object[] objArray22 = maxIterationsExceededException21.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable23 = maxIterationsExceededException21.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        java.lang.Object[] objArray29 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException30 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable24, localizable25, objArray29);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException31 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable23, objArray29);
        java.lang.Object[] objArray35 = new java.lang.Object[] { (-1L), 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException("", objArray35);
        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException(localizable23, objArray35);
        org.apache.commons.math.MathException mathException38 = new org.apache.commons.math.MathException(localizable11, objArray35);
        java.lang.Object[] objArray40 = null;
        org.apache.commons.math.MathException mathException41 = new org.apache.commons.math.MathException("org.apache.commons.math.MaxIterationsExceededException: hi!", objArray40);
        java.lang.Object[] objArray46 = new java.lang.Object[] { (-1L), 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException47 = new org.apache.commons.math.ConvergenceException("", objArray46);
        org.apache.commons.math.MathException mathException48 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException41, "org.apache.commons.math.MaxIterationsExceededException: hi!", objArray46);
        java.lang.Throwable[] throwableArray49 = mathException41.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException50 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, (java.lang.Object[]) throwableArray49);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException52 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable11, (java.lang.Number) (short) 0);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(localizable11);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(localizable23);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertNotNull(objArray46);
        org.junit.Assert.assertNotNull(throwableArray49);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        normalDistributionImpl0.reseedRandomGenerator(0L);
        try {
            double double5 = normalDistributionImpl0.cumulativeProbability((double) (short) 100, 1.0d);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ((double) (byte) 10, (double) 2147483647, (double) 10, 32);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 56);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.483314773547883d + "'", double1 == 7.483314773547883d);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (-1.0d), (java.lang.Number) (byte) -1, (java.lang.Number) 4.9E-324d);
        java.lang.String str4 = outOfRangeException3.toString();
        org.apache.commons.math.exception.util.Localizable localizable5 = outOfRangeException3.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, localizable9, objArray13);
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException("", objArray13);
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException("", objArray13);
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException(localizable5, objArray13);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.OutOfRangeException: -1 out of [-1, 0] range" + "'", str4.equals("org.apache.commons.math.exception.OutOfRangeException: -1 out of [-1, 0] range"));
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray13);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, localizable3, objArray7);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray7);
        java.lang.Object[] objArray10 = maxIterationsExceededException9.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable11 = maxIterationsExceededException9.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException15 = new org.apache.commons.math.exception.OutOfRangeException(localizable11, (java.lang.Number) 10L, (java.lang.Number) 97L, (java.lang.Number) 10);
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        java.lang.Object[] objArray23 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException24 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable18, localizable19, objArray23);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException25 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray23);
        java.lang.Object[] objArray26 = maxIterationsExceededException25.getArguments();
        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException(localizable11, objArray26);
        java.lang.Object[] objArray28 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException29 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, objArray28);
        org.apache.commons.math.MathException mathException30 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException29);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException34 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 100L, (java.lang.Number) 6.798157121994732E43d, true);
        java.lang.Number number35 = numberIsTooLargeException34.getMax();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException39 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 70.20706553972083d, (java.lang.Number) 243.0849990894393d, (java.lang.Number) (-1.0d));
        org.apache.commons.math.exception.util.Localizable localizable40 = outOfRangeException39.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable43 = null;
        org.apache.commons.math.exception.util.Localizable localizable44 = null;
        java.lang.Object[] objArray48 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException49 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable43, localizable44, objArray48);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException50 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray48);
        java.lang.Object[] objArray51 = maxIterationsExceededException50.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable52 = maxIterationsExceededException50.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable55 = null;
        org.apache.commons.math.exception.util.Localizable localizable56 = null;
        java.lang.Object[] objArray60 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException61 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable55, localizable56, objArray60);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException62 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray60);
        java.lang.Object[] objArray63 = maxIterationsExceededException62.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable64 = maxIterationsExceededException62.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable65 = null;
        org.apache.commons.math.exception.util.Localizable localizable66 = null;
        java.lang.Object[] objArray70 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException71 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable65, localizable66, objArray70);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException72 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable64, objArray70);
        java.lang.Object[] objArray76 = new java.lang.Object[] { (-1L), 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException77 = new org.apache.commons.math.ConvergenceException("", objArray76);
        org.apache.commons.math.MathException mathException78 = new org.apache.commons.math.MathException(localizable64, objArray76);
        org.apache.commons.math.MathException mathException79 = new org.apache.commons.math.MathException(localizable52, objArray76);
        org.apache.commons.math.ConvergenceException convergenceException80 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException34, localizable40, objArray76);
        org.apache.commons.math.exception.util.Localizable localizable83 = null;
        org.apache.commons.math.exception.util.Localizable localizable84 = null;
        java.lang.Object[] objArray88 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException89 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable83, localizable84, objArray88);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException90 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray88);
        java.lang.Object[] objArray91 = maxIterationsExceededException90.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable92 = maxIterationsExceededException90.getGeneralPattern();
        java.lang.Object[] objArray93 = maxIterationsExceededException90.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException94 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathIllegalArgumentException29, localizable40, objArray93);
        java.lang.String str95 = convergenceException94.toString();
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(localizable11);
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertTrue("'" + number35 + "' != '" + 6.798157121994732E43d + "'", number35.equals(6.798157121994732E43d));
        org.junit.Assert.assertTrue("'" + localizable40 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable40.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray48);
        org.junit.Assert.assertNotNull(objArray51);
        org.junit.Assert.assertNotNull(localizable52);
        org.junit.Assert.assertNotNull(objArray60);
        org.junit.Assert.assertNotNull(objArray63);
        org.junit.Assert.assertNotNull(localizable64);
        org.junit.Assert.assertNotNull(objArray70);
        org.junit.Assert.assertNotNull(objArray76);
        org.junit.Assert.assertNotNull(objArray88);
        org.junit.Assert.assertNotNull(objArray91);
        org.junit.Assert.assertNotNull(localizable92);
        org.junit.Assert.assertNotNull(objArray93);
        org.junit.Assert.assertTrue("'" + str95 + "' != '" + "org.apache.commons.math.ConvergenceException: 1 out of [-1, 100] range" + "'", str95.equals("org.apache.commons.math.ConvergenceException: 1 out of [-1, 100] range"));
    }

//    @Test
//    public void test217() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test217");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) 'a');
//        java.lang.Class<?> wildcardClass3 = randomDataImpl0.getClass();
//        try {
//            int int7 = randomDataImpl0.nextHypergeometric((-1), 3, 85);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): population size (-1)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 111L + "'", long2 == 111L);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) 0.5809401805942233d, (java.lang.Number) 0.5809401805942233d, (java.lang.Number) (byte) 0);
        org.apache.commons.math.exception.util.Localizable localizable5 = outOfRangeException4.getSpecificPattern();
        org.junit.Assert.assertNull(localizable5);
    }

//    @Test
//    public void test219() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test219");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextWeibull(Double.POSITIVE_INFINITY, (double) 52L);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        normalDistributionImpl5.reseedRandomGenerator(0L);
//        double double8 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        double double9 = normalDistributionImpl5.sample();
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 52.0d + "'", double4 == 52.0d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.8449919524961895d) + "'", double8 == (-1.8449919524961895d));
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.8025330637390305d + "'", double9 == 0.8025330637390305d);
//    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        java.lang.Number number0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException(number0, (java.lang.Number) 8, number2);
        java.lang.Number number4 = outOfRangeException3.getHi();
        org.junit.Assert.assertNull(number4);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        double double2 = org.apache.commons.math.util.FastMath.max(1.5707963267948966d, (double) 10L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number0);
        boolean boolean2 = notStrictlyPositiveException1.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable3 = notStrictlyPositiveException1.getGeneralPattern();
        java.lang.Number number4 = notStrictlyPositiveException1.getArgument();
        java.lang.Object[] objArray5 = notStrictlyPositiveException1.getArguments();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + localizable3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable3.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertNotNull(objArray5);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.15506706624860872d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.15383600203082393d + "'", double1 == 0.15383600203082393d);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, localizable3, objArray7);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray7);
        java.lang.Object[] objArray10 = maxIterationsExceededException9.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable11 = maxIterationsExceededException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable13, objArray17);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, objArray17);
        java.lang.Object[] objArray23 = new java.lang.Object[] { (-1L), 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException("", objArray23);
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException(localizable11, objArray23);
        java.lang.String str26 = mathException25.getPattern();
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(localizable11);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "hi!" + "'", str26.equals("hi!"));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        double double1 = org.apache.commons.math.util.FastMath.acosh((-2.8988930058234654d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        normalDistributionImpl0.reseedRandomGenerator(0L);
        double double4 = normalDistributionImpl0.cumulativeProbability(0.0d);
        double double5 = normalDistributionImpl0.getStandardDeviation();
        double double6 = normalDistributionImpl0.getStandardDeviation();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.5d + "'", double4 == 0.5d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(2.47859127706984d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.4785912770698406d + "'", double1 == 2.4785912770698406d);
    }

//    @Test
//    public void test229() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test229");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        int int4 = randomDataImpl0.nextSecureInt((int) (byte) 0, (int) (short) 10);
//        double double7 = randomDataImpl0.nextGaussian((double) 100L, 10.0d);
//        double double9 = randomDataImpl0.nextChiSquare(485.1720550638632d);
//        try {
//            randomDataImpl0.setSecureAlgorithm("org.apache.commons.math.ConvergenceException: 1 out of [-1, 100] range", "hi!");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: hi!");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 9 + "'", int4 == 9);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 104.59212321525561d + "'", double7 == 104.59212321525561d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 483.53311501045135d + "'", double9 == 483.53311501045135d);
//    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        double double2 = org.apache.commons.math.util.FastMath.pow((-1.0d), 1.0422198149762186E-9d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(0.473814720414451d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.625524171540933d + "'", double1 == 0.625524171540933d);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        double double1 = org.apache.commons.math.util.FastMath.acos(4.594700892207039d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 6, (long) 97);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 6L + "'", long2 == 6L);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP((double) 3, 107.61001763972789d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

//    @Test
//    public void test235() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test235");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int int3 = randomDataImpl0.nextZipf(10, 1.8146000362165722d);
//        randomDataImpl0.reSeed();
//        java.lang.String str6 = randomDataImpl0.nextHexString(8);
//        try {
//            java.lang.String str8 = randomDataImpl0.nextHexString((-1));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): length (-1)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "6d5cc24f" + "'", str6.equals("6d5cc24f"));
//    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.2076448279847295d, 0.23477947239890198d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.7772446417474868d + "'", double2 == 0.7772446417474868d);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, localizable3, objArray7);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray7);
        java.lang.Object[] objArray10 = maxIterationsExceededException9.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable11 = maxIterationsExceededException9.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException15 = new org.apache.commons.math.exception.OutOfRangeException(localizable11, (java.lang.Number) 10L, (java.lang.Number) 97L, (java.lang.Number) 10);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException19 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable11, (java.lang.Number) 0.10143992966509834d, (java.lang.Number) (-1.362665681324511d), true);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException23 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable11, (java.lang.Number) 100, (java.lang.Number) 104.2221698016779d, true);
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException23);
        boolean boolean25 = numberIsTooLargeException23.getBoundIsAllowed();
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(localizable11);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
    }

//    @Test
//    public void test238() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test238");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextWeibull(Double.POSITIVE_INFINITY, (double) 52L);
//        long long7 = randomDataImpl0.nextLong(0L, (long) (byte) 1);
//        long long10 = randomDataImpl0.nextSecureLong((long) 1, (long) 2147483647);
//        java.lang.String str12 = randomDataImpl0.nextHexString(56);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 52.0d + "'", double4 == 52.0d);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1920001583L + "'", long10 == 1920001583L);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2dc3862c08d2423eb96b3318c4cb4dc1f6a284a2826146d300e5a85a" + "'", str12.equals("2dc3862c08d2423eb96b3318c4cb4dc1f6a284a2826146d300e5a85a"));
//    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        double double1 = org.apache.commons.math.util.FastMath.sinh(17.10073412299546d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3357478088661466E7d + "'", double1 == 1.3357478088661466E7d);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        long long2 = org.apache.commons.math.util.FastMath.min(29L, (long) (-1));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        double double1 = org.apache.commons.math.util.FastMath.atan(309.97881155475915d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5675703110361978d + "'", double1 == 1.5675703110361978d);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.7772446417474868d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.17546980115622d + "'", double1 == 2.17546980115622d);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (-1.0d), (java.lang.Number) (byte) -1, (java.lang.Number) 4.9E-324d);
        java.lang.String str4 = outOfRangeException3.toString();
        org.apache.commons.math.exception.util.Localizable localizable5 = outOfRangeException3.getGeneralPattern();
        java.lang.Number number6 = outOfRangeException3.getLo();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.OutOfRangeException: -1 out of [-1, 0] range" + "'", str4.equals("org.apache.commons.math.exception.OutOfRangeException: -1 out of [-1, 0] range"));
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (byte) -1 + "'", number6.equals((byte) -1));
    }

//    @Test
//    public void test244() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test244");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextExponential((double) 'a');
//        double double4 = randomDataImpl0.nextExponential(0.2076448279847295d);
//        double double6 = randomDataImpl0.nextT(1.0d);
//        long long9 = randomDataImpl0.nextSecureLong((long) (byte) -1, (long) 2147483647);
//        double double12 = randomDataImpl0.nextF((double) 81L, 0.2076448279847295d);
//        double double15 = randomDataImpl0.nextWeibull(100.92781056272442d, (double) 3);
//        try {
//            int int18 = randomDataImpl0.nextSecureInt((int) ' ', (int) (byte) 10);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 32 is larger than, or equal to, the maximum (10): lower bound (32) must be strictly less than upper bound (10)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 29.80668747556958d + "'", double2 == 29.80668747556958d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05132759420582875d + "'", double4 == 0.05132759420582875d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-37.0614786534461d) + "'", double6 == (-37.0614786534461d));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2106119685L + "'", long9 == 2106119685L);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 20.859936414801766d + "'", double12 == 20.859936414801766d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 2.9868242348386125d + "'", double15 == 2.9868242348386125d);
//    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        double double2 = org.apache.commons.math.util.FastMath.max(55.87364823673484d, (double) 81L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 81.0d + "'", double2 == 81.0d);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double2 = normalDistributionImpl0.density(57.9674416413573d);
        double double5 = normalDistributionImpl0.cumulativeProbability((double) 8, (double) 81L);
        normalDistributionImpl0.reseedRandomGenerator(0L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 6.661338147750939E-16d + "'", double5 == 6.661338147750939E-16d);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.993222846126381d + "'", double1 == 2.993222846126381d);
    }

//    @Test
//    public void test248() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test248");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextExponential((double) 'a');
//        double double4 = randomDataImpl0.nextExponential(0.2076448279847295d);
//        double double6 = randomDataImpl0.nextT(1.0d);
//        try {
//            java.lang.String str8 = randomDataImpl0.nextSecureHexString(0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): length (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 36.57096672924838d + "'", double2 == 36.57096672924838d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.1283158278058864d + "'", double4 == 0.1283158278058864d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-0.3848470826720772d) + "'", double6 == (-0.3848470826720772d));
//    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        double double1 = org.apache.commons.math.util.FastMath.ulp(6.877649699236337d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.881784197001252E-16d + "'", double1 == 8.881784197001252E-16d);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        double double1 = org.apache.commons.math.util.FastMath.asin((-1.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5707963267948966d) + "'", double1 == (-1.5707963267948966d));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        try {
            randomDataImpl0.setSecureAlgorithm("24945e41", "24945e41");
            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: 24945e41");
        } catch (java.security.NoSuchProviderException e) {
        }
    }

//    @Test
//    public void test252() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test252");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextGaussian((double) 100, (double) (short) 10);
//        double double6 = randomDataImpl0.nextT(1.7724538509055159d);
//        double double8 = randomDataImpl0.nextChiSquare(40.34361551018096d);
//        double double10 = randomDataImpl0.nextChiSquare(0.00536757350748316d);
//        try {
//            double double13 = randomDataImpl0.nextBeta(0.0d, 54.78355549192687d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.5 p = 0.881");
//        } catch (org.apache.commons.math.exception.MathUserException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 101.31387814390504d + "'", double4 == 101.31387814390504d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.5181956469916298d + "'", double6 == 1.5181956469916298d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 39.42432114424741d + "'", double8 == 39.42432114424741d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.1564559197317552E-9d + "'", double10 == 1.1564559197317552E-9d);
//    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(403.16300718841666d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

//    @Test
//    public void test254() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test254");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextWeibull(Double.POSITIVE_INFINITY, (double) 52L);
//        long long7 = randomDataImpl0.nextSecureLong(0L, (long) 2);
//        try {
//            double double9 = randomDataImpl0.nextChiSquare((double) 0.0f);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): alpha");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 52.0d + "'", double4 == 52.0d);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
//    }

//    @Test
//    public void test255() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test255");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextGaussian((double) 100, (double) (short) 10);
//        try {
//            int int7 = randomDataImpl0.nextPascal(0, (double) 100L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 100 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 105.44837389665666d + "'", double4 == 105.44837389665666d);
//    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.15506706624860872d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4151009863938164d + "'", double1 == 1.4151009863938164d);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        double double1 = org.apache.commons.math.util.FastMath.expm1(4.594700892207039d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 97.95853185248363d + "'", double1 == 97.95853185248363d);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        long long2 = org.apache.commons.math.util.FastMath.max(0L, (long) 7);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 7L + "'", long2 == 7L);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        normalDistributionImpl0.reseedRandomGenerator(0L);
        double double4 = normalDistributionImpl0.cumulativeProbability(0.0d);
        double double5 = normalDistributionImpl0.getStandardDeviation();
        double double7 = normalDistributionImpl0.density(0.0d);
        double double9 = normalDistributionImpl0.cumulativeProbability((double) (-1));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.5d + "'", double4 == 0.5d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.3989422804014327d + "'", double7 == 0.3989422804014327d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.15865525393145702d + "'", double9 == 0.15865525393145702d);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(97);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, localizable4, objArray8);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException10 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray8);
        java.lang.Object[] objArray11 = maxIterationsExceededException10.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable12 = maxIterationsExceededException10.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        java.lang.Object[] objArray18 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable13, localizable14, objArray18);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException20 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, objArray18);
        java.lang.Object[] objArray24 = new java.lang.Object[] { (-1L), 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException25 = new org.apache.commons.math.ConvergenceException("", objArray24);
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException(localizable12, objArray24);
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException(localizable0, objArray24);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(localizable12);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(objArray24);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        int int3 = randomDataImpl0.nextZipf(10, 1.8146000362165722d);
        long long5 = randomDataImpl0.nextPoisson(0.23477947239890198d);
        try {
            double double7 = randomDataImpl0.nextChiSquare((-1.5574077246549023d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.779 is smaller than, or equal to, the minimum (0): alpha");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        double double2 = org.apache.commons.math.util.FastMath.max(1.0d, 0.009641065706572877d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

//    @Test
//    public void test264() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test264");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) 'a');
//        randomDataImpl0.reSeedSecure();
//        double double5 = randomDataImpl0.nextChiSquare(107.61001763972789d);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 99.07256892495049d + "'", double5 == 99.07256892495049d);
//    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number1);
        java.lang.Object[] objArray3 = notStrictlyPositiveException2.getArguments();
        org.apache.commons.math.MathException mathException4 = new org.apache.commons.math.MathException("", objArray3);
        java.lang.String str5 = mathException4.getPattern();
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, localizable4, objArray8);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException10 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray8);
        java.lang.Object[] objArray11 = maxIterationsExceededException10.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException12 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, objArray11);
        java.lang.Object[] objArray14 = null;
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException12, "org.apache.commons.math.ConvergenceException: 1 out of [-1, 100] range", objArray14);
        java.lang.Object[] objArray16 = mathException15.getArguments();
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(objArray16);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, localizable3, objArray7);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray7);
        java.lang.Object[] objArray10 = maxIterationsExceededException9.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable11 = maxIterationsExceededException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable13, objArray17);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, objArray17);
        org.apache.commons.math.exception.util.Localizable localizable22 = null;
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable22, localizable23, objArray27);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException29 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray27);
        java.lang.Object[] objArray30 = maxIterationsExceededException29.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable31 = maxIterationsExceededException29.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException35 = new org.apache.commons.math.exception.OutOfRangeException(localizable31, (java.lang.Number) 10L, (java.lang.Number) 97L, (java.lang.Number) 10);
        org.apache.commons.math.exception.util.Localizable localizable38 = null;
        org.apache.commons.math.exception.util.Localizable localizable39 = null;
        java.lang.Object[] objArray43 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException44 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable38, localizable39, objArray43);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException45 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray43);
        java.lang.Object[] objArray46 = maxIterationsExceededException45.getArguments();
        org.apache.commons.math.MathException mathException47 = new org.apache.commons.math.MathException(localizable31, objArray46);
        java.lang.Object[] objArray48 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException49 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable31, objArray48);
        java.lang.Object[] objArray50 = null;
        org.apache.commons.math.MathException mathException51 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException19, localizable31, objArray50);
        java.lang.Throwable throwable53 = null;
        org.apache.commons.math.exception.util.Localizable localizable56 = null;
        org.apache.commons.math.exception.util.Localizable localizable57 = null;
        java.lang.Object[] objArray61 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException62 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable56, localizable57, objArray61);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException63 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray61);
        java.lang.Object[] objArray64 = maxIterationsExceededException63.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable65 = maxIterationsExceededException63.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable68 = null;
        org.apache.commons.math.exception.util.Localizable localizable69 = null;
        java.lang.Object[] objArray73 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException74 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable68, localizable69, objArray73);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException75 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray73);
        java.lang.Object[] objArray76 = maxIterationsExceededException75.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable77 = maxIterationsExceededException75.getGeneralPattern();
        java.lang.Object[] objArray78 = maxIterationsExceededException75.getArguments();
        org.apache.commons.math.MathException mathException79 = new org.apache.commons.math.MathException(throwable53, localizable65, objArray78);
        org.apache.commons.math.ConvergenceException convergenceException80 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException51, "org.apache.commons.math.ConvergenceException: 1 out of [-1, 100] range", objArray78);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(localizable11);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertNotNull(localizable31);
        org.junit.Assert.assertNotNull(objArray43);
        org.junit.Assert.assertNotNull(objArray46);
        org.junit.Assert.assertNotNull(objArray61);
        org.junit.Assert.assertNotNull(objArray64);
        org.junit.Assert.assertNotNull(localizable65);
        org.junit.Assert.assertNotNull(objArray73);
        org.junit.Assert.assertNotNull(objArray76);
        org.junit.Assert.assertNotNull(localizable77);
        org.junit.Assert.assertNotNull(objArray78);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.MathException mathException1 = new org.apache.commons.math.MathException(throwable0);
        java.lang.Object[] objArray2 = mathException1.getArguments();
        org.junit.Assert.assertNotNull(objArray2);
    }

//    @Test
//    public void test269() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test269");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextWeibull(Double.POSITIVE_INFINITY, (double) 52L);
//        long long7 = randomDataImpl0.nextSecureLong(0L, (long) 2);
//        try {
//            double double10 = randomDataImpl0.nextGaussian((-1.362665681324511d), Double.NEGATIVE_INFINITY);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -∞ is smaller than, or equal to, the minimum (0): standard deviation (-∞)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 52.0d + "'", double4 == 52.0d);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
//    }

//    @Test
//    public void test270() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test270");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        int int4 = randomDataImpl0.nextSecureInt((int) (byte) 0, (int) (short) 10);
//        double double7 = randomDataImpl0.nextGaussian((double) 100L, 10.0d);
//        try {
//            double double9 = randomDataImpl0.nextT(1.8036482179291442E22d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument -1 p = 0.606");
//        } catch (org.apache.commons.math.exception.MathUserException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 106.93426338313549d + "'", double7 == 106.93426338313549d);
//    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.6881171418161356E43d + "'", double1 == 2.6881171418161356E43d);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 115896081L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.1589608E8f + "'", float1 == 1.1589608E8f);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        double double2 = org.apache.commons.math.util.FastMath.atan2(70.20706553972083d, 55.87364823673484d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.8985966235562164d + "'", double2 == 0.8985966235562164d);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, localizable3, objArray7);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray7);
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        java.lang.Object[] objArray18 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable13, localizable14, objArray18);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException20 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray18);
        java.lang.Object[] objArray21 = maxIterationsExceededException20.getArguments();
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException9, localizable10, objArray21);
        try {
            java.lang.String str23 = mathException22.getPattern();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(objArray21);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        double double1 = org.apache.commons.math.util.FastMath.acos(105.25636095684777d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test276() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test276");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        int int4 = randomDataImpl0.nextSecureInt((int) (byte) 0, (int) (short) 10);
//        double double7 = randomDataImpl0.nextGaussian((double) 100L, 10.0d);
//        double double9 = randomDataImpl0.nextChiSquare(485.1720550638632d);
//        int int12 = randomDataImpl0.nextPascal(10, 0.0d);
//        try {
//            double double15 = randomDataImpl0.nextGamma(0.0d, 82.46601179378642d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): alpha");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.21443471963349d + "'", double7 == 100.21443471963349d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 488.8611560385218d + "'", double9 == 488.8611560385218d);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2147483647 + "'", int12 == 2147483647);
//    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        int int2 = org.apache.commons.math.util.FastMath.min(56, 85);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 56 + "'", int2 == 56);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(85.33849662946932d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.237883774407932d + "'", double1 == 9.237883774407932d);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.20369724111510376d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

//    @Test
//    public void test280() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test280");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int int3 = randomDataImpl0.nextZipf(10, 1.8146000362165722d);
//        randomDataImpl0.reSeed();
//        java.lang.String str6 = randomDataImpl0.nextHexString(8);
//        try {
//            double double8 = randomDataImpl0.nextExponential(0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): mean (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "ecec4491" + "'", str6.equals("ecec4491"));
//    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        long long2 = org.apache.commons.math.util.FastMath.min(1920001583L, 1648137059L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1648137059L + "'", long2 == 1648137059L);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (byte) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.8025330637390305d, (double) 115896081L);
        double double5 = normalDistributionImpl2.cumulativeProbability(2.220446049250313E-16d, (double) 29L);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 9.982499865612837E-8d + "'", double5 == 9.982499865612837E-8d);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        normalDistributionImpl0.reseedRandomGenerator(0L);
        double double3 = normalDistributionImpl0.getStandardDeviation();
        double double4 = normalDistributionImpl0.getMean();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

//    @Test
//    public void test286() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test286");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int int3 = randomDataImpl0.nextZipf(10, 1.8146000362165722d);
//        long long5 = randomDataImpl0.nextPoisson(0.23477947239890198d);
//        double double8 = randomDataImpl0.nextUniform((double) (byte) 10, 485.1720550638632d);
//        try {
//            int int12 = randomDataImpl0.nextHypergeometric((int) (byte) -1, (int) (byte) -1, 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): population size (-1)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 323.280960996207d + "'", double8 == 323.280960996207d);
//    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 100L, (java.lang.Number) 6.798157121994732E43d, true);
        java.lang.Number number4 = numberIsTooLargeException3.getMax();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException8 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 70.20706553972083d, (java.lang.Number) 243.0849990894393d, (java.lang.Number) (-1.0d));
        org.apache.commons.math.exception.util.Localizable localizable9 = outOfRangeException8.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable13, objArray17);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException19 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray17);
        java.lang.Object[] objArray20 = maxIterationsExceededException19.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable21 = maxIterationsExceededException19.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        java.lang.Object[] objArray29 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException30 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable24, localizable25, objArray29);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException31 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray29);
        java.lang.Object[] objArray32 = maxIterationsExceededException31.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable33 = maxIterationsExceededException31.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable34 = null;
        org.apache.commons.math.exception.util.Localizable localizable35 = null;
        java.lang.Object[] objArray39 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException40 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable34, localizable35, objArray39);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException41 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable33, objArray39);
        java.lang.Object[] objArray45 = new java.lang.Object[] { (-1L), 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException("", objArray45);
        org.apache.commons.math.MathException mathException47 = new org.apache.commons.math.MathException(localizable33, objArray45);
        org.apache.commons.math.MathException mathException48 = new org.apache.commons.math.MathException(localizable21, objArray45);
        org.apache.commons.math.ConvergenceException convergenceException49 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException3, localizable9, objArray45);
        org.apache.commons.math.exception.util.Localizable localizable50 = numberIsTooLargeException3.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 6.798157121994732E43d + "'", number4.equals(6.798157121994732E43d));
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(localizable21);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(localizable33);
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertNotNull(objArray45);
        org.junit.Assert.assertNull(localizable50);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 70.20706553972083d, (java.lang.Number) 243.0849990894393d, (java.lang.Number) (-1.0d));
        org.apache.commons.math.exception.util.Localizable localizable4 = outOfRangeException3.getGeneralPattern();
        java.lang.Number number5 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException8 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable4, number5, (java.lang.Number) 8.0d, false);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException12 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable4, (java.lang.Number) (byte) 0, (java.lang.Number) 16.20317595417168d, false);
        boolean boolean13 = numberIsTooLargeException12.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

//    @Test
//    public void test289() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test289");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextWeibull(Double.POSITIVE_INFINITY, (double) 52L);
//        double double7 = randomDataImpl0.nextF((double) 81L, (double) 1L);
//        int int10 = randomDataImpl0.nextSecureInt((int) (byte) -1, 100);
//        double double13 = randomDataImpl0.nextBeta(0.7178896490901561d, 0.10968186267255918d);
//        try {
//            int int16 = randomDataImpl0.nextInt(11, 1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 11 is larger than, or equal to, the maximum (1): lower bound (11) must be strictly less than upper bound (1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 52.0d + "'", double4 == 52.0d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.8524559851965247d + "'", double7 == 0.8524559851965247d);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 45 + "'", int10 == 45);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.9979041615280712d + "'", double13 == 0.9979041615280712d);
//    }

//    @Test
//    public void test290() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test290");
//        org.apache.commons.math.exception.util.Localizable localizable2 = null;
//        org.apache.commons.math.exception.util.Localizable localizable3 = null;
//        java.lang.Object[] objArray7 = new java.lang.Object[] { 1L, (byte) -1, 100L };
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, localizable3, objArray7);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray7);
//        java.lang.Object[] objArray10 = maxIterationsExceededException9.getArguments();
//        org.apache.commons.math.exception.util.Localizable localizable11 = maxIterationsExceededException9.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable12 = null;
//        org.apache.commons.math.exception.util.Localizable localizable13 = null;
//        java.lang.Object[] objArray17 = new java.lang.Object[] { 1L, (byte) -1, 100L };
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable13, objArray17);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, objArray17);
//        org.apache.commons.math.exception.util.Localizable localizable22 = null;
//        org.apache.commons.math.exception.util.Localizable localizable23 = null;
//        java.lang.Object[] objArray27 = new java.lang.Object[] { 1L, (byte) -1, 100L };
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable22, localizable23, objArray27);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException29 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray27);
//        java.lang.Object[] objArray30 = maxIterationsExceededException29.getArguments();
//        org.apache.commons.math.exception.util.Localizable localizable31 = maxIterationsExceededException29.getGeneralPattern();
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException35 = new org.apache.commons.math.exception.OutOfRangeException(localizable31, (java.lang.Number) 10L, (java.lang.Number) 97L, (java.lang.Number) 10);
//        org.apache.commons.math.exception.util.Localizable localizable38 = null;
//        org.apache.commons.math.exception.util.Localizable localizable39 = null;
//        java.lang.Object[] objArray43 = new java.lang.Object[] { 1L, (byte) -1, 100L };
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException44 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable38, localizable39, objArray43);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException45 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray43);
//        java.lang.Object[] objArray46 = maxIterationsExceededException45.getArguments();
//        org.apache.commons.math.MathException mathException47 = new org.apache.commons.math.MathException(localizable31, objArray46);
//        java.lang.Object[] objArray48 = null;
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException49 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable31, objArray48);
//        java.lang.Object[] objArray50 = null;
//        org.apache.commons.math.MathException mathException51 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException19, localizable31, objArray50);
//        org.apache.commons.math.exception.util.Localizable localizable55 = null;
//        java.lang.Object[] objArray56 = null;
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException57 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable55, objArray56);
//        org.apache.commons.math.exception.util.Localizable localizable58 = mathIllegalArgumentException57.getGeneralPattern();
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException62 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.2076448279847295d, (java.lang.Number) 1.0E-9d, true);
//        java.lang.Number number63 = null;
//        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException64 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number63);
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl65 = new org.apache.commons.math.random.RandomDataImpl();
//        int int68 = randomDataImpl65.nextZipf(10, 1.8146000362165722d);
//        randomDataImpl65.reSeed();
//        java.lang.Object[] objArray70 = new java.lang.Object[] { 1, 0.21068150841353378d, mathIllegalArgumentException57, numberIsTooSmallException62, number63, randomDataImpl65 };
//        org.apache.commons.math.MathException mathException71 = new org.apache.commons.math.MathException("", objArray70);
//        org.apache.commons.math.ConvergenceException convergenceException72 = new org.apache.commons.math.ConvergenceException(localizable31, objArray70);
//        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException74 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable31, (java.lang.Number) 113.45520928773641d);
//        org.junit.Assert.assertNotNull(objArray7);
//        org.junit.Assert.assertNotNull(objArray10);
//        org.junit.Assert.assertNotNull(localizable11);
//        org.junit.Assert.assertNotNull(objArray17);
//        org.junit.Assert.assertNotNull(objArray27);
//        org.junit.Assert.assertNotNull(objArray30);
//        org.junit.Assert.assertNotNull(localizable31);
//        org.junit.Assert.assertNotNull(objArray43);
//        org.junit.Assert.assertNotNull(objArray46);
//        org.junit.Assert.assertNull(localizable58);
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 1 + "'", int68 == 1);
//        org.junit.Assert.assertNotNull(objArray70);
//    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray5 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException6 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray5);
        org.apache.commons.math.MathException mathException7 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException6);
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        java.lang.Object[] objArray15 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException16 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable10, localizable11, objArray15);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException17 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray15);
        java.lang.Object[] objArray18 = maxIterationsExceededException17.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable19 = maxIterationsExceededException17.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        org.apache.commons.math.exception.util.Localizable localizable21 = null;
        java.lang.Object[] objArray25 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException26 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable20, localizable21, objArray25);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException27 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable19, objArray25);
        java.lang.Object[] objArray31 = new java.lang.Object[] { (-1L), 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException("", objArray31);
        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException(localizable19, objArray31);
        java.lang.Number number35 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException36 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number35);
        java.lang.Object[] objArray37 = notStrictlyPositiveException36.getArguments();
        org.apache.commons.math.MathException mathException38 = new org.apache.commons.math.MathException("", objArray37);
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException(localizable19, objArray37);
        org.apache.commons.math.MathException mathException40 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException39);
        mathException7.addSuppressed((java.lang.Throwable) convergenceException39);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(localizable19);
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(objArray37);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.03347575746311028d, (double) 1L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0075936007973075315d + "'", double2 == 0.0075936007973075315d);
    }

//    @Test
//    public void test293() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test293");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextWeibull(Double.POSITIVE_INFINITY, (double) 52L);
//        double double6 = randomDataImpl0.nextChiSquare((double) 91L);
//        double double9 = randomDataImpl0.nextUniform(0.5809401805942233d, (double) 'a');
//        int int12 = randomDataImpl0.nextSecureInt(0, (int) (byte) 10);
//        double double14 = randomDataImpl0.nextT(55.01184692959797d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 52.0d + "'", double4 == 52.0d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.1711455688407d + "'", double6 == 100.1711455688407d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 62.13648399124318d + "'", double9 == 62.13648399124318d);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 7 + "'", int12 == 7);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-0.5917507542640688d) + "'", double14 == (-0.5917507542640688d));
//    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.8025330637390305d, (double) 115896081L);
        double double4 = normalDistributionImpl2.density(1.7724538509055159d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 3.4422413334358794E-9d + "'", double4 == 3.4422413334358794E-9d);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(57.967441641357304d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): standard deviation (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, localizable3, objArray7);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray7);
        java.lang.Object[] objArray10 = maxIterationsExceededException9.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable11 = maxIterationsExceededException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable13, objArray17);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, objArray17);
        java.lang.Number number20 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException23 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable11, number20, (java.lang.Number) (byte) -1, true);
        java.lang.Number number24 = numberIsTooLargeException23.getArgument();
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(localizable11);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNull(number24);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double2 = normalDistributionImpl0.density(57.9674416413573d);
        double double5 = normalDistributionImpl0.cumulativeProbability((double) 8, (double) 81L);
        try {
            double double8 = normalDistributionImpl0.cumulativeProbability((double) 6L, 8.881784197001252E-16d);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 6.661338147750939E-16d + "'", double5 == 6.661338147750939E-16d);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number0);
        java.lang.Object[] objArray2 = notStrictlyPositiveException1.getArguments();
        java.lang.Number number3 = notStrictlyPositiveException1.getArgument();
        java.lang.Number number4 = notStrictlyPositiveException1.getMin();
        java.lang.Throwable[] throwableArray5 = notStrictlyPositiveException1.getSuppressed();
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0 + "'", number4.equals(0));
        org.junit.Assert.assertNotNull(throwableArray5);
    }

//    @Test
//    public void test300() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test300");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int int3 = randomDataImpl0.nextZipf(10, 1.8146000362165722d);
//        try {
//            randomDataImpl0.setSecureAlgorithm("hi!", "43bd51");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: 43bd51");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException3 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, "24945e41", objArray2);
    }

//    @Test
//    public void test302() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test302");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextExponential((double) 'a');
//        randomDataImpl0.reSeed(97L);
//        try {
//            int int8 = randomDataImpl0.nextHypergeometric(11, (int) 'a', 11);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 97 is larger than the maximum (11): number of successes (97) must be less than or equal to population size (11)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 95.89287830092759d + "'", double2 == 95.89287830092759d);
//    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        double double1 = org.apache.commons.math.special.Gamma.trigamma((double) 6);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.1813229557370451d + "'", double1 == 0.1813229557370451d);
    }

//    @Test
//    public void test304() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test304");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextExponential((double) 'a');
//        randomDataImpl0.reSeed(97L);
//        java.lang.String str6 = randomDataImpl0.nextSecureHexString(6);
//        try {
//            double double9 = randomDataImpl0.nextF(58.125523009622476d, (-5.624687843428728d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -5.625 is smaller than, or equal to, the minimum (0): degrees of freedom (-5.625)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 96.59598442828698d + "'", double2 == 96.59598442828698d);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2b8ded" + "'", str6.equals("2b8ded"));
//    }

//    @Test
//    public void test305() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test305");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int int3 = randomDataImpl0.nextZipf(10, 1.8146000362165722d);
//        randomDataImpl0.reSeedSecure((long) (short) 0);
//        try {
//            int int8 = randomDataImpl0.nextSecureInt(2147483647, (int) (byte) 100);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 2,147,483,647 is larger than, or equal to, the maximum (100): lower bound (2,147,483,647) must be strictly less than upper bound (100)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (-1.0d), (java.lang.Number) (byte) -1, (java.lang.Number) 4.9E-324d);
        java.lang.Number number4 = outOfRangeException3.getArgument();
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3);
        java.lang.Throwable[] throwableArray6 = mathException5.getSuppressed();
        java.lang.Throwable throwable7 = null;
        try {
            mathException5.addSuppressed(throwable7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-1.0d) + "'", number4.equals((-1.0d)));
        org.junit.Assert.assertNotNull(throwableArray6);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, localizable3, objArray7);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray7);
        java.lang.Object[] objArray10 = maxIterationsExceededException9.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable11 = maxIterationsExceededException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable13, objArray17);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, objArray17);
        java.lang.Number number20 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException23 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable11, number20, (java.lang.Number) (byte) -1, true);
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        org.apache.commons.math.exception.util.Localizable localizable27 = null;
        java.lang.Object[] objArray31 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException32 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable26, localizable27, objArray31);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException33 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray31);
        java.lang.Object[] objArray34 = maxIterationsExceededException33.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable35 = maxIterationsExceededException33.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException39 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable35, (java.lang.Number) 0.0f, (java.lang.Number) 10.0f, false);
        org.apache.commons.math.exception.util.Localizable localizable42 = null;
        org.apache.commons.math.exception.util.Localizable localizable43 = null;
        java.lang.Object[] objArray47 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException48 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable42, localizable43, objArray47);
        org.apache.commons.math.ConvergenceException convergenceException49 = new org.apache.commons.math.ConvergenceException("", objArray47);
        org.apache.commons.math.ConvergenceException convergenceException50 = new org.apache.commons.math.ConvergenceException("", objArray47);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException51 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable35, objArray47);
        java.lang.Number number53 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException55 = new org.apache.commons.math.exception.OutOfRangeException(localizable11, (java.lang.Number) 6, number53, (java.lang.Number) 0.20369724111510376d);
        java.lang.Number number57 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException59 = new org.apache.commons.math.exception.OutOfRangeException(localizable11, (java.lang.Number) 94L, number57, (java.lang.Number) 1.1589608E8f);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(localizable11);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(localizable35);
        org.junit.Assert.assertNotNull(objArray47);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        double double1 = org.apache.commons.math.util.FastMath.expm1(6.186554122391093d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 485.1679412764894d + "'", double1 == 485.1679412764894d);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        double double1 = org.apache.commons.math.util.FastMath.atan((-1.5707963267948966d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0038848218538872d) + "'", double1 == (-1.0038848218538872d));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.20369724111510376d, (java.lang.Number) 0.15383600203082393d, false);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 6L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(3.001814241240583d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4425402437928183d + "'", double1 == 1.4425402437928183d);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((-0.5917507542640688d), 4.137975203405834d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.5917507542640686d) + "'", double2 == (-0.5917507542640686d));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.8985966235562164d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.456153783008741d + "'", double1 == 2.456153783008741d);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        double double1 = org.apache.commons.math.util.FastMath.tanh(73.30466172043384d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, localizable3, objArray7);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray7);
        java.lang.Object[] objArray10 = maxIterationsExceededException9.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable11 = maxIterationsExceededException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable13, objArray17);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, objArray17);
        java.lang.Object[] objArray20 = mathIllegalArgumentException19.getArguments();
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(localizable11);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(objArray20);
    }

//    @Test
//    public void test317() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test317");
//        org.apache.commons.math.exception.util.Localizable localizable2 = null;
//        org.apache.commons.math.exception.util.Localizable localizable3 = null;
//        java.lang.Object[] objArray7 = new java.lang.Object[] { 1L, (byte) -1, 100L };
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, localizable3, objArray7);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray7);
//        java.lang.Object[] objArray10 = maxIterationsExceededException9.getArguments();
//        org.apache.commons.math.exception.util.Localizable localizable11 = maxIterationsExceededException9.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable12 = null;
//        org.apache.commons.math.exception.util.Localizable localizable13 = null;
//        java.lang.Object[] objArray17 = new java.lang.Object[] { 1L, (byte) -1, 100L };
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable13, objArray17);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, objArray17);
//        org.apache.commons.math.exception.util.Localizable localizable22 = null;
//        org.apache.commons.math.exception.util.Localizable localizable23 = null;
//        java.lang.Object[] objArray27 = new java.lang.Object[] { 1L, (byte) -1, 100L };
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable22, localizable23, objArray27);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException29 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray27);
//        java.lang.Object[] objArray30 = maxIterationsExceededException29.getArguments();
//        org.apache.commons.math.exception.util.Localizable localizable31 = maxIterationsExceededException29.getGeneralPattern();
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException35 = new org.apache.commons.math.exception.OutOfRangeException(localizable31, (java.lang.Number) 10L, (java.lang.Number) 97L, (java.lang.Number) 10);
//        org.apache.commons.math.exception.util.Localizable localizable38 = null;
//        org.apache.commons.math.exception.util.Localizable localizable39 = null;
//        java.lang.Object[] objArray43 = new java.lang.Object[] { 1L, (byte) -1, 100L };
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException44 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable38, localizable39, objArray43);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException45 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray43);
//        java.lang.Object[] objArray46 = maxIterationsExceededException45.getArguments();
//        org.apache.commons.math.MathException mathException47 = new org.apache.commons.math.MathException(localizable31, objArray46);
//        java.lang.Object[] objArray48 = null;
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException49 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable31, objArray48);
//        java.lang.Object[] objArray50 = null;
//        org.apache.commons.math.MathException mathException51 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException19, localizable31, objArray50);
//        org.apache.commons.math.exception.util.Localizable localizable55 = null;
//        java.lang.Object[] objArray56 = null;
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException57 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable55, objArray56);
//        org.apache.commons.math.exception.util.Localizable localizable58 = mathIllegalArgumentException57.getGeneralPattern();
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException62 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.2076448279847295d, (java.lang.Number) 1.0E-9d, true);
//        java.lang.Number number63 = null;
//        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException64 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number63);
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl65 = new org.apache.commons.math.random.RandomDataImpl();
//        int int68 = randomDataImpl65.nextZipf(10, 1.8146000362165722d);
//        randomDataImpl65.reSeed();
//        java.lang.Object[] objArray70 = new java.lang.Object[] { 1, 0.21068150841353378d, mathIllegalArgumentException57, numberIsTooSmallException62, number63, randomDataImpl65 };
//        org.apache.commons.math.MathException mathException71 = new org.apache.commons.math.MathException("", objArray70);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException72 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable31, objArray70);
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException76 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable31, (java.lang.Number) 0.10143992966509834d, (java.lang.Number) 1.0f, true);
//        org.junit.Assert.assertNotNull(objArray7);
//        org.junit.Assert.assertNotNull(objArray10);
//        org.junit.Assert.assertNotNull(localizable11);
//        org.junit.Assert.assertNotNull(objArray17);
//        org.junit.Assert.assertNotNull(objArray27);
//        org.junit.Assert.assertNotNull(objArray30);
//        org.junit.Assert.assertNotNull(localizable31);
//        org.junit.Assert.assertNotNull(objArray43);
//        org.junit.Assert.assertNotNull(objArray46);
//        org.junit.Assert.assertNull(localizable58);
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 1 + "'", int68 == 1);
//        org.junit.Assert.assertNotNull(objArray70);
//    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        double double1 = org.apache.commons.math.util.FastMath.floor(73.30466172043384d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 73.0d + "'", double1 == 73.0d);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, localizable3, objArray7);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray7);
        java.lang.Object[] objArray10 = maxIterationsExceededException9.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable11 = maxIterationsExceededException9.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException15 = new org.apache.commons.math.exception.OutOfRangeException(localizable11, (java.lang.Number) 10L, (java.lang.Number) 97L, (java.lang.Number) 10);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException19 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable11, (java.lang.Number) 0.10143992966509834d, (java.lang.Number) (-1.362665681324511d), true);
        java.lang.Number number20 = numberIsTooLargeException19.getArgument();
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(localizable11);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 0.10143992966509834d + "'", number20.equals(0.10143992966509834d));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(56.2926043147719d, (double) 1, 0.9999999334750783d, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.615714421017007E-76d + "'", double4 == 1.615714421017007E-76d);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        double double1 = org.apache.commons.math.util.FastMath.atanh(Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test322() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test322");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextExponential((double) 'a');
//        randomDataImpl0.reSeed(97L);
//        int int7 = randomDataImpl0.nextZipf(85, (double) '#');
//        long long9 = randomDataImpl0.nextPoisson(0.00536757350748316d);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 148.70753841689253d + "'", double2 == 148.70753841689253d);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
//    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        long long1 = org.apache.commons.math.util.FastMath.round(113.99656702335484d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 114L + "'", long1 == 114L);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.8025330637390305d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.665450511637549d + "'", double1 == 0.665450511637549d);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, localizable3, objArray7);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray7);
        java.lang.Object[] objArray10 = maxIterationsExceededException9.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable11 = maxIterationsExceededException9.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException15 = new org.apache.commons.math.exception.OutOfRangeException(localizable11, (java.lang.Number) 10L, (java.lang.Number) 97L, (java.lang.Number) 10);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException19 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable11, (java.lang.Number) 0.10143992966509834d, (java.lang.Number) (-1.362665681324511d), true);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException23 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable11, (java.lang.Number) 100, (java.lang.Number) 104.2221698016779d, true);
        boolean boolean24 = numberIsTooLargeException23.getBoundIsAllowed();
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(localizable11);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, localizable3, objArray7);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray7);
        java.lang.Object[] objArray10 = maxIterationsExceededException9.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable11 = maxIterationsExceededException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable13, objArray17);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, objArray17);
        java.lang.Object[] objArray23 = new java.lang.Object[] { (-1L), 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException("", objArray23);
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException(localizable11, objArray23);
        org.apache.commons.math.exception.util.Localizable localizable28 = null;
        org.apache.commons.math.exception.util.Localizable localizable29 = null;
        java.lang.Object[] objArray33 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException34 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable28, localizable29, objArray33);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException35 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray33);
        java.lang.Object[] objArray36 = maxIterationsExceededException35.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable37 = maxIterationsExceededException35.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException41 = new org.apache.commons.math.exception.OutOfRangeException(localizable37, (java.lang.Number) 10L, (java.lang.Number) 97L, (java.lang.Number) 10);
        java.lang.Object[] objArray42 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException43 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable37, objArray42);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException47 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable37, (java.lang.Number) 8.0d, (java.lang.Number) 2.718281828459045d, true);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(localizable11);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertNotNull(localizable37);
    }

//    @Test
//    public void test327() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test327");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGamma((double) (short) 1, 2.722936728502507d);
//        try {
//            double double6 = randomDataImpl0.nextGamma((double) (short) 1, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): beta");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0921273686600044d + "'", double3 == 2.0921273686600044d);
//    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        long long1 = org.apache.commons.math.util.FastMath.round((double) (short) 1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException("org.apache.commons.math.MaxIterationsExceededException: hi!", objArray1);
        java.lang.Object[] objArray7 = new java.lang.Object[] { (-1L), 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException("", objArray7);
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException2, "org.apache.commons.math.MaxIterationsExceededException: hi!", objArray7);
        java.lang.String str10 = mathException2.toString();
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.apache.commons.math.MathException: org.apache.commons.math.MaxIterationsExceededException: hi!" + "'", str10.equals("org.apache.commons.math.MathException: org.apache.commons.math.MaxIterationsExceededException: hi!"));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        double double1 = org.apache.commons.math.util.FastMath.rint(1.5675703110361978d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7160033436347992d + "'", double1 == 1.7160033436347992d);
    }

//    @Test
//    public void test332() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test332");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) 'a');
//        long long5 = randomDataImpl0.nextLong(0L, 113L);
//        double double7 = randomDataImpl0.nextT(0.21068150841353378d);
//        try {
//            int int10 = randomDataImpl0.nextSecureInt((int) ' ', 8);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 32 is larger than, or equal to, the maximum (8): lower bound (32) must be strictly less than upper bound (8)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 109L + "'", long2 == 109L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 49L + "'", long5 == 49L);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-0.42907681837612727d) + "'", double7 == (-0.42907681837612727d));
//    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7853981633974483d) + "'", double1 == (-0.7853981633974483d));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, localizable3, objArray7);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray7);
        java.lang.Object[] objArray10 = maxIterationsExceededException9.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable11 = maxIterationsExceededException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable13, objArray17);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, objArray17);
        java.lang.Number number20 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException23 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable11, number20, (java.lang.Number) (byte) -1, true);
        boolean boolean24 = numberIsTooLargeException23.getBoundIsAllowed();
        java.lang.Number number25 = numberIsTooLargeException23.getMax();
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(localizable11);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + (byte) -1 + "'", number25.equals((byte) -1));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.5d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5000000000000001d + "'", double1 == 0.5000000000000001d);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        int int2 = org.apache.commons.math.util.FastMath.max(3, 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number0);
        boolean boolean2 = notStrictlyPositiveException1.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable3 = notStrictlyPositiveException1.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(localizable3);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.15865525393145702d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7995455414919705d) + "'", double1 == (-0.7995455414919705d));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 0.7772446417474868d, (java.lang.Number) (-1.0d), (java.lang.Number) 0.009641065706572877d);
    }

//    @Test
//    public void test340() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test340");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextExponential((double) 'a');
//        double double4 = randomDataImpl0.nextExponential(0.2076448279847295d);
//        double double6 = randomDataImpl0.nextT(1.0d);
//        long long9 = randomDataImpl0.nextSecureLong((long) (byte) -1, (long) 2147483647);
//        double double12 = randomDataImpl0.nextF((double) 81L, 0.2076448279847295d);
//        double double15 = randomDataImpl0.nextWeibull(100.92781056272442d, (double) 3);
//        try {
//            int int18 = randomDataImpl0.nextSecureInt(2147483647, (int) (byte) 100);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 2,147,483,647 is larger than, or equal to, the maximum (100): lower bound (2,147,483,647) must be strictly less than upper bound (100)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 57.04496000127005d + "'", double2 == 57.04496000127005d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.345581300412465d + "'", double4 == 0.345581300412465d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.11523630257846527d + "'", double6 == 0.11523630257846527d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 545878066L + "'", long9 == 545878066L);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 14.091262919301366d + "'", double12 == 14.091262919301366d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 2.9642607583491394d + "'", double15 == 2.9642607583491394d);
//    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, localizable3, objArray7);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray7);
        java.lang.Object[] objArray10 = maxIterationsExceededException9.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable11 = maxIterationsExceededException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable13, objArray17);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, objArray17);
        java.lang.Number number20 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException23 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable11, number20, (java.lang.Number) (byte) -1, true);
        java.lang.Number number24 = numberIsTooLargeException23.getMax();
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(localizable11);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + (byte) -1 + "'", number24.equals((byte) -1));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.0d, 6.877649699236337d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        double double1 = org.apache.commons.math.util.FastMath.log(1.0E-9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-20.72326583694641d) + "'", double1 == (-20.72326583694641d));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.0d, 99.07256892495049d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.15383600203082393d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0026849447435425607d + "'", double1 == 0.0026849447435425607d);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        double double1 = org.apache.commons.math.util.FastMath.asinh(85.33849662946932d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.139807168271055d + "'", double1 == 5.139807168271055d);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.665450511637549d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2297043139906967d + "'", double1 == 1.2297043139906967d);
    }

//    @Test
//    public void test348() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test348");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGamma((double) (short) 1, 2.722936728502507d);
//        randomDataImpl0.reSeed();
//        double double7 = randomDataImpl0.nextWeibull((double) 6L, 0.17084659589147716d);
//        try {
//            randomDataImpl0.setSecureAlgorithm("2dc3862c08d2423eb96b3318c4cb4dc1f6a284a2826146d300e5a85a", "org.apache.commons.math.exception.OutOfRangeException: -1 out of [-1, 0] range");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: org.apache.commons.math.exception.OutOfRangeException: -1 out of [-1, 0] range");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.4733154673057605d + "'", double3 == 1.4733154673057605d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.15422307672203245d + "'", double7 == 0.15422307672203245d);
//    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.009641065706572877d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.0158749572898302d) + "'", double1 == (-2.0158749572898302d));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException5 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (-1.0d), (java.lang.Number) (byte) -1, (java.lang.Number) 4.9E-324d);
        java.lang.String str6 = outOfRangeException5.toString();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 100L, (java.lang.Number) 6.798157121994732E43d, true);
        java.lang.Number number11 = numberIsTooLargeException10.getMax();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException15 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 70.20706553972083d, (java.lang.Number) 243.0849990894393d, (java.lang.Number) (-1.0d));
        org.apache.commons.math.exception.util.Localizable localizable16 = outOfRangeException15.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        java.lang.Object[] objArray24 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException25 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable19, localizable20, objArray24);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException26 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray24);
        java.lang.Object[] objArray27 = maxIterationsExceededException26.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable28 = maxIterationsExceededException26.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable31 = null;
        org.apache.commons.math.exception.util.Localizable localizable32 = null;
        java.lang.Object[] objArray36 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException37 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable31, localizable32, objArray36);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException38 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray36);
        java.lang.Object[] objArray39 = maxIterationsExceededException38.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable40 = maxIterationsExceededException38.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable41 = null;
        org.apache.commons.math.exception.util.Localizable localizable42 = null;
        java.lang.Object[] objArray46 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException47 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable41, localizable42, objArray46);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException48 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable40, objArray46);
        java.lang.Object[] objArray52 = new java.lang.Object[] { (-1L), 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException53 = new org.apache.commons.math.ConvergenceException("", objArray52);
        org.apache.commons.math.MathException mathException54 = new org.apache.commons.math.MathException(localizable40, objArray52);
        org.apache.commons.math.MathException mathException55 = new org.apache.commons.math.MathException(localizable28, objArray52);
        org.apache.commons.math.ConvergenceException convergenceException56 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException10, localizable16, objArray52);
        java.lang.Object[] objArray57 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException58 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException5, localizable16, objArray57);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException59 = new org.apache.commons.math.MaxIterationsExceededException((int) '#', "24945e41", objArray57);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.OutOfRangeException: -1 out of [-1, 0] range" + "'", str6.equals("org.apache.commons.math.exception.OutOfRangeException: -1 out of [-1, 0] range"));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 6.798157121994732E43d + "'", number11.equals(6.798157121994732E43d));
        org.junit.Assert.assertTrue("'" + localizable16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable16.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(localizable28);
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertNotNull(localizable40);
        org.junit.Assert.assertNotNull(objArray46);
        org.junit.Assert.assertNotNull(objArray52);
        org.junit.Assert.assertNotNull(objArray57);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        double double2 = org.apache.commons.math.util.FastMath.min(0.0026849447435425607d, 4.9E-324d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.9E-324d + "'", double2 == 4.9E-324d);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0);
        int int2 = maxIterationsExceededException1.getMaxIterations();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 70.20706553972083d, (java.lang.Number) 243.0849990894393d, (java.lang.Number) (-1.0d));
        org.apache.commons.math.exception.util.Localizable localizable4 = outOfRangeException3.getGeneralPattern();
        java.lang.Number number5 = outOfRangeException3.getLo();
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 243.0849990894393d + "'", number5.equals(243.0849990894393d));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.7203275164926227d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        double double1 = org.apache.commons.math.util.FastMath.log((double) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.5553480614894135d + "'", double1 == 3.5553480614894135d);
    }

//    @Test
//    public void test357() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test357");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextWeibull(Double.POSITIVE_INFINITY, (double) 52L);
//        double double6 = randomDataImpl0.nextChiSquare((double) 91L);
//        double double9 = randomDataImpl0.nextUniform(0.5809401805942233d, (double) 'a');
//        int int12 = randomDataImpl0.nextSecureInt(0, (int) (byte) 10);
//        double double15 = randomDataImpl0.nextUniform((double) 10, (double) 100L);
//        try {
//            double double18 = randomDataImpl0.nextBeta(0.0d, 200.52541630203507d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.5 p = 0.064");
//        } catch (org.apache.commons.math.exception.MathUserException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 52.0d + "'", double4 == 52.0d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 91.80628445432686d + "'", double6 == 91.80628445432686d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 30.777367603806088d + "'", double9 == 30.777367603806088d);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 25.39647588597326d + "'", double15 == 25.39647588597326d);
//    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        double double1 = org.apache.commons.math.util.FastMath.atanh(1.615714421017007E-76d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.615714421017007E-76d + "'", double1 == 1.615714421017007E-76d);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP((double) 7L, 2.251752586176186d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.008405407565868004d + "'", double2 == 0.008405407565868004d);
    }

//    @Test
//    public void test360() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test360");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextGaussian((double) 100, (double) (short) 10);
//        double double6 = randomDataImpl0.nextT(1.7724538509055159d);
//        double double8 = randomDataImpl0.nextChiSquare(40.34361551018096d);
//        double double10 = randomDataImpl0.nextChiSquare(0.00536757350748316d);
//        try {
//            int int13 = randomDataImpl0.nextZipf(0, 1.5675703110361978d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): dimension (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 104.87485585020924d + "'", double4 == 104.87485585020924d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.6428878958251267d + "'", double6 == 0.6428878958251267d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 46.574178219302524d + "'", double8 == 46.574178219302524d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.1198137410248853E-9d + "'", double10 == 1.1198137410248853E-9d);
//    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(1.8146000362165722d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 103.96892357949591d + "'", double1 == 103.96892357949591d);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, 0.009837992849466293d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

//    @Test
//    public void test363() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test363");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextGaussian((double) 100, (double) (short) 10);
//        double double6 = randomDataImpl0.nextT(1.7724538509055159d);
//        double double8 = randomDataImpl0.nextChiSquare(40.34361551018096d);
//        double double10 = randomDataImpl0.nextT(1.8190200166118848d);
//        java.lang.String str12 = randomDataImpl0.nextHexString(97);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution13 = null;
//        try {
//            int int14 = randomDataImpl0.nextInversionDeviate(integerDistribution13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 104.54664407748491d + "'", double4 == 104.54664407748491d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-0.5037354829766587d) + "'", double6 == (-0.5037354829766587d));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 50.813479806691305d + "'", double8 == 50.813479806691305d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.5409475154136667d + "'", double10 == 0.5409475154136667d);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "39cfe08ac569baeb8d48064e0dca6547e37138e6b0ca2f2fc2eefd8208fd3777f02605a235d9e10713486704f2ce85f17" + "'", str12.equals("39cfe08ac569baeb8d48064e0dca6547e37138e6b0ca2f2fc2eefd8208fd3777f02605a235d9e10713486704f2ce85f17"));
//    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 'a', 0.2076448279847295d, (double) ' ');
        double double5 = normalDistributionImpl3.inverseCumulativeProbability((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.NEGATIVE_INFINITY + "'", double5 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException("org.apache.commons.math.MaxIterationsExceededException: hi!", objArray1);
        java.lang.Object[] objArray7 = new java.lang.Object[] { (-1L), 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException("", objArray7);
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException2, "org.apache.commons.math.MaxIterationsExceededException: hi!", objArray7);
        org.apache.commons.math.exception.util.Localizable localizable10 = mathException2.getSpecificPattern();
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNull(localizable10);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

//    @Test
//    public void test367() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test367");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextExponential((double) 'a');
//        double double4 = randomDataImpl0.nextExponential(0.2076448279847295d);
//        try {
//            double double7 = randomDataImpl0.nextWeibull(0.0d, 2.4785912770698406d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): shape (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 56.203135161703834d + "'", double2 == 56.203135161703834d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.08690249763093981d + "'", double4 == 0.08690249763093981d);
//    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 43L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 43 + "'", int1 == 43);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        double double1 = org.apache.commons.math.util.FastMath.sinh(94.50400478273139d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.514901997689139E40d + "'", double1 == 5.514901997689139E40d);
    }

//    @Test
//    public void test370() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test370");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextGaussian((double) 100, (double) (short) 10);
//        double double6 = randomDataImpl0.nextT(1.7724538509055159d);
//        try {
//            double double9 = randomDataImpl0.nextGamma(1.9053343882104803d, (double) (short) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): beta");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 113.02831636497226d + "'", double4 == 113.02831636497226d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.01745742026186046d + "'", double6 == 0.01745742026186046d);
//    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        java.lang.Throwable throwable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException11 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable6, objArray10);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException12 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray10);
        java.lang.Object[] objArray13 = maxIterationsExceededException12.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable14 = maxIterationsExceededException12.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        java.lang.Object[] objArray22 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException23 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable17, localizable18, objArray22);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException24 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray22);
        java.lang.Object[] objArray25 = maxIterationsExceededException24.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable26 = maxIterationsExceededException24.getGeneralPattern();
        java.lang.Object[] objArray27 = maxIterationsExceededException24.getArguments();
        org.apache.commons.math.MathException mathException28 = new org.apache.commons.math.MathException(throwable2, localizable14, objArray27);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException29 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, "hi!", objArray27);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(localizable14);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(localizable26);
        org.junit.Assert.assertNotNull(objArray27);
    }

//    @Test
//    public void test372() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test372");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int int3 = randomDataImpl0.nextZipf(10, 1.8146000362165722d);
//        randomDataImpl0.reSeed();
//        double double7 = randomDataImpl0.nextWeibull(0.21068150841353378d, (double) 1920001583L);
//        try {
//            int int10 = randomDataImpl0.nextBinomial(3, (-1.0706633850580574d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: -1.071 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2 + "'", int3 == 2);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 9.044416227642395E9d + "'", double7 == 9.044416227642395E9d);
//    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        normalDistributionImpl0.reseedRandomGenerator(0L);
        double double4 = normalDistributionImpl0.cumulativeProbability(0.0d);
        try {
            double[] doubleArray6 = normalDistributionImpl0.sample((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): number of samples (-1)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.5d + "'", double4 == 0.5d);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(2.47859127706984d, 57.967441641357304d, 2.993222846126381d);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        double double1 = org.apache.commons.math.util.FastMath.expm1(104.2221698016779d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.832792237721146E45d + "'", double1 == 1.832792237721146E45d);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray5 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException6 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray5);
        org.apache.commons.math.exception.util.Localizable localizable7 = mathIllegalArgumentException6.getGeneralPattern();
        java.lang.Object[] objArray11 = new java.lang.Object[] { (-1L), 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException("", objArray11);
        mathIllegalArgumentException6.addSuppressed((java.lang.Throwable) convergenceException12);
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        java.lang.Object[] objArray21 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException22 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable16, localizable17, objArray21);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException23 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray21);
        java.lang.Object[] objArray24 = maxIterationsExceededException23.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable25 = maxIterationsExceededException23.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable28 = null;
        org.apache.commons.math.exception.util.Localizable localizable29 = null;
        java.lang.Object[] objArray33 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException34 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable28, localizable29, objArray33);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException35 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray33);
        java.lang.Object[] objArray36 = maxIterationsExceededException35.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException37 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException12, localizable25, objArray36);
        org.apache.commons.math.exception.util.Localizable localizable38 = convergenceException12.getGeneralPattern();
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNull(localizable7);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(localizable25);
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertNotNull(localizable38);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        double double1 = org.apache.commons.math.util.FastMath.log10(16.20317595417168d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2096001481343446d + "'", double1 == 1.2096001481343446d);
    }

//    @Test
//    public void test378() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test378");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextGaussian((double) 100, (double) (short) 10);
//        double double6 = randomDataImpl0.nextT(1.7724538509055159d);
//        double double8 = randomDataImpl0.nextChiSquare(40.34361551018096d);
//        double double10 = randomDataImpl0.nextT(1.8190200166118848d);
//        java.lang.String str12 = randomDataImpl0.nextHexString(97);
//        double double15 = randomDataImpl0.nextUniform(9.982499865612837E-8d, 275.69661220080457d);
//        try {
//            double double18 = randomDataImpl0.nextCauchy(6.186562584014371d, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): scale (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 115.57127195047221d + "'", double4 == 115.57127195047221d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-0.9576740813347762d) + "'", double6 == (-0.9576740813347762d));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 31.144875815026715d + "'", double8 == 31.144875815026715d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0208348720645717d + "'", double10 == 1.0208348720645717d);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "5c803d48cb88e0852e5e86330dde02dd9f7437d0827027a2a2a571bc723b18f6198f99485baead242b0282bfafb9d8513" + "'", str12.equals("5c803d48cb88e0852e5e86330dde02dd9f7437d0827027a2a2a571bc723b18f6198f99485baead242b0282bfafb9d8513"));
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 12.426034630227791d + "'", double15 == 12.426034630227791d);
//    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 81L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.530486572925153E34d + "'", double1 == 7.530486572925153E34d);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, localizable3, objArray7);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray7);
        java.lang.Object[] objArray10 = maxIterationsExceededException9.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable11 = maxIterationsExceededException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable13, objArray17);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, objArray17);
        java.lang.Object[] objArray23 = new java.lang.Object[] { (-1L), 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException("", objArray23);
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException(localizable11, objArray23);
        org.apache.commons.math.exception.util.Localizable localizable28 = null;
        org.apache.commons.math.exception.util.Localizable localizable29 = null;
        java.lang.Object[] objArray33 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException34 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable28, localizable29, objArray33);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException35 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray33);
        java.lang.Object[] objArray36 = maxIterationsExceededException35.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable37 = maxIterationsExceededException35.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException41 = new org.apache.commons.math.exception.OutOfRangeException(localizable37, (java.lang.Number) 10L, (java.lang.Number) 97L, (java.lang.Number) 10);
        java.lang.Object[] objArray42 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException43 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable37, objArray42);
        org.apache.commons.math.exception.util.Localizable localizable48 = null;
        org.apache.commons.math.exception.util.Localizable localizable49 = null;
        java.lang.Object[] objArray53 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException54 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable48, localizable49, objArray53);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException55 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray53);
        java.lang.Object[] objArray56 = maxIterationsExceededException55.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable57 = maxIterationsExceededException55.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable58 = null;
        org.apache.commons.math.exception.util.Localizable localizable59 = null;
        java.lang.Object[] objArray63 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException64 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable58, localizable59, objArray63);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException65 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable57, objArray63);
        java.lang.Object[] objArray69 = new java.lang.Object[] { (-1L), 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException70 = new org.apache.commons.math.ConvergenceException("", objArray69);
        org.apache.commons.math.MathException mathException71 = new org.apache.commons.math.MathException(localizable57, objArray69);
        java.lang.Number number73 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException74 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number73);
        java.lang.Object[] objArray75 = notStrictlyPositiveException74.getArguments();
        org.apache.commons.math.MathException mathException76 = new org.apache.commons.math.MathException("", objArray75);
        org.apache.commons.math.ConvergenceException convergenceException77 = new org.apache.commons.math.ConvergenceException(localizable57, objArray75);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException78 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray75);
        org.apache.commons.math.ConvergenceException convergenceException79 = new org.apache.commons.math.ConvergenceException(localizable37, objArray75);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(localizable11);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertNotNull(localizable37);
        org.junit.Assert.assertNotNull(objArray53);
        org.junit.Assert.assertNotNull(objArray56);
        org.junit.Assert.assertNotNull(localizable57);
        org.junit.Assert.assertNotNull(objArray63);
        org.junit.Assert.assertNotNull(objArray69);
        org.junit.Assert.assertNotNull(objArray75);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.665450511637549d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.011614302437156073d + "'", double1 == 0.011614302437156073d);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.009641065706572877d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2128343301432367d + "'", double1 == 0.2128343301432367d);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.0d, 0.5000000000000001d, (double) (short) -1, 0);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

//    @Test
//    public void test386() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test386");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextWeibull(Double.POSITIVE_INFINITY, (double) 52L);
//        double double7 = randomDataImpl0.nextF((double) 81L, (double) 1L);
//        int int10 = randomDataImpl0.nextSecureInt((int) (byte) -1, 100);
//        double double12 = randomDataImpl0.nextChiSquare(25.394233383316248d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 52.0d + "'", double4 == 52.0d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 7.87846911674262d + "'", double7 == 7.87846911674262d);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 59 + "'", int10 == 59);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 16.99511047744013d + "'", double12 == 16.99511047744013d);
//    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        double double1 = org.apache.commons.math.util.FastMath.sinh(2.220446049250313E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

//    @Test
//    public void test388() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test388");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        int int4 = randomDataImpl0.nextSecureInt((int) (byte) 0, (int) (short) 10);
//        double double7 = randomDataImpl0.nextGaussian((double) 100L, 10.0d);
//        double double9 = randomDataImpl0.nextChiSquare(485.1720550638632d);
//        double double11 = randomDataImpl0.nextExponential(0.10968186267255918d);
//        randomDataImpl0.reSeed();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 106.26204611493237d + "'", double7 == 106.26204611493237d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 510.46285881188624d + "'", double9 == 510.46285881188624d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.09855426050315531d + "'", double11 == 0.09855426050315531d);
//    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        double double1 = org.apache.commons.math.util.FastMath.tan(2.17546980115622d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.4471366886941577d) + "'", double1 == (-1.4471366886941577d));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, localizable4, objArray8);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException10 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray8);
        java.lang.Object[] objArray11 = maxIterationsExceededException10.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable12 = maxIterationsExceededException10.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        java.lang.Object[] objArray18 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable13, localizable14, objArray18);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException20 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, objArray18);
        java.lang.Object[] objArray24 = new java.lang.Object[] { (-1L), 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException25 = new org.apache.commons.math.ConvergenceException("", objArray24);
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException(localizable12, objArray24);
        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException("org.apache.commons.math.MathException: org.apache.commons.math.MaxIterationsExceededException: hi!", objArray24);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(localizable12);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(objArray24);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((-1.4471366886941577d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.02525729994412125d) + "'", double1 == (-0.02525729994412125d));
    }

//    @Test
//    public void test392() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test392");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextExponential((double) 'a');
//        randomDataImpl0.reSeed(97L);
//        try {
//            double double6 = randomDataImpl0.nextT(0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): degrees of freedom (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 19.94974043667387d + "'", double2 == 19.94974043667387d);
//    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) '#');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 35 + "'", int1 == 35);
    }

//    @Test
//    public void test394() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test394");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextExponential((double) 'a');
//        randomDataImpl0.reSeed(97L);
//        int int7 = randomDataImpl0.nextZipf(85, (double) '#');
//        double double10 = randomDataImpl0.nextCauchy((double) 100L, Double.NaN);
//        randomDataImpl0.reSeedSecure((long) 10);
//        try {
//            java.lang.String str14 = randomDataImpl0.nextSecureHexString((int) (short) -1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): length (-1)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 20.249063061455455d + "'", double2 == 20.249063061455455d);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
//    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray5 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException6 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray5);
        org.apache.commons.math.exception.util.Localizable localizable7 = mathIllegalArgumentException6.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable8 = mathIllegalArgumentException6.getSpecificPattern();
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException6);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNull(localizable7);
        org.junit.Assert.assertNull(localizable8);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException("org.apache.commons.math.exception.OutOfRangeException: -1 out of [-1, 0] range", objArray1);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.0066817551408230955d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5641145219342998d + "'", double1 == 1.5641145219342998d);
    }

//    @Test
//    public void test398() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test398");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int int3 = randomDataImpl0.nextZipf(10, 1.8146000362165722d);
//        randomDataImpl0.reSeed();
//        java.lang.String str6 = randomDataImpl0.nextHexString(8);
//        java.lang.Class<?> wildcardClass7 = randomDataImpl0.getClass();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "ddd66b53" + "'", str6.equals("ddd66b53"));
//        org.junit.Assert.assertNotNull(wildcardClass7);
//    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        double double1 = org.apache.commons.math.util.FastMath.asin(4.594700892207039d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, localizable3, objArray7);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray7);
        java.lang.Object[] objArray10 = maxIterationsExceededException9.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable11 = maxIterationsExceededException9.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException15 = new org.apache.commons.math.exception.OutOfRangeException(localizable11, (java.lang.Number) 10L, (java.lang.Number) 97L, (java.lang.Number) 10);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException19 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable11, (java.lang.Number) 0.10143992966509834d, (java.lang.Number) (-1.362665681324511d), true);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException23 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (-1.0d), (java.lang.Number) (byte) -1, (java.lang.Number) 4.9E-324d);
        java.lang.String str24 = outOfRangeException23.toString();
        org.apache.commons.math.exception.util.Localizable localizable25 = outOfRangeException23.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable28 = null;
        org.apache.commons.math.exception.util.Localizable localizable29 = null;
        java.lang.Object[] objArray33 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException34 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable28, localizable29, objArray33);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException35 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray33);
        java.lang.Object[] objArray36 = maxIterationsExceededException35.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable37 = maxIterationsExceededException35.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException41 = new org.apache.commons.math.exception.OutOfRangeException(localizable37, (java.lang.Number) 10L, (java.lang.Number) 97L, (java.lang.Number) 10);
        org.apache.commons.math.exception.util.Localizable localizable44 = null;
        org.apache.commons.math.exception.util.Localizable localizable45 = null;
        java.lang.Object[] objArray49 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException50 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable44, localizable45, objArray49);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException51 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray49);
        java.lang.Object[] objArray52 = maxIterationsExceededException51.getArguments();
        org.apache.commons.math.MathException mathException53 = new org.apache.commons.math.MathException(localizable37, objArray52);
        org.apache.commons.math.exception.util.Localizable localizable55 = null;
        org.apache.commons.math.exception.util.Localizable localizable56 = null;
        java.lang.Object[] objArray60 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException61 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable55, localizable56, objArray60);
        org.apache.commons.math.ConvergenceException convergenceException62 = new org.apache.commons.math.ConvergenceException("", objArray60);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException63 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable37, objArray60);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException67 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (-1.0d), (java.lang.Number) (byte) -1, (java.lang.Number) 4.9E-324d);
        java.lang.Number number68 = outOfRangeException67.getArgument();
        org.apache.commons.math.MathException mathException69 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException67);
        java.lang.Throwable[] throwableArray70 = mathException69.getSuppressed();
        org.apache.commons.math.MathException mathException71 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException23, localizable37, (java.lang.Object[]) throwableArray70);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException72 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, (java.lang.Object[]) throwableArray70);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException76 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable11, (java.lang.Number) (byte) 1, (java.lang.Number) 104.2221698016779d, true);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException80 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable11, (java.lang.Number) 73.30466172043384d, (java.lang.Number) 0.23477947239890198d, false);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(localizable11);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "org.apache.commons.math.exception.OutOfRangeException: -1 out of [-1, 0] range" + "'", str24.equals("org.apache.commons.math.exception.OutOfRangeException: -1 out of [-1, 0] range"));
        org.junit.Assert.assertTrue("'" + localizable25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable25.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertNotNull(localizable37);
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertNotNull(objArray52);
        org.junit.Assert.assertNotNull(objArray60);
        org.junit.Assert.assertTrue("'" + number68 + "' != '" + (-1.0d) + "'", number68.equals((-1.0d)));
        org.junit.Assert.assertNotNull(throwableArray70);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, localizable3, objArray7);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray7);
        java.lang.Object[] objArray10 = maxIterationsExceededException9.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable11 = maxIterationsExceededException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        java.lang.Object[] objArray19 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException20 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable14, localizable15, objArray19);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException21 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray19);
        java.lang.Object[] objArray22 = maxIterationsExceededException21.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable23 = maxIterationsExceededException21.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        java.lang.Object[] objArray29 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException30 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable24, localizable25, objArray29);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException31 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable23, objArray29);
        java.lang.Object[] objArray35 = new java.lang.Object[] { (-1L), 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException("", objArray35);
        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException(localizable23, objArray35);
        org.apache.commons.math.MathException mathException38 = new org.apache.commons.math.MathException(localizable11, objArray35);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException42 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable11, (java.lang.Number) 1.8146000362165722d, (java.lang.Number) 35.0d, false);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException44 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable11, (java.lang.Number) 0.06433798016957738d);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(localizable11);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(localizable23);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(objArray35);
    }

//    @Test
//    public void test402() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test402");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGamma((double) (short) 1, 2.722936728502507d);
//        randomDataImpl0.reSeed();
//        double double6 = randomDataImpl0.nextExponential(1.8190200166118848d);
//        double double9 = randomDataImpl0.nextUniform((double) 32, 63.54970114954832d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.251756476711159d + "'", double3 == 0.251756476711159d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.4145372766281294d + "'", double6 == 4.4145372766281294d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 57.8045884536121d + "'", double9 == 57.8045884536121d);
//    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        double double1 = org.apache.commons.math.util.FastMath.log(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.018379497154688493d, 1.5707963267948966d, 97.95853185248363d, 8);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0016657815358714588d + "'", double4 == 0.0016657815358714588d);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        double double2 = org.apache.commons.math.util.FastMath.atan2(51.909526214289926d, 3.5553480614894135d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5024118803034552d + "'", double2 == 1.5024118803034552d);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (short) -1, 32);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32 + "'", int2 == 32);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 2.252991960500742d, (java.lang.Number) 97, (java.lang.Number) 16L);
    }

//    @Test
//    public void test408() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test408");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextExponential((double) 'a');
//        double double4 = randomDataImpl0.nextExponential(0.2076448279847295d);
//        double double6 = randomDataImpl0.nextT(1.0d);
//        long long9 = randomDataImpl0.nextSecureLong((long) (byte) -1, (long) 2147483647);
//        double double12 = randomDataImpl0.nextF((double) 81L, 0.2076448279847295d);
//        try {
//            randomDataImpl0.setSecureAlgorithm("org.apache.commons.math.MaxIterationsExceededException: hi!", "ba49893455e914091fdd018c8f6be689dc75b7b3a1f4e871f44997a6130688eae3877d0d24e64df8cbe2b5ce5c8f00eec");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: ba49893455e914091fdd018c8f6be689dc75b7b3a1f4e871f44997a6130688eae3877d0d24e64df8cbe2b5ce5c8f00eec");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 220.98766713172301d + "'", double2 == 220.98766713172301d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.7288940788172804d + "'", double4 == 0.7288940788172804d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.4674974640283305d) + "'", double6 == (-1.4674974640283305d));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1791412351L + "'", long9 == 1791412351L);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.9035256191426952d + "'", double12 == 0.9035256191426952d);
//    }

//    @Test
//    public void test409() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test409");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextExponential((double) 'a');
//        randomDataImpl0.reSeed(97L);
//        double double6 = randomDataImpl0.nextExponential((double) 2);
//        long long9 = randomDataImpl0.nextLong(0L, (long) 11);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 220.05929101557922d + "'", double2 == 220.05929101557922d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.6506892372005573d + "'", double6 == 0.6506892372005573d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 8L + "'", long9 == 8L);
//    }

//    @Test
//    public void test410() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test410");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextWeibull(Double.POSITIVE_INFINITY, (double) 52L);
//        int int7 = randomDataImpl0.nextPascal((int) (byte) 10, 0.0d);
//        double double10 = randomDataImpl0.nextGaussian(0.21068150841353378d, 0.5809401805942233d);
//        double double12 = randomDataImpl0.nextT(0.9206068701998329d);
//        double double15 = randomDataImpl0.nextGaussian(0.062352991014519736d, (double) 35L);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 52.0d + "'", double4 == 52.0d);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2147483647 + "'", int7 == 2147483647);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.3953996971972733d + "'", double10 == 1.3953996971972733d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-0.020127434711303124d) + "'", double12 == (-0.020127434711303124d));
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-21.40205636020592d) + "'", double15 == (-21.40205636020592d));
//    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.2128343301432367d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.20967782321320586d + "'", double1 == 0.20967782321320586d);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 81L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.0d + "'", double1 == 9.0d);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 98L, 100.364233162726d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.364233162726d + "'", double2 == 100.364233162726d);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, localizable4, objArray8);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException10 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray8);
        java.lang.Object[] objArray11 = maxIterationsExceededException10.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable12 = maxIterationsExceededException10.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        java.lang.Object[] objArray18 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable13, localizable14, objArray18);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException20 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, objArray18);
        java.lang.Object[] objArray24 = new java.lang.Object[] { (-1L), 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException25 = new org.apache.commons.math.ConvergenceException("", objArray24);
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException(localizable12, objArray24);
        org.apache.commons.math.exception.util.Localizable localizable27 = mathException26.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException31 = new org.apache.commons.math.exception.OutOfRangeException(localizable27, (java.lang.Number) 54.78355549192687d, (java.lang.Number) 0.062352991014519736d, (java.lang.Number) 485.1679412764894d);
        org.apache.commons.math.exception.util.Localizable localizable36 = null;
        org.apache.commons.math.exception.util.Localizable localizable37 = null;
        java.lang.Object[] objArray41 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException42 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable36, localizable37, objArray41);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException43 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray41);
        java.lang.Object[] objArray44 = maxIterationsExceededException43.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable45 = maxIterationsExceededException43.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable46 = null;
        org.apache.commons.math.exception.util.Localizable localizable47 = null;
        java.lang.Object[] objArray51 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException52 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable46, localizable47, objArray51);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException53 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable45, objArray51);
        java.lang.Object[] objArray57 = new java.lang.Object[] { (-1L), 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException58 = new org.apache.commons.math.ConvergenceException("", objArray57);
        org.apache.commons.math.MathException mathException59 = new org.apache.commons.math.MathException(localizable45, objArray57);
        java.lang.Number number61 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException62 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number61);
        java.lang.Object[] objArray63 = notStrictlyPositiveException62.getArguments();
        org.apache.commons.math.MathException mathException64 = new org.apache.commons.math.MathException("", objArray63);
        org.apache.commons.math.ConvergenceException convergenceException65 = new org.apache.commons.math.ConvergenceException(localizable45, objArray63);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException66 = new org.apache.commons.math.MaxIterationsExceededException(0, "", objArray63);
        org.apache.commons.math.ConvergenceException convergenceException67 = new org.apache.commons.math.ConvergenceException(throwable0, localizable27, objArray63);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(localizable12);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(localizable27);
        org.junit.Assert.assertNotNull(objArray41);
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertNotNull(localizable45);
        org.junit.Assert.assertNotNull(objArray51);
        org.junit.Assert.assertNotNull(objArray57);
        org.junit.Assert.assertNotNull(objArray63);
    }

//    @Test
//    public void test415() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test415");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextExponential((double) 'a');
//        double double4 = randomDataImpl0.nextExponential(0.2076448279847295d);
//        double double6 = randomDataImpl0.nextT(1.0d);
//        long long9 = randomDataImpl0.nextSecureLong((long) (byte) -1, (long) 2147483647);
//        double double12 = randomDataImpl0.nextF((double) 81L, 0.2076448279847295d);
//        double double15 = randomDataImpl0.nextWeibull(100.92781056272442d, (double) 3);
//        try {
//            long long18 = randomDataImpl0.nextLong((long) 56, (long) '#');
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 56 is larger than, or equal to, the maximum (35): lower bound (56) must be strictly less than upper bound (35)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 478.01390350680833d + "'", double2 == 478.01390350680833d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.2832720330131663d + "'", double4 == 0.2832720330131663d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-0.2683158622036522d) + "'", double6 == (-0.2683158622036522d));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1519131579L + "'", long9 == 1519131579L);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 55236.04456545679d + "'", double12 == 55236.04456545679d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 2.961518353109775d + "'", double15 == 2.961518353109775d);
//    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, localizable4, objArray8);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException10 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray8);
        java.lang.Object[] objArray11 = maxIterationsExceededException10.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable12 = maxIterationsExceededException10.getGeneralPattern();
        java.lang.Number number14 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException15 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number14);
        java.lang.Object[] objArray16 = notStrictlyPositiveException15.getArguments();
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException("", objArray16);
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException(localizable12, objArray16);
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException("43bd51", objArray16);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(localizable12);
        org.junit.Assert.assertNotNull(objArray16);
    }

//    @Test
//    public void test417() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test417");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGamma((double) (short) 1, 2.722936728502507d);
//        randomDataImpl0.reSeed();
//        double double6 = randomDataImpl0.nextExponential(1.8190200166118848d);
//        double double9 = randomDataImpl0.nextGamma(265.73825046500843d, 6.661338147750939E-16d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 7.5013186234692295d + "'", double3 == 7.5013186234692295d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.11956683847830657d + "'", double6 == 0.11956683847830657d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.7701723451391546E-13d + "'", double9 == 1.7701723451391546E-13d);
//    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) 82.46601179378642d, (java.lang.Number) 62.13648399124318d, (java.lang.Number) (-0.02525729994412125d));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 70.20706553972083d, (java.lang.Number) 243.0849990894393d, (java.lang.Number) (-1.0d));
        org.apache.commons.math.exception.util.Localizable localizable4 = outOfRangeException3.getGeneralPattern();
        java.lang.Number number5 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException8 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable4, number5, (java.lang.Number) 8.0d, false);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException12 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable4, (java.lang.Number) (byte) 0, (java.lang.Number) 16.20317595417168d, false);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException16 = new org.apache.commons.math.exception.OutOfRangeException(localizable4, (java.lang.Number) 127.57006924632154d, (java.lang.Number) 1.8146000362165722d, (java.lang.Number) (-2.8988930058234654d));
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        double double1 = org.apache.commons.math.util.FastMath.log1p(502.4048767883503d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.221394770354628d + "'", double1 == 6.221394770354628d);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        double double2 = org.apache.commons.math.util.FastMath.min(0.0d, 275.69661220080457d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException(number0, (java.lang.Number) 85, false);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 29L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 29.0d + "'", double1 == 29.0d);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(10.0d, (double) (byte) 0, 0.7178896490901561d, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (-1.0d), (java.lang.Number) (byte) -1, (java.lang.Number) 4.9E-324d);
        java.lang.Number number4 = outOfRangeException3.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable5 = outOfRangeException3.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-1.0d) + "'", number4.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (-1.0d), (java.lang.Number) (byte) -1, (java.lang.Number) 4.9E-324d);
        java.lang.String str4 = outOfRangeException3.toString();
        org.apache.commons.math.exception.util.Localizable localizable5 = outOfRangeException3.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, localizable9, objArray13);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException15 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray13);
        java.lang.Object[] objArray16 = maxIterationsExceededException15.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable17 = maxIterationsExceededException15.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException21 = new org.apache.commons.math.exception.OutOfRangeException(localizable17, (java.lang.Number) 10L, (java.lang.Number) 97L, (java.lang.Number) 10);
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        java.lang.Object[] objArray29 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException30 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable24, localizable25, objArray29);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException31 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray29);
        java.lang.Object[] objArray32 = maxIterationsExceededException31.getArguments();
        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException(localizable17, objArray32);
        org.apache.commons.math.exception.util.Localizable localizable35 = null;
        org.apache.commons.math.exception.util.Localizable localizable36 = null;
        java.lang.Object[] objArray40 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException41 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable35, localizable36, objArray40);
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException("", objArray40);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException43 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable17, objArray40);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException47 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (-1.0d), (java.lang.Number) (byte) -1, (java.lang.Number) 4.9E-324d);
        java.lang.Number number48 = outOfRangeException47.getArgument();
        org.apache.commons.math.MathException mathException49 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException47);
        java.lang.Throwable[] throwableArray50 = mathException49.getSuppressed();
        org.apache.commons.math.MathException mathException51 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3, localizable17, (java.lang.Object[]) throwableArray50);
        org.apache.commons.math.MathException mathException52 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3);
        org.apache.commons.math.exception.util.Localizable localizable53 = null;
        org.apache.commons.math.exception.util.Localizable localizable54 = null;
        java.lang.Object[] objArray58 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException59 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable53, localizable54, objArray58);
        org.apache.commons.math.exception.util.Localizable localizable60 = mathIllegalArgumentException59.getGeneralPattern();
        java.lang.Object[] objArray64 = new java.lang.Object[] { (-1L), 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException65 = new org.apache.commons.math.ConvergenceException("", objArray64);
        mathIllegalArgumentException59.addSuppressed((java.lang.Throwable) convergenceException65);
        org.apache.commons.math.exception.util.Localizable localizable69 = null;
        org.apache.commons.math.exception.util.Localizable localizable70 = null;
        java.lang.Object[] objArray74 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException75 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable69, localizable70, objArray74);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException76 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray74);
        java.lang.Object[] objArray77 = maxIterationsExceededException76.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable78 = maxIterationsExceededException76.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable81 = null;
        org.apache.commons.math.exception.util.Localizable localizable82 = null;
        java.lang.Object[] objArray86 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException87 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable81, localizable82, objArray86);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException88 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray86);
        java.lang.Object[] objArray89 = maxIterationsExceededException88.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException90 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException65, localizable78, objArray89);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException94 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable78, (java.lang.Number) 40.34361551018096d, (java.lang.Number) 0.15506706624860872d, true);
        java.lang.Object[] objArray95 = null;
        org.apache.commons.math.ConvergenceException convergenceException96 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3, localizable78, objArray95);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.OutOfRangeException: -1 out of [-1, 0] range" + "'", str4.equals("org.apache.commons.math.exception.OutOfRangeException: -1 out of [-1, 0] range"));
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(localizable17);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(objArray40);
        org.junit.Assert.assertTrue("'" + number48 + "' != '" + (-1.0d) + "'", number48.equals((-1.0d)));
        org.junit.Assert.assertNotNull(throwableArray50);
        org.junit.Assert.assertNotNull(objArray58);
        org.junit.Assert.assertNull(localizable60);
        org.junit.Assert.assertNotNull(objArray64);
        org.junit.Assert.assertNotNull(objArray74);
        org.junit.Assert.assertNotNull(objArray77);
        org.junit.Assert.assertNotNull(localizable78);
        org.junit.Assert.assertNotNull(objArray86);
        org.junit.Assert.assertNotNull(objArray89);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, localizable3, objArray7);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray7);
        java.lang.Object[] objArray10 = maxIterationsExceededException9.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable11 = maxIterationsExceededException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable13, objArray17);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, objArray17);
        java.lang.Number number20 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException23 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable11, number20, (java.lang.Number) (byte) -1, true);
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        org.apache.commons.math.exception.util.Localizable localizable27 = null;
        java.lang.Object[] objArray31 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException32 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable26, localizable27, objArray31);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException33 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray31);
        java.lang.Object[] objArray34 = maxIterationsExceededException33.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable35 = maxIterationsExceededException33.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException39 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable35, (java.lang.Number) 0.0f, (java.lang.Number) 10.0f, false);
        org.apache.commons.math.exception.util.Localizable localizable42 = null;
        org.apache.commons.math.exception.util.Localizable localizable43 = null;
        java.lang.Object[] objArray47 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException48 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable42, localizable43, objArray47);
        org.apache.commons.math.ConvergenceException convergenceException49 = new org.apache.commons.math.ConvergenceException("", objArray47);
        org.apache.commons.math.ConvergenceException convergenceException50 = new org.apache.commons.math.ConvergenceException("", objArray47);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException51 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable35, objArray47);
        java.lang.Object[] objArray52 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException53 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable35, objArray52);
        org.apache.commons.math.exception.util.Localizable localizable56 = null;
        org.apache.commons.math.exception.util.Localizable localizable57 = null;
        java.lang.Object[] objArray61 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException62 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable56, localizable57, objArray61);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException63 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray61);
        java.lang.Object[] objArray64 = maxIterationsExceededException63.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable65 = maxIterationsExceededException63.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException69 = new org.apache.commons.math.exception.OutOfRangeException(localizable65, (java.lang.Number) 10L, (java.lang.Number) 97L, (java.lang.Number) 10);
        org.apache.commons.math.exception.util.Localizable localizable72 = null;
        org.apache.commons.math.exception.util.Localizable localizable73 = null;
        java.lang.Object[] objArray77 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException78 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable72, localizable73, objArray77);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException79 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray77);
        java.lang.Object[] objArray80 = maxIterationsExceededException79.getArguments();
        org.apache.commons.math.MathException mathException81 = new org.apache.commons.math.MathException(localizable65, objArray80);
        org.apache.commons.math.exception.util.Localizable localizable83 = null;
        org.apache.commons.math.exception.util.Localizable localizable84 = null;
        java.lang.Object[] objArray88 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException89 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable83, localizable84, objArray88);
        org.apache.commons.math.ConvergenceException convergenceException90 = new org.apache.commons.math.ConvergenceException("", objArray88);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException91 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable65, objArray88);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException92 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable35, objArray88);
        org.apache.commons.math.exception.util.Localizable localizable93 = mathIllegalArgumentException92.getGeneralPattern();
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(localizable11);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(localizable35);
        org.junit.Assert.assertNotNull(objArray47);
        org.junit.Assert.assertNotNull(objArray61);
        org.junit.Assert.assertNotNull(objArray64);
        org.junit.Assert.assertNotNull(localizable65);
        org.junit.Assert.assertNotNull(objArray77);
        org.junit.Assert.assertNotNull(objArray80);
        org.junit.Assert.assertNotNull(objArray88);
        org.junit.Assert.assertNotNull(localizable93);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        double double1 = org.apache.commons.math.util.FastMath.acosh(8.881784197001252E-16d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test429() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test429");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextExponential((double) 'a');
//        randomDataImpl0.reSeed(97L);
//        double double6 = randomDataImpl0.nextChiSquare(100.92781056272442d);
//        try {
//            long long9 = randomDataImpl0.nextLong(0L, 0L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 0 is larger than, or equal to, the maximum (0): lower bound (0) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.486200882191382d + "'", double2 == 7.486200882191382d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 108.8399875855036d + "'", double6 == 108.8399875855036d);
//    }

//    @Test
//    public void test430() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test430");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextExponential((double) 'a');
//        randomDataImpl0.reSeed(97L);
//        java.lang.String str6 = randomDataImpl0.nextSecureHexString(6);
//        randomDataImpl0.reSeed(6L);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.617614489731901d + "'", double2 == 5.617614489731901d);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "7c9e77" + "'", str6.equals("7c9e77"));
//    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.20967782321320586d, 0.011614302437156073d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.4282192902898057d + "'", double2 == 0.4282192902898057d);
    }

//    @Test
//    public void test432() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test432");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) 'a');
//        long long5 = randomDataImpl0.nextLong(0L, 113L);
//        long long8 = randomDataImpl0.nextSecureLong((long) '#', 52L);
//        try {
//            double double11 = randomDataImpl0.nextF(0.0d, (double) 2147483647);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): degrees of freedom (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 98L + "'", long2 == 98L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 35L + "'", long5 == 35L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 42L + "'", long8 == 42L);
//    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        double double2 = org.apache.commons.math.util.FastMath.max((-0.7853981633974483d), (double) 91L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 91.0d + "'", double2 == 91.0d);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(56.2926043147719d, 0.0066817551408230955d, 2.17546980115622d, 85);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.5476298342673078E-198d + "'", double4 == 1.5476298342673078E-198d);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 200.52541630203507d, number1, (java.lang.Number) 0.00536757350748316d);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 9);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9111302618846769d) + "'", double1 == (-0.9111302618846769d));
    }

//    @Test
//    public void test438() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test438");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextExponential((double) 'a');
//        randomDataImpl0.reSeed(97L);
//        int int7 = randomDataImpl0.nextZipf(85, (double) '#');
//        double double10 = randomDataImpl0.nextCauchy((double) 100L, Double.NaN);
//        randomDataImpl0.reSeedSecure((long) 10);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution13 = null;
//        try {
//            int int14 = randomDataImpl0.nextInversionDeviate(integerDistribution13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 13.16875191607696d + "'", double2 == 13.16875191607696d);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
//    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        normalDistributionImpl0.reseedRandomGenerator(0L);
        double double3 = normalDistributionImpl0.getStandardDeviation();
        double double5 = normalDistributionImpl0.density((double) 100.0f);
        double double6 = normalDistributionImpl0.getStandardDeviation();
        double double7 = normalDistributionImpl0.sample();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.8025330637390305d + "'", double7 == 0.8025330637390305d);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1.4151009863938164d, (java.lang.Number) 0.0016657815358714588d, true);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.MathException mathException1 = new org.apache.commons.math.MathException(throwable0);
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException(throwable0);
        java.lang.String str3 = mathException2.getPattern();
        java.lang.String str4 = mathException2.getPattern();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "{0}" + "'", str3.equals("{0}"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "{0}" + "'", str4.equals("{0}"));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeed();
        double double4 = randomDataImpl0.nextWeibull(Double.POSITIVE_INFINITY, (double) 52L);
        long long7 = randomDataImpl0.nextLong(0L, (long) (byte) 1);
        try {
            randomDataImpl0.setSecureAlgorithm("org.apache.commons.math.MaxIterationsExceededException: hi!", "24945e41");
            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: 24945e41");
        } catch (java.security.NoSuchProviderException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 52.0d + "'", double4 == 52.0d);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        double double1 = org.apache.commons.math.util.FastMath.asin(512.5029872044687d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(7.530486572925153E34d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.2228696841456244E11d + "'", double1 == 4.2228696841456244E11d);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray5 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException6 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray5);
        org.apache.commons.math.exception.util.Localizable localizable7 = mathIllegalArgumentException6.getGeneralPattern();
        java.lang.Object[] objArray11 = new java.lang.Object[] { (-1L), 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException("", objArray11);
        mathIllegalArgumentException6.addSuppressed((java.lang.Throwable) convergenceException12);
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        java.lang.Object[] objArray21 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException22 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable16, localizable17, objArray21);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException23 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray21);
        java.lang.Object[] objArray24 = maxIterationsExceededException23.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable25 = maxIterationsExceededException23.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable28 = null;
        org.apache.commons.math.exception.util.Localizable localizable29 = null;
        java.lang.Object[] objArray33 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException34 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable28, localizable29, objArray33);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException35 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray33);
        java.lang.Object[] objArray36 = maxIterationsExceededException35.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException37 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException12, localizable25, objArray36);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException41 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable25, (java.lang.Number) 40.34361551018096d, (java.lang.Number) 0.15506706624860872d, true);
        java.lang.Number number42 = numberIsTooLargeException41.getMax();
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNull(localizable7);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(localizable25);
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertTrue("'" + number42 + "' != '" + 0.15506706624860872d + "'", number42.equals(0.15506706624860872d));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 953576077L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 20.675729766922085d + "'", double1 == 20.675729766922085d);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        double double1 = org.apache.commons.math.util.FastMath.acosh((-0.02525729994412125d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (-1.0d), (java.lang.Number) (byte) -1, (java.lang.Number) 4.9E-324d);
        java.lang.Number number4 = outOfRangeException3.getArgument();
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3);
        java.lang.Number number6 = outOfRangeException3.getArgument();
        java.lang.Number number7 = outOfRangeException3.getArgument();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-1.0d) + "'", number4.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (-1.0d) + "'", number6.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (-1.0d) + "'", number7.equals((-1.0d)));
    }

//    @Test
//    public void test449() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test449");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        int int4 = randomDataImpl0.nextSecureInt((int) (byte) 0, (int) (short) 10);
//        double double7 = randomDataImpl0.nextGaussian((double) 100L, 10.0d);
//        double double9 = randomDataImpl0.nextChiSquare(485.1720550638632d);
//        int int12 = randomDataImpl0.nextPascal(10, 0.0d);
//        int int16 = randomDataImpl0.nextHypergeometric((int) 'a', 0, (int) (byte) 0);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 114.69316750055052d + "'", double7 == 114.69316750055052d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 463.2723532505754d + "'", double9 == 463.2723532505754d);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2147483647 + "'", int12 == 2147483647);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.21068150841353378d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.21224354715455565d + "'", double1 == 0.21224354715455565d);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.5542337861184903d, (double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5542337861184904d + "'", double2 == 0.5542337861184904d);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 114.39140754575091d, (java.lang.Number) 16.99511047744013d, (java.lang.Number) 0.008405407565868004d);
    }

//    @Test
//    public void test453() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test453");
//        org.apache.commons.math.exception.util.Localizable localizable0 = null;
//        org.apache.commons.math.exception.util.Localizable localizable4 = null;
//        java.lang.Object[] objArray5 = null;
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException6 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, objArray5);
//        org.apache.commons.math.exception.util.Localizable localizable7 = mathIllegalArgumentException6.getGeneralPattern();
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException11 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.2076448279847295d, (java.lang.Number) 1.0E-9d, true);
//        java.lang.Number number12 = null;
//        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException13 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number12);
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl14 = new org.apache.commons.math.random.RandomDataImpl();
//        int int17 = randomDataImpl14.nextZipf(10, 1.8146000362165722d);
//        randomDataImpl14.reSeed();
//        java.lang.Object[] objArray19 = new java.lang.Object[] { 1, 0.21068150841353378d, mathIllegalArgumentException6, numberIsTooSmallException11, number12, randomDataImpl14 };
//        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException("", objArray19);
//        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException(localizable0, objArray19);
//        org.junit.Assert.assertNull(localizable7);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertNotNull(objArray19);
//    }

//    @Test
//    public void test454() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test454");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        int int4 = randomDataImpl0.nextSecureInt((int) (byte) 0, (int) (short) 10);
//        double double7 = randomDataImpl0.nextGaussian((double) 100L, 10.0d);
//        double double9 = randomDataImpl0.nextChiSquare(485.1720550638632d);
//        randomDataImpl0.reSeed((long) 100);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.61499581435143d + "'", double7 == 100.61499581435143d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 450.20662381681876d + "'", double9 == 450.20662381681876d);
//    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        normalDistributionImpl0.reseedRandomGenerator(0L);
        double double4 = normalDistributionImpl0.cumulativeProbability(0.0d);
        double double5 = normalDistributionImpl0.getStandardDeviation();
        double double7 = normalDistributionImpl0.density(0.0d);
        double double10 = normalDistributionImpl0.cumulativeProbability((double) 1.0f, 227.06909087323695d);
        double double11 = normalDistributionImpl0.sample();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.5d + "'", double4 == 0.5d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.3989422804014327d + "'", double7 == 0.3989422804014327d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.15865525393145696d + "'", double10 == 0.15865525393145696d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.8025330637390305d + "'", double11 == 0.8025330637390305d);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 16L, 0.15865525393145702d, (double) (short) -1);
    }

//    @Test
//    public void test457() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test457");
//        org.apache.commons.math.exception.util.Localizable localizable2 = null;
//        org.apache.commons.math.exception.util.Localizable localizable3 = null;
//        java.lang.Object[] objArray7 = new java.lang.Object[] { 1L, (byte) -1, 100L };
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, localizable3, objArray7);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray7);
//        java.lang.Object[] objArray10 = maxIterationsExceededException9.getArguments();
//        org.apache.commons.math.exception.util.Localizable localizable11 = maxIterationsExceededException9.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable12 = null;
//        org.apache.commons.math.exception.util.Localizable localizable13 = null;
//        java.lang.Object[] objArray17 = new java.lang.Object[] { 1L, (byte) -1, 100L };
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable13, objArray17);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, objArray17);
//        org.apache.commons.math.exception.util.Localizable localizable22 = null;
//        org.apache.commons.math.exception.util.Localizable localizable23 = null;
//        java.lang.Object[] objArray27 = new java.lang.Object[] { 1L, (byte) -1, 100L };
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable22, localizable23, objArray27);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException29 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray27);
//        java.lang.Object[] objArray30 = maxIterationsExceededException29.getArguments();
//        org.apache.commons.math.exception.util.Localizable localizable31 = maxIterationsExceededException29.getGeneralPattern();
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException35 = new org.apache.commons.math.exception.OutOfRangeException(localizable31, (java.lang.Number) 10L, (java.lang.Number) 97L, (java.lang.Number) 10);
//        org.apache.commons.math.exception.util.Localizable localizable38 = null;
//        org.apache.commons.math.exception.util.Localizable localizable39 = null;
//        java.lang.Object[] objArray43 = new java.lang.Object[] { 1L, (byte) -1, 100L };
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException44 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable38, localizable39, objArray43);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException45 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray43);
//        java.lang.Object[] objArray46 = maxIterationsExceededException45.getArguments();
//        org.apache.commons.math.MathException mathException47 = new org.apache.commons.math.MathException(localizable31, objArray46);
//        java.lang.Object[] objArray48 = null;
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException49 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable31, objArray48);
//        java.lang.Object[] objArray50 = null;
//        org.apache.commons.math.MathException mathException51 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException19, localizable31, objArray50);
//        org.apache.commons.math.exception.util.Localizable localizable55 = null;
//        java.lang.Object[] objArray56 = null;
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException57 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable55, objArray56);
//        org.apache.commons.math.exception.util.Localizable localizable58 = mathIllegalArgumentException57.getGeneralPattern();
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException62 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.2076448279847295d, (java.lang.Number) 1.0E-9d, true);
//        java.lang.Number number63 = null;
//        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException64 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number63);
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl65 = new org.apache.commons.math.random.RandomDataImpl();
//        int int68 = randomDataImpl65.nextZipf(10, 1.8146000362165722d);
//        randomDataImpl65.reSeed();
//        java.lang.Object[] objArray70 = new java.lang.Object[] { 1, 0.21068150841353378d, mathIllegalArgumentException57, numberIsTooSmallException62, number63, randomDataImpl65 };
//        org.apache.commons.math.MathException mathException71 = new org.apache.commons.math.MathException("", objArray70);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException72 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable31, objArray70);
//        java.lang.String str73 = mathIllegalArgumentException72.toString();
//        org.junit.Assert.assertNotNull(objArray7);
//        org.junit.Assert.assertNotNull(objArray10);
//        org.junit.Assert.assertNotNull(localizable11);
//        org.junit.Assert.assertNotNull(objArray17);
//        org.junit.Assert.assertNotNull(objArray27);
//        org.junit.Assert.assertNotNull(objArray30);
//        org.junit.Assert.assertNotNull(localizable31);
//        org.junit.Assert.assertNotNull(objArray43);
//        org.junit.Assert.assertNotNull(objArray46);
//        org.junit.Assert.assertNull(localizable58);
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 1 + "'", int68 == 1);
//        org.junit.Assert.assertNotNull(objArray70);
//        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "org.apache.commons.math.exception.MathIllegalArgumentException: hi!" + "'", str73.equals("org.apache.commons.math.exception.MathIllegalArgumentException: hi!"));
//    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.06433798016957738d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

//    @Test
//    public void test459() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test459");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int int3 = randomDataImpl0.nextZipf(10, 1.8146000362165722d);
//        randomDataImpl0.reSeed();
//        double double7 = randomDataImpl0.nextWeibull(0.21068150841353378d, (double) 1920001583L);
//        try {
//            double double10 = randomDataImpl0.nextGaussian((-0.7853981633974483d), 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): standard deviation (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 3.274673018325588E8d + "'", double7 == 3.274673018325588E8d);
//    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, localizable3, objArray7);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray7);
        java.lang.Object[] objArray10 = maxIterationsExceededException9.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable11 = maxIterationsExceededException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable13, objArray17);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, objArray17);
        java.lang.Number number20 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException23 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable11, number20, (java.lang.Number) (byte) -1, true);
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        org.apache.commons.math.exception.util.Localizable localizable27 = null;
        java.lang.Object[] objArray31 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException32 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable26, localizable27, objArray31);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException33 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray31);
        java.lang.Object[] objArray34 = maxIterationsExceededException33.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable35 = maxIterationsExceededException33.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException39 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable35, (java.lang.Number) 0.0f, (java.lang.Number) 10.0f, false);
        org.apache.commons.math.exception.util.Localizable localizable42 = null;
        org.apache.commons.math.exception.util.Localizable localizable43 = null;
        java.lang.Object[] objArray47 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException48 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable42, localizable43, objArray47);
        org.apache.commons.math.ConvergenceException convergenceException49 = new org.apache.commons.math.ConvergenceException("", objArray47);
        org.apache.commons.math.ConvergenceException convergenceException50 = new org.apache.commons.math.ConvergenceException("", objArray47);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException51 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable35, objArray47);
        java.lang.Number number52 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException53 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number52);
        java.lang.Object[] objArray54 = notStrictlyPositiveException53.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException55 = new org.apache.commons.math.ConvergenceException(localizable11, objArray54);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(localizable11);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(localizable35);
        org.junit.Assert.assertNotNull(objArray47);
        org.junit.Assert.assertNotNull(objArray54);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        double double1 = org.apache.commons.math.util.FastMath.signum(9.982499865612837E-8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.3639973351338316d, (double) 2);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.36399733513383165d + "'", double2 == 0.36399733513383165d);
    }

//    @Test
//    public void test463() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test463");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int int3 = randomDataImpl0.nextZipf(10, 1.8146000362165722d);
//        randomDataImpl0.reSeed();
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution5 = null;
//        try {
//            int int6 = randomDataImpl0.nextInversionDeviate(integerDistribution5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//    }

//    @Test
//    public void test464() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test464");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextExponential((double) 'a');
//        double double4 = randomDataImpl0.nextExponential(0.2076448279847295d);
//        double double6 = randomDataImpl0.nextT(1.0d);
//        randomDataImpl0.reSeed();
//        double double10 = randomDataImpl0.nextGaussian(0.005945247535687155d, 72.9875457391492d);
//        try {
//            double double13 = randomDataImpl0.nextUniform((double) 97L, 17.403170913604605d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 97 is larger than, or equal to, the maximum (17.403): lower bound (97) must be strictly less than upper bound (17.403)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 81.44637071000277d + "'", double2 == 81.44637071000277d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.29699304583296926d + "'", double4 == 0.29699304583296926d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-0.20088586524192822d) + "'", double6 == (-0.20088586524192822d));
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-35.26502035046147d) + "'", double10 == (-35.26502035046147d));
//    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 70.20706553972083d, (java.lang.Number) 243.0849990894393d, (java.lang.Number) (-1.0d));
        org.apache.commons.math.MathException mathException4 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3);
        java.lang.Number number5 = outOfRangeException3.getArgument();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 70.20706553972083d + "'", number5.equals(70.20706553972083d));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        double double2 = org.apache.commons.math.util.FastMath.pow(359.1342053695754d, 127.57006924632154d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.4282192902898057d, 35.00000000000001d);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) 0.5809401805942233d, (java.lang.Number) 0.5809401805942233d, (java.lang.Number) (byte) 0);
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException4);
        org.apache.commons.math.exception.util.Localizable localizable6 = convergenceException5.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable7 = convergenceException5.getSpecificPattern();
        org.junit.Assert.assertNull(localizable6);
        org.junit.Assert.assertNull(localizable7);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, localizable4, objArray8);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException10 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray8);
        java.lang.Object[] objArray11 = maxIterationsExceededException10.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable12 = maxIterationsExceededException10.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException16 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable12, (java.lang.Number) 0.0f, (java.lang.Number) 10.0f, false);
        java.lang.Object[] objArray18 = null;
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException("org.apache.commons.math.MaxIterationsExceededException: hi!", objArray18);
        java.lang.Object[] objArray24 = new java.lang.Object[] { (-1L), 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException25 = new org.apache.commons.math.ConvergenceException("", objArray24);
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException19, "org.apache.commons.math.MaxIterationsExceededException: hi!", objArray24);
        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException(localizable12, objArray24);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException31 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 100L, (java.lang.Number) 6.798157121994732E43d, true);
        java.lang.Object[] objArray32 = numberIsTooLargeException31.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException33 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable12, objArray32);
        java.lang.String str34 = maxIterationsExceededException33.getPattern();
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(localizable12);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "hi!" + "'", str34.equals("hi!"));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 94L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 94 + "'", int1 == 94);
    }

//    @Test
//    public void test471() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test471");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextWeibull(Double.POSITIVE_INFINITY, (double) 52L);
//        java.lang.String str6 = randomDataImpl0.nextSecureHexString(32);
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl7 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl7.reSeed();
//        double double11 = randomDataImpl7.nextWeibull(Double.POSITIVE_INFINITY, (double) 52L);
//        int int14 = randomDataImpl7.nextPascal((int) (byte) 10, 0.0d);
//        double double17 = randomDataImpl7.nextGaussian(0.21068150841353378d, 0.5809401805942233d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl18 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double20 = normalDistributionImpl18.density(57.9674416413573d);
//        double double21 = randomDataImpl7.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl18);
//        double double22 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl18);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 52.0d + "'", double4 == 52.0d);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "656078212a3d55bdcb3830ed5d2081a4" + "'", str6.equals("656078212a3d55bdcb3830ed5d2081a4"));
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 52.0d + "'", double11 == 52.0d);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2147483647 + "'", int14 == 2147483647);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-0.4232132441231991d) + "'", double17 == (-0.4232132441231991d));
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + (-0.15737415474762972d) + "'", double21 == (-0.15737415474762972d));
//        org.junit.Assert.assertTrue("'" + double22 + "' != '" + (-1.4657090015874246d) + "'", double22 == (-1.4657090015874246d));
//    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        double double1 = org.apache.commons.math.util.FastMath.acosh(200.52541630203507d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.994081966522879d + "'", double1 == 5.994081966522879d);
    }

//    @Test
//    public void test473() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test473");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextWeibull(Double.POSITIVE_INFINITY, (double) 52L);
//        long long7 = randomDataImpl0.nextSecureLong(0L, (long) 2);
//        randomDataImpl0.reSeed();
//        try {
//            long long11 = randomDataImpl0.nextLong(8L, (long) 2);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 8 is larger than, or equal to, the maximum (2): lower bound (8) must be strictly less than upper bound (2)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 52.0d + "'", double4 == 52.0d);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
//    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1.8449919524961895d));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException5 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (-1.0d), (java.lang.Number) (byte) -1, (java.lang.Number) 4.9E-324d);
        java.lang.String str6 = outOfRangeException5.toString();
        org.apache.commons.math.exception.util.Localizable localizable7 = outOfRangeException5.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        java.lang.Object[] objArray15 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException16 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable10, localizable11, objArray15);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException17 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray15);
        java.lang.Object[] objArray18 = maxIterationsExceededException17.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable19 = maxIterationsExceededException17.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException23 = new org.apache.commons.math.exception.OutOfRangeException(localizable19, (java.lang.Number) 10L, (java.lang.Number) 97L, (java.lang.Number) 10);
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        org.apache.commons.math.exception.util.Localizable localizable27 = null;
        java.lang.Object[] objArray31 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException32 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable26, localizable27, objArray31);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException33 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray31);
        java.lang.Object[] objArray34 = maxIterationsExceededException33.getArguments();
        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException(localizable19, objArray34);
        org.apache.commons.math.exception.util.Localizable localizable37 = null;
        org.apache.commons.math.exception.util.Localizable localizable38 = null;
        java.lang.Object[] objArray42 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException43 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable37, localizable38, objArray42);
        org.apache.commons.math.ConvergenceException convergenceException44 = new org.apache.commons.math.ConvergenceException("", objArray42);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException45 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable19, objArray42);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException49 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (-1.0d), (java.lang.Number) (byte) -1, (java.lang.Number) 4.9E-324d);
        java.lang.Number number50 = outOfRangeException49.getArgument();
        org.apache.commons.math.MathException mathException51 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException49);
        java.lang.Throwable[] throwableArray52 = mathException51.getSuppressed();
        org.apache.commons.math.MathException mathException53 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException5, localizable19, (java.lang.Object[]) throwableArray52);
        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException("org.apache.commons.math.MaxIterationsExceededException: hi!", (java.lang.Object[]) throwableArray52);
        org.apache.commons.math.MathException mathException55 = new org.apache.commons.math.MathException("org.apache.commons.math.exception.OutOfRangeException: -1 out of [-1, 0] range", (java.lang.Object[]) throwableArray52);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.OutOfRangeException: -1 out of [-1, 0] range" + "'", str6.equals("org.apache.commons.math.exception.OutOfRangeException: -1 out of [-1, 0] range"));
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(localizable19);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertTrue("'" + number50 + "' != '" + (-1.0d) + "'", number50.equals((-1.0d)));
        org.junit.Assert.assertNotNull(throwableArray52);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 2075158725L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 2.07515878E9f + "'", float1 == 2.07515878E9f);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, localizable3, objArray7);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray7);
        java.lang.Object[] objArray10 = maxIterationsExceededException9.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable11 = maxIterationsExceededException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable13, objArray17);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, objArray17);
        java.lang.Number number20 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException23 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable11, number20, (java.lang.Number) (byte) -1, true);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException27 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (-1.0d), (java.lang.Number) (byte) -1, (java.lang.Number) 4.9E-324d);
        java.lang.String str28 = outOfRangeException27.toString();
        org.apache.commons.math.exception.util.Localizable localizable29 = outOfRangeException27.getGeneralPattern();
        numberIsTooLargeException23.addSuppressed((java.lang.Throwable) outOfRangeException27);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(localizable11);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "org.apache.commons.math.exception.OutOfRangeException: -1 out of [-1, 0] range" + "'", str28.equals("org.apache.commons.math.exception.OutOfRangeException: -1 out of [-1, 0] range"));
        org.junit.Assert.assertTrue("'" + localizable29 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable29.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.31054907748559946d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2704461925158988d + "'", double1 == 0.2704461925158988d);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (-1.0d), (java.lang.Number) (byte) -1, (java.lang.Number) 4.9E-324d);
        java.lang.String str4 = outOfRangeException3.toString();
        org.apache.commons.math.exception.util.Localizable localizable5 = outOfRangeException3.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, localizable9, objArray13);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException15 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray13);
        java.lang.Object[] objArray16 = maxIterationsExceededException15.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable17 = maxIterationsExceededException15.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException21 = new org.apache.commons.math.exception.OutOfRangeException(localizable17, (java.lang.Number) 10L, (java.lang.Number) 97L, (java.lang.Number) 10);
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        java.lang.Object[] objArray29 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException30 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable24, localizable25, objArray29);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException31 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray29);
        java.lang.Object[] objArray32 = maxIterationsExceededException31.getArguments();
        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException(localizable17, objArray32);
        org.apache.commons.math.exception.util.Localizable localizable35 = null;
        org.apache.commons.math.exception.util.Localizable localizable36 = null;
        java.lang.Object[] objArray40 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException41 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable35, localizable36, objArray40);
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException("", objArray40);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException43 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable17, objArray40);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException47 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (-1.0d), (java.lang.Number) (byte) -1, (java.lang.Number) 4.9E-324d);
        java.lang.Number number48 = outOfRangeException47.getArgument();
        org.apache.commons.math.MathException mathException49 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException47);
        java.lang.Throwable[] throwableArray50 = mathException49.getSuppressed();
        org.apache.commons.math.MathException mathException51 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3, localizable17, (java.lang.Object[]) throwableArray50);
        org.apache.commons.math.MathException mathException52 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException51);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.OutOfRangeException: -1 out of [-1, 0] range" + "'", str4.equals("org.apache.commons.math.exception.OutOfRangeException: -1 out of [-1, 0] range"));
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(localizable17);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(objArray40);
        org.junit.Assert.assertTrue("'" + number48 + "' != '" + (-1.0d) + "'", number48.equals((-1.0d)));
        org.junit.Assert.assertNotNull(throwableArray50);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 70.20706553972083d, (java.lang.Number) 243.0849990894393d, (java.lang.Number) (-1.0d));
        java.lang.Number number4 = outOfRangeException3.getArgument();
        java.lang.Object[] objArray7 = null;
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException("org.apache.commons.math.MaxIterationsExceededException: hi!", objArray7);
        java.lang.Object[] objArray13 = new java.lang.Object[] { (-1L), 4.9E-324d };
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException("", objArray13);
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException8, "org.apache.commons.math.MaxIterationsExceededException: hi!", objArray13);
        java.lang.Throwable[] throwableArray16 = mathException8.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3, "org.apache.commons.math.MaxIterationsExceededException: hi!", (java.lang.Object[]) throwableArray16);
        java.lang.Number number18 = outOfRangeException3.getArgument();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 70.20706553972083d + "'", number4.equals(70.20706553972083d));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 70.20706553972083d + "'", number18.equals(70.20706553972083d));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        double double2 = org.apache.commons.math.util.FastMath.min(16.99511047744013d, 0.8711009486916311d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.8711009486916311d + "'", double2 == 0.8711009486916311d);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (-1), 3.141592653589793d);
    }

//    @Test
//    public void test483() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test483");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextWeibull(Double.POSITIVE_INFINITY, (double) 52L);
//        long long7 = randomDataImpl0.nextSecureLong(0L, (long) 2);
//        java.lang.Class<?> wildcardClass8 = randomDataImpl0.getClass();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl9 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        normalDistributionImpl9.reseedRandomGenerator(0L);
//        double double13 = normalDistributionImpl9.cumulativeProbability(0.0d);
//        double double14 = normalDistributionImpl9.getStandardDeviation();
//        double double16 = normalDistributionImpl9.density(0.0d);
//        double double17 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl9);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 52.0d + "'", double4 == 52.0d);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.5d + "'", double13 == 0.5d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.3989422804014327d + "'", double16 == 0.3989422804014327d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-0.8995895579885126d) + "'", double17 == (-0.8995895579885126d));
//    }

//    @Test
//    public void test484() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test484");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) 'a');
//        randomDataImpl0.reSeedSecure();
//        randomDataImpl0.reSeed();
//        try {
//            long long7 = randomDataImpl0.nextSecureLong(97L, 0L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 97 is larger than, or equal to, the maximum (0): lower bound (97) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 95L + "'", long2 == 95L);
//    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        long long1 = org.apache.commons.math.util.FastMath.round(0.10968186267255918d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

//    @Test
//    public void test486() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test486");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) 'a');
//        long long5 = randomDataImpl0.nextLong(0L, 113L);
//        long long8 = randomDataImpl0.nextSecureLong((long) '#', 52L);
//        try {
//            double double10 = randomDataImpl0.nextExponential((double) (short) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): mean (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 92L + "'", long2 == 92L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 101L + "'", long5 == 101L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 50L + "'", long8 == 50L);
//    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(100.1711455688407d, (double) 91L, (-21.40205636020592d), (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: maximal number of iterations (100) exceeded");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray6 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException7 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable1, localizable2, objArray6);
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException("", objArray6);
        org.apache.commons.math.exception.util.Localizable localizable9 = convergenceException8.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException10 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException8);
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        java.lang.Object[] objArray21 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException22 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable16, localizable17, objArray21);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException23 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray21);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException24 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, "", objArray21);
        org.apache.commons.math.ConvergenceException convergenceException25 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException8, "org.apache.commons.math.ConvergenceException: 1 out of [-1, 100] range", objArray21);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(localizable9);
        org.junit.Assert.assertNotNull(objArray21);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 502.4048767883503d, number1, true);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (-1.0d), (java.lang.Number) (byte) -1, (java.lang.Number) 4.9E-324d);
        java.lang.Number number4 = outOfRangeException3.getArgument();
        java.lang.Number number5 = outOfRangeException3.getLo();
        java.lang.Object[] objArray6 = outOfRangeException3.getArguments();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-1.0d) + "'", number4.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (byte) -1 + "'", number5.equals((byte) -1));
        org.junit.Assert.assertNotNull(objArray6);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double2 = normalDistributionImpl0.density(57.9674416413573d);
        double double3 = normalDistributionImpl0.getStandardDeviation();
        double double5 = normalDistributionImpl0.inverseCumulativeProbability((double) 0.0f);
        normalDistributionImpl0.reseedRandomGenerator(953576077L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.NEGATIVE_INFINITY + "'", double5 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(9);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        double double1 = org.apache.commons.math.special.Gamma.trigamma((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.10516633568161556d + "'", double1 == 0.10516633568161556d);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        long long1 = org.apache.commons.math.util.FastMath.round(0.868684713990688d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

//    @Test
//    public void test495() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test495");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextExponential((double) 'a');
//        randomDataImpl0.reSeed(97L);
//        int int7 = randomDataImpl0.nextZipf(85, (double) '#');
//        double double10 = randomDataImpl0.nextCauchy((double) 100L, Double.NaN);
//        randomDataImpl0.reSeedSecure((long) 10);
//        double double15 = randomDataImpl0.nextCauchy(Double.NaN, 0.06048625084551451d);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.463202779546586d + "'", double2 == 6.463202779546586d);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
//        org.junit.Assert.assertEquals((double) double15, Double.NaN, 0);
//    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        java.lang.Object[] objArray9 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException10 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, localizable5, objArray9);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException11 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "hi!", objArray9);
        java.lang.Object[] objArray12 = maxIterationsExceededException11.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable13 = maxIterationsExceededException11.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        java.lang.Object[] objArray19 = new java.lang.Object[] { 1L, (byte) -1, 100L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException20 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable14, localizable15, objArray19);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException21 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable13, objArray19);
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException("hi!", objArray19);
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException("2dc3862c08d2423eb96b3318c4cb4dc1f6a284a2826146d300e5a85a", objArray19);
        org.apache.commons.math.exception.util.Localizable localizable24 = convergenceException23.getSpecificPattern();
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(localizable13);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNull(localizable24);
    }

//    @Test
//    public void test497() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test497");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextExponential((double) 'a');
//        double double4 = randomDataImpl0.nextExponential(0.2076448279847295d);
//        double double6 = randomDataImpl0.nextT(1.0d);
//        long long9 = randomDataImpl0.nextSecureLong((long) (byte) -1, (long) 2147483647);
//        double double12 = randomDataImpl0.nextF((double) 81L, 0.2076448279847295d);
//        double double14 = randomDataImpl0.nextChiSquare((double) (short) 100);
//        try {
//            int int17 = randomDataImpl0.nextZipf(85, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): exponent (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.951791702219754d + "'", double2 == 4.951791702219754d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.035005424822359556d + "'", double4 == 0.035005424822359556d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.6267774981043623d + "'", double6 == 1.6267774981043623d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1450505460L + "'", long9 == 1450505460L);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 9.385693626833593d + "'", double12 == 9.385693626833593d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 80.83454679706225d + "'", double14 == 80.83454679706225d);
//    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        double double1 = org.apache.commons.math.util.FastMath.atan(1.4151009863938164d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9556123024274972d + "'", double1 == 0.9556123024274972d);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        normalDistributionImpl0.reseedRandomGenerator(0L);
        double double4 = normalDistributionImpl0.cumulativeProbability(0.0d);
        double double5 = normalDistributionImpl0.getStandardDeviation();
        double double7 = normalDistributionImpl0.density(0.0d);
        double double10 = normalDistributionImpl0.cumulativeProbability((double) 1.0f, 227.06909087323695d);
        double[] doubleArray12 = normalDistributionImpl0.sample(10);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.5d + "'", double4 == 0.5d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.3989422804014327d + "'", double7 == 0.3989422804014327d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.15865525393145696d + "'", double10 == 0.15865525393145696d);
        org.junit.Assert.assertNotNull(doubleArray12);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(6);
    }
}

