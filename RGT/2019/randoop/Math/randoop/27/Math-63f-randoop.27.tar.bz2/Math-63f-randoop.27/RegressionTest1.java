import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.28366218546322625d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2764014075493026d + "'", double1 == 0.2764014075493026d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 340593891, 200.0d, 1024);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 34059389100L, 99, 90);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        double double2 = org.apache.commons.math.util.MathUtils.log(97.0d, 0.31046516452991896d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.2556846937279649d) + "'", double2 == (-0.2556846937279649d));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        double double2 = org.apache.commons.math.util.FastMath.max((-0.8813735870195429d), 1023.606454811765d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1023.606454811765d + "'", double2 == 1023.606454811765d);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) 99);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((int) (short) 1, (int) ' ');
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.9913289158005998d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6888022127440038d + "'", double1 == 0.6888022127440038d);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) 1059L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        double double2 = org.apache.commons.math.util.FastMath.max((double) (byte) 10, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        int int2 = org.apache.commons.math.util.FastMath.max(2, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.2344051195730661d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4841540246378895d + "'", double1 == 0.4841540246378895d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 10);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 90.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 90.0d + "'", double1 == 90.0d);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(2, (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 54 + "'", int2 == 54);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(35L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 11L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 29937.070865949758d + "'", double1 == 29937.070865949758d);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(1.5604874136486533d, (double) 35L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 32.97641394954658d + "'", double2 == 32.97641394954658d);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 52.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9075712110370514d + "'", double1 == 0.9075712110370514d);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 985523693061886047L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 42.12509674344045d + "'", double1 == 42.12509674344045d);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((-4.9E-324d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog((int) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 15.104412573075516d + "'", double1 == 15.104412573075516d);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        java.lang.Number number1 = null;
        java.lang.Number number6 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number6, (java.lang.Number) 100, 100);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = nonMonotonousSequenceException9.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 100.0f, (java.lang.Number) (-52L), (int) (byte) 1, orderDirection10, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException14 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 6.283185307179586d, number1, 0, orderDirection10, false);
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 0.009765314576904154d, (int) '4');
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(99, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 99 + "'", int2 == 99);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(1024.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 17.872171540421935d + "'", double1 == 17.872171540421935d);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 97, 2.718281828459045d, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) (byte) 10, (long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.6616961211922904d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6144558919811912d + "'", double1 == 0.6144558919811912d);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(0, 1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((-0.14042367749334314d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-8.045684064074768d) + "'", double1 == (-8.045684064074768d));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        double double2 = org.apache.commons.math.util.FastMath.atan2(32.97641394954658d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1023.606454811765d, (java.lang.Number) 3.141592653589793d, 1);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(2.4758800785707605E27d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.475880078570761E27d + "'", double1 == 2.475880078570761E27d);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        long long1 = org.apache.commons.math.util.FastMath.round(4.9E-324d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) 2);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1073741824 + "'", int1 == 1073741824);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        double double2 = org.apache.commons.math.util.MathUtils.log(0.0d, 8.065817517094494E67d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.0d) + "'", double2 == (-0.0d));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        double double1 = org.apache.commons.math.util.FastMath.floor(4.9E-324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) 985523693061886157L, 35, 1509505313);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        double double1 = org.apache.commons.math.util.FastMath.sin(10.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5440211108893698d) + "'", double1 == (-0.5440211108893698d));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(1.1752011936438014d, 200.06192982974676d, (-0.552750258507488d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(100, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 3.40593888E8f, (double) 1104155264);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.4059388800000006E8d + "'", double2 == 3.4059388800000006E8d);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 1104155264, (float) (byte) -1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        double double1 = org.apache.commons.math.util.FastMath.acos((-1.2246467991473532E-16d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948968d + "'", double1 == 1.5707963267948968d);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(97);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.619275968248924E151d + "'", double1 == 9.619275968248924E151d);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (-88L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 88.0f + "'", float1 == 88.0f);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) (byte) 10, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 9);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 9L + "'", long1 == 9L);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 1104155264);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.104155264E9d + "'", double1 == 1.104155264E9d);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        double double1 = org.apache.commons.math.util.FastMath.acos(2.4758800785707605E27d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0f, (float) 'a');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) 0);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 1024L, 0, 9);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        double[] doubleArray1 = new double[] { '4' };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray4 = new double[] { 7.105427357601002E-15d };
        boolean boolean5 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray4);
        double[] doubleArray7 = new double[] { '4' };
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray7);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7, orderDirection9, false);
        double[] doubleArray13 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, (double) 100);
        double[] doubleArray15 = new double[] { 0 };
        double[] doubleArray17 = new double[] { '4' };
        int int18 = org.apache.commons.math.util.MathUtils.hash(doubleArray17);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection19 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17, orderDirection19, false);
        double double22 = org.apache.commons.math.util.MathUtils.distance1(doubleArray15, doubleArray17);
        double double23 = org.apache.commons.math.util.MathUtils.distance1(doubleArray7, doubleArray17);
        double[] doubleArray25 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray17, (double) 100.0f);
        double[] doubleArray27 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray17, (double) (short) -1);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17);
        double double29 = org.apache.commons.math.util.MathUtils.distance1(doubleArray4, doubleArray17);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17);
        double[] doubleArray32 = new double[] { '4' };
        int int33 = org.apache.commons.math.util.MathUtils.hash(doubleArray32);
        double[] doubleArray35 = new double[] { 7.105427357601002E-15d };
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equals(doubleArray32, doubleArray35);
        double[] doubleArray39 = new double[] { (byte) 10, (byte) 1 };
        double[] doubleArray41 = new double[] { '4' };
        int int42 = org.apache.commons.math.util.MathUtils.hash(doubleArray41);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection43 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray41, orderDirection43, false);
        double[] doubleArray47 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray41, (double) 100);
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray39, doubleArray41);
        double double49 = org.apache.commons.math.util.MathUtils.distance(doubleArray32, doubleArray41);
        double[] doubleArray51 = new double[] { '4' };
        int int52 = org.apache.commons.math.util.MathUtils.hash(doubleArray51);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection53 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray51, orderDirection53, false);
        double[] doubleArray57 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray51, (double) 100);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection58 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray51, orderDirection58, false);
        double double61 = org.apache.commons.math.util.MathUtils.distance1(doubleArray32, doubleArray51);
        double double62 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray17, doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1078591519 + "'", int2 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1078591519 + "'", int8 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1078591519 + "'", int18 == 1078591519);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 52.0d + "'", double22 == 52.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 51.99999999999999d + "'", double29 == 51.99999999999999d);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1078591519 + "'", int33 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1078591519 + "'", int42 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1078591519 + "'", int52 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        int int1 = org.apache.commons.math.util.MathUtils.sign((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) (-88L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        double double1 = org.apache.commons.math.util.FastMath.sinh((-0.5440211108893698d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5712556729872575d) + "'", double1 == (-0.5712556729872575d));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 15.104412573075516d + "'", double1 == 15.104412573075516d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        int int2 = org.apache.commons.math.util.MathUtils.pow(99, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(54, 1078591519);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        double double2 = org.apache.commons.math.util.MathUtils.log(4.248699261236361d, 0.7110506631364506d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.23573106550029851d) + "'", double2 == (-0.23573106550029851d));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((double) 9.8552368E17f, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.8552367677649715E17d + "'", double2 == 9.8552367677649715E17d);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(1078591519);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(1.1752011936438014d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7737756783403529d + "'", double1 == 1.7737756783403529d);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        int[] intArray5 = new int[] { 1052060012, 1073741824, (-88), (byte) 10, (byte) 1 };
        int[] intArray7 = new int[] { (byte) 100 };
        int[] intArray10 = new int[] { 1, (short) -1 };
        int[] intArray14 = new int[] { 10, (byte) 0, (byte) 1 };
        double double15 = org.apache.commons.math.util.MathUtils.distance(intArray10, intArray14);
        int int16 = org.apache.commons.math.util.MathUtils.distance1(intArray7, intArray14);
        int[] intArray18 = new int[] { (byte) 100 };
        int[] intArray21 = new int[] { 1, (short) -1 };
        int[] intArray25 = new int[] { 10, (byte) 0, (byte) 1 };
        double double26 = org.apache.commons.math.util.MathUtils.distance(intArray21, intArray25);
        int int27 = org.apache.commons.math.util.MathUtils.distance1(intArray18, intArray25);
        int int28 = org.apache.commons.math.util.MathUtils.distance1(intArray7, intArray25);
        int[] intArray31 = new int[] { 1, (short) -1 };
        int[] intArray35 = new int[] { 10, (byte) 0, (byte) 1 };
        double double36 = org.apache.commons.math.util.MathUtils.distance(intArray31, intArray35);
        int[] intArray38 = new int[] { (byte) 100 };
        int[] intArray41 = new int[] { 1, (short) -1 };
        int[] intArray45 = new int[] { 10, (byte) 0, (byte) 1 };
        double double46 = org.apache.commons.math.util.MathUtils.distance(intArray41, intArray45);
        int int47 = org.apache.commons.math.util.MathUtils.distance1(intArray38, intArray45);
        int int48 = org.apache.commons.math.util.MathUtils.distanceInf(intArray31, intArray45);
        int[] intArray51 = new int[] { 1, (short) -1 };
        int[] intArray55 = new int[] { 10, (byte) 0, (byte) 1 };
        double double56 = org.apache.commons.math.util.MathUtils.distance(intArray51, intArray55);
        int int57 = org.apache.commons.math.util.MathUtils.distanceInf(intArray31, intArray55);
        int int58 = org.apache.commons.math.util.MathUtils.distance1(intArray7, intArray31);
        int[] intArray61 = new int[] { 1, (short) -1 };
        int[] intArray65 = new int[] { 10, (byte) 0, (byte) 1 };
        double double66 = org.apache.commons.math.util.MathUtils.distance(intArray61, intArray65);
        int[] intArray68 = new int[] { (byte) 100 };
        int[] intArray71 = new int[] { 1, (short) -1 };
        int[] intArray75 = new int[] { 10, (byte) 0, (byte) 1 };
        double double76 = org.apache.commons.math.util.MathUtils.distance(intArray71, intArray75);
        int int77 = org.apache.commons.math.util.MathUtils.distance1(intArray68, intArray75);
        double double78 = org.apache.commons.math.util.MathUtils.distance(intArray65, intArray75);
        int int79 = org.apache.commons.math.util.MathUtils.distanceInf(intArray31, intArray75);
        try {
            int int80 = org.apache.commons.math.util.MathUtils.distanceInf(intArray5, intArray31);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 9.055385138137417d + "'", double15 == 9.055385138137417d);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 90 + "'", int16 == 90);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 9.055385138137417d + "'", double26 == 9.055385138137417d);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 90 + "'", int27 == 90);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 90 + "'", int28 == 90);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 9.055385138137417d + "'", double36 == 9.055385138137417d);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 9.055385138137417d + "'", double46 == 9.055385138137417d);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 90 + "'", int47 == 90);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 9 + "'", int48 == 9);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 9.055385138137417d + "'", double56 == 9.055385138137417d);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 9 + "'", int57 == 9);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 99 + "'", int58 == 99);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertNotNull(intArray65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 9.055385138137417d + "'", double66 == 9.055385138137417d);
        org.junit.Assert.assertNotNull(intArray68);
        org.junit.Assert.assertNotNull(intArray71);
        org.junit.Assert.assertNotNull(intArray75);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 9.055385138137417d + "'", double76 == 9.055385138137417d);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 90 + "'", int77 == 90);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 0.0d + "'", double78 == 0.0d);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 9 + "'", int79 == 9);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(35);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 92.13617560368711d + "'", double1 == 92.13617560368711d);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        double double2 = org.apache.commons.math.util.FastMath.min(0.0d, (double) 'a');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((double) (short) 10, (-88));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.2311742677852644E-26d + "'", double2 == 3.2311742677852644E-26d);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) (short) 0, (long) 'a');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 97L + "'", long2 == 97L);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        double[] doubleArray0 = null;
        try {
            double[] doubleArray2 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray0, 32.97641394954658d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(1024);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 9, (long) '#');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        int int1 = org.apache.commons.math.util.FastMath.round(88.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 88 + "'", int1 == 88);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((int) ' ', (int) (short) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.4657359027997265d + "'", double2 == 3.4657359027997265d);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1078591519, (java.lang.Number) 1.0d, (int) (short) 0);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException7 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1078591519, (java.lang.Number) 1.0d, (int) (short) 0);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException7);
        java.lang.Number number9 = nonMonotonousSequenceException3.getPrevious();
        java.lang.String str10 = nonMonotonousSequenceException3.toString();
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 1.0d + "'", number9.equals(1.0d));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (1 >= 1,078,591,519)" + "'", str10.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (1 >= 1,078,591,519)"));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((-4.9E-324d), (double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-4.9E-324d) + "'", double2 == (-4.9E-324d));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 43L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 43.0f + "'", float1 == 43.0f);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(3.1622776601683795d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(5.0d, (-0.23573106550029851d), 0.3010299956639812d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) 100);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        double double1 = org.apache.commons.math.util.FastMath.signum((-1.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.61512051684126d + "'", double1 == 4.61512051684126d);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 10);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 10.0f + "'", float1 == 10.0f);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(9.035405699485793d, (double) 43L, 2.0666295932772593E40d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        float float1 = org.apache.commons.math.util.FastMath.abs(52.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 52.0f + "'", float1 == 52.0f);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        double double1 = org.apache.commons.math.util.FastMath.signum(4.6d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((-9.060282259287522d), (-0.2556846937279649d), 5.362856488696706E10d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        int int1 = org.apache.commons.math.util.MathUtils.hash(0.0d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(9.055385138137417d, (double) 35, Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(0.043329155290542036d, (-0.8813735870195429d));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 43.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5551133015206257d + "'", double1 == 0.5551133015206257d);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        double double1 = org.apache.commons.math.util.FastMath.asin(100.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        int int2 = org.apache.commons.math.util.MathUtils.pow(88, (long) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 9.8552368E17f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.8552367677649728E17d + "'", double1 == 9.8552367677649728E17d);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(52.098904879217365d, (-99));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 8.21975785280856E-29d + "'", double2 == 8.21975785280856E-29d);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 0L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 1124L, 7.016735912097631E20d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.6018844290008112E-18d + "'", double2 == 1.6018844290008112E-18d);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 1073741824, (float) 985523693061886047L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 9.8552368E17f + "'", float2 == 9.8552368E17f);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        double double1 = org.apache.commons.math.util.FastMath.expm1(1.486418323994938d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.421231706927556d + "'", double1 == 3.421231706927556d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (short) 100, (int) ' ');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 54);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6738001006480598d + "'", double1 == 0.6738001006480598d);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(0.0d, 99);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(99, 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(1104155264, 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1104155263 + "'", int2 == 1104155263);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.7150149345207635d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7150149345207635d + "'", double1 == 0.7150149345207635d);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 985523693061886047L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.8552369306188608E17d + "'", double1 == 9.8552369306188608E17d);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        long long1 = org.apache.commons.math.util.MathUtils.factorial(10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 3628800L + "'", long1 == 3628800L);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        int[] intArray1 = new int[] { (byte) 100 };
        int[] intArray4 = new int[] { 1, (short) -1 };
        int[] intArray8 = new int[] { 10, (byte) 0, (byte) 1 };
        double double9 = org.apache.commons.math.util.MathUtils.distance(intArray4, intArray8);
        int int10 = org.apache.commons.math.util.MathUtils.distance1(intArray1, intArray8);
        int[] intArray12 = new int[] { (byte) 100 };
        int[] intArray15 = new int[] { 1, (short) -1 };
        int[] intArray19 = new int[] { 10, (byte) 0, (byte) 1 };
        double double20 = org.apache.commons.math.util.MathUtils.distance(intArray15, intArray19);
        int int21 = org.apache.commons.math.util.MathUtils.distance1(intArray12, intArray19);
        int int22 = org.apache.commons.math.util.MathUtils.distance1(intArray1, intArray19);
        int[] intArray25 = new int[] { 1, (short) -1 };
        int[] intArray29 = new int[] { 10, (byte) 0, (byte) 1 };
        double double30 = org.apache.commons.math.util.MathUtils.distance(intArray25, intArray29);
        try {
            int int31 = org.apache.commons.math.util.MathUtils.distanceInf(intArray19, intArray25);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 9.055385138137417d + "'", double9 == 9.055385138137417d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 90 + "'", int10 == 90);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 9.055385138137417d + "'", double20 == 9.055385138137417d);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 90 + "'", int21 == 90);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 90 + "'", int22 == 90);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 9.055385138137417d + "'", double30 == 9.055385138137417d);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        double double1 = org.apache.commons.math.util.FastMath.cosh(15.104412573075516d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1814400.000000139d + "'", double1 == 1814400.000000139d);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        long long2 = org.apache.commons.math.util.FastMath.max(0L, (long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(0.0d, 5.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 8);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        double double1 = org.apache.commons.math.util.FastMath.acosh((-0.2556846937279649d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        double[] doubleArray2 = new double[] { (byte) 10, (byte) 1 };
        double[] doubleArray4 = new double[] { '4' };
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray4, orderDirection6, false);
        double[] doubleArray10 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray4, (double) 100);
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray4);
        double[] doubleArray13 = new double[] { '4' };
        int int14 = org.apache.commons.math.util.MathUtils.hash(doubleArray13);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray13, orderDirection15, false);
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray13, (double) 100);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection20 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray13, orderDirection20, false);
        double[] doubleArray24 = new double[] { '4' };
        int int25 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection26 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray24, orderDirection26, false);
        double[] doubleArray30 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray24, (double) 100);
        double double31 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray13, doubleArray30);
        try {
            double double32 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray13);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1078591519 + "'", int5 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1078591519 + "'", int14 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1078591519 + "'", int25 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 48.0d + "'", double31 == 48.0d);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        double double2 = org.apache.commons.math.util.FastMath.pow((-0.5278888682247536d), (double) 1104155264);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        double double1 = org.apache.commons.math.util.FastMath.log(1.9233097485725157d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6540475293360811d + "'", double1 == 0.6540475293360811d);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        double double1 = org.apache.commons.math.util.FastMath.log10((-0.14042367749334314d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        long long1 = org.apache.commons.math.util.MathUtils.factorial(0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        int int2 = org.apache.commons.math.util.MathUtils.pow(0, 1124L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (byte) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) (short) 10);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) (byte) 0);
        java.math.BigInteger bigInteger8 = null;
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, (long) (byte) 0);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, (long) (short) 10);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, bigInteger12);
        java.math.BigInteger bigInteger14 = null;
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger14, (long) (byte) 0);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, (long) (short) 10);
        java.math.BigInteger bigInteger19 = null;
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, (long) (byte) 0);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, (long) (short) 10);
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, bigInteger21);
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, bigInteger24);
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger25);
        java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (int) '#');
        java.math.BigInteger bigInteger29 = null;
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, (long) (byte) 0);
        java.math.BigInteger bigInteger32 = null;
        java.math.BigInteger bigInteger34 = org.apache.commons.math.util.MathUtils.pow(bigInteger32, (long) (byte) 0);
        java.math.BigInteger bigInteger36 = org.apache.commons.math.util.MathUtils.pow(bigInteger34, (long) (short) 10);
        java.math.BigInteger bigInteger37 = org.apache.commons.math.util.MathUtils.pow(bigInteger31, bigInteger36);
        java.math.BigInteger bigInteger38 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger37);
        try {
            java.math.BigInteger bigInteger40 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) (short) -1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger28);
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertNotNull(bigInteger34);
        org.junit.Assert.assertNotNull(bigInteger36);
        org.junit.Assert.assertNotNull(bigInteger37);
        org.junit.Assert.assertNotNull(bigInteger38);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.5395531969044848d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5661158159967962d + "'", double1 == 0.5661158159967962d);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        long long1 = org.apache.commons.math.util.FastMath.round(7.09810715E8d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 709810715L + "'", long1 == 709810715L);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(1.9721522630525295E-31d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.820766091346741E-11d + "'", double1 == 5.820766091346741E-11d);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 43.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.5033980603867243d + "'", double1 == 3.5033980603867243d);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) (byte) -1, 9.8552369306188621E17d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.8552369306188621E17d + "'", double2 == 9.8552369306188621E17d);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.5551133015206257d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5884991765377913d + "'", double1 == 0.5884991765377913d);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 8, (float) 1104155263);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 8.0f + "'", float2 == 8.0f);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((int) ' ', 99);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.000000000000007d, (double) 1124L, 100);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        double[] doubleArray1 = new double[] { '4' };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray4 = new double[] { 7.105427357601002E-15d };
        boolean boolean5 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray4);
        double[] doubleArray8 = new double[] { (byte) 10, (byte) 1 };
        double[] doubleArray10 = new double[] { '4' };
        int int11 = org.apache.commons.math.util.MathUtils.hash(doubleArray10);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray10, orderDirection12, false);
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray10, (double) 100);
        boolean boolean17 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray8, doubleArray10);
        double double18 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray10);
        double[] doubleArray20 = new double[] { '4' };
        int int21 = org.apache.commons.math.util.MathUtils.hash(doubleArray20);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection22 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray20, orderDirection22, false);
        double double25 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray20);
        double double26 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray20);
        double[] doubleArray28 = new double[] { '4' };
        int int29 = org.apache.commons.math.util.MathUtils.hash(doubleArray28);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection30 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray28, orderDirection30, false);
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray28, (double) 100);
        double double35 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray34);
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1078591519 + "'", int2 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1078591519 + "'", int11 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1078591519 + "'", int21 == 1078591519);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 52.0d + "'", double25 == 52.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1078591519 + "'", int29 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 100.0d + "'", double35 == 100.0d);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        double double1 = org.apache.commons.math.util.FastMath.sinh(5.362856488696706E10d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        double double2 = org.apache.commons.math.util.MathUtils.round(3.421231706927556d, (-88));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((int) (byte) -1, 1052060012);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1052060013) + "'", int2 == (-1052060013));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(0.0d, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        byte byte1 = org.apache.commons.math.util.MathUtils.sign((byte) 100);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 1 + "'", byte1 == (byte) 1);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) 100.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1079574528 + "'", int1 == 1079574528);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        double double2 = org.apache.commons.math.util.MathUtils.log(8.065817517094494E67d, 53.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.025391856473934358d + "'", double2 == 0.025391856473934358d);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        double[] doubleArray1 = new double[] { '4' };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray4 = new double[] { 7.105427357601002E-15d };
        boolean boolean5 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray4);
        double[] doubleArray7 = new double[] { '4' };
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray7);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7, orderDirection9, false);
        double[] doubleArray13 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, (double) 100);
        double[] doubleArray15 = new double[] { 0 };
        double[] doubleArray17 = new double[] { '4' };
        int int18 = org.apache.commons.math.util.MathUtils.hash(doubleArray17);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection19 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17, orderDirection19, false);
        double double22 = org.apache.commons.math.util.MathUtils.distance1(doubleArray15, doubleArray17);
        double double23 = org.apache.commons.math.util.MathUtils.distance1(doubleArray7, doubleArray17);
        double[] doubleArray25 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray17, (double) 100.0f);
        double[] doubleArray27 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray17, (double) (short) -1);
        double[] doubleArray29 = new double[] { '4' };
        int int30 = org.apache.commons.math.util.MathUtils.hash(doubleArray29);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection31 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray29, orderDirection31, false);
        double[] doubleArray35 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray29, (double) 100);
        double[] doubleArray37 = new double[] { 0 };
        double[] doubleArray39 = new double[] { '4' };
        int int40 = org.apache.commons.math.util.MathUtils.hash(doubleArray39);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection41 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray39, orderDirection41, false);
        double double44 = org.apache.commons.math.util.MathUtils.distance1(doubleArray37, doubleArray39);
        double double45 = org.apache.commons.math.util.MathUtils.distance1(doubleArray29, doubleArray39);
        double[] doubleArray47 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray39, (double) 100.0f);
        double double48 = org.apache.commons.math.util.MathUtils.distance1(doubleArray17, doubleArray39);
        double[] doubleArray50 = new double[] { '4' };
        int int51 = org.apache.commons.math.util.MathUtils.hash(doubleArray50);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection52 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray50, orderDirection52, false);
        double[] doubleArray56 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray50, (double) 100);
        double[] doubleArray58 = new double[] { 0 };
        double[] doubleArray60 = new double[] { '4' };
        int int61 = org.apache.commons.math.util.MathUtils.hash(doubleArray60);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection62 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray60, orderDirection62, false);
        double double65 = org.apache.commons.math.util.MathUtils.distance1(doubleArray58, doubleArray60);
        double double66 = org.apache.commons.math.util.MathUtils.distance1(doubleArray50, doubleArray60);
        double double67 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray50);
        double double68 = org.apache.commons.math.util.MathUtils.distance(doubleArray39, doubleArray50);
        double double69 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray4, doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1078591519 + "'", int2 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1078591519 + "'", int8 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1078591519 + "'", int18 == 1078591519);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 52.0d + "'", double22 == 52.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1078591519 + "'", int30 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1078591519 + "'", int40 == 1078591519);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 52.0d + "'", double44 == 52.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1078591519 + "'", int51 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 1078591519 + "'", int61 == 1078591519);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 52.0d + "'", double65 == 52.0d);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 52.0d + "'", double67 == 52.0d);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 51.99999999999999d + "'", double69 == 51.99999999999999d);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 200);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 200 + "'", int1 == 200);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) '4', 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 52.0f + "'", float2 == 52.0f);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        int int2 = org.apache.commons.math.util.FastMath.max(35, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        double double1 = org.apache.commons.math.util.FastMath.tan((-0.5440211108893698d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6049088194604227d) + "'", double1 == (-0.6049088194604227d));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 985523693061886057L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.754423631317469d + "'", double1 == 4.754423631317469d);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(9.748415547902194d, 0.6616961211922905d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        double double1 = org.apache.commons.math.util.FastMath.tan((-0.14042367749334314d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.1413540121206391d) + "'", double1 == (-0.1413540121206391d));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-88), (float) (byte) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-88.0f) + "'", float2 == (-88.0f));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1078591519, (java.lang.Number) 1.0d, (int) (short) 0);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException7 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1078591519, (java.lang.Number) 1.0d, (int) (short) 0);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException7);
        java.lang.Number number9 = nonMonotonousSequenceException7.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0d, (java.lang.Number) (byte) -1, (int) '4', orderDirection13, false);
        int int16 = nonMonotonousSequenceException15.getIndex();
        nonMonotonousSequenceException7.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException15);
        java.lang.Throwable[] throwableArray18 = nonMonotonousSequenceException15.getSuppressed();
        int int19 = nonMonotonousSequenceException15.getIndex();
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 1.0d + "'", number9.equals(1.0d));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 52 + "'", int16 == 52);
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 52 + "'", int19 == 52);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 200);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.225973768125749E86d + "'", double1 == 7.225973768125749E86d);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(0.6616961211922905d, 1.486418323994938d, 0.6144558919811912d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        int int1 = org.apache.commons.math.util.MathUtils.hash(0.6144558919811912d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1493119226 + "'", int1 == 1493119226);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        long long1 = org.apache.commons.math.util.FastMath.round(2.6750134462402384d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 3L + "'", long1 == 3L);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 15.104412573075516d + "'", double1 == 15.104412573075516d);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        double double1 = org.apache.commons.math.util.FastMath.floor(90.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 90.0d + "'", double1 == 90.0d);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.9785884097858146d, (double) (-1L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9785884097858145d + "'", double2 == 0.9785884097858145d);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(5.298292365610485d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 303.5697911758657d + "'", double1 == 303.5697911758657d);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) (-99));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 1078591519, 1079574528, (int) (short) -1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(35, 97);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(99);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 359.1342053695755d + "'", double1 == 359.1342053695755d);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        double double1 = org.apache.commons.math.util.FastMath.ceil(9.055385138137419d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 709810715, (double) 1073741824);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0203089395406904d + "'", double2 == 1.0203089395406904d);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) '#', (long) 1052060012);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1052060047L + "'", long2 == 1052060047L);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        double double2 = org.apache.commons.math.util.MathUtils.round(0.5884991765377913d, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5884991765d + "'", double2 == 0.5884991765d);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 2758547353515625L, (-0.41032129904823816d));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 1078591519L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) (byte) 100, 1078591519);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(1.5515679276951895d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5515679276951897d + "'", double1 == 1.5515679276951897d);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 985523693061886047L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        double double1 = org.apache.commons.math.util.FastMath.expm1(1059.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(0, 52);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5607966601082315d + "'", double1 == 1.5607966601082315d);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        double double1 = org.apache.commons.math.util.FastMath.acos((-0.5712556729872575d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.178831236867478d + "'", double1 == 2.178831236867478d);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        float float3 = org.apache.commons.math.util.MathUtils.round((float) 34059389100L, (-99), 0);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + Float.POSITIVE_INFINITY + "'", float3 == Float.POSITIVE_INFINITY);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 1124L, (-88));
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        int int1 = org.apache.commons.math.util.MathUtils.sign(200);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(1.1752011936438014d, (double) 2);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.1752011936438016d + "'", double2 == 1.1752011936438016d);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (byte) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 985523693061886057L);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) (byte) 0);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) (short) 10);
        java.math.BigInteger bigInteger10 = null;
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, (long) (byte) 0);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (long) (short) 10);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, bigInteger12);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (int) 'a');
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, (long) 0);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger20);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 709810715, 1078591519L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 709810715L + "'", long2 == 709810715L);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (short) -1, Float.NaN);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(200, (-88));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        long long1 = org.apache.commons.math.util.FastMath.round(0.9913289158005998d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(1124, 1104155264);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1104154140) + "'", int2 == (-1104154140));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 90);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(1052060012, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(1.0333147966386297E40d, 200.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0333147966386295E40d + "'", double2 == 1.0333147966386295E40d);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        double double1 = org.apache.commons.math.util.FastMath.tanh(1.0203089395406904d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7699923387629767d + "'", double1 == 0.7699923387629767d);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) ' ', (long) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 33L + "'", long2 == 33L);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        long long2 = org.apache.commons.math.util.MathUtils.pow(0L, (long) 200);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        double double1 = org.apache.commons.math.util.FastMath.expm1(2.893443985885872d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 17.055385138137428d + "'", double1 == 17.055385138137428d);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) 'a', (long) 97);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1573460895) + "'", int2 == (-1573460895));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(1104155264, 1052060012);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(340593891, 200);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        double double1 = org.apache.commons.math.util.FastMath.log1p((-0.9036922050915067d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.3402060194404175d) + "'", double1 == (-2.3402060194404175d));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 340593891L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 340593888 + "'", int1 == 340593888);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) (-52L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.105427357601002E-15d + "'", double1 == 7.105427357601002E-15d);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(1.5860134523134308E15d, 2.2951872969998433d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.5d + "'", double2 == 3.5d);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(1509505313);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 10L, (int) (short) 0, 709810715);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5430806348152437d + "'", double1 == 1.5430806348152437d);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) (-1052060013), 54, 88);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        double double1 = org.apache.commons.math.util.FastMath.floor(200.06192982974676d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 200.0d + "'", double1 == 200.0d);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        long long2 = org.apache.commons.math.util.FastMath.min((-88L), (long) 200);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-88L) + "'", long2 == (-88L));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (-99));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 99L + "'", long1 == 99L);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((double) 88, (int) '4');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.9631676720860365E17d + "'", double2 == 3.9631676720860365E17d);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(52, (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 87 + "'", int2 == 87);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.6738001006480598d, (double) 1124, (double) 34059389100L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        long long2 = org.apache.commons.math.util.MathUtils.pow(0L, 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.31046516452991896d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.310465164529919d + "'", double1 == 0.310465164529919d);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 11L, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 11.0d + "'", double2 == 11.0d);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 43L, 4.61512051684126d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.406609043584561d + "'", double2 == 0.406609043584561d);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((-88), 340593888);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-340593976) + "'", int2 == (-340593976));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(4.754423631317469d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 58.04405292798697d + "'", double1 == 58.04405292798697d);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(1104155263, 87);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        long long1 = org.apache.commons.math.util.MathUtils.sign(3L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(0L, (-1L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        double double2 = org.apache.commons.math.util.FastMath.pow(8.065817517094494E67d, 0.28366218546322625d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.8304096233512614E19d + "'", double2 == 1.8304096233512614E19d);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 8, (double) 33L, (double) 10L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((-88), (int) (short) 10);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        double[] doubleArray1 = new double[] { '4' };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection3, false);
        double[] doubleArray7 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray1, (double) 100);
        double[] doubleArray9 = new double[] { 0 };
        double[] doubleArray11 = new double[] { '4' };
        int int12 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11, orderDirection13, false);
        double double16 = org.apache.commons.math.util.MathUtils.distance1(doubleArray9, doubleArray11);
        double double17 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray11);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1078591519 + "'", int2 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1078591519 + "'", int12 == 1078591519);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 52.0d + "'", double16 == 52.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 43L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.105427357601002E-15d + "'", double1 == 7.105427357601002E-15d);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 88);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 88L + "'", long1 == 88L);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 52);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7160033436347992d + "'", double1 == 1.7160033436347992d);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        int int1 = org.apache.commons.math.util.MathUtils.hash((-1.0d));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1074790400) + "'", int1 == (-1074790400));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(200);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(0, 1124);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1124 + "'", int2 == 1124);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(5.298292365610485d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.298292365610486d + "'", double1 == 5.298292365610486d);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(2, 340593891);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-340593889) + "'", int2 == (-340593889));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        double double1 = org.apache.commons.math.util.FastMath.asin(1.7737756783403529d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        double double1 = org.apache.commons.math.util.FastMath.atan((-0.552750258507488d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5049522813008377d) + "'", double1 == (-0.5049522813008377d));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(3.4657359027997265d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.465735902799727d + "'", double1 == 3.465735902799727d);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(5.298292365610486d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.298292365610487d + "'", double1 == 5.298292365610487d);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) 1104155264, 4.440892098500626E-16d, 0.7699923387629767d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 200, (long) (-1074790400));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1074790600L + "'", long2 == 1074790600L);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(985523693061886157L, (long) 2);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 985523693061886155L + "'", long2 == 985523693061886155L);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.31046516452991896d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9521915644015781d + "'", double1 == 0.9521915644015781d);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 54, number1, (-1104154140));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(200, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 200 + "'", int2 == 200);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(1.9867717342662448d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.986771734266245d + "'", double1 == 1.986771734266245d);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 52);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.105427357601002E-15d + "'", double1 == 7.105427357601002E-15d);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 35L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 2L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 1L, (float) (-99));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-99.0f) + "'", float2 == (-99.0f));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        double double2 = org.apache.commons.math.util.MathUtils.round(3.9631676720860365E17d, 99);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.9631676720860365E17d + "'", double2 == 3.9631676720860365E17d);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        double[] doubleArray1 = new double[] { '4' };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection3, false);
        double[] doubleArray7 = new double[] { '4' };
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray7);
        double[] doubleArray10 = new double[] { 7.105427357601002E-15d };
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray10);
        double[] doubleArray13 = new double[] { '4' };
        int int14 = org.apache.commons.math.util.MathUtils.hash(doubleArray13);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray13, orderDirection15, false);
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray13, (double) 100);
        double[] doubleArray21 = new double[] { 0 };
        double[] doubleArray23 = new double[] { '4' };
        int int24 = org.apache.commons.math.util.MathUtils.hash(doubleArray23);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection25 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray23, orderDirection25, false);
        double double28 = org.apache.commons.math.util.MathUtils.distance1(doubleArray21, doubleArray23);
        double double29 = org.apache.commons.math.util.MathUtils.distance1(doubleArray13, doubleArray23);
        double[] doubleArray31 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray23, (double) 100.0f);
        double[] doubleArray33 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray23, (double) (short) -1);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray23);
        double double35 = org.apache.commons.math.util.MathUtils.distance1(doubleArray10, doubleArray23);
        double double36 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray10);
        double[] doubleArray38 = new double[] { '4' };
        int int39 = org.apache.commons.math.util.MathUtils.hash(doubleArray38);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection40 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray38, orderDirection40, false);
        double[] doubleArray44 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray38, (double) 100);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection45 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray38, orderDirection45, false);
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray38);
        double double49 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1078591519 + "'", int2 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1078591519 + "'", int8 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1078591519 + "'", int14 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1078591519 + "'", int24 == 1078591519);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 52.0d + "'", double28 == 52.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 51.99999999999999d + "'", double35 == 51.99999999999999d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 51.99999999999999d + "'", double36 == 51.99999999999999d);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1078591519 + "'", int39 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 52.0d + "'", double49 == 52.0d);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        double double1 = org.apache.commons.math.util.FastMath.cos((-0.5440211108893698d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8556343548213666d + "'", double1 == 0.8556343548213666d);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(99);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        int int2 = org.apache.commons.math.util.FastMath.min((-1074790400), 340593888);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1074790400) + "'", int2 == (-1074790400));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((-7.016709298534876E-15d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-7.016709298534875E-15d) + "'", double1 == (-7.016709298534875E-15d));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((int) (short) 0, (int) 'a');
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((-9.060282259287522d), 1104155264, 1073741824);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 34059389100L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        int int1 = org.apache.commons.math.util.MathUtils.sign((int) (short) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        int[] intArray0 = null;
        int[] intArray2 = new int[] { (byte) 100 };
        int[] intArray5 = new int[] { 1, (short) -1 };
        int[] intArray9 = new int[] { 10, (byte) 0, (byte) 1 };
        double double10 = org.apache.commons.math.util.MathUtils.distance(intArray5, intArray9);
        int int11 = org.apache.commons.math.util.MathUtils.distance1(intArray2, intArray9);
        try {
            int int12 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 9.055385138137417d + "'", double10 == 9.055385138137417d);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 90 + "'", int11 == 90);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.5661158159967962d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 52, 53.0d, (double) '#');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialLog((-1052060013));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        double[] doubleArray1 = new double[] { '4' };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray4 = new double[] { 7.105427357601002E-15d };
        boolean boolean5 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray4);
        double[] doubleArray8 = new double[] { (byte) 10, (byte) 1 };
        double[] doubleArray10 = new double[] { '4' };
        int int11 = org.apache.commons.math.util.MathUtils.hash(doubleArray10);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray10, orderDirection12, false);
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray10, (double) 100);
        boolean boolean17 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray8, doubleArray10);
        double double18 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray10);
        double[] doubleArray21 = new double[] { (byte) 10, (byte) 1 };
        double[] doubleArray23 = new double[] { '4' };
        int int24 = org.apache.commons.math.util.MathUtils.hash(doubleArray23);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection25 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray23, orderDirection25, false);
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray23, (double) 100);
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray21, doubleArray23);
        java.lang.Class<?> wildcardClass31 = doubleArray23.getClass();
        double double32 = org.apache.commons.math.util.MathUtils.distance(doubleArray10, doubleArray23);
        double[] doubleArray33 = null;
        try {
            double double34 = org.apache.commons.math.util.MathUtils.distance(doubleArray10, doubleArray33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1078591519 + "'", int2 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1078591519 + "'", int11 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1078591519 + "'", int24 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        double double2 = org.apache.commons.math.util.FastMath.pow(1.5707963267948968d, (double) 2758547353515625L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (byte) 100, 43L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        int int1 = org.apache.commons.math.util.FastMath.round(9.8552368E17f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2147483647 + "'", int1 == 2147483647);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) 'a', 2, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 1124L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5699066473143302d + "'", double1 == 1.5699066473143302d);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        double[] doubleArray2 = new double[] { (byte) 10, (byte) 1 };
        double[] doubleArray4 = new double[] { '4' };
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray4, orderDirection6, false);
        double[] doubleArray10 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray4, (double) 100);
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray4);
        java.lang.Class<?> wildcardClass12 = doubleArray4.getClass();
        double[] doubleArray14 = new double[] { '4' };
        int int15 = org.apache.commons.math.util.MathUtils.hash(doubleArray14);
        double[] doubleArray17 = new double[] { 7.105427357601002E-15d };
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equals(doubleArray14, doubleArray17);
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray4, doubleArray14);
        double[] doubleArray20 = null;
        double[] doubleArray22 = new double[] { '4' };
        int int23 = org.apache.commons.math.util.MathUtils.hash(doubleArray22);
        double[] doubleArray25 = new double[] { 7.105427357601002E-15d };
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equals(doubleArray22, doubleArray25);
        double[] doubleArray28 = new double[] { '4' };
        int int29 = org.apache.commons.math.util.MathUtils.hash(doubleArray28);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection30 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray28, orderDirection30, false);
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray28, (double) 100);
        double[] doubleArray36 = new double[] { 0 };
        double[] doubleArray38 = new double[] { '4' };
        int int39 = org.apache.commons.math.util.MathUtils.hash(doubleArray38);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection40 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray38, orderDirection40, false);
        double double43 = org.apache.commons.math.util.MathUtils.distance1(doubleArray36, doubleArray38);
        double double44 = org.apache.commons.math.util.MathUtils.distance1(doubleArray28, doubleArray38);
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray38, (double) 100.0f);
        double[] doubleArray48 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray38, (double) (short) -1);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray38);
        double double50 = org.apache.commons.math.util.MathUtils.distance1(doubleArray25, doubleArray38);
        boolean boolean51 = org.apache.commons.math.util.MathUtils.equals(doubleArray20, doubleArray25);
        double double52 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray4, doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1078591519 + "'", int5 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1078591519 + "'", int15 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1078591519 + "'", int23 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1078591519 + "'", int29 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1078591519 + "'", int39 == 1078591519);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 52.0d + "'", double43 == 52.0d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 51.99999999999999d + "'", double50 == 51.99999999999999d);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 51.99999999999999d + "'", double52 == 51.99999999999999d);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) (-1052060013), (long) 35);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-36822100455L) + "'", long2 == (-36822100455L));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        int int2 = org.apache.commons.math.util.FastMath.min(87, (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 1124L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(3.1622776601683795d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11.7910068511973d + "'", double1 == 11.7910068511973d);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        double double2 = org.apache.commons.math.util.FastMath.min((-0.9036922050915067d), 1.000000000000007d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.9036922050915067d) + "'", double2 == (-0.9036922050915067d));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.332621544395286E157d + "'", double1 == 9.332621544395286E157d);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 0.0d, (int) (byte) 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        java.lang.String str5 = nonMonotonousSequenceException3.toString();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.0d + "'", number4.equals(0.0d));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= null)" + "'", str5.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= null)"));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(340593888);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        int int1 = org.apache.commons.math.util.FastMath.abs((-88));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 88 + "'", int1 == 88);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        double[] doubleArray0 = null;
        double[] doubleArray3 = new double[] { (byte) 10, (byte) 1 };
        double[] doubleArray5 = new double[] { '4' };
        int int6 = org.apache.commons.math.util.MathUtils.hash(doubleArray5);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray5, orderDirection7, false);
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray5, (double) 100);
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray5);
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray3);
        double double14 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        java.lang.Number number15 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException18 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number15, (java.lang.Number) 0.0d, (int) (byte) 0);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection19 = nonMonotonousSequenceException18.getDirection();
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray3, orderDirection19, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (10 >= 1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1078591519 + "'", int6 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 10.04987562112089d + "'", double14 == 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + orderDirection19 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection19.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        double double1 = org.apache.commons.math.util.FastMath.asinh(8563.535109229691d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.748415547902194d + "'", double1 == 9.748415547902194d);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(6.283185307179586d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 360.0d + "'", double1 == 360.0d);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        double double1 = org.apache.commons.math.util.FastMath.ulp(1.8304096233512614E19d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2048.0d + "'", double1 == 2048.0d);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        double double1 = org.apache.commons.math.util.FastMath.sinh(8563.535167616788d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(3.1622776601683795d, 7.016735912097631E20d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) 3628800L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.6888022127440038d, (double) 1059L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.5042692692183E-4d + "'", double2 == 6.5042692692183E-4d);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((double) 43L, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 43.0d + "'", double2 == 43.0d);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(5.206879716514544E22d, 1.5604874136486533d, 9.619275968248924E151d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(100, 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((int) (byte) -1, 1079574528);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        double[] doubleArray1 = new double[] { '4' };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray4 = new double[] { 7.105427357601002E-15d };
        boolean boolean5 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray4);
        double[] doubleArray8 = new double[] { (byte) 10, (byte) 1 };
        double[] doubleArray10 = new double[] { '4' };
        int int11 = org.apache.commons.math.util.MathUtils.hash(doubleArray10);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray10, orderDirection12, false);
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray10, (double) 100);
        boolean boolean17 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray8, doubleArray10);
        double double18 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray10);
        double[] doubleArray20 = new double[] { '4' };
        int int21 = org.apache.commons.math.util.MathUtils.hash(doubleArray20);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection22 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray20, orderDirection22, false);
        double double25 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray20);
        double double26 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray20);
        double[] doubleArray28 = new double[] { '4' };
        int int29 = org.apache.commons.math.util.MathUtils.hash(doubleArray28);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection30 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray28, orderDirection30, false);
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray28, (double) 100);
        double[] doubleArray36 = new double[] { 0 };
        double[] doubleArray38 = new double[] { '4' };
        int int39 = org.apache.commons.math.util.MathUtils.hash(doubleArray38);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection40 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray38, orderDirection40, false);
        double double43 = org.apache.commons.math.util.MathUtils.distance1(doubleArray36, doubleArray38);
        double double44 = org.apache.commons.math.util.MathUtils.distance1(doubleArray28, doubleArray38);
        double[] doubleArray46 = new double[] { '4' };
        int int47 = org.apache.commons.math.util.MathUtils.hash(doubleArray46);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection48 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray46, orderDirection48, false);
        double[] doubleArray52 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray46, (double) 100);
        double[] doubleArray54 = new double[] { 0 };
        double[] doubleArray56 = new double[] { '4' };
        int int57 = org.apache.commons.math.util.MathUtils.hash(doubleArray56);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection58 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray56, orderDirection58, false);
        double double61 = org.apache.commons.math.util.MathUtils.distance1(doubleArray54, doubleArray56);
        double double62 = org.apache.commons.math.util.MathUtils.distance1(doubleArray46, doubleArray56);
        double[] doubleArray64 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray56, (double) 100.0f);
        double[] doubleArray66 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray56, (double) (short) -1);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray56);
        boolean boolean68 = org.apache.commons.math.util.MathUtils.equals(doubleArray28, doubleArray56);
        double double69 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray56);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray56);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1078591519 + "'", int2 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1078591519 + "'", int11 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1078591519 + "'", int21 == 1078591519);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 52.0d + "'", double25 == 52.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1078591519 + "'", int29 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1078591519 + "'", int39 == 1078591519);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 52.0d + "'", double43 == 52.0d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1078591519 + "'", int47 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1078591519 + "'", int57 == 1078591519);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 52.0d + "'", double61 == 52.0d);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(43L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43L + "'", long2 == 43L);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        double double1 = org.apache.commons.math.util.MathUtils.sign((-0.5278888682247537d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 88L, 51.99999999999999d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.2974748604157617E101d + "'", double2 == 1.2974748604157617E101d);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.043329155290542036d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.04332915529054204d + "'", double1 == 0.04332915529054204d);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(360.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.113786608980126d + "'", double1 == 7.113786608980126d);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) (-99), (-88), 88);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        int int1 = org.apache.commons.math.util.FastMath.abs(1493119226);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1493119226 + "'", int1 == 1493119226);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(0.025391856473934358d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.000322390508714d + "'", double1 == 1.000322390508714d);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(9, 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 900 + "'", int2 == 900);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) (-99));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.7278759594743862d) + "'", double1 == (-1.7278759594743862d));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 1104155264, (float) 0L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        double[] doubleArray1 = new double[] { '4' };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection3, false);
        double[] doubleArray7 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray1, (double) 100);
        double[] doubleArray9 = new double[] { 0 };
        double[] doubleArray11 = new double[] { '4' };
        int int12 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11, orderDirection13, false);
        double double16 = org.apache.commons.math.util.MathUtils.distance1(doubleArray9, doubleArray11);
        double double17 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray11);
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, (double) 100.0f);
        double[] doubleArray21 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, (double) (short) -1);
        double[] doubleArray23 = new double[] { '4' };
        int int24 = org.apache.commons.math.util.MathUtils.hash(doubleArray23);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection25 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray23, orderDirection25, false);
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray23, (double) 100);
        double[] doubleArray31 = new double[] { 0 };
        double[] doubleArray33 = new double[] { '4' };
        int int34 = org.apache.commons.math.util.MathUtils.hash(doubleArray33);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection35 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray33, orderDirection35, false);
        double double38 = org.apache.commons.math.util.MathUtils.distance1(doubleArray31, doubleArray33);
        double double39 = org.apache.commons.math.util.MathUtils.distance1(doubleArray23, doubleArray33);
        double[] doubleArray41 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray33, (double) 100.0f);
        double double42 = org.apache.commons.math.util.MathUtils.distance1(doubleArray11, doubleArray33);
        double double43 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1078591519 + "'", int2 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1078591519 + "'", int12 == 1078591519);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 52.0d + "'", double16 == 52.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1078591519 + "'", int24 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1078591519 + "'", int34 == 1078591519);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 52.0d + "'", double38 == 52.0d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 52.0d + "'", double43 == 52.0d);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 8.0f, 0.025391856473934358d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.025391856473934358d + "'", double2 == 0.025391856473934358d);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(54);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 164.3201122631952d + "'", double1 == 164.3201122631952d);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        int[] intArray3 = new int[] { 1024, 1078591519, (-1052060013) };
        int[] intArray5 = new int[] { (byte) 100 };
        int[] intArray8 = new int[] { 1, (short) -1 };
        int[] intArray12 = new int[] { 10, (byte) 0, (byte) 1 };
        double double13 = org.apache.commons.math.util.MathUtils.distance(intArray8, intArray12);
        int int14 = org.apache.commons.math.util.MathUtils.distance1(intArray5, intArray12);
        int[] intArray16 = new int[] { (byte) 100 };
        int[] intArray19 = new int[] { 1, (short) -1 };
        int[] intArray23 = new int[] { 10, (byte) 0, (byte) 1 };
        double double24 = org.apache.commons.math.util.MathUtils.distance(intArray19, intArray23);
        int int25 = org.apache.commons.math.util.MathUtils.distance1(intArray16, intArray23);
        int int26 = org.apache.commons.math.util.MathUtils.distance1(intArray5, intArray23);
        int[] intArray29 = new int[] { 1, (short) -1 };
        int[] intArray33 = new int[] { 10, (byte) 0, (byte) 1 };
        double double34 = org.apache.commons.math.util.MathUtils.distance(intArray29, intArray33);
        int[] intArray36 = new int[] { (byte) 100 };
        int[] intArray39 = new int[] { 1, (short) -1 };
        int[] intArray43 = new int[] { 10, (byte) 0, (byte) 1 };
        double double44 = org.apache.commons.math.util.MathUtils.distance(intArray39, intArray43);
        int int45 = org.apache.commons.math.util.MathUtils.distance1(intArray36, intArray43);
        int int46 = org.apache.commons.math.util.MathUtils.distanceInf(intArray29, intArray43);
        int[] intArray49 = new int[] { 1, (short) -1 };
        int[] intArray53 = new int[] { 10, (byte) 0, (byte) 1 };
        double double54 = org.apache.commons.math.util.MathUtils.distance(intArray49, intArray53);
        int int55 = org.apache.commons.math.util.MathUtils.distanceInf(intArray29, intArray53);
        int int56 = org.apache.commons.math.util.MathUtils.distance1(intArray5, intArray29);
        int[] intArray59 = new int[] { 1, (short) -1 };
        int[] intArray63 = new int[] { 10, (byte) 0, (byte) 1 };
        double double64 = org.apache.commons.math.util.MathUtils.distance(intArray59, intArray63);
        int[] intArray66 = new int[] { (byte) 100 };
        int[] intArray69 = new int[] { 1, (short) -1 };
        int[] intArray73 = new int[] { 10, (byte) 0, (byte) 1 };
        double double74 = org.apache.commons.math.util.MathUtils.distance(intArray69, intArray73);
        int int75 = org.apache.commons.math.util.MathUtils.distance1(intArray66, intArray73);
        double double76 = org.apache.commons.math.util.MathUtils.distance(intArray63, intArray73);
        int int77 = org.apache.commons.math.util.MathUtils.distanceInf(intArray29, intArray73);
        int int78 = org.apache.commons.math.util.MathUtils.distanceInf(intArray3, intArray73);
        int[] intArray80 = new int[] { (byte) 100 };
        int[] intArray83 = new int[] { 1, (short) -1 };
        int[] intArray87 = new int[] { 10, (byte) 0, (byte) 1 };
        double double88 = org.apache.commons.math.util.MathUtils.distance(intArray83, intArray87);
        int int89 = org.apache.commons.math.util.MathUtils.distance1(intArray80, intArray87);
        try {
            int int90 = org.apache.commons.math.util.MathUtils.distanceInf(intArray73, intArray80);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 9.055385138137417d + "'", double13 == 9.055385138137417d);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 90 + "'", int14 == 90);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 9.055385138137417d + "'", double24 == 9.055385138137417d);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 90 + "'", int25 == 90);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 90 + "'", int26 == 90);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 9.055385138137417d + "'", double34 == 9.055385138137417d);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 9.055385138137417d + "'", double44 == 9.055385138137417d);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 90 + "'", int45 == 90);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 9 + "'", int46 == 9);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 9.055385138137417d + "'", double54 == 9.055385138137417d);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 9 + "'", int55 == 9);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 99 + "'", int56 == 99);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertNotNull(intArray63);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 9.055385138137417d + "'", double64 == 9.055385138137417d);
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertNotNull(intArray69);
        org.junit.Assert.assertNotNull(intArray73);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 9.055385138137417d + "'", double74 == 9.055385138137417d);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 90 + "'", int75 == 90);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.0d + "'", double76 == 0.0d);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 9 + "'", int77 == 9);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 1078591519 + "'", int78 == 1078591519);
        org.junit.Assert.assertNotNull(intArray80);
        org.junit.Assert.assertNotNull(intArray83);
        org.junit.Assert.assertNotNull(intArray87);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 9.055385138137417d + "'", double88 == 9.055385138137417d);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 90 + "'", int89 == 90);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.6540475293360811d, 5.752220392306214d, (-1.2246467991473535E-16d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) 1493119226);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 0.0d, (int) (byte) 0);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection4 = nonMonotonousSequenceException3.getDirection();
        java.lang.Throwable[] throwableArray5 = nonMonotonousSequenceException3.getSuppressed();
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection4.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        double double1 = org.apache.commons.math.util.FastMath.asinh(10.04987562112089d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.003173546455298d + "'", double1 == 3.003173546455298d);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.4841540246378895d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.45089065785741317d + "'", double1 == 0.45089065785741317d);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        int[] intArray3 = new int[] { 1024, 1078591519, (-1052060013) };
        int[] intArray5 = new int[] { (byte) 100 };
        int[] intArray8 = new int[] { 1, (short) -1 };
        int[] intArray12 = new int[] { 10, (byte) 0, (byte) 1 };
        double double13 = org.apache.commons.math.util.MathUtils.distance(intArray8, intArray12);
        int int14 = org.apache.commons.math.util.MathUtils.distance1(intArray5, intArray12);
        int[] intArray16 = new int[] { (byte) 100 };
        int[] intArray19 = new int[] { 1, (short) -1 };
        int[] intArray23 = new int[] { 10, (byte) 0, (byte) 1 };
        double double24 = org.apache.commons.math.util.MathUtils.distance(intArray19, intArray23);
        int int25 = org.apache.commons.math.util.MathUtils.distance1(intArray16, intArray23);
        int int26 = org.apache.commons.math.util.MathUtils.distance1(intArray5, intArray23);
        int[] intArray29 = new int[] { 1, (short) -1 };
        int[] intArray33 = new int[] { 10, (byte) 0, (byte) 1 };
        double double34 = org.apache.commons.math.util.MathUtils.distance(intArray29, intArray33);
        int[] intArray36 = new int[] { (byte) 100 };
        int[] intArray39 = new int[] { 1, (short) -1 };
        int[] intArray43 = new int[] { 10, (byte) 0, (byte) 1 };
        double double44 = org.apache.commons.math.util.MathUtils.distance(intArray39, intArray43);
        int int45 = org.apache.commons.math.util.MathUtils.distance1(intArray36, intArray43);
        int int46 = org.apache.commons.math.util.MathUtils.distanceInf(intArray29, intArray43);
        int[] intArray49 = new int[] { 1, (short) -1 };
        int[] intArray53 = new int[] { 10, (byte) 0, (byte) 1 };
        double double54 = org.apache.commons.math.util.MathUtils.distance(intArray49, intArray53);
        int int55 = org.apache.commons.math.util.MathUtils.distanceInf(intArray29, intArray53);
        int int56 = org.apache.commons.math.util.MathUtils.distance1(intArray5, intArray29);
        int[] intArray59 = new int[] { 1, (short) -1 };
        int[] intArray63 = new int[] { 10, (byte) 0, (byte) 1 };
        double double64 = org.apache.commons.math.util.MathUtils.distance(intArray59, intArray63);
        int[] intArray66 = new int[] { (byte) 100 };
        int[] intArray69 = new int[] { 1, (short) -1 };
        int[] intArray73 = new int[] { 10, (byte) 0, (byte) 1 };
        double double74 = org.apache.commons.math.util.MathUtils.distance(intArray69, intArray73);
        int int75 = org.apache.commons.math.util.MathUtils.distance1(intArray66, intArray73);
        double double76 = org.apache.commons.math.util.MathUtils.distance(intArray63, intArray73);
        int int77 = org.apache.commons.math.util.MathUtils.distanceInf(intArray29, intArray73);
        int int78 = org.apache.commons.math.util.MathUtils.distanceInf(intArray3, intArray73);
        int[] intArray81 = new int[] { 1, (short) -1 };
        int[] intArray85 = new int[] { 10, (byte) 0, (byte) 1 };
        double double86 = org.apache.commons.math.util.MathUtils.distance(intArray81, intArray85);
        int[] intArray88 = new int[] { (byte) 100 };
        int[] intArray91 = new int[] { 1, (short) -1 };
        int[] intArray95 = new int[] { 10, (byte) 0, (byte) 1 };
        double double96 = org.apache.commons.math.util.MathUtils.distance(intArray91, intArray95);
        int int97 = org.apache.commons.math.util.MathUtils.distance1(intArray88, intArray95);
        double double98 = org.apache.commons.math.util.MathUtils.distance(intArray85, intArray95);
        double double99 = org.apache.commons.math.util.MathUtils.distance(intArray3, intArray95);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 9.055385138137417d + "'", double13 == 9.055385138137417d);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 90 + "'", int14 == 90);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 9.055385138137417d + "'", double24 == 9.055385138137417d);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 90 + "'", int25 == 90);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 90 + "'", int26 == 90);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 9.055385138137417d + "'", double34 == 9.055385138137417d);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 9.055385138137417d + "'", double44 == 9.055385138137417d);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 90 + "'", int45 == 90);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 9 + "'", int46 == 9);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 9.055385138137417d + "'", double54 == 9.055385138137417d);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 9 + "'", int55 == 9);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 99 + "'", int56 == 99);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertNotNull(intArray63);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 9.055385138137417d + "'", double64 == 9.055385138137417d);
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertNotNull(intArray69);
        org.junit.Assert.assertNotNull(intArray73);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 9.055385138137417d + "'", double74 == 9.055385138137417d);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 90 + "'", int75 == 90);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.0d + "'", double76 == 0.0d);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 9 + "'", int77 == 9);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 1078591519 + "'", int78 == 1078591519);
        org.junit.Assert.assertNotNull(intArray81);
        org.junit.Assert.assertNotNull(intArray85);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 9.055385138137417d + "'", double86 == 9.055385138137417d);
        org.junit.Assert.assertNotNull(intArray88);
        org.junit.Assert.assertNotNull(intArray91);
        org.junit.Assert.assertNotNull(intArray95);
        org.junit.Assert.assertTrue("'" + double96 + "' != '" + 9.055385138137417d + "'", double96 == 9.055385138137417d);
        org.junit.Assert.assertTrue("'" + int97 + "' != '" + 90 + "'", int97 == 90);
        org.junit.Assert.assertTrue("'" + double98 + "' != '" + 0.0d + "'", double98 == 0.0d);
        org.junit.Assert.assertTrue("'" + double99 + "' != '" + 1.5067149491252272E9d + "'", double99 == 1.5067149491252272E9d);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 985523693061886155L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        double double2 = org.apache.commons.math.util.FastMath.pow(4.440892098500626E-16d, 164.3201122631952d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 985523693061886057L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        float float2 = org.apache.commons.math.util.MathUtils.round(52.0f, 52);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(8.21975785280856E-29d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        double double1 = org.apache.commons.math.util.FastMath.log1p(5.820766091346741E-11d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.820766091177334E-11d + "'", double1 == 5.820766091177334E-11d);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.141592653589793d + "'", double1 == 3.141592653589793d);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        double double1 = org.apache.commons.math.util.FastMath.expm1(Double.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        double double1 = org.apache.commons.math.util.FastMath.exp((-0.23573106550029851d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.789993101766527d + "'", double1 == 0.789993101766527d);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(1.9867717342662448d, 1.5607966601082315d, (-0.41032129904823816d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        double double1 = org.apache.commons.math.util.FastMath.tanh((-0.1413540121206391d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.14042001348501493d) + "'", double1 == (-0.14042001348501493d));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        double double1 = org.apache.commons.math.util.MathUtils.sign(9.055385138137419d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) ' ', (double) 1509505313);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((-1104154140), (-99));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) (-340593976));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 52);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        float float2 = org.apache.commons.math.util.FastMath.max(0.0f, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.406609043584561d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6376590339551076d + "'", double1 == 0.6376590339551076d);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(32.97641394954658d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1889.4093427853531d + "'", double1 == 1889.4093427853531d);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((int) ' ', 9);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        double double1 = org.apache.commons.math.util.FastMath.rint(9.619275968248924E151d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.619275968248924E151d + "'", double1 == 9.619275968248924E151d);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(1, 1493119226);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1493119226 + "'", int2 == 1493119226);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) (byte) 1, (long) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        long long2 = org.apache.commons.math.util.MathUtils.pow(1074790600L, 11L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-8738718778893795328L) + "'", long2 == (-8738718778893795328L));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        double[] doubleArray1 = new double[] { '4' };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection3, false);
        double[] doubleArray7 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray1, (double) 100);
        double[] doubleArray9 = new double[] { 0 };
        double[] doubleArray11 = new double[] { '4' };
        int int12 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11, orderDirection13, false);
        double double16 = org.apache.commons.math.util.MathUtils.distance1(doubleArray9, doubleArray11);
        double double17 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray11);
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, (double) 100.0f);
        double[] doubleArray21 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, (double) (short) -1);
        double[] doubleArray23 = new double[] { '4' };
        int int24 = org.apache.commons.math.util.MathUtils.hash(doubleArray23);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection25 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray23, orderDirection25, false);
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray23, (double) 100);
        double[] doubleArray31 = new double[] { 0 };
        double[] doubleArray33 = new double[] { '4' };
        int int34 = org.apache.commons.math.util.MathUtils.hash(doubleArray33);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection35 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray33, orderDirection35, false);
        double double38 = org.apache.commons.math.util.MathUtils.distance1(doubleArray31, doubleArray33);
        double double39 = org.apache.commons.math.util.MathUtils.distance1(doubleArray23, doubleArray33);
        double[] doubleArray41 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray33, (double) 100.0f);
        double double42 = org.apache.commons.math.util.MathUtils.distance1(doubleArray11, doubleArray33);
        double[] doubleArray44 = new double[] { '4' };
        int int45 = org.apache.commons.math.util.MathUtils.hash(doubleArray44);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection46 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray44, orderDirection46, false);
        double[] doubleArray50 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray44, (double) 100);
        double[] doubleArray52 = new double[] { 0 };
        double[] doubleArray54 = new double[] { '4' };
        int int55 = org.apache.commons.math.util.MathUtils.hash(doubleArray54);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection56 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray54, orderDirection56, false);
        double double59 = org.apache.commons.math.util.MathUtils.distance1(doubleArray52, doubleArray54);
        double double60 = org.apache.commons.math.util.MathUtils.distance1(doubleArray44, doubleArray54);
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray33, doubleArray44);
        double double62 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1078591519 + "'", int2 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1078591519 + "'", int12 == 1078591519);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 52.0d + "'", double16 == 52.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1078591519 + "'", int24 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1078591519 + "'", int34 == 1078591519);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 52.0d + "'", double38 == 52.0d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1078591519 + "'", int45 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1078591519 + "'", int55 == 1078591519);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 52.0d + "'", double59 == 52.0d);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 52.0d + "'", double62 == 52.0d);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        double[] doubleArray1 = new double[] { '4' };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray4 = new double[] { 7.105427357601002E-15d };
        boolean boolean5 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray4);
        double[] doubleArray6 = null;
        try {
            double double7 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray1, doubleArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1078591519 + "'", int2 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.6540475293360811d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((int) (byte) 1, 900);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-899) + "'", int2 == (-899));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-1052060013), (int) '#');
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        double[] doubleArray1 = new double[] { '4' };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection3, false);
        double double6 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray1);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1078591519 + "'", int2 == 1078591519);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 52.0d + "'", double6 == 52.0d);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 99, 9L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 913517247483640899L + "'", long2 == 913517247483640899L);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) (byte) 100, 340593891L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(8, 1509505313);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        java.lang.Number number3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number3, (java.lang.Number) 100, 100);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException6.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 100.0f, (java.lang.Number) (-52L), (int) (byte) 1, orderDirection7, true);
        int int10 = nonMonotonousSequenceException9.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.5661158159967962d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6017862359796351d + "'", double1 == 0.6017862359796351d);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.4841540246378895d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.00845008181671292d + "'", double1 == 0.00845008181671292d);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        double[] doubleArray1 = new double[] { '4' };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray4 = new double[] { 7.105427357601002E-15d };
        boolean boolean5 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray4);
        double[] doubleArray8 = new double[] { (byte) 10, (byte) 1 };
        double[] doubleArray10 = new double[] { '4' };
        int int11 = org.apache.commons.math.util.MathUtils.hash(doubleArray10);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray10, orderDirection12, false);
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray10, (double) 100);
        boolean boolean17 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray8, doubleArray10);
        double double18 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray10);
        double[] doubleArray20 = new double[] { '4' };
        int int21 = org.apache.commons.math.util.MathUtils.hash(doubleArray20);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection22 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray20, orderDirection22, false);
        double double25 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray20);
        double double26 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray20);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException30 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1078591519, (java.lang.Number) 1.0d, (int) (short) 0);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection31 = nonMonotonousSequenceException30.getDirection();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection31, false);
        double[] doubleArray36 = new double[] { (byte) 10, (byte) 1 };
        double[] doubleArray38 = new double[] { '4' };
        int int39 = org.apache.commons.math.util.MathUtils.hash(doubleArray38);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection40 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray38, orderDirection40, false);
        double[] doubleArray44 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray38, (double) 100);
        boolean boolean45 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray36, doubleArray38);
        java.lang.Class<?> wildcardClass46 = doubleArray38.getClass();
        double[] doubleArray48 = new double[] { '4' };
        int int49 = org.apache.commons.math.util.MathUtils.hash(doubleArray48);
        double[] doubleArray51 = new double[] { 7.105427357601002E-15d };
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equals(doubleArray48, doubleArray51);
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray38, doubleArray48);
        double[] doubleArray56 = new double[] { 4.9E-324d, 5.267884728309446d };
        boolean boolean57 = org.apache.commons.math.util.MathUtils.equals(doubleArray48, doubleArray56);
        double double58 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray1, doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1078591519 + "'", int2 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1078591519 + "'", int11 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1078591519 + "'", int21 == 1078591519);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 52.0d + "'", double25 == 52.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection31 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection31.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1078591519 + "'", int39 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(wildcardClass46);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1078591519 + "'", int49 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((int) ' ', (int) 'a');
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        double[] doubleArray4 = new double[] { '4' };
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        double[] doubleArray7 = new double[] { 7.105427357601002E-15d };
        boolean boolean8 = org.apache.commons.math.util.MathUtils.equals(doubleArray4, doubleArray7);
        double[] doubleArray10 = new double[] { '4' };
        int int11 = org.apache.commons.math.util.MathUtils.hash(doubleArray10);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray10, orderDirection12, false);
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray10, (double) 100);
        double[] doubleArray18 = new double[] { 0 };
        double[] doubleArray20 = new double[] { '4' };
        int int21 = org.apache.commons.math.util.MathUtils.hash(doubleArray20);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection22 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray20, orderDirection22, false);
        double double25 = org.apache.commons.math.util.MathUtils.distance1(doubleArray18, doubleArray20);
        double double26 = org.apache.commons.math.util.MathUtils.distance1(doubleArray10, doubleArray20);
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray20, (double) 100.0f);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection29 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray20, orderDirection29, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray4, orderDirection29, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException35 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.5067149491252272E9d, (java.lang.Number) (-0.1413540121206391d), 1078591519, orderDirection29, true);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1078591519 + "'", int5 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1078591519 + "'", int11 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1078591519 + "'", int21 == 1078591519);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 52.0d + "'", double25 == 52.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + orderDirection29 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection29.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        int int1 = org.apache.commons.math.util.MathUtils.hash(3.970291913552122d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 674103171 + "'", int1 == 674103171);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.04332915529054204d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.043302060025879614d + "'", double1 == 0.043302060025879614d);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        double double1 = org.apache.commons.math.util.FastMath.cosh(3.141592653589793d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11.591953275521519d + "'", double1 == 11.591953275521519d);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        java.lang.Number number0 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        java.lang.Class<?> wildcardClass4 = orderDirection3.getClass();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) (byte) -1, (-99), orderDirection3, false);
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow(88L, (-1573460895));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        double[] doubleArray1 = new double[] { '4' };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection3, false);
        double[] doubleArray7 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray1, (double) 100);
        double[] doubleArray9 = new double[] { 0 };
        double[] doubleArray11 = new double[] { '4' };
        int int12 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11, orderDirection13, false);
        double double16 = org.apache.commons.math.util.MathUtils.distance1(doubleArray9, doubleArray11);
        double double17 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray11);
        double[] doubleArray19 = new double[] { '4' };
        int int20 = org.apache.commons.math.util.MathUtils.hash(doubleArray19);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection21 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray19, orderDirection21, false);
        double[] doubleArray25 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, (double) 100);
        double[] doubleArray27 = new double[] { 0 };
        double[] doubleArray29 = new double[] { '4' };
        int int30 = org.apache.commons.math.util.MathUtils.hash(doubleArray29);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection31 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray29, orderDirection31, false);
        double double34 = org.apache.commons.math.util.MathUtils.distance1(doubleArray27, doubleArray29);
        double double35 = org.apache.commons.math.util.MathUtils.distance1(doubleArray19, doubleArray29);
        double[] doubleArray37 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray29, (double) 100.0f);
        double[] doubleArray39 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray29, (double) (short) -1);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray29);
        boolean boolean41 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray29);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1078591519 + "'", int2 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1078591519 + "'", int12 == 1078591519);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 52.0d + "'", double16 == 52.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1078591519 + "'", int20 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1078591519 + "'", int30 == 1078591519);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 52.0d + "'", double34 == 52.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        double double2 = org.apache.commons.math.util.FastMath.atan2(4.6d, 8.881784197001252E-16d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948963d + "'", double2 == 1.5707963267948963d);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.9913289158005998d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9913289158005999d + "'", double1 == 0.9913289158005999d);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) 90);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.102016471589204E38d + "'", double1 == 6.102016471589204E38d);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(8, (-88));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(8563.535109229691d, 1.0333147966386297E40d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 100, 100);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection4 = nonMonotonousSequenceException3.getDirection();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection4.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNull(number5);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(100, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        double[] doubleArray1 = new double[] { '4' };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray4 = new double[] { 7.105427357601002E-15d };
        boolean boolean5 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray4);
        double[] doubleArray8 = new double[] { (byte) 10, (byte) 1 };
        double[] doubleArray10 = new double[] { '4' };
        int int11 = org.apache.commons.math.util.MathUtils.hash(doubleArray10);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray10, orderDirection12, false);
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray10, (double) 100);
        boolean boolean17 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray8, doubleArray10);
        double double18 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray10);
        double[] doubleArray20 = new double[] { '4' };
        int int21 = org.apache.commons.math.util.MathUtils.hash(doubleArray20);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection22 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray20, orderDirection22, false);
        double double25 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray20);
        double double26 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray20);
        java.lang.Number number27 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException30 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number27, (java.lang.Number) 100, 100);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection31 = nonMonotonousSequenceException30.getDirection();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection31, false);
        int int34 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray36 = new double[] { '4' };
        int int37 = org.apache.commons.math.util.MathUtils.hash(doubleArray36);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection38 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray36, orderDirection38, false);
        double[] doubleArray42 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray36, (double) 100);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection43 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray36, orderDirection43, false);
        double[] doubleArray47 = new double[] { '4' };
        int int48 = org.apache.commons.math.util.MathUtils.hash(doubleArray47);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection49 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray47, orderDirection49, false);
        double[] doubleArray53 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray47, (double) 100);
        double double54 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray36, doubleArray53);
        double double55 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray1, doubleArray36);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1078591519 + "'", int2 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1078591519 + "'", int11 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1078591519 + "'", int21 == 1078591519);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 52.0d + "'", double25 == 52.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection31 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection31.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1078591519 + "'", int34 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1078591519 + "'", int37 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1078591519 + "'", int48 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 48.0d + "'", double54 == 48.0d);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        double double2 = org.apache.commons.math.util.MathUtils.round((-0.0d), 1052060012);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(0.019998666799998722d, (-340593976), 200);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        int int1 = org.apache.commons.math.util.FastMath.abs(900);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 900 + "'", int1 == 900);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        int int1 = org.apache.commons.math.util.MathUtils.sign((-99));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.01999733397315053d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.019800013540950654d + "'", double1 == 0.019800013540950654d);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.9999798297878753d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8813593244538519d + "'", double1 == 0.8813593244538519d);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 100.0f, 7.105427357601002E-15d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-7.074204898103558d) + "'", double2 == (-7.074204898103558d));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        double double1 = org.apache.commons.math.util.FastMath.ceil(9.8552369306188621E17d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.8552369306188621E17d + "'", double1 == 9.8552369306188621E17d);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 200);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) (-1));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        double double1 = org.apache.commons.math.util.FastMath.acosh(2.893443985885872d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7242993583184938d + "'", double1 == 1.7242993583184938d);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 0);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(88L, 9L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 97L + "'", long2 == 97L);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-1), (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-10) + "'", int2 == (-10));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        int int2 = org.apache.commons.math.util.FastMath.min(340593891, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        int[] intArray3 = new int[] { 1024, 1078591519, (-1052060013) };
        int[] intArray5 = new int[] { (byte) 100 };
        int[] intArray8 = new int[] { 1, (short) -1 };
        int[] intArray12 = new int[] { 10, (byte) 0, (byte) 1 };
        double double13 = org.apache.commons.math.util.MathUtils.distance(intArray8, intArray12);
        int int14 = org.apache.commons.math.util.MathUtils.distance1(intArray5, intArray12);
        int[] intArray16 = new int[] { (byte) 100 };
        int[] intArray19 = new int[] { 1, (short) -1 };
        int[] intArray23 = new int[] { 10, (byte) 0, (byte) 1 };
        double double24 = org.apache.commons.math.util.MathUtils.distance(intArray19, intArray23);
        int int25 = org.apache.commons.math.util.MathUtils.distance1(intArray16, intArray23);
        int int26 = org.apache.commons.math.util.MathUtils.distance1(intArray5, intArray23);
        int[] intArray29 = new int[] { 1, (short) -1 };
        int[] intArray33 = new int[] { 10, (byte) 0, (byte) 1 };
        double double34 = org.apache.commons.math.util.MathUtils.distance(intArray29, intArray33);
        int[] intArray36 = new int[] { (byte) 100 };
        int[] intArray39 = new int[] { 1, (short) -1 };
        int[] intArray43 = new int[] { 10, (byte) 0, (byte) 1 };
        double double44 = org.apache.commons.math.util.MathUtils.distance(intArray39, intArray43);
        int int45 = org.apache.commons.math.util.MathUtils.distance1(intArray36, intArray43);
        int int46 = org.apache.commons.math.util.MathUtils.distanceInf(intArray29, intArray43);
        int[] intArray49 = new int[] { 1, (short) -1 };
        int[] intArray53 = new int[] { 10, (byte) 0, (byte) 1 };
        double double54 = org.apache.commons.math.util.MathUtils.distance(intArray49, intArray53);
        int int55 = org.apache.commons.math.util.MathUtils.distanceInf(intArray29, intArray53);
        int int56 = org.apache.commons.math.util.MathUtils.distance1(intArray5, intArray29);
        int[] intArray59 = new int[] { 1, (short) -1 };
        int[] intArray63 = new int[] { 10, (byte) 0, (byte) 1 };
        double double64 = org.apache.commons.math.util.MathUtils.distance(intArray59, intArray63);
        int[] intArray66 = new int[] { (byte) 100 };
        int[] intArray69 = new int[] { 1, (short) -1 };
        int[] intArray73 = new int[] { 10, (byte) 0, (byte) 1 };
        double double74 = org.apache.commons.math.util.MathUtils.distance(intArray69, intArray73);
        int int75 = org.apache.commons.math.util.MathUtils.distance1(intArray66, intArray73);
        double double76 = org.apache.commons.math.util.MathUtils.distance(intArray63, intArray73);
        int int77 = org.apache.commons.math.util.MathUtils.distanceInf(intArray29, intArray73);
        int int78 = org.apache.commons.math.util.MathUtils.distanceInf(intArray3, intArray73);
        int[] intArray81 = new int[] { 1, (short) -1 };
        int[] intArray85 = new int[] { 10, (byte) 0, (byte) 1 };
        double double86 = org.apache.commons.math.util.MathUtils.distance(intArray81, intArray85);
        int[] intArray88 = new int[] { (byte) 100 };
        int[] intArray91 = new int[] { 1, (short) -1 };
        int[] intArray95 = new int[] { 10, (byte) 0, (byte) 1 };
        double double96 = org.apache.commons.math.util.MathUtils.distance(intArray91, intArray95);
        int int97 = org.apache.commons.math.util.MathUtils.distance1(intArray88, intArray95);
        double double98 = org.apache.commons.math.util.MathUtils.distance(intArray85, intArray95);
        int int99 = org.apache.commons.math.util.MathUtils.distanceInf(intArray73, intArray85);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 9.055385138137417d + "'", double13 == 9.055385138137417d);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 90 + "'", int14 == 90);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 9.055385138137417d + "'", double24 == 9.055385138137417d);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 90 + "'", int25 == 90);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 90 + "'", int26 == 90);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 9.055385138137417d + "'", double34 == 9.055385138137417d);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 9.055385138137417d + "'", double44 == 9.055385138137417d);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 90 + "'", int45 == 90);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 9 + "'", int46 == 9);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 9.055385138137417d + "'", double54 == 9.055385138137417d);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 9 + "'", int55 == 9);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 99 + "'", int56 == 99);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertNotNull(intArray63);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 9.055385138137417d + "'", double64 == 9.055385138137417d);
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertNotNull(intArray69);
        org.junit.Assert.assertNotNull(intArray73);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 9.055385138137417d + "'", double74 == 9.055385138137417d);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 90 + "'", int75 == 90);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.0d + "'", double76 == 0.0d);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 9 + "'", int77 == 9);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 1078591519 + "'", int78 == 1078591519);
        org.junit.Assert.assertNotNull(intArray81);
        org.junit.Assert.assertNotNull(intArray85);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 9.055385138137417d + "'", double86 == 9.055385138137417d);
        org.junit.Assert.assertNotNull(intArray88);
        org.junit.Assert.assertNotNull(intArray91);
        org.junit.Assert.assertNotNull(intArray95);
        org.junit.Assert.assertTrue("'" + double96 + "' != '" + 9.055385138137417d + "'", double96 == 9.055385138137417d);
        org.junit.Assert.assertTrue("'" + int97 + "' != '" + 90 + "'", int97 == 90);
        org.junit.Assert.assertTrue("'" + double98 + "' != '" + 0.0d + "'", double98 == 0.0d);
        org.junit.Assert.assertTrue("'" + int99 + "' != '" + 0 + "'", int99 == 0);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        double double2 = org.apache.commons.math.util.MathUtils.log(17.872171540421935d, (double) 97);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5866536598456238d + "'", double2 == 1.5866536598456238d);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 10, 33L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) (short) 0, 17.055385138137428d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.0d) + "'", double2 == (-0.0d));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        double double1 = org.apache.commons.math.util.FastMath.log1p(1.5699066473143302d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9438695742451897d + "'", double1 == 0.9438695742451897d);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) (-1), (long) 1124);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        double double2 = org.apache.commons.math.util.MathUtils.log(2.99822295029797d, 32.97641394954658d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.1837246414845604d + "'", double2 == 3.1837246414845604d);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) (short) -1, 800L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-800L) + "'", long2 == (-800L));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        double[] doubleArray1 = new double[] { '4' };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double double3 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray1);
        double[] doubleArray5 = new double[] { '4' };
        int int6 = org.apache.commons.math.util.MathUtils.hash(doubleArray5);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray5, orderDirection7, false);
        double double10 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double[] doubleArray12 = new double[] { '4' };
        int int13 = org.apache.commons.math.util.MathUtils.hash(doubleArray12);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray12, orderDirection14, false);
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, (double) 100);
        double[] doubleArray20 = new double[] { 0 };
        double[] doubleArray22 = new double[] { '4' };
        int int23 = org.apache.commons.math.util.MathUtils.hash(doubleArray22);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection24 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray22, orderDirection24, false);
        double double27 = org.apache.commons.math.util.MathUtils.distance1(doubleArray20, doubleArray22);
        double double28 = org.apache.commons.math.util.MathUtils.distance1(doubleArray12, doubleArray22);
        double[] doubleArray30 = new double[] { '4' };
        int int31 = org.apache.commons.math.util.MathUtils.hash(doubleArray30);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection32 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray30, orderDirection32, false);
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray30, (double) 100);
        double[] doubleArray38 = new double[] { 0 };
        double[] doubleArray40 = new double[] { '4' };
        int int41 = org.apache.commons.math.util.MathUtils.hash(doubleArray40);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection42 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray40, orderDirection42, false);
        double double45 = org.apache.commons.math.util.MathUtils.distance1(doubleArray38, doubleArray40);
        double double46 = org.apache.commons.math.util.MathUtils.distance1(doubleArray30, doubleArray40);
        double[] doubleArray48 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray40, (double) 100.0f);
        double[] doubleArray50 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray40, (double) (short) -1);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray40);
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray40);
        double double53 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray12);
        double double54 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1078591519 + "'", int2 == 1078591519);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 52.0d + "'", double3 == 52.0d);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1078591519 + "'", int6 == 1078591519);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 52.0d + "'", double10 == 52.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1078591519 + "'", int13 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1078591519 + "'", int23 == 1078591519);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 52.0d + "'", double27 == 52.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1078591519 + "'", int31 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1078591519 + "'", int41 == 1078591519);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 52.0d + "'", double45 == 52.0d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((-0.552750258507488d), 8563.535109229691d, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (byte) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (int) (short) 10);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) (byte) 0);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) (short) 10);
        java.math.BigInteger bigInteger10 = null;
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, (long) (byte) 0);
        java.math.BigInteger bigInteger13 = null;
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (long) (byte) 0);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, (long) (short) 10);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, bigInteger17);
        java.math.BigInteger bigInteger19 = null;
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, (long) (byte) 0);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, (long) (short) 10);
        java.math.BigInteger bigInteger24 = null;
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger24, (long) (byte) 0);
        java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger26, (long) (short) 10);
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, bigInteger26);
        java.math.BigInteger bigInteger30 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, bigInteger29);
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, bigInteger30);
        java.math.BigInteger bigInteger33 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (int) '#');
        java.math.BigInteger bigInteger34 = null;
        java.math.BigInteger bigInteger36 = org.apache.commons.math.util.MathUtils.pow(bigInteger34, (long) (byte) 0);
        java.math.BigInteger bigInteger37 = null;
        java.math.BigInteger bigInteger39 = org.apache.commons.math.util.MathUtils.pow(bigInteger37, (long) (byte) 0);
        java.math.BigInteger bigInteger41 = org.apache.commons.math.util.MathUtils.pow(bigInteger39, (long) (short) 10);
        java.math.BigInteger bigInteger42 = org.apache.commons.math.util.MathUtils.pow(bigInteger36, bigInteger41);
        java.math.BigInteger bigInteger43 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, bigInteger42);
        java.math.BigInteger bigInteger45 = org.apache.commons.math.util.MathUtils.pow(bigInteger42, 10);
        java.math.BigInteger bigInteger46 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger45);
        java.math.BigInteger bigInteger47 = null;
        java.math.BigInteger bigInteger49 = org.apache.commons.math.util.MathUtils.pow(bigInteger47, (long) (byte) 0);
        java.math.BigInteger bigInteger51 = org.apache.commons.math.util.MathUtils.pow(bigInteger49, (int) (short) 10);
        java.math.BigInteger bigInteger53 = org.apache.commons.math.util.MathUtils.pow(bigInteger51, (long) 'a');
        java.math.BigInteger bigInteger54 = org.apache.commons.math.util.MathUtils.pow(bigInteger45, bigInteger53);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger28);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger30);
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertNotNull(bigInteger33);
        org.junit.Assert.assertNotNull(bigInteger36);
        org.junit.Assert.assertNotNull(bigInteger39);
        org.junit.Assert.assertNotNull(bigInteger41);
        org.junit.Assert.assertNotNull(bigInteger42);
        org.junit.Assert.assertNotNull(bigInteger43);
        org.junit.Assert.assertNotNull(bigInteger45);
        org.junit.Assert.assertNotNull(bigInteger46);
        org.junit.Assert.assertNotNull(bigInteger49);
        org.junit.Assert.assertNotNull(bigInteger51);
        org.junit.Assert.assertNotNull(bigInteger53);
        org.junit.Assert.assertNotNull(bigInteger54);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) (-99), (double) 1.0f);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(99.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.944515159673473E42d + "'", double1 == 4.944515159673473E42d);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        double double1 = org.apache.commons.math.util.FastMath.acos((-0.8813735870195429d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.649558242894909d + "'", double1 == 2.649558242894909d);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        double double1 = org.apache.commons.math.util.FastMath.log(6.102016471589204E38d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 89.30685281944005d + "'", double1 == 89.30685281944005d);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        double[] doubleArray1 = new double[] { '4' };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection3, false);
        double[] doubleArray7 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray1, (double) 100);
        double[] doubleArray9 = new double[] { 0 };
        double[] doubleArray11 = new double[] { '4' };
        int int12 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11, orderDirection13, false);
        double double16 = org.apache.commons.math.util.MathUtils.distance1(doubleArray9, doubleArray11);
        double double17 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray11);
        double double18 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray1);
        double[] doubleArray20 = new double[] { '4' };
        int int21 = org.apache.commons.math.util.MathUtils.hash(doubleArray20);
        double double22 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1078591519 + "'", int2 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1078591519 + "'", int12 == 1078591519);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 52.0d + "'", double16 == 52.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 52.0d + "'", double18 == 52.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1078591519 + "'", int21 == 1078591519);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(9.035405699485793d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.005895157766783d + "'", double1 == 3.005895157766783d);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(6.102016471589204E38d, (double) (-1573460895), 100.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((-10), 8);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(97);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        double double2 = org.apache.commons.math.util.FastMath.pow(Double.NaN, (double) 1104155263);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(48.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.019800013540950654d, (double) (-800L), 0.5988224392024553d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) (-99));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4210854715202004E-14d + "'", double1 == 1.4210854715202004E-14d);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) 100);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 985523693061886155L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((int) (short) 1, (-88));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-87) + "'", int2 == (-87));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(92.13617560368711d, 5.298292365610486d, 8);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        double double1 = org.apache.commons.math.util.FastMath.log(1.5607966601082315d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4451963704655766d + "'", double1 == 0.4451963704655766d);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        double double2 = org.apache.commons.math.util.FastMath.max(1.1840915351162484E42d, 0.4841540246378895d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.1840915351162484E42d + "'", double2 == 1.1840915351162484E42d);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(0L, (long) (-1104154140));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1104154140L + "'", long2 == 1104154140L);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        double double1 = org.apache.commons.math.util.FastMath.expm1(1.986771734266245d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.29195535450082d + "'", double1 == 6.29195535450082d);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (byte) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 985523693061886057L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 88L);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 1493119226);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 21.81728038953947d + "'", double1 == 21.81728038953947d);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        double double1 = org.apache.commons.math.util.FastMath.sin(1.5607966601082315d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999500037496876d + "'", double1 == 0.9999500037496876d);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) 985523693061886157L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        double double1 = org.apache.commons.math.util.MathUtils.sign(8.065817517094494E67d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 3.465735902799727d, (java.lang.Number) 8.881784197001252E-16d, (int) (byte) 1);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.5551133015206257d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        double double2 = org.apache.commons.math.util.MathUtils.round(0.2344051195730661d, 2);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.23d + "'", double2 == 0.23d);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) 800L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1073741824, 1493119226);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        double double1 = org.apache.commons.math.util.FastMath.sinh((-9.060282259287522d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-4303.28974102346d) + "'", double1 == (-4303.28974102346d));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) (-10), 35, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((-0.2556846937279649d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        double double3 = org.apache.commons.math.util.MathUtils.round(1.1102230246251565E-16d, (-88), 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E88d + "'", double3 == 1.0E88d);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.8813593244538519d, 5.298292365610485d, 3.970291913552122d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((-1074790400), (int) (short) 100);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        double double1 = org.apache.commons.math.util.FastMath.log10(6.29195535450082d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7987856323614964d + "'", double1 == 0.7987856323614964d);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1078591519, (java.lang.Number) 1.0d, (int) (short) 0);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException7 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1078591519, (java.lang.Number) 1.0d, (int) (short) 0);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException7);
        boolean boolean9 = nonMonotonousSequenceException3.getStrict();
        java.lang.Number number10 = nonMonotonousSequenceException3.getArgument();
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 1078591519 + "'", number10.equals(1078591519));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 100, 100);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1078591519, (java.lang.Number) 1.0d, (int) (short) 0);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException8);
        boolean boolean10 = nonMonotonousSequenceException8.getStrict();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        int int1 = org.apache.commons.math.util.FastMath.abs((-1052060013));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1052060013 + "'", int1 == 1052060013);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        long long2 = org.apache.commons.math.util.MathUtils.pow(985523693061886047L, 985523693061886155L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3447824565082718239L + "'", long2 == 3447824565082718239L);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 2147483647, (double) (-899));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) (short) 0, (-1L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (byte) 10, (double) 'a', 5.362856488696706E10d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(9.748415547902194d, (double) 1052060047L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.052060044750411E9d + "'", double2 == 1.052060044750411E9d);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 43L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 43 + "'", int1 == 43);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(0L, 1124L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.01999733397315053d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.999800059980007d + "'", double1 == 0.999800059980007d);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        double double1 = org.apache.commons.math.util.FastMath.abs(3.2311742677852644E-26d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.2311742677852644E-26d + "'", double1 == 3.2311742677852644E-26d);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        byte byte1 = org.apache.commons.math.util.MathUtils.sign((byte) -1);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) -1 + "'", byte1 == (byte) -1);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        double double1 = org.apache.commons.math.util.FastMath.abs(3.141592653589793d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.141592653589793d + "'", double1 == 3.141592653589793d);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1078591519, (java.lang.Number) 1.0d, (int) (short) 0);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException7 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1078591519, (java.lang.Number) 1.0d, (int) (short) 0);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException7);
        java.lang.Number number9 = nonMonotonousSequenceException3.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = nonMonotonousSequenceException3.getDirection();
        boolean boolean11 = nonMonotonousSequenceException3.getStrict();
        java.lang.Number number12 = nonMonotonousSequenceException3.getArgument();
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 1.0d + "'", number9.equals(1.0d));
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 1078591519 + "'", number12.equals(1078591519));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (byte) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 985523693061886057L);
        java.lang.Class<?> wildcardClass5 = bigInteger2.getClass();
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) '4');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 52 + "'", int1 == 52);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow((int) '#', (long) (short) -1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 985523693061886057L, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        long long2 = org.apache.commons.math.util.FastMath.max(43L, (long) 2147483647);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2147483647L + "'", long2 == 2147483647L);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-8738718778893795328L), (float) 985523693061886047L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-8.7387189E18f) + "'", float2 == (-8.7387189E18f));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        double double1 = org.apache.commons.math.util.FastMath.atan(1.1102230246251565E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 800L, 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 800.0f + "'", float2 == 800.0f);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-10), 709810715);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(1509505313, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.4841540246378895d, (java.lang.Number) Double.NaN, 1493119226);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        double[] doubleArray1 = new double[] { '4' };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray4 = new double[] { 7.105427357601002E-15d };
        boolean boolean5 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray4);
        double[] doubleArray8 = new double[] { (byte) 10, (byte) 1 };
        double[] doubleArray10 = new double[] { '4' };
        int int11 = org.apache.commons.math.util.MathUtils.hash(doubleArray10);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray10, orderDirection12, false);
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray10, (double) 100);
        boolean boolean17 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray8, doubleArray10);
        double double18 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray10);
        double[] doubleArray20 = new double[] { '4' };
        int int21 = org.apache.commons.math.util.MathUtils.hash(doubleArray20);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection22 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray20, orderDirection22, false);
        double double25 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray20);
        double double26 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray20);
        double[] doubleArray28 = new double[] { '4' };
        int int29 = org.apache.commons.math.util.MathUtils.hash(doubleArray28);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection30 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray28, orderDirection30, false);
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray28, (double) 100);
        double[] doubleArray36 = new double[] { 0 };
        double[] doubleArray38 = new double[] { '4' };
        int int39 = org.apache.commons.math.util.MathUtils.hash(doubleArray38);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection40 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray38, orderDirection40, false);
        double double43 = org.apache.commons.math.util.MathUtils.distance1(doubleArray36, doubleArray38);
        double double44 = org.apache.commons.math.util.MathUtils.distance1(doubleArray28, doubleArray38);
        double[] doubleArray46 = new double[] { '4' };
        int int47 = org.apache.commons.math.util.MathUtils.hash(doubleArray46);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection48 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray46, orderDirection48, false);
        double[] doubleArray52 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray46, (double) 100);
        double[] doubleArray54 = new double[] { 0 };
        double[] doubleArray56 = new double[] { '4' };
        int int57 = org.apache.commons.math.util.MathUtils.hash(doubleArray56);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection58 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray56, orderDirection58, false);
        double double61 = org.apache.commons.math.util.MathUtils.distance1(doubleArray54, doubleArray56);
        double double62 = org.apache.commons.math.util.MathUtils.distance1(doubleArray46, doubleArray56);
        double[] doubleArray64 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray56, (double) 100.0f);
        double[] doubleArray66 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray56, (double) (short) -1);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray56);
        boolean boolean68 = org.apache.commons.math.util.MathUtils.equals(doubleArray28, doubleArray56);
        double double69 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray56);
        double[] doubleArray71 = new double[] { '4' };
        int int72 = org.apache.commons.math.util.MathUtils.hash(doubleArray71);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection73 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray71, orderDirection73, false);
        double[] doubleArray77 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray71, (double) 100);
        double[] doubleArray79 = new double[] { 0 };
        double[] doubleArray81 = new double[] { '4' };
        int int82 = org.apache.commons.math.util.MathUtils.hash(doubleArray81);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection83 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray81, orderDirection83, false);
        double double86 = org.apache.commons.math.util.MathUtils.distance1(doubleArray79, doubleArray81);
        double double87 = org.apache.commons.math.util.MathUtils.distance1(doubleArray71, doubleArray81);
        double[] doubleArray89 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray81, (double) 100.0f);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection90 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray81, orderDirection90, false);
        double double93 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray81);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1078591519 + "'", int2 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1078591519 + "'", int11 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1078591519 + "'", int21 == 1078591519);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 52.0d + "'", double25 == 52.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1078591519 + "'", int29 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1078591519 + "'", int39 == 1078591519);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 52.0d + "'", double43 == 52.0d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1078591519 + "'", int47 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1078591519 + "'", int57 == 1078591519);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 52.0d + "'", double61 == 52.0d);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 1078591519 + "'", int72 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 1078591519 + "'", int82 == 1078591519);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 52.0d + "'", double86 == 52.0d);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 0.0d + "'", double87 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertTrue("'" + orderDirection90 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection90.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + double93 + "' != '" + 0.0d + "'", double93 == 0.0d);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        double double1 = org.apache.commons.math.util.FastMath.cos((-0.4161468365471424d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9146533258523714d + "'", double1 == 0.9146533258523714d);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 9, 3628800L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-813036757852547071L) + "'", long2 == (-813036757852547071L));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        int[] intArray0 = null;
        int[] intArray4 = new int[] { 1024, 1078591519, (-1052060013) };
        int[] intArray6 = new int[] { (byte) 100 };
        int[] intArray9 = new int[] { 1, (short) -1 };
        int[] intArray13 = new int[] { 10, (byte) 0, (byte) 1 };
        double double14 = org.apache.commons.math.util.MathUtils.distance(intArray9, intArray13);
        int int15 = org.apache.commons.math.util.MathUtils.distance1(intArray6, intArray13);
        int[] intArray17 = new int[] { (byte) 100 };
        int[] intArray20 = new int[] { 1, (short) -1 };
        int[] intArray24 = new int[] { 10, (byte) 0, (byte) 1 };
        double double25 = org.apache.commons.math.util.MathUtils.distance(intArray20, intArray24);
        int int26 = org.apache.commons.math.util.MathUtils.distance1(intArray17, intArray24);
        int int27 = org.apache.commons.math.util.MathUtils.distance1(intArray6, intArray24);
        int[] intArray30 = new int[] { 1, (short) -1 };
        int[] intArray34 = new int[] { 10, (byte) 0, (byte) 1 };
        double double35 = org.apache.commons.math.util.MathUtils.distance(intArray30, intArray34);
        int[] intArray37 = new int[] { (byte) 100 };
        int[] intArray40 = new int[] { 1, (short) -1 };
        int[] intArray44 = new int[] { 10, (byte) 0, (byte) 1 };
        double double45 = org.apache.commons.math.util.MathUtils.distance(intArray40, intArray44);
        int int46 = org.apache.commons.math.util.MathUtils.distance1(intArray37, intArray44);
        int int47 = org.apache.commons.math.util.MathUtils.distanceInf(intArray30, intArray44);
        int[] intArray50 = new int[] { 1, (short) -1 };
        int[] intArray54 = new int[] { 10, (byte) 0, (byte) 1 };
        double double55 = org.apache.commons.math.util.MathUtils.distance(intArray50, intArray54);
        int int56 = org.apache.commons.math.util.MathUtils.distanceInf(intArray30, intArray54);
        int int57 = org.apache.commons.math.util.MathUtils.distance1(intArray6, intArray30);
        int[] intArray60 = new int[] { 1, (short) -1 };
        int[] intArray64 = new int[] { 10, (byte) 0, (byte) 1 };
        double double65 = org.apache.commons.math.util.MathUtils.distance(intArray60, intArray64);
        int[] intArray67 = new int[] { (byte) 100 };
        int[] intArray70 = new int[] { 1, (short) -1 };
        int[] intArray74 = new int[] { 10, (byte) 0, (byte) 1 };
        double double75 = org.apache.commons.math.util.MathUtils.distance(intArray70, intArray74);
        int int76 = org.apache.commons.math.util.MathUtils.distance1(intArray67, intArray74);
        double double77 = org.apache.commons.math.util.MathUtils.distance(intArray64, intArray74);
        int int78 = org.apache.commons.math.util.MathUtils.distanceInf(intArray30, intArray74);
        int int79 = org.apache.commons.math.util.MathUtils.distanceInf(intArray4, intArray74);
        try {
            int int80 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray74);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 9.055385138137417d + "'", double14 == 9.055385138137417d);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 90 + "'", int15 == 90);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 9.055385138137417d + "'", double25 == 9.055385138137417d);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 90 + "'", int26 == 90);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 90 + "'", int27 == 90);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 9.055385138137417d + "'", double35 == 9.055385138137417d);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 9.055385138137417d + "'", double45 == 9.055385138137417d);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 90 + "'", int46 == 90);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 9 + "'", int47 == 9);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertNotNull(intArray54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 9.055385138137417d + "'", double55 == 9.055385138137417d);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 9 + "'", int56 == 9);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 99 + "'", int57 == 99);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertNotNull(intArray64);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 9.055385138137417d + "'", double65 == 9.055385138137417d);
        org.junit.Assert.assertNotNull(intArray67);
        org.junit.Assert.assertNotNull(intArray70);
        org.junit.Assert.assertNotNull(intArray74);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 9.055385138137417d + "'", double75 == 9.055385138137417d);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 90 + "'", int76 == 90);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 0.0d + "'", double77 == 0.0d);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 9 + "'", int78 == 9);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 1078591519 + "'", int79 == 1078591519);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.6616961211922905d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) (byte) 100, 709810715);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (byte) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) (short) 10);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 100);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        double double2 = org.apache.commons.math.util.MathUtils.round(2.8934439858858716d, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1078591519, (java.lang.Number) 1.0d, (int) (short) 0);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException7 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1078591519, (java.lang.Number) 1.0d, (int) (short) 0);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException7);
        int int9 = nonMonotonousSequenceException7.getIndex();
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((-8.7387189E18f));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        double[] doubleArray1 = new double[] { '4' };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection3, false);
        double[] doubleArray7 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray1, (double) 100);
        double[] doubleArray9 = new double[] { 0 };
        double[] doubleArray11 = new double[] { '4' };
        int int12 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11, orderDirection13, false);
        double double16 = org.apache.commons.math.util.MathUtils.distance1(doubleArray9, doubleArray11);
        double double17 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray11);
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, (double) 100.0f);
        double[] doubleArray21 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, (double) (short) -1);
        double[] doubleArray23 = new double[] { '4' };
        int int24 = org.apache.commons.math.util.MathUtils.hash(doubleArray23);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection25 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray23, orderDirection25, false);
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray23, (double) 100);
        double[] doubleArray31 = new double[] { 0 };
        double[] doubleArray33 = new double[] { '4' };
        int int34 = org.apache.commons.math.util.MathUtils.hash(doubleArray33);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection35 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray33, orderDirection35, false);
        double double38 = org.apache.commons.math.util.MathUtils.distance1(doubleArray31, doubleArray33);
        double double39 = org.apache.commons.math.util.MathUtils.distance1(doubleArray23, doubleArray33);
        double[] doubleArray41 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray33, (double) 100.0f);
        double double42 = org.apache.commons.math.util.MathUtils.distance1(doubleArray11, doubleArray33);
        double[] doubleArray44 = new double[] { '4' };
        int int45 = org.apache.commons.math.util.MathUtils.hash(doubleArray44);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection46 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray44, orderDirection46, false);
        double[] doubleArray50 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray44, (double) 100);
        double[] doubleArray52 = new double[] { 0 };
        double[] doubleArray54 = new double[] { '4' };
        int int55 = org.apache.commons.math.util.MathUtils.hash(doubleArray54);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection56 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray54, orderDirection56, false);
        double double59 = org.apache.commons.math.util.MathUtils.distance1(doubleArray52, doubleArray54);
        double double60 = org.apache.commons.math.util.MathUtils.distance1(doubleArray44, doubleArray54);
        double double61 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray44);
        double double62 = org.apache.commons.math.util.MathUtils.distance(doubleArray33, doubleArray44);
        double[] doubleArray64 = new double[] { '4' };
        int int65 = org.apache.commons.math.util.MathUtils.hash(doubleArray64);
        double double66 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray64);
        boolean boolean67 = org.apache.commons.math.util.MathUtils.equals(doubleArray33, doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1078591519 + "'", int2 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1078591519 + "'", int12 == 1078591519);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 52.0d + "'", double16 == 52.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1078591519 + "'", int24 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1078591519 + "'", int34 == 1078591519);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 52.0d + "'", double38 == 52.0d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1078591519 + "'", int45 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1078591519 + "'", int55 == 1078591519);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 52.0d + "'", double59 == 52.0d);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 52.0d + "'", double61 == 52.0d);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 1078591519 + "'", int65 == 1078591519);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 52.0d + "'", double66 == 52.0d);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-1052060013), 1078591519);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 99, 97L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2L + "'", long2 == 2L);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.9785884097858145d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.774576936332999d + "'", double1 == 0.774576936332999d);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        double[] doubleArray1 = new double[] { '4' };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray4 = new double[] { 7.105427357601002E-15d };
        boolean boolean5 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray4);
        double[] doubleArray6 = null;
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray4, doubleArray6);
        double[] doubleArray9 = new double[] { '4' };
        int int10 = org.apache.commons.math.util.MathUtils.hash(doubleArray9);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray9, orderDirection11, false);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, (double) 100);
        double[] doubleArray17 = new double[] { 0 };
        double[] doubleArray19 = new double[] { '4' };
        int int20 = org.apache.commons.math.util.MathUtils.hash(doubleArray19);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection21 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray19, orderDirection21, false);
        double double24 = org.apache.commons.math.util.MathUtils.distance1(doubleArray17, doubleArray19);
        double double25 = org.apache.commons.math.util.MathUtils.distance1(doubleArray9, doubleArray19);
        double[] doubleArray27 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, (double) 100.0f);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection28 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray19, orderDirection28, false);
        try {
            double double31 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray6, doubleArray19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1078591519 + "'", int2 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1078591519 + "'", int10 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1078591519 + "'", int20 == 1078591519);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 52.0d + "'", double24 == 52.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + orderDirection28 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection28.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (short) 0, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) (-1573460895), (long) 1073741824);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-499719071L) + "'", long2 == (-499719071L));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        double double1 = org.apache.commons.math.util.FastMath.expm1(4.754423631317469d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 115.09671936379293d + "'", double1 == 115.09671936379293d);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 1059L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.9650803456014065d + "'", double1 == 6.9650803456014065d);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        int int1 = org.apache.commons.math.util.MathUtils.hash(3.1622776601683795d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2060654347 + "'", int1 == 2060654347);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(5.298292365610487d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.09247264651318218d + "'", double1 == 0.09247264651318218d);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(1.5707963267948966d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.3012989023072947d + "'", double1 == 2.3012989023072947d);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 340593891L, (double) 8.0f, (double) 54);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        double double1 = org.apache.commons.math.util.FastMath.cosh(6.29195535450082d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 270.1052237423238d + "'", double1 == 270.1052237423238d);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        double double2 = org.apache.commons.math.util.FastMath.min(0.6616961211922905d, 0.6738001006480598d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.6616961211922905d + "'", double2 == 0.6616961211922905d);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (byte) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (int) (short) 10);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) (byte) 0);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) (short) 10);
        java.math.BigInteger bigInteger10 = null;
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, (long) (byte) 0);
        java.math.BigInteger bigInteger13 = null;
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (long) (byte) 0);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, (long) (short) 10);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, bigInteger17);
        java.math.BigInteger bigInteger19 = null;
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, (long) (byte) 0);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, (long) (short) 10);
        java.math.BigInteger bigInteger24 = null;
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger24, (long) (byte) 0);
        java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger26, (long) (short) 10);
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, bigInteger26);
        java.math.BigInteger bigInteger30 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, bigInteger29);
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, bigInteger30);
        java.math.BigInteger bigInteger33 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (int) '#');
        java.math.BigInteger bigInteger34 = null;
        java.math.BigInteger bigInteger36 = org.apache.commons.math.util.MathUtils.pow(bigInteger34, (long) (byte) 0);
        java.math.BigInteger bigInteger37 = null;
        java.math.BigInteger bigInteger39 = org.apache.commons.math.util.MathUtils.pow(bigInteger37, (long) (byte) 0);
        java.math.BigInteger bigInteger41 = org.apache.commons.math.util.MathUtils.pow(bigInteger39, (long) (short) 10);
        java.math.BigInteger bigInteger42 = org.apache.commons.math.util.MathUtils.pow(bigInteger36, bigInteger41);
        java.math.BigInteger bigInteger43 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, bigInteger42);
        java.math.BigInteger bigInteger45 = org.apache.commons.math.util.MathUtils.pow(bigInteger42, 10);
        java.math.BigInteger bigInteger46 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger45);
        java.math.BigInteger bigInteger47 = null;
        try {
            java.math.BigInteger bigInteger48 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger47);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger28);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger30);
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertNotNull(bigInteger33);
        org.junit.Assert.assertNotNull(bigInteger36);
        org.junit.Assert.assertNotNull(bigInteger39);
        org.junit.Assert.assertNotNull(bigInteger41);
        org.junit.Assert.assertNotNull(bigInteger42);
        org.junit.Assert.assertNotNull(bigInteger43);
        org.junit.Assert.assertNotNull(bigInteger45);
        org.junit.Assert.assertNotNull(bigInteger46);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (byte) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) (short) 10);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) (byte) 0);
        java.math.BigInteger bigInteger8 = null;
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, (long) (byte) 0);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, (long) (short) 10);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, bigInteger12);
        java.math.BigInteger bigInteger14 = null;
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger14, (long) (byte) 0);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, (long) (short) 10);
        java.math.BigInteger bigInteger19 = null;
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, (long) (byte) 0);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, (long) (short) 10);
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, bigInteger21);
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, bigInteger24);
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger25);
        java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (int) '#');
        try {
            java.math.BigInteger bigInteger30 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) (-87));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger28);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        long long1 = org.apache.commons.math.util.FastMath.abs(2147483647L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2147483647L + "'", long1 == 2147483647L);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(0.00845008181671292d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.008450182378513804d + "'", double1 == 0.008450182378513804d);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(3.5033980603867243d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.5033980603867247d + "'", double1 == 3.5033980603867247d);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        int int2 = org.apache.commons.math.util.MathUtils.pow(674103171, 2060654347);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 153499259 + "'", int2 == 153499259);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 1509505313, (long) 1104155264);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3923610861786877953L + "'", long2 == 3923610861786877953L);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((-813036757852547071L), (long) 52);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-813036757852547019L) + "'", long2 == (-813036757852547019L));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(0.0d, 3.1622776601683795d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialLog((int) (byte) -1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        double double1 = org.apache.commons.math.util.FastMath.log(9.748415547902194d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.277104763896448d + "'", double1 == 2.277104763896448d);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        long long1 = org.apache.commons.math.util.FastMath.round((-0.41032129904823816d));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }
}

