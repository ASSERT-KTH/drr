import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(1.1752011936438016d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.055287372175112d + "'", double1 == 1.055287372175112d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (short) 0, 1079574528);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1079574528 + "'", int2 == 1079574528);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (byte) 0);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (long) (byte) 0);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) (short) 10);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger7);
        java.math.BigInteger bigInteger9 = null;
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (long) (byte) 0);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, (long) (short) 10);
        java.math.BigInteger bigInteger14 = null;
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger14, (long) (byte) 0);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, (long) (short) 10);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, bigInteger16);
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, (int) 'a');
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, 99);
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, 340593888);
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, bigInteger25);
        java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) 2147483647);
        java.math.BigInteger bigInteger30 = org.apache.commons.math.util.MathUtils.pow(bigInteger28, (int) 'a');
        java.math.BigInteger bigInteger32 = org.apache.commons.math.util.MathUtils.pow(bigInteger30, (long) '4');
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger28);
        org.junit.Assert.assertNotNull(bigInteger30);
        org.junit.Assert.assertNotNull(bigInteger32);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (short) -1, (-1104154140));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1104154140) + "'", int2 == (-1104154140));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 100, 100);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1078591519, (java.lang.Number) 1.0d, (int) (short) 0);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException8);
        java.lang.Number number10 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number10, (java.lang.Number) 100, 100);
        boolean boolean14 = nonMonotonousSequenceException13.getStrict();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException18 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1078591519, (java.lang.Number) 1.0d, (int) (short) 0);
        nonMonotonousSequenceException13.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException18);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException13);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        double double1 = org.apache.commons.math.util.FastMath.log10((-0.5278888682247537d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) (byte) 1, 97L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((-7.016709298534875E-15d), 0.0d, 19.64620139003671d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 0.0d, (int) (byte) 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        java.lang.Number number5 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number5, (java.lang.Number) 100, 100);
        boolean boolean9 = nonMonotonousSequenceException8.getStrict();
        int int10 = nonMonotonousSequenceException8.getIndex();
        java.lang.Number number11 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException14 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number11, (java.lang.Number) 0.0d, (int) (byte) 0);
        java.lang.Number number15 = nonMonotonousSequenceException14.getPrevious();
        java.lang.Number number16 = nonMonotonousSequenceException14.getPrevious();
        java.lang.String str17 = nonMonotonousSequenceException14.toString();
        java.lang.Number number18 = nonMonotonousSequenceException14.getPrevious();
        int int19 = nonMonotonousSequenceException14.getIndex();
        nonMonotonousSequenceException8.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException14);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException8);
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 0.0d + "'", number15.equals(0.0d));
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 0.0d + "'", number16.equals(0.0d));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= null)" + "'", str17.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= null)"));
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 0.0d + "'", number18.equals(0.0d));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(99.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 99.00000000000001d + "'", double1 == 99.00000000000001d);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        double double1 = org.apache.commons.math.util.FastMath.sin(9.8552367677649715E17d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8155525103660037d + "'", double1 == 0.8155525103660037d);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.7150149345207635d, (double) 340593888);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 1104155263, 800L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1104154463L + "'", long2 == 1104154463L);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 52, (long) (-340593976));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4427721688L + "'", long2 == 4427721688L);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(1.5067149491252272E9d, (-340593976), (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        double double1 = org.apache.commons.math.util.FastMath.cos((-1.2246467991473535E-16d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (byte) 100, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        double double2 = org.apache.commons.math.util.FastMath.max(4.754423631317469d, 0.5845535578774329d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.754423631317469d + "'", double2 == 4.754423631317469d);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(1.4210854715202004E-14d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4210854715202004E-14d + "'", double1 == 1.4210854715202004E-14d);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        double double2 = org.apache.commons.math.util.FastMath.pow(3.4059388800000006E8d, (-0.5712556729872575d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.3363225468965105E-5d + "'", double2 == 1.3363225468965105E-5d);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) (byte) 10, 2.3012989023072947d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.999999999999998d + "'", double2 == 9.999999999999998d);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 1078591519, 0.8305977954225592d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.8305977954225592d + "'", double2 == 0.8305977954225592d);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((-1104154140), 340593888);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1444748028) + "'", int2 == (-1444748028));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        double double1 = org.apache.commons.math.util.FastMath.tanh(2.0666295932772593E40d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.0f), (java.lang.Number) 1.5607966601082315d, 100, orderDirection3, false);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(throwableArray6);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.5988224392024553d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1847163416814828d + "'", double1 == 1.1847163416814828d);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) (-1104154140), 11.7910068511973d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (-340593889), 709810715);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 410574641189857375L + "'", long2 == 410574641189857375L);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.7150149345207635d, 0.9092974268256817d, 17.055385138137428d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (byte) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 985523693061886057L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) (byte) 0);
        try {
            java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (-813036757852547071L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        double[] doubleArray2 = new double[] { (byte) 10, (byte) 1 };
        double[] doubleArray4 = new double[] { '4' };
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray4, orderDirection6, false);
        double[] doubleArray10 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray4, (double) 100);
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray4);
        java.lang.Class<?> wildcardClass12 = doubleArray4.getClass();
        double[] doubleArray14 = new double[] { '4' };
        int int15 = org.apache.commons.math.util.MathUtils.hash(doubleArray14);
        double[] doubleArray17 = new double[] { 7.105427357601002E-15d };
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equals(doubleArray14, doubleArray17);
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray4, doubleArray14);
        double[] doubleArray22 = new double[] { 4.9E-324d, 5.267884728309446d };
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equals(doubleArray14, doubleArray22);
        double[] doubleArray25 = new double[] { '4' };
        int int26 = org.apache.commons.math.util.MathUtils.hash(doubleArray25);
        double[] doubleArray28 = new double[] { 7.105427357601002E-15d };
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equals(doubleArray25, doubleArray28);
        double[] doubleArray32 = new double[] { (byte) 10, (byte) 1 };
        double[] doubleArray34 = new double[] { '4' };
        int int35 = org.apache.commons.math.util.MathUtils.hash(doubleArray34);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection36 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray34, orderDirection36, false);
        double[] doubleArray40 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray34, (double) 100);
        boolean boolean41 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray32, doubleArray34);
        double double42 = org.apache.commons.math.util.MathUtils.distance(doubleArray25, doubleArray34);
        double[] doubleArray45 = new double[] { (byte) 10, (byte) 1 };
        double[] doubleArray47 = new double[] { '4' };
        int int48 = org.apache.commons.math.util.MathUtils.hash(doubleArray47);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection49 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray47, orderDirection49, false);
        double[] doubleArray53 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray47, (double) 100);
        boolean boolean54 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray45, doubleArray47);
        java.lang.Class<?> wildcardClass55 = doubleArray47.getClass();
        double double56 = org.apache.commons.math.util.MathUtils.distance(doubleArray34, doubleArray47);
        double[] doubleArray57 = null;
        double[] doubleArray59 = new double[] { '4' };
        int int60 = org.apache.commons.math.util.MathUtils.hash(doubleArray59);
        double[] doubleArray62 = new double[] { 7.105427357601002E-15d };
        boolean boolean63 = org.apache.commons.math.util.MathUtils.equals(doubleArray59, doubleArray62);
        double[] doubleArray65 = new double[] { '4' };
        int int66 = org.apache.commons.math.util.MathUtils.hash(doubleArray65);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection67 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray65, orderDirection67, false);
        double[] doubleArray71 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray65, (double) 100);
        double[] doubleArray73 = new double[] { 0 };
        double[] doubleArray75 = new double[] { '4' };
        int int76 = org.apache.commons.math.util.MathUtils.hash(doubleArray75);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection77 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray75, orderDirection77, false);
        double double80 = org.apache.commons.math.util.MathUtils.distance1(doubleArray73, doubleArray75);
        double double81 = org.apache.commons.math.util.MathUtils.distance1(doubleArray65, doubleArray75);
        double[] doubleArray83 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray75, (double) 100.0f);
        double[] doubleArray85 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray75, (double) (short) -1);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray75);
        double double87 = org.apache.commons.math.util.MathUtils.distance1(doubleArray62, doubleArray75);
        boolean boolean88 = org.apache.commons.math.util.MathUtils.equals(doubleArray57, doubleArray62);
        boolean boolean89 = org.apache.commons.math.util.MathUtils.equals(doubleArray34, doubleArray62);
        boolean boolean90 = org.apache.commons.math.util.MathUtils.equals(doubleArray14, doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1078591519 + "'", int5 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1078591519 + "'", int15 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1078591519 + "'", int26 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1078591519 + "'", int35 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1078591519 + "'", int48 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(wildcardClass55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1078591519 + "'", int60 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 1078591519 + "'", int66 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 1078591519 + "'", int76 == 1078591519);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 52.0d + "'", double80 == 52.0d);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 0.0d + "'", double81 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 51.99999999999999d + "'", double87 == 51.99999999999999d);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + true + "'", boolean90 == true);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 54);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 54.0d + "'", double1 == 54.0d);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        double double2 = org.apache.commons.math.util.MathUtils.log(3.005895157766783d, (-743.7469247408213d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        int int1 = org.apache.commons.math.util.MathUtils.sign(52);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-8.7387189E18f), (java.lang.Number) 99.00000000000001d, 0);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((-0.14042367749334314d), 4.440892098500626E-16d, 1.5866536598456238d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        double double2 = org.apache.commons.math.util.MathUtils.round(0.0d, 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(9L, (long) 674103171);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-674103162L) + "'", long2 == (-674103162L));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        double[] doubleArray1 = new double[] { '4' };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray4 = new double[] { 7.105427357601002E-15d };
        boolean boolean5 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray4);
        double[] doubleArray8 = new double[] { (byte) 10, (byte) 1 };
        double[] doubleArray10 = new double[] { '4' };
        int int11 = org.apache.commons.math.util.MathUtils.hash(doubleArray10);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray10, orderDirection12, false);
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray10, (double) 100);
        boolean boolean17 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray8, doubleArray10);
        double double18 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray10);
        double[] doubleArray20 = new double[] { '4' };
        int int21 = org.apache.commons.math.util.MathUtils.hash(doubleArray20);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection22 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray20, orderDirection22, false);
        double double25 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray20);
        double double26 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray20);
        double[] doubleArray28 = new double[] { '4' };
        int int29 = org.apache.commons.math.util.MathUtils.hash(doubleArray28);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection30 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray28, orderDirection30, false);
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray28, (double) 100);
        double[] doubleArray36 = new double[] { 0 };
        double[] doubleArray38 = new double[] { '4' };
        int int39 = org.apache.commons.math.util.MathUtils.hash(doubleArray38);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection40 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray38, orderDirection40, false);
        double double43 = org.apache.commons.math.util.MathUtils.distance1(doubleArray36, doubleArray38);
        double double44 = org.apache.commons.math.util.MathUtils.distance1(doubleArray28, doubleArray38);
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray38, (double) 100.0f);
        double[] doubleArray48 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray38, (double) (short) -1);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray38);
        boolean boolean50 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1078591519 + "'", int2 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1078591519 + "'", int11 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1078591519 + "'", int21 == 1078591519);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 52.0d + "'", double25 == 52.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1078591519 + "'", int29 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1078591519 + "'", int39 == 1078591519);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 52.0d + "'", double43 == 52.0d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 913517247483640899L, 4.61512051684126d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        double double1 = org.apache.commons.math.util.MathUtils.sign((-1.2246467991473532E-16d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        double double1 = org.apache.commons.math.util.FastMath.log1p(6.9650803456014065d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0750670306433894d + "'", double1 == 2.0750670306433894d);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) 10);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-899), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        double double1 = org.apache.commons.math.util.FastMath.signum(270.1052237423238d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-10), 88);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(709810715, 97);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        double double1 = org.apache.commons.math.util.FastMath.rint((-4303.28974102346d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-4303.0d) + "'", double1 == (-4303.0d));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(54.0d, 3.005895157766783d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 53.99999999999999d + "'", double2 == 53.99999999999999d);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        double double2 = org.apache.commons.math.util.FastMath.atan2(9.8552367677649728E17d, 0.043329155290542036d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(9.332621544395286E157d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.332621544395287E157d + "'", double1 == 9.332621544395287E157d);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (byte) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 985523693061886057L);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) (byte) 0);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) (short) 10);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 9L);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger12);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 43.0f, (double) 985523693061886057L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.8552369306188608E17d + "'", double2 == 9.8552369306188608E17d);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (byte) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        double double1 = org.apache.commons.math.util.FastMath.sinh((-0.5278888682247537d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.552750258507488d) + "'", double1 == (-0.552750258507488d));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(1104154463L, (long) '4');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.4841540246378895d, (double) 52.0f, 87);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 0.0d, (int) (byte) 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        java.lang.String str6 = nonMonotonousSequenceException3.toString();
        java.lang.Number number7 = nonMonotonousSequenceException3.getPrevious();
        int int8 = nonMonotonousSequenceException3.getIndex();
        java.lang.Number number9 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        java.lang.Class<?> wildcardClass13 = orderDirection12.getClass();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number9, (java.lang.Number) 0.019998666799998722d, 1, orderDirection12, true);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException15);
        java.lang.Number number17 = nonMonotonousSequenceException3.getPrevious();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.0d + "'", number4.equals(0.0d));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0d + "'", number5.equals(0.0d));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= null)" + "'", str6.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= null)"));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 0.0d + "'", number7.equals(0.0d));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 0.0d + "'", number17.equals(0.0d));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.019998666799998722d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.01999733375994514d + "'", double1 == 0.01999733375994514d);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        double[] doubleArray1 = new double[] { '4' };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection3, false);
        double[] doubleArray7 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray1, (double) 100);
        double[] doubleArray9 = new double[] { 0 };
        double[] doubleArray11 = new double[] { '4' };
        int int12 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11, orderDirection13, false);
        double double16 = org.apache.commons.math.util.MathUtils.distance1(doubleArray9, doubleArray11);
        double double17 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray11);
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, (double) 100.0f);
        double[] doubleArray21 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, (double) (short) -1);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11);
        java.lang.Number number26 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException29 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number26, (java.lang.Number) 100, 100);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection30 = nonMonotonousSequenceException29.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException32 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2758547353515625L, (java.lang.Number) 0.6888022127440038d, (int) (byte) -1, orderDirection30, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11, orderDirection30, true);
        int int35 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1078591519 + "'", int2 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1078591519 + "'", int12 == 1078591519);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 52.0d + "'", double16 == 52.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + orderDirection30 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection30.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1078591519 + "'", int35 == 1078591519);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 1509505313, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1509505313L + "'", long2 == 1509505313L);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        double double1 = org.apache.commons.math.util.FastMath.ceil(19.64620139003671d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 20.0d + "'", double1 == 20.0d);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(3923610861786877953L, (long) 35);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 985523693061886157L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        double double1 = org.apache.commons.math.util.FastMath.log(270.1052237423238d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.598811600642372d + "'", double1 == 5.598811600642372d);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(0, (int) '#');
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 1059L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 43);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5551133015206257d + "'", double1 == 0.5551133015206257d);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 3.40593888E8f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.40593888E8d + "'", double1 == 3.40593888E8d);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        double double1 = org.apache.commons.math.util.FastMath.abs(1024.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1024.0d + "'", double1 == 1024.0d);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        long long2 = org.apache.commons.math.util.FastMath.max(0L, (long) (-1444748028));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1078591519, (java.lang.Number) 1.0d, (int) (short) 0);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException7 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1078591519, (java.lang.Number) 1.0d, (int) (short) 0);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException7);
        java.lang.Throwable[] throwableArray9 = nonMonotonousSequenceException7.getSuppressed();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1078591519, (java.lang.Number) 1.0d, (int) (short) 0);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException17 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1078591519, (java.lang.Number) 1.0d, (int) (short) 0);
        nonMonotonousSequenceException13.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException17);
        java.lang.Number number19 = nonMonotonousSequenceException17.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection23 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException25 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0d, (java.lang.Number) (byte) -1, (int) '4', orderDirection23, false);
        int int26 = nonMonotonousSequenceException25.getIndex();
        nonMonotonousSequenceException17.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException25);
        nonMonotonousSequenceException7.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException17);
        boolean boolean29 = nonMonotonousSequenceException17.getStrict();
        java.lang.Number number30 = nonMonotonousSequenceException17.getPrevious();
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + 1.0d + "'", number19.equals(1.0d));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 52 + "'", int26 == 52);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + number30 + "' != '" + 1.0d + "'", number30.equals(1.0d));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 90, (float) (-1573460895));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.57346086E9f) + "'", float2 == (-1.57346086E9f));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        double[] doubleArray1 = new double[] { '4' };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection3, false);
        double[] doubleArray7 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray1, (double) 100);
        double[] doubleArray9 = new double[] { 0 };
        double[] doubleArray11 = new double[] { '4' };
        int int12 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11, orderDirection13, false);
        double double16 = org.apache.commons.math.util.MathUtils.distance1(doubleArray9, doubleArray11);
        double double17 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray11);
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, (double) 100.0f);
        double double20 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1078591519 + "'", int2 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1078591519 + "'", int12 == 1078591519);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 52.0d + "'", double16 == 52.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 100.0d + "'", double20 == 100.0d);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(100, 900);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1000 + "'", int2 == 1000);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        double double1 = org.apache.commons.math.util.FastMath.sinh(2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.544137102816975d + "'", double1 == 7.544137102816975d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        double double1 = org.apache.commons.math.util.FastMath.log1p(9.999999999999998d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.3978952727983702d + "'", double1 == 2.3978952727983702d);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        float float2 = org.apache.commons.math.util.MathUtils.round(0.0f, 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 1073741824);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) (-88.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-88.0d) + "'", double1 == (-88.0d));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((int) (short) -1, 200);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-200) + "'", int2 == (-200));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        int int1 = org.apache.commons.math.util.FastMath.abs((-1444748028));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1444748028 + "'", int1 == 1444748028);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) (-674103162L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        double double2 = org.apache.commons.math.util.MathUtils.log(8.21975785280856E-29d, 2.3012989023072947d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.012888417780019397d) + "'", double2 == (-0.012888417780019397d));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 376068537633892224L, 1.8304096233512614E19d, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.0d, (double) 9);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 709810715, 43);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5617882297855941635L + "'", long2 == 5617882297855941635L);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 35.00000000000001d + "'", double1 == 35.00000000000001d);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (byte) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) (short) 10);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) (byte) 0);
        java.math.BigInteger bigInteger8 = null;
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, (long) (byte) 0);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, (long) (short) 10);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, bigInteger12);
        java.math.BigInteger bigInteger14 = null;
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger14, (long) (byte) 0);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, (long) (short) 10);
        java.math.BigInteger bigInteger19 = null;
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, (long) (byte) 0);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, (long) (short) 10);
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, bigInteger21);
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, bigInteger24);
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger25);
        java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (int) '#');
        java.math.BigInteger bigInteger29 = null;
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, (long) (byte) 0);
        java.math.BigInteger bigInteger32 = null;
        java.math.BigInteger bigInteger34 = org.apache.commons.math.util.MathUtils.pow(bigInteger32, (long) (byte) 0);
        java.math.BigInteger bigInteger36 = org.apache.commons.math.util.MathUtils.pow(bigInteger34, (long) (short) 10);
        java.math.BigInteger bigInteger37 = org.apache.commons.math.util.MathUtils.pow(bigInteger31, bigInteger36);
        java.math.BigInteger bigInteger38 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger37);
        java.math.BigInteger bigInteger39 = null;
        java.math.BigInteger bigInteger41 = org.apache.commons.math.util.MathUtils.pow(bigInteger39, (long) (byte) 0);
        java.math.BigInteger bigInteger43 = org.apache.commons.math.util.MathUtils.pow(bigInteger41, (long) (short) 10);
        java.math.BigInteger bigInteger44 = null;
        java.math.BigInteger bigInteger46 = org.apache.commons.math.util.MathUtils.pow(bigInteger44, (long) (byte) 0);
        java.math.BigInteger bigInteger48 = org.apache.commons.math.util.MathUtils.pow(bigInteger46, (long) (short) 10);
        java.math.BigInteger bigInteger49 = org.apache.commons.math.util.MathUtils.pow(bigInteger43, bigInteger46);
        java.math.BigInteger bigInteger51 = org.apache.commons.math.util.MathUtils.pow(bigInteger46, (int) 'a');
        java.math.BigInteger bigInteger53 = org.apache.commons.math.util.MathUtils.pow(bigInteger51, 99);
        java.math.BigInteger bigInteger55 = org.apache.commons.math.util.MathUtils.pow(bigInteger51, 340593888);
        java.math.BigInteger bigInteger56 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger55);
        java.math.BigInteger bigInteger58 = org.apache.commons.math.util.MathUtils.pow(bigInteger55, 1078591519);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger28);
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertNotNull(bigInteger34);
        org.junit.Assert.assertNotNull(bigInteger36);
        org.junit.Assert.assertNotNull(bigInteger37);
        org.junit.Assert.assertNotNull(bigInteger38);
        org.junit.Assert.assertNotNull(bigInteger41);
        org.junit.Assert.assertNotNull(bigInteger43);
        org.junit.Assert.assertNotNull(bigInteger46);
        org.junit.Assert.assertNotNull(bigInteger48);
        org.junit.Assert.assertNotNull(bigInteger49);
        org.junit.Assert.assertNotNull(bigInteger51);
        org.junit.Assert.assertNotNull(bigInteger53);
        org.junit.Assert.assertNotNull(bigInteger55);
        org.junit.Assert.assertNotNull(bigInteger56);
        org.junit.Assert.assertNotNull(bigInteger58);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 1124L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.771137801989229d + "'", double1 == 0.771137801989229d);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 0.0d, (int) (byte) 0);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.String str5 = nonMonotonousSequenceException3.toString();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= null)" + "'", str5.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= null)"));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        int int2 = org.apache.commons.math.util.FastMath.min(1444748028, 340593891);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 340593891 + "'", int2 == 340593891);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        double double2 = org.apache.commons.math.util.MathUtils.round(270.1052237423238d, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 270.1052237423d + "'", double2 == 270.1052237423d);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        double[] doubleArray1 = new double[] { '4' };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection3, false);
        double[] doubleArray7 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray1, (double) 100);
        double[] doubleArray9 = new double[] { 0 };
        double[] doubleArray11 = new double[] { '4' };
        int int12 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11, orderDirection13, false);
        double double16 = org.apache.commons.math.util.MathUtils.distance1(doubleArray9, doubleArray11);
        double double17 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray11);
        double double18 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray1);
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray1, 32.97641394954658d);
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray1, (double) 340593891);
        double[] doubleArray24 = new double[] { '4' };
        int int25 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        double[] doubleArray27 = new double[] { 7.105427357601002E-15d };
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equals(doubleArray24, doubleArray27);
        double[] doubleArray31 = new double[] { (byte) 10, (byte) 1 };
        double[] doubleArray33 = new double[] { '4' };
        int int34 = org.apache.commons.math.util.MathUtils.hash(doubleArray33);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection35 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray33, orderDirection35, false);
        double[] doubleArray39 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray33, (double) 100);
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray31, doubleArray33);
        double double41 = org.apache.commons.math.util.MathUtils.distance(doubleArray24, doubleArray33);
        double[] doubleArray43 = new double[] { '4' };
        int int44 = org.apache.commons.math.util.MathUtils.hash(doubleArray43);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection45 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray43, orderDirection45, false);
        double double48 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray43);
        double double49 = org.apache.commons.math.util.MathUtils.distance1(doubleArray24, doubleArray43);
        java.lang.Number number50 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException53 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number50, (java.lang.Number) 100, 100);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection54 = nonMonotonousSequenceException53.getDirection();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray24, orderDirection54, false);
        int int57 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        double[] doubleArray59 = new double[] { '4' };
        int int60 = org.apache.commons.math.util.MathUtils.hash(doubleArray59);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection61 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray59, orderDirection61, false);
        double[] doubleArray65 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray59, (double) 100);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection66 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray59, orderDirection66, false);
        double[] doubleArray70 = new double[] { '4' };
        int int71 = org.apache.commons.math.util.MathUtils.hash(doubleArray70);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection72 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray70, orderDirection72, false);
        double[] doubleArray76 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray70, (double) 100);
        double double77 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray59, doubleArray76);
        double double78 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray24, doubleArray59);
        double[] doubleArray80 = new double[] { '4' };
        int int81 = org.apache.commons.math.util.MathUtils.hash(doubleArray80);
        double[] doubleArray83 = new double[] { 7.105427357601002E-15d };
        boolean boolean84 = org.apache.commons.math.util.MathUtils.equals(doubleArray80, doubleArray83);
        boolean boolean85 = org.apache.commons.math.util.MathUtils.equals(doubleArray59, doubleArray83);
        boolean boolean86 = org.apache.commons.math.util.MathUtils.equals(doubleArray22, doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1078591519 + "'", int2 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1078591519 + "'", int12 == 1078591519);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 52.0d + "'", double16 == 52.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 52.0d + "'", double18 == 52.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1078591519 + "'", int25 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1078591519 + "'", int34 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1078591519 + "'", int44 == 1078591519);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 52.0d + "'", double48 == 52.0d);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection54 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection54.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1078591519 + "'", int57 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1078591519 + "'", int60 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 1078591519 + "'", int71 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 48.0d + "'", double77 == 48.0d);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 0.0d + "'", double78 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 1078591519 + "'", int81 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        int[] intArray0 = null;
        int[] intArray2 = new int[] { (byte) 100 };
        int[] intArray5 = new int[] { 1, (short) -1 };
        int[] intArray9 = new int[] { 10, (byte) 0, (byte) 1 };
        double double10 = org.apache.commons.math.util.MathUtils.distance(intArray5, intArray9);
        int int11 = org.apache.commons.math.util.MathUtils.distance1(intArray2, intArray9);
        int[] intArray13 = new int[] { (byte) 100 };
        int[] intArray16 = new int[] { 1, (short) -1 };
        int[] intArray20 = new int[] { 10, (byte) 0, (byte) 1 };
        double double21 = org.apache.commons.math.util.MathUtils.distance(intArray16, intArray20);
        int int22 = org.apache.commons.math.util.MathUtils.distance1(intArray13, intArray20);
        int int23 = org.apache.commons.math.util.MathUtils.distance1(intArray2, intArray20);
        int[] intArray26 = new int[] { 1, (short) -1 };
        int[] intArray30 = new int[] { 10, (byte) 0, (byte) 1 };
        double double31 = org.apache.commons.math.util.MathUtils.distance(intArray26, intArray30);
        int[] intArray33 = new int[] { (byte) 100 };
        int[] intArray36 = new int[] { 1, (short) -1 };
        int[] intArray40 = new int[] { 10, (byte) 0, (byte) 1 };
        double double41 = org.apache.commons.math.util.MathUtils.distance(intArray36, intArray40);
        int int42 = org.apache.commons.math.util.MathUtils.distance1(intArray33, intArray40);
        int int43 = org.apache.commons.math.util.MathUtils.distanceInf(intArray26, intArray40);
        int[] intArray46 = new int[] { 1, (short) -1 };
        int[] intArray50 = new int[] { 10, (byte) 0, (byte) 1 };
        double double51 = org.apache.commons.math.util.MathUtils.distance(intArray46, intArray50);
        int int52 = org.apache.commons.math.util.MathUtils.distanceInf(intArray26, intArray50);
        int int53 = org.apache.commons.math.util.MathUtils.distance1(intArray2, intArray26);
        int[] intArray56 = new int[] { 1, (short) -1 };
        int[] intArray60 = new int[] { 10, (byte) 0, (byte) 1 };
        double double61 = org.apache.commons.math.util.MathUtils.distance(intArray56, intArray60);
        int int62 = org.apache.commons.math.util.MathUtils.distance1(intArray26, intArray60);
        int[] intArray65 = new int[] { 1, (short) -1 };
        int[] intArray69 = new int[] { 10, (byte) 0, (byte) 1 };
        double double70 = org.apache.commons.math.util.MathUtils.distance(intArray65, intArray69);
        double double71 = org.apache.commons.math.util.MathUtils.distance(intArray60, intArray69);
        try {
            int int72 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray60);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 9.055385138137417d + "'", double10 == 9.055385138137417d);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 90 + "'", int11 == 90);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 9.055385138137417d + "'", double21 == 9.055385138137417d);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 90 + "'", int22 == 90);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 90 + "'", int23 == 90);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 9.055385138137417d + "'", double31 == 9.055385138137417d);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 9.055385138137417d + "'", double41 == 9.055385138137417d);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 90 + "'", int42 == 90);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 9 + "'", int43 == 9);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 9.055385138137417d + "'", double51 == 9.055385138137417d);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 9 + "'", int52 == 9);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 99 + "'", int53 == 99);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 9.055385138137417d + "'", double61 == 9.055385138137417d);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 10 + "'", int62 == 10);
        org.junit.Assert.assertNotNull(intArray65);
        org.junit.Assert.assertNotNull(intArray69);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 9.055385138137417d + "'", double70 == 9.055385138137417d);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.0d + "'", double71 == 0.0d);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, 1.0E-323d, (int) '4');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        int int1 = org.apache.commons.math.util.FastMath.abs(8);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow((int) ' ', (-200));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        double double1 = org.apache.commons.math.util.FastMath.sinh(7.544137102816975d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 944.8154734160571d + "'", double1 == 944.8154734160571d);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 0.0d, (int) (byte) 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        java.lang.String str6 = nonMonotonousSequenceException3.toString();
        java.lang.String str7 = nonMonotonousSequenceException3.toString();
        java.lang.Throwable throwable8 = null;
        try {
            nonMonotonousSequenceException3.addSuppressed(throwable8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= null)" + "'", str6.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= null)"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= null)" + "'", str7.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= null)"));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        double[] doubleArray1 = new double[] { '4' };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection3, false);
        double[] doubleArray7 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray1, (double) 100);
        double double8 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray7);
        double[] doubleArray10 = new double[] { '4' };
        int int11 = org.apache.commons.math.util.MathUtils.hash(doubleArray10);
        double[] doubleArray13 = new double[] { 7.105427357601002E-15d };
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equals(doubleArray10, doubleArray13);
        double[] doubleArray17 = new double[] { (byte) 10, (byte) 1 };
        double[] doubleArray19 = new double[] { '4' };
        int int20 = org.apache.commons.math.util.MathUtils.hash(doubleArray19);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection21 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray19, orderDirection21, false);
        double[] doubleArray25 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, (double) 100);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray17, doubleArray19);
        double double27 = org.apache.commons.math.util.MathUtils.distance(doubleArray10, doubleArray19);
        double[] doubleArray29 = new double[] { '4' };
        int int30 = org.apache.commons.math.util.MathUtils.hash(doubleArray29);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection31 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray29, orderDirection31, false);
        double double34 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray29);
        double double35 = org.apache.commons.math.util.MathUtils.distance1(doubleArray10, doubleArray29);
        double[] doubleArray37 = new double[] { '4' };
        int int38 = org.apache.commons.math.util.MathUtils.hash(doubleArray37);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection39 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray37, orderDirection39, false);
        double double42 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray37);
        double double43 = org.apache.commons.math.util.MathUtils.distance(doubleArray29, doubleArray37);
        double[] doubleArray45 = new double[] { '4' };
        int int46 = org.apache.commons.math.util.MathUtils.hash(doubleArray45);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection47 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray45, orderDirection47, false);
        double[] doubleArray51 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray45, (double) 100);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection52 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray45, orderDirection52, false);
        double[] doubleArray56 = new double[] { '4' };
        int int57 = org.apache.commons.math.util.MathUtils.hash(doubleArray56);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection58 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray56, orderDirection58, false);
        double[] doubleArray62 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray56, (double) 100);
        double double63 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray45, doubleArray62);
        double double64 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray37, doubleArray62);
        double double65 = org.apache.commons.math.util.MathUtils.distance(doubleArray7, doubleArray62);
        double[] doubleArray67 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, 0.5514266812416906d);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1078591519 + "'", int2 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1078591519 + "'", int11 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1078591519 + "'", int20 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1078591519 + "'", int30 == 1078591519);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 52.0d + "'", double34 == 52.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1078591519 + "'", int38 == 1078591519);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 52.0d + "'", double42 == 52.0d);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1078591519 + "'", int46 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1078591519 + "'", int57 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 48.0d + "'", double63 == 48.0d);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 48.0d + "'", double64 == 48.0d);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray67);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        double[] doubleArray1 = new double[] { '4' };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray4 = new double[] { 7.105427357601002E-15d };
        boolean boolean5 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray4);
        double[] doubleArray7 = new double[] { '4' };
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray7);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7, orderDirection9, false);
        double[] doubleArray13 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, (double) 100);
        double[] doubleArray15 = new double[] { 0 };
        double[] doubleArray17 = new double[] { '4' };
        int int18 = org.apache.commons.math.util.MathUtils.hash(doubleArray17);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection19 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17, orderDirection19, false);
        double double22 = org.apache.commons.math.util.MathUtils.distance1(doubleArray15, doubleArray17);
        double double23 = org.apache.commons.math.util.MathUtils.distance1(doubleArray7, doubleArray17);
        double[] doubleArray25 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray17, (double) 100.0f);
        double[] doubleArray27 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray17, (double) (short) -1);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17);
        double double29 = org.apache.commons.math.util.MathUtils.distance1(doubleArray4, doubleArray17);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17);
        int int31 = org.apache.commons.math.util.MathUtils.hash(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1078591519 + "'", int2 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1078591519 + "'", int8 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1078591519 + "'", int18 == 1078591519);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 52.0d + "'", double22 == 52.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 51.99999999999999d + "'", double29 == 51.99999999999999d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1078591519 + "'", int31 == 1078591519);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (-1074790400), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        int int1 = org.apache.commons.math.util.FastMath.abs((-899));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 899 + "'", int1 == 899);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(43, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        double double1 = org.apache.commons.math.util.FastMath.atanh(2.0666295932772593E40d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 709810715L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 0.0d, (int) (byte) 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        java.lang.String str6 = nonMonotonousSequenceException3.toString();
        java.lang.String str7 = nonMonotonousSequenceException3.toString();
        java.lang.Throwable[] throwableArray8 = nonMonotonousSequenceException3.getSuppressed();
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= null)" + "'", str6.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= null)"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= null)" + "'", str7.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= null)"));
        org.junit.Assert.assertNotNull(throwableArray8);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        int int1 = org.apache.commons.math.util.MathUtils.sign((-899));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        double double2 = org.apache.commons.math.util.FastMath.min(0.6738001006480598d, (double) 1024L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.6738001006480598d + "'", double2 == 0.6738001006480598d);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(1.9721522630525295E-31d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 11L, (double) 1509505313L, (int) '4');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 674103171);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1920928955078125E-7d + "'", double1 == 1.1920928955078125E-7d);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(8.065817517094494E67d, 5557.690612768985d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(20.0d, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 20.0d + "'", double2 == 20.0d);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.774576936332999d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.774576936332999d + "'", double1 == 0.774576936332999d);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0d, (java.lang.Number) (byte) -1, (int) '4', orderDirection3, false);
        int int6 = nonMonotonousSequenceException5.getIndex();
        java.lang.Number number7 = nonMonotonousSequenceException5.getArgument();
        int int8 = nonMonotonousSequenceException5.getIndex();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 52 + "'", int6 == 52);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 0.0d + "'", number7.equals(0.0d));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 52 + "'", int8 == 52);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 2758547353515625L, 88, (-1));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(1052060012, 1078591519);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((-340593976), 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 9.8552368E17f);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 709810715, 1L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 709810715L + "'", long2 == 709810715L);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((-674103162L), 1124L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-674102038L) + "'", long2 == (-674102038L));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 100, (long) 1000);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        java.lang.Number number3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number3, (java.lang.Number) 100, 100);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException6.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 100.0f, (java.lang.Number) (-52L), (int) (byte) 1, orderDirection7, true);
        java.lang.Number number10 = nonMonotonousSequenceException9.getPrevious();
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + (-52L) + "'", number10.equals((-52L)));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 1079574528, (long) (-1444748028));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 129976097533919232L + "'", long2 == 129976097533919232L);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-1104154140), (float) (-1074790400));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.10415411E9f) + "'", float2 == (-1.10415411E9f));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(35, (int) '4');
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        double double1 = org.apache.commons.math.util.FastMath.signum(800.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        double double1 = org.apache.commons.math.util.FastMath.exp(9.748415547902194d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 17127.070276846483d + "'", double1 == 17127.070276846483d);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(43, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 0L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3440585709080678E43d + "'", double1 == 1.3440585709080678E43d);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 0.0d, (int) (byte) 0);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Class<?> wildcardClass5 = throwableArray4.getClass();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) (-8.7387189E18f), 200.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-8.7387188562032056E18d) + "'", double2 == (-8.7387188562032056E18d));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 410574641189857375L, 0.9999500037496876d, (double) 100L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        double[] doubleArray1 = new double[] { '4' };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection3, false);
        double[] doubleArray7 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray1, (double) 100);
        double[] doubleArray9 = new double[] { 0 };
        double[] doubleArray11 = new double[] { '4' };
        int int12 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11, orderDirection13, false);
        double double16 = org.apache.commons.math.util.MathUtils.distance1(doubleArray9, doubleArray11);
        double double17 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray11);
        double double18 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1078591519 + "'", int2 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1078591519 + "'", int12 == 1078591519);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 52.0d + "'", double16 == 52.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 52.0d + "'", double18 == 52.0d);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        double double1 = org.apache.commons.math.util.FastMath.signum(5.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(1073741824, (-99));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((int) (byte) -1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((-1444748028));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (-87), (double) 1509505313L, 35);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        int int1 = org.apache.commons.math.util.MathUtils.sign(97);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (byte) 1, 1052060047L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1052060047L + "'", long2 == 1052060047L);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        double double1 = org.apache.commons.math.util.FastMath.log1p(1.1102230246251565E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 200, (long) 1079574528);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1079574528L + "'", long2 == 1079574528L);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        int[] intArray2 = new int[] { 1, (short) -1 };
        int[] intArray6 = new int[] { 10, (byte) 0, (byte) 1 };
        double double7 = org.apache.commons.math.util.MathUtils.distance(intArray2, intArray6);
        int[] intArray9 = new int[] { (byte) 100 };
        int[] intArray12 = new int[] { 1, (short) -1 };
        int[] intArray16 = new int[] { 10, (byte) 0, (byte) 1 };
        double double17 = org.apache.commons.math.util.MathUtils.distance(intArray12, intArray16);
        int int18 = org.apache.commons.math.util.MathUtils.distance1(intArray9, intArray16);
        double double19 = org.apache.commons.math.util.MathUtils.distance(intArray6, intArray16);
        int[] intArray21 = new int[] { (byte) 100 };
        int[] intArray24 = new int[] { 1, (short) -1 };
        int[] intArray28 = new int[] { 10, (byte) 0, (byte) 1 };
        double double29 = org.apache.commons.math.util.MathUtils.distance(intArray24, intArray28);
        int int30 = org.apache.commons.math.util.MathUtils.distance1(intArray21, intArray28);
        int int31 = org.apache.commons.math.util.MathUtils.distanceInf(intArray16, intArray28);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 9.055385138137417d + "'", double7 == 9.055385138137417d);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 9.055385138137417d + "'", double17 == 9.055385138137417d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 90 + "'", int18 == 90);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 9.055385138137417d + "'", double29 == 9.055385138137417d);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 90 + "'", int30 == 90);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(0, 2060654347);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2060654347 + "'", int2 == 2060654347);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 1078591519);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((-1444748028));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(1.5067149491252272E9d, 1073741824);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5067149491252272E9d + "'", double2 == 1.5067149491252272E9d);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(340593888);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(1.5707963267948968d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.027415567780803778d + "'", double1 == 0.027415567780803778d);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        double[] doubleArray1 = new double[] { '4' };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection3, false);
        double[] doubleArray7 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray1, (double) 100);
        double[] doubleArray9 = new double[] { 0 };
        double[] doubleArray11 = new double[] { '4' };
        int int12 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11, orderDirection13, false);
        double double16 = org.apache.commons.math.util.MathUtils.distance1(doubleArray9, doubleArray11);
        double double17 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray11);
        double[] doubleArray19 = new double[] { '4' };
        int int20 = org.apache.commons.math.util.MathUtils.hash(doubleArray19);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection21 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray19, orderDirection21, false);
        double[] doubleArray25 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, (double) 100);
        double[] doubleArray27 = new double[] { 0 };
        double[] doubleArray29 = new double[] { '4' };
        int int30 = org.apache.commons.math.util.MathUtils.hash(doubleArray29);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection31 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray29, orderDirection31, false);
        double double34 = org.apache.commons.math.util.MathUtils.distance1(doubleArray27, doubleArray29);
        double double35 = org.apache.commons.math.util.MathUtils.distance1(doubleArray19, doubleArray29);
        double[] doubleArray37 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray29, (double) 100.0f);
        double[] doubleArray39 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray29, (double) (short) -1);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray29);
        boolean boolean41 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray29);
        double[] doubleArray43 = new double[] { '4' };
        int int44 = org.apache.commons.math.util.MathUtils.hash(doubleArray43);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection45 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray43, orderDirection45, false);
        double[] doubleArray49 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray43, (double) 100);
        double double50 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray49);
        double[] doubleArray51 = null;
        double[] doubleArray53 = new double[] { '4' };
        int int54 = org.apache.commons.math.util.MathUtils.hash(doubleArray53);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection55 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray53, orderDirection55, false);
        double[] doubleArray59 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray53, (double) 100);
        double[] doubleArray61 = new double[] { 0 };
        double[] doubleArray63 = new double[] { '4' };
        int int64 = org.apache.commons.math.util.MathUtils.hash(doubleArray63);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection65 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray63, orderDirection65, false);
        double double68 = org.apache.commons.math.util.MathUtils.distance1(doubleArray61, doubleArray63);
        double double69 = org.apache.commons.math.util.MathUtils.distance1(doubleArray53, doubleArray63);
        double[] doubleArray71 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray63, (double) 100.0f);
        double[] doubleArray73 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray63, (double) (short) -1);
        boolean boolean74 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray51, doubleArray63);
        double double75 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray49, doubleArray63);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray63);
        double double77 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray29, doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1078591519 + "'", int2 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1078591519 + "'", int12 == 1078591519);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 52.0d + "'", double16 == 52.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1078591519 + "'", int20 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1078591519 + "'", int30 == 1078591519);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 52.0d + "'", double34 == 52.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1078591519 + "'", int44 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 100.0d + "'", double50 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1078591519 + "'", int54 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 1078591519 + "'", int64 == 1078591519);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 52.0d + "'", double68 == 52.0d);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 48.0d + "'", double75 == 48.0d);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 0.0d + "'", double77 == 0.0d);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1078591519, (java.lang.Number) 1.0d, (int) (short) 0);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1078591519, (java.lang.Number) 1.0d, (int) (short) 0);
        nonMonotonousSequenceException6.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException10);
        java.lang.Number number12 = nonMonotonousSequenceException6.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = nonMonotonousSequenceException6.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.4758800785707603E27d, (java.lang.Number) 99, 90, orderDirection13, false);
        java.lang.Number number16 = nonMonotonousSequenceException15.getPrevious();
        java.lang.String str17 = nonMonotonousSequenceException15.toString();
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 1.0d + "'", number12.equals(1.0d));
        org.junit.Assert.assertTrue("'" + orderDirection13 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection13.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 99 + "'", number16.equals(99));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 89 and 90 are not increasing (99 > 2,475,880,078,570,760,300,000,000,000)" + "'", str17.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 89 and 90 are not increasing (99 > 2,475,880,078,570,760,300,000,000,000)"));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        int int2 = org.apache.commons.math.util.FastMath.max(1104155263, 54);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1104155263 + "'", int2 == 1104155263);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 376068537633892224L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2147483647 + "'", int1 == 2147483647);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1078591519, (java.lang.Number) 1.0d, (int) (short) 0);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1078591519, (java.lang.Number) 1.0d, (int) (short) 0);
        nonMonotonousSequenceException9.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException13);
        java.lang.Number number15 = nonMonotonousSequenceException9.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection16 = nonMonotonousSequenceException9.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException18 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.4758800785707603E27d, (java.lang.Number) 99, 90, orderDirection16, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException20 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 100L, (java.lang.Number) 1104155264, (int) '#', orderDirection16, true);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 1.0d + "'", number15.equals(1.0d));
        org.junit.Assert.assertTrue("'" + orderDirection16 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection16.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(0.28366218546322625d, 9, 1079574528);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) (-1573460895), (long) 900);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1573461795L) + "'", long2 == (-1573461795L));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(2, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        long long2 = org.apache.commons.math.util.MathUtils.pow(0L, 43);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        long long1 = org.apache.commons.math.util.FastMath.round(1.5707963267948963d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2L + "'", long1 == 2L);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        int int2 = org.apache.commons.math.util.MathUtils.pow(97, 0L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 674103171);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        int int2 = org.apache.commons.math.util.FastMath.min(1052060013, (-1074790400));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1074790400) + "'", int2 == (-1074790400));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1078591519, (java.lang.Number) 1.0d, (int) (short) 0);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection4 = nonMonotonousSequenceException3.getDirection();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection4.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1078591519 + "'", number5.equals(1078591519));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (byte) 0, (long) 9);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) (short) 10);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        int int1 = org.apache.commons.math.util.FastMath.abs(52);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 52 + "'", int1 == 52);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(0, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((-1074790400), (-200));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1074790600) + "'", int2 == (-1074790600));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        int int2 = org.apache.commons.math.util.FastMath.min(1052060012, 2060654347);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1052060012 + "'", int2 == 1052060012);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test180");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(2.178831236867478d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test181");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(52, 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 50 + "'", int2 == 50);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test182");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(4.754423631317469d, 54.0d, 800.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test183");
        double double1 = org.apache.commons.math.util.FastMath.log(1.000322390508714d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.223385520604992E-4d + "'", double1 == 3.223385520604992E-4d);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test184");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.6144558919811912d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.21150928699510407d) + "'", double1 == (-0.21150928699510407d));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test185");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(4.644483341943245d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 52.009614495783374d + "'", double1 == 52.009614495783374d);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test186");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.21150928699510407d), (java.lang.Number) Double.NaN, 50);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test187");
        double[] doubleArray1 = new double[] { '4' };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection3, false);
        double[] doubleArray7 = new double[] { '4' };
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray7);
        double[] doubleArray10 = new double[] { 7.105427357601002E-15d };
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray10);
        double[] doubleArray13 = new double[] { '4' };
        int int14 = org.apache.commons.math.util.MathUtils.hash(doubleArray13);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray13, orderDirection15, false);
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray13, (double) 100);
        double[] doubleArray21 = new double[] { 0 };
        double[] doubleArray23 = new double[] { '4' };
        int int24 = org.apache.commons.math.util.MathUtils.hash(doubleArray23);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection25 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray23, orderDirection25, false);
        double double28 = org.apache.commons.math.util.MathUtils.distance1(doubleArray21, doubleArray23);
        double double29 = org.apache.commons.math.util.MathUtils.distance1(doubleArray13, doubleArray23);
        double[] doubleArray31 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray23, (double) 100.0f);
        double[] doubleArray33 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray23, (double) (short) -1);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray23);
        double double35 = org.apache.commons.math.util.MathUtils.distance1(doubleArray10, doubleArray23);
        double double36 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray10);
        int int37 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1078591519 + "'", int2 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1078591519 + "'", int8 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1078591519 + "'", int14 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1078591519 + "'", int24 == 1078591519);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 52.0d + "'", double28 == 52.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 51.99999999999999d + "'", double35 == 51.99999999999999d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 51.99999999999999d + "'", double36 == 51.99999999999999d);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1078591519 + "'", int37 == 1078591519);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test188");
        double double1 = org.apache.commons.math.util.FastMath.abs(2048.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2048.0d + "'", double1 == 2048.0d);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test189");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 43.0f, (double) (-1104154140), 88);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test190");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) (byte) 0, 3447824565082718239L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3447824565082718239L + "'", long2 == 3447824565082718239L);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test191");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((-1573461795L), (long) '#');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5L + "'", long2 == 5L);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test192");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 2, (long) (byte) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-8L) + "'", long2 == (-8L));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test193");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(4.944515159673473E42d, 0, 1073741824);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test194");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(11.591953275521519d, 0.0d, (double) 1124L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test195");
        java.lang.Number number0 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        java.lang.Class<?> wildcardClass4 = orderDirection3.getClass();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 0.019998666799998722d, 1, orderDirection3, true);
        java.lang.Number number7 = nonMonotonousSequenceException6.getArgument();
        boolean boolean8 = nonMonotonousSequenceException6.getStrict();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test196");
        int[] intArray1 = new int[] { (byte) 100 };
        int[] intArray4 = new int[] { 1, (short) -1 };
        int[] intArray8 = new int[] { 10, (byte) 0, (byte) 1 };
        double double9 = org.apache.commons.math.util.MathUtils.distance(intArray4, intArray8);
        int int10 = org.apache.commons.math.util.MathUtils.distance1(intArray1, intArray8);
        int[] intArray12 = new int[] { (byte) 100 };
        int[] intArray15 = new int[] { 1, (short) -1 };
        int[] intArray19 = new int[] { 10, (byte) 0, (byte) 1 };
        double double20 = org.apache.commons.math.util.MathUtils.distance(intArray15, intArray19);
        int int21 = org.apache.commons.math.util.MathUtils.distance1(intArray12, intArray19);
        int int22 = org.apache.commons.math.util.MathUtils.distance1(intArray1, intArray19);
        int[] intArray25 = new int[] { 1, (short) -1 };
        int[] intArray29 = new int[] { 10, (byte) 0, (byte) 1 };
        double double30 = org.apache.commons.math.util.MathUtils.distance(intArray25, intArray29);
        int[] intArray32 = new int[] { (byte) 100 };
        int[] intArray35 = new int[] { 1, (short) -1 };
        int[] intArray39 = new int[] { 10, (byte) 0, (byte) 1 };
        double double40 = org.apache.commons.math.util.MathUtils.distance(intArray35, intArray39);
        int int41 = org.apache.commons.math.util.MathUtils.distance1(intArray32, intArray39);
        int int42 = org.apache.commons.math.util.MathUtils.distanceInf(intArray25, intArray39);
        int[] intArray45 = new int[] { 1, (short) -1 };
        int[] intArray49 = new int[] { 10, (byte) 0, (byte) 1 };
        double double50 = org.apache.commons.math.util.MathUtils.distance(intArray45, intArray49);
        int int51 = org.apache.commons.math.util.MathUtils.distanceInf(intArray25, intArray49);
        int int52 = org.apache.commons.math.util.MathUtils.distance1(intArray1, intArray25);
        int[] intArray55 = new int[] { 1, (short) -1 };
        int[] intArray59 = new int[] { 10, (byte) 0, (byte) 1 };
        double double60 = org.apache.commons.math.util.MathUtils.distance(intArray55, intArray59);
        int int61 = org.apache.commons.math.util.MathUtils.distance1(intArray25, intArray59);
        java.lang.Class<?> wildcardClass62 = intArray59.getClass();
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 9.055385138137417d + "'", double9 == 9.055385138137417d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 90 + "'", int10 == 90);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 9.055385138137417d + "'", double20 == 9.055385138137417d);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 90 + "'", int21 == 90);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 90 + "'", int22 == 90);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 9.055385138137417d + "'", double30 == 9.055385138137417d);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 9.055385138137417d + "'", double40 == 9.055385138137417d);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 90 + "'", int41 == 90);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 9 + "'", int42 == 9);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 9.055385138137417d + "'", double50 == 9.055385138137417d);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 9 + "'", int51 == 9);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 99 + "'", int52 == 99);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 9.055385138137417d + "'", double60 == 9.055385138137417d);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 10 + "'", int61 == 10);
        org.junit.Assert.assertNotNull(wildcardClass62);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test197");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(99, (-1104154140));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test198");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 88);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test199");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) (-340593976));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test200");
        java.lang.Number number9 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number9, (java.lang.Number) 100, 100);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = nonMonotonousSequenceException12.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2758547353515625L, (java.lang.Number) 0.6888022127440038d, (int) (byte) -1, orderDirection13, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException17 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 90, (java.lang.Number) 359.1342053695755d, 200, orderDirection13, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-4303.0d), (java.lang.Number) (-0.552750258507488d), (int) (short) 100, orderDirection13, false);
        org.junit.Assert.assertTrue("'" + orderDirection13 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection13.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test201");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(1889.4093427853531d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1889.4093427853534d + "'", double1 == 1889.4093427853534d);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test202");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (byte) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (int) (short) 10);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) 'a');
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 100);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 100, (java.lang.Number) (short) 100, 10);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test203");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 0.0d, (int) (byte) 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException3.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException3.getDirection();
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test204");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(88);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.8548264225740497E134d + "'", double1 == 1.8548264225740497E134d);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test205");
        long long2 = org.apache.commons.math.util.MathUtils.pow(0L, (long) ' ');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test206");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(0, (-87));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test207");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (byte) 0, (long) (byte) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test208");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) (-340593889));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test209");
        double[] doubleArray1 = new double[] { '4' };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection3, false);
        double[] doubleArray7 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray1, (double) 100);
        double[] doubleArray9 = new double[] { 0 };
        double[] doubleArray11 = new double[] { '4' };
        int int12 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11, orderDirection13, false);
        double double16 = org.apache.commons.math.util.MathUtils.distance1(doubleArray9, doubleArray11);
        double double17 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray11);
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, (double) 100.0f);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection20 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11, orderDirection20, false);
        double[] doubleArray24 = new double[] { '4' };
        int int25 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        double[] doubleArray27 = new double[] { 7.105427357601002E-15d };
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equals(doubleArray24, doubleArray27);
        double[] doubleArray31 = new double[] { (byte) 10, (byte) 1 };
        double[] doubleArray33 = new double[] { '4' };
        int int34 = org.apache.commons.math.util.MathUtils.hash(doubleArray33);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection35 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray33, orderDirection35, false);
        double[] doubleArray39 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray33, (double) 100);
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray31, doubleArray33);
        double double41 = org.apache.commons.math.util.MathUtils.distance(doubleArray24, doubleArray33);
        double[] doubleArray43 = new double[] { '4' };
        int int44 = org.apache.commons.math.util.MathUtils.hash(doubleArray43);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection45 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray43, orderDirection45, false);
        double double48 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray43);
        double double49 = org.apache.commons.math.util.MathUtils.distance1(doubleArray24, doubleArray43);
        double[] doubleArray51 = new double[] { '4' };
        int int52 = org.apache.commons.math.util.MathUtils.hash(doubleArray51);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection53 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray51, orderDirection53, false);
        double[] doubleArray57 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray51, (double) 100);
        double[] doubleArray59 = new double[] { 0 };
        double[] doubleArray61 = new double[] { '4' };
        int int62 = org.apache.commons.math.util.MathUtils.hash(doubleArray61);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection63 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray61, orderDirection63, false);
        double double66 = org.apache.commons.math.util.MathUtils.distance1(doubleArray59, doubleArray61);
        double double67 = org.apache.commons.math.util.MathUtils.distance1(doubleArray51, doubleArray61);
        double[] doubleArray69 = new double[] { '4' };
        int int70 = org.apache.commons.math.util.MathUtils.hash(doubleArray69);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection71 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray69, orderDirection71, false);
        double[] doubleArray75 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray69, (double) 100);
        double[] doubleArray77 = new double[] { 0 };
        double[] doubleArray79 = new double[] { '4' };
        int int80 = org.apache.commons.math.util.MathUtils.hash(doubleArray79);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection81 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray79, orderDirection81, false);
        double double84 = org.apache.commons.math.util.MathUtils.distance1(doubleArray77, doubleArray79);
        double double85 = org.apache.commons.math.util.MathUtils.distance1(doubleArray69, doubleArray79);
        double[] doubleArray87 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray79, (double) 100.0f);
        double[] doubleArray89 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray79, (double) (short) -1);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray79);
        boolean boolean91 = org.apache.commons.math.util.MathUtils.equals(doubleArray51, doubleArray79);
        double double92 = org.apache.commons.math.util.MathUtils.distance1(doubleArray24, doubleArray79);
        boolean boolean93 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray79);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1078591519 + "'", int2 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1078591519 + "'", int12 == 1078591519);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 52.0d + "'", double16 == 52.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + orderDirection20 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection20.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1078591519 + "'", int25 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1078591519 + "'", int34 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1078591519 + "'", int44 == 1078591519);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 52.0d + "'", double48 == 52.0d);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1078591519 + "'", int52 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 1078591519 + "'", int62 == 1078591519);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 52.0d + "'", double66 == 52.0d);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 1078591519 + "'", int70 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 1078591519 + "'", int80 == 1078591519);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 52.0d + "'", double84 == 52.0d);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 0.0d + "'", double85 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + true + "'", boolean91 == true);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 0.0d + "'", double92 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + true + "'", boolean93 == true);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test210");
        double double1 = org.apache.commons.math.util.FastMath.tan(8.21975785280856E-29d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.21975785280856E-29d + "'", double1 == 8.21975785280856E-29d);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test211");
        double[] doubleArray1 = new double[] { '4' };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection3, false);
        double[] doubleArray7 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray1, (double) 100);
        double[] doubleArray9 = new double[] { '4' };
        int int10 = org.apache.commons.math.util.MathUtils.hash(doubleArray9);
        double[] doubleArray12 = new double[] { 7.105427357601002E-15d };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(doubleArray9, doubleArray12);
        double[] doubleArray16 = new double[] { (byte) 10, (byte) 1 };
        double[] doubleArray18 = new double[] { '4' };
        int int19 = org.apache.commons.math.util.MathUtils.hash(doubleArray18);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection20 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray18, orderDirection20, false);
        double[] doubleArray24 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray18, (double) 100);
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray16, doubleArray18);
        double double26 = org.apache.commons.math.util.MathUtils.distance(doubleArray9, doubleArray18);
        double[] doubleArray28 = new double[] { '4' };
        int int29 = org.apache.commons.math.util.MathUtils.hash(doubleArray28);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection30 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray28, orderDirection30, false);
        double double33 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray28);
        double double34 = org.apache.commons.math.util.MathUtils.distance1(doubleArray9, doubleArray28);
        double[] doubleArray36 = new double[] { '4' };
        int int37 = org.apache.commons.math.util.MathUtils.hash(doubleArray36);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection38 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray36, orderDirection38, false);
        double double41 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray36);
        double double42 = org.apache.commons.math.util.MathUtils.distance(doubleArray28, doubleArray36);
        double[] doubleArray44 = new double[] { '4' };
        int int45 = org.apache.commons.math.util.MathUtils.hash(doubleArray44);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection46 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray44, orderDirection46, false);
        double[] doubleArray50 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray44, (double) 100);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection51 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray44, orderDirection51, false);
        double[] doubleArray55 = new double[] { '4' };
        int int56 = org.apache.commons.math.util.MathUtils.hash(doubleArray55);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection57 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray55, orderDirection57, false);
        double[] doubleArray61 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray55, (double) 100);
        double double62 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray44, doubleArray61);
        double double63 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray36, doubleArray61);
        double double64 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray36);
        double double65 = org.apache.commons.math.util.MathUtils.distance1(doubleArray7, doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1078591519 + "'", int2 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1078591519 + "'", int10 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1078591519 + "'", int19 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1078591519 + "'", int29 == 1078591519);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 52.0d + "'", double33 == 52.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1078591519 + "'", int37 == 1078591519);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 52.0d + "'", double41 == 52.0d);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1078591519 + "'", int45 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1078591519 + "'", int56 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 48.0d + "'", double62 == 48.0d);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 48.0d + "'", double63 == 48.0d);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 52.0d + "'", double64 == 52.0d);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 48.0d + "'", double65 == 48.0d);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test212");
        double double1 = org.apache.commons.math.util.MathUtils.sign((-0.5278888682247536d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test213");
        double double2 = org.apache.commons.math.util.FastMath.min(0.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test214");
        int int2 = org.apache.commons.math.util.FastMath.max(0, 50);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 50 + "'", int2 == 50);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test215");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((int) ' ', (int) (byte) 100);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test216");
        double double1 = org.apache.commons.math.util.FastMath.tan(2.3978952727983702d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9198925387979966d) + "'", double1 == (-0.9198925387979966d));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test217");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 3628800L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0791492469707313E8d + "'", double1 == 2.0791492469707313E8d);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test218");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(0.5514266812416906d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1559274280097633d + "'", double1 == 1.1559274280097633d);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test219");
        double double2 = org.apache.commons.math.util.FastMath.pow(1.1840915351162484E42d, 0.8556343548213666d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.986972779012214E35d + "'", double2 == 9.986972779012214E35d);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test220");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 9.8552368E17f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 42.12509672691585d + "'", double1 == 42.12509672691585d);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test221");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 985523693061886057L, 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 9.8552368E17f + "'", float2 == 9.8552368E17f);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test222");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(99.00000000000001d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test223");
        double double2 = org.apache.commons.math.util.FastMath.max(2.4758800785707603E27d, (double) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.4758800785707603E27d + "'", double2 == 2.4758800785707603E27d);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test224");
        double[] doubleArray1 = new double[] { '4' };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double double3 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray1);
        double[] doubleArray5 = new double[] { '4' };
        int int6 = org.apache.commons.math.util.MathUtils.hash(doubleArray5);
        double[] doubleArray8 = new double[] { 7.105427357601002E-15d };
        boolean boolean9 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray8);
        double[] doubleArray12 = new double[] { (byte) 10, (byte) 1 };
        double[] doubleArray14 = new double[] { '4' };
        int int15 = org.apache.commons.math.util.MathUtils.hash(doubleArray14);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection16 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray14, orderDirection16, false);
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray14, (double) 100);
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray14);
        double double22 = org.apache.commons.math.util.MathUtils.distance(doubleArray5, doubleArray14);
        double[] doubleArray24 = new double[] { '4' };
        int int25 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection26 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray24, orderDirection26, false);
        double double29 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray24);
        double double30 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray24);
        java.lang.Number number31 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException34 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number31, (java.lang.Number) 100, 100);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection35 = nonMonotonousSequenceException34.getDirection();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray5, orderDirection35, false);
        int int38 = org.apache.commons.math.util.MathUtils.hash(doubleArray5);
        double[] doubleArray40 = new double[] { '4' };
        int int41 = org.apache.commons.math.util.MathUtils.hash(doubleArray40);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection42 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray40, orderDirection42, false);
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray40, (double) 100);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection47 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray40, orderDirection47, false);
        double[] doubleArray51 = new double[] { '4' };
        int int52 = org.apache.commons.math.util.MathUtils.hash(doubleArray51);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection53 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray51, orderDirection53, false);
        double[] doubleArray57 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray51, (double) 100);
        double double58 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray40, doubleArray57);
        double double59 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray40);
        double double60 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray40);
        double[] doubleArray62 = new double[] { '4' };
        int int63 = org.apache.commons.math.util.MathUtils.hash(doubleArray62);
        double[] doubleArray65 = new double[] { 7.105427357601002E-15d };
        boolean boolean66 = org.apache.commons.math.util.MathUtils.equals(doubleArray62, doubleArray65);
        double[] doubleArray68 = new double[] { '4' };
        int int69 = org.apache.commons.math.util.MathUtils.hash(doubleArray68);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection70 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray68, orderDirection70, false);
        double[] doubleArray74 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray68, (double) 100);
        double[] doubleArray76 = new double[] { 0 };
        double[] doubleArray78 = new double[] { '4' };
        int int79 = org.apache.commons.math.util.MathUtils.hash(doubleArray78);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection80 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray78, orderDirection80, false);
        double double83 = org.apache.commons.math.util.MathUtils.distance1(doubleArray76, doubleArray78);
        double double84 = org.apache.commons.math.util.MathUtils.distance1(doubleArray68, doubleArray78);
        double[] doubleArray86 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray78, (double) 100.0f);
        double[] doubleArray88 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray78, (double) (short) -1);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray78);
        double double90 = org.apache.commons.math.util.MathUtils.distance1(doubleArray65, doubleArray78);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray78);
        double[] doubleArray95 = new double[] { 0.8813593244538519d, 0.6376590339551076d, 3447824565082718239L };
        double double96 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray78, doubleArray95);
        boolean boolean97 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray78);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1078591519 + "'", int2 == 1078591519);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 52.0d + "'", double3 == 52.0d);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1078591519 + "'", int6 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1078591519 + "'", int15 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1078591519 + "'", int25 == 1078591519);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 52.0d + "'", double29 == 52.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection35 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection35.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1078591519 + "'", int38 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1078591519 + "'", int41 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1078591519 + "'", int52 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 48.0d + "'", double58 == 48.0d);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1078591519 + "'", int63 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 1078591519 + "'", int69 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 1078591519 + "'", int79 == 1078591519);
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + 52.0d + "'", double83 == 52.0d);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 0.0d + "'", double84 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + 51.99999999999999d + "'", double90 == 51.99999999999999d);
        org.junit.Assert.assertNotNull(doubleArray95);
        org.junit.Assert.assertTrue("'" + double96 + "' != '" + 51.118640675546146d + "'", double96 == 51.118640675546146d);
        org.junit.Assert.assertTrue("'" + boolean97 + "' != '" + true + "'", boolean97 == true);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test225");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((-87), 1104155263);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1104155350) + "'", int2 == (-1104155350));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test226");
        double double1 = org.apache.commons.math.util.FastMath.sin(198.36281798666926d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.4281826694961581d) + "'", double1 == (-0.4281826694961581d));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test227");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 985523693061886155L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 9.8552368E17f + "'", float1 == 9.8552368E17f);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test228");
        double double2 = org.apache.commons.math.util.FastMath.pow((-7.016709298534875E-15d), (double) (-1074790400));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test229");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 100.0f, 0.6144558919811912d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.6144558919811912d + "'", double2 == 0.6144558919811912d);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test230");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 2147483647);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2147483647 + "'", int1 == 2147483647);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test231");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, 52.009614495783374d, 1124);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test232");
        double double1 = org.apache.commons.math.util.FastMath.atan(1.7242993583184938d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0452531650406858d + "'", double1 == 1.0452531650406858d);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test233");
        double double1 = org.apache.commons.math.util.FastMath.cosh(3.005895157766783d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.126894231686824d + "'", double1 == 10.126894231686824d);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test234");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 1444748028, (long) '4');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52L + "'", long2 == 52L);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test235");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(1124L, 99L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1223L + "'", long2 == 1223L);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test236");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(0.0d, (double) (-8738718778893795328L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-8.7387187788937953E18d) + "'", double2 == (-8.7387187788937953E18d));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test237");
        double[] doubleArray1 = new double[] { 0 };
        double[] doubleArray3 = new double[] { '4' };
        int int4 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection5 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray3, orderDirection5, false);
        double double8 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray3);
        double[] doubleArray10 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, 0.5514266812416906d);
        double double11 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1078591519 + "'", int4 == 1078591519);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 52.0d + "'", double8 == 52.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.5514266812416906d + "'", double11 == 0.5514266812416906d);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test238");
        double double2 = org.apache.commons.math.util.FastMath.min((double) (-1.57346086E9f), (double) 1073741824);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.573460864E9d) + "'", double2 == (-1.573460864E9d));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test239");
        double double1 = org.apache.commons.math.util.FastMath.acos(17.055385138137428d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test240");
        double double1 = org.apache.commons.math.util.FastMath.floor(6.9650803456014065d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.0d + "'", double1 == 6.0d);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test241");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) 1444748028, 3.5033980603867243d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.1213476657867432d + "'", double2 == 1.1213476657867432d);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test242");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) (-200));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test243");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) (-813036757852547019L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 128.0d + "'", double1 == 128.0d);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test244");
        double[] doubleArray1 = new double[] { '4' };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray4 = new double[] { 7.105427357601002E-15d };
        boolean boolean5 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray4);
        double[] doubleArray7 = new double[] { '4' };
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray7);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7, orderDirection9, false);
        double[] doubleArray13 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, (double) 100);
        double[] doubleArray15 = new double[] { 0 };
        double[] doubleArray17 = new double[] { '4' };
        int int18 = org.apache.commons.math.util.MathUtils.hash(doubleArray17);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection19 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17, orderDirection19, false);
        double double22 = org.apache.commons.math.util.MathUtils.distance1(doubleArray15, doubleArray17);
        double double23 = org.apache.commons.math.util.MathUtils.distance1(doubleArray7, doubleArray17);
        double[] doubleArray25 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray17, (double) 100.0f);
        double[] doubleArray27 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray17, (double) (short) -1);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17);
        double double29 = org.apache.commons.math.util.MathUtils.distance1(doubleArray4, doubleArray17);
        double[] doubleArray31 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray4, (double) 4427721688L);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1078591519 + "'", int2 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1078591519 + "'", int8 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1078591519 + "'", int18 == 1078591519);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 52.0d + "'", double22 == 52.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 51.99999999999999d + "'", double29 == 51.99999999999999d);
        org.junit.Assert.assertNotNull(doubleArray31);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test245");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 3);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 3.0f + "'", float1 == 3.0f);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test246");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 1024, 1104154463L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test247");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.16299078079570548d) + "'", double1 == (-0.16299078079570548d));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test248");
        double double1 = org.apache.commons.math.util.FastMath.cosh((-8.7387187788937953E18d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test249");
        double[] doubleArray4 = new double[] { '4' };
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray4, orderDirection6, false);
        double[] doubleArray10 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray4, (double) 100);
        double[] doubleArray12 = new double[] { 0 };
        double[] doubleArray14 = new double[] { '4' };
        int int15 = org.apache.commons.math.util.MathUtils.hash(doubleArray14);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection16 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray14, orderDirection16, false);
        double double19 = org.apache.commons.math.util.MathUtils.distance1(doubleArray12, doubleArray14);
        double double20 = org.apache.commons.math.util.MathUtils.distance1(doubleArray4, doubleArray14);
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray14, (double) 100.0f);
        double[] doubleArray24 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray14, (double) (short) -1);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray14);
        java.lang.Number number29 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException32 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number29, (java.lang.Number) 100, 100);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection33 = nonMonotonousSequenceException32.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException35 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2758547353515625L, (java.lang.Number) 0.6888022127440038d, (int) (byte) -1, orderDirection33, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray14, orderDirection33, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException39 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 7.105427357601002E-15d, (java.lang.Number) 10.04987562112089d, 1079574528, orderDirection33, false);
        boolean boolean40 = nonMonotonousSequenceException39.getStrict();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1078591519 + "'", int5 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1078591519 + "'", int15 == 1078591519);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 52.0d + "'", double19 == 52.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + orderDirection33 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection33.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test250");
        double[] doubleArray1 = new double[] { '4' };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection3, false);
        double[] doubleArray7 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray1, (double) 100);
        double[] doubleArray9 = new double[] { 0 };
        double[] doubleArray11 = new double[] { '4' };
        int int12 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11, orderDirection13, false);
        double double16 = org.apache.commons.math.util.MathUtils.distance1(doubleArray9, doubleArray11);
        double double17 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray11);
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, (double) 100.0f);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection20 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11, orderDirection20, false);
        double[] doubleArray24 = new double[] { '4' };
        int int25 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        double[] doubleArray27 = new double[] { 7.105427357601002E-15d };
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equals(doubleArray24, doubleArray27);
        double[] doubleArray31 = new double[] { (byte) 10, (byte) 1 };
        double[] doubleArray33 = new double[] { '4' };
        int int34 = org.apache.commons.math.util.MathUtils.hash(doubleArray33);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection35 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray33, orderDirection35, false);
        double[] doubleArray39 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray33, (double) 100);
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray31, doubleArray33);
        double double41 = org.apache.commons.math.util.MathUtils.distance(doubleArray24, doubleArray33);
        double[] doubleArray43 = new double[] { '4' };
        int int44 = org.apache.commons.math.util.MathUtils.hash(doubleArray43);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection45 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray43, orderDirection45, false);
        double double48 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray43);
        double double49 = org.apache.commons.math.util.MathUtils.distance1(doubleArray24, doubleArray43);
        double[] doubleArray51 = new double[] { '4' };
        int int52 = org.apache.commons.math.util.MathUtils.hash(doubleArray51);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection53 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray51, orderDirection53, false);
        double double56 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray51);
        double double57 = org.apache.commons.math.util.MathUtils.distance(doubleArray43, doubleArray51);
        double double58 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray11, doubleArray51);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray51);
        double[] doubleArray61 = new double[] { '4' };
        int int62 = org.apache.commons.math.util.MathUtils.hash(doubleArray61);
        double[] doubleArray64 = new double[] { 7.105427357601002E-15d };
        boolean boolean65 = org.apache.commons.math.util.MathUtils.equals(doubleArray61, doubleArray64);
        double[] doubleArray67 = new double[] { '4' };
        int int68 = org.apache.commons.math.util.MathUtils.hash(doubleArray67);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection69 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray67, orderDirection69, false);
        double[] doubleArray73 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray67, (double) 100);
        double[] doubleArray75 = new double[] { 0 };
        double[] doubleArray77 = new double[] { '4' };
        int int78 = org.apache.commons.math.util.MathUtils.hash(doubleArray77);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection79 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray77, orderDirection79, false);
        double double82 = org.apache.commons.math.util.MathUtils.distance1(doubleArray75, doubleArray77);
        double double83 = org.apache.commons.math.util.MathUtils.distance1(doubleArray67, doubleArray77);
        double[] doubleArray85 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray77, (double) 100.0f);
        double[] doubleArray87 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray77, (double) (short) -1);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray77);
        double double89 = org.apache.commons.math.util.MathUtils.distance1(doubleArray64, doubleArray77);
        double double90 = org.apache.commons.math.util.MathUtils.distance(doubleArray51, doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1078591519 + "'", int2 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1078591519 + "'", int12 == 1078591519);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 52.0d + "'", double16 == 52.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + orderDirection20 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection20.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1078591519 + "'", int25 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1078591519 + "'", int34 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1078591519 + "'", int44 == 1078591519);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 52.0d + "'", double48 == 52.0d);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1078591519 + "'", int52 == 1078591519);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 52.0d + "'", double56 == 52.0d);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 1078591519 + "'", int62 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 1078591519 + "'", int68 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 1078591519 + "'", int78 == 1078591519);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 52.0d + "'", double82 == 52.0d);
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + 0.0d + "'", double83 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 51.99999999999999d + "'", double89 == 51.99999999999999d);
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + 51.99999999999999d + "'", double90 == 51.99999999999999d);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test251");
        double double1 = org.apache.commons.math.util.FastMath.atanh(11.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test252");
        int int2 = org.apache.commons.math.util.FastMath.max(1444748028, 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1444748028 + "'", int2 == 1444748028);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test253");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 99L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test254");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(0, 1444748028);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test255");
        double double1 = org.apache.commons.math.util.FastMath.log(0.406609043584561d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8999031360663243d) + "'", double1 == (-0.8999031360663243d));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test256");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.7110506631364506d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test257");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-10), (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test258");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(40.46854780263063d, (double) 99);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 40.46854780263064d + "'", double2 == 40.46854780263064d);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test259");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 709810715);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test260");
        double double1 = org.apache.commons.math.util.FastMath.atanh((-1.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test261");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 52);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 52 + "'", int1 == 52);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test262");
        int[] intArray6 = new int[] { 3, (byte) 0, 1124, 99, (-99), (byte) 100 };
        int[] intArray8 = new int[] { (byte) 100 };
        int[] intArray11 = new int[] { 1, (short) -1 };
        int[] intArray15 = new int[] { 10, (byte) 0, (byte) 1 };
        double double16 = org.apache.commons.math.util.MathUtils.distance(intArray11, intArray15);
        int int17 = org.apache.commons.math.util.MathUtils.distance1(intArray8, intArray15);
        int[] intArray19 = new int[] { (byte) 100 };
        int[] intArray22 = new int[] { 1, (short) -1 };
        int[] intArray26 = new int[] { 10, (byte) 0, (byte) 1 };
        double double27 = org.apache.commons.math.util.MathUtils.distance(intArray22, intArray26);
        int int28 = org.apache.commons.math.util.MathUtils.distance1(intArray19, intArray26);
        int int29 = org.apache.commons.math.util.MathUtils.distance1(intArray8, intArray26);
        int[] intArray31 = new int[] { (byte) 100 };
        int[] intArray34 = new int[] { 1, (short) -1 };
        int[] intArray38 = new int[] { 10, (byte) 0, (byte) 1 };
        double double39 = org.apache.commons.math.util.MathUtils.distance(intArray34, intArray38);
        int int40 = org.apache.commons.math.util.MathUtils.distance1(intArray31, intArray38);
        int[] intArray42 = new int[] { (byte) 100 };
        int[] intArray45 = new int[] { 1, (short) -1 };
        int[] intArray49 = new int[] { 10, (byte) 0, (byte) 1 };
        double double50 = org.apache.commons.math.util.MathUtils.distance(intArray45, intArray49);
        int int51 = org.apache.commons.math.util.MathUtils.distance1(intArray42, intArray49);
        int int52 = org.apache.commons.math.util.MathUtils.distance1(intArray31, intArray49);
        int[] intArray55 = new int[] { 1, (short) -1 };
        int[] intArray59 = new int[] { 10, (byte) 0, (byte) 1 };
        double double60 = org.apache.commons.math.util.MathUtils.distance(intArray55, intArray59);
        int[] intArray62 = new int[] { (byte) 100 };
        int[] intArray65 = new int[] { 1, (short) -1 };
        int[] intArray69 = new int[] { 10, (byte) 0, (byte) 1 };
        double double70 = org.apache.commons.math.util.MathUtils.distance(intArray65, intArray69);
        int int71 = org.apache.commons.math.util.MathUtils.distance1(intArray62, intArray69);
        int int72 = org.apache.commons.math.util.MathUtils.distanceInf(intArray55, intArray69);
        int[] intArray75 = new int[] { 1, (short) -1 };
        int[] intArray79 = new int[] { 10, (byte) 0, (byte) 1 };
        double double80 = org.apache.commons.math.util.MathUtils.distance(intArray75, intArray79);
        int int81 = org.apache.commons.math.util.MathUtils.distanceInf(intArray55, intArray79);
        int int82 = org.apache.commons.math.util.MathUtils.distance1(intArray31, intArray55);
        int[] intArray85 = new int[] { 1, (short) -1 };
        int[] intArray89 = new int[] { 10, (byte) 0, (byte) 1 };
        double double90 = org.apache.commons.math.util.MathUtils.distance(intArray85, intArray89);
        int int91 = org.apache.commons.math.util.MathUtils.distance1(intArray55, intArray89);
        double double92 = org.apache.commons.math.util.MathUtils.distance(intArray8, intArray55);
        try {
            int int93 = org.apache.commons.math.util.MathUtils.distanceInf(intArray6, intArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 9.055385138137417d + "'", double16 == 9.055385138137417d);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 90 + "'", int17 == 90);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 9.055385138137417d + "'", double27 == 9.055385138137417d);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 90 + "'", int28 == 90);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 90 + "'", int29 == 90);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 9.055385138137417d + "'", double39 == 9.055385138137417d);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 90 + "'", int40 == 90);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 9.055385138137417d + "'", double50 == 9.055385138137417d);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 90 + "'", int51 == 90);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 90 + "'", int52 == 90);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 9.055385138137417d + "'", double60 == 9.055385138137417d);
        org.junit.Assert.assertNotNull(intArray62);
        org.junit.Assert.assertNotNull(intArray65);
        org.junit.Assert.assertNotNull(intArray69);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 9.055385138137417d + "'", double70 == 9.055385138137417d);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 90 + "'", int71 == 90);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 9 + "'", int72 == 9);
        org.junit.Assert.assertNotNull(intArray75);
        org.junit.Assert.assertNotNull(intArray79);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 9.055385138137417d + "'", double80 == 9.055385138137417d);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 9 + "'", int81 == 9);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 99 + "'", int82 == 99);
        org.junit.Assert.assertNotNull(intArray85);
        org.junit.Assert.assertNotNull(intArray89);
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + 9.055385138137417d + "'", double90 == 9.055385138137417d);
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 10 + "'", int91 == 10);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 99.0d + "'", double92 == 99.0d);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test263");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 1000);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test264");
        double double1 = org.apache.commons.math.util.FastMath.signum((-0.4281826694961581d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test265");
        long long1 = org.apache.commons.math.util.FastMath.round(10.04987562112089d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 10L + "'", long1 == 10L);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test266");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.17453292519943295d + "'", double1 == 0.17453292519943295d);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test267");
        double[] doubleArray1 = new double[] { '4' };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray4 = new double[] { 7.105427357601002E-15d };
        boolean boolean5 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray4);
        double[] doubleArray7 = new double[] { '4' };
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray7);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7);
        double double10 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray7);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, 0.31046516452991896d);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1078591519 + "'", int2 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1078591519 + "'", int8 == 1078591519);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test268");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(1023.606454811765d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test269");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(3.003173546455298d, 97);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.758718435941999E29d + "'", double2 == 4.758718435941999E29d);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test270");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(11.7910068511973d, (-7.074204898103558d), 88);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test271");
        int int2 = org.apache.commons.math.util.MathUtils.pow(0, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test272");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((-1104154140));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test273");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 2060654347, 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963219178653d + "'", double2 == 1.5707963219178653d);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test274");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (-1), (long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test275");
        int int1 = org.apache.commons.math.util.FastMath.abs((-1074790600));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1074790600 + "'", int1 == 1074790600);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test276");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 87, (java.lang.Number) 0.9999500037496876d, 100);
        java.lang.Class<?> wildcardClass4 = nonMonotonousSequenceException3.getClass();
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test277");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) (-10), (long) 90);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test278");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 340593888, (long) 2147483647);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1806889759L) + "'", long2 == (-1806889759L));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test279");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(985523693061886047L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test280");
        int int2 = org.apache.commons.math.util.FastMath.max(1078591519, (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1078591519 + "'", int2 == 1078591519);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test281");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 1079574528, (long) (-1573460895));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-493886367L) + "'", long2 == (-493886367L));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test282");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) (-1.0f), (double) (-99.0f));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-3.1314919870044715d) + "'", double2 == (-3.1314919870044715d));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test283");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 900, (float) 1444748028);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.44474803E9f + "'", float2 == 1.44474803E9f);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test284");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 1.0f, 0.771137801989229d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.NEGATIVE_INFINITY + "'", double2 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test285");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) (short) 0, 200, (-1444748028));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test286");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(944.8154734160571d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 944.8154734160572d + "'", double1 == 944.8154734160572d);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test287");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4210854715202004E-14d + "'", double1 == 1.4210854715202004E-14d);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test288");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(8, (-88));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test289");
        double[] doubleArray1 = new double[] { '4' };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection3, false);
        double[] doubleArray7 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray1, (double) 100);
        double[] doubleArray9 = new double[] { 0 };
        double[] doubleArray11 = new double[] { '4' };
        int int12 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11, orderDirection13, false);
        double double16 = org.apache.commons.math.util.MathUtils.distance1(doubleArray9, doubleArray11);
        double double17 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray11);
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, (double) 100.0f);
        double[] doubleArray21 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, (double) (short) -1);
        double[] doubleArray22 = null;
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equals(doubleArray21, doubleArray22);
        double[] doubleArray25 = new double[] { '4' };
        int int26 = org.apache.commons.math.util.MathUtils.hash(doubleArray25);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection27 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray25, orderDirection27, false);
        double[] doubleArray31 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, (double) 100);
        double[] doubleArray33 = new double[] { 0 };
        double[] doubleArray35 = new double[] { '4' };
        int int36 = org.apache.commons.math.util.MathUtils.hash(doubleArray35);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection37 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray35, orderDirection37, false);
        double double40 = org.apache.commons.math.util.MathUtils.distance1(doubleArray33, doubleArray35);
        double double41 = org.apache.commons.math.util.MathUtils.distance1(doubleArray25, doubleArray35);
        double double42 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray25);
        double[] doubleArray44 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, 32.97641394954658d);
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, (double) 340593891);
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equals(doubleArray21, doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1078591519 + "'", int2 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1078591519 + "'", int12 == 1078591519);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 52.0d + "'", double16 == 52.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1078591519 + "'", int26 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1078591519 + "'", int36 == 1078591519);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 52.0d + "'", double40 == 52.0d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 52.0d + "'", double42 == 52.0d);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test290");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 88L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test291");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 90);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5156.620156177409d + "'", double1 == 5156.620156177409d);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test292");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.043329155290542036d, (java.lang.Number) 5557.690612768985d, (-1104154140));
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection4 = nonMonotonousSequenceException3.getDirection();
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection4.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test293");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((-0.14042367749334314d), (double) 10L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test294");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0d, (java.lang.Number) (byte) -1, (int) '4', orderDirection3, false);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.Number number7 = nonMonotonousSequenceException5.getArgument();
        java.lang.Throwable[] throwableArray8 = nonMonotonousSequenceException5.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 0.0d + "'", number7.equals(0.0d));
        org.junit.Assert.assertNotNull(throwableArray8);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test295");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(8, (-10));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test296");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 1052060047L, (float) 1509505313L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.50950528E9f + "'", float2 == 1.50950528E9f);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test297");
        double double1 = org.apache.commons.math.util.MathUtils.sign(9.8552367677649728E17d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test298");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 1104155264);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.10415526E9f + "'", float1 == 1.10415526E9f);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test299");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) (-1104155350));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test300");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 8, (float) 1024);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 8.0f + "'", float2 == 8.0f);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test301");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 985523693061886057L, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test302");
        int int1 = org.apache.commons.math.util.MathUtils.hash((-4.9E-324d));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-2147483647) + "'", int1 == (-2147483647));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test303");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 5617882297855941635L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.6178822978559416E18d + "'", double1 == 5.6178822978559416E18d);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test304");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 8);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.8284271247461903d + "'", double1 == 2.8284271247461903d);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test305");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) (byte) 0, 0.09247264651318218d, (double) (-99));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test306");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.0d, 32.97641394954658d, (-9.060282259287522d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test307");
        double double1 = org.apache.commons.math.util.FastMath.tan(7.105427357601002E-15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.105427357601002E-15d + "'", double1 == 7.105427357601002E-15d);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test308");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 1052060013, (-800L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1052060013L + "'", long2 == 1052060013L);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test309");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 'a');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test310");
        double double1 = org.apache.commons.math.util.FastMath.sinh(99.00000000000001d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9445151596735437E42d + "'", double1 == 4.9445151596735437E42d);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test311");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(0.4451963704655766d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4600491053413155d + "'", double1 == 0.4600491053413155d);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test312");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 1052060012);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.052060012E9d + "'", double1 == 1.052060012E9d);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test313");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test314");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (byte) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) (short) 10);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) (byte) 0);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) (short) 10);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger7);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (int) 'a');
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (long) 90);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, 0L);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger16);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test315");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(72090561, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test316");
        double double1 = org.apache.commons.math.util.FastMath.tanh(5.362856488696706E10d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test317");
        double double2 = org.apache.commons.math.util.FastMath.atan2(90.0d, 9.619275968248924E151d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.35621353385326E-151d + "'", double2 == 9.35621353385326E-151d);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test318");
        long long2 = org.apache.commons.math.util.FastMath.max(1052060013L, 5L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1052060013L + "'", long2 == 1052060013L);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test319");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 340593888);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test320");
        double[] doubleArray1 = new double[] { '4' };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection3, false);
        double[] doubleArray7 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray1, (double) 100);
        double[] doubleArray9 = new double[] { 0 };
        double[] doubleArray11 = new double[] { '4' };
        int int12 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11, orderDirection13, false);
        double double16 = org.apache.commons.math.util.MathUtils.distance1(doubleArray9, doubleArray11);
        double double17 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray11);
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, (double) 100.0f);
        double[] doubleArray21 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, (double) (short) -1);
        double[] doubleArray23 = new double[] { '4' };
        int int24 = org.apache.commons.math.util.MathUtils.hash(doubleArray23);
        double[] doubleArray26 = new double[] { 7.105427357601002E-15d };
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equals(doubleArray23, doubleArray26);
        double[] doubleArray30 = new double[] { (byte) 10, (byte) 1 };
        double[] doubleArray32 = new double[] { '4' };
        int int33 = org.apache.commons.math.util.MathUtils.hash(doubleArray32);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection34 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray32, orderDirection34, false);
        double[] doubleArray38 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray32, (double) 100);
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray30, doubleArray32);
        double double40 = org.apache.commons.math.util.MathUtils.distance(doubleArray23, doubleArray32);
        double[] doubleArray43 = new double[] { (byte) 10, (byte) 1 };
        double[] doubleArray45 = new double[] { '4' };
        int int46 = org.apache.commons.math.util.MathUtils.hash(doubleArray45);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection47 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray45, orderDirection47, false);
        double[] doubleArray51 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray45, (double) 100);
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray43, doubleArray45);
        java.lang.Class<?> wildcardClass53 = doubleArray45.getClass();
        double double54 = org.apache.commons.math.util.MathUtils.distance(doubleArray32, doubleArray45);
        double double55 = org.apache.commons.math.util.MathUtils.distance1(doubleArray11, doubleArray45);
        double[] doubleArray57 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, 2.6750134462402384d);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1078591519 + "'", int2 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1078591519 + "'", int12 == 1078591519);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 52.0d + "'", double16 == 52.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1078591519 + "'", int24 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1078591519 + "'", int33 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1078591519 + "'", int46 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(wildcardClass53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray57);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test321");
        double[] doubleArray1 = new double[] { '4' };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray4 = new double[] { 7.105427357601002E-15d };
        boolean boolean5 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray4);
        double[] doubleArray8 = new double[] { (byte) 10, (byte) 1 };
        double[] doubleArray10 = new double[] { '4' };
        int int11 = org.apache.commons.math.util.MathUtils.hash(doubleArray10);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray10, orderDirection12, false);
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray10, (double) 100);
        boolean boolean17 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray8, doubleArray10);
        double double18 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray10);
        double[] doubleArray20 = new double[] { '4' };
        int int21 = org.apache.commons.math.util.MathUtils.hash(doubleArray20);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection22 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray20, orderDirection22, false);
        double double25 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray20);
        double double26 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray20);
        double[] doubleArray28 = new double[] { '4' };
        int int29 = org.apache.commons.math.util.MathUtils.hash(doubleArray28);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection30 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray28, orderDirection30, false);
        double double33 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray28);
        double double34 = org.apache.commons.math.util.MathUtils.distance(doubleArray20, doubleArray28);
        double[] doubleArray36 = new double[] { '4' };
        int int37 = org.apache.commons.math.util.MathUtils.hash(doubleArray36);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection38 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray36, orderDirection38, false);
        double[] doubleArray42 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray36, (double) 100);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection43 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray36, orderDirection43, false);
        double[] doubleArray47 = new double[] { '4' };
        int int48 = org.apache.commons.math.util.MathUtils.hash(doubleArray47);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection49 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray47, orderDirection49, false);
        double[] doubleArray53 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray47, (double) 100);
        double double54 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray36, doubleArray53);
        double double55 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray28, doubleArray53);
        double double56 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray28);
        java.lang.Number number60 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException63 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number60, (java.lang.Number) 100, 100);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection64 = nonMonotonousSequenceException63.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException66 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2758547353515625L, (java.lang.Number) 0.6888022127440038d, (int) (byte) -1, orderDirection64, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray28, orderDirection64, true);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1078591519 + "'", int2 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1078591519 + "'", int11 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1078591519 + "'", int21 == 1078591519);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 52.0d + "'", double25 == 52.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1078591519 + "'", int29 == 1078591519);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 52.0d + "'", double33 == 52.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1078591519 + "'", int37 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1078591519 + "'", int48 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 48.0d + "'", double54 == 48.0d);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 48.0d + "'", double55 == 48.0d);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 52.0d + "'", double56 == 52.0d);
        org.junit.Assert.assertTrue("'" + orderDirection64 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection64.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test322");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 1074790600, 1.5515679276951895d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.02112323693971006d + "'", double2 == 0.02112323693971006d);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test323");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.6738001006480598d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.67380010064806d + "'", double1 == 0.67380010064806d);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test324");
        double double2 = org.apache.commons.math.util.FastMath.min((double) (-813036757852547019L), 128.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-8.1303675785254707E17d) + "'", double2 == (-8.1303675785254707E17d));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test325");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) (-1444748028));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test326");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.019800013540950654d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test327");
        double double1 = org.apache.commons.math.util.FastMath.cos(4.61512051684126d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.09711515743188391d) + "'", double1 == (-0.09711515743188391d));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test328");
        int int2 = org.apache.commons.math.util.FastMath.max(153499259, 1444748028);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1444748028 + "'", int2 == 1444748028);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test329");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(709810715L, 3923610861786877953L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test330");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.5514266812416906d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8200290894110793d + "'", double1 == 0.8200290894110793d);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test331");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 52.0d, (java.lang.Number) (byte) 1, (int) '4', orderDirection3, true);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        int int7 = nonMonotonousSequenceException5.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 52 + "'", int7 == 52);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test332");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (-1074790600));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1074790656) + "'", int1 == (-1074790656));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test333");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1124, (long) 1024);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test334");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round(0.0f, (int) (byte) -1, 54);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test335");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.0d, 3.093102195050827d, (double) 97);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test336");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) (-8738718778893795328L), 0.789993101766527d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test337");
        byte byte1 = org.apache.commons.math.util.MathUtils.indicator((byte) 0);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 1 + "'", byte1 == (byte) 1);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test338");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow(1124, (-1104155350));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test339");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(0.6017862359796351d, (int) '4');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.710204268114578E15d + "'", double2 == 2.710204268114578E15d);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test340");
        double double1 = org.apache.commons.math.util.FastMath.tanh(1.0E-323d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0E-323d + "'", double1 == 1.0E-323d);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test341");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) (short) 10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test342");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (-1052060013), 1059L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1052060013L) + "'", long2 == (-1052060013L));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test343");
        double double1 = org.apache.commons.math.util.FastMath.rint(1.052060012E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.052060012E9d + "'", double1 == 1.052060012E9d);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test344");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) 674103171, (double) 1104155264);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.104155261562341E9d + "'", double2 == 1.104155261562341E9d);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test345");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.lcm((-499719071L), (-8738718778893795328L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test346");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-1074790369), 340593888);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test347");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) 88.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test348");
        double double1 = org.apache.commons.math.util.FastMath.atan(5.820766091346741E-11d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.820766091346741E-11d + "'", double1 == 5.820766091346741E-11d);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test349");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (byte) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) (short) 10);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) (byte) 0);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) (short) 10);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger7);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (int) 'a');
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, 99);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger14, 0);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger14, (long) 1444748028);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger18);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test350");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.0203089395406904d, (-8.045684064074768d), 1889.4093427853531d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test351");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 100);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 100L + "'", long1 == 100L);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test352");
        long long1 = org.apache.commons.math.util.FastMath.round((double) '4');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 52L + "'", long1 == 52L);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test353");
        int int2 = org.apache.commons.math.util.MathUtils.pow(52, (long) 97);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test354");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 11L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11.0d + "'", double1 == 11.0d);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test355");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) 90, 376068537633892224L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test356");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) 340593891);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test357");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) (-1444748028), (double) 1104154140L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.1041541368907743E9d + "'", double2 == 1.1041541368907743E9d);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test358");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(0, 72090561);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test359");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 1509505313, 1104154463L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1509505313L + "'", long2 == 1509505313L);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test360");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1078591519, (java.lang.Number) 1.0d, (int) (short) 0);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException7 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1078591519, (java.lang.Number) 1.0d, (int) (short) 0);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException7);
        java.lang.Number number9 = nonMonotonousSequenceException3.getPrevious();
        java.lang.Number number10 = nonMonotonousSequenceException3.getArgument();
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 1.0d + "'", number9.equals(1.0d));
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 1078591519 + "'", number10.equals(1078591519));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test361");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 100, 100);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        int int5 = nonMonotonousSequenceException3.getIndex();
        java.lang.Number number6 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number6, (java.lang.Number) 0.0d, (int) (byte) 0);
        java.lang.Number number10 = nonMonotonousSequenceException9.getPrevious();
        java.lang.Number number11 = nonMonotonousSequenceException9.getPrevious();
        java.lang.String str12 = nonMonotonousSequenceException9.toString();
        java.lang.Number number13 = nonMonotonousSequenceException9.getPrevious();
        int int14 = nonMonotonousSequenceException9.getIndex();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException9);
        boolean boolean16 = nonMonotonousSequenceException9.getStrict();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 100 + "'", int5 == 100);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 0.0d + "'", number10.equals(0.0d));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 0.0d + "'", number11.equals(0.0d));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= null)" + "'", str12.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= null)"));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 0.0d + "'", number13.equals(0.0d));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test362");
        double[] doubleArray1 = new double[] { '4' };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1078591519 + "'", int2 == 1078591519);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test363");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 1078591519, (long) 99);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1078591618L + "'", long2 == 1078591618L);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test364");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.019800013540950654d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.01979871983165594d + "'", double1 == 0.01979871983165594d);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test365");
        double[] doubleArray1 = new double[] { '4' };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection3, false);
        double[] doubleArray7 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray1, (double) 100);
        double[] doubleArray9 = new double[] { 0 };
        double[] doubleArray11 = new double[] { '4' };
        int int12 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11, orderDirection13, false);
        double double16 = org.apache.commons.math.util.MathUtils.distance1(doubleArray9, doubleArray11);
        double double17 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray11);
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, (double) 100.0f);
        double[] doubleArray21 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, (double) (short) -1);
        double[] doubleArray23 = new double[] { '4' };
        int int24 = org.apache.commons.math.util.MathUtils.hash(doubleArray23);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection25 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray23, orderDirection25, false);
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray23, (double) 100);
        double[] doubleArray31 = new double[] { 0 };
        double[] doubleArray33 = new double[] { '4' };
        int int34 = org.apache.commons.math.util.MathUtils.hash(doubleArray33);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection35 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray33, orderDirection35, false);
        double double38 = org.apache.commons.math.util.MathUtils.distance1(doubleArray31, doubleArray33);
        double double39 = org.apache.commons.math.util.MathUtils.distance1(doubleArray23, doubleArray33);
        double[] doubleArray41 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray33, (double) 100.0f);
        double double42 = org.apache.commons.math.util.MathUtils.distance1(doubleArray11, doubleArray33);
        double[] doubleArray44 = new double[] { '4' };
        int int45 = org.apache.commons.math.util.MathUtils.hash(doubleArray44);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection46 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray44, orderDirection46, false);
        double[] doubleArray50 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray44, (double) 100);
        double[] doubleArray52 = new double[] { 0 };
        double[] doubleArray54 = new double[] { '4' };
        int int55 = org.apache.commons.math.util.MathUtils.hash(doubleArray54);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection56 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray54, orderDirection56, false);
        double double59 = org.apache.commons.math.util.MathUtils.distance1(doubleArray52, doubleArray54);
        double double60 = org.apache.commons.math.util.MathUtils.distance1(doubleArray44, doubleArray54);
        double double61 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray44);
        double double62 = org.apache.commons.math.util.MathUtils.distance(doubleArray33, doubleArray44);
        double double63 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1078591519 + "'", int2 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1078591519 + "'", int12 == 1078591519);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 52.0d + "'", double16 == 52.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1078591519 + "'", int24 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1078591519 + "'", int34 == 1078591519);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 52.0d + "'", double38 == 52.0d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1078591519 + "'", int45 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1078591519 + "'", int55 == 1078591519);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 52.0d + "'", double59 == 52.0d);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 52.0d + "'", double61 == 52.0d);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 52.0d + "'", double63 == 52.0d);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test366");
        double double1 = org.apache.commons.math.util.MathUtils.sign(3.5d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test367");
        double double2 = org.apache.commons.math.util.FastMath.atan2((-8.045684064074768d), (-8.7387187788937953E18d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-3.141592653589793d) + "'", double2 == (-3.141592653589793d));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test368");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) (byte) 0, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test369");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((-1074790369));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test370");
        long long1 = org.apache.commons.math.util.MathUtils.sign((-800L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test371");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) (-674103162L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test372");
        double[] doubleArray1 = new double[] { '4' };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection3, false);
        double[] doubleArray7 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray1, (double) 100);
        double[] doubleArray9 = new double[] { 0 };
        double[] doubleArray11 = new double[] { '4' };
        int int12 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11, orderDirection13, false);
        double double16 = org.apache.commons.math.util.MathUtils.distance1(doubleArray9, doubleArray11);
        double double17 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray11);
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, (double) 100.0f);
        double[] doubleArray21 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, (double) (short) -1);
        double[] doubleArray23 = new double[] { '4' };
        int int24 = org.apache.commons.math.util.MathUtils.hash(doubleArray23);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection25 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray23, orderDirection25, false);
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray23, (double) 100);
        double[] doubleArray31 = new double[] { 0 };
        double[] doubleArray33 = new double[] { '4' };
        int int34 = org.apache.commons.math.util.MathUtils.hash(doubleArray33);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection35 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray33, orderDirection35, false);
        double double38 = org.apache.commons.math.util.MathUtils.distance1(doubleArray31, doubleArray33);
        double double39 = org.apache.commons.math.util.MathUtils.distance1(doubleArray23, doubleArray33);
        double[] doubleArray41 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray33, (double) 100.0f);
        double double42 = org.apache.commons.math.util.MathUtils.distance1(doubleArray11, doubleArray33);
        double[] doubleArray44 = new double[] { '4' };
        int int45 = org.apache.commons.math.util.MathUtils.hash(doubleArray44);
        double[] doubleArray47 = new double[] { 7.105427357601002E-15d };
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equals(doubleArray44, doubleArray47);
        double[] doubleArray51 = new double[] { (byte) 10, (byte) 1 };
        double[] doubleArray53 = new double[] { '4' };
        int int54 = org.apache.commons.math.util.MathUtils.hash(doubleArray53);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection55 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray53, orderDirection55, false);
        double[] doubleArray59 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray53, (double) 100);
        boolean boolean60 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray51, doubleArray53);
        double double61 = org.apache.commons.math.util.MathUtils.distance(doubleArray44, doubleArray53);
        double[] doubleArray63 = new double[] { '4' };
        int int64 = org.apache.commons.math.util.MathUtils.hash(doubleArray63);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection65 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray63, orderDirection65, false);
        double double68 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray63);
        double double69 = org.apache.commons.math.util.MathUtils.distance1(doubleArray44, doubleArray63);
        java.lang.Number number70 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException73 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number70, (java.lang.Number) 100, 100);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection74 = nonMonotonousSequenceException73.getDirection();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray44, orderDirection74, false);
        double double77 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray11, doubleArray44);
        int int78 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1078591519 + "'", int2 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1078591519 + "'", int12 == 1078591519);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 52.0d + "'", double16 == 52.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1078591519 + "'", int24 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1078591519 + "'", int34 == 1078591519);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 52.0d + "'", double38 == 52.0d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1078591519 + "'", int45 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1078591519 + "'", int54 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 1078591519 + "'", int64 == 1078591519);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 52.0d + "'", double68 == 52.0d);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection74 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection74.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 0.0d + "'", double77 == 0.0d);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 1078591519 + "'", int78 == 1078591519);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test373");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(2060654347, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test374");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(1023410207, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test375");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(0, (-340593889));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 340593889 + "'", int2 == 340593889);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test376");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 899, (float) (byte) 100);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test377");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((int) (byte) 1, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test378");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 99L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.605170185988092d + "'", double1 == 4.605170185988092d);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test379");
        double[] doubleArray0 = null;
        try {
            double double1 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test380");
        double double1 = org.apache.commons.math.util.FastMath.cosh(1.0E88d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test381");
        double double1 = org.apache.commons.math.util.MathUtils.sign(17.872171540421935d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test382");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.043302060025879614d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.04327502565930109d + "'", double1 == 0.04327502565930109d);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test383");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm((-1052060013), (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test384");
        double[] doubleArray1 = new double[] { '4' };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection3, false);
        double[] doubleArray7 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray1, (double) 100);
        double[] doubleArray9 = new double[] { 0 };
        double[] doubleArray11 = new double[] { '4' };
        int int12 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11, orderDirection13, false);
        double double16 = org.apache.commons.math.util.MathUtils.distance1(doubleArray9, doubleArray11);
        double double17 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray11);
        double[] doubleArray19 = new double[] { '4' };
        int int20 = org.apache.commons.math.util.MathUtils.hash(doubleArray19);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection21 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray19, orderDirection21, false);
        double[] doubleArray25 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, (double) 100);
        double[] doubleArray27 = new double[] { 0 };
        double[] doubleArray29 = new double[] { '4' };
        int int30 = org.apache.commons.math.util.MathUtils.hash(doubleArray29);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection31 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray29, orderDirection31, false);
        double double34 = org.apache.commons.math.util.MathUtils.distance1(doubleArray27, doubleArray29);
        double double35 = org.apache.commons.math.util.MathUtils.distance1(doubleArray19, doubleArray29);
        double[] doubleArray37 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray29, (double) 100.0f);
        double[] doubleArray39 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray29, (double) (short) -1);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray29);
        boolean boolean41 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray29);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray29);
        int int43 = org.apache.commons.math.util.MathUtils.hash(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1078591519 + "'", int2 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1078591519 + "'", int12 == 1078591519);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 52.0d + "'", double16 == 52.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1078591519 + "'", int20 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1078591519 + "'", int30 == 1078591519);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 52.0d + "'", double34 == 52.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1078591519 + "'", int43 == 1078591519);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test385");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-57.29577951308232d) + "'", double1 == (-57.29577951308232d));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test386");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((-340593889), (-200));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test387");
        double double1 = org.apache.commons.math.util.FastMath.log10(30.719587249254804d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.487415376184498d + "'", double1 == 1.487415376184498d);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test388");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1052060012, 1052060012);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test389");
        long long1 = org.apache.commons.math.util.FastMath.round(0.8813593244538519d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test390");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.8200290894110793d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0717762252344276d + "'", double1 == 1.0717762252344276d);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test391");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-899), 340593891L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1648403227) + "'", int2 == (-1648403227));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test392");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.2764014075493026d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.27640140754930265d + "'", double1 == 0.27640140754930265d);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test393");
        float float1 = org.apache.commons.math.util.MathUtils.sign(1.50950528E9f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test394");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((-1104155350), 674103171);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1778258521) + "'", int2 == (-1778258521));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test395");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(376068537633892224L, 709810715L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 376068538343702939L + "'", long2 == 376068538343702939L);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test396");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { '4' };
        int int3 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray5 = new double[] { 7.105427357601002E-15d };
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray5);
        double[] doubleArray9 = new double[] { (byte) 10, (byte) 1 };
        double[] doubleArray11 = new double[] { '4' };
        int int12 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11, orderDirection13, false);
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, (double) 100);
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray9, doubleArray11);
        double double19 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray11);
        double[] doubleArray21 = new double[] { '4' };
        int int22 = org.apache.commons.math.util.MathUtils.hash(doubleArray21);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection23 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray21, orderDirection23, false);
        double double26 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray21);
        double double27 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray21);
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1078591519 + "'", int3 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1078591519 + "'", int12 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1078591519 + "'", int22 == 1078591519);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 52.0d + "'", double26 == 52.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test397");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(51.118640675546146d, (double) (-1052060013));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0520600152992812E9d) + "'", double2 == (-1.0520600152992812E9d));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test398");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.008450182378513804d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.48415978640466045d + "'", double1 == 0.48415978640466045d);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test399");
        double double1 = org.apache.commons.math.util.FastMath.tanh(1.5607966601082315d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9155494254642262d + "'", double1 == 0.9155494254642262d);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test400");
        long long2 = org.apache.commons.math.util.MathUtils.pow(340593891L, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 940879284210579025L + "'", long2 == 940879284210579025L);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test401");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 50, 4.9445151596735437E42d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0112214926104341E-41d + "'", double2 == 1.0112214926104341E-41d);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test402");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((-1573460895));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test403");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.0f), (java.lang.Number) 1.5607966601082315d, 100, orderDirection6, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.0f), (java.lang.Number) 3.40593888E8d, (-340593889), orderDirection6, true);
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test404");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((-674103162L), (-1L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test405");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 1000);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1000.0d + "'", double1 == 1000.0d);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test406");
        double[] doubleArray1 = new double[] { 0 };
        double[] doubleArray3 = new double[] { '4' };
        int int4 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection5 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray3, orderDirection5, false);
        double double8 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray3);
        double[] doubleArray10 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, 0.5514266812416906d);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (-8.045684064074768d));
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1078591519 + "'", int4 == 1078591519);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 52.0d + "'", double8 == 52.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test407");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) 1024);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1083179008 + "'", int1 == 1083179008);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test408");
        long long1 = org.apache.commons.math.util.MathUtils.factorial(1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test409");
        double double1 = org.apache.commons.math.util.FastMath.abs((-0.09711515743188391d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.09711515743188391d + "'", double1 == 0.09711515743188391d);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test410");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.7110506631364506d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8925519748933151d + "'", double1 == 0.8925519748933151d);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test411");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 100);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 100L + "'", long1 == 100L);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test412");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(1052060013, (-1104154140));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test413");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(0, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test414");
        int[] intArray2 = new int[] { 1, (short) -1 };
        int[] intArray6 = new int[] { 10, (byte) 0, (byte) 1 };
        double double7 = org.apache.commons.math.util.MathUtils.distance(intArray2, intArray6);
        int[] intArray9 = new int[] { (byte) 100 };
        int[] intArray12 = new int[] { 1, (short) -1 };
        int[] intArray16 = new int[] { 10, (byte) 0, (byte) 1 };
        double double17 = org.apache.commons.math.util.MathUtils.distance(intArray12, intArray16);
        int int18 = org.apache.commons.math.util.MathUtils.distance1(intArray9, intArray16);
        int int19 = org.apache.commons.math.util.MathUtils.distanceInf(intArray2, intArray16);
        int[] intArray20 = null;
        try {
            int int21 = org.apache.commons.math.util.MathUtils.distance1(intArray2, intArray20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 9.055385138137417d + "'", double7 == 9.055385138137417d);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 9.055385138137417d + "'", double17 == 9.055385138137417d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 90 + "'", int18 == 90);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 9 + "'", int19 == 9);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test415");
        long long2 = org.apache.commons.math.util.MathUtils.pow(1052060013L, 9);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1328467627058191859L) + "'", long2 == (-1328467627058191859L));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test416");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(52L, 4427721688L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 230241527776L + "'", long2 == 230241527776L);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test417");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(0.6616961211922905d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7110506631364506d + "'", double1 == 0.7110506631364506d);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test418");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) (-1778258521), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1778258521L) + "'", long2 == (-1778258521L));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test419");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(0.0d, 1.5515679276951895d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test420");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(6.5042692692183E-4d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.03726671779428488d + "'", double1 == 0.03726671779428488d);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test421");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 0.0d, (int) (byte) 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        java.lang.String str6 = nonMonotonousSequenceException3.toString();
        java.lang.Throwable[] throwableArray7 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Throwable[] throwableArray8 = nonMonotonousSequenceException3.getSuppressed();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.0d + "'", number4.equals(0.0d));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0d + "'", number5.equals(0.0d));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= null)" + "'", str6.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= null)"));
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(throwableArray8);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test422");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.5661158159967962d, 0.0d, 9.8552369306188621E17d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test423");
        double[] doubleArray2 = new double[] { (byte) 10, (byte) 1 };
        double[] doubleArray4 = new double[] { '4' };
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray4, orderDirection6, false);
        double[] doubleArray10 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray4, (double) 100);
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray4);
        double[] doubleArray13 = new double[] { '4' };
        int int14 = org.apache.commons.math.util.MathUtils.hash(doubleArray13);
        double[] doubleArray16 = new double[] { 7.105427357601002E-15d };
        boolean boolean17 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray16);
        double[] doubleArray20 = new double[] { (byte) 10, (byte) 1 };
        double[] doubleArray22 = new double[] { '4' };
        int int23 = org.apache.commons.math.util.MathUtils.hash(doubleArray22);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection24 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray22, orderDirection24, false);
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray22, (double) 100);
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray22);
        double double30 = org.apache.commons.math.util.MathUtils.distance(doubleArray13, doubleArray22);
        double[] doubleArray32 = new double[] { '4' };
        int int33 = org.apache.commons.math.util.MathUtils.hash(doubleArray32);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection34 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray32, orderDirection34, false);
        double double37 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray32);
        double double38 = org.apache.commons.math.util.MathUtils.distance1(doubleArray13, doubleArray32);
        double[] doubleArray40 = new double[] { '4' };
        int int41 = org.apache.commons.math.util.MathUtils.hash(doubleArray40);
        double[] doubleArray43 = new double[] { 7.105427357601002E-15d };
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equals(doubleArray40, doubleArray43);
        double[] doubleArray47 = new double[] { (byte) 10, (byte) 1 };
        double[] doubleArray49 = new double[] { '4' };
        int int50 = org.apache.commons.math.util.MathUtils.hash(doubleArray49);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection51 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray49, orderDirection51, false);
        double[] doubleArray55 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray49, (double) 100);
        boolean boolean56 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray47, doubleArray49);
        double double57 = org.apache.commons.math.util.MathUtils.distance(doubleArray40, doubleArray49);
        double[] doubleArray59 = new double[] { '4' };
        int int60 = org.apache.commons.math.util.MathUtils.hash(doubleArray59);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection61 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray59, orderDirection61, false);
        double double64 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray59);
        double double65 = org.apache.commons.math.util.MathUtils.distance1(doubleArray40, doubleArray59);
        double[] doubleArray67 = new double[] { '4' };
        int int68 = org.apache.commons.math.util.MathUtils.hash(doubleArray67);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection69 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray67, orderDirection69, false);
        double double72 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray67);
        double double73 = org.apache.commons.math.util.MathUtils.distance(doubleArray59, doubleArray67);
        double[] doubleArray75 = new double[] { '4' };
        int int76 = org.apache.commons.math.util.MathUtils.hash(doubleArray75);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection77 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray75, orderDirection77, false);
        double[] doubleArray81 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray75, (double) 100);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection82 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray75, orderDirection82, false);
        double[] doubleArray86 = new double[] { '4' };
        int int87 = org.apache.commons.math.util.MathUtils.hash(doubleArray86);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection88 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray86, orderDirection88, false);
        double[] doubleArray92 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray86, (double) 100);
        double double93 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray75, doubleArray92);
        double double94 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray67, doubleArray92);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray92);
        boolean boolean96 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray32, doubleArray92);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray92);
        boolean boolean98 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray92);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1078591519 + "'", int5 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1078591519 + "'", int14 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1078591519 + "'", int23 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1078591519 + "'", int33 == 1078591519);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 52.0d + "'", double37 == 52.0d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1078591519 + "'", int41 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1078591519 + "'", int50 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1078591519 + "'", int60 == 1078591519);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 52.0d + "'", double64 == 52.0d);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 1078591519 + "'", int68 == 1078591519);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 52.0d + "'", double72 == 52.0d);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 1078591519 + "'", int76 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 1078591519 + "'", int87 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray92);
        org.junit.Assert.assertTrue("'" + double93 + "' != '" + 48.0d + "'", double93 == 48.0d);
        org.junit.Assert.assertTrue("'" + double94 + "' != '" + 48.0d + "'", double94 == 48.0d);
        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + false + "'", boolean96 == false);
        org.junit.Assert.assertTrue("'" + boolean98 + "' != '" + false + "'", boolean98 == false);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test424");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) (-52L), 54);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test425");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(1.7242993583184938d, 1.4210854715202004E-14d, 899);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test426");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(99, (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 151 + "'", int2 == 151);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test427");
        float float2 = org.apache.commons.math.util.FastMath.min(3.0f, (float) 99);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 3.0f + "'", float2 == 3.0f);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test428");
        int int2 = org.apache.commons.math.util.FastMath.max(1052060012, 1444748028);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1444748028 + "'", int2 == 1444748028);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test429");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 42.12509674344045d, number1, (int) (short) 10);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (null >= 42.125)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (null >= 42.125)"));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test430");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 97, 1074790600, (-1074790369));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test431");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(376068538343702939L, (long) 340593889);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 376068538684296828L + "'", long2 == 376068538684296828L);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test432");
        int int1 = org.apache.commons.math.util.FastMath.abs(43);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 43 + "'", int1 == 43);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test433");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.9999500037496876d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.298342365610975d + "'", double1 == 5.298342365610975d);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test434");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(1.3363225468965105E-5d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3363225468965107E-5d + "'", double1 == 1.3363225468965107E-5d);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test435");
        int int2 = org.apache.commons.math.util.FastMath.max(0, 1104155263);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1104155263 + "'", int2 == 1104155263);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test436");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1078591519, (java.lang.Number) 1.0d, (int) (short) 0);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection4 = nonMonotonousSequenceException3.getDirection();
        java.lang.Number number8 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number8, (java.lang.Number) 100, 100);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = nonMonotonousSequenceException11.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException14 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2758547353515625L, (java.lang.Number) 0.6888022127440038d, (int) (byte) -1, orderDirection12, true);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException14);
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection4.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test437");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(1.5860134523134308E15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test438");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 88L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.258181274970009E37d + "'", double1 == 8.258181274970009E37d);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test439");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(8.258181274970009E37d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test440");
        double[] doubleArray2 = new double[] { (byte) 10, (byte) 1 };
        double[] doubleArray4 = new double[] { '4' };
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray4, orderDirection6, false);
        double[] doubleArray10 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray4, (double) 100);
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray4);
        int int12 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray13 = null;
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray13);
        double double15 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1078591519 + "'", int5 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 72090561 + "'", int12 == 72090561);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 10.04987562112089d + "'", double15 == 10.04987562112089d);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test441");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (-899), (-1573461795L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1573461795L) + "'", long2 == (-1573461795L));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test442");
        double double1 = org.apache.commons.math.util.FastMath.abs(2.8284271247461903d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.8284271247461903d + "'", double1 == 2.8284271247461903d);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test443");
        double double1 = org.apache.commons.math.util.FastMath.floor(115.09671936379293d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 115.0d + "'", double1 == 115.0d);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test444");
        double double1 = org.apache.commons.math.util.FastMath.log1p(48.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.8918202981106265d + "'", double1 == 3.8918202981106265d);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test445");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(985523693061886157L, (long) (-1));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 985523693061886157L + "'", long2 == 985523693061886157L);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test446");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(2147483647, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test447");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (byte) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) (short) 10);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) (byte) 0);
        java.math.BigInteger bigInteger8 = null;
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, (long) (byte) 0);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, (long) (short) 10);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, bigInteger12);
        java.math.BigInteger bigInteger14 = null;
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger14, (long) (byte) 0);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, (long) (short) 10);
        java.math.BigInteger bigInteger19 = null;
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, (long) (byte) 0);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, (long) (short) 10);
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, bigInteger21);
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, bigInteger24);
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger25);
        java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (int) '#');
        java.math.BigInteger bigInteger30 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 1073741824);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger28);
        org.junit.Assert.assertNotNull(bigInteger30);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test448");
        float float3 = org.apache.commons.math.util.MathUtils.round((float) 1078591618L, 1444748028, 0);
        org.junit.Assert.assertEquals((float) float3, Float.NaN, 0);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test449");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((-52L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test450");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test451");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) (-1), 376068537633892224L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test452");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) (short) 1, (long) (-1104155350));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1104155350L + "'", long2 == 1104155350L);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test453");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(1023.606454811765d, (double) 1.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test454");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 52);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9155040003582885E22d + "'", double1 == 1.9155040003582885E22d);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test455");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(17.872171540421935d, (-4303.28974102346d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-4304.9593197991335d) + "'", double2 == (-4304.9593197991335d));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test456");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(1079574528, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test457");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(709810715, (-1778258521));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test458");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(88, 97);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test459");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.2344051195730661d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2387948120273963d + "'", double1 == 0.2387948120273963d);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test460");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1104155263, 900);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2104199679) + "'", int2 == (-2104199679));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test461");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(0.5661158159967962d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5968428916537847d + "'", double1 == 0.5968428916537847d);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test462");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.09247264651318218d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.08844361015762627d + "'", double1 == 0.08844361015762627d);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test463");
        int[] intArray2 = new int[] { 1, (short) -1 };
        int[] intArray6 = new int[] { 10, (byte) 0, (byte) 1 };
        double double7 = org.apache.commons.math.util.MathUtils.distance(intArray2, intArray6);
        int[] intArray9 = new int[] { (byte) 100 };
        int[] intArray12 = new int[] { 1, (short) -1 };
        int[] intArray16 = new int[] { 10, (byte) 0, (byte) 1 };
        double double17 = org.apache.commons.math.util.MathUtils.distance(intArray12, intArray16);
        int int18 = org.apache.commons.math.util.MathUtils.distance1(intArray9, intArray16);
        int int19 = org.apache.commons.math.util.MathUtils.distanceInf(intArray2, intArray16);
        int[] intArray22 = new int[] { 1, (short) -1 };
        int[] intArray26 = new int[] { 10, (byte) 0, (byte) 1 };
        double double27 = org.apache.commons.math.util.MathUtils.distance(intArray22, intArray26);
        int int28 = org.apache.commons.math.util.MathUtils.distanceInf(intArray2, intArray26);
        int[] intArray31 = new int[] { 1, (short) -1 };
        int[] intArray35 = new int[] { 10, (byte) 0, (byte) 1 };
        double double36 = org.apache.commons.math.util.MathUtils.distance(intArray31, intArray35);
        int[] intArray38 = new int[] { (byte) 100 };
        int[] intArray41 = new int[] { 1, (short) -1 };
        int[] intArray45 = new int[] { 10, (byte) 0, (byte) 1 };
        double double46 = org.apache.commons.math.util.MathUtils.distance(intArray41, intArray45);
        int int47 = org.apache.commons.math.util.MathUtils.distance1(intArray38, intArray45);
        int int48 = org.apache.commons.math.util.MathUtils.distanceInf(intArray31, intArray45);
        int[] intArray51 = new int[] { 1, (short) -1 };
        int[] intArray55 = new int[] { 10, (byte) 0, (byte) 1 };
        double double56 = org.apache.commons.math.util.MathUtils.distance(intArray51, intArray55);
        int int57 = org.apache.commons.math.util.MathUtils.distanceInf(intArray31, intArray55);
        double double58 = org.apache.commons.math.util.MathUtils.distance(intArray2, intArray55);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 9.055385138137417d + "'", double7 == 9.055385138137417d);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 9.055385138137417d + "'", double17 == 9.055385138137417d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 90 + "'", int18 == 90);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 9 + "'", int19 == 9);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 9.055385138137417d + "'", double27 == 9.055385138137417d);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 9 + "'", int28 == 9);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 9.055385138137417d + "'", double36 == 9.055385138137417d);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 9.055385138137417d + "'", double46 == 9.055385138137417d);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 90 + "'", int47 == 90);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 9 + "'", int48 == 9);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 9.055385138137417d + "'", double56 == 9.055385138137417d);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 9 + "'", int57 == 9);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 9.055385138137417d + "'", double58 == 9.055385138137417d);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test464");
        double double1 = org.apache.commons.math.util.FastMath.tanh(21.81728038953947d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test465");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(0.0d, 2060654347);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test466");
        double double1 = org.apache.commons.math.util.FastMath.tanh((-0.14042367749334314d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.13950790409876887d) + "'", double1 == (-0.13950790409876887d));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test467");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1078591519, (java.lang.Number) 1.0d, (int) (short) 0);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection4 = nonMonotonousSequenceException3.getDirection();
        java.lang.String str5 = nonMonotonousSequenceException3.toString();
        boolean boolean6 = nonMonotonousSequenceException3.getStrict();
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection4.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (1 >= 1,078,591,519)" + "'", str5.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (1 >= 1,078,591,519)"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test468");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 985523693061886157L, (double) (-99.0f));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test469");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (-1104155350), (int) (short) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test470");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 2060654347);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.060654347E9d + "'", double1 == 2.060654347E9d);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test471");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((-1104154140));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test472");
        double[] doubleArray1 = new double[] { '4' };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray4 = new double[] { 7.105427357601002E-15d };
        boolean boolean5 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray4);
        double[] doubleArray8 = new double[] { (byte) 10, (byte) 1 };
        double[] doubleArray10 = new double[] { '4' };
        int int11 = org.apache.commons.math.util.MathUtils.hash(doubleArray10);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray10, orderDirection12, false);
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray10, (double) 100);
        boolean boolean17 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray8, doubleArray10);
        double double18 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray10);
        double[] doubleArray20 = new double[] { '4' };
        int int21 = org.apache.commons.math.util.MathUtils.hash(doubleArray20);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection22 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray20, orderDirection22, false);
        double double25 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray20);
        double double26 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray20);
        double[] doubleArray28 = new double[] { '4' };
        int int29 = org.apache.commons.math.util.MathUtils.hash(doubleArray28);
        double[] doubleArray31 = new double[] { 7.105427357601002E-15d };
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equals(doubleArray28, doubleArray31);
        double[] doubleArray35 = new double[] { (byte) 10, (byte) 1 };
        double[] doubleArray37 = new double[] { '4' };
        int int38 = org.apache.commons.math.util.MathUtils.hash(doubleArray37);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection39 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray37, orderDirection39, false);
        double[] doubleArray43 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray37, (double) 100);
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray35, doubleArray37);
        double double45 = org.apache.commons.math.util.MathUtils.distance(doubleArray28, doubleArray37);
        double[] doubleArray47 = new double[] { '4' };
        int int48 = org.apache.commons.math.util.MathUtils.hash(doubleArray47);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection49 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray47, orderDirection49, false);
        double[] doubleArray53 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray47, (double) 100);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection54 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray47, orderDirection54, false);
        double double57 = org.apache.commons.math.util.MathUtils.distance1(doubleArray28, doubleArray47);
        double double58 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray28);
        double[] doubleArray60 = new double[] { '4' };
        int int61 = org.apache.commons.math.util.MathUtils.hash(doubleArray60);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection62 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray60, orderDirection62, false);
        double[] doubleArray66 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray60, (double) 100);
        double[] doubleArray68 = new double[] { 0 };
        double[] doubleArray70 = new double[] { '4' };
        int int71 = org.apache.commons.math.util.MathUtils.hash(doubleArray70);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection72 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray70, orderDirection72, false);
        double double75 = org.apache.commons.math.util.MathUtils.distance1(doubleArray68, doubleArray70);
        double double76 = org.apache.commons.math.util.MathUtils.distance1(doubleArray60, doubleArray70);
        double[] doubleArray78 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray70, (double) 100.0f);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection79 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray70, orderDirection79, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection79, false);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1078591519 + "'", int2 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1078591519 + "'", int11 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1078591519 + "'", int21 == 1078591519);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 52.0d + "'", double25 == 52.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1078591519 + "'", int29 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1078591519 + "'", int38 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1078591519 + "'", int48 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 1078591519 + "'", int61 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 1078591519 + "'", int71 == 1078591519);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 52.0d + "'", double75 == 52.0d);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.0d + "'", double76 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertTrue("'" + orderDirection79 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection79.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test473");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) 52L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1078591488 + "'", int1 == 1078591488);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test474");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(0, (-1444748028));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1444748028) + "'", int2 == (-1444748028));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test475");
        double double1 = org.apache.commons.math.util.FastMath.cosh(115.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.3937508179185116E49d + "'", double1 == 4.3937508179185116E49d);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test476");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.017453292519943295d + "'", double1 == 0.017453292519943295d);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test477");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (-2104199679), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test478");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) (-1648403227));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test479");
        double[] doubleArray1 = new double[] { '4' };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection3, false);
        double[] doubleArray7 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray1, (double) 100);
        double[] doubleArray9 = new double[] { 0 };
        double[] doubleArray11 = new double[] { '4' };
        int int12 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11, orderDirection13, false);
        double double16 = org.apache.commons.math.util.MathUtils.distance1(doubleArray9, doubleArray11);
        double double17 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray11);
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, (double) 100.0f);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection20 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11, orderDirection20, false);
        double[] doubleArray24 = new double[] { '4' };
        int int25 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection26 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray24, orderDirection26, false);
        double[] doubleArray30 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray24, (double) 100);
        double[] doubleArray32 = new double[] { 0 };
        double[] doubleArray34 = new double[] { '4' };
        int int35 = org.apache.commons.math.util.MathUtils.hash(doubleArray34);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection36 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray34, orderDirection36, false);
        double double39 = org.apache.commons.math.util.MathUtils.distance1(doubleArray32, doubleArray34);
        double double40 = org.apache.commons.math.util.MathUtils.distance1(doubleArray24, doubleArray34);
        double[] doubleArray42 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray34, (double) 100.0f);
        double[] doubleArray44 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray34, (double) (short) -1);
        double double45 = org.apache.commons.math.util.MathUtils.distance1(doubleArray11, doubleArray44);
        int int46 = org.apache.commons.math.util.MathUtils.hash(doubleArray44);
        double double47 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1078591519 + "'", int2 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1078591519 + "'", int12 == 1078591519);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 52.0d + "'", double16 == 52.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + orderDirection20 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection20.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1078591519 + "'", int25 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1078591519 + "'", int35 == 1078591519);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 52.0d + "'", double39 == 52.0d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 53.0d + "'", double45 == 53.0d);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1074790369) + "'", int46 == (-1074790369));
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 1.0d + "'", double47 == 1.0d);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test480");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 35, 3447824565082718239L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3447824565082718274L + "'", long2 == 3447824565082718274L);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test481");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) (-1104155350));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test482");
        double[] doubleArray1 = new double[] { '4' };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection3, false);
        double[] doubleArray7 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray1, (double) 100);
        double[] doubleArray9 = new double[] { 0 };
        double[] doubleArray11 = new double[] { '4' };
        int int12 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11, orderDirection13, false);
        double double16 = org.apache.commons.math.util.MathUtils.distance1(doubleArray9, doubleArray11);
        double double17 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray11);
        double double18 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray1);
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray1, 32.97641394954658d);
        double double21 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1078591519 + "'", int2 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1078591519 + "'", int12 == 1078591519);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 52.0d + "'", double16 == 52.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 52.0d + "'", double18 == 52.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 32.97641394954658d + "'", double21 == 32.97641394954658d);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test483");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(5.298292365610485d, 4.644483341943245d, 800.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test484");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { '4' };
        int int3 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection4 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2, orderDirection4, false);
        double[] doubleArray8 = new double[] { '4' };
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray8);
        double[] doubleArray11 = new double[] { 7.105427357601002E-15d };
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equals(doubleArray8, doubleArray11);
        double[] doubleArray14 = new double[] { '4' };
        int int15 = org.apache.commons.math.util.MathUtils.hash(doubleArray14);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection16 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray14, orderDirection16, false);
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray14, (double) 100);
        double[] doubleArray22 = new double[] { 0 };
        double[] doubleArray24 = new double[] { '4' };
        int int25 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection26 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray24, orderDirection26, false);
        double double29 = org.apache.commons.math.util.MathUtils.distance1(doubleArray22, doubleArray24);
        double double30 = org.apache.commons.math.util.MathUtils.distance1(doubleArray14, doubleArray24);
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray24, (double) 100.0f);
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray24, (double) (short) -1);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray24);
        double double36 = org.apache.commons.math.util.MathUtils.distance1(doubleArray11, doubleArray24);
        double double37 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray11);
        double[] doubleArray39 = new double[] { '4' };
        int int40 = org.apache.commons.math.util.MathUtils.hash(doubleArray39);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection41 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray39, orderDirection41, false);
        double[] doubleArray45 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray39, (double) 100);
        double[] doubleArray47 = new double[] { 0 };
        double[] doubleArray49 = new double[] { '4' };
        int int50 = org.apache.commons.math.util.MathUtils.hash(doubleArray49);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection51 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray49, orderDirection51, false);
        double double54 = org.apache.commons.math.util.MathUtils.distance1(doubleArray47, doubleArray49);
        double double55 = org.apache.commons.math.util.MathUtils.distance1(doubleArray39, doubleArray49);
        double double56 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray39);
        java.lang.Class<?> wildcardClass57 = doubleArray39.getClass();
        double double58 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray39);
        try {
            double double59 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1078591519 + "'", int3 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1078591519 + "'", int9 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1078591519 + "'", int15 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1078591519 + "'", int25 == 1078591519);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 52.0d + "'", double29 == 52.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 51.99999999999999d + "'", double36 == 51.99999999999999d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 51.99999999999999d + "'", double37 == 51.99999999999999d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1078591519 + "'", int40 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1078591519 + "'", int50 == 1078591519);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 52.0d + "'", double54 == 52.0d);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 52.0d + "'", double56 == 52.0d);
        org.junit.Assert.assertNotNull(wildcardClass57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test485");
        double[] doubleArray1 = new double[] { '4' };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection3, false);
        double[] doubleArray7 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray1, (double) 100);
        double[] doubleArray9 = new double[] { 0 };
        double[] doubleArray11 = new double[] { '4' };
        int int12 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11, orderDirection13, false);
        double double16 = org.apache.commons.math.util.MathUtils.distance1(doubleArray9, doubleArray11);
        double double17 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray11);
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, (double) 100.0f);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection20 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11, orderDirection20, false);
        double[] doubleArray24 = new double[] { '4' };
        int int25 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        double[] doubleArray27 = new double[] { 7.105427357601002E-15d };
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equals(doubleArray24, doubleArray27);
        double[] doubleArray31 = new double[] { (byte) 10, (byte) 1 };
        double[] doubleArray33 = new double[] { '4' };
        int int34 = org.apache.commons.math.util.MathUtils.hash(doubleArray33);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection35 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray33, orderDirection35, false);
        double[] doubleArray39 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray33, (double) 100);
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray31, doubleArray33);
        double double41 = org.apache.commons.math.util.MathUtils.distance(doubleArray24, doubleArray33);
        double[] doubleArray43 = new double[] { '4' };
        int int44 = org.apache.commons.math.util.MathUtils.hash(doubleArray43);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection45 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray43, orderDirection45, false);
        double double48 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray43);
        double double49 = org.apache.commons.math.util.MathUtils.distance1(doubleArray24, doubleArray43);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException53 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1078591519, (java.lang.Number) 1.0d, (int) (short) 0);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection54 = nonMonotonousSequenceException53.getDirection();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray24, orderDirection54, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11, orderDirection54, true);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1078591519 + "'", int2 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1078591519 + "'", int12 == 1078591519);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 52.0d + "'", double16 == 52.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + orderDirection20 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection20.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1078591519 + "'", int25 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1078591519 + "'", int34 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1078591519 + "'", int44 == 1078591519);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 52.0d + "'", double48 == 52.0d);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection54 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection54.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test486");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(1104155263, 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1104155363 + "'", int2 == 1104155363);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test487");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.8556343548213666d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2768163014799492d + "'", double1 == 1.2768163014799492d);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test488");
        double double1 = org.apache.commons.math.util.FastMath.asinh((-2.3402060194404175d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5861929269790456d) + "'", double1 == (-1.5861929269790456d));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test489");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.0112214926104341E-41d, 3.1622776601683795d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test490");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0f, (float) 33L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test491");
        double[] doubleArray1 = new double[] { '4' };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray4 = new double[] { 7.105427357601002E-15d };
        boolean boolean5 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray4);
        double[] doubleArray8 = new double[] { (byte) 10, (byte) 1 };
        double[] doubleArray10 = new double[] { '4' };
        int int11 = org.apache.commons.math.util.MathUtils.hash(doubleArray10);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray10, orderDirection12, false);
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray10, (double) 100);
        boolean boolean17 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray8, doubleArray10);
        double double18 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray10);
        double[] doubleArray20 = new double[] { '4' };
        int int21 = org.apache.commons.math.util.MathUtils.hash(doubleArray20);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection22 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray20, orderDirection22, false);
        double double25 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray20);
        double double26 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray20);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException30 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1078591519, (java.lang.Number) 1.0d, (int) (short) 0);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection31 = nonMonotonousSequenceException30.getDirection();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection31, false);
        int int34 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1078591519 + "'", int2 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1078591519 + "'", int11 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1078591519 + "'", int21 == 1078591519);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 52.0d + "'", double25 == 52.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection31 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection31.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1078591519 + "'", int34 == 1078591519);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test492");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 1509505313L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1509505280 + "'", int1 == 1509505280);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test493");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 899, (long) (-1648403227));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1481914501073L + "'", long2 == 1481914501073L);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test494");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 3.141592653589793d, (java.lang.Number) 8563.535167616788d, (-1052060013));
        int int4 = nonMonotonousSequenceException3.getIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1052060013) + "'", int4 == (-1052060013));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test495");
        long long2 = org.apache.commons.math.util.MathUtils.pow(709810715L, (long) '4');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-6177663653831265999L) + "'", long2 == (-6177663653831265999L));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test496");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 9, 2758547353515625L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 24826926181640625L + "'", long2 == 24826926181640625L);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test497");
        double double1 = org.apache.commons.math.util.FastMath.atan(35.00000000000001d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5422326689561365d + "'", double1 == 1.5422326689561365d);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test498");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 88.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.170516276532822d + "'", double1 == 5.170516276532822d);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test499");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 52.0d, (java.lang.Number) (byte) 1, (int) '4', orderDirection3, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test500");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) (-1778258521L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }
}

