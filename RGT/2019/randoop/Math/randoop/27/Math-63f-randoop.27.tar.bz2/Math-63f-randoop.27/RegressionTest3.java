import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest3 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test001");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 0.0d, (int) (byte) 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException3.getDirection();
        java.lang.Number number7 = nonMonotonousSequenceException3.getPrevious();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.0d + "'", number4.equals(0.0d));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0d + "'", number5.equals(0.0d));
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 0.0d + "'", number7.equals(0.0d));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test002");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(2147483647, 200);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.ArithmeticException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test003");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 52.0d, (java.lang.Number) (byte) 1, (int) '4', orderDirection3, true);
        boolean boolean6 = nonMonotonousSequenceException5.getStrict();
        double[] doubleArray11 = new double[] { '4' };
        int int12 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11, orderDirection13, false);
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, (double) 100);
        double[] doubleArray19 = new double[] { 0 };
        double[] doubleArray21 = new double[] { '4' };
        int int22 = org.apache.commons.math.util.MathUtils.hash(doubleArray21);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection23 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray21, orderDirection23, false);
        double double26 = org.apache.commons.math.util.MathUtils.distance1(doubleArray19, doubleArray21);
        double double27 = org.apache.commons.math.util.MathUtils.distance1(doubleArray11, doubleArray21);
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray21, (double) 100.0f);
        double[] doubleArray31 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray21, (double) (short) -1);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray21);
        java.lang.Number number36 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException39 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number36, (java.lang.Number) 100, 100);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection40 = nonMonotonousSequenceException39.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException42 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2758547353515625L, (java.lang.Number) 0.6888022127440038d, (int) (byte) -1, orderDirection40, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray21, orderDirection40, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException46 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 7.105427357601002E-15d, (java.lang.Number) 10.04987562112089d, 1079574528, orderDirection40, false);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException46);
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1078591519 + "'", int12 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1078591519 + "'", int22 == 1078591519);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 52.0d + "'", double26 == 52.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + orderDirection40 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection40.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test004");
        double double1 = org.apache.commons.math.util.FastMath.cos(1.5067149491252272E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.994781578038135d + "'", double1 == 0.994781578038135d);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test005");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 1083179008, (-813036757852547071L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test006");
        double double2 = org.apache.commons.math.util.FastMath.max(10.04987562112089d, (-0.8813735870195429d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.04987562112089d + "'", double2 == 10.04987562112089d);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test007");
        double double2 = org.apache.commons.math.util.FastMath.atan2(9.35621353385326E-151d, (double) 43);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.175863612524014E-152d + "'", double2 == 2.175863612524014E-152d);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test008");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.0d, 1.486418323994938d, 1.6018844290008112E-18d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test009");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(1, 87);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test010");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) '#', 9);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 78815638671875L + "'", long2 == 78815638671875L);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test011");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((double) 1104154140L, 151);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.151802897413467E54d + "'", double2 == 3.151802897413467E54d);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test012");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((-8.1303675785254707E17d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.4190168364266808E16d) + "'", double1 == (-1.4190168364266808E16d));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test013");
        double double1 = org.apache.commons.math.util.FastMath.log((-0.989740156313126d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test014");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(1.9233097485725157d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3868344344486532d + "'", double1 == 1.3868344344486532d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test015");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(1.5430806348152437d, 0.8200290894110793d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5430806348152437d + "'", double2 == 1.5430806348152437d);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test016");
        long long2 = org.apache.commons.math.util.MathUtils.pow(0L, 87);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test017");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5430806348152437d + "'", double1 == 1.5430806348152437d);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test018");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(1024, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1024 + "'", int2 == 1024);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test019");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) 1024, (long) 1104155263);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1130654989312L + "'", long2 == 1130654989312L);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test020");
        double double1 = org.apache.commons.math.util.FastMath.acosh(1.104155264E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 21.515493593153867d + "'", double1 == 21.515493593153867d);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test021");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (short) 1, (long) 99);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test022");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((-0.5278888682247536d), 1.5707963267948966d, 1024);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test023");
        double double1 = org.apache.commons.math.util.MathUtils.sign((-8.045684064074768d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test024");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 1444748028);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.44474803E9f + "'", float1 == 1.44474803E9f);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test025");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test026");
        double double1 = org.apache.commons.math.util.MathUtils.sign(4.61512051684126d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test027");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((int) (short) 100, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test028");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) (byte) 0, (double) 1052060012, 0.09247264651318218d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test029");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { 0 };
        double[] doubleArray4 = new double[] { '4' };
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray4, orderDirection6, false);
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray4);
        double[] doubleArray11 = new double[] { '4' };
        int int12 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11, orderDirection13, false);
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, (double) 100);
        double[] doubleArray19 = new double[] { 0 };
        double[] doubleArray21 = new double[] { '4' };
        int int22 = org.apache.commons.math.util.MathUtils.hash(doubleArray21);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection23 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray21, orderDirection23, false);
        double double26 = org.apache.commons.math.util.MathUtils.distance1(doubleArray19, doubleArray21);
        double double27 = org.apache.commons.math.util.MathUtils.distance1(doubleArray11, doubleArray21);
        double double28 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray11);
        double double29 = org.apache.commons.math.util.MathUtils.distance(doubleArray4, doubleArray11);
        try {
            double double30 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1078591519 + "'", int5 == 1078591519);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 52.0d + "'", double9 == 52.0d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1078591519 + "'", int12 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1078591519 + "'", int22 == 1078591519);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 52.0d + "'", double26 == 52.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 52.0d + "'", double28 == 52.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test030");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 0.0d, (int) (byte) 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        boolean boolean6 = nonMonotonousSequenceException3.getStrict();
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test031");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(9);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test032");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 9);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9111302618846769d) + "'", double1 == (-0.9111302618846769d));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test033");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 2147483647L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7249165551445564d) + "'", double1 == (-0.7249165551445564d));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test034");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(1079574528);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test035");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 33L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.1898842314256335d + "'", double1 == 4.1898842314256335d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test036");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(200, (-1052060013));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test037");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 1078591488, (long) 340593889);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 340593889L + "'", long2 == 340593889L);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test038");
        long long1 = org.apache.commons.math.util.FastMath.abs(410574641189857375L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 410574641189857375L + "'", long1 == 410574641189857375L);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test039");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.019998666799998722d, 8.21975785280856E-29d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.01999866679999872d + "'", double2 == 0.01999866679999872d);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test040");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.67380010064806d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.17146892848269052d) + "'", double1 == (-0.17146892848269052d));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test041");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((double) 78815638671875L, (-1074790656));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.806651403477326E-64d + "'", double2 == 6.806651403477326E-64d);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test042");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(1052060013);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test043");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) '4');
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test044");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((int) ' ', (-1074790369));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1074790337) + "'", int2 == (-1074790337));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test045");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (byte) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) (short) 10);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) (byte) 0);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) (short) 10);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger7);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (int) 'a');
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (long) 90);
        java.math.BigInteger bigInteger15 = null;
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, (long) (byte) 0);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, (long) (short) 10);
        java.math.BigInteger bigInteger20 = null;
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, (long) (byte) 0);
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, (long) (short) 10);
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, bigInteger22);
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, (int) 'a');
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger27, 99);
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, 0);
        java.math.BigInteger bigInteger32 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertNotNull(bigInteger32);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test046");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 1052060047L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.05206003E9f + "'", float1 == 1.05206003E9f);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test047");
        double double1 = org.apache.commons.math.util.FastMath.ceil(1.0717762252344276d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test048");
        double double1 = org.apache.commons.math.util.FastMath.floor(1.5707963219178653d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test049");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5707963267948966d) + "'", double1 == (-1.5707963267948966d));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test050");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 200, (double) 43, (double) 800.0f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test051");
        double double1 = org.apache.commons.math.util.FastMath.ulp(4.9E-324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test052");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(5.598811600642372d, (double) 1024);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test053");
        double double1 = org.apache.commons.math.util.FastMath.rint(20.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 20.0d + "'", double1 == 20.0d);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test054");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) (-800L), (double) 376068538343702939L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.7606853834370291E17d + "'", double2 == 3.7606853834370291E17d);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test055");
        double double1 = org.apache.commons.math.util.FastMath.ceil(4.9E-324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test056");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        org.junit.Assert.assertNotNull(bigInteger2);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test057");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(1074790600, 1104155263);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-29364663) + "'", int2 == (-29364663));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test058");
        double double1 = org.apache.commons.math.util.FastMath.atanh(10.126894231686824d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test059");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 1444748028);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.073074329466795d + "'", double1 == 2.073074329466795d);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test060");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1078591519, (java.lang.Number) 1.0d, (int) (short) 0);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException7 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1078591519, (java.lang.Number) 1.0d, (int) (short) 0);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException7);
        java.lang.Number number9 = nonMonotonousSequenceException7.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0d, (java.lang.Number) (byte) -1, (int) '4', orderDirection13, false);
        int int16 = nonMonotonousSequenceException15.getIndex();
        nonMonotonousSequenceException7.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException15);
        java.lang.Number number18 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException21 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number18, (java.lang.Number) 100, 100);
        nonMonotonousSequenceException15.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException21);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection23 = nonMonotonousSequenceException21.getDirection();
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 1.0d + "'", number9.equals(1.0d));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 52 + "'", int16 == 52);
        org.junit.Assert.assertTrue("'" + orderDirection23 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection23.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test061");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((-29364663));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test062");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(340593891, 1083179008);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test063");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(0, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test064");
        double double1 = org.apache.commons.math.util.FastMath.floor(270.1052237423d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 270.0d + "'", double1 == 270.0d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test065");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-1074790400), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test066");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.23d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test067");
        int[] intArray1 = new int[] { (byte) 100 };
        int[] intArray4 = new int[] { 1, (short) -1 };
        int[] intArray8 = new int[] { 10, (byte) 0, (byte) 1 };
        double double9 = org.apache.commons.math.util.MathUtils.distance(intArray4, intArray8);
        int int10 = org.apache.commons.math.util.MathUtils.distance1(intArray1, intArray8);
        int[] intArray12 = new int[] { (byte) 100 };
        int[] intArray15 = new int[] { 1, (short) -1 };
        int[] intArray19 = new int[] { 10, (byte) 0, (byte) 1 };
        double double20 = org.apache.commons.math.util.MathUtils.distance(intArray15, intArray19);
        int int21 = org.apache.commons.math.util.MathUtils.distance1(intArray12, intArray19);
        int int22 = org.apache.commons.math.util.MathUtils.distance1(intArray1, intArray19);
        int[] intArray24 = new int[] { (byte) 100 };
        int[] intArray27 = new int[] { 1, (short) -1 };
        int[] intArray31 = new int[] { 10, (byte) 0, (byte) 1 };
        double double32 = org.apache.commons.math.util.MathUtils.distance(intArray27, intArray31);
        int int33 = org.apache.commons.math.util.MathUtils.distance1(intArray24, intArray31);
        int[] intArray35 = new int[] { (byte) 100 };
        int[] intArray38 = new int[] { 1, (short) -1 };
        int[] intArray42 = new int[] { 10, (byte) 0, (byte) 1 };
        double double43 = org.apache.commons.math.util.MathUtils.distance(intArray38, intArray42);
        int int44 = org.apache.commons.math.util.MathUtils.distance1(intArray35, intArray42);
        int int45 = org.apache.commons.math.util.MathUtils.distance1(intArray24, intArray42);
        int[] intArray48 = new int[] { 1, (short) -1 };
        int[] intArray52 = new int[] { 10, (byte) 0, (byte) 1 };
        double double53 = org.apache.commons.math.util.MathUtils.distance(intArray48, intArray52);
        int[] intArray55 = new int[] { (byte) 100 };
        int[] intArray58 = new int[] { 1, (short) -1 };
        int[] intArray62 = new int[] { 10, (byte) 0, (byte) 1 };
        double double63 = org.apache.commons.math.util.MathUtils.distance(intArray58, intArray62);
        int int64 = org.apache.commons.math.util.MathUtils.distance1(intArray55, intArray62);
        int int65 = org.apache.commons.math.util.MathUtils.distanceInf(intArray48, intArray62);
        int[] intArray68 = new int[] { 1, (short) -1 };
        int[] intArray72 = new int[] { 10, (byte) 0, (byte) 1 };
        double double73 = org.apache.commons.math.util.MathUtils.distance(intArray68, intArray72);
        int int74 = org.apache.commons.math.util.MathUtils.distanceInf(intArray48, intArray72);
        int int75 = org.apache.commons.math.util.MathUtils.distance1(intArray24, intArray48);
        int[] intArray78 = new int[] { 1, (short) -1 };
        int[] intArray82 = new int[] { 10, (byte) 0, (byte) 1 };
        double double83 = org.apache.commons.math.util.MathUtils.distance(intArray78, intArray82);
        int int84 = org.apache.commons.math.util.MathUtils.distance1(intArray48, intArray82);
        double double85 = org.apache.commons.math.util.MathUtils.distance(intArray1, intArray48);
        int[] intArray88 = new int[] { 1, (short) -1 };
        int[] intArray92 = new int[] { 10, (byte) 0, (byte) 1 };
        double double93 = org.apache.commons.math.util.MathUtils.distance(intArray88, intArray92);
        double double94 = org.apache.commons.math.util.MathUtils.distance(intArray48, intArray88);
        java.lang.Class<?> wildcardClass95 = intArray88.getClass();
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 9.055385138137417d + "'", double9 == 9.055385138137417d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 90 + "'", int10 == 90);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 9.055385138137417d + "'", double20 == 9.055385138137417d);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 90 + "'", int21 == 90);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 90 + "'", int22 == 90);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 9.055385138137417d + "'", double32 == 9.055385138137417d);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 90 + "'", int33 == 90);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 9.055385138137417d + "'", double43 == 9.055385138137417d);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 90 + "'", int44 == 90);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 90 + "'", int45 == 90);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 9.055385138137417d + "'", double53 == 9.055385138137417d);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertNotNull(intArray62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 9.055385138137417d + "'", double63 == 9.055385138137417d);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 90 + "'", int64 == 90);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 9 + "'", int65 == 9);
        org.junit.Assert.assertNotNull(intArray68);
        org.junit.Assert.assertNotNull(intArray72);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 9.055385138137417d + "'", double73 == 9.055385138137417d);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 9 + "'", int74 == 9);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 99 + "'", int75 == 99);
        org.junit.Assert.assertNotNull(intArray78);
        org.junit.Assert.assertNotNull(intArray82);
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + 9.055385138137417d + "'", double83 == 9.055385138137417d);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 10 + "'", int84 == 10);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 99.0d + "'", double85 == 99.0d);
        org.junit.Assert.assertNotNull(intArray88);
        org.junit.Assert.assertNotNull(intArray92);
        org.junit.Assert.assertTrue("'" + double93 + "' != '" + 9.055385138137417d + "'", double93 == 9.055385138137417d);
        org.junit.Assert.assertTrue("'" + double94 + "' != '" + 0.0d + "'", double94 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass95);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test068");
        java.lang.Number number1 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 1, number1, 0, orderDirection3, true);
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test069");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 100, 6.102016471589204E38d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 19.392736687814338d + "'", double2 == 19.392736687814338d);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test070");
        double[] doubleArray1 = new double[] { '4' };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection3, false);
        double[] doubleArray7 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray1, (double) 100);
        double[] doubleArray9 = new double[] { 0 };
        double[] doubleArray11 = new double[] { '4' };
        int int12 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11, orderDirection13, false);
        double double16 = org.apache.commons.math.util.MathUtils.distance1(doubleArray9, doubleArray11);
        double double17 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray11);
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, (double) 100.0f);
        double[] doubleArray21 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, (double) (short) -1);
        double[] doubleArray22 = null;
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equals(doubleArray21, doubleArray22);
        try {
            double double24 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1078591519 + "'", int2 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1078591519 + "'", int12 == 1078591519);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 52.0d + "'", double16 == 52.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test071");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.17453292519943295d + "'", double1 == 0.17453292519943295d);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test072");
        int int1 = org.apache.commons.math.util.MathUtils.sign((-1074790656));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test073");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(1493119226, 1073741824);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test074");
        double double1 = org.apache.commons.math.util.FastMath.asinh(3.4059388800000006E8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 20.33934856178851d + "'", double1 == 20.33934856178851d);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test075");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(3.5033980603867247d, 1.5699066473143302d, (double) 88L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test076");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(5156.620156177409d, 88);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5958966396795113E30d + "'", double2 == 1.5958966396795113E30d);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test077");
        double double1 = org.apache.commons.math.util.FastMath.tan(3.40593888E8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.1770150795479175d) + "'", double1 == (-1.1770150795479175d));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test078");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 2147483647, (long) 1509505280);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3241637903860156160L + "'", long2 == 3241637903860156160L);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test079");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.01999866679999872d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.019997333759945137d + "'", double1 == 0.019997333759945137d);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test080");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 0.0d, (int) (byte) 0);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= null)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (0 >= null)"));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test081");
        double double1 = org.apache.commons.math.util.FastMath.abs(17.872171540421935d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 17.872171540421935d + "'", double1 == 17.872171540421935d);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test082");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) (-1.10415411E9f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test083");
        long long2 = org.apache.commons.math.util.MathUtils.pow(0L, 1083179008);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test084");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) 153499259);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test085");
        float float1 = org.apache.commons.math.util.MathUtils.sign(90.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test086");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(200.06192982974676d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.843812265895635E86d + "'", double1 == 3.843812265895635E86d);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test087");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(0.8200290894110793d, 72090561);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5982881949586748E289d + "'", double2 == 1.5982881949586748E289d);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test088");
        long long1 = org.apache.commons.math.util.MathUtils.sign(1104155350L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test089");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 5L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test090");
        int[] intArray0 = null;
        int[] intArray4 = new int[] { 1024, 1078591519, (-1052060013) };
        int[] intArray6 = new int[] { (byte) 100 };
        int[] intArray9 = new int[] { 1, (short) -1 };
        int[] intArray13 = new int[] { 10, (byte) 0, (byte) 1 };
        double double14 = org.apache.commons.math.util.MathUtils.distance(intArray9, intArray13);
        int int15 = org.apache.commons.math.util.MathUtils.distance1(intArray6, intArray13);
        int[] intArray17 = new int[] { (byte) 100 };
        int[] intArray20 = new int[] { 1, (short) -1 };
        int[] intArray24 = new int[] { 10, (byte) 0, (byte) 1 };
        double double25 = org.apache.commons.math.util.MathUtils.distance(intArray20, intArray24);
        int int26 = org.apache.commons.math.util.MathUtils.distance1(intArray17, intArray24);
        int int27 = org.apache.commons.math.util.MathUtils.distance1(intArray6, intArray24);
        int[] intArray30 = new int[] { 1, (short) -1 };
        int[] intArray34 = new int[] { 10, (byte) 0, (byte) 1 };
        double double35 = org.apache.commons.math.util.MathUtils.distance(intArray30, intArray34);
        int[] intArray37 = new int[] { (byte) 100 };
        int[] intArray40 = new int[] { 1, (short) -1 };
        int[] intArray44 = new int[] { 10, (byte) 0, (byte) 1 };
        double double45 = org.apache.commons.math.util.MathUtils.distance(intArray40, intArray44);
        int int46 = org.apache.commons.math.util.MathUtils.distance1(intArray37, intArray44);
        int int47 = org.apache.commons.math.util.MathUtils.distanceInf(intArray30, intArray44);
        int[] intArray50 = new int[] { 1, (short) -1 };
        int[] intArray54 = new int[] { 10, (byte) 0, (byte) 1 };
        double double55 = org.apache.commons.math.util.MathUtils.distance(intArray50, intArray54);
        int int56 = org.apache.commons.math.util.MathUtils.distanceInf(intArray30, intArray54);
        int int57 = org.apache.commons.math.util.MathUtils.distance1(intArray6, intArray30);
        int[] intArray60 = new int[] { 1, (short) -1 };
        int[] intArray64 = new int[] { 10, (byte) 0, (byte) 1 };
        double double65 = org.apache.commons.math.util.MathUtils.distance(intArray60, intArray64);
        int[] intArray67 = new int[] { (byte) 100 };
        int[] intArray70 = new int[] { 1, (short) -1 };
        int[] intArray74 = new int[] { 10, (byte) 0, (byte) 1 };
        double double75 = org.apache.commons.math.util.MathUtils.distance(intArray70, intArray74);
        int int76 = org.apache.commons.math.util.MathUtils.distance1(intArray67, intArray74);
        double double77 = org.apache.commons.math.util.MathUtils.distance(intArray64, intArray74);
        int int78 = org.apache.commons.math.util.MathUtils.distanceInf(intArray30, intArray74);
        int int79 = org.apache.commons.math.util.MathUtils.distanceInf(intArray4, intArray74);
        try {
            double double80 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray74);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 9.055385138137417d + "'", double14 == 9.055385138137417d);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 90 + "'", int15 == 90);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 9.055385138137417d + "'", double25 == 9.055385138137417d);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 90 + "'", int26 == 90);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 90 + "'", int27 == 90);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 9.055385138137417d + "'", double35 == 9.055385138137417d);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 9.055385138137417d + "'", double45 == 9.055385138137417d);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 90 + "'", int46 == 90);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 9 + "'", int47 == 9);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertNotNull(intArray54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 9.055385138137417d + "'", double55 == 9.055385138137417d);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 9 + "'", int56 == 9);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 99 + "'", int57 == 99);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertNotNull(intArray64);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 9.055385138137417d + "'", double65 == 9.055385138137417d);
        org.junit.Assert.assertNotNull(intArray67);
        org.junit.Assert.assertNotNull(intArray70);
        org.junit.Assert.assertNotNull(intArray74);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 9.055385138137417d + "'", double75 == 9.055385138137417d);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 90 + "'", int76 == 90);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 0.0d + "'", double77 == 0.0d);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 9 + "'", int78 == 9);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 1078591519 + "'", int79 == 1078591519);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test091");
        int[] intArray1 = new int[] { (byte) 100 };
        int[] intArray4 = new int[] { 1, (short) -1 };
        int[] intArray8 = new int[] { 10, (byte) 0, (byte) 1 };
        double double9 = org.apache.commons.math.util.MathUtils.distance(intArray4, intArray8);
        int int10 = org.apache.commons.math.util.MathUtils.distance1(intArray1, intArray8);
        int[] intArray12 = new int[] { (byte) 100 };
        int[] intArray15 = new int[] { 1, (short) -1 };
        int[] intArray19 = new int[] { 10, (byte) 0, (byte) 1 };
        double double20 = org.apache.commons.math.util.MathUtils.distance(intArray15, intArray19);
        int int21 = org.apache.commons.math.util.MathUtils.distance1(intArray12, intArray19);
        int int22 = org.apache.commons.math.util.MathUtils.distance1(intArray1, intArray19);
        int[] intArray25 = new int[] { 1, (short) -1 };
        int[] intArray29 = new int[] { 10, (byte) 0, (byte) 1 };
        double double30 = org.apache.commons.math.util.MathUtils.distance(intArray25, intArray29);
        int[] intArray32 = new int[] { (byte) 100 };
        int[] intArray35 = new int[] { 1, (short) -1 };
        int[] intArray39 = new int[] { 10, (byte) 0, (byte) 1 };
        double double40 = org.apache.commons.math.util.MathUtils.distance(intArray35, intArray39);
        int int41 = org.apache.commons.math.util.MathUtils.distance1(intArray32, intArray39);
        int int42 = org.apache.commons.math.util.MathUtils.distanceInf(intArray25, intArray39);
        int[] intArray45 = new int[] { 1, (short) -1 };
        int[] intArray49 = new int[] { 10, (byte) 0, (byte) 1 };
        double double50 = org.apache.commons.math.util.MathUtils.distance(intArray45, intArray49);
        int int51 = org.apache.commons.math.util.MathUtils.distanceInf(intArray25, intArray49);
        int int52 = org.apache.commons.math.util.MathUtils.distance1(intArray1, intArray25);
        int[] intArray55 = new int[] { 1, (short) -1 };
        int[] intArray59 = new int[] { 10, (byte) 0, (byte) 1 };
        double double60 = org.apache.commons.math.util.MathUtils.distance(intArray55, intArray59);
        int[] intArray62 = new int[] { (byte) 100 };
        int[] intArray65 = new int[] { 1, (short) -1 };
        int[] intArray69 = new int[] { 10, (byte) 0, (byte) 1 };
        double double70 = org.apache.commons.math.util.MathUtils.distance(intArray65, intArray69);
        int int71 = org.apache.commons.math.util.MathUtils.distance1(intArray62, intArray69);
        double double72 = org.apache.commons.math.util.MathUtils.distance(intArray59, intArray69);
        int int73 = org.apache.commons.math.util.MathUtils.distanceInf(intArray25, intArray69);
        int[] intArray74 = null;
        try {
            int int75 = org.apache.commons.math.util.MathUtils.distanceInf(intArray25, intArray74);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 9.055385138137417d + "'", double9 == 9.055385138137417d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 90 + "'", int10 == 90);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 9.055385138137417d + "'", double20 == 9.055385138137417d);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 90 + "'", int21 == 90);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 90 + "'", int22 == 90);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 9.055385138137417d + "'", double30 == 9.055385138137417d);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 9.055385138137417d + "'", double40 == 9.055385138137417d);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 90 + "'", int41 == 90);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 9 + "'", int42 == 9);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 9.055385138137417d + "'", double50 == 9.055385138137417d);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 9 + "'", int51 == 9);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 99 + "'", int52 == 99);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 9.055385138137417d + "'", double60 == 9.055385138137417d);
        org.junit.Assert.assertNotNull(intArray62);
        org.junit.Assert.assertNotNull(intArray65);
        org.junit.Assert.assertNotNull(intArray69);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 9.055385138137417d + "'", double70 == 9.055385138137417d);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 90 + "'", int71 == 90);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.0d + "'", double72 == 0.0d);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 9 + "'", int73 == 9);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test092");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 1104155263);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.104155263E9d + "'", double1 == 1.104155263E9d);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test093");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1023410207, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1023410207 + "'", int2 == 1023410207);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test094");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(0.6888022127440038d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.6888022127440038d + "'", double2 == 0.6888022127440038d);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test095");
        float float2 = org.apache.commons.math.util.FastMath.min((float) '#', (float) 1223L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 35.0f + "'", float2 == 35.0f);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test096");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(11L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test097");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(3241637903860156160L, 1052060047L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test098");
        int[] intArray0 = null;
        int[] intArray3 = new int[] { 1, (short) -1 };
        int[] intArray7 = new int[] { 10, (byte) 0, (byte) 1 };
        double double8 = org.apache.commons.math.util.MathUtils.distance(intArray3, intArray7);
        int[] intArray10 = new int[] { (byte) 100 };
        int[] intArray13 = new int[] { 1, (short) -1 };
        int[] intArray17 = new int[] { 10, (byte) 0, (byte) 1 };
        double double18 = org.apache.commons.math.util.MathUtils.distance(intArray13, intArray17);
        int int19 = org.apache.commons.math.util.MathUtils.distance1(intArray10, intArray17);
        int int20 = org.apache.commons.math.util.MathUtils.distanceInf(intArray3, intArray17);
        try {
            int int21 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 9.055385138137417d + "'", double8 == 9.055385138137417d);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 9.055385138137417d + "'", double18 == 9.055385138137417d);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 90 + "'", int19 == 90);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 9 + "'", int20 == 9);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test099");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(90);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test100");
        double double1 = org.apache.commons.math.util.FastMath.sinh(800.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test101");
        double double1 = org.apache.commons.math.util.FastMath.asinh(2.8934439858858716d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.784200838503966d + "'", double1 == 1.784200838503966d);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test102");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((int) (byte) 100, (-1778258521));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test103");
        double double1 = org.apache.commons.math.util.FastMath.log(1059.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.9650803456014065d + "'", double1 == 6.9650803456014065d);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test104");
        double double2 = org.apache.commons.math.util.FastMath.max(800.0d, (double) 87);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 800.0d + "'", double2 == 800.0d);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test105");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 1444748028, (float) 5L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 5.0f + "'", float2 == 5.0f);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test106");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1078591519, (java.lang.Number) 1.0d, (int) (short) 0);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException7 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1078591519, (java.lang.Number) 1.0d, (int) (short) 0);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException7);
        java.lang.Number number9 = nonMonotonousSequenceException3.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = nonMonotonousSequenceException3.getDirection();
        boolean boolean11 = nonMonotonousSequenceException3.getStrict();
        java.lang.Number number18 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException21 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number18, (java.lang.Number) 100, 100);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection22 = nonMonotonousSequenceException21.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException24 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2758547353515625L, (java.lang.Number) 0.6888022127440038d, (int) (byte) -1, orderDirection22, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException26 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 90, (java.lang.Number) 359.1342053695755d, 200, orderDirection22, false);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException26);
        boolean boolean28 = nonMonotonousSequenceException3.getStrict();
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 1.0d + "'", number9.equals(1.0d));
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + orderDirection22 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection22.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test107");
        long long1 = org.apache.commons.math.util.FastMath.round(1.6018844290008112E-18d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test108");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(17.872171540421935d, 1.7160033436347992d, 32.97641394954658d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test109");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 35, (-1573460895));
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test110");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(0, 54);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 54 + "'", int2 == 54);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test111");
        java.lang.Number number6 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number6, (java.lang.Number) 100, 100);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = nonMonotonousSequenceException9.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2758547353515625L, (java.lang.Number) 0.6888022127440038d, (int) (byte) -1, orderDirection10, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException14 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 90, (java.lang.Number) 359.1342053695755d, 200, orderDirection10, false);
        boolean boolean15 = nonMonotonousSequenceException14.getStrict();
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test112");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 2758547353515625L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 36.24662779545408d + "'", double1 == 36.24662779545408d);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test113");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 376068538684296828L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test114");
        double[] doubleArray1 = new double[] { '4' };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection3, false);
        double[] doubleArray7 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray1, (double) 100);
        double[] doubleArray9 = new double[] { 0 };
        double[] doubleArray11 = new double[] { '4' };
        int int12 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11, orderDirection13, false);
        double double16 = org.apache.commons.math.util.MathUtils.distance1(doubleArray9, doubleArray11);
        double double17 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray11);
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, (double) 100.0f);
        double[] doubleArray21 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, (double) (short) -1);
        double[] doubleArray23 = new double[] { '4' };
        int int24 = org.apache.commons.math.util.MathUtils.hash(doubleArray23);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection25 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray23, orderDirection25, false);
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray23, (double) 100);
        double[] doubleArray31 = new double[] { 0 };
        double[] doubleArray33 = new double[] { '4' };
        int int34 = org.apache.commons.math.util.MathUtils.hash(doubleArray33);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection35 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray33, orderDirection35, false);
        double double38 = org.apache.commons.math.util.MathUtils.distance1(doubleArray31, doubleArray33);
        double double39 = org.apache.commons.math.util.MathUtils.distance1(doubleArray23, doubleArray33);
        double[] doubleArray41 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray33, (double) 100.0f);
        double double42 = org.apache.commons.math.util.MathUtils.distance1(doubleArray11, doubleArray33);
        double[] doubleArray44 = new double[] { '4' };
        int int45 = org.apache.commons.math.util.MathUtils.hash(doubleArray44);
        double[] doubleArray47 = new double[] { 7.105427357601002E-15d };
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equals(doubleArray44, doubleArray47);
        double[] doubleArray51 = new double[] { (byte) 10, (byte) 1 };
        double[] doubleArray53 = new double[] { '4' };
        int int54 = org.apache.commons.math.util.MathUtils.hash(doubleArray53);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection55 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray53, orderDirection55, false);
        double[] doubleArray59 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray53, (double) 100);
        boolean boolean60 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray51, doubleArray53);
        double double61 = org.apache.commons.math.util.MathUtils.distance(doubleArray44, doubleArray53);
        double[] doubleArray63 = new double[] { '4' };
        int int64 = org.apache.commons.math.util.MathUtils.hash(doubleArray63);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection65 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray63, orderDirection65, false);
        double double68 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray63);
        double double69 = org.apache.commons.math.util.MathUtils.distance1(doubleArray44, doubleArray63);
        java.lang.Number number70 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException73 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number70, (java.lang.Number) 100, 100);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection74 = nonMonotonousSequenceException73.getDirection();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray44, orderDirection74, false);
        double double77 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray11, doubleArray44);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1078591519 + "'", int2 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1078591519 + "'", int12 == 1078591519);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 52.0d + "'", double16 == 52.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1078591519 + "'", int24 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1078591519 + "'", int34 == 1078591519);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 52.0d + "'", double38 == 52.0d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1078591519 + "'", int45 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1078591519 + "'", int54 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 1078591519 + "'", int64 == 1078591519);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 52.0d + "'", double68 == 52.0d);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection74 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection74.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 0.0d + "'", double77 == 0.0d);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test115");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 376068538343702939L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test116");
        double double1 = org.apache.commons.math.util.FastMath.atanh((-0.012888417780019397d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.012889131488486541d) + "'", double1 == (-0.012889131488486541d));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test117");
        int int1 = org.apache.commons.math.util.MathUtils.sign(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test118");
        float float1 = org.apache.commons.math.util.MathUtils.sign(0.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test119");
        double[] doubleArray1 = new double[] { '4' };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection3, false);
        double[] doubleArray7 = new double[] { '4' };
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray7);
        double[] doubleArray10 = new double[] { 7.105427357601002E-15d };
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray10);
        double[] doubleArray13 = new double[] { '4' };
        int int14 = org.apache.commons.math.util.MathUtils.hash(doubleArray13);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray13, orderDirection15, false);
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray13, (double) 100);
        double[] doubleArray21 = new double[] { 0 };
        double[] doubleArray23 = new double[] { '4' };
        int int24 = org.apache.commons.math.util.MathUtils.hash(doubleArray23);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection25 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray23, orderDirection25, false);
        double double28 = org.apache.commons.math.util.MathUtils.distance1(doubleArray21, doubleArray23);
        double double29 = org.apache.commons.math.util.MathUtils.distance1(doubleArray13, doubleArray23);
        double[] doubleArray31 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray23, (double) 100.0f);
        double[] doubleArray33 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray23, (double) (short) -1);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray23);
        double double35 = org.apache.commons.math.util.MathUtils.distance1(doubleArray10, doubleArray23);
        double double36 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray10);
        double[] doubleArray38 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray10, 1.7242993583184938d);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1078591519 + "'", int2 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1078591519 + "'", int8 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1078591519 + "'", int14 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1078591519 + "'", int24 == 1078591519);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 52.0d + "'", double28 == 52.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 51.99999999999999d + "'", double35 == 51.99999999999999d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 51.99999999999999d + "'", double36 == 51.99999999999999d);
        org.junit.Assert.assertNotNull(doubleArray38);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test120");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-200), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test121");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (-1L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test122");
        double double1 = org.apache.commons.math.util.MathUtils.sign(4.1898842314256335d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test123");
        double[] doubleArray1 = new double[] { '4' };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection3, false);
        double[] doubleArray7 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray1, (double) 100);
        double[] doubleArray9 = new double[] { 0 };
        double[] doubleArray11 = new double[] { '4' };
        int int12 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11, orderDirection13, false);
        double double16 = org.apache.commons.math.util.MathUtils.distance1(doubleArray9, doubleArray11);
        double double17 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray11);
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, (double) 100.0f);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection20 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11, orderDirection20, false);
        double[] doubleArray24 = new double[] { '4' };
        int int25 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        double[] doubleArray27 = new double[] { 7.105427357601002E-15d };
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equals(doubleArray24, doubleArray27);
        double[] doubleArray31 = new double[] { (byte) 10, (byte) 1 };
        double[] doubleArray33 = new double[] { '4' };
        int int34 = org.apache.commons.math.util.MathUtils.hash(doubleArray33);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection35 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray33, orderDirection35, false);
        double[] doubleArray39 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray33, (double) 100);
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray31, doubleArray33);
        double double41 = org.apache.commons.math.util.MathUtils.distance(doubleArray24, doubleArray33);
        double[] doubleArray43 = new double[] { '4' };
        int int44 = org.apache.commons.math.util.MathUtils.hash(doubleArray43);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection45 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray43, orderDirection45, false);
        double double48 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray43);
        double double49 = org.apache.commons.math.util.MathUtils.distance1(doubleArray24, doubleArray43);
        double[] doubleArray51 = new double[] { '4' };
        int int52 = org.apache.commons.math.util.MathUtils.hash(doubleArray51);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection53 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray51, orderDirection53, false);
        double double56 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray51);
        double double57 = org.apache.commons.math.util.MathUtils.distance(doubleArray43, doubleArray51);
        double double58 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray11, doubleArray51);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray51);
        double[] doubleArray61 = new double[] { '4' };
        int int62 = org.apache.commons.math.util.MathUtils.hash(doubleArray61);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection63 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray61, orderDirection63, false);
        double[] doubleArray67 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray61, (double) 100);
        double double68 = org.apache.commons.math.util.MathUtils.distance1(doubleArray51, doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1078591519 + "'", int2 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1078591519 + "'", int12 == 1078591519);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 52.0d + "'", double16 == 52.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + orderDirection20 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection20.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1078591519 + "'", int25 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1078591519 + "'", int34 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1078591519 + "'", int44 == 1078591519);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 52.0d + "'", double48 == 52.0d);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1078591519 + "'", int52 == 1078591519);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 52.0d + "'", double56 == 52.0d);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 1078591519 + "'", int62 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test124");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(Double.NEGATIVE_INFINITY, (-1074790656));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.NEGATIVE_INFINITY + "'", double2 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test125");
        double[] doubleArray1 = new double[] { '4' };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection3, false);
        double[] doubleArray7 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray1, (double) 100);
        double[] doubleArray9 = new double[] { 0 };
        double[] doubleArray11 = new double[] { '4' };
        int int12 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11, orderDirection13, false);
        double double16 = org.apache.commons.math.util.MathUtils.distance1(doubleArray9, doubleArray11);
        double double17 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray11);
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, (double) 100.0f);
        double[] doubleArray21 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, (double) (short) -1);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11);
        java.lang.Number number26 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException29 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number26, (java.lang.Number) 100, 100);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection30 = nonMonotonousSequenceException29.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException32 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2758547353515625L, (java.lang.Number) 0.6888022127440038d, (int) (byte) -1, orderDirection30, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11, orderDirection30, true);
        double[] doubleArray36 = new double[] { '4' };
        int int37 = org.apache.commons.math.util.MathUtils.hash(doubleArray36);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray36);
        double double39 = org.apache.commons.math.util.MathUtils.distance(doubleArray11, doubleArray36);
        double double40 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1078591519 + "'", int2 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1078591519 + "'", int12 == 1078591519);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 52.0d + "'", double16 == 52.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + orderDirection30 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection30.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1078591519 + "'", int37 == 1078591519);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 52.0d + "'", double40 == 52.0d);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test126");
        double double1 = org.apache.commons.math.util.MathUtils.sign(0.8556343548213666d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test127");
        double double1 = org.apache.commons.math.util.FastMath.floor(99.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 99.0d + "'", double1 == 99.0d);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test128");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 985523693061886157L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test129");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) (byte) 10);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test130");
        double[] doubleArray2 = new double[] { (byte) 10, (byte) 1 };
        double[] doubleArray4 = new double[] { '4' };
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray4, orderDirection6, false);
        double[] doubleArray10 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray4, (double) 100);
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray4);
        double[] doubleArray13 = new double[] { '4' };
        int int14 = org.apache.commons.math.util.MathUtils.hash(doubleArray13);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray13, orderDirection15, false);
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray13, (double) 100);
        double[] doubleArray21 = new double[] { 0 };
        double[] doubleArray23 = new double[] { '4' };
        int int24 = org.apache.commons.math.util.MathUtils.hash(doubleArray23);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection25 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray23, orderDirection25, false);
        double double28 = org.apache.commons.math.util.MathUtils.distance1(doubleArray21, doubleArray23);
        double double29 = org.apache.commons.math.util.MathUtils.distance1(doubleArray13, doubleArray23);
        double double30 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray13);
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray13, 32.97641394954658d);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1078591519 + "'", int5 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1078591519 + "'", int14 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1078591519 + "'", int24 == 1078591519);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 52.0d + "'", double28 == 52.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 52.0d + "'", double30 == 52.0d);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test131");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((-0.4161468365471424d), (double) 200);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test132");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 1104155264, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test133");
        double double1 = org.apache.commons.math.util.FastMath.acosh(1.0203089395406904d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.20119924077955773d + "'", double1 == 0.20119924077955773d);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test134");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (-6177663653831265999L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 6.1776638E18f + "'", float1 == 6.1776638E18f);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test135");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 5.298292365610485d, (java.lang.Number) 54, 200);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test136");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 1078591519, (long) 153499259);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 153499259L + "'", long2 == 153499259L);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test137");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (-1));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test138");
        double double1 = org.apache.commons.math.util.FastMath.sinh(1.1752011936438014d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4650188248182272d + "'", double1 == 1.4650188248182272d);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test139");
        double double2 = org.apache.commons.math.util.FastMath.min((-7.016709298534876E-15d), 3.005895157766783d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-7.016709298534876E-15d) + "'", double2 == (-7.016709298534876E-15d));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test140");
        double[] doubleArray1 = new double[] { '4' };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray4 = new double[] { 7.105427357601002E-15d };
        boolean boolean5 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray4);
        double[] doubleArray7 = new double[] { '4' };
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray7);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7, orderDirection9, false);
        double[] doubleArray13 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, (double) 100);
        double[] doubleArray15 = new double[] { 0 };
        double[] doubleArray17 = new double[] { '4' };
        int int18 = org.apache.commons.math.util.MathUtils.hash(doubleArray17);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection19 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17, orderDirection19, false);
        double double22 = org.apache.commons.math.util.MathUtils.distance1(doubleArray15, doubleArray17);
        double double23 = org.apache.commons.math.util.MathUtils.distance1(doubleArray7, doubleArray17);
        double[] doubleArray25 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray17, (double) 100.0f);
        double[] doubleArray27 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray17, (double) (short) -1);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17);
        double double29 = org.apache.commons.math.util.MathUtils.distance1(doubleArray4, doubleArray17);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17);
        double[] doubleArray32 = new double[] { '4' };
        int int33 = org.apache.commons.math.util.MathUtils.hash(doubleArray32);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection34 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray32, orderDirection34, false);
        double[] doubleArray38 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray32, (double) 100);
        double[] doubleArray40 = new double[] { 0 };
        double[] doubleArray42 = new double[] { '4' };
        int int43 = org.apache.commons.math.util.MathUtils.hash(doubleArray42);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection44 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray42, orderDirection44, false);
        double double47 = org.apache.commons.math.util.MathUtils.distance1(doubleArray40, doubleArray42);
        double double48 = org.apache.commons.math.util.MathUtils.distance1(doubleArray32, doubleArray42);
        double double49 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray32);
        double[] doubleArray51 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray32, 32.97641394954658d);
        double[] doubleArray53 = new double[] { '4' };
        int int54 = org.apache.commons.math.util.MathUtils.hash(doubleArray53);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection55 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray53, orderDirection55, false);
        double[] doubleArray59 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray53, (double) 100);
        boolean boolean60 = org.apache.commons.math.util.MathUtils.equals(doubleArray32, doubleArray53);
        double double61 = org.apache.commons.math.util.MathUtils.distance(doubleArray17, doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1078591519 + "'", int2 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1078591519 + "'", int8 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1078591519 + "'", int18 == 1078591519);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 52.0d + "'", double22 == 52.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 51.99999999999999d + "'", double29 == 51.99999999999999d);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1078591519 + "'", int33 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1078591519 + "'", int43 == 1078591519);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 52.0d + "'", double47 == 52.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 52.0d + "'", double49 == 52.0d);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1078591519 + "'", int54 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test141");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 54, (long) 1862770862);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1862770862L + "'", long2 == 1862770862L);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test142");
        int int1 = org.apache.commons.math.util.MathUtils.sign((-1074790400));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test143");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.31046516452991896d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test144");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) (-813036757852547019L), (double) 1509505313L, 3.5033980603867243d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test145");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (byte) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) (short) 10);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) (byte) 0);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) (short) 10);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger7);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (int) 'a');
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, 99);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, 340593888);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, 709810715L);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger18);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test146");
        double double1 = org.apache.commons.math.util.FastMath.asinh(944.8154734160571d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.544137102816975d + "'", double1 == 7.544137102816975d);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test147");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialLog((-899));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test148");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(2.8284271247461903d, 10.04987562112089d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.111612431925776d + "'", double2 == 9.111612431925776d);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test149");
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, (long) (byte) 0);
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 985523693061886057L);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) (byte) 0);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 52.0f, (java.lang.Number) bigInteger7, (-1104154140));
        int int10 = nonMonotonousSequenceException9.getIndex();
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1104154140) + "'", int10 == (-1104154140));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test150");
        long long2 = org.apache.commons.math.util.MathUtils.pow((-1573461795L), 1078591519L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-9137155172879727627L) + "'", long2 == (-9137155172879727627L));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test151");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (byte) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) (short) 10);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) (byte) 0);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) (short) 10);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger7);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (int) 'a');
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (long) 0);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, 0L);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, 674103171);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, (int) (short) 100);
        java.math.BigInteger bigInteger21 = null;
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, (long) (byte) 0);
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, (int) (short) 10);
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger25, (long) 'a');
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger25, 100);
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger25, (long) 709810715);
        java.math.BigInteger bigInteger32 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, bigInteger25);
        java.math.BigInteger bigInteger33 = null;
        java.math.BigInteger bigInteger35 = org.apache.commons.math.util.MathUtils.pow(bigInteger33, (long) (byte) 0);
        java.math.BigInteger bigInteger37 = org.apache.commons.math.util.MathUtils.pow(bigInteger35, (long) (short) 10);
        java.math.BigInteger bigInteger38 = null;
        java.math.BigInteger bigInteger40 = org.apache.commons.math.util.MathUtils.pow(bigInteger38, (long) (byte) 0);
        java.math.BigInteger bigInteger42 = org.apache.commons.math.util.MathUtils.pow(bigInteger40, (long) (short) 10);
        java.math.BigInteger bigInteger43 = org.apache.commons.math.util.MathUtils.pow(bigInteger37, bigInteger40);
        java.math.BigInteger bigInteger45 = org.apache.commons.math.util.MathUtils.pow(bigInteger40, (int) 'a');
        java.math.BigInteger bigInteger47 = org.apache.commons.math.util.MathUtils.pow(bigInteger45, (long) 0);
        java.math.BigInteger bigInteger49 = org.apache.commons.math.util.MathUtils.pow(bigInteger45, 0L);
        java.math.BigInteger bigInteger51 = org.apache.commons.math.util.MathUtils.pow(bigInteger49, 674103171);
        java.math.BigInteger bigInteger52 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, bigInteger49);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertNotNull(bigInteger32);
        org.junit.Assert.assertNotNull(bigInteger35);
        org.junit.Assert.assertNotNull(bigInteger37);
        org.junit.Assert.assertNotNull(bigInteger40);
        org.junit.Assert.assertNotNull(bigInteger42);
        org.junit.Assert.assertNotNull(bigInteger43);
        org.junit.Assert.assertNotNull(bigInteger45);
        org.junit.Assert.assertNotNull(bigInteger47);
        org.junit.Assert.assertNotNull(bigInteger49);
        org.junit.Assert.assertNotNull(bigInteger51);
        org.junit.Assert.assertNotNull(bigInteger52);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test152");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 1073741824);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test153");
        double[] doubleArray1 = new double[] { '4' };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection3, false);
        double[] doubleArray7 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray1, (double) 100);
        double[] doubleArray9 = new double[] { 0 };
        double[] doubleArray11 = new double[] { '4' };
        int int12 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11, orderDirection13, false);
        double double16 = org.apache.commons.math.util.MathUtils.distance1(doubleArray9, doubleArray11);
        double double17 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray11);
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, (double) 100.0f);
        double[] doubleArray21 = new double[] { '4' };
        int int22 = org.apache.commons.math.util.MathUtils.hash(doubleArray21);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection23 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray21, orderDirection23, false);
        double[] doubleArray27 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray21, (double) 100);
        double[] doubleArray29 = new double[] { 0 };
        double[] doubleArray31 = new double[] { '4' };
        int int32 = org.apache.commons.math.util.MathUtils.hash(doubleArray31);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection33 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray31, orderDirection33, false);
        double double36 = org.apache.commons.math.util.MathUtils.distance1(doubleArray29, doubleArray31);
        double double37 = org.apache.commons.math.util.MathUtils.distance1(doubleArray21, doubleArray31);
        double[] doubleArray39 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray31, (double) 100.0f);
        double[] doubleArray41 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray31, (double) (short) -1);
        double[] doubleArray43 = new double[] { '4' };
        int int44 = org.apache.commons.math.util.MathUtils.hash(doubleArray43);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection45 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray43, orderDirection45, false);
        double[] doubleArray49 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray43, (double) 100);
        double[] doubleArray51 = new double[] { 0 };
        double[] doubleArray53 = new double[] { '4' };
        int int54 = org.apache.commons.math.util.MathUtils.hash(doubleArray53);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection55 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray53, orderDirection55, false);
        double double58 = org.apache.commons.math.util.MathUtils.distance1(doubleArray51, doubleArray53);
        double double59 = org.apache.commons.math.util.MathUtils.distance1(doubleArray43, doubleArray53);
        double[] doubleArray61 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray53, (double) 100.0f);
        double double62 = org.apache.commons.math.util.MathUtils.distance1(doubleArray31, doubleArray53);
        boolean boolean63 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray11, doubleArray53);
        double[] doubleArray65 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray53, 3.2311742677852644E-26d);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1078591519 + "'", int2 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1078591519 + "'", int12 == 1078591519);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 52.0d + "'", double16 == 52.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1078591519 + "'", int22 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1078591519 + "'", int32 == 1078591519);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 52.0d + "'", double36 == 52.0d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1078591519 + "'", int44 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1078591519 + "'", int54 == 1078591519);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 52.0d + "'", double58 == 52.0d);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNotNull(doubleArray65);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test154");
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, (long) (byte) 0);
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 985523693061886057L);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) (byte) 0);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 52.0f, (java.lang.Number) bigInteger7, (-1104154140));
        java.lang.Number number10 = nonMonotonousSequenceException9.getPrevious();
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(number10);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test155");
        double double1 = org.apache.commons.math.util.FastMath.log10(3.465735902799727d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5397954653811573d + "'", double1 == 0.5397954653811573d);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test156");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(0.03726671779428488d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.03727534444752073d + "'", double1 == 0.03727534444752073d);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test157");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 1509505280, 1.104155264E9d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5095052799999998E9d + "'", double2 == 1.5095052799999998E9d);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test158");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (byte) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) (short) 10);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) (byte) 0);
        java.math.BigInteger bigInteger8 = null;
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, (long) (byte) 0);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, (long) (short) 10);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, bigInteger12);
        java.math.BigInteger bigInteger14 = null;
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger14, (long) (byte) 0);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, (long) (short) 10);
        java.math.BigInteger bigInteger19 = null;
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, (long) (byte) 0);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, (long) (short) 10);
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, bigInteger21);
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, bigInteger24);
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger25);
        java.math.BigInteger bigInteger27 = null;
        try {
            java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger26);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test159");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test160");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.5699066473143302d, (java.lang.Number) 1.1840915351162484E42d, 8);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.5699066473143302d, (java.lang.Number) 1.1840915351162484E42d, 8);
        java.lang.Throwable[] throwableArray9 = nonMonotonousSequenceException8.getSuppressed();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException8);
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(throwableArray9);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test161");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 0.0d, (int) (byte) 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException3.getDirection();
        int int7 = nonMonotonousSequenceException3.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = nonMonotonousSequenceException3.getDirection();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.0d + "'", number4.equals(0.0d));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0d + "'", number5.equals(0.0d));
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + orderDirection8 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection8.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test162");
        int int2 = org.apache.commons.math.util.MathUtils.pow(9, (long) 1493119226);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1376083217 + "'", int2 == 1376083217);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test163");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 376068538343702939L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test164");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(1104155263, 88);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1104155175 + "'", int2 == 1104155175);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test165");
        double double2 = org.apache.commons.math.util.MathUtils.log(3.151802897413467E54d, 8.065817517094494E67d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.2460264927256066d + "'", double2 == 1.2460264927256066d);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test166");
        int int1 = org.apache.commons.math.util.FastMath.abs(90);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 90 + "'", int1 == 90);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test167");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) (-36822100455L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test168");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(1124L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1124L + "'", long2 == 1124L);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test169");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((-4304.9593197991335d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-16.267582477150757d) + "'", double1 == (-16.267582477150757d));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test170");
        double[] doubleArray0 = null;
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test171");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) 52L, 6.0d, 1059.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test172");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 88, (float) 340593889);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 3.40593888E8f + "'", float2 == 3.40593888E8f);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test173");
        int int2 = org.apache.commons.math.util.FastMath.min((-340593889), 1074790600);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-340593889) + "'", int2 == (-340593889));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test174");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-340593889), (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-340593889) + "'", int2 == (-340593889));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test175");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(4.944515159673473E42d, (double) (-36822100455L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.9445151596734725E42d + "'", double2 == 4.9445151596734725E42d);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test176");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.9721522630525295E-31d, 200.0d, 100.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test177");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(1.5604874136486533d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.159898775761099d + "'", double1 == 1.159898775761099d);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test178");
        double double2 = org.apache.commons.math.util.FastMath.min(0.0d, 1.1920928955078125E-7d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test179");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (byte) 0);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (long) (byte) 0);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) (short) 10);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger7);
        java.math.BigInteger bigInteger9 = null;
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (long) (byte) 0);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, (long) (short) 10);
        java.math.BigInteger bigInteger14 = null;
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger14, (long) (byte) 0);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, (long) (short) 10);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, bigInteger16);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, bigInteger19);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, (long) 87);
        java.math.BigInteger bigInteger23 = null;
        try {
            java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, bigInteger23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger22);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test180");
        double[] doubleArray1 = new double[] { 0 };
        double[] doubleArray3 = new double[] { '4' };
        int int4 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection5 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray3, orderDirection5, false);
        double double8 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray3);
        try {
            double[] doubleArray10 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray1, (double) 2758547353515625L);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.ArithmeticException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1078591519 + "'", int4 == 1078591519);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 52.0d + "'", double8 == 52.0d);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test181");
        double double1 = org.apache.commons.math.util.FastMath.log10(1.5958966396795113E30d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 30.20300476027884d + "'", double1 == 30.20300476027884d);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test182");
        double double1 = org.apache.commons.math.util.FastMath.atanh((-0.5278888682247537d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.587213915156929d) + "'", double1 == (-0.587213915156929d));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test183");
        double[] doubleArray1 = new double[] { '4' };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray4 = new double[] { 7.105427357601002E-15d };
        boolean boolean5 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray4);
        double[] doubleArray8 = new double[] { (byte) 10, (byte) 1 };
        double[] doubleArray10 = new double[] { '4' };
        int int11 = org.apache.commons.math.util.MathUtils.hash(doubleArray10);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray10, orderDirection12, false);
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray10, (double) 100);
        boolean boolean17 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray8, doubleArray10);
        double double18 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray10);
        double[] doubleArray20 = new double[] { '4' };
        int int21 = org.apache.commons.math.util.MathUtils.hash(doubleArray20);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection22 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray20, orderDirection22, false);
        double double25 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray20);
        double double26 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray20);
        double[] doubleArray28 = new double[] { '4' };
        int int29 = org.apache.commons.math.util.MathUtils.hash(doubleArray28);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection30 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray28, orderDirection30, false);
        double double33 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray28);
        double double34 = org.apache.commons.math.util.MathUtils.distance(doubleArray20, doubleArray28);
        double[] doubleArray36 = new double[] { '4' };
        int int37 = org.apache.commons.math.util.MathUtils.hash(doubleArray36);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection38 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray36, orderDirection38, false);
        double[] doubleArray42 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray36, (double) 100);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection43 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray36, orderDirection43, false);
        double[] doubleArray47 = new double[] { '4' };
        int int48 = org.apache.commons.math.util.MathUtils.hash(doubleArray47);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection49 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray47, orderDirection49, false);
        double[] doubleArray53 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray47, (double) 100);
        double double54 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray36, doubleArray53);
        double double55 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray28, doubleArray53);
        double[] doubleArray57 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray28, (double) 674103171);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1078591519 + "'", int2 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1078591519 + "'", int11 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1078591519 + "'", int21 == 1078591519);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 52.0d + "'", double25 == 52.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1078591519 + "'", int29 == 1078591519);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 52.0d + "'", double33 == 52.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1078591519 + "'", int37 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1078591519 + "'", int48 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 48.0d + "'", double54 == 48.0d);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 48.0d + "'", double55 == 48.0d);
        org.junit.Assert.assertNotNull(doubleArray57);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test184");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(0.45089065785741317d, 1073741824, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test185");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(72090561, 1104155175);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test186");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(0.999800059980007d, (-2147483647), 1104155264);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test187");
        double double1 = org.apache.commons.math.util.FastMath.asinh(2.4758800785707603E27d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 63.76954061151497d + "'", double1 == 63.76954061151497d);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test188");
        int[] intArray1 = new int[] { (byte) 100 };
        int[] intArray4 = new int[] { 1, (short) -1 };
        int[] intArray8 = new int[] { 10, (byte) 0, (byte) 1 };
        double double9 = org.apache.commons.math.util.MathUtils.distance(intArray4, intArray8);
        int int10 = org.apache.commons.math.util.MathUtils.distance1(intArray1, intArray8);
        int[] intArray12 = new int[] { (byte) 100 };
        int[] intArray15 = new int[] { 1, (short) -1 };
        int[] intArray19 = new int[] { 10, (byte) 0, (byte) 1 };
        double double20 = org.apache.commons.math.util.MathUtils.distance(intArray15, intArray19);
        int int21 = org.apache.commons.math.util.MathUtils.distance1(intArray12, intArray19);
        int int22 = org.apache.commons.math.util.MathUtils.distance1(intArray1, intArray19);
        int[] intArray25 = new int[] { 1, (short) -1 };
        int[] intArray29 = new int[] { 10, (byte) 0, (byte) 1 };
        double double30 = org.apache.commons.math.util.MathUtils.distance(intArray25, intArray29);
        try {
            double double31 = org.apache.commons.math.util.MathUtils.distance(intArray19, intArray25);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 9.055385138137417d + "'", double9 == 9.055385138137417d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 90 + "'", int10 == 90);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 9.055385138137417d + "'", double20 == 9.055385138137417d);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 90 + "'", int21 == 90);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 90 + "'", int22 == 90);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 9.055385138137417d + "'", double30 == 9.055385138137417d);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test189");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((int) (short) 100, (-1778258521));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test190");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(1.052060044750411E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.027860035854307E10d + "'", double1 == 6.027860035854307E10d);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test191");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) 100, 340593889);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 340593889 + "'", int2 == 340593889);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test192");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(1073741824, 72090561);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test193");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2147483647L, (java.lang.Number) (-0.41032129904823816d), 0);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test194");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-899), 100);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test195");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) Float.POSITIVE_INFINITY, (double) 1104155363);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test196");
        double double1 = org.apache.commons.math.util.FastMath.atanh(6.283185307179586d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test197");
        int int1 = org.apache.commons.math.util.MathUtils.sign(2147483647);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test198");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(2.718281828459045d, 0.8155525103660037d, (double) 1052060013);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test199");
        int int1 = org.apache.commons.math.util.MathUtils.sign(8);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test200");
        double[] doubleArray1 = new double[] { '4' };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection3, false);
        double[] doubleArray7 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray1, (double) 100);
        double[] doubleArray9 = new double[] { 0 };
        double[] doubleArray11 = new double[] { '4' };
        int int12 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11, orderDirection13, false);
        double double16 = org.apache.commons.math.util.MathUtils.distance1(doubleArray9, doubleArray11);
        double double17 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray11);
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, (double) 100.0f);
        double[] doubleArray21 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, (double) (short) -1);
        java.lang.Class<?> wildcardClass22 = doubleArray21.getClass();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1078591519 + "'", int2 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1078591519 + "'", int12 == 1078591519);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 52.0d + "'", double16 == 52.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(wildcardClass22);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test201");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(0.9521915644015781d, (double) (-813036757852547071L), 360.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test202");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.9785884097858145d, 8563.535167616788d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test203");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.2764014075493026d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.004824114618882041d + "'", double1 == 0.004824114618882041d);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test204");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((int) (byte) -1, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test205");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 985523693061886155L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 128.0d + "'", double1 == 128.0d);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test206");
        double double1 = org.apache.commons.math.util.FastMath.rint((-0.5712556729872575d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test207");
        double[] doubleArray1 = new double[] { '4' };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection3, false);
        double[] doubleArray7 = new double[] { '4' };
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray7);
        double[] doubleArray10 = new double[] { 7.105427357601002E-15d };
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray10);
        double[] doubleArray13 = new double[] { '4' };
        int int14 = org.apache.commons.math.util.MathUtils.hash(doubleArray13);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray13, orderDirection15, false);
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray13, (double) 100);
        double[] doubleArray21 = new double[] { 0 };
        double[] doubleArray23 = new double[] { '4' };
        int int24 = org.apache.commons.math.util.MathUtils.hash(doubleArray23);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection25 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray23, orderDirection25, false);
        double double28 = org.apache.commons.math.util.MathUtils.distance1(doubleArray21, doubleArray23);
        double double29 = org.apache.commons.math.util.MathUtils.distance1(doubleArray13, doubleArray23);
        double[] doubleArray31 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray23, (double) 100.0f);
        double[] doubleArray33 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray23, (double) (short) -1);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray23);
        double double35 = org.apache.commons.math.util.MathUtils.distance1(doubleArray10, doubleArray23);
        double double36 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray10);
        int int37 = org.apache.commons.math.util.MathUtils.hash(doubleArray10);
        double[] doubleArray39 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray10, 1.5699066473143302d);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1078591519 + "'", int2 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1078591519 + "'", int8 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1078591519 + "'", int14 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1078591519 + "'", int24 == 1078591519);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 52.0d + "'", double28 == 52.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 51.99999999999999d + "'", double35 == 51.99999999999999d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 51.99999999999999d + "'", double36 == 51.99999999999999d);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1023410207 + "'", int37 == 1023410207);
        org.junit.Assert.assertNotNull(doubleArray39);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test208");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (byte) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (int) (short) 10);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) 'a');
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 100);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) 100);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test209");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow(153499259L, (-899));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test210");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.104155261562341E9d, 9.986972779012214E35d, 1.5707963267948963d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test211");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(3, (-99));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 102 + "'", int2 == 102);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test212");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(340593891, 50);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test213");
        java.lang.Number number3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number3, (java.lang.Number) 100, 100);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException6.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 100.0f, (java.lang.Number) (-52L), (int) (byte) 1, orderDirection7, true);
        boolean boolean10 = nonMonotonousSequenceException9.getStrict();
        java.lang.Number number11 = nonMonotonousSequenceException9.getArgument();
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 100.0f + "'", number11.equals(100.0f));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test214");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(0L, 1104154463L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1104154463L + "'", long2 == 1104154463L);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test215");
        int int2 = org.apache.commons.math.util.FastMath.max((-1074790600), 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test216");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(0, (-200));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 200 + "'", int2 == 200);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test217");
        double double1 = org.apache.commons.math.util.FastMath.abs(5.267884728309446d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.267884728309446d + "'", double1 == 5.267884728309446d);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test218");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(1073741824, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test219");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(1.159898775761099d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0506870109409334d + "'", double1 == 1.0506870109409334d);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test220");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) (-499719071L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test221");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) (-899));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-9.651316634226061d) + "'", double1 == (-9.651316634226061d));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test222");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0d, (java.lang.Number) (byte) -1, (int) '4', orderDirection3, false);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        int int7 = nonMonotonousSequenceException5.getIndex();
        java.lang.Throwable[] throwableArray8 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.String str9 = nonMonotonousSequenceException5.toString();
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 52 + "'", int7 == 52);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 51 and 52 are not decreasing (-1 < 0)" + "'", str9.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 51 and 52 are not decreasing (-1 < 0)"));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test223");
        int int1 = org.apache.commons.math.util.MathUtils.hash(Double.NaN);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2146959360 + "'", int1 == 2146959360);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test224");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(1.5607966601082315d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.027241040673019475d + "'", double1 == 0.027241040673019475d);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test225");
        double[] doubleArray1 = new double[] { '4' };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection3, false);
        double[] doubleArray7 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray1, (double) 100);
        double[] doubleArray9 = new double[] { 0 };
        double[] doubleArray11 = new double[] { '4' };
        int int12 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11, orderDirection13, false);
        double double16 = org.apache.commons.math.util.MathUtils.distance1(doubleArray9, doubleArray11);
        double double17 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray11);
        double double18 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray1);
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray1, 32.97641394954658d);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection21 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray20, orderDirection21, true);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1078591519 + "'", int2 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1078591519 + "'", int12 == 1078591519);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 52.0d + "'", double16 == 52.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 52.0d + "'", double18 == 52.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + orderDirection21 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection21.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test226");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(2048.0d, (int) 'a', (-2104199679));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test227");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) (-813036757852547019L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test228");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) ' ', (double) 340593889L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test229");
        java.lang.Number number3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number3, (java.lang.Number) 100, 100);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException6.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 100.0f, (java.lang.Number) (-52L), (int) (byte) 1, orderDirection7, true);
        java.lang.Throwable[] throwableArray10 = nonMonotonousSequenceException9.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = nonMonotonousSequenceException9.getDirection();
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + orderDirection11 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection11.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test230");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { '4' };
        int int3 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection4 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2, orderDirection4, false);
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 100);
        double[] doubleArray10 = new double[] { 0 };
        double[] doubleArray12 = new double[] { '4' };
        int int13 = org.apache.commons.math.util.MathUtils.hash(doubleArray12);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray12, orderDirection14, false);
        double double17 = org.apache.commons.math.util.MathUtils.distance1(doubleArray10, doubleArray12);
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray12);
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, (double) 100.0f);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection21 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray12, orderDirection21, false);
        double[] doubleArray25 = new double[] { '4' };
        int int26 = org.apache.commons.math.util.MathUtils.hash(doubleArray25);
        double[] doubleArray28 = new double[] { 7.105427357601002E-15d };
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equals(doubleArray25, doubleArray28);
        double[] doubleArray32 = new double[] { (byte) 10, (byte) 1 };
        double[] doubleArray34 = new double[] { '4' };
        int int35 = org.apache.commons.math.util.MathUtils.hash(doubleArray34);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection36 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray34, orderDirection36, false);
        double[] doubleArray40 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray34, (double) 100);
        boolean boolean41 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray32, doubleArray34);
        double double42 = org.apache.commons.math.util.MathUtils.distance(doubleArray25, doubleArray34);
        double[] doubleArray44 = new double[] { '4' };
        int int45 = org.apache.commons.math.util.MathUtils.hash(doubleArray44);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection46 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray44, orderDirection46, false);
        double double49 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray44);
        double double50 = org.apache.commons.math.util.MathUtils.distance1(doubleArray25, doubleArray44);
        double[] doubleArray52 = new double[] { '4' };
        int int53 = org.apache.commons.math.util.MathUtils.hash(doubleArray52);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection54 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray52, orderDirection54, false);
        double double57 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray52);
        double double58 = org.apache.commons.math.util.MathUtils.distance(doubleArray44, doubleArray52);
        double double59 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray12, doubleArray52);
        try {
            double double60 = org.apache.commons.math.util.MathUtils.distance1(doubleArray0, doubleArray12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1078591519 + "'", int3 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1078591519 + "'", int13 == 1078591519);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 52.0d + "'", double17 == 52.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + orderDirection21 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection21.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1078591519 + "'", int26 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1078591519 + "'", int35 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1078591519 + "'", int45 == 1078591519);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 52.0d + "'", double49 == 52.0d);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1078591519 + "'", int53 == 1078591519);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 52.0d + "'", double57 == 52.0d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test231");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1078591519, (java.lang.Number) 1.0d, (int) (short) 0);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException7 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1078591519, (java.lang.Number) 1.0d, (int) (short) 0);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException7);
        java.lang.Number number9 = nonMonotonousSequenceException7.getPrevious();
        java.lang.String str10 = nonMonotonousSequenceException7.toString();
        java.lang.Number number14 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException17 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number14, (java.lang.Number) 0.0d, (int) (byte) 0);
        java.lang.Number number18 = nonMonotonousSequenceException17.getArgument();
        java.lang.Number number19 = nonMonotonousSequenceException17.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection20 = nonMonotonousSequenceException17.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException22 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 11L, (java.lang.Number) 6.0d, 1493119226, orderDirection20, false);
        nonMonotonousSequenceException7.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException22);
        java.lang.Number number24 = nonMonotonousSequenceException22.getPrevious();
        java.lang.Number number25 = nonMonotonousSequenceException22.getPrevious();
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 1.0d + "'", number9.equals(1.0d));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (1 >= 1,078,591,519)" + "'", str10.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (1 >= 1,078,591,519)"));
        org.junit.Assert.assertNull(number18);
        org.junit.Assert.assertNull(number19);
        org.junit.Assert.assertTrue("'" + orderDirection20 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection20.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + 6.0d + "'", number24.equals(6.0d));
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + 6.0d + "'", number25.equals(6.0d));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test232");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) (-1));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1074790400) + "'", int1 == (-1074790400));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test233");
        long long1 = org.apache.commons.math.util.MathUtils.sign(0L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test234");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((-1.2246467991473532E-16d), (double) 'a', 3);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test235");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 0L, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test236");
        double double1 = org.apache.commons.math.util.FastMath.cos(6.102016471589204E38d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7415933335367688d + "'", double1 == 0.7415933335367688d);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test237");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 0.0d, (int) (byte) 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        boolean boolean6 = nonMonotonousSequenceException3.getStrict();
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0d + "'", number5.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test238");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 3.0d, (java.lang.Number) 0.4841540246378895d, 2147483647);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test239");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1078591519, (java.lang.Number) 1.0d, (int) (short) 0);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException7 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1078591519, (java.lang.Number) 1.0d, (int) (short) 0);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException7);
        boolean boolean9 = nonMonotonousSequenceException3.getStrict();
        int int10 = nonMonotonousSequenceException3.getIndex();
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test240");
        double double1 = org.apache.commons.math.util.FastMath.sinh((-0.012889131488486541d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.012889488369398143d) + "'", double1 == (-0.012889488369398143d));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test241");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.7987856323614964d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7317197133460711d + "'", double1 == 0.7317197133460711d);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test242");
        double double1 = org.apache.commons.math.util.FastMath.rint(1.1213476657867432d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test243");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 340593891L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5855912138640784d) + "'", double1 == (-1.5855912138640784d));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test244");
        int int1 = org.apache.commons.math.util.FastMath.abs(340593889);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 340593889 + "'", int1 == 340593889);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test245");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 1104154140L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1104154112 + "'", int1 == 1104154112);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test246");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(20.33934856178851d, 0.0d, (double) (-88L));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test247");
        double double1 = org.apache.commons.math.util.FastMath.log(2.175863612524014E-152d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-349.2155084861336d) + "'", double1 == (-349.2155084861336d));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test248");
        long long1 = org.apache.commons.math.util.FastMath.round(92.13617560368711d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 92L + "'", long1 == 92L);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test249");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (byte) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) (short) 10);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) (byte) 0);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) (short) 10);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger7);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (int) 'a');
        java.math.BigInteger bigInteger13 = null;
        try {
            java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, bigInteger13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test250");
        double double1 = org.apache.commons.math.util.FastMath.ceil(2.3978952727983702d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test251");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) (-1328467627058191859L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 256.0d + "'", double1 == 256.0d);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test252");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (byte) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (int) (short) 10);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) 'a');
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 100);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) 709810715);
        java.math.BigInteger bigInteger11 = null;
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, (long) (byte) 0);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (long) (short) 10);
        java.math.BigInteger bigInteger16 = null;
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, (long) (byte) 0);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, (long) (short) 10);
        java.math.BigInteger bigInteger21 = null;
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, (long) (byte) 0);
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, (long) (short) 10);
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, bigInteger23);
        java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger26, (long) 1104155264);
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, bigInteger28);
        java.math.BigInteger bigInteger30 = null;
        java.math.BigInteger bigInteger32 = org.apache.commons.math.util.MathUtils.pow(bigInteger30, (long) (byte) 0);
        java.math.BigInteger bigInteger34 = org.apache.commons.math.util.MathUtils.pow(bigInteger32, (int) (short) 10);
        java.math.BigInteger bigInteger35 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, bigInteger32);
        java.math.BigInteger bigInteger36 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger32);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger28);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger32);
        org.junit.Assert.assertNotNull(bigInteger34);
        org.junit.Assert.assertNotNull(bigInteger35);
        org.junit.Assert.assertNotNull(bigInteger36);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test253");
        double[] doubleArray1 = new double[] { '4' };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection3, false);
        double[] doubleArray7 = new double[] { '4' };
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray7);
        double[] doubleArray10 = new double[] { 7.105427357601002E-15d };
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray10);
        double[] doubleArray13 = new double[] { '4' };
        int int14 = org.apache.commons.math.util.MathUtils.hash(doubleArray13);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray13, orderDirection15, false);
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray13, (double) 100);
        double[] doubleArray21 = new double[] { 0 };
        double[] doubleArray23 = new double[] { '4' };
        int int24 = org.apache.commons.math.util.MathUtils.hash(doubleArray23);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection25 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray23, orderDirection25, false);
        double double28 = org.apache.commons.math.util.MathUtils.distance1(doubleArray21, doubleArray23);
        double double29 = org.apache.commons.math.util.MathUtils.distance1(doubleArray13, doubleArray23);
        double[] doubleArray31 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray23, (double) 100.0f);
        double[] doubleArray33 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray23, (double) (short) -1);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray23);
        double double35 = org.apache.commons.math.util.MathUtils.distance1(doubleArray10, doubleArray23);
        double double36 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray10);
        double[] doubleArray38 = new double[] { '4' };
        int int39 = org.apache.commons.math.util.MathUtils.hash(doubleArray38);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection40 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray38, orderDirection40, false);
        double[] doubleArray44 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray38, (double) 100);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection45 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray38, orderDirection45, false);
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray38);
        double double49 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1078591519 + "'", int2 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1078591519 + "'", int8 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1078591519 + "'", int14 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1078591519 + "'", int24 == 1078591519);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 52.0d + "'", double28 == 52.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 51.99999999999999d + "'", double35 == 51.99999999999999d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 51.99999999999999d + "'", double36 == 51.99999999999999d);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1078591519 + "'", int39 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 52.0d + "'", double49 == 52.0d);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test254");
        double double1 = org.apache.commons.math.util.FastMath.log(35.00000000000001d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.555348061489414d + "'", double1 == 3.555348061489414d);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test255");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(1079574528, 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test256");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (byte) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (int) (short) 10);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) 'a');
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 100);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 52L);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test257");
        double[] doubleArray1 = new double[] { '4' };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray4 = new double[] { 7.105427357601002E-15d };
        boolean boolean5 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray4);
        double[] doubleArray8 = new double[] { (byte) 10, (byte) 1 };
        double[] doubleArray10 = new double[] { '4' };
        int int11 = org.apache.commons.math.util.MathUtils.hash(doubleArray10);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray10, orderDirection12, false);
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray10, (double) 100);
        boolean boolean17 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray8, doubleArray10);
        double double18 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray10);
        double[] doubleArray20 = new double[] { '4' };
        int int21 = org.apache.commons.math.util.MathUtils.hash(doubleArray20);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection22 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray20, orderDirection22, false);
        double double25 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray20);
        double double26 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray20);
        java.lang.Number number27 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException30 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number27, (java.lang.Number) 100, 100);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection31 = nonMonotonousSequenceException30.getDirection();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection31, false);
        int int34 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray36 = new double[] { '4' };
        int int37 = org.apache.commons.math.util.MathUtils.hash(doubleArray36);
        double double38 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray36);
        double[] doubleArray40 = new double[] { '4' };
        int int41 = org.apache.commons.math.util.MathUtils.hash(doubleArray40);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection42 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray40, orderDirection42, false);
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray40, (double) 100);
        double[] doubleArray48 = new double[] { 0 };
        double[] doubleArray50 = new double[] { '4' };
        int int51 = org.apache.commons.math.util.MathUtils.hash(doubleArray50);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection52 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray50, orderDirection52, false);
        double double55 = org.apache.commons.math.util.MathUtils.distance1(doubleArray48, doubleArray50);
        double double56 = org.apache.commons.math.util.MathUtils.distance1(doubleArray40, doubleArray50);
        double[] doubleArray58 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray50, (double) 100.0f);
        double[] doubleArray60 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray50, (double) (short) -1);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray50);
        java.lang.Number number65 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException68 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number65, (java.lang.Number) 100, 100);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection69 = nonMonotonousSequenceException68.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException71 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2758547353515625L, (java.lang.Number) 0.6888022127440038d, (int) (byte) -1, orderDirection69, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray50, orderDirection69, true);
        boolean boolean74 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray36, doubleArray50);
        double double75 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray50);
        double[] doubleArray77 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray1, (double) 2147483647);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1078591519 + "'", int2 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1078591519 + "'", int11 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1078591519 + "'", int21 == 1078591519);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 52.0d + "'", double25 == 52.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection31 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection31.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1078591519 + "'", int34 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1078591519 + "'", int37 == 1078591519);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 52.0d + "'", double38 == 52.0d);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1078591519 + "'", int41 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1078591519 + "'", int51 == 1078591519);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 52.0d + "'", double55 == 52.0d);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + orderDirection69 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection69.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.0d + "'", double75 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray77);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test258");
        double double1 = org.apache.commons.math.util.FastMath.asin(1814400.000000139d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test259");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0d, (java.lang.Number) (byte) -1, (int) '4', orderDirection3, false);
        int int6 = nonMonotonousSequenceException5.getIndex();
        java.lang.Number number7 = nonMonotonousSequenceException5.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException14 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1078591519, (java.lang.Number) 1.0d, (int) (short) 0);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = nonMonotonousSequenceException14.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException17 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.710204268114578E15d, (java.lang.Number) 90.0d, 50, orderDirection15, false);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException17);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 52 + "'", int6 == 52);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 0.0d + "'", number7.equals(0.0d));
        org.junit.Assert.assertTrue("'" + orderDirection15 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection15.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test260");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 3628800L, 164.3201122631952d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3628800.0d + "'", double2 == 3628800.0d);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test261");
        double[] doubleArray1 = new double[] { '4' };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray4 = new double[] { 7.105427357601002E-15d };
        boolean boolean5 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray4);
        double[] doubleArray8 = new double[] { (byte) 10, (byte) 1 };
        double[] doubleArray10 = new double[] { '4' };
        int int11 = org.apache.commons.math.util.MathUtils.hash(doubleArray10);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray10, orderDirection12, false);
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray10, (double) 100);
        boolean boolean17 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray8, doubleArray10);
        double double18 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray10);
        double[] doubleArray20 = new double[] { '4' };
        int int21 = org.apache.commons.math.util.MathUtils.hash(doubleArray20);
        double[] doubleArray23 = new double[] { 7.105427357601002E-15d };
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equals(doubleArray20, doubleArray23);
        double[] doubleArray26 = new double[] { '4' };
        int int27 = org.apache.commons.math.util.MathUtils.hash(doubleArray26);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection28 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray26, orderDirection28, false);
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, (double) 100);
        double[] doubleArray34 = new double[] { 0 };
        double[] doubleArray36 = new double[] { '4' };
        int int37 = org.apache.commons.math.util.MathUtils.hash(doubleArray36);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection38 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray36, orderDirection38, false);
        double double41 = org.apache.commons.math.util.MathUtils.distance1(doubleArray34, doubleArray36);
        double double42 = org.apache.commons.math.util.MathUtils.distance1(doubleArray26, doubleArray36);
        double[] doubleArray44 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray36, (double) 100.0f);
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray36, (double) (short) -1);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray36);
        double double48 = org.apache.commons.math.util.MathUtils.distance1(doubleArray23, doubleArray36);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray36);
        double[] doubleArray53 = new double[] { 0.8813593244538519d, 0.6376590339551076d, 3447824565082718239L };
        double double54 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray36, doubleArray53);
        int int55 = org.apache.commons.math.util.MathUtils.hash(doubleArray53);
        double double56 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray10, doubleArray53);
        double[] doubleArray58 = new double[] { '4' };
        int int59 = org.apache.commons.math.util.MathUtils.hash(doubleArray58);
        double[] doubleArray61 = new double[] { 7.105427357601002E-15d };
        boolean boolean62 = org.apache.commons.math.util.MathUtils.equals(doubleArray58, doubleArray61);
        double[] doubleArray64 = new double[] { '4' };
        int int65 = org.apache.commons.math.util.MathUtils.hash(doubleArray64);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection66 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray64, orderDirection66, false);
        double[] doubleArray70 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray64, (double) 100);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection71 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray64, orderDirection71, false);
        double[] doubleArray75 = new double[] { '4' };
        int int76 = org.apache.commons.math.util.MathUtils.hash(doubleArray75);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection77 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray75, orderDirection77, false);
        double[] doubleArray81 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray75, (double) 100);
        double double82 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray64, doubleArray81);
        double double83 = org.apache.commons.math.util.MathUtils.distance1(doubleArray61, doubleArray64);
        boolean boolean84 = org.apache.commons.math.util.MathUtils.equals(doubleArray53, doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1078591519 + "'", int2 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1078591519 + "'", int11 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1078591519 + "'", int21 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1078591519 + "'", int27 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1078591519 + "'", int37 == 1078591519);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 52.0d + "'", double41 == 52.0d);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 51.99999999999999d + "'", double48 == 51.99999999999999d);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 51.118640675546146d + "'", double54 == 51.118640675546146d);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1862770862 + "'", int55 == 1862770862);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 51.118640675546146d + "'", double56 == 51.118640675546146d);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1078591519 + "'", int59 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 1078591519 + "'", int65 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 1078591519 + "'", int76 == 1078591519);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 48.0d + "'", double82 == 48.0d);
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + 51.99999999999999d + "'", double83 == 51.99999999999999d);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test262");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(35, 4);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 52360.0d + "'", double2 == 52360.0d);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test263");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 410574641189857375L, (double) 2060654347, (double) (-9137155172879727627L));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test264");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 35);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.473814720414451d + "'", double1 == 0.473814720414451d);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test265");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }
}

