import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest3 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test001");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO;
        org.apache.commons.math.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math.exception.NotPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 2);
        java.lang.Number number3 = notPositiveException2.getMin();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO));
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test002");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(1.7182818284590453d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.697783723013432d + "'", double1 == 2.697783723013432d);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test003");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.BANDWIDTH;
        org.apache.commons.math.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math.exception.NotPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 10.0f);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.BANDWIDTH + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.BANDWIDTH));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test004");
        double double1 = org.apache.commons.math.util.FastMath.atan(11.407165544086638d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4833556674013948d + "'", double1 == 1.4833556674013948d);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test005");
        float float2 = org.apache.commons.math.util.MathUtils.round(9.5284192E8f, (int) '4');
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test006");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.DENOMINATOR;
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = localizedFormats0.getLocalizedString(locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DENOMINATOR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.DENOMINATOR));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test007");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.STANDARD_DEVIATION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.IDENTICAL_ABSCISSAS_DIVISION_BY_ZERO;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException9 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats6, (int) (short) 100, (int) (byte) -1);
        int int10 = dimensionMismatchException9.getDimension();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL_INTERPOLANTS_MISMATCH_SEGMENTS;
        org.apache.commons.math.exception.NullArgumentException nullArgumentException12 = new org.apache.commons.math.exception.NullArgumentException();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext13 = nullArgumentException12.getContext();
        java.lang.Object[] objArray14 = new java.lang.Object[] { localizedFormats5, int10, localizedFormats11, exceptionContext13 };
        org.apache.commons.math.exception.NoBracketingException noBracketingException15 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, 0.0d, (double) (-537919489), (double) 1.2676506E30f, (double) (short) 10, objArray14);
        double double16 = noBracketingException15.getFHi();
        double double17 = noBracketingException15.getHi();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.STANDARD_DEVIATION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.STANDARD_DEVIATION));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.IDENTICAL_ABSCISSAS_DIVISION_BY_ZERO + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.IDENTICAL_ABSCISSAS_DIVISION_BY_ZERO));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL_INTERPOLANTS_MISMATCH_SEGMENTS + "'", localizedFormats11.equals(org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL_INTERPOLANTS_MISMATCH_SEGMENTS));
        org.junit.Assert.assertNotNull(exceptionContext13);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 10.0d + "'", double16 == 10.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-5.37919489E8d) + "'", double17 == (-5.37919489E8d));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test008");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_0_FOR_SOME_ALPHA;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX;
        java.lang.Object[] objArray11 = new java.lang.Object[] { localizedFormats7, 6.50349243853352d, localizedFormats9, localizedFormats10 };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException12 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats6, objArray11);
        org.apache.commons.math.exception.NoBracketingException noBracketingException13 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (-0.0d), (-0.7853981633974483d), 0.0d, (double) 2L, objArray11);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException14 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 2.2250738585072014E-308d, objArray11);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats17 = org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED;
        java.lang.Number number18 = null;
        java.lang.Object[] objArray21 = new java.lang.Object[] { (-1.0f), true };
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException22 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats17, number18, objArray21);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException23 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats15, (java.lang.Number) 107L, objArray21);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext24 = maxCountExceededException23.getContext();
        notFiniteNumberException14.addSuppressed((java.lang.Throwable) maxCountExceededException23);
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_0_FOR_SOME_ALPHA + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_0_FOR_SOME_ALPHA));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX_OUT_OF_RANGE + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizedFormats9.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX + "'", localizedFormats10.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM + "'", localizedFormats15.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM));
        org.junit.Assert.assertTrue("'" + localizedFormats17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED + "'", localizedFormats17.equals(org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED));
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(exceptionContext24);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test009");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_OBJECT_TO_FRACTION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.TOO_MUCH_CANCELLATION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ROUNDING_METHOD;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_SIZE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray9 = new java.lang.Object[] { "hi!", localizedFormats4, localizedFormats5, localizedFormats6, localizedFormats7, 10L };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException10 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Number) 1.0f, objArray9);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext11 = maxCountExceededException10.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_SUCCESSES;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math.exception.util.LocalizedFormats.TOO_MUCH_CANCELLATION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats18 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ROUNDING_METHOD;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats19 = org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_SIZE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats20 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray23 = new java.lang.Object[] { "hi!", localizedFormats18, localizedFormats19, localizedFormats20, localizedFormats21, 10L };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException24 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats15, (java.lang.Number) 1.0f, objArray23);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException25 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats13, (java.lang.Number) (-1.7581226324091723d), objArray23);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats26 = org.apache.commons.math.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT;
        int[] intArray32 = new int[] { (byte) 1, 0, (byte) 10, 1, 0 };
        int[] intArray34 = org.apache.commons.math.util.MathUtils.copyOf(intArray32, (int) '4');
        int[] intArray40 = new int[] { (byte) 1, 0, (byte) 10, 1, 0 };
        int[] intArray42 = org.apache.commons.math.util.MathUtils.copyOf(intArray40, (int) '4');
        int[] intArray48 = new int[] { (-1000602687), 10, 0, (short) 100, (short) 0 };
        double double49 = org.apache.commons.math.util.MathUtils.distance(intArray40, intArray48);
        double double50 = org.apache.commons.math.util.MathUtils.distance(intArray32, intArray48);
        java.lang.Object[] objArray51 = new java.lang.Object[] { (-1.7581226324091723d), localizedFormats26, intArray32 };
        exceptionContext11.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats12, objArray51);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException53 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray51);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext54 = mathArithmeticException53.getContext();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_OBJECT_TO_FRACTION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_OBJECT_TO_FRACTION));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TOO_MUCH_CANCELLATION + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.TOO_MUCH_CANCELLATION));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ROUNDING_METHOD + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ROUNDING_METHOD));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_SIZE + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_SIZE));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(exceptionContext11);
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_SUCCESSES + "'", localizedFormats12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_SUCCESSES));
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER + "'", localizedFormats13.equals(org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER));
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TOO_MUCH_CANCELLATION + "'", localizedFormats15.equals(org.apache.commons.math.exception.util.LocalizedFormats.TOO_MUCH_CANCELLATION));
        org.junit.Assert.assertTrue("'" + localizedFormats18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ROUNDING_METHOD + "'", localizedFormats18.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ROUNDING_METHOD));
        org.junit.Assert.assertTrue("'" + localizedFormats19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_SIZE + "'", localizedFormats19.equals(org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_SIZE));
        org.junit.Assert.assertTrue("'" + localizedFormats20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats20.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES + "'", localizedFormats21.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertTrue("'" + localizedFormats26 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT + "'", localizedFormats26.equals(org.apache.commons.math.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT));
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 1.000602688000005E9d + "'", double49 == 1.000602688000005E9d);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 1.000602688000005E9d + "'", double50 == 1.000602688000005E9d);
        org.junit.Assert.assertNotNull(objArray51);
        org.junit.Assert.assertNotNull(exceptionContext54);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test010");
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifySequence((double) 1000602688, 2048.0d, 100.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [1,000,602,688, 2,048]");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test011");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) (-100));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-5729.5779513082325d) + "'", double1 == (-5729.5779513082325d));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test012");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) (-1023));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test013");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 537919490);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.3791949E8d + "'", double1 == 5.3791949E8d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test014");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test015");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double double3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(univariateRealFunction0, 1025.8871450155818d, (-1.1591352365493741d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test016");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 4, 15.104412573075516d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test017");
        int[] intArray0 = null;
        int[] intArray6 = new int[] { (-537919489), 31, (short) 100, 2, 3 };
        int[] intArray7 = org.apache.commons.math.util.MathUtils.copyOf(intArray6);
        int[] intArray13 = new int[] { (byte) 1, 0, (byte) 10, 1, 0 };
        int[] intArray15 = org.apache.commons.math.util.MathUtils.copyOf(intArray13, (int) '4');
        int[] intArray21 = new int[] { (-1000602687), 10, 0, (short) 100, (short) 0 };
        double double22 = org.apache.commons.math.util.MathUtils.distance(intArray13, intArray21);
        int[] intArray28 = new int[] { (byte) 1, 0, (byte) 10, 1, 0 };
        int[] intArray30 = org.apache.commons.math.util.MathUtils.copyOf(intArray28, (int) '4');
        int int31 = org.apache.commons.math.util.MathUtils.distanceInf(intArray13, intArray28);
        int[] intArray32 = org.apache.commons.math.util.MathUtils.copyOf(intArray13);
        int[] intArray33 = org.apache.commons.math.util.MathUtils.copyOf(intArray32);
        int int34 = org.apache.commons.math.util.MathUtils.distanceInf(intArray7, intArray33);
        try {
            int int35 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.000602688000005E9d + "'", double22 == 1.000602688000005E9d);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 537919490 + "'", int34 == 537919490);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test018");
        double double4 = org.apache.commons.math.util.MathUtils.linearCombination(1.0E-5d, (double) 6.1035156E9f, 0.0d, 97.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 61035.156480000005d + "'", double4 == 61035.156480000005d);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test019");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 952841920, 1.1216563220823819d, (double) (-419311268));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test020");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(1.1920928955078125E-7d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.000000000000007d + "'", double1 == 1.000000000000007d);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test021");
        double double2 = org.apache.commons.math.util.FastMath.max((double) Float.NaN, 0.7853982230020895d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test022");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException(number0, (java.lang.Number) (byte) 0, true);
        java.lang.Number number4 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (byte) 0 + "'", number4.equals((byte) 0));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test023");
        double double1 = org.apache.commons.math.util.FastMath.sinh((-1.075554604777982E11d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test024");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(462683420, 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathArithmeticException; message: arithmetic exception");
        } catch (org.apache.commons.math.exception.MathArithmeticException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test025");
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math.exception.DimensionMismatchException(1594323, 60466176);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test026");
        double[] doubleArray1 = new double[] { 10 };
        double[] doubleArray6 = new double[] { 3.4965075614664802d, (-1), (byte) 1, 100 };
        double double7 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray6);
        double[] doubleArray10 = new double[] { 10.0d, 0.0d };
        double[] doubleArray14 = new double[] { 1.7182818284590453d, (short) 10, '4' };
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray10, doubleArray14);
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray10);
        double[] doubleArray19 = new double[] { 10.0d, 0.0d };
        double[] doubleArray23 = new double[] { 1.7182818284590453d, (short) 10, '4' };
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray23);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection25 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        boolean boolean28 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray23, orderDirection25, false, true);
        boolean boolean31 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection25, false, true);
        double[] doubleArray34 = new double[] { 10.0d, 0.0d };
        double[] doubleArray38 = new double[] { 1.7182818284590453d, (short) 10, '4' };
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray34, doubleArray38);
        double[] doubleArray41 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray34, (double) (short) 100);
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray34);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException46 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 22026.465794806718d, (java.lang.Number) 100, (int) (short) 1);
        java.lang.Number number47 = nonMonotonousSequenceException46.getPrevious();
        java.lang.Number number48 = nonMonotonousSequenceException46.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection49 = nonMonotonousSequenceException46.getDirection();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection49, false);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 6.50349243853352d + "'", double7 == 6.50349243853352d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + orderDirection25 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection25.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + number47 + "' != '" + 100 + "'", number47.equals(100));
        org.junit.Assert.assertTrue("'" + number48 + "' != '" + 22026.465794806718d + "'", number48.equals(22026.465794806718d));
        org.junit.Assert.assertTrue("'" + orderDirection49 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection49.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test027");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver0 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        double double1 = regulaFalsiSolver0.getFunctionValueAccuracy();
        double double2 = regulaFalsiSolver0.getAbsoluteAccuracy();
        double double3 = regulaFalsiSolver0.getMin();
        int int4 = regulaFalsiSolver0.getEvaluations();
        double double5 = regulaFalsiSolver0.getMax();
        double double6 = regulaFalsiSolver0.getRelativeAccuracy();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction8 = null;
        try {
            double double12 = regulaFalsiSolver0.solve((-127), univariateRealFunction8, 0.0d, 0.0d, (double) 952841920);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0E-15d + "'", double1 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E-6d + "'", double2 == 1.0E-6d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0E-14d + "'", double6 == 1.0E-14d);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test028");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1;
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = localizedFormats0.getLocalizedString(locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1 + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test029");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) (-6404850697806645175L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test030");
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) 9.536743E-7f);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test031");
        int int2 = org.apache.commons.math.util.FastMath.max(2, (-49));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test032");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException(number0, (java.lang.Number) (byte) 0, true);
        java.lang.Number number4 = numberIsTooLargeException3.getArgument();
        java.lang.Number number5 = numberIsTooLargeException3.getMax();
        org.apache.commons.math.exception.MathInternalError mathInternalError6 = new org.apache.commons.math.exception.MathInternalError((java.lang.Throwable) numberIsTooLargeException3);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.AT_LEAST_ONE_COLUMN;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_PLUS_ONE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED;
        java.lang.Number number11 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] { (-1.0f), true };
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException15 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats10, number11, objArray14);
        java.lang.Object[] objArray16 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray14);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException17 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats8, (java.lang.Number) 1.5707963267948966d, objArray14);
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats19 = org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_ROOT_OF_UNITY_INDEX;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats20 = org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats22 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats27 = org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED;
        java.lang.Number number28 = null;
        java.lang.Object[] objArray31 = new java.lang.Object[] { (-1.0f), true };
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException32 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats27, number28, objArray31);
        java.lang.Object[] objArray33 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray31);
        org.apache.commons.math.exception.NoBracketingException noBracketingException34 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats22, (-1.7581226324091723d), 0.0d, (double) 0.99999994f, 5.298342365610589d, objArray33);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException35 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats20, (java.lang.Number) (-1.0f), objArray33);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException36 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats19, objArray33);
        java.lang.Object[] objArray37 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray33);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) localizedFormats8, localizable18, objArray33);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException39 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) mathInternalError6, (org.apache.commons.math.exception.util.Localizable) localizedFormats7, objArray33);
        java.lang.String str40 = mathInternalError6.toString();
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (byte) 0 + "'", number5.equals((byte) 0));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.AT_LEAST_ONE_COLUMN + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.AT_LEAST_ONE_COLUMN));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_PLUS_ONE + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_PLUS_ONE));
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED + "'", localizedFormats10.equals(org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertTrue("'" + localizedFormats19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_ROOT_OF_UNITY_INDEX + "'", localizedFormats19.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_ROOT_OF_UNITY_INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION + "'", localizedFormats20.equals(org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION));
        org.junit.Assert.assertTrue("'" + localizedFormats22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH + "'", localizedFormats22.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH));
        org.junit.Assert.assertTrue("'" + localizedFormats27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED + "'", localizedFormats27.equals(org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED));
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "org.apache.commons.math.exception.MathInternalError: internal error, please fill a bug report at https://issues.apache.org/jira/browse/MATH" + "'", str40.equals("org.apache.commons.math.exception.MathInternalError: internal error, please fill a bug report at https://issues.apache.org/jira/browse/MATH"));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test033");
        double[] doubleArray2 = new double[] { 10.0d, 0.0d };
        double[] doubleArray6 = new double[] { 1.7182818284590453d, (short) 10, '4' };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray6);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        boolean boolean11 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray6, orderDirection8, false, true);
        double[] doubleArray12 = new double[] {};
        double[] doubleArray17 = new double[] { 1.0E-15d, Double.NaN, 5.0d, (byte) 10 };
        double[] doubleArray22 = new double[] { 1.0E-15d, Double.NaN, 5.0d, (byte) 10 };
        double[] doubleArray27 = new double[] { 1.0E-15d, Double.NaN, 5.0d, (byte) 10 };
        double[] doubleArray32 = new double[] { 1.0E-15d, Double.NaN, 5.0d, (byte) 10 };
        double[][] doubleArray33 = new double[][] { doubleArray17, doubleArray22, doubleArray27, doubleArray32 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray12, doubleArray33);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray12);
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray12);
        java.lang.Class<?> wildcardClass37 = doubleArray12.getClass();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + orderDirection8 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection8.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(wildcardClass37);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test034");
        double double2 = org.apache.commons.math.util.MathUtils.round(54.598150033144236d, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 50.0d + "'", double2 == 50.0d);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test035");
        int[] intArray0 = null;
        int[] intArray1 = new int[] {};
        int[] intArray7 = new int[] { (byte) 1, 0, (byte) 10, 1, 0 };
        int[] intArray9 = org.apache.commons.math.util.MathUtils.copyOf(intArray7, (int) '4');
        int[] intArray15 = new int[] { (-1000602687), 10, 0, (short) 100, (short) 0 };
        double double16 = org.apache.commons.math.util.MathUtils.distance(intArray7, intArray15);
        int[] intArray22 = new int[] { (byte) 1, 0, (byte) 10, 1, 0 };
        int[] intArray24 = org.apache.commons.math.util.MathUtils.copyOf(intArray22, (int) '4');
        int int25 = org.apache.commons.math.util.MathUtils.distanceInf(intArray7, intArray22);
        int int26 = org.apache.commons.math.util.MathUtils.distance1(intArray1, intArray7);
        try {
            double double27 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.000602688000005E9d + "'", double16 == 1.000602688000005E9d);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test036");
        double[] doubleArray2 = new double[] { 10.0d, 0.0d };
        double[] doubleArray6 = new double[] { 1.7182818284590453d, (short) 10, '4' };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray6);
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray6, 10);
        int int10 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray6, 0);
        double[] doubleArray15 = new double[] { 10.0d, 0.0d };
        double[] doubleArray19 = new double[] { 1.7182818284590453d, (short) 10, '4' };
        boolean boolean20 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray15, doubleArray19);
        double[] doubleArray21 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray19);
        double double22 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray12, doubleArray19);
        double[] doubleArray25 = new double[] { 10.0d, 0.0d };
        double[] doubleArray29 = new double[] { 1.7182818284590453d, (short) 10, '4' };
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray25, doubleArray29);
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, (double) (short) 100);
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray25, 0);
        double double35 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray34);
        double[] doubleArray38 = new double[] { 10.0d, 0.0d };
        double[] doubleArray42 = new double[] { 1.7182818284590453d, (short) 10, '4' };
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray38, doubleArray42);
        double[] doubleArray45 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray38, (double) (short) 100);
        int int46 = org.apache.commons.math.util.MathUtils.hash(doubleArray38);
        double double47 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray34, doubleArray38);
        try {
            double double48 = org.apache.commons.math.util.MathUtils.distance1(doubleArray19, doubleArray34);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 147401637 + "'", int10 == 147401637);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1000602687) + "'", int46 == (-1000602687));
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test037");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 1222L, 0.17453292519943295d, (-97));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test038");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 29, 52L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 29L + "'", long2 == 29L);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test039");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((-1074790400), (-100));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1074790400 + "'", int2 == 1074790400);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test040");
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) 35.0d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test041");
        int int2 = org.apache.commons.math.util.MathUtils.pow(537919490, (long) 1075052544);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test042");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((float) 0L, (float) (-6404850697806645175L), (float) 52L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test043");
        org.apache.commons.math.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math.exception.NotPositiveException((java.lang.Number) 2813L);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test044");
        java.lang.Number number1 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 100, number1, 0, orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException5.getDirection();
        boolean boolean8 = nonMonotonousSequenceException5.getStrict();
        java.lang.Number number9 = nonMonotonousSequenceException5.getPrevious();
        int int10 = nonMonotonousSequenceException5.getIndex();
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertNull(orderDirection7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(number9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test045");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException2 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 50.0d, objArray1);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test046");
        int int1 = org.apache.commons.math.util.MathUtils.hash((-1.5607966601082315d));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1423250983 + "'", int1 == 1423250983);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test047");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(1.000602688000005E9d);
        int int2 = regulaFalsiSolver1.getMaxEvaluations();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test048");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round(28.0f, 60466176, (-48));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathIllegalArgumentException; message: invalid rounding method -48, valid methods: ROUND_CEILING (2), ROUND_DOWN (1), ROUND_FLOOR (3), ROUND_HALF_DOWN (5), ROUND_HALF_EVEN (6), ROUND_HALF_UP (4), ROUND_UNNECESSARY (7), ROUND_UP (0)");
        } catch (org.apache.commons.math.exception.MathIllegalArgumentException e) {
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test049");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE;
        java.lang.String str1 = localizedFormats0.getSourceString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "population limit has to be positive" + "'", str1.equals("population limit has to be positive"));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test050");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 22026.465794806718d, (java.lang.Number) 100, (int) (short) 1);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test051");
        int[] intArray5 = new int[] { (byte) 1, 0, (byte) 10, 1, 0 };
        int[] intArray7 = org.apache.commons.math.util.MathUtils.copyOf(intArray5, (int) '4');
        int[] intArray8 = org.apache.commons.math.util.MathUtils.copyOf(intArray5);
        int[] intArray14 = new int[] { (-537919489), 31, (short) 100, 2, 3 };
        int[] intArray15 = org.apache.commons.math.util.MathUtils.copyOf(intArray14);
        int[] intArray21 = new int[] { (byte) 1, 0, (byte) 10, 1, 0 };
        int[] intArray23 = org.apache.commons.math.util.MathUtils.copyOf(intArray21, (int) '4');
        int[] intArray29 = new int[] { (-1000602687), 10, 0, (short) 100, (short) 0 };
        double double30 = org.apache.commons.math.util.MathUtils.distance(intArray21, intArray29);
        int[] intArray36 = new int[] { (byte) 1, 0, (byte) 10, 1, 0 };
        int[] intArray38 = org.apache.commons.math.util.MathUtils.copyOf(intArray36, (int) '4');
        int int39 = org.apache.commons.math.util.MathUtils.distanceInf(intArray21, intArray36);
        int[] intArray40 = org.apache.commons.math.util.MathUtils.copyOf(intArray21);
        int[] intArray41 = org.apache.commons.math.util.MathUtils.copyOf(intArray40);
        int int42 = org.apache.commons.math.util.MathUtils.distanceInf(intArray15, intArray41);
        int[] intArray44 = org.apache.commons.math.util.MathUtils.copyOf(intArray15, 0);
        int[] intArray50 = new int[] { (byte) 1, 0, (byte) 10, 1, 0 };
        int[] intArray52 = org.apache.commons.math.util.MathUtils.copyOf(intArray50, (int) '4');
        int[] intArray58 = new int[] { (-1000602687), 10, 0, (short) 100, (short) 0 };
        double double59 = org.apache.commons.math.util.MathUtils.distance(intArray50, intArray58);
        int int60 = org.apache.commons.math.util.MathUtils.distance1(intArray15, intArray58);
        int int61 = org.apache.commons.math.util.MathUtils.distance1(intArray8, intArray15);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.000602688000005E9d + "'", double30 == 1.000602688000005E9d);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 537919490 + "'", int42 == 537919490);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 1.000602688000005E9d + "'", double59 == 1.000602688000005E9d);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 462683420 + "'", int60 == 462683420);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 537919615 + "'", int61 == 537919615);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test052");
        double[] doubleArray2 = new double[] { 10.0d, 0.0d };
        double[] doubleArray6 = new double[] { 1.7182818284590453d, (short) 10, '4' };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray6);
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) (short) 100);
        int int10 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) (short) -1);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray2);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats14 = org.apache.commons.math.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats20 = org.apache.commons.math.exception.util.LocalizedFormats.TOO_LARGE_CUTOFF_SINGULAR_VALUE;
        java.lang.Number number21 = null;
        double[] doubleArray22 = new double[] {};
        double[] doubleArray27 = new double[] { 1.0E-15d, Double.NaN, 5.0d, (byte) 10 };
        double[] doubleArray32 = new double[] { 1.0E-15d, Double.NaN, 5.0d, (byte) 10 };
        double[] doubleArray37 = new double[] { 1.0E-15d, Double.NaN, 5.0d, (byte) 10 };
        double[] doubleArray42 = new double[] { 1.0E-15d, Double.NaN, 5.0d, (byte) 10 };
        double[][] doubleArray43 = new double[][] { doubleArray27, doubleArray32, doubleArray37, doubleArray42 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray22, doubleArray43);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException45 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats20, number21, (java.lang.Object[]) doubleArray43);
        org.apache.commons.math.exception.NoBracketingException noBracketingException46 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats15, (double) 118608221, (double) 7.6293945E-6f, 0.0d, 34.99999999999999d, (java.lang.Object[]) doubleArray43);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException47 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats14, (java.lang.Object[]) doubleArray43);
        try {
            org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray2, doubleArray43);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 4 != 2");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1000602687) + "'", int10 == (-1000602687));
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + localizedFormats14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY + "'", localizedFormats14.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY));
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION + "'", localizedFormats15.equals(org.apache.commons.math.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION));
        org.junit.Assert.assertTrue("'" + localizedFormats20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TOO_LARGE_CUTOFF_SINGULAR_VALUE + "'", localizedFormats20.equals(org.apache.commons.math.exception.util.LocalizedFormats.TOO_LARGE_CUTOFF_SINGULAR_VALUE));
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test053");
        double double1 = org.apache.commons.math.util.FastMath.asinh((-6.999999523162842d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.644120693623669d) + "'", double1 == (-2.644120693623669d));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test054");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-1000602687), 35);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1312836799) + "'", int2 == (-1312836799));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test055");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, number1);
        boolean boolean3 = notStrictlyPositiveException2.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test056");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(35.0d, (double) 31);
        double double3 = regulaFalsiSolver2.getAbsoluteAccuracy();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 31.0d + "'", double3 == 31.0d);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test057");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((-1.0d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test058");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, 1.5707963526808657d, 3.6268604078471d, 0.9950547536867305d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test059");
        int int2 = org.apache.commons.math.util.FastMath.max((-118608221), (-48));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-48) + "'", int2 == (-48));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test060");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 97.0f);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 97L + "'", long1 == 97L);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test061");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) (-1.0f));
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException5 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, 1594323, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test062");
        float float2 = org.apache.commons.math.util.FastMath.max(52.0f, (float) (short) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 52.0f + "'", float2 == 52.0f);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test063");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, (double) 4.8801257E18f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test064");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED;
        java.lang.Number number8 = null;
        java.lang.Object[] objArray11 = new java.lang.Object[] { (-1.0f), true };
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException12 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats7, number8, objArray11);
        java.lang.Object[] objArray13 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray11);
        org.apache.commons.math.exception.NoBracketingException noBracketingException14 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, (-1.7581226324091723d), 0.0d, (double) 0.99999994f, 5.298342365610589d, objArray13);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException15 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) (-1.0f), objArray13);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException19 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) (-1000602687), (java.lang.Number) 300.0d, true);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(objArray13);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test065");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((float) 3, 0.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test066");
        float float2 = org.apache.commons.math.util.FastMath.scalb((float) 8978085206306062337L, 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 8.9780853E18f + "'", float2 == 8.9780853E18f);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test067");
        int int1 = org.apache.commons.math.util.FastMath.abs(462683420);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 462683420 + "'", int1 == 462683420);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test068");
        double double1 = org.apache.commons.math.util.FastMath.log((-1.0d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test069");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 1074790401L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0747904E9f + "'", float1 == 1.0747904E9f);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test070");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED;
        java.lang.Number number4 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] { (-1.0f), true };
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException8 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, number4, objArray7);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException9 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Number) 107L, objArray7);
        java.lang.Object[] objArray10 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray7);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException11 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 0.7250423179995003d, objArray7);
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED));
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(objArray10);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test071");
        java.lang.Number number1 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 100, number1, 0, orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getPrevious();
        java.lang.Number number7 = nonMonotonousSequenceException5.getArgument();
        org.apache.commons.math.exception.MathInternalError mathInternalError8 = new org.apache.commons.math.exception.MathInternalError((java.lang.Throwable) nonMonotonousSequenceException5);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext9 = mathInternalError8.getContext();
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 100 + "'", number7.equals(100));
        org.junit.Assert.assertNotNull(exceptionContext9);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test072");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver0 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        double double1 = regulaFalsiSolver0.getRelativeAccuracy();
        double double2 = regulaFalsiSolver0.getAbsoluteAccuracy();
        double double3 = regulaFalsiSolver0.getMin();
        int int4 = regulaFalsiSolver0.getMaxEvaluations();
        double double5 = regulaFalsiSolver0.getMax();
        double double6 = regulaFalsiSolver0.getFunctionValueAccuracy();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0E-14d + "'", double1 == 1.0E-14d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E-6d + "'", double2 == 1.0E-6d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0E-15d + "'", double6 == 1.0E-15d);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test073");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, 1073741824, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test074");
        float float1 = org.apache.commons.math.util.FastMath.nextUp((float) 952841920);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 9.5284198E8f + "'", float1 == 9.5284198E8f);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test075");
        org.apache.commons.math.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math.exception.TooManyEvaluationsException((java.lang.Number) 0.5403023058681398d);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.PERMUTATION_EXCEEDS_N;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.TOO_MUCH_CANCELLATION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ROUNDING_METHOD;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_SIZE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray11 = new java.lang.Object[] { "hi!", localizedFormats6, localizedFormats7, localizedFormats8, localizedFormats9, 10L };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException12 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, (java.lang.Number) 1.0f, objArray11);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext13 = maxCountExceededException12.getContext();
        exceptionContext13.setValue("org.apache.commons.math.exception.NumberIsTooLargeException: null is larger than the maximum (0)", (java.lang.Object) '4');
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats18 = org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_OBSERVED_POINTS_IN_SAMPLE;
        exceptionContext13.setValue("", (java.lang.Object) localizedFormats18);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats20 = org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED;
        java.lang.Number number22 = null;
        java.lang.Object[] objArray25 = new java.lang.Object[] { (-1.0f), true };
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException26 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats21, number22, objArray25);
        java.lang.Object[] objArray27 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray25);
        exceptionContext13.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats20, objArray25);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats29 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_COLUMNDIMENSION;
        java.lang.Number number30 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException33 = new org.apache.commons.math.exception.NumberIsTooLargeException(number30, (java.lang.Number) (byte) 0, true);
        java.lang.Number number34 = numberIsTooLargeException33.getArgument();
        java.lang.Number number35 = numberIsTooLargeException33.getMax();
        org.apache.commons.math.exception.MathInternalError mathInternalError36 = new org.apache.commons.math.exception.MathInternalError((java.lang.Throwable) numberIsTooLargeException33);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats37 = org.apache.commons.math.exception.util.LocalizedFormats.AT_LEAST_ONE_COLUMN;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats38 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_PLUS_ONE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats40 = org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED;
        java.lang.Number number41 = null;
        java.lang.Object[] objArray44 = new java.lang.Object[] { (-1.0f), true };
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException45 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats40, number41, objArray44);
        java.lang.Object[] objArray46 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray44);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException47 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats38, (java.lang.Number) 1.5707963267948966d, objArray44);
        org.apache.commons.math.exception.util.Localizable localizable48 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats49 = org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_ROOT_OF_UNITY_INDEX;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats50 = org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats52 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats57 = org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED;
        java.lang.Number number58 = null;
        java.lang.Object[] objArray61 = new java.lang.Object[] { (-1.0f), true };
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException62 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats57, number58, objArray61);
        java.lang.Object[] objArray63 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray61);
        org.apache.commons.math.exception.NoBracketingException noBracketingException64 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats52, (-1.7581226324091723d), 0.0d, (double) 0.99999994f, 5.298342365610589d, objArray63);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException65 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats50, (java.lang.Number) (-1.0f), objArray63);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException66 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats49, objArray63);
        java.lang.Object[] objArray67 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray63);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) localizedFormats38, localizable48, objArray63);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException69 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) mathInternalError36, (org.apache.commons.math.exception.util.Localizable) localizedFormats37, objArray63);
        exceptionContext13.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats29, objArray63);
        java.lang.Number number71 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats72 = org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_ROOT_OF_UNITY_INDEX;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats73 = org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats75 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats80 = org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED;
        java.lang.Number number81 = null;
        java.lang.Object[] objArray84 = new java.lang.Object[] { (-1.0f), true };
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException85 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats80, number81, objArray84);
        java.lang.Object[] objArray86 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray84);
        org.apache.commons.math.exception.NoBracketingException noBracketingException87 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats75, (-1.7581226324091723d), 0.0d, (double) 0.99999994f, 5.298342365610589d, objArray86);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException88 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats73, (java.lang.Number) (-1.0f), objArray86);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException89 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats72, objArray86);
        java.lang.Object[] objArray90 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray86);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException91 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats29, number71, objArray86);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException92 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) tooManyEvaluationsException1, (org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray86);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext93 = mathIllegalStateException92.getContext();
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.PERMUTATION_EXCEEDS_N + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.PERMUTATION_EXCEEDS_N));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TOO_MUCH_CANCELLATION + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.TOO_MUCH_CANCELLATION));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ROUNDING_METHOD + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ROUNDING_METHOD));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_SIZE + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_SIZE));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES + "'", localizedFormats9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(exceptionContext13);
        org.junit.Assert.assertTrue("'" + localizedFormats18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_OBSERVED_POINTS_IN_SAMPLE + "'", localizedFormats18.equals(org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_OBSERVED_POINTS_IN_SAMPLE));
        org.junit.Assert.assertTrue("'" + localizedFormats20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT + "'", localizedFormats20.equals(org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT));
        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED + "'", localizedFormats21.equals(org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED));
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertTrue("'" + localizedFormats29 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_COLUMNDIMENSION + "'", localizedFormats29.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_COLUMNDIMENSION));
        org.junit.Assert.assertNull(number34);
        org.junit.Assert.assertTrue("'" + number35 + "' != '" + (byte) 0 + "'", number35.equals((byte) 0));
        org.junit.Assert.assertTrue("'" + localizedFormats37 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.AT_LEAST_ONE_COLUMN + "'", localizedFormats37.equals(org.apache.commons.math.exception.util.LocalizedFormats.AT_LEAST_ONE_COLUMN));
        org.junit.Assert.assertTrue("'" + localizedFormats38 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_PLUS_ONE + "'", localizedFormats38.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_PLUS_ONE));
        org.junit.Assert.assertTrue("'" + localizedFormats40 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED + "'", localizedFormats40.equals(org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED));
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertNotNull(objArray46);
        org.junit.Assert.assertTrue("'" + localizedFormats49 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_ROOT_OF_UNITY_INDEX + "'", localizedFormats49.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_ROOT_OF_UNITY_INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats50 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION + "'", localizedFormats50.equals(org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION));
        org.junit.Assert.assertTrue("'" + localizedFormats52 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH + "'", localizedFormats52.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH));
        org.junit.Assert.assertTrue("'" + localizedFormats57 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED + "'", localizedFormats57.equals(org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED));
        org.junit.Assert.assertNotNull(objArray61);
        org.junit.Assert.assertNotNull(objArray63);
        org.junit.Assert.assertNotNull(objArray67);
        org.junit.Assert.assertTrue("'" + localizedFormats72 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_ROOT_OF_UNITY_INDEX + "'", localizedFormats72.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_ROOT_OF_UNITY_INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats73 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION + "'", localizedFormats73.equals(org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION));
        org.junit.Assert.assertTrue("'" + localizedFormats75 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH + "'", localizedFormats75.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH));
        org.junit.Assert.assertTrue("'" + localizedFormats80 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED + "'", localizedFormats80.equals(org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED));
        org.junit.Assert.assertNotNull(objArray84);
        org.junit.Assert.assertNotNull(objArray86);
        org.junit.Assert.assertNotNull(objArray90);
        org.junit.Assert.assertNotNull(exceptionContext93);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test076");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(4.0d, 1.5275028665387278d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test077");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 4.0d, (java.lang.Number) 1.9963110132772695d, 52);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        int int5 = nonMonotonousSequenceException3.getIndex();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 52 + "'", int5 == 52);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test078");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 6.1035156E9f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.785580062340824d + "'", double1 == 9.785580062340824d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test079");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(3.6268604078471d, 1.0E-6d, (double) 118608231);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test080");
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math.exception.DimensionMismatchException(118608231, 35);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test081");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) Double.NaN, (java.lang.Number) 2.4414062E-4f, true);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test082");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(0L, 29L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test083");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.5403023058681398d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8144772166995121d + "'", double1 == 0.8144772166995121d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test084");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.TOO_MUCH_CANCELLATION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ROUNDING_METHOD;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_SIZE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray8 = new java.lang.Object[] { "hi!", localizedFormats3, localizedFormats4, localizedFormats5, localizedFormats6, 10L };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException9 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1.0f, objArray8);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext10 = maxCountExceededException9.getContext();
        java.util.Set<java.lang.String> strSet11 = exceptionContext10.getKeys();
        java.lang.Object obj13 = exceptionContext10.getValue("org.apache.commons.math.exception.MaxCountExceededException: illegal state: maximal count (10,230) exceeded");
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TOO_MUCH_CANCELLATION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.TOO_MUCH_CANCELLATION));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ROUNDING_METHOD + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ROUNDING_METHOD));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_SIZE + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_SIZE));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(exceptionContext10);
        org.junit.Assert.assertNotNull(strSet11);
        org.junit.Assert.assertNull(obj13);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test085");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyBracketing(univariateRealFunction0, (double) (-118608221), 0.7250423179995003d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test086");
        double[] doubleArray0 = null;
        try {
            double[] doubleArray1 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test087");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(1.1920929665620834E-7d, 0.7250423179995003d);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test088");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(1074790400);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test089");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(0L, (long) 2704);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test090");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver0 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        double double1 = regulaFalsiSolver0.getFunctionValueAccuracy();
        double double2 = regulaFalsiSolver0.getAbsoluteAccuracy();
        double double3 = regulaFalsiSolver0.getMin();
        int int4 = regulaFalsiSolver0.getEvaluations();
        double double5 = regulaFalsiSolver0.getStartValue();
        double double6 = regulaFalsiSolver0.getFunctionValueAccuracy();
        double double7 = regulaFalsiSolver0.getStartValue();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction9 = null;
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution12 = org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE;
        try {
            double double13 = regulaFalsiSolver0.solve(1163694305, univariateRealFunction9, 3.6268604078470186d, 0.047442967903742035d, allowedSolution12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0E-15d + "'", double1 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E-6d + "'", double2 == 1.0E-6d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0E-15d + "'", double6 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + allowedSolution12 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE + "'", allowedSolution12.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test091");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_REAL_VECTOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_ENOUGH_POINTS_IN_SPLINE_PARTITION;
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException4 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Number) 1.5707963267948966d, objArray3);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED;
        java.lang.Number number8 = null;
        java.lang.Object[] objArray11 = new java.lang.Object[] { (-1.0f), true };
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException12 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats7, number8, objArray11);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException13 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 2L, objArray11);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException14 = new org.apache.commons.math.exception.MathArithmeticException(localizable5, objArray11);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) localizedFormats0, (org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray11);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException17 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Number) 1.0E-5d);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_REAL_VECTOR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_REAL_VECTOR));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_ENOUGH_POINTS_IN_SPLINE_PARTITION + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_ENOUGH_POINTS_IN_SPLINE_PARTITION));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED));
        org.junit.Assert.assertNotNull(objArray11);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test092");
        double[] doubleArray2 = new double[] { 10.0d, 0.0d };
        double[] doubleArray6 = new double[] { 1.7182818284590453d, (short) 10, '4' };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray6);
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) (short) 100);
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2, 0);
        int int12 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math.exception.util.LocalizedFormats.TOO_LARGE_CUTOFF_SINGULAR_VALUE;
        java.lang.Number number14 = null;
        double[] doubleArray15 = new double[] {};
        double[] doubleArray20 = new double[] { 1.0E-15d, Double.NaN, 5.0d, (byte) 10 };
        double[] doubleArray25 = new double[] { 1.0E-15d, Double.NaN, 5.0d, (byte) 10 };
        double[] doubleArray30 = new double[] { 1.0E-15d, Double.NaN, 5.0d, (byte) 10 };
        double[] doubleArray35 = new double[] { 1.0E-15d, Double.NaN, 5.0d, (byte) 10 };
        double[][] doubleArray36 = new double[][] { doubleArray20, doubleArray25, doubleArray30, doubleArray35 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray15, doubleArray36);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException38 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats13, number14, (java.lang.Object[]) doubleArray36);
        try {
            org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray2, doubleArray36);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 4 != 2");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1000602687) + "'", int12 == (-1000602687));
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TOO_LARGE_CUTOFF_SINGULAR_VALUE + "'", localizedFormats13.equals(org.apache.commons.math.exception.util.LocalizedFormats.TOO_LARGE_CUTOFF_SINGULAR_VALUE));
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test093");
        float float2 = org.apache.commons.math.util.FastMath.max(28.0f, (float) '4');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 52.0f + "'", float2 == 52.0f);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test094");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(2813L, (long) 52);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2865L + "'", long2 == 2865L);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test095");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 118608231);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 18.59133644346881d + "'", double1 == 18.59133644346881d);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test096");
        double double2 = org.apache.commons.math.util.FastMath.IEEEremainder((-0.017453292519943295d), 1225.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.017453292519943295d) + "'", double2 == (-0.017453292519943295d));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test097");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) (-1072));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6570547737201031d + "'", double1 == 0.6570547737201031d);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test098");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.setMaximalCount(184);
        incrementor0.setMaximalCount(97);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test099");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray5 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, 0.2532797083404758d, (double) 107L, (-1.9999999999999998d), 1594323);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test100");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.TOO_MUCH_CANCELLATION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ROUNDING_METHOD;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_SIZE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray13 = new java.lang.Object[] { "hi!", localizedFormats8, localizedFormats9, localizedFormats10, localizedFormats11, 10L };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException14 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, (java.lang.Number) 1.0f, objArray13);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext15 = maxCountExceededException14.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats17 = org.apache.commons.math.exception.util.LocalizedFormats.ROTATION_MATRIX_DIMENSIONS;
        exceptionContext15.setValue("", (java.lang.Object) localizedFormats17);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats19 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_0_FOR_SOME_ALPHA;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats20 = org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats22 = org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats23 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX;
        java.lang.Object[] objArray24 = new java.lang.Object[] { localizedFormats20, 6.50349243853352d, localizedFormats22, localizedFormats23 };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException25 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats19, objArray24);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats26 = org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED;
        java.lang.Number number27 = null;
        java.lang.Object[] objArray30 = new java.lang.Object[] { (-1.0f), true };
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException31 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats26, number27, objArray30);
        java.lang.Object[] objArray32 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray30);
        exceptionContext15.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats19, objArray30);
        java.lang.Object[] objArray34 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray30);
        org.apache.commons.math.exception.NoBracketingException noBracketingException35 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, 10.0d, 6.283185307179586d, 3.141592653589793d, 1.0070326031835695E19d, objArray34);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TOO_MUCH_CANCELLATION + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.TOO_MUCH_CANCELLATION));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ROUNDING_METHOD + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ROUNDING_METHOD));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_SIZE + "'", localizedFormats9.equals(org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_SIZE));
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats10.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES + "'", localizedFormats11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(exceptionContext15);
        org.junit.Assert.assertTrue("'" + localizedFormats17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ROTATION_MATRIX_DIMENSIONS + "'", localizedFormats17.equals(org.apache.commons.math.exception.util.LocalizedFormats.ROTATION_MATRIX_DIMENSIONS));
        org.junit.Assert.assertTrue("'" + localizedFormats19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_0_FOR_SOME_ALPHA + "'", localizedFormats19.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_0_FOR_SOME_ALPHA));
        org.junit.Assert.assertTrue("'" + localizedFormats20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX_OUT_OF_RANGE + "'", localizedFormats20.equals(org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizedFormats22.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + localizedFormats23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX + "'", localizedFormats23.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX));
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertTrue("'" + localizedFormats26 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED + "'", localizedFormats26.equals(org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED));
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(objArray34);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test101");
        int[] intArray0 = null;
        int[] intArray6 = new int[] { (byte) 1, 0, (byte) 10, 1, 0 };
        int[] intArray8 = org.apache.commons.math.util.MathUtils.copyOf(intArray6, (int) '4');
        int[] intArray14 = new int[] { (-1000602687), 10, 0, (short) 100, (short) 0 };
        double double15 = org.apache.commons.math.util.MathUtils.distance(intArray6, intArray14);
        try {
            double double16 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.000602688000005E9d + "'", double15 == 1.000602688000005E9d);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test102");
        double double1 = org.apache.commons.math.util.FastMath.tanh(3.4965075614664802d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.998165137614679d + "'", double1 == 0.998165137614679d);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test103");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 4.0d, (java.lang.Number) 1.9963110132772695d, 52);
        int int4 = nonMonotonousSequenceException3.getIndex();
        java.lang.String str5 = nonMonotonousSequenceException3.toString();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 52 + "'", int4 == 52);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 51 and 52 are not strictly increasing (1.996 >= 4)" + "'", str5.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 51 and 52 are not strictly increasing (1.996 >= 4)"));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test104");
        double double2 = org.apache.commons.math.util.FastMath.min(1.5707963267948966d, 5.3791949E8d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test105");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1073741824, (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test106");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((float) '4', (float) 720L, 132);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test107");
        double double1 = org.apache.commons.math.util.FastMath.log10(1225.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0881360887005513d + "'", double1 == 3.0881360887005513d);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test108");
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) 1225L);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test109");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 1300, (-107555460478L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-107555459178L) + "'", long2 == (-107555459178L));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test110");
        float float2 = org.apache.commons.math.util.FastMath.copySign((float) 1302087493, (float) 952841907);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.30208755E9f + "'", float2 == 1.30208755E9f);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test111");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray5 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, 0.0d, 10231.0d, 1.3440585709080678E43d, (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test112");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) (-8.2674572E18f), 1225.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.NEGATIVE_INFINITY + "'", double2 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test113");
        double[] doubleArray2 = new double[] { 10.0d, 0.0d };
        double[] doubleArray6 = new double[] { 1.7182818284590453d, (short) 10, '4' };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray6);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        boolean boolean11 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray6, orderDirection8, false, true);
        double[] doubleArray12 = new double[] {};
        double[] doubleArray17 = new double[] { 1.0E-15d, Double.NaN, 5.0d, (byte) 10 };
        double[] doubleArray22 = new double[] { 1.0E-15d, Double.NaN, 5.0d, (byte) 10 };
        double[] doubleArray27 = new double[] { 1.0E-15d, Double.NaN, 5.0d, (byte) 10 };
        double[] doubleArray32 = new double[] { 1.0E-15d, Double.NaN, 5.0d, (byte) 10 };
        double[][] doubleArray33 = new double[][] { doubleArray17, doubleArray22, doubleArray27, doubleArray32 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray12, doubleArray33);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray12);
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray12);
        double[] doubleArray38 = new double[] { 10 };
        double[] doubleArray43 = new double[] { 3.4965075614664802d, (-1), (byte) 1, 100 };
        double double44 = org.apache.commons.math.util.MathUtils.distance(doubleArray38, doubleArray43);
        double[] doubleArray46 = new double[] { 10 };
        double[] doubleArray51 = new double[] { 3.4965075614664802d, (-1), (byte) 1, 100 };
        double double52 = org.apache.commons.math.util.MathUtils.distance(doubleArray46, doubleArray51);
        double[] doubleArray55 = new double[] { 10.0d, 0.0d };
        double[] doubleArray59 = new double[] { 1.7182818284590453d, (short) 10, '4' };
        boolean boolean60 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray55, doubleArray59);
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equals(doubleArray46, doubleArray55);
        int int62 = org.apache.commons.math.util.MathUtils.hash(doubleArray55);
        double double63 = org.apache.commons.math.util.MathUtils.distance(doubleArray38, doubleArray55);
        boolean boolean64 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + orderDirection8 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection8.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 6.50349243853352d + "'", double44 == 6.50349243853352d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 6.50349243853352d + "'", double52 == 6.50349243853352d);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + (-1000602687) + "'", int62 == (-1000602687));
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test114");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(710366363, (-1023));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test115");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(0.6610060414837631d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7102040865618037d + "'", double1 == 0.7102040865618037d);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test116");
        double double1 = org.apache.commons.math.util.FastMath.acosh(61035.156480000005d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11.712352493368334d + "'", double1 == 11.712352493368334d);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test117");
        double[] doubleArray2 = new double[] { 10.0d, 0.0d };
        double[] doubleArray6 = new double[] { 1.7182818284590453d, (short) 10, '4' };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray6);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray6);
        double[] doubleArray10 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray6, (int) (short) 10);
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray6);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        double[] doubleArray14 = new double[] { 10 };
        double[] doubleArray19 = new double[] { 3.4965075614664802d, (-1), (byte) 1, 100 };
        double double20 = org.apache.commons.math.util.MathUtils.distance(doubleArray14, doubleArray19);
        double[] doubleArray23 = new double[] { 10.0d, 0.0d };
        double[] doubleArray27 = new double[] { 1.7182818284590453d, (short) 10, '4' };
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray23, doubleArray27);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection29 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        boolean boolean32 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray27, orderDirection29, false, true);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats33 = org.apache.commons.math.exception.util.LocalizedFormats.TOO_LARGE_CUTOFF_SINGULAR_VALUE;
        java.lang.Number number34 = null;
        double[] doubleArray35 = new double[] {};
        double[] doubleArray40 = new double[] { 1.0E-15d, Double.NaN, 5.0d, (byte) 10 };
        double[] doubleArray45 = new double[] { 1.0E-15d, Double.NaN, 5.0d, (byte) 10 };
        double[] doubleArray50 = new double[] { 1.0E-15d, Double.NaN, 5.0d, (byte) 10 };
        double[] doubleArray55 = new double[] { 1.0E-15d, Double.NaN, 5.0d, (byte) 10 };
        double[][] doubleArray56 = new double[][] { doubleArray40, doubleArray45, doubleArray50, doubleArray55 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray35, doubleArray56);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException58 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats33, number34, (java.lang.Object[]) doubleArray56);
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray19, orderDirection29, doubleArray56);
        java.lang.Class<?> wildcardClass60 = doubleArray56.getClass();
        try {
            org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray6, orderDirection12, doubleArray56);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 4 != 3");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 6.50349243853352d + "'", double20 == 6.50349243853352d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + orderDirection29 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection29.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + localizedFormats33 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TOO_LARGE_CUTOFF_SINGULAR_VALUE + "'", localizedFormats33.equals(org.apache.commons.math.exception.util.LocalizedFormats.TOO_LARGE_CUTOFF_SINGULAR_VALUE));
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(wildcardClass60);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test118");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 537919490);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test119");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray5 = new double[] { 1.0E-15d, Double.NaN, 5.0d, (byte) 10 };
        double[] doubleArray10 = new double[] { 1.0E-15d, Double.NaN, 5.0d, (byte) 10 };
        double[] doubleArray15 = new double[] { 1.0E-15d, Double.NaN, 5.0d, (byte) 10 };
        double[] doubleArray20 = new double[] { 1.0E-15d, Double.NaN, 5.0d, (byte) 10 };
        double[][] doubleArray21 = new double[][] { doubleArray5, doubleArray10, doubleArray15, doubleArray20 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray0, doubleArray21);
        double[] doubleArray25 = new double[] { 10.0d, 0.0d };
        double[] doubleArray29 = new double[] { 1.7182818284590453d, (short) 10, '4' };
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray25, doubleArray29);
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, (double) (short) 100);
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray25, 0);
        double double35 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray34);
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray34);
        double double37 = org.apache.commons.math.util.MathUtils.distance1(doubleArray0, doubleArray34);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test120");
        int int1 = org.apache.commons.math.util.MathUtils.sign((-1023));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test121");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.7250423179995003d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.012654375665383025d + "'", double1 == 0.012654375665383025d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test122");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(1.5860134523134298E15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.58601345231343E15d + "'", double1 == 1.58601345231343E15d);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test123");
        float[] floatArray0 = new float[] {};
        float[] floatArray3 = new float[] { (short) 100, (-100) };
        float[] floatArray7 = new float[] { 1L, (byte) 100, 1 };
        float[] floatArray12 = new float[] { 100, (short) -1, (byte) 100, 'a' };
        float[] floatArray19 = new float[] { 'a', (-1L), 100, (-1L), 100L, (-1L) };
        boolean boolean20 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray12, floatArray19);
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equals(floatArray7, floatArray19);
        float[] floatArray25 = new float[] { 1L, (byte) 100, 1 };
        float[] floatArray30 = new float[] { 100, (short) -1, (byte) 100, 'a' };
        float[] floatArray37 = new float[] { 'a', (-1L), 100, (-1L), 100L, (-1L) };
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray30, floatArray37);
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equals(floatArray25, floatArray37);
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equals(floatArray19, floatArray37);
        boolean boolean41 = org.apache.commons.math.util.MathUtils.equals(floatArray3, floatArray19);
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray0, floatArray3);
        float[] floatArray45 = new float[] { 2, 2.0f };
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equals(floatArray3, floatArray45);
        org.junit.Assert.assertNotNull(floatArray0);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(floatArray37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(floatArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test124");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((-28L), (long) (byte) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 140L + "'", long2 == 140L);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test125");
        double double2 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.midpoint((double) (byte) -1, 58613.58244188321d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 29306.291220941606d + "'", double2 == 29306.291220941606d);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test126");
        double double1 = org.apache.commons.math.util.FastMath.atan(2.0634370688955608d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1195215262618592d + "'", double1 == 1.1195215262618592d);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test127");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(35.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.930067261567154E14d + "'", double1 == 7.930067261567154E14d);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test128");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_PLUS_ONE;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (int) ' ', (int) (byte) 0);
        java.lang.Number number4 = dimensionMismatchException3.getArgument();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_PLUS_ONE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_PLUS_ONE));
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 32 + "'", number4.equals(32));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test129");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_0_FOR_SOME_ALPHA;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX;
        java.lang.Object[] objArray5 = new java.lang.Object[] { localizedFormats1, 6.50349243853352d, localizedFormats3, localizedFormats4 };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException6 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray5);
        java.lang.Class<?> wildcardClass7 = localizedFormats0.getClass();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_0_FOR_SOME_ALPHA + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_0_FOR_SOME_ALPHA));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX_OUT_OF_RANGE + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test130");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver0 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        double double1 = regulaFalsiSolver0.getFunctionValueAccuracy();
        double double2 = regulaFalsiSolver0.getStartValue();
        double double3 = regulaFalsiSolver0.getRelativeAccuracy();
        double double4 = regulaFalsiSolver0.getStartValue();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0E-15d + "'", double1 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E-14d + "'", double3 == 1.0E-14d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test131");
        double[] doubleArray0 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.TOO_LARGE_CUTOFF_SINGULAR_VALUE;
        java.lang.Number number2 = null;
        double[] doubleArray3 = new double[] {};
        double[] doubleArray8 = new double[] { 1.0E-15d, Double.NaN, 5.0d, (byte) 10 };
        double[] doubleArray13 = new double[] { 1.0E-15d, Double.NaN, 5.0d, (byte) 10 };
        double[] doubleArray18 = new double[] { 1.0E-15d, Double.NaN, 5.0d, (byte) 10 };
        double[] doubleArray23 = new double[] { 1.0E-15d, Double.NaN, 5.0d, (byte) 10 };
        double[][] doubleArray24 = new double[][] { doubleArray8, doubleArray13, doubleArray18, doubleArray23 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray3, doubleArray24);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException26 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, number2, (java.lang.Object[]) doubleArray24);
        try {
            org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray0, doubleArray24);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TOO_LARGE_CUTOFF_SINGULAR_VALUE + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.TOO_LARGE_CUTOFF_SINGULAR_VALUE));
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test132");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.resetCount();
        incrementor0.incrementCount((int) (byte) -1);
        int int4 = incrementor0.getCount();
        incrementor0.incrementCount((int) (short) 0);
        incrementor0.setMaximalCount(1079574528);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test133");
        double double3 = org.apache.commons.math.util.MathUtils.reduce(0.0d, 0.7102040865618037d, 0.998165137614679d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.4222430355089284d + "'", double3 == 0.4222430355089284d);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test134");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ASSYMETRIC_EIGEN_NOT_SUPPORTED;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (-1074790401), 0);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ASSYMETRIC_EIGEN_NOT_SUPPORTED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ASSYMETRIC_EIGEN_NOT_SUPPORTED));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test135");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray5 = new double[] { 1.0E-15d, Double.NaN, 5.0d, (byte) 10 };
        double[] doubleArray10 = new double[] { 1.0E-15d, Double.NaN, 5.0d, (byte) 10 };
        double[] doubleArray15 = new double[] { 1.0E-15d, Double.NaN, 5.0d, (byte) 10 };
        double[] doubleArray20 = new double[] { 1.0E-15d, Double.NaN, 5.0d, (byte) 10 };
        double[][] doubleArray21 = new double[][] { doubleArray5, doubleArray10, doubleArray15, doubleArray20 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray0, doubleArray21);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray0);
        double[] doubleArray26 = new double[] { 10.0d, 0.0d };
        double[] doubleArray30 = new double[] { 1.7182818284590453d, (short) 10, '4' };
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray26, doubleArray30);
        double[] doubleArray33 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, (double) (short) 100);
        double[] doubleArray35 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray26, 0);
        double double36 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray35);
        double[] doubleArray39 = new double[] { 10.0d, 0.0d };
        double[] doubleArray43 = new double[] { 1.7182818284590453d, (short) 10, '4' };
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray39, doubleArray43);
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray39, (double) (short) 100);
        int int47 = org.apache.commons.math.util.MathUtils.hash(doubleArray39);
        double double48 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray35, doubleArray39);
        int int49 = org.apache.commons.math.util.MathUtils.hash(doubleArray39);
        double double50 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray39);
        double[] doubleArray51 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1000602687) + "'", int47 == (-1000602687));
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1000602687) + "'", int49 == (-1000602687));
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray51);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test136");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_INCREASING_NUMBER_OF_POINTS;
        org.apache.commons.math.exception.NoBracketingException noBracketingException9 = new org.apache.commons.math.exception.NoBracketingException((double) (short) 10, 97.0d, (double) 4, (double) 107L);
        org.apache.commons.math.exception.NotPositiveException notPositiveException11 = new org.apache.commons.math.exception.NotPositiveException((java.lang.Number) (-0.0d));
        noBracketingException9.addSuppressed((java.lang.Throwable) notPositiveException11);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats14 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_PLUS_ONE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED;
        java.lang.Number number17 = null;
        java.lang.Object[] objArray20 = new java.lang.Object[] { (-1.0f), true };
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException21 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats16, number17, objArray20);
        java.lang.Object[] objArray22 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray20);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException23 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats14, (java.lang.Number) 1.5707963267948966d, objArray20);
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats25 = org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_ROOT_OF_UNITY_INDEX;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats26 = org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats28 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats33 = org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED;
        java.lang.Number number34 = null;
        java.lang.Object[] objArray37 = new java.lang.Object[] { (-1.0f), true };
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException38 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats33, number34, objArray37);
        java.lang.Object[] objArray39 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray37);
        org.apache.commons.math.exception.NoBracketingException noBracketingException40 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats28, (-1.7581226324091723d), 0.0d, (double) 0.99999994f, 5.298342365610589d, objArray39);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException41 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats26, (java.lang.Number) (-1.0f), objArray39);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException42 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats25, objArray39);
        java.lang.Object[] objArray43 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray39);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) localizedFormats14, localizable24, objArray39);
        java.lang.Object[] objArray45 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray39);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException46 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) notPositiveException11, (org.apache.commons.math.exception.util.Localizable) localizedFormats13, objArray39);
        org.apache.commons.math.exception.NoBracketingException noBracketingException47 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (double) 2L, (-5.37919489E8d), 0.9950547536867305d, 1.3440585709080678E43d, objArray39);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_INCREASING_NUMBER_OF_POINTS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_INCREASING_NUMBER_OF_POINTS));
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO + "'", localizedFormats13.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO));
        org.junit.Assert.assertTrue("'" + localizedFormats14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_PLUS_ONE + "'", localizedFormats14.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_PLUS_ONE));
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED + "'", localizedFormats16.equals(org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED));
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertTrue("'" + localizedFormats25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_ROOT_OF_UNITY_INDEX + "'", localizedFormats25.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_ROOT_OF_UNITY_INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats26 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION + "'", localizedFormats26.equals(org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION));
        org.junit.Assert.assertTrue("'" + localizedFormats28 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH + "'", localizedFormats28.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH));
        org.junit.Assert.assertTrue("'" + localizedFormats33 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED + "'", localizedFormats33.equals(org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED));
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertNotNull(objArray43);
        org.junit.Assert.assertNotNull(objArray45);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test137");
        double double1 = org.apache.commons.math.util.FastMath.sinh(11013.232874703393d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test138");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_SUBSTITUTE_ELEMENT_FROM_EMPTY_ARRAY;
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException2 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray1);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext3 = mathArithmeticException2.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_UPPER_BOUND;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.FAILED_BRACKETING;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SAMPLE_SIZE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_PLUS_ONE;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException10 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats7, (int) ' ', (int) (byte) 0);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math.exception.util.LocalizedFormats.NO_REGRESSORS;
        java.lang.Number number12 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException15 = new org.apache.commons.math.exception.NumberIsTooLargeException(number12, (java.lang.Number) (byte) 0, true);
        java.lang.Number number16 = numberIsTooLargeException15.getArgument();
        java.lang.Number number17 = numberIsTooLargeException15.getMax();
        org.apache.commons.math.exception.MathInternalError mathInternalError18 = new org.apache.commons.math.exception.MathInternalError((java.lang.Throwable) numberIsTooLargeException15);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats19 = org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats20 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_SET_AT_NEGATIVE_INDEX;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats25 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_PLUS_ONE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats27 = org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED;
        java.lang.Number number28 = null;
        java.lang.Object[] objArray31 = new java.lang.Object[] { (-1.0f), true };
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException32 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats27, number28, objArray31);
        java.lang.Object[] objArray33 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray31);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException34 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats25, (java.lang.Number) 1.5707963267948966d, objArray31);
        org.apache.commons.math.exception.NoBracketingException noBracketingException35 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats20, (double) 100, Double.NEGATIVE_INFINITY, 0.8414709848078965d, 2.0d, objArray31);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException36 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) mathInternalError18, (org.apache.commons.math.exception.util.Localizable) localizedFormats19, objArray31);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException37 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) dimensionMismatchException10, (org.apache.commons.math.exception.util.Localizable) localizedFormats11, objArray31);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) localizedFormats5, (org.apache.commons.math.exception.util.Localizable) localizedFormats6, objArray31);
        java.lang.Number number39 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException42 = new org.apache.commons.math.exception.NumberIsTooLargeException(number39, (java.lang.Number) (byte) 0, true);
        java.lang.Number number43 = numberIsTooLargeException42.getArgument();
        java.lang.Number number44 = numberIsTooLargeException42.getMax();
        org.apache.commons.math.exception.MathInternalError mathInternalError45 = new org.apache.commons.math.exception.MathInternalError((java.lang.Throwable) numberIsTooLargeException42);
        java.lang.Throwable[] throwableArray46 = mathInternalError45.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException47 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats6, (java.lang.Object[]) throwableArray46);
        exceptionContext3.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats4, (java.lang.Object[]) throwableArray46);
        java.util.Set<java.lang.String> strSet49 = exceptionContext3.getKeys();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_SUBSTITUTE_ELEMENT_FROM_EMPTY_ARRAY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_SUBSTITUTE_ELEMENT_FROM_EMPTY_ARRAY));
        org.junit.Assert.assertNotNull(exceptionContext3);
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_UPPER_BOUND + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_UPPER_BOUND));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FAILED_BRACKETING + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.FAILED_BRACKETING));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SAMPLE_SIZE + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SAMPLE_SIZE));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_PLUS_ONE + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_PLUS_ONE));
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_REGRESSORS + "'", localizedFormats11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_REGRESSORS));
        org.junit.Assert.assertNull(number16);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + (byte) 0 + "'", number17.equals((byte) 0));
        org.junit.Assert.assertTrue("'" + localizedFormats19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizedFormats19.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizedFormats20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_SET_AT_NEGATIVE_INDEX + "'", localizedFormats20.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_SET_AT_NEGATIVE_INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_PLUS_ONE + "'", localizedFormats25.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_PLUS_ONE));
        org.junit.Assert.assertTrue("'" + localizedFormats27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED + "'", localizedFormats27.equals(org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED));
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertNull(number43);
        org.junit.Assert.assertTrue("'" + number44 + "' != '" + (byte) 0 + "'", number44.equals((byte) 0));
        org.junit.Assert.assertNotNull(throwableArray46);
        org.junit.Assert.assertNotNull(strSet49);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test139");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) 720L, 28.0f, (float) 3);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test140");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_REAL_VECTOR;
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException2 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray1);
        java.lang.Number number3 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException4 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, number3);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_REAL_VECTOR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_REAL_VECTOR));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test141");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test142");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException((double) (short) 10, 97.0d, (double) 4, (double) 107L);
        double double5 = noBracketingException4.getLo();
        double double6 = noBracketingException4.getFHi();
        double double7 = noBracketingException4.getFHi();
        double double8 = noBracketingException4.getLo();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 10.0d + "'", double5 == 10.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 107.0d + "'", double6 == 107.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 107.0d + "'", double7 == 107.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 10.0d + "'", double8 == 10.0d);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test143");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.FAILED_BRACKETING;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 2.5091784592555326d, (java.lang.Number) 952841907, false);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_TRANSFORM_TO_DOUBLE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_ROOT_OF_UNITY_INDEX;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats20 = org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED;
        java.lang.Number number21 = null;
        java.lang.Object[] objArray24 = new java.lang.Object[] { (-1.0f), true };
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException25 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats20, number21, objArray24);
        java.lang.Object[] objArray26 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray24);
        org.apache.commons.math.exception.NoBracketingException noBracketingException27 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats15, (-1.7581226324091723d), 0.0d, (double) 0.99999994f, 5.298342365610589d, objArray26);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException28 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats13, (java.lang.Number) (-1.0f), objArray26);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException29 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats12, objArray26);
        org.apache.commons.math.exception.NoBracketingException noBracketingException30 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats7, 1.9963110132772695d, (double) (-49), (double) (-1023), 1.0E-15d, objArray26);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException31 = new org.apache.commons.math.exception.MaxCountExceededException(localizable5, (java.lang.Number) (-1074790400), objArray26);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException32 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray26);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FAILED_BRACKETING + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.FAILED_BRACKETING));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_TRANSFORM_TO_DOUBLE + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_TRANSFORM_TO_DOUBLE));
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_ROOT_OF_UNITY_INDEX + "'", localizedFormats12.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_ROOT_OF_UNITY_INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION + "'", localizedFormats13.equals(org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION));
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH + "'", localizedFormats15.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH));
        org.junit.Assert.assertTrue("'" + localizedFormats20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED + "'", localizedFormats20.equals(org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED));
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(objArray26);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test144");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.EXPANSION_FACTOR_SMALLER_THAN_ONE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_PLUS_ONE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED;
        java.lang.Number number4 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] { (-1.0f), true };
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException8 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, number4, objArray7);
        java.lang.Object[] objArray9 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray7);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException10 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Number) 1.5707963267948966d, objArray7);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException11 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray7);
        java.lang.String str12 = localizedFormats0.getSourceString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EXPANSION_FACTOR_SMALLER_THAN_ONE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.EXPANSION_FACTOR_SMALLER_THAN_ONE));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_PLUS_ONE + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_PLUS_ONE));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED));
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "expansion factor smaller than one ({0})" + "'", str12.equals("expansion factor smaller than one ({0})"));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test145");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        try {
            java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (-1072));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: exponent (-1,072)");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger2);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test146");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((-1074790401));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: must have n >= 0 for n!, got n = -1,074,790,401");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test147");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double double4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(univariateRealFunction0, (double) 537919615, (-0.6536436208636119d), 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test148");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 60466176, (float) 107L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 6.0466176E7f + "'", float2 == 6.0466176E7f);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test149");
        double[] doubleArray2 = new double[] { 10.0d, 0.0d };
        double[] doubleArray6 = new double[] { 1.7182818284590453d, (short) 10, '4' };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray6);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray6);
        double[] doubleArray10 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray6, (int) (short) 10);
        double[] doubleArray16 = new double[] { 10.0d, 0.0d };
        double[] doubleArray20 = new double[] { 1.7182818284590453d, (short) 10, '4' };
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray16, doubleArray20);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection22 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        boolean boolean25 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray20, orderDirection22, false, true);
        double[] doubleArray26 = new double[] {};
        double[] doubleArray31 = new double[] { 1.0E-15d, Double.NaN, 5.0d, (byte) 10 };
        double[] doubleArray36 = new double[] { 1.0E-15d, Double.NaN, 5.0d, (byte) 10 };
        double[] doubleArray41 = new double[] { 1.0E-15d, Double.NaN, 5.0d, (byte) 10 };
        double[] doubleArray46 = new double[] { 1.0E-15d, Double.NaN, 5.0d, (byte) 10 };
        double[][] doubleArray47 = new double[][] { doubleArray31, doubleArray36, doubleArray41, doubleArray46 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray26, doubleArray47);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray26);
        boolean boolean50 = org.apache.commons.math.util.MathUtils.equals(doubleArray20, doubleArray26);
        double double51 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray20);
        double[] doubleArray54 = new double[] { 1.0986122886681098d, 5.298342365610589d };
        double[] doubleArray56 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray54, (-307.6526555685888d));
        double[] doubleArray59 = new double[] { 10.0d, 0.0d };
        double[] doubleArray63 = new double[] { 1.7182818284590453d, (short) 10, '4' };
        boolean boolean64 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray59, doubleArray63);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection65 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        boolean boolean68 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray63, orderDirection65, false, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray54, orderDirection65, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray20, orderDirection65, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException74 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 3.0f, (java.lang.Number) 97, 5, orderDirection65, true);
        boolean boolean77 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray10, orderDirection65, false, false);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + orderDirection22 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection22.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 52.98068036975377d + "'", double51 == 52.98068036975377d);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + orderDirection65 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection65.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test150");
        int[] intArray5 = new int[] { (byte) 1, 0, (byte) 10, 1, 0 };
        int[] intArray7 = org.apache.commons.math.util.MathUtils.copyOf(intArray5, (int) '4');
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) intArray5);
        int[] intArray14 = new int[] { (byte) 1, 0, (byte) 10, 1, 0 };
        int[] intArray16 = org.apache.commons.math.util.MathUtils.copyOf(intArray14, (int) '4');
        int[] intArray22 = new int[] { (byte) 1, 0, (byte) 10, 1, 0 };
        int[] intArray24 = org.apache.commons.math.util.MathUtils.copyOf(intArray22, (int) '4');
        int[] intArray30 = new int[] { (-1000602687), 10, 0, (short) 100, (short) 0 };
        double double31 = org.apache.commons.math.util.MathUtils.distance(intArray22, intArray30);
        double double32 = org.apache.commons.math.util.MathUtils.distance(intArray14, intArray30);
        int int33 = org.apache.commons.math.util.MathUtils.distanceInf(intArray5, intArray14);
        int[] intArray39 = new int[] { (byte) 1, 0, (byte) 10, 1, 0 };
        int[] intArray41 = org.apache.commons.math.util.MathUtils.copyOf(intArray39, (int) '4');
        int[] intArray47 = new int[] { (-1000602687), 10, 0, (short) 100, (short) 0 };
        double double48 = org.apache.commons.math.util.MathUtils.distance(intArray39, intArray47);
        int[] intArray54 = new int[] { (byte) 1, 0, (byte) 10, 1, 0 };
        int[] intArray56 = org.apache.commons.math.util.MathUtils.copyOf(intArray54, (int) '4');
        int int57 = org.apache.commons.math.util.MathUtils.distanceInf(intArray39, intArray54);
        int[] intArray58 = org.apache.commons.math.util.MathUtils.copyOf(intArray39);
        int int59 = org.apache.commons.math.util.MathUtils.distance1(intArray5, intArray58);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 1.000602688000005E9d + "'", double31 == 1.000602688000005E9d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.000602688000005E9d + "'", double32 == 1.000602688000005E9d);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 1.000602688000005E9d + "'", double48 == 1.000602688000005E9d);
        org.junit.Assert.assertNotNull(intArray54);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test151");
        float float1 = org.apache.commons.math.util.FastMath.nextUp(4.8801257E18f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 4.8801263E18f + "'", float1 == 4.8801263E18f);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test152");
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException0 = new org.apache.commons.math.exception.MathArithmeticException();
        org.apache.commons.math.exception.MathInternalError mathInternalError1 = new org.apache.commons.math.exception.MathInternalError((java.lang.Throwable) mathArithmeticException0);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test153");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test154");
        double double2 = org.apache.commons.math.util.FastMath.scalb(0.012654375665383025d, (-100));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.982542242400797E-33d + "'", double2 == 9.982542242400797E-33d);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test155");
        double[] doubleArray2 = new double[] { 10.0d, 0.0d };
        double[] doubleArray6 = new double[] { 1.7182818284590453d, (short) 10, '4' };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray6);
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) (short) 100);
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2, 60466176);
        double[] doubleArray17 = new double[] { 10.0d, 0.0d };
        double[] doubleArray21 = new double[] { 1.7182818284590453d, (short) 10, '4' };
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray17, doubleArray21);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection23 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        boolean boolean26 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray21, orderDirection23, false, true);
        double[] doubleArray27 = new double[] {};
        double[] doubleArray32 = new double[] { 1.0E-15d, Double.NaN, 5.0d, (byte) 10 };
        double[] doubleArray37 = new double[] { 1.0E-15d, Double.NaN, 5.0d, (byte) 10 };
        double[] doubleArray42 = new double[] { 1.0E-15d, Double.NaN, 5.0d, (byte) 10 };
        double[] doubleArray47 = new double[] { 1.0E-15d, Double.NaN, 5.0d, (byte) 10 };
        double[][] doubleArray48 = new double[][] { doubleArray32, doubleArray37, doubleArray42, doubleArray47 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray27, doubleArray48);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray27);
        boolean boolean51 = org.apache.commons.math.util.MathUtils.equals(doubleArray21, doubleArray27);
        double double52 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray21);
        double[] doubleArray55 = new double[] { 1.0986122886681098d, 5.298342365610589d };
        double[] doubleArray57 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray55, (-307.6526555685888d));
        double[] doubleArray60 = new double[] { 10.0d, 0.0d };
        double[] doubleArray64 = new double[] { 1.7182818284590453d, (short) 10, '4' };
        boolean boolean65 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray60, doubleArray64);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection66 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        boolean boolean69 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray64, orderDirection66, false, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray55, orderDirection66, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray21, orderDirection66, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException75 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 3.0f, (java.lang.Number) 97, 5, orderDirection66, true);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2, orderDirection66, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (10 >= 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + orderDirection23 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection23.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 52.98068036975377d + "'", double52 == 52.98068036975377d);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + orderDirection66 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection66.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test156");
        double[] doubleArray2 = new double[] { 10.0d, 0.0d };
        double[] doubleArray6 = new double[] { 1.7182818284590453d, (short) 10, '4' };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray6);
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) (short) 100);
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2, 0);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test157");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver0 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        double double1 = regulaFalsiSolver0.getRelativeAccuracy();
        int int2 = regulaFalsiSolver0.getEvaluations();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0E-14d + "'", double1 == 1.0E-14d);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test158");
        float float2 = org.apache.commons.math.util.FastMath.scalb((float) (short) 10, 32);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 4.2949673E10f + "'", float2 == 4.2949673E10f);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test159");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver0 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        double double1 = regulaFalsiSolver0.getFunctionValueAccuracy();
        double double2 = regulaFalsiSolver0.getAbsoluteAccuracy();
        double double3 = regulaFalsiSolver0.getMin();
        int int4 = regulaFalsiSolver0.getEvaluations();
        double double5 = regulaFalsiSolver0.getMax();
        int int6 = regulaFalsiSolver0.getMaxEvaluations();
        double double7 = regulaFalsiSolver0.getFunctionValueAccuracy();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction9 = null;
        try {
            double double12 = regulaFalsiSolver0.solve(0, univariateRealFunction9, 15.104412573075516d, (double) 1.4E-45f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0E-15d + "'", double1 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E-6d + "'", double2 == 1.0E-6d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0E-15d + "'", double7 == 1.0E-15d);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test160");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_REGRESSION_OBSERVATION;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_0_FOR_SOME_ALPHA;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX;
        java.lang.Object[] objArray12 = new java.lang.Object[] { localizedFormats8, 6.50349243853352d, localizedFormats10, localizedFormats11 };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException13 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats7, objArray12);
        org.apache.commons.math.exception.NoBracketingException noBracketingException14 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, (-0.0d), (-0.7853981633974483d), 0.0d, (double) 2L, objArray12);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException15 = new org.apache.commons.math.exception.NotFiniteNumberException(number1, objArray12);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException16 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray12);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext17 = mathArithmeticException16.getContext();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_REGRESSION_OBSERVATION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_REGRESSION_OBSERVATION));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_0_FOR_SOME_ALPHA + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_0_FOR_SOME_ALPHA));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX_OUT_OF_RANGE + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizedFormats10.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX + "'", localizedFormats11.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(exceptionContext17);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test161");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((int) (short) 0, 13);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test162");
        double double2 = org.apache.commons.math.util.FastMath.scalb(0.0d, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test163");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(0.9866275920404853d, 26.799075016572118d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 26.11936882075883d + "'", double2 == 26.11936882075883d);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test164");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 1594323);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1262.6650387177115d + "'", double1 == 1262.6650387177115d);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test165");
        double[] doubleArray2 = new double[] { 10.0d, 0.0d };
        double[] doubleArray6 = new double[] { 1.7182818284590453d, (short) 10, '4' };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray6);
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) (short) 100);
        int int10 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 31);
        int int13 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1000602687) + "'", int10 == (-1000602687));
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1000602687) + "'", int13 == (-1000602687));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test166");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test167");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, number1);
        java.lang.Throwable[] throwableArray3 = notStrictlyPositiveException2.getSuppressed();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL));
        org.junit.Assert.assertNotNull(throwableArray3);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test168");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.resetCount();
        incrementor0.incrementCount((int) (byte) -1);
        int int4 = incrementor0.getCount();
        incrementor0.resetCount();
        incrementor0.setMaximalCount(0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test169");
        int int2 = org.apache.commons.math.util.FastMath.min(32, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32 + "'", int2 == 32);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test170");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.resetCount();
        incrementor0.setMaximalCount(118608221);
        incrementor0.setMaximalCount((-118608221));
        incrementor0.setMaximalCount(147401637);
        incrementor0.incrementCount(14);
        try {
            incrementor0.incrementCount(1078034432);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MaxCountExceededException; message: illegal state: maximal count (147,401,637) exceeded");
        } catch (org.apache.commons.math.exception.MaxCountExceededException e) {
        }
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test171");
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math.exception.DimensionMismatchException(29, 31);
        int int3 = dimensionMismatchException2.getDimension();
        int int4 = dimensionMismatchException2.getDimension();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 31 + "'", int3 == 31);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 31 + "'", int4 == 31);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test172");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.9950547536867305d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5444569635349489d + "'", double1 == 0.5444569635349489d);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test173");
        float float2 = org.apache.commons.math.util.MathUtils.round(0.0f, (-49));
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test174");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1078034432L, (java.lang.Number) 30.999998f, true);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test175");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 1302087493, (long) 537919490);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 537919490L + "'", long2 == 537919490L);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test176");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 7.629395E-6f, 1.8378770664093453d, (double) 720L);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test177");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyBracketing(univariateRealFunction0, 1.58601345231343E15d, (double) 537919490);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test178");
        int int1 = org.apache.commons.math.util.FastMath.abs(147401637);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 147401637 + "'", int1 == 147401637);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test179");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double double3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(univariateRealFunction0, 5.549306144334055d, 3.0517578145E9d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test180");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED;
        java.lang.Number number6 = null;
        java.lang.Object[] objArray9 = new java.lang.Object[] { (-1.0f), true };
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException10 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, number6, objArray9);
        java.lang.Object[] objArray11 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray9);
        org.apache.commons.math.exception.NoBracketingException noBracketingException12 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (-1.7581226324091723d), 0.0d, (double) 0.99999994f, 5.298342365610589d, objArray11);
        double double13 = noBracketingException12.getLo();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED));
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-1.7581226324091723d) + "'", double13 == (-1.7581226324091723d));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test181");
        double double2 = org.apache.commons.math.util.FastMath.scalb(5.298342365610589d, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.298342365610589d + "'", double2 == 5.298342365610589d);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test182");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.3978952727983707d + "'", double1 == 2.3978952727983707d);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test183");
        int[] intArray5 = new int[] { (byte) 1, 0, (byte) 10, 1, 0 };
        int[] intArray7 = org.apache.commons.math.util.MathUtils.copyOf(intArray5, (int) '4');
        int[] intArray13 = new int[] { (-1000602687), 10, 0, (short) 100, (short) 0 };
        double double14 = org.apache.commons.math.util.MathUtils.distance(intArray5, intArray13);
        int[] intArray20 = new int[] { (byte) 1, 0, (byte) 10, 1, 0 };
        int[] intArray22 = org.apache.commons.math.util.MathUtils.copyOf(intArray20, (int) '4');
        int int23 = org.apache.commons.math.util.MathUtils.distanceInf(intArray5, intArray20);
        int[] intArray24 = org.apache.commons.math.util.MathUtils.copyOf(intArray5);
        int[] intArray30 = new int[] { (byte) 1, 0, (byte) 10, 1, 0 };
        int[] intArray32 = org.apache.commons.math.util.MathUtils.copyOf(intArray30, (int) '4');
        double double33 = org.apache.commons.math.util.MathUtils.distance(intArray5, intArray32);
        int[] intArray34 = org.apache.commons.math.util.MathUtils.copyOf(intArray5);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.000602688000005E9d + "'", double14 == 1.000602688000005E9d);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(intArray34);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test184");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) (-1312836799));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-7.522000777216478E10d) + "'", double1 == (-7.522000777216478E10d));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test185");
        float float1 = org.apache.commons.math.util.FastMath.ulp((float) (-1L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.1920929E-7f + "'", float1 == 1.1920929E-7f);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test186");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_INCREASING_NUMBER_OF_POINTS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED;
        java.lang.Number number4 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] { (-1.0f), true };
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException8 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, number4, objArray7);
        java.lang.Object[] objArray9 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray7);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException10 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray7);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException11 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) (-307.6526555685888d), objArray7);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException12 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray7);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_INCREASING_NUMBER_OF_POINTS + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_INCREASING_NUMBER_OF_POINTS));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED));
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(objArray9);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test187");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (byte) 1, (float) (-49));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-49.0f) + "'", float2 == (-49.0f));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test188");
        double[] doubleArray2 = new double[] { 10.0d, 0.0d };
        double[] doubleArray6 = new double[] { 1.7182818284590453d, (short) 10, '4' };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray6);
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) (short) 100);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (100 >= 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray9);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test189");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 32, 52);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test190");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 60466176);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test191");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) (-8.2674572E18f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-4.7369040357142856E20d) + "'", double1 == (-4.7369040357142856E20d));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test192");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver0 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        double double1 = regulaFalsiSolver0.getFunctionValueAccuracy();
        double double2 = regulaFalsiSolver0.getStartValue();
        double double3 = regulaFalsiSolver0.getRelativeAccuracy();
        double double4 = regulaFalsiSolver0.getRelativeAccuracy();
        double double5 = regulaFalsiSolver0.getFunctionValueAccuracy();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0E-15d + "'", double1 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E-14d + "'", double3 == 1.0E-14d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-14d + "'", double4 == 1.0E-14d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0E-15d + "'", double5 == 1.0E-15d);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test193");
        double[] doubleArray2 = new double[] { 10.0d, 0.0d };
        double[] doubleArray6 = new double[] { 1.7182818284590453d, (short) 10, '4' };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray6);
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray6, 10);
        int int10 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray6);
        double[] doubleArray14 = new double[] { 10.0d, 0.0d };
        double[] doubleArray18 = new double[] { 1.7182818284590453d, (short) 10, '4' };
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray14, doubleArray18);
        java.lang.Number number21 = null;
        double[] doubleArray28 = new double[] { 10.0d, 0.0d };
        double[] doubleArray32 = new double[] { 1.7182818284590453d, (short) 10, '4' };
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray28, doubleArray32);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection34 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        boolean boolean37 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray32, orderDirection34, false, true);
        double[] doubleArray38 = new double[] {};
        double[] doubleArray43 = new double[] { 1.0E-15d, Double.NaN, 5.0d, (byte) 10 };
        double[] doubleArray48 = new double[] { 1.0E-15d, Double.NaN, 5.0d, (byte) 10 };
        double[] doubleArray53 = new double[] { 1.0E-15d, Double.NaN, 5.0d, (byte) 10 };
        double[] doubleArray58 = new double[] { 1.0E-15d, Double.NaN, 5.0d, (byte) 10 };
        double[][] doubleArray59 = new double[][] { doubleArray43, doubleArray48, doubleArray53, doubleArray58 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray38, doubleArray59);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray38);
        boolean boolean62 = org.apache.commons.math.util.MathUtils.equals(doubleArray32, doubleArray38);
        double double63 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray32);
        double[] doubleArray66 = new double[] { 1.0986122886681098d, 5.298342365610589d };
        double[] doubleArray68 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray66, (-307.6526555685888d));
        double[] doubleArray71 = new double[] { 10.0d, 0.0d };
        double[] doubleArray75 = new double[] { 1.7182818284590453d, (short) 10, '4' };
        boolean boolean76 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray71, doubleArray75);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection77 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        boolean boolean80 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray75, orderDirection77, false, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray66, orderDirection77, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray32, orderDirection77, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException86 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 3.0f, (java.lang.Number) 97, 5, orderDirection77, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException88 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 4.605170185988092d, number21, (int) 'a', orderDirection77, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray18, orderDirection77, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11, orderDirection77, true);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 147401637 + "'", int10 == 147401637);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + orderDirection34 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection34.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 52.98068036975377d + "'", double63 == 52.98068036975377d);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertTrue("'" + orderDirection77 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection77.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + true + "'", boolean80 == true);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test194");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException((double) (short) 10, 97.0d, (double) 4, (double) 107L);
        double double5 = noBracketingException4.getFHi();
        double double6 = noBracketingException4.getLo();
        double double7 = noBracketingException4.getFLo();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 107.0d + "'", double5 == 107.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 10.0d + "'", double6 == 10.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test195");
        double double4 = org.apache.commons.math.util.MathUtils.linearCombination(2.5501945883664487d, (double) 1.1920929E-7f, (double) 14, (double) 4.8801257E18f);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 6.832176029048924E19d + "'", double4 == 6.832176029048924E19d);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test196");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 2);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.38905609893065d + "'", double1 == 6.38905609893065d);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test197");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((-42L), (-28L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-14L) + "'", long2 == (-14L));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test198");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver0 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        double double1 = regulaFalsiSolver0.getFunctionValueAccuracy();
        double double2 = regulaFalsiSolver0.getAbsoluteAccuracy();
        double double3 = regulaFalsiSolver0.getMin();
        int int4 = regulaFalsiSolver0.getEvaluations();
        double double5 = regulaFalsiSolver0.getStartValue();
        double double6 = regulaFalsiSolver0.getFunctionValueAccuracy();
        double double7 = regulaFalsiSolver0.getMax();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0E-15d + "'", double1 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E-6d + "'", double2 == 1.0E-6d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0E-15d + "'", double6 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test199");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 96.99999f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.560487412837878d + "'", double1 == 1.560487412837878d);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test200");
        double double2 = org.apache.commons.math.util.FastMath.hypot(300.0d, 1.5860134523134298E15d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5860134523134298E15d + "'", double2 == 1.5860134523134298E15d);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test201");
        double double1 = org.apache.commons.math.util.FastMath.exp((-4.517953907461389E-10d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999999995482046d + "'", double1 == 0.9999999995482046d);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test202");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) (-48));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5499660067586796d) + "'", double1 == (-1.5499660067586796d));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test203");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 1023L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.290822861412639d) + "'", double1 == (-2.290822861412639d));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test204");
        double double2 = org.apache.commons.math.util.FastMath.IEEEremainder(4.5272586500377818E17d, 1.5707963526808657d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.76779764786907d + "'", double2 == 0.76779764786907d);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test205");
        int int1 = org.apache.commons.math.util.FastMath.abs(1078034432);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1078034432 + "'", int1 == 1078034432);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test206");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(1.7485284286691797E11d, 2.3693300629462564d, 29);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test207");
        int int2 = org.apache.commons.math.util.FastMath.max(29, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 29 + "'", int2 == 29);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test208");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 14, (java.lang.Number) 1.0E-6d, (-1));
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test209");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 952841920L, 3.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 9.5284192E8f + "'", float2 == 9.5284192E8f);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test210");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-1074790400), 1222L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test211");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(1078034432, 147401637);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathArithmeticException; message: arithmetic exception");
        } catch (org.apache.commons.math.exception.MathArithmeticException e) {
        }
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test212");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 14, 1594323.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 14.000000000000002d + "'", double2 == 14.000000000000002d);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test213");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) (-100));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5063656411097588d + "'", double1 == 0.5063656411097588d);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test214");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.STANDARD_DEVIATION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.IDENTICAL_ABSCISSAS_DIVISION_BY_ZERO;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException9 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats6, (int) (short) 100, (int) (byte) -1);
        int int10 = dimensionMismatchException9.getDimension();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL_INTERPOLANTS_MISMATCH_SEGMENTS;
        org.apache.commons.math.exception.NullArgumentException nullArgumentException12 = new org.apache.commons.math.exception.NullArgumentException();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext13 = nullArgumentException12.getContext();
        java.lang.Object[] objArray14 = new java.lang.Object[] { localizedFormats5, int10, localizedFormats11, exceptionContext13 };
        org.apache.commons.math.exception.NoBracketingException noBracketingException15 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, 0.0d, (double) (-537919489), (double) 1.2676506E30f, (double) (short) 10, objArray14);
        double double16 = noBracketingException15.getFLo();
        double double17 = noBracketingException15.getHi();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.STANDARD_DEVIATION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.STANDARD_DEVIATION));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.IDENTICAL_ABSCISSAS_DIVISION_BY_ZERO + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.IDENTICAL_ABSCISSAS_DIVISION_BY_ZERO));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL_INTERPOLANTS_MISMATCH_SEGMENTS + "'", localizedFormats11.equals(org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL_INTERPOLANTS_MISMATCH_SEGMENTS));
        org.junit.Assert.assertNotNull(exceptionContext13);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.2676506002282294E30d + "'", double16 == 1.2676506002282294E30d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-5.37919489E8d) + "'", double17 == (-5.37919489E8d));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test215");
        double double2 = org.apache.commons.math.util.FastMath.hypot((-0.0d), 0.4883986821298858d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.4883986821298858d + "'", double2 == 0.4883986821298858d);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test216");
        int[] intArray0 = null;
        int[] intArray5 = new int[] { (-118608221), (-48), (-1023), 1079689216 };
        try {
            int int6 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test217");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 8004785555916557953L, 3.0865652692765765E-41d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test218");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED;
        java.lang.Number number6 = null;
        java.lang.Object[] objArray9 = new java.lang.Object[] { (-1.0f), true };
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException10 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, number6, objArray9);
        java.lang.Object[] objArray11 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray9);
        org.apache.commons.math.exception.NoBracketingException noBracketingException12 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (-1.7581226324091723d), 0.0d, (double) 0.99999994f, 5.298342365610589d, objArray11);
        double double13 = noBracketingException12.getFLo();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats14 = org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED;
        java.lang.Number number22 = null;
        java.lang.Object[] objArray25 = new java.lang.Object[] { (-1.0f), true };
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException26 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats21, number22, objArray25);
        java.lang.Object[] objArray27 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray25);
        org.apache.commons.math.exception.NoBracketingException noBracketingException28 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats16, (-1.7581226324091723d), 0.0d, (double) 0.99999994f, 5.298342365610589d, objArray27);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException29 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats14, (java.lang.Number) (-1.0f), objArray27);
        noBracketingException12.addSuppressed((java.lang.Throwable) notFiniteNumberException29);
        double double31 = noBracketingException12.getFHi();
        double double32 = noBracketingException12.getLo();
        double double33 = noBracketingException12.getFHi();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext34 = noBracketingException12.getContext();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED));
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.9999999403953552d + "'", double13 == 0.9999999403953552d);
        org.junit.Assert.assertTrue("'" + localizedFormats14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION + "'", localizedFormats14.equals(org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION));
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH + "'", localizedFormats16.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH));
        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED + "'", localizedFormats21.equals(org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED));
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 5.298342365610589d + "'", double31 == 5.298342365610589d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + (-1.7581226324091723d) + "'", double32 == (-1.7581226324091723d));
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 5.298342365610589d + "'", double33 == 5.298342365610589d);
        org.junit.Assert.assertNotNull(exceptionContext34);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test219");
        float float1 = org.apache.commons.math.util.MathUtils.sign(28.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test220");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) (-1000602687));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test221");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) (short) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test222");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.TOO_MUCH_CANCELLATION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ROUNDING_METHOD;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_SIZE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray9 = new java.lang.Object[] { "hi!", localizedFormats4, localizedFormats5, localizedFormats6, localizedFormats7, 10L };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException10 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Number) 1.0f, objArray9);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext11 = maxCountExceededException10.getContext();
        exceptionContext11.setValue("org.apache.commons.math.exception.NumberIsTooLargeException: null is larger than the maximum (0)", (java.lang.Object) '4');
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_OBSERVED_POINTS_IN_SAMPLE;
        exceptionContext11.setValue("", (java.lang.Object) localizedFormats16);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats18 = org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats19 = org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED;
        java.lang.Number number20 = null;
        java.lang.Object[] objArray23 = new java.lang.Object[] { (-1.0f), true };
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException24 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats19, number20, objArray23);
        java.lang.Object[] objArray25 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray23);
        exceptionContext11.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats18, objArray23);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats27 = org.apache.commons.math.exception.util.LocalizedFormats.UNKNOWN_MODE;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException31 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0, (java.lang.Number) 0L, true);
        java.lang.Number number32 = numberIsTooLargeException31.getMax();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext33 = numberIsTooLargeException31.getContext();
        double[] doubleArray35 = new double[] {};
        double[] doubleArray40 = new double[] { 1.0E-15d, Double.NaN, 5.0d, (byte) 10 };
        double[] doubleArray45 = new double[] { 1.0E-15d, Double.NaN, 5.0d, (byte) 10 };
        double[] doubleArray50 = new double[] { 1.0E-15d, Double.NaN, 5.0d, (byte) 10 };
        double[] doubleArray55 = new double[] { 1.0E-15d, Double.NaN, 5.0d, (byte) 10 };
        double[][] doubleArray56 = new double[][] { doubleArray40, doubleArray45, doubleArray50, doubleArray55 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray35, doubleArray56);
        exceptionContext33.setValue("", (java.lang.Object) doubleArray56);
        exceptionContext11.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats27, (java.lang.Object[]) doubleArray56);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException60 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 10231.0d, (java.lang.Object[]) doubleArray56);
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TOO_MUCH_CANCELLATION + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.TOO_MUCH_CANCELLATION));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ROUNDING_METHOD + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ROUNDING_METHOD));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_SIZE + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_SIZE));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(exceptionContext11);
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_OBSERVED_POINTS_IN_SAMPLE + "'", localizedFormats16.equals(org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_OBSERVED_POINTS_IN_SAMPLE));
        org.junit.Assert.assertTrue("'" + localizedFormats18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT + "'", localizedFormats18.equals(org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT));
        org.junit.Assert.assertTrue("'" + localizedFormats19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED + "'", localizedFormats19.equals(org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED));
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertTrue("'" + localizedFormats27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNKNOWN_MODE + "'", localizedFormats27.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNKNOWN_MODE));
        org.junit.Assert.assertTrue("'" + number32 + "' != '" + 0L + "'", number32.equals(0L));
        org.junit.Assert.assertNotNull(exceptionContext33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray56);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test223");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_TRANSFORM_TO_DOUBLE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_ROOT_OF_UNITY_INDEX;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED;
        java.lang.Number number14 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] { (-1.0f), true };
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException18 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats13, number14, objArray17);
        java.lang.Object[] objArray19 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray17);
        org.apache.commons.math.exception.NoBracketingException noBracketingException20 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats8, (-1.7581226324091723d), 0.0d, (double) 0.99999994f, 5.298342365610589d, objArray19);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException21 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats6, (java.lang.Number) (-1.0f), objArray19);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException22 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, objArray19);
        org.apache.commons.math.exception.NoBracketingException noBracketingException23 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, 1.9963110132772695d, (double) (-49), (double) (-1023), 1.0E-15d, objArray19);
        double double24 = noBracketingException23.getFLo();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_TRANSFORM_TO_DOUBLE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_TRANSFORM_TO_DOUBLE));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_ROOT_OF_UNITY_INDEX + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_ROOT_OF_UNITY_INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH));
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED + "'", localizedFormats13.equals(org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED));
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + (-1023.0d) + "'", double24 == (-1023.0d));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test224");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(3.0881360887005513d, (double) 4.2949673E10f, 2704);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test225");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver0 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        double double1 = regulaFalsiSolver0.getFunctionValueAccuracy();
        double double2 = regulaFalsiSolver0.getAbsoluteAccuracy();
        double double3 = regulaFalsiSolver0.getMin();
        int int4 = regulaFalsiSolver0.getEvaluations();
        double double5 = regulaFalsiSolver0.getStartValue();
        double double6 = regulaFalsiSolver0.getStartValue();
        double double7 = regulaFalsiSolver0.getAbsoluteAccuracy();
        double double8 = regulaFalsiSolver0.getStartValue();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0E-15d + "'", double1 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E-6d + "'", double2 == 1.0E-6d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0E-6d + "'", double7 == 1.0E-6d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test226");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.TOO_LARGE_CUTOFF_SINGULAR_VALUE;
        java.lang.Number number8 = null;
        double[] doubleArray9 = new double[] {};
        double[] doubleArray14 = new double[] { 1.0E-15d, Double.NaN, 5.0d, (byte) 10 };
        double[] doubleArray19 = new double[] { 1.0E-15d, Double.NaN, 5.0d, (byte) 10 };
        double[] doubleArray24 = new double[] { 1.0E-15d, Double.NaN, 5.0d, (byte) 10 };
        double[] doubleArray29 = new double[] { 1.0E-15d, Double.NaN, 5.0d, (byte) 10 };
        double[][] doubleArray30 = new double[][] { doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray9, doubleArray30);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException32 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats7, number8, (java.lang.Object[]) doubleArray30);
        org.apache.commons.math.exception.NoBracketingException noBracketingException33 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, (double) 118608221, (double) 7.6293945E-6f, 0.0d, 34.99999999999999d, (java.lang.Object[]) doubleArray30);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException34 = new org.apache.commons.math.exception.MaxCountExceededException(localizable0, (java.lang.Number) 5, (java.lang.Object[]) doubleArray30);
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TOO_LARGE_CUTOFF_SINGULAR_VALUE + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.TOO_LARGE_CUTOFF_SINGULAR_VALUE));
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test227");
        double double1 = org.apache.commons.math.util.FastMath.abs(1.5707963267948966d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test228");
        double[] doubleArray2 = new double[] { 10.0d, 0.0d };
        double[] doubleArray6 = new double[] { 1.7182818284590453d, (short) 10, '4' };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray6);
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) (short) 100);
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2, 0);
        double double12 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray11);
        double[] doubleArray15 = new double[] { 10.0d, 0.0d };
        double[] doubleArray19 = new double[] { 1.7182818284590453d, (short) 10, '4' };
        boolean boolean20 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray15, doubleArray19);
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) (short) 100);
        int int23 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        double double24 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray11, doubleArray15);
        double[] doubleArray27 = new double[] { 10.0d, 0.0d };
        double[] doubleArray31 = new double[] { 1.7182818284590453d, (short) 10, '4' };
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray27, doubleArray31);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection33 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        boolean boolean36 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray31, orderDirection33, false, true);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11, orderDirection33, true);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1000602687) + "'", int23 == (-1000602687));
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + orderDirection33 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection33.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test229");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.WRONG_BLOCK_LENGTH;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 0.017453292519943295d, (java.lang.Number) 0.8414709848078965d, false);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1.5607966601082315d, (java.lang.Number) 0.05235987755982989d, true);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WRONG_BLOCK_LENGTH + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.WRONG_BLOCK_LENGTH));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test230");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-419311268), 132);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathArithmeticException; message: arithmetic exception");
        } catch (org.apache.commons.math.exception.MathArithmeticException e) {
        }
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test231");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(2383.0938723101453d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test232");
        double[] doubleArray2 = new double[] { 1.0986122886681098d, 5.298342365610589d };
        double[] doubleArray4 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (-307.6526555685888d));
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 260.23657820726487d + "'", double5 == 260.23657820726487d);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test233");
        double double2 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.midpoint(0.9950547536867305d, (double) 10L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.497527376843365d + "'", double2 == 5.497527376843365d);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test234");
        float float2 = org.apache.commons.math.util.FastMath.copySign((float) (-419311268), (float) 60466176);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 4.19311264E8f + "'", float2 == 4.19311264E8f);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test235");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.FAILED_BRACKETING;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SAMPLE_SIZE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_PLUS_ONE;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException5 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, (int) ' ', (int) (byte) 0);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.NO_REGRESSORS;
        java.lang.Number number7 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException(number7, (java.lang.Number) (byte) 0, true);
        java.lang.Number number11 = numberIsTooLargeException10.getArgument();
        java.lang.Number number12 = numberIsTooLargeException10.getMax();
        org.apache.commons.math.exception.MathInternalError mathInternalError13 = new org.apache.commons.math.exception.MathInternalError((java.lang.Throwable) numberIsTooLargeException10);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats14 = org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_SET_AT_NEGATIVE_INDEX;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats20 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_PLUS_ONE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats22 = org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED;
        java.lang.Number number23 = null;
        java.lang.Object[] objArray26 = new java.lang.Object[] { (-1.0f), true };
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException27 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats22, number23, objArray26);
        java.lang.Object[] objArray28 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray26);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException29 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats20, (java.lang.Number) 1.5707963267948966d, objArray26);
        org.apache.commons.math.exception.NoBracketingException noBracketingException30 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats15, (double) 100, Double.NEGATIVE_INFINITY, 0.8414709848078965d, 2.0d, objArray26);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException31 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) mathInternalError13, (org.apache.commons.math.exception.util.Localizable) localizedFormats14, objArray26);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException32 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) dimensionMismatchException5, (org.apache.commons.math.exception.util.Localizable) localizedFormats6, objArray26);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) localizedFormats0, (org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray26);
        java.lang.Number number34 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException37 = new org.apache.commons.math.exception.NumberIsTooLargeException(number34, (java.lang.Number) (byte) 0, true);
        java.lang.Number number38 = numberIsTooLargeException37.getArgument();
        java.lang.Number number39 = numberIsTooLargeException37.getMax();
        org.apache.commons.math.exception.MathInternalError mathInternalError40 = new org.apache.commons.math.exception.MathInternalError((java.lang.Throwable) numberIsTooLargeException37);
        java.lang.Throwable[] throwableArray41 = mathInternalError40.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException42 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Object[]) throwableArray41);
        java.util.Locale locale43 = null;
        try {
            java.lang.String str44 = localizedFormats1.getLocalizedString(locale43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FAILED_BRACKETING + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.FAILED_BRACKETING));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SAMPLE_SIZE + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SAMPLE_SIZE));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_PLUS_ONE + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_PLUS_ONE));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_REGRESSORS + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_REGRESSORS));
        org.junit.Assert.assertNull(number11);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (byte) 0 + "'", number12.equals((byte) 0));
        org.junit.Assert.assertTrue("'" + localizedFormats14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizedFormats14.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_SET_AT_NEGATIVE_INDEX + "'", localizedFormats15.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_SET_AT_NEGATIVE_INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_PLUS_ONE + "'", localizedFormats20.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_PLUS_ONE));
        org.junit.Assert.assertTrue("'" + localizedFormats22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED + "'", localizedFormats22.equals(org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED));
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertNull(number38);
        org.junit.Assert.assertTrue("'" + number39 + "' != '" + (byte) 0 + "'", number39.equals((byte) 0));
        org.junit.Assert.assertNotNull(throwableArray41);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test236");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (short) 10, (java.lang.Number) 537919490, false);
        boolean boolean4 = numberIsTooSmallException3.getBoundIsAllowed();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext5 = numberIsTooSmallException3.getContext();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(exceptionContext5);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test237");
        double[] doubleArray2 = new double[] { 10.0d, 0.0d };
        double[] doubleArray6 = new double[] { 1.7182818284590453d, (short) 10, '4' };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray6);
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) (short) 100);
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2, 0);
        double double12 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray11);
        double[] doubleArray13 = null;
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray11, doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test238");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException((double) (short) 10, 97.0d, (double) 4, (double) 107L);
        org.apache.commons.math.exception.NotPositiveException notPositiveException6 = new org.apache.commons.math.exception.NotPositiveException((java.lang.Number) (-0.0d));
        noBracketingException4.addSuppressed((java.lang.Throwable) notPositiveException6);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_PLUS_ONE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED;
        java.lang.Number number12 = null;
        java.lang.Object[] objArray15 = new java.lang.Object[] { (-1.0f), true };
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException16 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats11, number12, objArray15);
        java.lang.Object[] objArray17 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray15);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException18 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats9, (java.lang.Number) 1.5707963267948966d, objArray15);
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats20 = org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_ROOT_OF_UNITY_INDEX;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats23 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats28 = org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED;
        java.lang.Number number29 = null;
        java.lang.Object[] objArray32 = new java.lang.Object[] { (-1.0f), true };
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException33 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats28, number29, objArray32);
        java.lang.Object[] objArray34 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray32);
        org.apache.commons.math.exception.NoBracketingException noBracketingException35 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats23, (-1.7581226324091723d), 0.0d, (double) 0.99999994f, 5.298342365610589d, objArray34);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException36 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats21, (java.lang.Number) (-1.0f), objArray34);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException37 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats20, objArray34);
        java.lang.Object[] objArray38 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray34);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) localizedFormats9, localizable19, objArray34);
        java.lang.Object[] objArray40 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray34);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException41 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) notPositiveException6, (org.apache.commons.math.exception.util.Localizable) localizedFormats8, objArray34);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats43 = org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED;
        java.lang.Number number44 = null;
        java.lang.Object[] objArray47 = new java.lang.Object[] { (-1.0f), true };
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException48 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats43, number44, objArray47);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException49 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 2L, objArray47);
        java.lang.Throwable[] throwableArray50 = notFiniteNumberException49.getSuppressed();
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException51 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats8, (java.lang.Object[]) throwableArray50);
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_PLUS_ONE + "'", localizedFormats9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_PLUS_ONE));
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED + "'", localizedFormats11.equals(org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED));
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertTrue("'" + localizedFormats20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_ROOT_OF_UNITY_INDEX + "'", localizedFormats20.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_ROOT_OF_UNITY_INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION + "'", localizedFormats21.equals(org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION));
        org.junit.Assert.assertTrue("'" + localizedFormats23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH + "'", localizedFormats23.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH));
        org.junit.Assert.assertTrue("'" + localizedFormats28 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED + "'", localizedFormats28.equals(org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED));
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(objArray40);
        org.junit.Assert.assertTrue("'" + localizedFormats43 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED + "'", localizedFormats43.equals(org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED));
        org.junit.Assert.assertNotNull(objArray47);
        org.junit.Assert.assertNotNull(throwableArray50);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test239");
        int int2 = org.apache.commons.math.util.MathUtils.pow(2, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test240");
        double double1 = org.apache.commons.math.util.FastMath.exp(1.9647605821757634d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.133204569383454d + "'", double1 == 7.133204569383454d);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test241");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(35.0d, (double) 31);
        int int3 = regulaFalsiSolver2.getMaxEvaluations();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test242");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test243");
        int int1 = org.apache.commons.math.util.FastMath.getExponent(363.7393755555636d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test244");
        java.lang.Number number1 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 100, number1, 0, orderDirection3, false);
        org.apache.commons.math.exception.MathInternalError mathInternalError6 = new org.apache.commons.math.exception.MathInternalError((java.lang.Throwable) nonMonotonousSequenceException5);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math.exception.util.LocalizedFormats.TOO_MUCH_CANCELLATION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ROUNDING_METHOD;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_SIZE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats14 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray17 = new java.lang.Object[] { "hi!", localizedFormats12, localizedFormats13, localizedFormats14, localizedFormats15, 10L };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException18 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats9, (java.lang.Number) 1.0f, objArray17);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext19 = maxCountExceededException18.getContext();
        exceptionContext19.setValue("org.apache.commons.math.exception.NumberIsTooLargeException: null is larger than the maximum (0)", (java.lang.Object) '4');
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats23 = org.apache.commons.math.exception.util.LocalizedFormats.ALPHA;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats25 = org.apache.commons.math.exception.util.LocalizedFormats.AT_LEAST_ONE_COLUMN;
        java.lang.Number number26 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats27 = org.apache.commons.math.exception.util.LocalizedFormats.TOO_MUCH_CANCELLATION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats30 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ROUNDING_METHOD;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats31 = org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_SIZE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats32 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats33 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray35 = new java.lang.Object[] { "hi!", localizedFormats30, localizedFormats31, localizedFormats32, localizedFormats33, 10L };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException36 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats27, (java.lang.Number) 1.0f, objArray35);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException37 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats25, number26, objArray35);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException38 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 0.017453292519943295d, objArray35);
        exceptionContext19.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats23, objArray35);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException40 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 0.047442967903742035d, objArray35);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException41 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) mathInternalError6, (org.apache.commons.math.exception.util.Localizable) localizedFormats7, objArray35);
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TOO_MUCH_CANCELLATION + "'", localizedFormats9.equals(org.apache.commons.math.exception.util.LocalizedFormats.TOO_MUCH_CANCELLATION));
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ROUNDING_METHOD + "'", localizedFormats12.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ROUNDING_METHOD));
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_SIZE + "'", localizedFormats13.equals(org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_SIZE));
        org.junit.Assert.assertTrue("'" + localizedFormats14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats14.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES + "'", localizedFormats15.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(exceptionContext19);
        org.junit.Assert.assertTrue("'" + localizedFormats23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ALPHA + "'", localizedFormats23.equals(org.apache.commons.math.exception.util.LocalizedFormats.ALPHA));
        org.junit.Assert.assertTrue("'" + localizedFormats25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.AT_LEAST_ONE_COLUMN + "'", localizedFormats25.equals(org.apache.commons.math.exception.util.LocalizedFormats.AT_LEAST_ONE_COLUMN));
        org.junit.Assert.assertTrue("'" + localizedFormats27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TOO_MUCH_CANCELLATION + "'", localizedFormats27.equals(org.apache.commons.math.exception.util.LocalizedFormats.TOO_MUCH_CANCELLATION));
        org.junit.Assert.assertTrue("'" + localizedFormats30 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ROUNDING_METHOD + "'", localizedFormats30.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ROUNDING_METHOD));
        org.junit.Assert.assertTrue("'" + localizedFormats31 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_SIZE + "'", localizedFormats31.equals(org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_SIZE));
        org.junit.Assert.assertTrue("'" + localizedFormats32 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats32.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertTrue("'" + localizedFormats33 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES + "'", localizedFormats33.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray35);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test245");
        long long2 = org.apache.commons.math.util.FastMath.max(0L, (long) 118608221);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 118608221L + "'", long2 == 118608221L);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test246");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 1079574528, 2865L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1079571663L + "'", long2 == 1079571663L);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test247");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.SAME_SIGN_AT_ENDPOINTS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_REGRESSION_OBSERVATION;
        java.lang.Number number6 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_0_FOR_SOME_ALPHA;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX;
        java.lang.Object[] objArray17 = new java.lang.Object[] { localizedFormats13, 6.50349243853352d, localizedFormats15, localizedFormats16 };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException18 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats12, objArray17);
        org.apache.commons.math.exception.NoBracketingException noBracketingException19 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats7, (-0.0d), (-0.7853981633974483d), 0.0d, (double) 2L, objArray17);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException20 = new org.apache.commons.math.exception.NotFiniteNumberException(number6, objArray17);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException21 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, objArray17);
        org.apache.commons.math.exception.NoBracketingException noBracketingException22 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (double) '#', 5.930411282452817E7d, 61035.156480000005d, (double) (-49), objArray17);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SAME_SIGN_AT_ENDPOINTS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.SAME_SIGN_AT_ENDPOINTS));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_REGRESSION_OBSERVATION + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_REGRESSION_OBSERVATION));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT));
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_0_FOR_SOME_ALPHA + "'", localizedFormats12.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_0_FOR_SOME_ALPHA));
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX_OUT_OF_RANGE + "'", localizedFormats13.equals(org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizedFormats15.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX + "'", localizedFormats16.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX));
        org.junit.Assert.assertNotNull(objArray17);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test248");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(1.5607966601082315d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test249");
        float float3 = org.apache.commons.math.util.MathUtils.round((float) 1, 29, 1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test250");
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math.exception.DimensionMismatchException(31, 0);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test251");
        int[] intArray5 = new int[] { (-537919489), 31, (short) 100, 2, 3 };
        int[] intArray6 = org.apache.commons.math.util.MathUtils.copyOf(intArray5);
        int[] intArray12 = new int[] { (byte) 1, 0, (byte) 10, 1, 0 };
        int[] intArray14 = org.apache.commons.math.util.MathUtils.copyOf(intArray12, (int) '4');
        int[] intArray20 = new int[] { (-1000602687), 10, 0, (short) 100, (short) 0 };
        double double21 = org.apache.commons.math.util.MathUtils.distance(intArray12, intArray20);
        int[] intArray27 = new int[] { (byte) 1, 0, (byte) 10, 1, 0 };
        int[] intArray29 = org.apache.commons.math.util.MathUtils.copyOf(intArray27, (int) '4');
        int int30 = org.apache.commons.math.util.MathUtils.distanceInf(intArray12, intArray27);
        int[] intArray31 = org.apache.commons.math.util.MathUtils.copyOf(intArray12);
        int[] intArray32 = org.apache.commons.math.util.MathUtils.copyOf(intArray31);
        int int33 = org.apache.commons.math.util.MathUtils.distanceInf(intArray6, intArray32);
        int[] intArray35 = org.apache.commons.math.util.MathUtils.copyOf(intArray6, 0);
        int[] intArray41 = new int[] { (byte) 1, 0, (byte) 10, 1, 0 };
        int[] intArray43 = org.apache.commons.math.util.MathUtils.copyOf(intArray41, (int) '4');
        int[] intArray49 = new int[] { (-1000602687), 10, 0, (short) 100, (short) 0 };
        double double50 = org.apache.commons.math.util.MathUtils.distance(intArray41, intArray49);
        int[] intArray56 = new int[] { (byte) 1, 0, (byte) 10, 1, 0 };
        int[] intArray58 = org.apache.commons.math.util.MathUtils.copyOf(intArray56, (int) '4');
        int int59 = org.apache.commons.math.util.MathUtils.distanceInf(intArray41, intArray56);
        int[] intArray60 = org.apache.commons.math.util.MathUtils.copyOf(intArray41);
        double double61 = org.apache.commons.math.util.MathUtils.distance(intArray35, intArray41);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.000602688000005E9d + "'", double21 == 1.000602688000005E9d);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 537919490 + "'", int33 == 537919490);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 1.000602688000005E9d + "'", double50 == 1.000602688000005E9d);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test252");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_PLUS_ONE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED;
        java.lang.Number number4 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] { (-1.0f), true };
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException8 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, number4, objArray7);
        java.lang.Object[] objArray9 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray7);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException10 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Number) 1.5707963267948966d, objArray7);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_ROOT_OF_UNITY_INDEX;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats20 = org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED;
        java.lang.Number number21 = null;
        java.lang.Object[] objArray24 = new java.lang.Object[] { (-1.0f), true };
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException25 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats20, number21, objArray24);
        java.lang.Object[] objArray26 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray24);
        org.apache.commons.math.exception.NoBracketingException noBracketingException27 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats15, (-1.7581226324091723d), 0.0d, (double) 0.99999994f, 5.298342365610589d, objArray26);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException28 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats13, (java.lang.Number) (-1.0f), objArray26);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException29 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats12, objArray26);
        java.lang.Object[] objArray30 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray26);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) localizedFormats1, localizable11, objArray26);
        java.lang.Object[] objArray32 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray26);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException33 = new org.apache.commons.math.exception.MathArithmeticException(localizable0, objArray32);
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_PLUS_ONE + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_PLUS_ONE));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED));
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_ROOT_OF_UNITY_INDEX + "'", localizedFormats12.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_ROOT_OF_UNITY_INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION + "'", localizedFormats13.equals(org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION));
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH + "'", localizedFormats15.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH));
        org.junit.Assert.assertTrue("'" + localizedFormats20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED + "'", localizedFormats20.equals(org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED));
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertNotNull(objArray32);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test253");
        float float1 = org.apache.commons.math.util.MathUtils.sign(0.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test254");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((-2.5885969093217648E-8d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.002958158745523026d) + "'", double1 == (-0.002958158745523026d));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test255");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) (short) 100);
        int int2 = regulaFalsiSolver1.getEvaluations();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction4 = null;
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction8 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver10 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(1.000602688000005E9d);
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution14 = org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE;
        double double15 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide((-118608221), univariateRealFunction8, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver10, 0.0d, (-0.0d), 5.1072502269620796E22d, allowedSolution14);
        try {
            double double16 = regulaFalsiSolver1.solve(952841920, univariateRealFunction4, (-1.5574077246549023d), 0.0d, allowedSolution14);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + allowedSolution14 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE + "'", allowedSolution14.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test256");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 2.0634370688955608d, (java.lang.Number) 1.47401632E8f, false);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test257");
        org.apache.commons.math.exception.NullArgumentException nullArgumentException0 = new org.apache.commons.math.exception.NullArgumentException();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext1 = nullArgumentException0.getContext();
        java.lang.Object obj3 = exceptionContext1.getValue("org.apache.commons.math.exception.MaxCountExceededException: illegal state: maximal count (10,230) exceeded");
        org.junit.Assert.assertNotNull(exceptionContext1);
        org.junit.Assert.assertNull(obj3);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test258");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.resetCount();
        incrementor0.incrementCount((int) (byte) -1);
        int int4 = incrementor0.getCount();
        incrementor0.incrementCount((int) (short) 0);
        incrementor0.resetCount();
        incrementor0.setMaximalCount((int) (byte) -1);
        try {
            incrementor0.incrementCount();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MaxCountExceededException; message: illegal state: maximal count (-1) exceeded");
        } catch (org.apache.commons.math.exception.MaxCountExceededException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test259");
        int[] intArray5 = new int[] { (-537919489), 31, (short) 100, 2, 3 };
        int[] intArray6 = org.apache.commons.math.util.MathUtils.copyOf(intArray5);
        int[] intArray12 = new int[] { (byte) 1, 0, (byte) 10, 1, 0 };
        int[] intArray14 = org.apache.commons.math.util.MathUtils.copyOf(intArray12, (int) '4');
        int[] intArray20 = new int[] { (-1000602687), 10, 0, (short) 100, (short) 0 };
        double double21 = org.apache.commons.math.util.MathUtils.distance(intArray12, intArray20);
        int[] intArray27 = new int[] { (byte) 1, 0, (byte) 10, 1, 0 };
        int[] intArray29 = org.apache.commons.math.util.MathUtils.copyOf(intArray27, (int) '4');
        int int30 = org.apache.commons.math.util.MathUtils.distanceInf(intArray12, intArray27);
        int[] intArray31 = org.apache.commons.math.util.MathUtils.copyOf(intArray12);
        int[] intArray32 = org.apache.commons.math.util.MathUtils.copyOf(intArray31);
        int int33 = org.apache.commons.math.util.MathUtils.distanceInf(intArray6, intArray32);
        int[] intArray35 = org.apache.commons.math.util.MathUtils.copyOf(intArray6, 0);
        int[] intArray41 = new int[] { (byte) 1, 0, (byte) 10, 1, 0 };
        int[] intArray43 = org.apache.commons.math.util.MathUtils.copyOf(intArray41, (int) '4');
        int[] intArray49 = new int[] { (-1000602687), 10, 0, (short) 100, (short) 0 };
        double double50 = org.apache.commons.math.util.MathUtils.distance(intArray41, intArray49);
        int[] intArray56 = new int[] { (byte) 1, 0, (byte) 10, 1, 0 };
        int[] intArray58 = org.apache.commons.math.util.MathUtils.copyOf(intArray56, (int) '4');
        int int59 = org.apache.commons.math.util.MathUtils.distanceInf(intArray41, intArray56);
        int[] intArray60 = org.apache.commons.math.util.MathUtils.copyOf(intArray41);
        int int61 = org.apache.commons.math.util.MathUtils.distance1(intArray35, intArray60);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.000602688000005E9d + "'", double21 == 1.000602688000005E9d);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 537919490 + "'", int33 == 537919490);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 1.000602688000005E9d + "'", double50 == 1.000602688000005E9d);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test260");
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) 0.6626739020865235d);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test261");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (-14L));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: exponent (-14)");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test262");
        int int2 = org.apache.commons.math.util.FastMath.max(1074790400, 1023);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1074790400 + "'", int2 == 1074790400);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test263");
        int[] intArray5 = new int[] { (byte) 1, 0, (byte) 10, 1, 0 };
        int[] intArray7 = org.apache.commons.math.util.MathUtils.copyOf(intArray5, (int) '4');
        int[] intArray13 = new int[] { (-1000602687), 10, 0, (short) 100, (short) 0 };
        double double14 = org.apache.commons.math.util.MathUtils.distance(intArray5, intArray13);
        int[] intArray15 = org.apache.commons.math.util.MathUtils.copyOf(intArray13);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.000602688000005E9d + "'", double14 == 1.000602688000005E9d);
        org.junit.Assert.assertNotNull(intArray15);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test264");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED;
        java.lang.Number number6 = null;
        java.lang.Object[] objArray9 = new java.lang.Object[] { (-1.0f), true };
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException10 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, number6, objArray9);
        java.lang.Object[] objArray11 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray9);
        org.apache.commons.math.exception.NoBracketingException noBracketingException12 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (-1.7581226324091723d), 0.0d, (double) 0.99999994f, 5.298342365610589d, objArray11);
        double double13 = noBracketingException12.getFLo();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats14 = org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED;
        java.lang.Number number22 = null;
        java.lang.Object[] objArray25 = new java.lang.Object[] { (-1.0f), true };
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException26 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats21, number22, objArray25);
        java.lang.Object[] objArray27 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray25);
        org.apache.commons.math.exception.NoBracketingException noBracketingException28 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats16, (-1.7581226324091723d), 0.0d, (double) 0.99999994f, 5.298342365610589d, objArray27);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException29 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats14, (java.lang.Number) (-1.0f), objArray27);
        noBracketingException12.addSuppressed((java.lang.Throwable) notFiniteNumberException29);
        double double31 = noBracketingException12.getFHi();
        double double32 = noBracketingException12.getLo();
        double double33 = noBracketingException12.getFHi();
        double double34 = noBracketingException12.getFHi();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED));
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.9999999403953552d + "'", double13 == 0.9999999403953552d);
        org.junit.Assert.assertTrue("'" + localizedFormats14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION + "'", localizedFormats14.equals(org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION));
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH + "'", localizedFormats16.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH));
        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED + "'", localizedFormats21.equals(org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED));
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 5.298342365610589d + "'", double31 == 5.298342365610589d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + (-1.7581226324091723d) + "'", double32 == (-1.7581226324091723d));
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 5.298342365610589d + "'", double33 == 5.298342365610589d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 5.298342365610589d + "'", double34 == 5.298342365610589d);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test265");
        double[] doubleArray2 = new double[] { 10.0d, 0.0d };
        double[] doubleArray6 = new double[] { 1.7182818284590453d, (short) 10, '4' };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray6);
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) (short) 100);
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2, 0);
        double double12 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray11);
        double[] doubleArray14 = new double[] { 10 };
        double[] doubleArray19 = new double[] { 3.4965075614664802d, (-1), (byte) 1, 100 };
        double double20 = org.apache.commons.math.util.MathUtils.distance(doubleArray14, doubleArray19);
        double[] doubleArray22 = new double[] { 10 };
        double[] doubleArray27 = new double[] { 3.4965075614664802d, (-1), (byte) 1, 100 };
        double double28 = org.apache.commons.math.util.MathUtils.distance(doubleArray22, doubleArray27);
        double[] doubleArray31 = new double[] { 10.0d, 0.0d };
        double[] doubleArray35 = new double[] { 1.7182818284590453d, (short) 10, '4' };
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray31, doubleArray35);
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equals(doubleArray22, doubleArray31);
        int int38 = org.apache.commons.math.util.MathUtils.hash(doubleArray31);
        double double39 = org.apache.commons.math.util.MathUtils.distance(doubleArray14, doubleArray31);
        double double40 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray11, doubleArray31);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 6.50349243853352d + "'", double20 == 6.50349243853352d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 6.50349243853352d + "'", double28 == 6.50349243853352d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1000602687) + "'", int38 == (-1000602687));
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test266");
        int int1 = org.apache.commons.math.util.FastMath.getExponent(5.930411282452817E7d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 25 + "'", int1 == 25);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test267");
        double[] doubleArray2 = new double[] { 10.0d, 0.0d };
        double[] doubleArray6 = new double[] { 1.7182818284590453d, (short) 10, '4' };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray6);
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) (short) 100);
        int int10 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 31);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1000602687) + "'", int10 == (-1000602687));
        org.junit.Assert.assertNotNull(doubleArray12);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test268");
        int int2 = org.apache.commons.math.util.FastMath.max(1594323, 3);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1594323 + "'", int2 == 1594323);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test269");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 2865L, (-100));
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test270");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.5063656411097588d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.039831411921513d + "'", double1 == 1.039831411921513d);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test271");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(14.000000000000002d, (-0.16299078079570548d), 0.017453292519943295d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test272");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(Double.POSITIVE_INFINITY, (double) (short) 0, (-8.9780852053532211E18d));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test273");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.STANDARD_DEVIATION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.IDENTICAL_ABSCISSAS_DIVISION_BY_ZERO;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException11 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats8, (int) (short) 100, (int) (byte) -1);
        int int12 = dimensionMismatchException11.getDimension();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL_INTERPOLANTS_MISMATCH_SEGMENTS;
        org.apache.commons.math.exception.NullArgumentException nullArgumentException14 = new org.apache.commons.math.exception.NullArgumentException();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext15 = nullArgumentException14.getContext();
        java.lang.Object[] objArray16 = new java.lang.Object[] { localizedFormats7, int12, localizedFormats13, exceptionContext15 };
        org.apache.commons.math.exception.NoBracketingException noBracketingException17 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, 0.0d, (double) (-537919489), (double) 1.2676506E30f, (double) (short) 10, objArray16);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException18 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 10.0d, objArray16);
        java.lang.Number number19 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException22 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, number19, (java.lang.Number) 1074790401L, true);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.STANDARD_DEVIATION + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.STANDARD_DEVIATION));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.IDENTICAL_ABSCISSAS_DIVISION_BY_ZERO + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.IDENTICAL_ABSCISSAS_DIVISION_BY_ZERO));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL_INTERPOLANTS_MISMATCH_SEGMENTS + "'", localizedFormats13.equals(org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL_INTERPOLANTS_MISMATCH_SEGMENTS));
        org.junit.Assert.assertNotNull(exceptionContext15);
        org.junit.Assert.assertNotNull(objArray16);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test274");
        float float1 = org.apache.commons.math.util.FastMath.signum((float) 184);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test275");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(18.281718171540955d, 1.9647605821757634d, 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test276");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver0 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        double double1 = regulaFalsiSolver0.getFunctionValueAccuracy();
        double double2 = regulaFalsiSolver0.getStartValue();
        int int3 = regulaFalsiSolver0.getMaxEvaluations();
        double double4 = regulaFalsiSolver0.getMin();
        double double5 = regulaFalsiSolver0.getRelativeAccuracy();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0E-15d + "'", double1 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0E-14d + "'", double5 == 1.0E-14d);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test277");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.setMaximalCount(184);
        int int3 = incrementor0.getMaximalCount();
        incrementor0.resetCount();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 184 + "'", int3 == 184);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test278");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 118608227L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test279");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(5.1072502269620796E22d, 86808.04131816389d, (double) 97L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test280");
        long long1 = org.apache.commons.math.util.FastMath.round((double) (-1000602687));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1000602687L) + "'", long1 == (-1000602687L));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test281");
        double[] doubleArray2 = new double[] { 10.0d, 0.0d };
        double[] doubleArray6 = new double[] { 1.7182818284590453d, (short) 10, '4' };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray6);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        boolean boolean11 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray6, orderDirection8, false, true);
        double[] doubleArray12 = new double[] {};
        double[] doubleArray17 = new double[] { 1.0E-15d, Double.NaN, 5.0d, (byte) 10 };
        double[] doubleArray22 = new double[] { 1.0E-15d, Double.NaN, 5.0d, (byte) 10 };
        double[] doubleArray27 = new double[] { 1.0E-15d, Double.NaN, 5.0d, (byte) 10 };
        double[] doubleArray32 = new double[] { 1.0E-15d, Double.NaN, 5.0d, (byte) 10 };
        double[][] doubleArray33 = new double[][] { doubleArray17, doubleArray22, doubleArray27, doubleArray32 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray12, doubleArray33);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray12);
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray12);
        double[] doubleArray37 = null;
        double double38 = org.apache.commons.math.util.MathUtils.distance(doubleArray12, doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + orderDirection8 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection8.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test282");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 8978085206306062337L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2078394.1320467473d + "'", double1 == 2078394.1320467473d);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test283");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.TOO_LARGE_CUTOFF_SINGULAR_VALUE;
        java.lang.Number number6 = null;
        double[] doubleArray7 = new double[] {};
        double[] doubleArray12 = new double[] { 1.0E-15d, Double.NaN, 5.0d, (byte) 10 };
        double[] doubleArray17 = new double[] { 1.0E-15d, Double.NaN, 5.0d, (byte) 10 };
        double[] doubleArray22 = new double[] { 1.0E-15d, Double.NaN, 5.0d, (byte) 10 };
        double[] doubleArray27 = new double[] { 1.0E-15d, Double.NaN, 5.0d, (byte) 10 };
        double[][] doubleArray28 = new double[][] { doubleArray12, doubleArray17, doubleArray22, doubleArray27 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray7, doubleArray28);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException30 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, number6, (java.lang.Object[]) doubleArray28);
        org.apache.commons.math.exception.NoBracketingException noBracketingException31 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (double) 118608221, (double) 7.6293945E-6f, 0.0d, 34.99999999999999d, (java.lang.Object[]) doubleArray28);
        java.lang.Number number32 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException35 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, number32, (java.lang.Number) (-3.97724720171748d), false);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TOO_LARGE_CUTOFF_SINGULAR_VALUE + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.TOO_LARGE_CUTOFF_SINGULAR_VALUE));
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test284");
        double double2 = org.apache.commons.math.util.FastMath.scalb(0.0d, (-419311268));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test285");
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) 7.930067261567154E14d);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test286");
        double[] doubleArray2 = new double[] { 1.0986122886681098d, 5.298342365610589d };
        double[] doubleArray4 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (-307.6526555685888d));
        double[][] doubleArray5 = null;
        try {
            org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray4, doubleArray5);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test287");
        float[] floatArray2 = new float[] { (short) 100, (-100) };
        float[] floatArray6 = new float[] { 1L, (byte) 100, 1 };
        float[] floatArray11 = new float[] { 100, (short) -1, (byte) 100, 'a' };
        float[] floatArray18 = new float[] { 'a', (-1L), 100, (-1L), 100L, (-1L) };
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray11, floatArray18);
        boolean boolean20 = org.apache.commons.math.util.MathUtils.equals(floatArray6, floatArray18);
        float[] floatArray24 = new float[] { 1L, (byte) 100, 1 };
        float[] floatArray29 = new float[] { 100, (short) -1, (byte) 100, 'a' };
        float[] floatArray36 = new float[] { 'a', (-1L), 100, (-1L), 100L, (-1L) };
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray29, floatArray36);
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equals(floatArray24, floatArray36);
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equals(floatArray18, floatArray36);
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equals(floatArray2, floatArray18);
        float[] floatArray43 = new float[] { (short) 100, (-100) };
        float[] floatArray47 = new float[] { 1L, (byte) 100, 1 };
        float[] floatArray52 = new float[] { 100, (short) -1, (byte) 100, 'a' };
        float[] floatArray59 = new float[] { 'a', (-1L), 100, (-1L), 100L, (-1L) };
        boolean boolean60 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray52, floatArray59);
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equals(floatArray47, floatArray59);
        float[] floatArray65 = new float[] { 1L, (byte) 100, 1 };
        float[] floatArray70 = new float[] { 100, (short) -1, (byte) 100, 'a' };
        float[] floatArray77 = new float[] { 'a', (-1L), 100, (-1L), 100L, (-1L) };
        boolean boolean78 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray70, floatArray77);
        boolean boolean79 = org.apache.commons.math.util.MathUtils.equals(floatArray65, floatArray77);
        boolean boolean80 = org.apache.commons.math.util.MathUtils.equals(floatArray59, floatArray77);
        boolean boolean81 = org.apache.commons.math.util.MathUtils.equals(floatArray43, floatArray59);
        boolean boolean82 = org.apache.commons.math.util.MathUtils.equals(floatArray18, floatArray59);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray29);
        org.junit.Assert.assertNotNull(floatArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(floatArray43);
        org.junit.Assert.assertNotNull(floatArray47);
        org.junit.Assert.assertNotNull(floatArray52);
        org.junit.Assert.assertNotNull(floatArray59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(floatArray65);
        org.junit.Assert.assertNotNull(floatArray70);
        org.junit.Assert.assertNotNull(floatArray77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + true + "'", boolean80 == true);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + true + "'", boolean82 == true);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test288");
        double double2 = org.apache.commons.math.util.FastMath.IEEEremainder((double) 1594323, (-2.20676381741154304E17d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1594323.0d + "'", double2 == 1594323.0d);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test289");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((-0.7853981633974483d), 0.0d, 462683420);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test290");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SHAPE;
        org.apache.commons.math.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math.exception.NotPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 0.8144772166995121d);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SHAPE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SHAPE));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test291");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(11013.232874703393d, (double) 537919490L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test292");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((int) (byte) 0, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test293");
        org.apache.commons.math.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math.exception.NotPositiveException((java.lang.Number) 1.444773539659331d);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test294");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED;
        java.lang.Number number6 = null;
        java.lang.Object[] objArray9 = new java.lang.Object[] { (-1.0f), true };
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException10 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, number6, objArray9);
        java.lang.Object[] objArray11 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray9);
        org.apache.commons.math.exception.NoBracketingException noBracketingException12 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (-1.7581226324091723d), 0.0d, (double) 0.99999994f, 5.298342365610589d, objArray11);
        double double13 = noBracketingException12.getFLo();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats14 = org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED;
        java.lang.Number number22 = null;
        java.lang.Object[] objArray25 = new java.lang.Object[] { (-1.0f), true };
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException26 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats21, number22, objArray25);
        java.lang.Object[] objArray27 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray25);
        org.apache.commons.math.exception.NoBracketingException noBracketingException28 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats16, (-1.7581226324091723d), 0.0d, (double) 0.99999994f, 5.298342365610589d, objArray27);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException29 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats14, (java.lang.Number) (-1.0f), objArray27);
        noBracketingException12.addSuppressed((java.lang.Throwable) notFiniteNumberException29);
        double double31 = noBracketingException12.getFHi();
        double double32 = noBracketingException12.getLo();
        double double33 = noBracketingException12.getFHi();
        java.lang.String str34 = noBracketingException12.toString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED));
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.9999999403953552d + "'", double13 == 0.9999999403953552d);
        org.junit.Assert.assertTrue("'" + localizedFormats14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION + "'", localizedFormats14.equals(org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION));
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH + "'", localizedFormats16.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH));
        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED + "'", localizedFormats21.equals(org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED));
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 5.298342365610589d + "'", double31 == 5.298342365610589d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + (-1.7581226324091723d) + "'", double32 == (-1.7581226324091723d));
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 5.298342365610589d + "'", double33 == 5.298342365610589d);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "org.apache.commons.math.exception.NoBracketingException: unable to bracket optimum in line search" + "'", str34.equals("org.apache.commons.math.exception.NoBracketingException: unable to bracket optimum in line search"));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test295");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NO_DATA;
        java.lang.Class<?> wildcardClass1 = localizedFormats0.getClass();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 3.0865652692765765E-41d, (java.lang.Number) (-49.0f), false);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_DATA + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_DATA));
        org.junit.Assert.assertNotNull(wildcardClass1);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test296");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(7L, (-28L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 7L + "'", long2 == 7L);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test297");
        double double2 = org.apache.commons.math.util.FastMath.atan2(10231.0d, 1.0E-5d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.570796325817475d + "'", double2 == 1.570796325817475d);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test298");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.1752011936438014d) + "'", double1 == (-1.1752011936438014d));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test299");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_SUPPORTED_IN_DIMENSION_N;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED;
        java.lang.Number number5 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { (-1.0f), true };
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException9 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats4, number5, objArray8);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException10 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, (java.lang.Number) 107L, objArray8);
        java.lang.Object[] objArray11 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray8);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException12 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 0.9999999995482046d, objArray8);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_SUPPORTED_IN_DIMENSION_N + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_SUPPORTED_IN_DIMENSION_N));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(objArray11);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test300");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_3D_VECTOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.TOO_MUCH_CANCELLATION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ROUNDING_METHOD;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_SIZE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray9 = new java.lang.Object[] { "hi!", localizedFormats4, localizedFormats5, localizedFormats6, localizedFormats7, 10L };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException10 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Number) 1.0f, objArray9);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext11 = maxCountExceededException10.getContext();
        exceptionContext11.setValue("org.apache.commons.math.exception.NumberIsTooLargeException: null is larger than the maximum (0)", (java.lang.Object) '4');
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_OBSERVED_POINTS_IN_SAMPLE;
        exceptionContext11.setValue("", (java.lang.Object) localizedFormats16);
        java.lang.Object obj19 = exceptionContext11.getValue("");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats20 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SHAPE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math.exception.util.LocalizedFormats.TOO_MUCH_CANCELLATION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats24 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ROUNDING_METHOD;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats25 = org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_SIZE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats26 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats27 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray29 = new java.lang.Object[] { "hi!", localizedFormats24, localizedFormats25, localizedFormats26, localizedFormats27, 10L };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException30 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats21, (java.lang.Number) 1.0f, objArray29);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext31 = maxCountExceededException30.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats32 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_SUCCESSES;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats33 = org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats35 = org.apache.commons.math.exception.util.LocalizedFormats.TOO_MUCH_CANCELLATION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats38 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ROUNDING_METHOD;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats39 = org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_SIZE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats40 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats41 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray43 = new java.lang.Object[] { "hi!", localizedFormats38, localizedFormats39, localizedFormats40, localizedFormats41, 10L };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException44 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats35, (java.lang.Number) 1.0f, objArray43);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException45 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats33, (java.lang.Number) (-1.7581226324091723d), objArray43);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats46 = org.apache.commons.math.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT;
        int[] intArray52 = new int[] { (byte) 1, 0, (byte) 10, 1, 0 };
        int[] intArray54 = org.apache.commons.math.util.MathUtils.copyOf(intArray52, (int) '4');
        int[] intArray60 = new int[] { (byte) 1, 0, (byte) 10, 1, 0 };
        int[] intArray62 = org.apache.commons.math.util.MathUtils.copyOf(intArray60, (int) '4');
        int[] intArray68 = new int[] { (-1000602687), 10, 0, (short) 100, (short) 0 };
        double double69 = org.apache.commons.math.util.MathUtils.distance(intArray60, intArray68);
        double double70 = org.apache.commons.math.util.MathUtils.distance(intArray52, intArray68);
        java.lang.Object[] objArray71 = new java.lang.Object[] { (-1.7581226324091723d), localizedFormats46, intArray52 };
        exceptionContext31.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats32, objArray71);
        exceptionContext11.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats20, objArray71);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException74 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray71);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext75 = mathIllegalArgumentException74.getContext();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_3D_VECTOR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_3D_VECTOR));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TOO_MUCH_CANCELLATION + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.TOO_MUCH_CANCELLATION));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ROUNDING_METHOD + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ROUNDING_METHOD));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_SIZE + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_SIZE));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(exceptionContext11);
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_OBSERVED_POINTS_IN_SAMPLE + "'", localizedFormats16.equals(org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_OBSERVED_POINTS_IN_SAMPLE));
        org.junit.Assert.assertTrue("'" + obj19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_OBSERVED_POINTS_IN_SAMPLE + "'", obj19.equals(org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_OBSERVED_POINTS_IN_SAMPLE));
        org.junit.Assert.assertTrue("'" + localizedFormats20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SHAPE + "'", localizedFormats20.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SHAPE));
        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TOO_MUCH_CANCELLATION + "'", localizedFormats21.equals(org.apache.commons.math.exception.util.LocalizedFormats.TOO_MUCH_CANCELLATION));
        org.junit.Assert.assertTrue("'" + localizedFormats24 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ROUNDING_METHOD + "'", localizedFormats24.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ROUNDING_METHOD));
        org.junit.Assert.assertTrue("'" + localizedFormats25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_SIZE + "'", localizedFormats25.equals(org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_SIZE));
        org.junit.Assert.assertTrue("'" + localizedFormats26 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats26.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertTrue("'" + localizedFormats27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES + "'", localizedFormats27.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(exceptionContext31);
        org.junit.Assert.assertTrue("'" + localizedFormats32 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_SUCCESSES + "'", localizedFormats32.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_SUCCESSES));
        org.junit.Assert.assertTrue("'" + localizedFormats33 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER + "'", localizedFormats33.equals(org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER));
        org.junit.Assert.assertTrue("'" + localizedFormats35 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TOO_MUCH_CANCELLATION + "'", localizedFormats35.equals(org.apache.commons.math.exception.util.LocalizedFormats.TOO_MUCH_CANCELLATION));
        org.junit.Assert.assertTrue("'" + localizedFormats38 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ROUNDING_METHOD + "'", localizedFormats38.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ROUNDING_METHOD));
        org.junit.Assert.assertTrue("'" + localizedFormats39 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_SIZE + "'", localizedFormats39.equals(org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_SIZE));
        org.junit.Assert.assertTrue("'" + localizedFormats40 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats40.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertTrue("'" + localizedFormats41 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES + "'", localizedFormats41.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(objArray43);
        org.junit.Assert.assertTrue("'" + localizedFormats46 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT + "'", localizedFormats46.equals(org.apache.commons.math.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT));
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertNotNull(intArray54);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertNotNull(intArray62);
        org.junit.Assert.assertNotNull(intArray68);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 1.000602688000005E9d + "'", double69 == 1.000602688000005E9d);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 1.000602688000005E9d + "'", double70 == 1.000602688000005E9d);
        org.junit.Assert.assertNotNull(objArray71);
        org.junit.Assert.assertNotNull(exceptionContext75);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test301");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 100L);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test302");
        int int2 = org.apache.commons.math.util.FastMath.min(0, (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test303");
        float float3 = org.apache.commons.math.util.MathUtils.round(0.0f, (-1), (int) (short) 0);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 10.0f + "'", float3 == 10.0f);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test304");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 2L);
        double double2 = regulaFalsiSolver1.getMin();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test305");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_NAN;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED;
        java.lang.Number number3 = null;
        java.lang.Object[] objArray6 = new java.lang.Object[] { (-1.0f), true };
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException7 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, number3, objArray6);
        java.lang.Object[] objArray8 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray6);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException9 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1.18608221E8d, objArray6);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_NAN + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_NAN));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED));
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(objArray8);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test306");
        int int1 = org.apache.commons.math.util.FastMath.getExponent(2.718281828459045d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test307");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction1 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        double double3 = regulaFalsiSolver2.getFunctionValueAccuracy();
        double double4 = regulaFalsiSolver2.getAbsoluteAccuracy();
        double double5 = regulaFalsiSolver2.getMin();
        int int6 = regulaFalsiSolver2.getEvaluations();
        double double7 = regulaFalsiSolver2.getStartValue();
        double double8 = regulaFalsiSolver2.getStartValue();
        double double9 = regulaFalsiSolver2.getFunctionValueAccuracy();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction14 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver18 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(1.000602688000005E9d, 1.5707963526808657d, 1.9647605821757634d);
        double double19 = regulaFalsiSolver18.getAbsoluteAccuracy();
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution23 = org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE;
        double double24 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide(1594323, univariateRealFunction14, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver18, (-2.644120693623669d), (double) (-1222L), (-0.1585290151921035d), allowedSolution23);
        double double25 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide(8, univariateRealFunction1, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver2, 4.649056350183434d, (-5.37919489E8d), (-0.7853981633974483d), allowedSolution23);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction27 = null;
        try {
            double double30 = regulaFalsiSolver2.solve((int) ' ', univariateRealFunction27, (double) 7L, (double) 1079574528);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E-15d + "'", double3 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-6d + "'", double4 == 1.0E-6d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0E-15d + "'", double9 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.5707963526808657d + "'", double19 == 1.5707963526808657d);
        org.junit.Assert.assertTrue("'" + allowedSolution23 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE + "'", allowedSolution23.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE));
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + (-2.644120693623669d) + "'", double24 == (-2.644120693623669d));
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 4.649056350183434d + "'", double25 == 4.649056350183434d);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test308");
        double double1 = org.apache.commons.math.util.FastMath.log((double) (-48));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test309");
        int int1 = org.apache.commons.math.util.FastMath.abs(1423250983);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1423250983 + "'", int1 == 1423250983);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test310");
        double double1 = org.apache.commons.math.util.FastMath.log1p(130.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.875197323201151d + "'", double1 == 4.875197323201151d);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test311");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) 97L, 4.2949673E10f, (float) '#');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test312");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double double4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(univariateRealFunction0, 286.4788975654116d, (double) (byte) 100, (-0.5d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test313");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) 537919615, (float) 29, 537919490);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test314");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_2D_INDEX;
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        double[] doubleArray6 = new double[] {};
        double[] doubleArray11 = new double[] { 1.0E-15d, Double.NaN, 5.0d, (byte) 10 };
        double[] doubleArray16 = new double[] { 1.0E-15d, Double.NaN, 5.0d, (byte) 10 };
        double[] doubleArray21 = new double[] { 1.0E-15d, Double.NaN, 5.0d, (byte) 10 };
        double[] doubleArray26 = new double[] { 1.0E-15d, Double.NaN, 5.0d, (byte) 10 };
        double[][] doubleArray27 = new double[][] { doubleArray11, doubleArray16, doubleArray21, doubleArray26 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray6, doubleArray27);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException29 = new org.apache.commons.math.exception.MathIllegalStateException(localizable5, (java.lang.Object[]) doubleArray27);
        org.apache.commons.math.exception.NoBracketingException noBracketingException30 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, 100.07110254777545d, 3.626860407847019d, (double) 35L, (-307.6526555685888d), (java.lang.Object[]) doubleArray27);
        double double31 = noBracketingException30.getFHi();
        java.lang.Throwable[] throwableArray32 = noBracketingException30.getSuppressed();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_2D_INDEX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_2D_INDEX));
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + (-307.6526555685888d) + "'", double31 == (-307.6526555685888d));
        org.junit.Assert.assertNotNull(throwableArray32);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test315");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver0 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction2 = null;
        try {
            double double6 = regulaFalsiSolver0.solve((int) (byte) 100, univariateRealFunction2, (-1.7581226324091723d), 1.1920929665620834E-7d, 1.000000000000007d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test316");
        boolean boolean3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.isSequence((double) (-1.00060269E9f), 1594323.0d, (double) 10L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test317");
        int[] intArray5 = new int[] { (byte) 1, 0, (byte) 10, 1, 0 };
        int[] intArray7 = org.apache.commons.math.util.MathUtils.copyOf(intArray5, (int) '4');
        int[] intArray13 = new int[] { (-1000602687), 10, 0, (short) 100, (short) 0 };
        double double14 = org.apache.commons.math.util.MathUtils.distance(intArray5, intArray13);
        int[] intArray20 = new int[] { (byte) 1, 0, (byte) 10, 1, 0 };
        int[] intArray22 = org.apache.commons.math.util.MathUtils.copyOf(intArray20, (int) '4');
        int[] intArray28 = new int[] { (byte) 1, 0, (byte) 10, 1, 0 };
        int[] intArray30 = org.apache.commons.math.util.MathUtils.copyOf(intArray28, (int) '4');
        int[] intArray36 = new int[] { (-1000602687), 10, 0, (short) 100, (short) 0 };
        double double37 = org.apache.commons.math.util.MathUtils.distance(intArray28, intArray36);
        double double38 = org.apache.commons.math.util.MathUtils.distance(intArray20, intArray36);
        int int39 = org.apache.commons.math.util.MathUtils.distanceInf(intArray13, intArray36);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.000602688000005E9d + "'", double14 == 1.000602688000005E9d);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 1.000602688000005E9d + "'", double37 == 1.000602688000005E9d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 1.000602688000005E9d + "'", double38 == 1.000602688000005E9d);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test318");
        double[] doubleArray2 = new double[] { 10.0d, 0.0d };
        double[] doubleArray6 = new double[] { 1.7182818284590453d, (short) 10, '4' };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray6);
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) (short) 100);
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2, 0);
        double double12 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray11);
        double[] doubleArray15 = new double[] { 10.0d, 0.0d };
        double[] doubleArray19 = new double[] { 1.7182818284590453d, (short) 10, '4' };
        boolean boolean20 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray15, doubleArray19);
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) (short) 100);
        int int23 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        double double24 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray11, doubleArray15);
        double[] doubleArray26 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) (-1072));
        double[] doubleArray29 = new double[] { 10.0d, 0.0d };
        double[] doubleArray33 = new double[] { 1.7182818284590453d, (short) 10, '4' };
        boolean boolean34 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray29, doubleArray33);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray33);
        double[] doubleArray37 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray33, (int) (short) 10);
        double[] doubleArray40 = new double[] { 10.0d, 0.0d };
        double[] doubleArray44 = new double[] { 1.7182818284590453d, (short) 10, '4' };
        boolean boolean45 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray40, doubleArray44);
        double[] doubleArray47 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray40, (double) (short) 100);
        int int48 = org.apache.commons.math.util.MathUtils.hash(doubleArray40);
        boolean boolean49 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray33, doubleArray40);
        double[] doubleArray51 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray40, (-0.6536436208636119d));
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equals(doubleArray26, doubleArray51);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection56 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException58 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 3.0517578145E9d, (java.lang.Number) 2.3458247401995457E41d, 710366363, orderDirection56, true);
        double[] doubleArray63 = new double[] { (-2.0d), 3.141592653589793d, 3.7621956910836314d, 1.1920929E-7f };
        double[] doubleArray68 = new double[] { (-2.0d), 3.141592653589793d, 3.7621956910836314d, 1.1920929E-7f };
        double[] doubleArray73 = new double[] { (-2.0d), 3.141592653589793d, 3.7621956910836314d, 1.1920929E-7f };
        double[][] doubleArray74 = new double[][] { doubleArray63, doubleArray68, doubleArray73 };
        try {
            org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray26, orderDirection56, doubleArray74);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 4 != 2");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1000602687) + "'", int23 == (-1000602687));
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1000602687) + "'", int48 == (-1000602687));
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + orderDirection56 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection56.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray74);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test319");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) 147401637, (-118608222L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-17483046084459414L) + "'", long2 == (-17483046084459414L));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test320");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) 31);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1077870592 + "'", int1 == 1077870592);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test321");
        double double2 = org.apache.commons.math.util.FastMath.scalb(0.0d, 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test322");
        double double4 = org.apache.commons.math.util.MathUtils.linearCombination(3358.2742008679797d, (-2.290822861412639d), 1.1195215262618592d, (double) 8);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-7684.2551420305335d) + "'", double4 == (-7684.2551420305335d));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test323");
        java.lang.Number number0 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 1079689216, 118608221, orderDirection3, true);
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test324");
        double double1 = org.apache.commons.math.util.FastMath.sin((-14.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9906073556948704d) + "'", double1 == (-0.9906073556948704d));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test325");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 147401637);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 8);
        try {
            java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, (long) (-1074790400));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: exponent (-1,074,790,400)");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test326");
        boolean boolean3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.isSequence((double) 4.2949673E10f, 2.3693300629462564d, 29306.291220941606d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test327");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) (-1023), (-0.6536436208636119d));
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction4 = null;
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction9 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver11 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(1.000602688000005E9d);
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution15 = org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE;
        double double16 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide((-118608221), univariateRealFunction9, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver11, 0.0d, (-0.0d), 5.1072502269620796E22d, allowedSolution15);
        try {
            double double17 = regulaFalsiSolver2.solve(5, univariateRealFunction4, (double) 1.0000001f, 1.560487412837878d, 26.799075016572118d, allowedSolution15);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + allowedSolution15 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE + "'", allowedSolution15.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE));
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test328");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) (-1000602687L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }
}

