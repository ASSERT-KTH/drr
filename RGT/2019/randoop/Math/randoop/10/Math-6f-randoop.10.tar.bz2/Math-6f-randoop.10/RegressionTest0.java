import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex1 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.ZeroException; message: zero not allowed here");
        } catch (org.apache.commons.math3.exception.ZeroException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        java.text.NumberFormat numberFormat3 = null;
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat4 = new org.apache.commons.math3.linear.RealVectorFormat("", "hi!", "hi!", numberFormat3);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        int int3 = org.apache.commons.math3.util.Precision.compareTo((double) ' ', (double) (-1L), (double) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        float float1 = org.apache.commons.math3.util.FastMath.nextUp((float) (short) 1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0000001f + "'", float1 == 1.0000001f);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        java.text.NumberFormat numberFormat1 = null;
        java.lang.StringBuffer stringBuffer2 = null;
        java.text.FieldPosition fieldPosition3 = null;
        try {
            java.lang.StringBuffer stringBuffer4 = org.apache.commons.math3.util.CompositeFormat.formatDouble((double) (byte) 10, numberFormat1, stringBuffer2, fieldPosition3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        try {
            org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix1 = new org.apache.commons.math3.linear.DiagonalMatrix((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, arrayRealVector1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        double[] doubleArray1 = new double[] { 1.0d };
        double[] doubleArray4 = new double[] { (short) 10, (byte) -1 };
        double[] doubleArray7 = new double[] { (short) 10, (byte) -1 };
        double[] doubleArray10 = new double[] { (short) 10, (byte) -1 };
        double[] doubleArray13 = new double[] { (short) 10, (byte) -1 };
        double[] doubleArray16 = new double[] { (short) 10, (byte) -1 };
        double[][] doubleArray17 = new double[][] { doubleArray4, doubleArray7, doubleArray10, doubleArray13, doubleArray16 };
        try {
            org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray1, doubleArray17);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 2 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        java.text.ParsePosition parsePosition2 = null;
        try {
            boolean boolean3 = org.apache.commons.math3.util.CompositeFormat.parseFixedstring("", "", parsePosition2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        double double1 = org.apache.commons.math3.util.FastMath.atan(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        double double3 = org.apache.commons.math3.util.Precision.round((double) (byte) 1, 100, 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        double[] doubleArray6 = new double[] { 100.0d, (short) 100, 1L, 1.0000001f, ' ', 1L };
        double[] doubleArray13 = new double[] { 100.0d, (short) 100, 1L, 1.0000001f, ' ', 1L };
        double[] doubleArray20 = new double[] { 100.0d, (short) 100, 1L, 1.0000001f, ' ', 1L };
        double[] doubleArray27 = new double[] { 100.0d, (short) 100, 1L, 1.0000001f, ' ', 1L };
        double[] doubleArray34 = new double[] { 100.0d, (short) 100, 1L, 1.0000001f, ' ', 1L };
        double[][] doubleArray35 = new double[][] { doubleArray6, doubleArray13, doubleArray20, doubleArray27, doubleArray34 };
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex36 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray35);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 6 != 4");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        double double0 = org.apache.commons.math3.util.Precision.SAFE_MIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.2250738585072014E-308d + "'", double0 == 2.2250738585072014E-308d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.apache.commons.math3.util.MathUtils.checkFinite((double) 1.0f);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.apache.commons.math3.linear.AnyMatrix anyMatrix0 = null;
        int[] intArray7 = new int[] { 1, (byte) 0, 10, 1, (short) 100, 1 };
        int[] intArray14 = new int[] { 'a', '4', (short) 0, 'a', (short) 0, (-1) };
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSubMatrixIndex(anyMatrix0, intArray7, intArray14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray14);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex5 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(0, (double) 10, (double) (byte) 10, 10.0d, 1.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.ZeroException; message: zero not allowed here");
        } catch (org.apache.commons.math3.exception.ZeroException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor8 = null;
        try {
            double double9 = array2DRowRealMatrix7.walkInColumnOrder(realMatrixChangingVisitor8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSubMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix7, 1, (int) (short) 0, 0, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooSmallException; message: initial row 1 after final row 0");
        } catch (org.apache.commons.math3.exception.NumberIsTooSmallException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        double double3 = org.apache.commons.math3.util.Precision.round((double) 0, (int) (byte) 100, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        double[] doubleArray0 = null;
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex5 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray0, (double) 10, 0.0d, (double) 1, (double) 0L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        try {
            double double10 = array2DRowRealMatrix7.getEntry(0, (int) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray12 = new double[] { '4', 1.0000001f, 10.0f, 'a' };
        double[][] doubleArray13 = new double[][] { doubleArray12 };
        try {
            array2DRowRealMatrix7.setSubMatrix(doubleArray13, (int) '#', (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        java.lang.Double[] doubleArray1 = new java.lang.Double[] { 100.0d };
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1, (int) (byte) 0, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: 100 is larger than the maximum (1)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        float float2 = org.apache.commons.math3.util.FastMath.min((float) (short) 1, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NoDataException noDataException1 = new org.apache.commons.math3.exception.NoDataException(localizable0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer powellOptimizer2 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer((double) (short) 100, (double) (byte) 1);
        java.io.ObjectInputStream objectInputStream4 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.deserializeRealMatrix((java.lang.Object) powellOptimizer2, "", objectInputStream4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType0 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE;
        org.junit.Assert.assertTrue("'" + goalType0 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE + "'", goalType0.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.PopulationSize populationSize1 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.PopulationSize((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        double double2 = org.apache.commons.math3.util.MathUtils.normalizeAngle((double) 0L, (-1.0d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor8 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        try {
            double double13 = array2DRowRealMatrix7.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor8, (int) (short) 0, (int) (short) 1, 0, (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        java.text.ParsePosition parsePosition1 = null;
        try {
            char char2 = org.apache.commons.math3.util.CompositeFormat.parseNextCharacter("", parsePosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) (short) 1, (java.lang.Number) (byte) 1, false);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        double double1 = org.apache.commons.math3.util.FastMath.asin((double) 100L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray11 = new double[] { (byte) 100, Double.NaN, (byte) 100 };
        try {
            double[] doubleArray12 = array2DRowRealMatrix7.preMultiply(doubleArray11);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 3 != 6");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        double[][] doubleArray2 = org.apache.commons.math3.linear.BlockRealMatrix.createBlocksLayout((int) (short) -1, (int) (short) 10);
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix4 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NoDataException; message: matrix must have at least one row");
        } catch (org.apache.commons.math3.exception.NoDataException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsWithRelativeTolerance(0.0d, 100.0d, (double) (byte) -1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        int int2 = org.apache.commons.math3.util.MathUtils.copySign(0, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.apache.commons.math3.linear.FieldMatrix<org.apache.commons.math3.fraction.Fraction> fractionFieldMatrix0 = null;
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix1 = org.apache.commons.math3.linear.MatrixUtils.fractionMatrixToRealMatrix(fractionFieldMatrix0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray3 = new double[] { 10.0d, (byte) 0 };
        try {
            double[] doubleArray4 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray0, doubleArray3);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 2");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.apache.commons.math3.util.MathUtils.checkFinite((double) (byte) -1);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor8 = null;
        try {
            double double13 = array2DRowRealMatrix7.walkInOptimizedOrder(realMatrixChangingVisitor8, 100, 0, (int) (byte) 1, (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        float float2 = org.apache.commons.math3.util.FastMath.max((float) (byte) 1, (float) '#');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 35.0f + "'", float2 == 35.0f);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex2 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(10, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.ZeroException; message: equal vertices 0 and {1} in simplex configuration");
        } catch (org.apache.commons.math3.exception.ZeroException e) {
        }
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        byte byte2 = org.apache.commons.math3.util.MathUtils.copySign((byte) 1, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[][] doubleArray10 = org.apache.commons.math3.linear.BlockRealMatrix.createBlocksLayout((int) (short) -1, (int) (short) 10);
        try {
            array2DRowRealMatrix7.setSubMatrix(doubleArray10, (int) 'a', 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NoDataException; message: matrix must have at least one row");
        } catch (org.apache.commons.math3.exception.NoDataException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        long long1 = org.apache.commons.math3.util.FastMath.abs(0L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.RealVector realVector9 = null;
        try {
            array2DRowRealMatrix7.setColumnVector((int) (short) 1, realVector9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.apache.commons.math3.linear.RealVector realVector0 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector(realVector0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        byte byte2 = org.apache.commons.math3.util.MathUtils.copySign((byte) 100, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex2 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex((int) (byte) -1, (double) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        try {
            org.apache.commons.math3.linear.LUDecomposition lUDecomposition8 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix7);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.NonSquareMatrixException; message: non square (6x1) matrix");
        } catch (org.apache.commons.math3.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((double) (byte) 0, 0.0d, 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        double double1 = org.apache.commons.math3.util.FastMath.log10((double) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver2 = new org.apache.commons.math3.analysis.solvers.BrentSolver((double) 100L, (double) 'a');
        double double3 = brentSolver2.getStartValue();
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction5 = null;
        try {
            double double8 = brentSolver2.solve((int) ' ', univariateFunction5, 0.0d, (double) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equals((float) (short) 10, (float) 10L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double double8 = array2DRowRealMatrix7.getFrobeniusNorm();
        try {
            org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition10 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix7, 1.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.NonSquareMatrixException; message: non square (6x1) matrix");
        } catch (org.apache.commons.math3.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 61.886993787063204d + "'", double8 == 61.886993787063204d);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        double double1 = org.apache.commons.math3.util.FastMath.log10((double) (-1L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.apache.commons.math3.util.Pair<double[], double[]> doubleArrayPair0 = null;
        try {
            org.apache.commons.math3.util.Pair<double[], double[]> doubleArrayPair1 = new org.apache.commons.math3.util.Pair<double[], double[]>(doubleArrayPair0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor8 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        try {
            double double13 = array2DRowRealMatrix7.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor8, (int) 'a', (int) ' ', (int) (short) 1, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (97)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        double[][] doubleArray16 = array2DRowRealMatrix15.getData();
        double[][] doubleArray17 = array2DRowRealMatrix15.getData();
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = array2DRowRealMatrix7.multiply(array2DRowRealMatrix15);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 6");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN(100.0f, 10.0f, (float) 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        try {
            org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix1 = new org.apache.commons.math3.linear.DiagonalMatrix(0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[][] doubleArray8 = array2DRowRealMatrix7.getData();
        double[][] doubleArray9 = array2DRowRealMatrix7.getData();
        int[] intArray15 = new int[] { 0, (byte) 0, '4', (byte) 0, 0 };
        int[] intArray21 = new int[] { (short) 1, '#', (short) 0, (short) -1, (byte) 1 };
        double[] doubleArray26 = new double[] { (-1L), (-1L), 100, Double.NaN };
        double[] doubleArray31 = new double[] { (-1L), (-1L), 100, Double.NaN };
        double[] doubleArray36 = new double[] { (-1L), (-1L), 100, Double.NaN };
        double[][] doubleArray37 = new double[][] { doubleArray26, doubleArray31, doubleArray36 };
        try {
            array2DRowRealMatrix7.copySubMatrix(intArray15, intArray21, doubleArray37);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        double double8 = org.apache.commons.math3.util.MathArrays.linearCombination((double) 'a', (double) '4', Double.NaN, 0.0d, (double) 1.0f, (double) ' ', (double) '4', 0.0d);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer powellOptimizer2 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer((double) (short) 100, (double) (byte) 1);
        int int3 = powellOptimizer2.getMaxIterations();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2147483647 + "'", int3 == 2147483647);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        long long1 = org.apache.commons.math3.util.FastMath.round((double) 10.0f);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 10L + "'", long1 == 10L);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        double double1 = org.apache.commons.math3.util.FastMath.expm1((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6321205588285577d) + "'", double1 == (-0.6321205588285577d));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        double double2 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.midpoint(2.2250738585072014E-308d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.1125369292536007E-308d + "'", double2 == 1.1125369292536007E-308d);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        double double1 = org.apache.commons.math3.util.FastMath.tanh((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[][] doubleArray8 = array2DRowRealMatrix7.getData();
        double[][] doubleArray9 = array2DRowRealMatrix7.getData();
        double[] doubleArray16 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16);
        try {
            double[] doubleArray18 = array2DRowRealMatrix7.operate(doubleArray16);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 6 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        double[][] doubleArray2 = org.apache.commons.math3.linear.BlockRealMatrix.createBlocksLayout((int) (short) -1, (int) (short) 10);
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex5 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(doubleArray2, 61.886993787063204d, (double) 1.0000001f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: simplex must contain at least one point");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[][] doubleArray8 = array2DRowRealMatrix7.getData();
        double[] doubleArray15 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray15);
        try {
            double[] doubleArray18 = array2DRowRealMatrix7.operate(doubleArray15);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 6 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realMatrix17);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex5 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex((int) (short) 100, 0.0d, (double) (short) 0, (double) (short) 100, 0.0d);
        double[] doubleArray12 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray12);
        try {
            nelderMeadSimplex5.build(doubleArray12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 100 != 6");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray12);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor8 = null;
        try {
            double double9 = array2DRowRealMatrix7.walkInRowOrder(realMatrixChangingVisitor8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((double) (-1.0f), 10.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        double double2 = org.apache.commons.math3.util.FastMath.log(Double.NaN, 1.0d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair> pointVectorValuePairConvergenceChecker1 = null;
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer6 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer((double) 1, pointVectorValuePairConvergenceChecker1, 0.0d, (double) 10.0f, (double) 10L, 0.0d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[][] doubleArray8 = array2DRowRealMatrix7.getData();
        double[][] doubleArray11 = org.apache.commons.math3.linear.BlockRealMatrix.createBlocksLayout((int) (short) -1, (int) (byte) 100);
        try {
            array2DRowRealMatrix7.setSubMatrix(doubleArray11, (-1), (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NoDataException; message: matrix must have at least one row");
        } catch (org.apache.commons.math3.exception.NoDataException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equals((float) 10, (float) (short) 10);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math3.exception.MathInternalError mathInternalError2 = new org.apache.commons.math3.exception.MathInternalError(localizable0, objArray1);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        java.text.NumberFormat numberFormat0 = null;
        try {
            org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat1 = new org.apache.commons.math3.linear.RealMatrixFormat(numberFormat0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        double double1 = org.apache.commons.math3.util.FastMath.log1p(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math3.exception.DimensionMismatchException((int) (short) -1, 1);
        int int3 = dimensionMismatchException2.getDimension();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[][] doubleArray8 = array2DRowRealMatrix7.getData();
        double[][] doubleArray9 = array2DRowRealMatrix7.getData();
        double[] doubleArray16 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16);
        double double18 = array2DRowRealMatrix17.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix7, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix17);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix21 = array2DRowRealMatrix7.power((-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException; message: invalid exponent -1 (must be positive)");
        } catch (org.apache.commons.math3.exception.NotPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 61.886993787063204d + "'", double18 == 61.886993787063204d);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        double double1 = org.apache.commons.math3.util.FastMath.log((double) (-1.0f));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double double8 = array2DRowRealMatrix7.getFrobeniusNorm();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor9 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        try {
            double double14 = array2DRowRealMatrix7.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor9, 1, (int) (short) 1, 1, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 61.886993787063204d + "'", double8 == 61.886993787063204d);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        double[] doubleArray17 = new double[] {};
        try {
            double double18 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray6, doubleArray17);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        try {
            org.apache.commons.math3.optim.univariate.BrentOptimizer brentOptimizer2 = new org.apache.commons.math3.optim.univariate.BrentOptimizer(Double.NaN, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        try {
            org.apache.commons.math3.optim.univariate.BrentOptimizer brentOptimizer2 = new org.apache.commons.math3.optim.univariate.BrentOptimizer(2.2250738585072014E-308d, (double) 35.0f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooSmallException; message: 0 is smaller than the minimum (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooSmallException e) {
        }
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        double double1 = org.apache.commons.math3.util.FastMath.tanh((double) 1.0000001f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7615942060206032d + "'", double1 == 0.7615942060206032d);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equals(0.0d, Double.NaN);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math3.exception.NotPositiveException(localizable0, (java.lang.Number) (byte) 0);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double double8 = array2DRowRealMatrix7.getFrobeniusNorm();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        try {
            org.apache.commons.math3.linear.RealVector realVector12 = array2DRowRealMatrix7.operateTranspose((org.apache.commons.math3.linear.RealVector) arrayRealVector11);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 61.886993787063204d + "'", double8 == 61.886993787063204d);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor8 = null;
        try {
            double double13 = array2DRowRealMatrix7.walkInRowOrder(realMatrixChangingVisitor8, (-1), (int) (short) 10, 1, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        long long2 = org.apache.commons.math3.util.FastMath.max((long) 96, (long) (short) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 96L + "'", long2 == 96L);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        double[][] doubleArray4 = org.apache.commons.math3.linear.BlockRealMatrix.createBlocksLayout((int) (short) -1, (int) (byte) 100);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 1, (int) (byte) -1, doubleArray4, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        org.apache.commons.math3.linear.RealVector realVector5 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector2.combineToSelf((double) 35.0f, (double) 100, realVector5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN(0.0d, (double) 1, (double) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        double[] doubleArray22 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix23 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray22);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair24 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray14, doubleArray22);
        try {
            double[] doubleArray25 = array2DRowRealMatrix7.operate(doubleArray14);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 6 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray22);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.apache.commons.math3.optim.SimpleBounds simpleBounds1 = org.apache.commons.math3.optim.SimpleBounds.unbounded((int) (byte) 10);
        org.junit.Assert.assertNotNull(simpleBounds1);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[][] doubleArray8 = array2DRowRealMatrix7.getData();
        double[][] doubleArray9 = array2DRowRealMatrix7.getData();
        double[] doubleArray16 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16);
        double[] doubleArray24 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray24);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair26 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray16, doubleArray24);
        double[] doubleArray27 = pointVectorValuePair26.getFirst();
        double[] doubleArray28 = pointVectorValuePair26.getPointRef();
        double[] doubleArray35 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray35);
        double[] doubleArray43 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix44 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray43);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair45 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray35, doubleArray43);
        double[] doubleArray46 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray28, doubleArray43);
        try {
            double[] doubleArray47 = array2DRowRealMatrix7.operate(doubleArray28);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 6 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray46);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        double double0 = org.apache.commons.math3.util.Precision.EPSILON;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.1102230246251565E-16d + "'", double0 == 1.1102230246251565E-16d);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        double double1 = org.apache.commons.math3.util.FastMath.cbrt((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        double[] doubleArray0 = null;
        try {
            double double1 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.append((double) 0.0f);
        boolean boolean5 = arrayRealVector2.isNaN();
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor6 = null;
        try {
            double double7 = arrayRealVector2.walkInDefaultOrder(realVectorChangingVisitor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor3 = null;
        try {
            double double4 = arrayRealVector2.walkInDefaultOrder(realVectorPreservingVisitor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.apache.commons.math3.linear.FieldMatrix<org.apache.commons.math3.fraction.BigFraction> bigFractionFieldMatrix0 = null;
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix1 = org.apache.commons.math3.linear.MatrixUtils.bigFractionMatrixToRealMatrix(bigFractionFieldMatrix0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker4 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker((double) ' ', (double) '#');
        org.apache.commons.math3.optim.univariate.BrentOptimizer brentOptimizer5 = new org.apache.commons.math3.optim.univariate.BrentOptimizer((double) 1.0000001f, (double) ' ', (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.univariate.UnivariatePointValuePair>) simpleUnivariateValueChecker4);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex10 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(100, (double) ' ', (double) (short) -1, 0.0d);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex15 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(100, (double) ' ', (double) (short) -1, 0.0d);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex18 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex((int) '#', (double) 100.0f);
        org.apache.commons.math3.analysis.MultivariateVectorFunction multivariateVectorFunction19 = null;
        org.apache.commons.math3.optim.nonlinear.vector.ModelFunction modelFunction20 = new org.apache.commons.math3.optim.nonlinear.vector.ModelFunction(multivariateVectorFunction19);
        double[] doubleArray27 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray27);
        double[] doubleArray35 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray35);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair37 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray27, doubleArray35);
        org.apache.commons.math3.optim.InitialGuess initialGuess38 = new org.apache.commons.math3.optim.InitialGuess(doubleArray27);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex43 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(100, (double) ' ', (double) (short) -1, 0.0d);
        org.apache.commons.math3.optim.OptimizationData[] optimizationDataArray44 = new org.apache.commons.math3.optim.OptimizationData[] { multiDirectionalSimplex10, multiDirectionalSimplex15, nelderMeadSimplex18, modelFunction20, initialGuess38, multiDirectionalSimplex43 };
        try {
            org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair45 = brentOptimizer5.optimize(optimizationDataArray44);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.TooManyEvaluationsException; message: illegal state: maximal count (0) exceeded: evaluations");
        } catch (org.apache.commons.math3.exception.TooManyEvaluationsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(optimizationDataArray44);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        int int1 = org.apache.commons.math3.util.FastMath.getExponent(0.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-127) + "'", int1 == (-127));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double double8 = array2DRowRealMatrix7.getFrobeniusNorm();
        java.lang.String str9 = array2DRowRealMatrix7.toString();
        double[] doubleArray16 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor18 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double19 = array2DRowRealMatrix17.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor18);
        try {
            double double24 = array2DRowRealMatrix7.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor18, (int) (short) 100, (int) (byte) 1, (-127), 96);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 61.886993787063204d + "'", double8 == 61.886993787063204d);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Array2DRowRealMatrix{{32.0},{0.0},{52.0},{-1.0},{10.0},{-1.0}}" + "'", str9.equals("Array2DRowRealMatrix{{32.0},{0.0},{52.0},{-1.0},{10.0},{-1.0}}"));
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((float) (short) 10, (float) 50);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.apache.commons.math3.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number) 1);
        boolean boolean2 = notPositiveException1.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor8 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double9 = array2DRowRealMatrix7.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor8);
        java.io.ObjectOutputStream objectOutputStream10 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.serializeRealMatrix((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix7, objectOutputStream10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer5 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer((double) (short) -1, (double) 10, (double) (-1L), (double) (byte) -1, 0.0d);
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair> pointVectorValuePairConvergenceChecker6 = levenbergMarquardtOptimizer5.getConvergenceChecker();
        int int7 = levenbergMarquardtOptimizer5.getMaxIterations();
        org.junit.Assert.assertNull(pointVectorValuePairConvergenceChecker6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2147483647 + "'", int7 == 2147483647);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker2 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker((double) ' ', (double) '#');
        org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair6 = new org.apache.commons.math3.optim.univariate.UnivariatePointValuePair(0.0d, (double) 1.0f);
        org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair7 = null;
        try {
            boolean boolean8 = simpleUnivariateValueChecker2.converged((int) (byte) 1, univariatePointValuePair6, univariatePointValuePair7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        int int1 = org.apache.commons.math3.util.MathUtils.hash((double) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.append((double) 0.0f);
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor5 = null;
        try {
            double double8 = arrayRealVector2.walkInDefaultOrder(realVectorChangingVisitor5, (int) ' ', (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (32)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[][] doubleArray8 = array2DRowRealMatrix7.getData();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor9 = null;
        try {
            double double14 = array2DRowRealMatrix7.walkInColumnOrder(realMatrixChangingVisitor9, (int) '4', (int) (byte) 0, (int) '4', (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[][] doubleArray8 = array2DRowRealMatrix7.getData();
        double[][] doubleArray9 = array2DRowRealMatrix7.getData();
        double[] doubleArray16 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16);
        double double18 = array2DRowRealMatrix17.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix7, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix17);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor20 = null;
        try {
            double double25 = array2DRowRealMatrix17.walkInColumnOrder(realMatrixChangingVisitor20, (-127), 0, 50, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-127)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 61.886993787063204d + "'", double18 == 61.886993787063204d);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        double[] doubleArray2 = new double[] { 0, (-1.0d) };
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex5 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(doubleArray2, 0.0d, (double) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.ZeroException; message: equal vertices 0 and {1} in simplex configuration");
        } catch (org.apache.commons.math3.exception.ZeroException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        double double1 = org.apache.commons.math3.util.FastMath.cos((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5403023058681398d + "'", double1 == 0.5403023058681398d);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.apache.commons.math3.optim.MaxEval maxEval1 = new org.apache.commons.math3.optim.MaxEval(1);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray15 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        try {
            array2DRowRealMatrix7.setRow((int) (short) 1, doubleArray15);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 1x6 but expected 1x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray15);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        long long1 = org.apache.commons.math3.util.FastMath.round(0.0d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number) (-1.0f));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(localizable0, number1, (java.lang.Number) (short) -1, false);
        boolean boolean5 = numberIsTooLargeException4.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[][] doubleArray8 = array2DRowRealMatrix7.getData();
        double[][] doubleArray9 = array2DRowRealMatrix7.getData();
        double[] doubleArray16 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16);
        double double18 = array2DRowRealMatrix17.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix7, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix17);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor20 = null;
        try {
            double double21 = array2DRowRealMatrix7.walkInRowOrder(realMatrixChangingVisitor20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 61.886993787063204d + "'", double18 == 61.886993787063204d);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[][] doubleArray8 = array2DRowRealMatrix7.getData();
        double[][] doubleArray9 = array2DRowRealMatrix7.getData();
        double[] doubleArray16 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16);
        double double18 = array2DRowRealMatrix17.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix7, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix17);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor20 = null;
        try {
            double double25 = array2DRowRealMatrix17.walkInColumnOrder(realMatrixChangingVisitor20, 50, 0, 1, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (50)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 61.886993787063204d + "'", double18 == 61.886993787063204d);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        float float2 = org.apache.commons.math3.util.FastMath.nextAfter((float) 'a', (double) 100);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 97.00001f + "'", float2 == 97.00001f);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat3 = new org.apache.commons.math3.linear.RealVectorFormat("Array2DRowRealMatrix{{32.0},{0.0},{52.0},{-1.0},{10.0},{-1.0}}", "hi!", "hi!");
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.apache.commons.math3.analysis.function.Sinc sinc0 = new org.apache.commons.math3.analysis.function.Sinc();
        org.apache.commons.math3.analysis.differentiation.DerivativeStructure derivativeStructure1 = null;
        try {
            org.apache.commons.math3.analysis.differentiation.DerivativeStructure derivativeStructure2 = sinc0.value(derivativeStructure1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        double double1 = org.apache.commons.math3.util.FastMath.cbrt(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        double double1 = org.apache.commons.math3.util.FastMath.sqrt((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor8 = null;
        try {
            double double13 = array2DRowRealMatrix7.walkInColumnOrder(realMatrixChangingVisitor8, (-127), (int) (short) 0, (int) '4', (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-127)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        double double2 = org.apache.commons.math3.util.FastMath.hypot((double) (-127), (double) (short) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 127.00393694685216d + "'", double2 == 127.00393694685216d);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        double[] doubleArray17 = pointVectorValuePair16.getValue();
        double[] doubleArray18 = pointVectorValuePair16.getPointRef();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray18);
        org.apache.commons.math3.linear.RealVector realVector21 = arrayRealVector19.mapMultiplyToSelf((double) (byte) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        org.apache.commons.math3.linear.RealVector realVector26 = arrayRealVector24.append((double) 0.0f);
        boolean boolean27 = arrayRealVector24.isNaN();
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = arrayRealVector19.add((org.apache.commons.math3.linear.RealVector) arrayRealVector24);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 6 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector21);
        org.junit.Assert.assertNotNull(realVector26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor8 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double9 = array2DRowRealMatrix7.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor8);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor10 = null;
        try {
            double double15 = array2DRowRealMatrix7.walkInColumnOrder(realMatrixChangingVisitor10, (int) (byte) 10, (int) (byte) 1, (int) (short) -1, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.PopulationSize populationSize1 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.PopulationSize(0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix9 = array2DRowRealMatrix7.getRowMatrix((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver2 = new org.apache.commons.math3.analysis.solvers.BrentSolver((double) 100L, (double) 'a');
        int int3 = brentSolver2.getMaxEvaluations();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        double double1 = org.apache.commons.math3.util.FastMath.sin((double) 2147483647);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7249165551445564d) + "'", double1 == (-0.7249165551445564d));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        java.text.ParsePosition parsePosition1 = null;
        try {
            org.apache.commons.math3.util.CompositeFormat.parseAndIgnoreWhitespace("", parsePosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        double double2 = org.apache.commons.math3.util.FastMath.copySign((double) 96, 1.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 96.0d + "'", double2 == 96.0d);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        int[] intArray3 = new int[] { (byte) 1, (byte) 100, '4' };
        int[] intArray8 = new int[] { 'a', (short) 1, (byte) 100, 'a' };
        double double9 = org.apache.commons.math3.util.MathArrays.distance(intArray3, intArray8);
        org.apache.commons.math3.random.MersenneTwister mersenneTwister10 = new org.apache.commons.math3.random.MersenneTwister(intArray3);
        double double11 = mersenneTwister10.nextGaussian();
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 146.01712228365548d + "'", double9 == 146.01712228365548d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-1.0728086555169287d) + "'", double11 == (-1.0728086555169287d));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.apache.commons.math3.linear.SingularMatrixException singularMatrixException0 = new org.apache.commons.math3.linear.SingularMatrixException();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext1 = singularMatrixException0.getContext();
        org.junit.Assert.assertNotNull(exceptionContext1);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        double[] doubleArray0 = null;
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix1 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        double double1 = org.apache.commons.math3.util.FastMath.nextUp((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double double8 = array2DRowRealMatrix7.getFrobeniusNorm();
        java.lang.String str9 = array2DRowRealMatrix7.toString();
        double[] doubleArray17 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray17);
        double[] doubleArray25 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair27 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray17, doubleArray25);
        double[] doubleArray28 = pointVectorValuePair27.getValue();
        double[] doubleArray29 = pointVectorValuePair27.getPointRef();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray29);
        try {
            array2DRowRealMatrix7.setRowVector((int) (short) -1, (org.apache.commons.math3.linear.RealVector) arrayRealVector30);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 61.886993787063204d + "'", double8 == 61.886993787063204d);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Array2DRowRealMatrix{{32.0},{0.0},{52.0},{-1.0},{10.0},{-1.0}}" + "'", str9.equals("Array2DRowRealMatrix{{32.0},{0.0},{52.0},{-1.0},{10.0},{-1.0}}"));
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        double[][] doubleArray2 = org.apache.commons.math3.linear.BlockRealMatrix.createBlocksLayout((int) (short) -1, (int) (byte) 100);
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex3 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray2);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: simplex must contain at least one point");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        double double1 = org.apache.commons.math3.util.FastMath.nextUp((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9999999999999999d) + "'", double1 == (-0.9999999999999999d));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        int int1 = org.apache.commons.math3.util.FastMath.round((float) (-1L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection17 = org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING;
        double[] doubleArray24 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray24);
        double[][] doubleArray26 = array2DRowRealMatrix25.getData();
        double[][] doubleArray27 = array2DRowRealMatrix25.getData();
        try {
            org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray6, orderDirection17, doubleArray27);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 6");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + orderDirection17 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING + "'", orderDirection17.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        float float2 = org.apache.commons.math3.util.Precision.round(1.0f, (int) ' ');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        double[] doubleArray17 = pointVectorValuePair16.getValue();
        double[] doubleArray18 = pointVectorValuePair16.getPointRef();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray18);
        org.apache.commons.math3.linear.RealVector realVector21 = arrayRealVector19.mapMultiplyToSelf((double) (byte) 1);
        try {
            double double23 = arrayRealVector19.getEntry((int) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector21);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        double double1 = org.apache.commons.math3.util.FastMath.nextUp((-1.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9999999999999999d) + "'", double1 == (-0.9999999999999999d));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector2.addToEntry(0, (double) 1.0f);
        arrayRealVector2.unitize();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        org.apache.commons.math3.linear.RealVector realVector11 = arrayRealVector9.append((double) 0.0f);
        try {
            double double12 = arrayRealVector2.getL1Distance(realVector11);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 2");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realVector11);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        try {
            org.apache.commons.math3.optim.SimpleVectorValueChecker simpleVectorValueChecker3 = new org.apache.commons.math3.optim.SimpleVectorValueChecker(146.01712228365548d, (double) 0.14566922f, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        int int0 = org.apache.commons.math3.linear.BlockFieldMatrix.BLOCK_SIZE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 36 + "'", int0 == 36);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        double[] doubleArray0 = null;
        try {
            double[] doubleArray1 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = new org.apache.commons.math3.linear.RealVectorFormat();
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.apache.commons.math3.linear.NonSymmetricMatrixException nonSymmetricMatrixException3 = new org.apache.commons.math3.linear.NonSymmetricMatrixException((int) (byte) 1, 0, 1.1102230246251565E-16d);
        double double4 = nonSymmetricMatrixException3.getThreshold();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.1102230246251565E-16d + "'", double4 == 1.1102230246251565E-16d);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        int int1 = org.apache.commons.math3.util.MathUtils.hash((double) 96);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1079508992 + "'", int1 == 1079508992);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        double double1 = org.apache.commons.math3.util.FastMath.tan(4.9E-324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        double[] doubleArray17 = pointVectorValuePair16.getValue();
        double[] doubleArray18 = pointVectorValuePair16.getPointRef();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray18);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector19);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor21 = null;
        try {
            double double22 = arrayRealVector19.walkInOptimizedOrder(realVectorPreservingVisitor21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver2 = new org.apache.commons.math3.analysis.solvers.BrentSolver((double) 100L, (double) 'a');
        double double3 = brentSolver2.getStartValue();
        int int4 = brentSolver2.getMaxEvaluations();
        double double5 = brentSolver2.getMax();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        double double2 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.midpoint((double) (byte) 0, (double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.5d) + "'", double2 == (-0.5d));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        double[] doubleArray17 = pointVectorValuePair16.getValue();
        double[] doubleArray18 = pointVectorValuePair16.getPointRef();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray18);
        try {
            org.apache.commons.math3.util.MathArrays.checkPositive(doubleArray18);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        double[] doubleArray17 = pointVectorValuePair16.getValue();
        double[] doubleArray18 = pointVectorValuePair16.getPointRef();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray18);
        double[] doubleArray26 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix27 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray26);
        double[] doubleArray34 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix35 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray34);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair36 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray26, doubleArray34);
        double[] doubleArray37 = pointVectorValuePair36.getValue();
        org.apache.commons.math3.linear.RealVector realVector38 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray37);
        double double39 = org.apache.commons.math3.util.MathArrays.linearCombination(doubleArray18, doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(realVector38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 3830.0d + "'", double39 == 3830.0d);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        double double3 = org.apache.commons.math3.util.Precision.round(0.0d, (int) (short) 100, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        long long2 = org.apache.commons.math3.util.MathUtils.copySign(0L, (long) (short) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) (short) 10, (java.lang.Number) 100.0f, true);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        org.apache.commons.math3.linear.RealVector realVector7 = arrayRealVector5.append((double) 0.0f);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = arrayRealVector2.ebeDivide(realVector7);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 2");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realVector7);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        double[] doubleArray17 = pointVectorValuePair16.getValue();
        double[] doubleArray18 = pointVectorValuePair16.getPointRef();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray18);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector19);
        try {
            org.apache.commons.math3.linear.RealVector realVector23 = arrayRealVector20.getSubVector(96, 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (96)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        try {
            org.apache.commons.math3.util.MathArrays.checkPositive(doubleArray6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.apache.commons.math3.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math3.exception.TooManyEvaluationsException((java.lang.Number) 100);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext2 = tooManyEvaluationsException1.getContext();
        org.junit.Assert.assertNotNull(exceptionContext2);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        double double2 = org.apache.commons.math3.util.FastMath.max((-0.5d), 0.7615942060206032d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.7615942060206032d + "'", double2 == 0.7615942060206032d);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[][] doubleArray8 = array2DRowRealMatrix7.getData();
        double[] doubleArray15 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        double double17 = array2DRowRealMatrix16.getFrobeniusNorm();
        java.lang.String str18 = array2DRowRealMatrix16.toString();
        org.apache.commons.math3.linear.RealMatrix realMatrix19 = array2DRowRealMatrix7.subtract((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix16);
        try {
            org.apache.commons.math3.linear.LUDecomposition lUDecomposition21 = new org.apache.commons.math3.linear.LUDecomposition(realMatrix19, (double) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.NonSquareMatrixException; message: non square (6x1) matrix");
        } catch (org.apache.commons.math3.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 61.886993787063204d + "'", double17 == 61.886993787063204d);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Array2DRowRealMatrix{{32.0},{0.0},{52.0},{-1.0},{10.0},{-1.0}}" + "'", str18.equals("Array2DRowRealMatrix{{32.0},{0.0},{52.0},{-1.0},{10.0},{-1.0}}"));
        org.junit.Assert.assertNotNull(realMatrix19);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((float) (-1), (float) (short) 10);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[][] doubleArray8 = array2DRowRealMatrix7.getData();
        double[][] doubleArray9 = array2DRowRealMatrix7.getData();
        double[] doubleArray16 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16);
        double double18 = array2DRowRealMatrix17.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix7, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix17);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor20 = null;
        try {
            double double21 = array2DRowRealMatrix7.walkInRowOrder(realMatrixChangingVisitor20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 61.886993787063204d + "'", double18 == 61.886993787063204d);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 100.0f, (java.lang.Number) 1.0d, false);
        boolean boolean5 = numberIsTooLargeException4.getBoundIsAllowed();
        java.lang.Number number6 = numberIsTooLargeException4.getMax();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 1.0d + "'", number6.equals(1.0d));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equals((double) (short) 0, (double) '4');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula0 = null;
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker1 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer2 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, pointValuePairConvergenceChecker1);
        double[] doubleArray9 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray9);
        double[] doubleArray17 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray17);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair19 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray9, doubleArray17);
        org.apache.commons.math3.optim.InitialGuess initialGuess20 = new org.apache.commons.math3.optim.InitialGuess(doubleArray9);
        org.apache.commons.math3.optim.InitialGuess initialGuess21 = new org.apache.commons.math3.optim.InitialGuess(doubleArray9);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds23 = org.apache.commons.math3.optim.SimpleBounds.unbounded((int) (byte) 10);
        org.apache.commons.math3.optim.OptimizationData[] optimizationDataArray24 = new org.apache.commons.math3.optim.OptimizationData[] { initialGuess21, simpleBounds23 };
        try {
            org.apache.commons.math3.optim.PointValuePair pointValuePair25 = nonLinearConjugateGradientOptimizer2.optimize(optimizationDataArray24);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 10 != 6");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(simpleBounds23);
        org.junit.Assert.assertNotNull(optimizationDataArray24);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 100L, (java.lang.Number) 0, false);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector2.addToEntry(0, (double) 1.0f);
        double double6 = arrayRealVector2.getNorm();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 11.0d + "'", double6 == 11.0d);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        double double1 = org.apache.commons.math3.util.FastMath.acos((double) 35.0f);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        int int2 = org.apache.commons.math3.util.MathUtils.copySign((int) (byte) 0, 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        double[] doubleArray23 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray23);
        double[] doubleArray31 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray31);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair33 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray23, doubleArray31);
        double[] doubleArray34 = pointVectorValuePair33.getFirst();
        double[] doubleArray35 = pointVectorValuePair33.getPointRef();
        double[] doubleArray42 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix43 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray42);
        double[] doubleArray50 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix51 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray50);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair52 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray42, doubleArray50);
        double[] doubleArray53 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray35, doubleArray50);
        double[] doubleArray54 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray14, doubleArray50);
        double[] doubleArray61 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix62 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray61);
        double[] doubleArray69 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix70 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray69);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair71 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray61, doubleArray69);
        double double72 = org.apache.commons.math3.util.MathArrays.linearCombination(doubleArray50, doubleArray61);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection73 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        boolean boolean76 = org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray61, orderDirection73, true, false);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 3830.0d + "'", double72 == 3830.0d);
        org.junit.Assert.assertTrue("'" + orderDirection73 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection73.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6, true);
        double[] doubleArray25 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double[] doubleArray33 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray33);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair35 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray25, doubleArray33);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix37 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray25, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix38 = diagonalMatrix18.add(diagonalMatrix37);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor39 = null;
        try {
            double double44 = diagonalMatrix37.walkInColumnOrder(realMatrixChangingVisitor39, (int) '#', (int) ' ', (int) (byte) 100, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(diagonalMatrix38);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray2 = new java.lang.Object[] {};
        org.apache.commons.math3.exception.MathInternalError mathInternalError3 = new org.apache.commons.math3.exception.MathInternalError(localizable1, objArray2);
        java.lang.Throwable[] throwableArray4 = mathInternalError3.getSuppressed();
        org.apache.commons.math3.exception.MathUnsupportedOperationException mathUnsupportedOperationException5 = new org.apache.commons.math3.exception.MathUnsupportedOperationException(localizable0, (java.lang.Object[]) throwableArray4);
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(throwableArray4);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[][] doubleArray8 = array2DRowRealMatrix7.getData();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector12.addToEntry(0, (double) 1.0f);
        double[] doubleArray22 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix23 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray22);
        double[][] doubleArray24 = array2DRowRealMatrix23.getData();
        double[][] doubleArray25 = array2DRowRealMatrix23.getData();
        double[] doubleArray32 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray32);
        double double34 = array2DRowRealMatrix33.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix23, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix33);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector39.addToEntry(0, (double) 1.0f);
        arrayRealVector39.unitize();
        array2DRowRealMatrix23.setRowVector(0, (org.apache.commons.math3.linear.RealVector) arrayRealVector39);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = arrayRealVector12.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector39);
        try {
            array2DRowRealMatrix7.setRowVector(96, (org.apache.commons.math3.linear.RealVector) arrayRealVector45);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (96)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 61.886993787063204d + "'", double34 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(arrayRealVector45);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        double double1 = org.apache.commons.math3.util.FastMath.atan((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[][] doubleArray8 = array2DRowRealMatrix7.getData();
        double[][] doubleArray9 = array2DRowRealMatrix7.getData();
        double[] doubleArray16 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16);
        double double18 = array2DRowRealMatrix17.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix7, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix17);
        try {
            org.apache.commons.math3.optim.nonlinear.vector.Weight weight20 = new org.apache.commons.math3.optim.nonlinear.vector.Weight((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix17);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.NonSquareMatrixException; message: non square (1x6) matrix");
        } catch (org.apache.commons.math3.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 61.886993787063204d + "'", double18 == 61.886993787063204d);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        double double2 = org.apache.commons.math3.util.FastMath.copySign(146.01712228365548d, (double) 0.14566922f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 146.01712228365548d + "'", double2 == 146.01712228365548d);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        double[] doubleArray23 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray23);
        double[] doubleArray31 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray31);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair33 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray23, doubleArray31);
        double[] doubleArray34 = pointVectorValuePair33.getFirst();
        double[] doubleArray35 = pointVectorValuePair33.getPointRef();
        double[] doubleArray42 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix43 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray42);
        double[] doubleArray50 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix51 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray50);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair52 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray42, doubleArray50);
        double[] doubleArray53 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray35, doubleArray50);
        double[] doubleArray54 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray14, doubleArray50);
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex55 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray50);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.ZeroException; message: equal vertices 0 and {1} in simplex configuration");
        } catch (org.apache.commons.math3.exception.ZeroException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray54);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        double double3 = org.apache.commons.math3.util.Precision.round((double) (short) 1, (int) (short) -1, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double double8 = array2DRowRealMatrix7.getFrobeniusNorm();
        double[] doubleArray15 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        double[][] doubleArray17 = array2DRowRealMatrix16.getData();
        double[][] doubleArray18 = array2DRowRealMatrix16.getData();
        double[] doubleArray25 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double double27 = array2DRowRealMatrix26.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix16, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix26);
        org.apache.commons.math3.linear.RealMatrix realMatrix29 = array2DRowRealMatrix7.add((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix16);
        boolean boolean30 = array2DRowRealMatrix7.isSquare();
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix7, 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 61.886993787063204d + "'", double8 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 61.886993787063204d + "'", double27 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        java.util.Locale locale0 = null;
        try {
            org.apache.commons.math3.linear.RealVectorFormat realVectorFormat1 = org.apache.commons.math3.linear.RealVectorFormat.getInstance(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray5 = null;
        org.apache.commons.math3.exception.NoBracketingException noBracketingException6 = new org.apache.commons.math3.exception.NoBracketingException(localizable0, (double) 96L, Double.NaN, (double) (byte) 0, 0.0d, objArray5);
        double double7 = noBracketingException6.getFHi();
        double double8 = noBracketingException6.getFLo();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.apache.commons.math3.analysis.function.Sinc sinc0 = new org.apache.commons.math3.analysis.function.Sinc();
        org.apache.commons.math3.optim.univariate.UnivariateObjectiveFunction univariateObjectiveFunction1 = new org.apache.commons.math3.optim.univariate.UnivariateObjectiveFunction((org.apache.commons.math3.analysis.UnivariateFunction) sinc0);
        try {
            org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.verifyBracketing((org.apache.commons.math3.analysis.UnivariateFunction) sinc0, (double) 1.0f, (double) (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [1, -1]");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        double double1 = org.apache.commons.math3.util.FastMath.floor((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        double[] doubleArray17 = pointVectorValuePair16.getValue();
        double[] doubleArray18 = pointVectorValuePair16.getPointRef();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray18);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector19);
        org.apache.commons.math3.linear.RealVector realVector22 = arrayRealVector20.append((double) 36);
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor23 = null;
        try {
            double double26 = arrayRealVector20.walkInOptimizedOrder(realVectorChangingVisitor23, (int) (short) 10, 36);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector22);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        org.apache.commons.math3.optim.InitialGuess initialGuess17 = new org.apache.commons.math3.optim.InitialGuess(doubleArray6);
        double[] doubleArray18 = initialGuess17.getInitialGuess();
        double[] doubleArray19 = initialGuess17.getInitialGuess();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        java.util.Locale locale0 = null;
        try {
            org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat1 = org.apache.commons.math3.linear.RealMatrixFormat.getInstance(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver0 = new org.apache.commons.math3.analysis.solvers.BrentSolver();
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math3.random.MersenneTwister(100);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        int[] intArray3 = new int[] { (byte) 1, (byte) 100, '4' };
        int[] intArray8 = new int[] { 'a', (short) 1, (byte) 100, 'a' };
        double double9 = org.apache.commons.math3.util.MathArrays.distance(intArray3, intArray8);
        org.apache.commons.math3.random.MersenneTwister mersenneTwister10 = new org.apache.commons.math3.random.MersenneTwister(intArray3);
        try {
            int int12 = mersenneTwister10.nextInt(0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 146.01712228365548d + "'", double9 == 146.01712228365548d);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        double double1 = org.apache.commons.math3.util.FastMath.log1p((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector2.addToEntry(0, (double) 1.0f);
        double[] doubleArray12 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray12);
        double[][] doubleArray14 = array2DRowRealMatrix13.getData();
        double[][] doubleArray15 = array2DRowRealMatrix13.getData();
        double[] doubleArray22 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix23 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray22);
        double double24 = array2DRowRealMatrix23.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix13, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix23);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector29.addToEntry(0, (double) 1.0f);
        arrayRealVector29.unitize();
        array2DRowRealMatrix13.setRowVector(0, (org.apache.commons.math3.linear.RealVector) arrayRealVector29);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = arrayRealVector2.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector29);
        double[] doubleArray36 = arrayRealVector29.toArray();
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor37 = null;
        try {
            double double38 = arrayRealVector29.walkInDefaultOrder(realVectorChangingVisitor37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 61.886993787063204d + "'", double24 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(arrayRealVector35);
        org.junit.Assert.assertNotNull(doubleArray36);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        double double2 = org.apache.commons.math3.util.FastMath.pow((-0.6321205588285577d), 35);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0665888468632587E-7d) + "'", double2 == (-1.0665888468632587E-7d));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        double[] doubleArray17 = pointVectorValuePair16.getValue();
        double[] doubleArray18 = pointVectorValuePair16.getPointRef();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray18);
        org.apache.commons.math3.linear.RealVector realVector21 = arrayRealVector19.mapMultiplyToSelf((double) (byte) 1);
        double[] doubleArray29 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix30 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray29);
        double[] doubleArray37 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix38 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray37);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair39 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray29, doubleArray37);
        double[] doubleArray40 = pointVectorValuePair39.getValue();
        org.apache.commons.math3.linear.RealVector realVector41 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray40);
        arrayRealVector19.setSubVector(0, realVector41);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector45.addToEntry(0, (double) 1.0f);
        double[] doubleArray55 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix56 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray55);
        double[][] doubleArray57 = array2DRowRealMatrix56.getData();
        double[][] doubleArray58 = array2DRowRealMatrix56.getData();
        double[] doubleArray65 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix66 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray65);
        double double67 = array2DRowRealMatrix66.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix56, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix66);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector72 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector72.addToEntry(0, (double) 1.0f);
        arrayRealVector72.unitize();
        array2DRowRealMatrix56.setRowVector(0, (org.apache.commons.math3.linear.RealVector) arrayRealVector72);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector78 = arrayRealVector45.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector72);
        org.apache.commons.math3.linear.RealVector realVector79 = arrayRealVector19.append((org.apache.commons.math3.linear.RealVector) arrayRealVector72);
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor80 = null;
        try {
            double double83 = arrayRealVector72.walkInOptimizedOrder(realVectorChangingVisitor80, 10, 1079508992);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector21);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(realVector41);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 61.886993787063204d + "'", double67 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(arrayRealVector78);
        org.junit.Assert.assertNotNull(realVector79);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        float float1 = org.apache.commons.math3.util.FastMath.ulp((float) 10);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 9.536743E-7f + "'", float1 == 9.536743E-7f);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.apache.commons.math3.util.Incrementor.MaxCountExceededCallback maxCountExceededCallback1 = null;
        try {
            org.apache.commons.math3.util.Incrementor incrementor2 = new org.apache.commons.math3.util.Incrementor((int) (short) 100, maxCountExceededCallback1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) (-0.6321205588285577d), (java.lang.Number) (-1.0f), false);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        long long2 = org.apache.commons.math3.util.MathUtils.copySign(0L, (-1L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[][] doubleArray8 = array2DRowRealMatrix7.getData();
        double[][] doubleArray9 = array2DRowRealMatrix7.getData();
        double[] doubleArray16 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16);
        double double18 = array2DRowRealMatrix17.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix7, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector23.addToEntry(0, (double) 1.0f);
        arrayRealVector23.unitize();
        array2DRowRealMatrix7.setRowVector(0, (org.apache.commons.math3.linear.RealVector) arrayRealVector23);
        try {
            double double30 = arrayRealVector23.getEntry((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 61.886993787063204d + "'", double18 == 61.886993787063204d);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        int[] intArray1 = new int[] { (byte) 100 };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister2 = new org.apache.commons.math3.random.MersenneTwister(intArray1);
        float float3 = mersenneTwister2.nextFloat();
        mersenneTwister2.clear();
        int[] intArray8 = new int[] { (byte) 1, (byte) 100, '4' };
        int[] intArray13 = new int[] { 'a', (short) 1, (byte) 100, 'a' };
        double double14 = org.apache.commons.math3.util.MathArrays.distance(intArray8, intArray13);
        org.apache.commons.math3.random.MersenneTwister mersenneTwister15 = new org.apache.commons.math3.random.MersenneTwister(intArray8);
        mersenneTwister2.setSeed(intArray8);
        long long17 = mersenneTwister2.nextLong();
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.14566922f + "'", float3 == 0.14566922f);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 146.01712228365548d + "'", double14 == 146.01712228365548d);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-9090371258452850456L) + "'", long17 == (-9090371258452850456L));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((float) 36, (float) (short) 1, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        try {
            double double3 = org.apache.commons.math3.util.Precision.round((double) 'a', 35, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        double double1 = org.apache.commons.math3.util.FastMath.log(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[][] doubleArray8 = array2DRowRealMatrix7.getData();
        double[] doubleArray16 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16);
        double[][] doubleArray18 = array2DRowRealMatrix17.getData();
        double[][] doubleArray19 = array2DRowRealMatrix17.getData();
        double[] doubleArray26 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix27 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray26);
        double[] doubleArray34 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix35 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray34);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair36 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray26, doubleArray34);
        double[] doubleArray37 = pointVectorValuePair36.getFirst();
        double[] doubleArray38 = array2DRowRealMatrix17.preMultiply(doubleArray37);
        try {
            array2DRowRealMatrix7.setRowMatrix((int) (byte) 1, (org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix17);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 6x1 but expected 1x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        double[] doubleArray0 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector3.addToEntry(0, (double) 1.0f);
        double[] doubleArray13 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13);
        double[][] doubleArray15 = array2DRowRealMatrix14.getData();
        double[][] doubleArray16 = array2DRowRealMatrix14.getData();
        double[] doubleArray23 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray23);
        double double25 = array2DRowRealMatrix24.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix14, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector30.addToEntry(0, (double) 1.0f);
        arrayRealVector30.unitize();
        array2DRowRealMatrix14.setRowVector(0, (org.apache.commons.math3.linear.RealVector) arrayRealVector30);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = arrayRealVector3.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector30);
        double[] doubleArray37 = arrayRealVector30.toArray();
        try {
            double[] doubleArray38 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray0, doubleArray37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 61.886993787063204d + "'", double25 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(arrayRealVector36);
        org.junit.Assert.assertNotNull(doubleArray37);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6, true);
        double[] doubleArray25 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double[][] doubleArray27 = array2DRowRealMatrix26.getData();
        double[][] doubleArray28 = array2DRowRealMatrix26.getData();
        double[] doubleArray35 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray35);
        double[] doubleArray43 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix44 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray43);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair45 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray35, doubleArray43);
        double[] doubleArray46 = pointVectorValuePair45.getFirst();
        double[] doubleArray47 = pointVectorValuePair45.getPointRef();
        double[] doubleArray54 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix55 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray54);
        double[] doubleArray62 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix63 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray62);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair64 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray54, doubleArray62);
        double[] doubleArray65 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray47, doubleArray62);
        double[] doubleArray66 = array2DRowRealMatrix26.preMultiply(doubleArray62);
        try {
            double[] doubleArray67 = diagonalMatrix18.operate(doubleArray66);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 6 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray66);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double double8 = array2DRowRealMatrix7.getFrobeniusNorm();
        java.lang.String str9 = array2DRowRealMatrix7.toString();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector12.addToEntry(0, (double) 1.0f);
        double[] doubleArray22 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix23 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray22);
        double[][] doubleArray24 = array2DRowRealMatrix23.getData();
        double[][] doubleArray25 = array2DRowRealMatrix23.getData();
        double[] doubleArray32 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray32);
        double double34 = array2DRowRealMatrix33.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix23, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix33);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector39.addToEntry(0, (double) 1.0f);
        arrayRealVector39.unitize();
        array2DRowRealMatrix23.setRowVector(0, (org.apache.commons.math3.linear.RealVector) arrayRealVector39);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = arrayRealVector12.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector39);
        try {
            org.apache.commons.math3.linear.RealVector realVector46 = array2DRowRealMatrix7.operateTranspose((org.apache.commons.math3.linear.RealVector) arrayRealVector39);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 61.886993787063204d + "'", double8 == 61.886993787063204d);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Array2DRowRealMatrix{{32.0},{0.0},{52.0},{-1.0},{10.0},{-1.0}}" + "'", str9.equals("Array2DRowRealMatrix{{32.0},{0.0},{52.0},{-1.0},{10.0},{-1.0}}"));
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 61.886993787063204d + "'", double34 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(arrayRealVector45);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker2 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker(100.0d, (double) 50);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        double double1 = org.apache.commons.math3.util.FastMath.sin((double) 96);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9835877454343449d + "'", double1 == 0.9835877454343449d);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat3 = new org.apache.commons.math3.linear.RealVectorFormat("", "Array2DRowRealMatrix{{32.0},{0.0},{52.0},{-1.0},{10.0},{-1.0}}", "");
        java.lang.String str4 = realVectorFormat3.getSeparator();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6, true);
        double[] doubleArray25 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        org.apache.commons.math3.linear.RealMatrix realMatrix27 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray25);
        org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math3.linear.AnyMatrix) diagonalMatrix18, (org.apache.commons.math3.linear.AnyMatrix) realMatrix27);
        double[] doubleArray35 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray35);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor37 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double38 = array2DRowRealMatrix36.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor37);
        try {
            double double43 = diagonalMatrix18.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor37, (int) '#', (-1), (int) (short) 100, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realMatrix27);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        double double6 = org.apache.commons.math3.util.MathArrays.linearCombination((double) 1.0f, 0.9835877454343449d, (double) (short) 1, 96.0d, (-0.6321205588285577d), (double) 5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 93.82298495129156d + "'", double6 == 93.82298495129156d);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.apache.commons.math3.util.Incrementor.MaxCountExceededCallback maxCountExceededCallback1 = null;
        try {
            org.apache.commons.math3.util.Incrementor incrementor2 = new org.apache.commons.math3.util.Incrementor(5, maxCountExceededCallback1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex1 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(10);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double double8 = array2DRowRealMatrix7.getFrobeniusNorm();
        double[] doubleArray15 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        double[][] doubleArray17 = array2DRowRealMatrix16.getData();
        double[][] doubleArray18 = array2DRowRealMatrix16.getData();
        double[] doubleArray25 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double double27 = array2DRowRealMatrix26.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix16, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix26);
        org.apache.commons.math3.linear.RealMatrix realMatrix29 = array2DRowRealMatrix7.add((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix16);
        double double30 = array2DRowRealMatrix7.getNorm();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 61.886993787063204d + "'", double8 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 61.886993787063204d + "'", double27 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 96.0d + "'", double30 == 96.0d);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        double double2 = org.apache.commons.math3.util.MathUtils.normalizeAngle(96.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.7522203923062136d + "'", double2 == 1.7522203923062136d);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        double double6 = org.apache.commons.math3.util.MathArrays.linearCombination(83.86684335012045d, (double) (-127), (double) (short) 100, (-1.0d), (double) (-1.0f), (double) 10.0f);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-10761.089105465297d) + "'", double6 == (-10761.089105465297d));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        double[] doubleArray17 = pointVectorValuePair16.getValue();
        double[] doubleArray18 = pointVectorValuePair16.getPointRef();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray18);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector19);
        double double21 = arrayRealVector20.getMaxValue();
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor22 = null;
        try {
            double double25 = arrayRealVector20.walkInDefaultOrder(realVectorChangingVisitor22, (int) (byte) 100, 1079508992);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 52.0d + "'", double21 == 52.0d);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula0 = null;
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker1 = null;
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver4 = new org.apache.commons.math3.analysis.solvers.BrentSolver((double) 100L, (double) 'a');
        double double5 = brentSolver4.getStartValue();
        int int6 = brentSolver4.getEvaluations();
        double double7 = brentSolver4.getAbsoluteAccuracy();
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer8 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, pointValuePairConvergenceChecker1, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver4);
        org.apache.commons.math3.analysis.function.Sinc sinc9 = new org.apache.commons.math3.analysis.function.Sinc();
        org.apache.commons.math3.optim.univariate.UnivariateObjectiveFunction univariateObjectiveFunction10 = new org.apache.commons.math3.optim.univariate.UnivariateObjectiveFunction((org.apache.commons.math3.analysis.UnivariateFunction) sinc9);
        double[] doubleArray17 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray17);
        double[] doubleArray25 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair27 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray17, doubleArray25);
        org.apache.commons.math3.optim.InitialGuess initialGuess28 = new org.apache.commons.math3.optim.InitialGuess(doubleArray17);
        double[] doubleArray29 = initialGuess28.getInitialGuess();
        double[] doubleArray30 = initialGuess28.getInitialGuess();
        double[] doubleArray37 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix38 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray37);
        double[] doubleArray45 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix46 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray45);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair47 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray37, doubleArray45);
        org.apache.commons.math3.optim.InitialGuess initialGuess48 = new org.apache.commons.math3.optim.InitialGuess(doubleArray37);
        double[] doubleArray49 = initialGuess48.getInitialGuess();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex52 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex((int) '#', (double) 100.0f);
        org.apache.commons.math3.analysis.function.Sinc sinc53 = new org.apache.commons.math3.analysis.function.Sinc();
        org.apache.commons.math3.optim.univariate.UnivariateObjectiveFunction univariateObjectiveFunction54 = new org.apache.commons.math3.optim.univariate.UnivariateObjectiveFunction((org.apache.commons.math3.analysis.UnivariateFunction) sinc53);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction55 = univariateObjectiveFunction54.getObjectiveFunction();
        double[] doubleArray62 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix63 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray62);
        double[] doubleArray70 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix71 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray70);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair72 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray62, doubleArray70);
        org.apache.commons.math3.optim.InitialGuess initialGuess73 = new org.apache.commons.math3.optim.InitialGuess(doubleArray62);
        org.apache.commons.math3.optim.OptimizationData[] optimizationDataArray74 = new org.apache.commons.math3.optim.OptimizationData[] { univariateObjectiveFunction10, initialGuess28, initialGuess48, nelderMeadSimplex52, univariateObjectiveFunction54, initialGuess73 };
        try {
            org.apache.commons.math3.optim.PointValuePair pointValuePair75 = nonLinearConjugateGradientOptimizer8.optimize(optimizationDataArray74);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 97.0d + "'", double7 == 97.0d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(univariateFunction55);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(optimizationDataArray74);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        double[] doubleArray17 = pointVectorValuePair16.getValue();
        double[] doubleArray18 = pointVectorValuePair16.getPointRef();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray18);
        org.apache.commons.math3.linear.RealVector realVector21 = arrayRealVector19.mapMultiplyToSelf((double) (byte) 1);
        java.io.ObjectOutputStream objectOutputStream22 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.serializeRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector19, objectOutputStream22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector21);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray2 = new java.lang.Object[] {};
        org.apache.commons.math3.exception.MathInternalError mathInternalError3 = new org.apache.commons.math3.exception.MathInternalError(localizable1, objArray2);
        org.apache.commons.math3.exception.MathInternalError mathInternalError4 = new org.apache.commons.math3.exception.MathInternalError(localizable0, objArray2);
        org.junit.Assert.assertNotNull(objArray2);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double double8 = array2DRowRealMatrix7.getFrobeniusNorm();
        double[] doubleArray15 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        double[][] doubleArray17 = array2DRowRealMatrix16.getData();
        double[][] doubleArray18 = array2DRowRealMatrix16.getData();
        double[] doubleArray25 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double double27 = array2DRowRealMatrix26.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix16, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix26);
        org.apache.commons.math3.linear.RealMatrix realMatrix29 = array2DRowRealMatrix7.add((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix16);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor30 = null;
        try {
            double double31 = array2DRowRealMatrix16.walkInOptimizedOrder(realMatrixChangingVisitor30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 61.886993787063204d + "'", double8 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 61.886993787063204d + "'", double27 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(realMatrix29);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        int int2 = org.apache.commons.math3.util.FastMath.min(96, 5);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        try {
            org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.verifyInterval(0.0d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [0, 0]");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        double double1 = org.apache.commons.math3.util.FastMath.cosh(11.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 29937.07086594976d + "'", double1 == 29937.07086594976d);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector5.addToEntry(0, (double) 1.0f);
        double[] doubleArray15 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        double[][] doubleArray17 = array2DRowRealMatrix16.getData();
        double[][] doubleArray18 = array2DRowRealMatrix16.getData();
        double[] doubleArray25 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double double27 = array2DRowRealMatrix26.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix16, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix26);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector32.addToEntry(0, (double) 1.0f);
        arrayRealVector32.unitize();
        array2DRowRealMatrix16.setRowVector(0, (org.apache.commons.math3.linear.RealVector) arrayRealVector32);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = arrayRealVector5.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector32);
        double double39 = arrayRealVector2.cosine((org.apache.commons.math3.linear.RealVector) arrayRealVector38);
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor40 = null;
        try {
            double double43 = arrayRealVector38.walkInDefaultOrder(realVectorChangingVisitor40, (-1), (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 61.886993787063204d + "'", double27 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(arrayRealVector38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 1.0d + "'", double39 == 1.0d);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        double[] doubleArray17 = pointVectorValuePair16.getFirst();
        double[] doubleArray18 = pointVectorValuePair16.getPointRef();
        double[] doubleArray25 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double[] doubleArray33 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray33);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair35 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray25, doubleArray33);
        double[] doubleArray36 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray18, doubleArray33);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection37 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        double[] doubleArray44 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix45 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray44);
        double[][] doubleArray46 = array2DRowRealMatrix45.getData();
        double[][] doubleArray47 = array2DRowRealMatrix45.getData();
        try {
            org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray36, orderDirection37, doubleArray47);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 6");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + orderDirection37 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection37.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        double[] doubleArray17 = pointVectorValuePair16.getValue();
        double[] doubleArray18 = pointVectorValuePair16.getPointRef();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray18);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector19);
        double double21 = arrayRealVector20.getMaxValue();
        double[] doubleArray29 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix30 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray29);
        double[] doubleArray37 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix38 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray37);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair39 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray29, doubleArray37);
        double[] doubleArray40 = pointVectorValuePair39.getValue();
        org.apache.commons.math3.linear.RealVector realVector41 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray40);
        double[] doubleArray48 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix49 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray48);
        double[] doubleArray56 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix57 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray56);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair58 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray48, doubleArray56);
        double[] doubleArray59 = pointVectorValuePair58.getValue();
        org.apache.commons.math3.linear.RealVector realVector60 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray59);
        org.apache.commons.math3.linear.RealVector realVector61 = realVector41.projection(realVector60);
        int int62 = realVector60.getMinIndex();
        try {
            arrayRealVector20.setSubVector(100, realVector60);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 52.0d + "'", double21 == 52.0d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(realVector41);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(realVector60);
        org.junit.Assert.assertNotNull(realVector61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 5 + "'", int62 == 5);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.apache.commons.math3.util.MathUtils.checkFinite(0.0d);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math3.exception.DimensionMismatchException(1, 35);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.apache.commons.math3.linear.RealMatrix realMatrix1 = org.apache.commons.math3.linear.MatrixUtils.createRealIdentityMatrix(36);
        org.junit.Assert.assertNotNull(realMatrix1);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        int[] intArray1 = new int[] { (byte) 100 };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister2 = new org.apache.commons.math3.random.MersenneTwister(intArray1);
        float float3 = mersenneTwister2.nextFloat();
        mersenneTwister2.clear();
        int[] intArray8 = new int[] { (byte) 1, (byte) 100, '4' };
        int[] intArray13 = new int[] { 'a', (short) 1, (byte) 100, 'a' };
        double double14 = org.apache.commons.math3.util.MathArrays.distance(intArray8, intArray13);
        org.apache.commons.math3.random.MersenneTwister mersenneTwister15 = new org.apache.commons.math3.random.MersenneTwister(intArray8);
        mersenneTwister2.setSeed(intArray8);
        try {
            int[] intArray18 = org.apache.commons.math3.util.MathArrays.copyOf(intArray8, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.14566922f + "'", float3 == 0.14566922f);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 146.01712228365548d + "'", double14 == 146.01712228365548d);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        int int2 = org.apache.commons.math3.util.FastMath.min(96, 50);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 50 + "'", int2 == 50);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        java.lang.String[] strArray1 = new java.lang.String[] { "Array2DRowRealMatrix{{32.0},{0.0},{52.0},{-1.0},{10.0},{-1.0}}" };
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection2 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        boolean boolean4 = org.apache.commons.math3.util.MathArrays.isMonotonic(strArray1, orderDirection2, false);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + orderDirection2 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection2.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[][] doubleArray8 = array2DRowRealMatrix7.getData();
        double[][] doubleArray9 = array2DRowRealMatrix7.getData();
        double[] doubleArray16 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16);
        double double18 = array2DRowRealMatrix17.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix7, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector23.addToEntry(0, (double) 1.0f);
        arrayRealVector23.unitize();
        array2DRowRealMatrix7.setRowVector(0, (org.apache.commons.math3.linear.RealVector) arrayRealVector23);
        try {
            array2DRowRealMatrix7.multiplyEntry(0, 1, 97.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 61.886993787063204d + "'", double18 == 61.886993787063204d);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        int[] intArray1 = new int[] { (byte) 100 };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister2 = new org.apache.commons.math3.random.MersenneTwister(intArray1);
        byte[] byteArray6 = new byte[] { (byte) 0, (byte) 100, (byte) 0 };
        mersenneTwister2.nextBytes(byteArray6);
        int int9 = mersenneTwister2.nextInt(2147483647);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 986830553 + "'", int9 == 986830553);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix0 = null;
        try {
            org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix1 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray5 = null;
        org.apache.commons.math3.exception.NoBracketingException noBracketingException6 = new org.apache.commons.math3.exception.NoBracketingException(localizable0, (double) 96L, Double.NaN, (double) (byte) 0, 0.0d, objArray5);
        double double7 = noBracketingException6.getLo();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 96.0d + "'", double7 == 96.0d);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        int int2 = org.apache.commons.math3.util.MathUtils.copySign((-127), (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 127 + "'", int2 == 127);
    }

//    @Test
//    public void test257() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test257");
//        double double0 = org.apache.commons.math3.util.FastMath.random();
//        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.5267696213326568d + "'", double0 == 0.5267696213326568d);
//    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        double double1 = org.apache.commons.math3.util.FastMath.asinh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        double double1 = org.apache.commons.math3.util.FastMath.floor(61.886993787063204d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 61.0d + "'", double1 == 61.0d);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(localizable0, number1);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double double8 = array2DRowRealMatrix7.getFrobeniusNorm();
        double[] doubleArray15 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        double[][] doubleArray17 = array2DRowRealMatrix16.getData();
        double[][] doubleArray18 = array2DRowRealMatrix16.getData();
        double[] doubleArray25 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double double27 = array2DRowRealMatrix26.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix16, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix26);
        org.apache.commons.math3.linear.RealMatrix realMatrix29 = array2DRowRealMatrix7.add((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix16);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor30 = null;
        try {
            double double31 = array2DRowRealMatrix16.walkInColumnOrder(realMatrixChangingVisitor30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 61.886993787063204d + "'", double8 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 61.886993787063204d + "'", double27 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(realMatrix29);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[][] doubleArray8 = array2DRowRealMatrix7.getData();
        double[][] doubleArray9 = array2DRowRealMatrix7.getData();
        double[] doubleArray16 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16);
        double double18 = array2DRowRealMatrix17.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix7, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector23.addToEntry(0, (double) 1.0f);
        arrayRealVector23.unitize();
        array2DRowRealMatrix7.setRowVector(0, (org.apache.commons.math3.linear.RealVector) arrayRealVector23);
        double double29 = arrayRealVector23.getNorm();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = arrayRealVector23.copy();
        arrayRealVector30.set((-10761.089105465297d));
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 61.886993787063204d + "'", double18 == 61.886993787063204d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.0d + "'", double29 == 1.0d);
        org.junit.Assert.assertNotNull(arrayRealVector30);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        int int1 = org.apache.commons.math3.util.FastMath.round((float) 0L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        double[] doubleArray17 = pointVectorValuePair16.getValue();
        org.apache.commons.math3.linear.RealVector realVector18 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray17);
        double[] doubleArray25 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double[] doubleArray33 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray33);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair35 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray25, doubleArray33);
        double[] doubleArray36 = pointVectorValuePair35.getValue();
        org.apache.commons.math3.linear.RealVector realVector37 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray36);
        org.apache.commons.math3.linear.RealVector realVector38 = realVector18.projection(realVector37);
        int int39 = realVector37.getMinIndex();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector42.addToEntry(0, (double) 1.0f);
        double[] doubleArray52 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix53 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray52);
        double[][] doubleArray54 = array2DRowRealMatrix53.getData();
        double[][] doubleArray55 = array2DRowRealMatrix53.getData();
        double[] doubleArray62 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix63 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray62);
        double double64 = array2DRowRealMatrix63.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix53, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix63);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector69 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector69.addToEntry(0, (double) 1.0f);
        arrayRealVector69.unitize();
        array2DRowRealMatrix53.setRowVector(0, (org.apache.commons.math3.linear.RealVector) arrayRealVector69);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector75 = arrayRealVector42.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector69);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector76 = new org.apache.commons.math3.linear.ArrayRealVector(realVector37, arrayRealVector69);
        double double77 = arrayRealVector69.getMaxValue();
        double double78 = arrayRealVector69.getLInfNorm();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(realVector37);
        org.junit.Assert.assertNotNull(realVector38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 5 + "'", int39 == 5);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 61.886993787063204d + "'", double64 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(arrayRealVector75);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 1.0d + "'", double77 == 1.0d);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 1.0d + "'", double78 == 1.0d);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer powellOptimizer2 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer((double) (short) 100, (double) (byte) 1);
        int int3 = powellOptimizer2.getEvaluations();
        double[] doubleArray4 = powellOptimizer2.getUpperBound();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNull(doubleArray4);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[][] doubleArray8 = array2DRowRealMatrix7.getData();
        double[] doubleArray15 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        double double17 = array2DRowRealMatrix16.getFrobeniusNorm();
        java.lang.String str18 = array2DRowRealMatrix16.toString();
        org.apache.commons.math3.linear.RealMatrix realMatrix19 = array2DRowRealMatrix7.subtract((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix16);
        try {
            org.apache.commons.math3.linear.LUDecomposition lUDecomposition21 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix16, (double) 50);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.NonSquareMatrixException; message: non square (6x1) matrix");
        } catch (org.apache.commons.math3.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 61.886993787063204d + "'", double17 == 61.886993787063204d);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Array2DRowRealMatrix{{32.0},{0.0},{52.0},{-1.0},{10.0},{-1.0}}" + "'", str18.equals("Array2DRowRealMatrix{{32.0},{0.0},{52.0},{-1.0},{10.0},{-1.0}}"));
        org.junit.Assert.assertNotNull(realMatrix19);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[][] doubleArray8 = array2DRowRealMatrix7.getData();
        double[][] doubleArray9 = array2DRowRealMatrix7.getData();
        double[] doubleArray16 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16);
        double[] doubleArray24 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray24);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair26 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray16, doubleArray24);
        double[] doubleArray27 = pointVectorValuePair26.getFirst();
        double[] doubleArray28 = array2DRowRealMatrix7.preMultiply(doubleArray27);
        double[] doubleArray29 = null;
        try {
            double[] doubleArray30 = org.apache.commons.math3.util.MathArrays.ebeSubtract(doubleArray28, doubleArray29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[][] doubleArray8 = array2DRowRealMatrix7.getData();
        double[][] doubleArray9 = array2DRowRealMatrix7.getData();
        double[] doubleArray16 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16);
        double double18 = array2DRowRealMatrix17.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix7, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix17);
        boolean boolean20 = array2DRowRealMatrix7.isSquare();
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSubMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix7, 986830553, 10, 0, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (986,830,553)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 61.886993787063204d + "'", double18 == 61.886993787063204d);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        java.util.Locale locale0 = null;
        try {
            java.text.NumberFormat numberFormat1 = org.apache.commons.math3.util.CompositeFormat.getDefaultNumberFormat(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.apache.commons.math3.exception.MathParseException mathParseException2 = new org.apache.commons.math3.exception.MathParseException("{", 2147483647);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) (short) 100, 100, (int) (byte) -1, (int) (short) 100);
        java.lang.Integer[] intArray5 = matrixDimensionMismatchException4.getWrongDimensions();
        int int6 = matrixDimensionMismatchException4.getExpectedColumnDimension();
        java.lang.String str7 = matrixDimensionMismatchException4.toString();
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math3.linear.MatrixDimensionMismatchException: got 100x100 but expected -1x100" + "'", str7.equals("org.apache.commons.math3.linear.MatrixDimensionMismatchException: got 100x100 but expected -1x100"));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        try {
            org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.verifySequence(100.0d, 0.7650730050315234d, (double) 0.0f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [100, 0.765]");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        int int0 = org.apache.commons.math3.linear.BlockRealMatrix.BLOCK_SIZE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 52 + "'", int0 == 52);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        long long1 = org.apache.commons.math3.util.FastMath.round(83.86684335012045d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 84L + "'", long1 == 84L);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((double) 1.0000001f, (double) (short) -1, 96);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        double[][] doubleArray2 = org.apache.commons.math3.linear.BlockRealMatrix.createBlocksLayout((int) (short) -1, (int) (short) 10);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix3 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        double double1 = org.apache.commons.math3.util.FastMath.asinh((-1.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8813735870195429d) + "'", double1 == (-0.8813735870195429d));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        double double1 = org.apache.commons.math3.util.FastMath.atan(1.1125369292536007E-308d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1125369292536007E-308d + "'", double1 == 1.1125369292536007E-308d);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula0 = null;
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker1 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer2 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, pointValuePairConvergenceChecker1);
        org.apache.commons.math3.optim.OptimizationData[] optimizationDataArray3 = new org.apache.commons.math3.optim.OptimizationData[] {};
        try {
            org.apache.commons.math3.optim.PointValuePair pointValuePair4 = nonLinearConjugateGradientOptimizer2.optimize(optimizationDataArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(optimizationDataArray3);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray2 = new java.lang.Object[] {};
        org.apache.commons.math3.exception.MathInternalError mathInternalError3 = new org.apache.commons.math3.exception.MathInternalError(localizable1, objArray2);
        java.lang.Throwable[] throwableArray4 = mathInternalError3.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException5 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable0, (java.lang.Object[]) throwableArray4);
        org.apache.commons.math3.exception.util.Localizable localizable6 = null;
        org.apache.commons.math3.exception.util.Localizable localizable7 = null;
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        double[][] doubleArray16 = array2DRowRealMatrix15.getData();
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException17 = new org.apache.commons.math3.exception.NullArgumentException(localizable7, (java.lang.Object[]) doubleArray16);
        try {
            org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException18 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) mathIllegalArgumentException5, localizable6, (java.lang.Object[]) doubleArray16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        double double1 = org.apache.commons.math3.util.FastMath.rint(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        double double2 = org.apache.commons.math3.util.Precision.round((-4.5451856292264253E18d), 127);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-4.5451856292264253E18d) + "'", double2 == (-4.5451856292264253E18d));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        org.apache.commons.math3.optim.InitialGuess initialGuess17 = new org.apache.commons.math3.optim.InitialGuess(doubleArray6);
        org.apache.commons.math3.optim.InitialGuess initialGuess18 = new org.apache.commons.math3.optim.InitialGuess(doubleArray6);
        org.apache.commons.math3.linear.RealMatrix realMatrix19 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray6);
        double[] doubleArray20 = null;
        try {
            double double21 = org.apache.commons.math3.util.MathArrays.distance(doubleArray6, doubleArray20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realMatrix19);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        boolean boolean3 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.isSequence((double) 0, (double) (byte) 10, 96.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.apache.commons.math3.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number) (-10761.089105465297d));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        double[] doubleArray17 = pointVectorValuePair16.getValue();
        org.apache.commons.math3.linear.RealVector realVector18 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray17);
        double[] doubleArray25 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double[] doubleArray33 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray33);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair35 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray25, doubleArray33);
        double[] doubleArray36 = pointVectorValuePair35.getValue();
        org.apache.commons.math3.linear.RealVector realVector37 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray36);
        org.apache.commons.math3.linear.RealVector realVector38 = realVector18.projection(realVector37);
        int int39 = realVector37.getMinIndex();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector42.addToEntry(0, (double) 1.0f);
        double[] doubleArray52 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix53 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray52);
        double[][] doubleArray54 = array2DRowRealMatrix53.getData();
        double[][] doubleArray55 = array2DRowRealMatrix53.getData();
        double[] doubleArray62 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix63 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray62);
        double double64 = array2DRowRealMatrix63.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix53, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix63);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector69 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector69.addToEntry(0, (double) 1.0f);
        arrayRealVector69.unitize();
        array2DRowRealMatrix53.setRowVector(0, (org.apache.commons.math3.linear.RealVector) arrayRealVector69);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector75 = arrayRealVector42.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector69);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector76 = new org.apache.commons.math3.linear.ArrayRealVector(realVector37, arrayRealVector69);
        double double77 = arrayRealVector69.getMaxValue();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector78 = new org.apache.commons.math3.linear.ArrayRealVector();
        double double79 = arrayRealVector78.getNorm();
        try {
            double double80 = arrayRealVector69.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector78);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(realVector37);
        org.junit.Assert.assertNotNull(realVector38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 5 + "'", int39 == 5);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 61.886993787063204d + "'", double64 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(arrayRealVector75);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 1.0d + "'", double77 == 1.0d);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 0.0d + "'", double79 == 0.0d);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[][] doubleArray8 = array2DRowRealMatrix7.getData();
        double[][] doubleArray9 = array2DRowRealMatrix7.getData();
        double[] doubleArray16 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16);
        double double18 = array2DRowRealMatrix17.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix7, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix17);
        try {
            org.apache.commons.math3.linear.RealVector realVector21 = array2DRowRealMatrix7.getRowVector((-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 61.886993787063204d + "'", double18 == 61.886993787063204d);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6, true);
        double[] doubleArray25 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double[] doubleArray33 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray33);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair35 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray25, doubleArray33);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix37 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray25, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix38 = diagonalMatrix18.add(diagonalMatrix37);
        double[] doubleArray39 = diagonalMatrix18.getDataRef();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector42.addToEntry(0, (double) 1.0f);
        arrayRealVector42.unitize();
        try {
            org.apache.commons.math3.linear.RealVector realVector47 = diagonalMatrix18.operateTranspose((org.apache.commons.math3.linear.RealVector) arrayRealVector42);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(diagonalMatrix38);
        org.junit.Assert.assertNotNull(doubleArray39);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.apache.commons.math3.linear.NonSymmetricMatrixException nonSymmetricMatrixException3 = new org.apache.commons.math3.linear.NonSymmetricMatrixException((int) (byte) 1, 0, 1.1102230246251565E-16d);
        int int4 = nonSymmetricMatrixException3.getRow();
        java.lang.String str5 = nonSymmetricMatrixException3.toString();
        int int6 = nonSymmetricMatrixException3.getColumn();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math3.linear.NonSymmetricMatrixException: non symmetric matrix: the difference between entries at (1,0) and (0,1) is larger than 0" + "'", str5.equals("org.apache.commons.math3.linear.NonSymmetricMatrixException: non symmetric matrix: the difference between entries at (1,0) and (0,1) is larger than 0"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6, true);
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray6, (double) 2147483647);
        boolean boolean22 = pointValuePair20.equals((java.lang.Object) 11.0d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        double double0 = org.apache.commons.math3.util.FastMath.E;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.718281828459045d + "'", double0 == 2.718281828459045d);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        double double2 = org.apache.commons.math3.util.FastMath.hypot((-0.5d), (-0.9999999999999999d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.1180339887498947d + "'", double2 == 1.1180339887498947d);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        double double2 = org.apache.commons.math3.util.FastMath.max((double) 100L, (double) 127);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 127.0d + "'", double2 == 127.0d);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[][] doubleArray8 = array2DRowRealMatrix7.getData();
        double[][] doubleArray9 = array2DRowRealMatrix7.getData();
        double[] doubleArray16 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16);
        double double18 = array2DRowRealMatrix17.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix7, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector23.addToEntry(0, (double) 1.0f);
        arrayRealVector23.unitize();
        array2DRowRealMatrix7.setRowVector(0, (org.apache.commons.math3.linear.RealVector) arrayRealVector23);
        double double29 = arrayRealVector23.getNorm();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = arrayRealVector23.copy();
        int int31 = arrayRealVector30.getDimension();
        double[] doubleArray38 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix39 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray38);
        double[] doubleArray46 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix47 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray46);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair48 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray38, doubleArray46);
        double[] doubleArray49 = pointVectorValuePair48.getValue();
        double[] doubleArray50 = pointVectorValuePair48.getPointRef();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector51 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray50);
        org.apache.commons.math3.linear.RealVector realVector53 = arrayRealVector51.mapMultiplyToSelf((double) (byte) 1);
        double[] doubleArray61 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix62 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray61);
        double[] doubleArray69 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix70 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray69);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair71 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray61, doubleArray69);
        double[] doubleArray72 = pointVectorValuePair71.getValue();
        org.apache.commons.math3.linear.RealVector realVector73 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray72);
        arrayRealVector51.setSubVector(0, realVector73);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector75 = arrayRealVector30.subtract(realVector73);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 6");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 61.886993787063204d + "'", double18 == 61.886993787063204d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.0d + "'", double29 == 1.0d);
        org.junit.Assert.assertNotNull(arrayRealVector30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(realVector53);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(realVector73);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.apache.commons.math3.analysis.function.Sinc sinc1 = new org.apache.commons.math3.analysis.function.Sinc();
        org.apache.commons.math3.optim.univariate.UnivariateObjectiveFunction univariateObjectiveFunction2 = new org.apache.commons.math3.optim.univariate.UnivariateObjectiveFunction((org.apache.commons.math3.analysis.UnivariateFunction) sinc1);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction3 = univariateObjectiveFunction2.getObjectiveFunction();
        org.apache.commons.math3.analysis.solvers.BracketedUnivariateSolver<org.apache.commons.math3.analysis.UnivariateFunction> univariateFunctionBracketedUnivariateSolver4 = null;
        org.apache.commons.math3.analysis.solvers.AllowedSolution allowedSolution8 = null;
        try {
            double double9 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.forceSide((int) (short) 100, univariateFunction3, univariateFunctionBracketedUnivariateSolver4, (double) 10L, (double) '4', 1.0E-15d, allowedSolution8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(univariateFunction3);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.apache.commons.math3.linear.RealMatrix realMatrix2 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix((int) (byte) 100, (int) (short) 100);
        int[] intArray3 = null;
        int[] intArray7 = new int[] { (byte) 1, (byte) 100, '4' };
        int[] intArray12 = new int[] { 'a', (short) 1, (byte) 100, 'a' };
        double double13 = org.apache.commons.math3.util.MathArrays.distance(intArray7, intArray12);
        int[] intArray17 = new int[] { (byte) 1, (byte) 100, '4' };
        int[] intArray22 = new int[] { 'a', (short) 1, (byte) 100, 'a' };
        double double23 = org.apache.commons.math3.util.MathArrays.distance(intArray17, intArray22);
        int int24 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray7, intArray17);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSubMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) realMatrix2, intArray3, intArray17);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix2);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 146.01712228365548d + "'", double13 == 146.01712228365548d);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 146.01712228365548d + "'", double23 == 146.01712228365548d);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        int[] intArray6 = new int[] { (byte) 100 };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister7 = new org.apache.commons.math3.random.MersenneTwister(intArray6);
        double double8 = mersenneTwister7.nextGaussian();
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker10 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer11 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer((int) 'a', (double) 10, true, (int) (short) -1, 0, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister7, false, pointValuePairConvergenceChecker10);
        mersenneTwister7.clear();
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.7650730050315234d + "'", double8 == 0.7650730050315234d);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        java.text.ParsePosition parsePosition2 = null;
        try {
            boolean boolean3 = org.apache.commons.math3.util.CompositeFormat.parseFixedstring("{", "Array2DRowRealMatrix{{32.0},{0.0},{52.0},{-1.0},{10.0},{-1.0}}", parsePosition2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        java.lang.Double[] doubleArray2 = new java.lang.Double[] { 61.886993787063204d, 0.7650730050315234d };
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray2, 96, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: 97 is larger than the maximum (2)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double double8 = array2DRowRealMatrix7.getFrobeniusNorm();
        double[] doubleArray15 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        double[][] doubleArray17 = array2DRowRealMatrix16.getData();
        double[][] doubleArray18 = array2DRowRealMatrix16.getData();
        double[] doubleArray25 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double double27 = array2DRowRealMatrix26.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix16, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix26);
        org.apache.commons.math3.linear.RealMatrix realMatrix29 = array2DRowRealMatrix7.add((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix16);
        double[] doubleArray36 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix37 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray36);
        double[][] doubleArray38 = array2DRowRealMatrix37.getData();
        double[][] doubleArray39 = array2DRowRealMatrix37.getData();
        double[] doubleArray46 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix47 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray46);
        double[] doubleArray54 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix55 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray54);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair56 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray46, doubleArray54);
        double[] doubleArray57 = pointVectorValuePair56.getFirst();
        double[] doubleArray58 = array2DRowRealMatrix37.preMultiply(doubleArray57);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix59 = array2DRowRealMatrix7.multiply((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix37);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 6");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 61.886993787063204d + "'", double8 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 61.886993787063204d + "'", double27 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray58);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex4 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex((int) ' ', (double) 100L, 0.0d, 10.0d);
        org.apache.commons.math3.analysis.MultivariateFunction multivariateFunction5 = null;
        java.util.Comparator<org.apache.commons.math3.optim.PointValuePair> pointValuePairComparator6 = null;
        try {
            multiDirectionalSimplex4.iterate(multivariateFunction5, pointValuePairComparator6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6, true);
        double[] doubleArray25 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double[] doubleArray33 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray33);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair35 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray25, doubleArray33);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix37 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray25, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix38 = diagonalMatrix18.add(diagonalMatrix37);
        double[] doubleArray39 = diagonalMatrix18.getDataRef();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix40 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray39);
        try {
            org.apache.commons.math3.linear.LUDecomposition lUDecomposition41 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix40);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.NonSquareMatrixException; message: non square (6x1) matrix");
        } catch (org.apache.commons.math3.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(diagonalMatrix38);
        org.junit.Assert.assertNotNull(doubleArray39);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        java.text.NumberFormat numberFormat6 = org.apache.commons.math3.util.CompositeFormat.getDefaultNumberFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat7 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat6);
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat8 = new org.apache.commons.math3.linear.RealMatrixFormat("", "org.apache.commons.math3.linear.NonSymmetricMatrixException: non symmetric matrix: the difference between entries at (1,0) and (0,1) is larger than 0", "", "hi!", "{", "hi!", numberFormat6);
        java.text.ParsePosition parsePosition10 = null;
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix11 = realMatrixFormat8.parse("org.apache.commons.math3.linear.NonSymmetricMatrixException: non symmetric matrix: the difference between entries at (1,0) and (0,1) is larger than 0", parsePosition10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat6);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[][] doubleArray8 = array2DRowRealMatrix7.getData();
        double[][] doubleArray9 = array2DRowRealMatrix7.getData();
        double[] doubleArray16 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16);
        double double18 = array2DRowRealMatrix17.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix7, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix17);
        double[] doubleArray27 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray27);
        double[] doubleArray35 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray35);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair37 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray27, doubleArray35);
        double[] doubleArray38 = pointVectorValuePair37.getValue();
        org.apache.commons.math3.linear.RealVector realVector39 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray38);
        try {
            array2DRowRealMatrix17.setRowVector((int) (short) 100, realVector39);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 61.886993787063204d + "'", double18 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(realVector39);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector2.addToEntry(0, (double) 1.0f);
        double[] doubleArray12 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray12);
        double[][] doubleArray14 = array2DRowRealMatrix13.getData();
        double[][] doubleArray15 = array2DRowRealMatrix13.getData();
        double[] doubleArray22 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix23 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray22);
        double double24 = array2DRowRealMatrix23.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix13, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix23);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector29.addToEntry(0, (double) 1.0f);
        arrayRealVector29.unitize();
        array2DRowRealMatrix13.setRowVector(0, (org.apache.commons.math3.linear.RealVector) arrayRealVector29);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = arrayRealVector2.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector29);
        double[] doubleArray36 = arrayRealVector29.toArray();
        double[] doubleArray43 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix44 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray43);
        double[] doubleArray51 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix52 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray51);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair53 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray43, doubleArray51);
        double[] doubleArray54 = pointVectorValuePair53.getFirst();
        double[] doubleArray55 = pointVectorValuePair53.getPointRef();
        double[] doubleArray56 = pointVectorValuePair53.getFirst();
        double double57 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray36, doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 61.886993787063204d + "'", double24 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(arrayRealVector35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 31.0d + "'", double57 == 31.0d);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        double[] doubleArray17 = pointVectorValuePair16.getValue();
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder18 = new org.apache.commons.math3.optim.univariate.BracketFinder();
        int int19 = bracketFinder18.getMaxEvaluations();
        boolean boolean20 = pointVectorValuePair16.equals((java.lang.Object) bracketFinder18);
        double[] doubleArray21 = pointVectorValuePair16.getPoint();
        double[] doubleArray28 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray28);
        double double30 = array2DRowRealMatrix29.getFrobeniusNorm();
        java.lang.String str31 = array2DRowRealMatrix29.toString();
        double[] doubleArray38 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix39 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray38);
        double[] doubleArray46 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix47 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray46);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair48 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray38, doubleArray46);
        double[] doubleArray55 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix56 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray55);
        double[] doubleArray63 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix64 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray63);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair65 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray55, doubleArray63);
        double[] doubleArray66 = pointVectorValuePair65.getFirst();
        double[] doubleArray67 = pointVectorValuePair65.getPointRef();
        double[] doubleArray74 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix75 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray74);
        double[] doubleArray82 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix83 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray82);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair84 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray74, doubleArray82);
        double[] doubleArray85 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray67, doubleArray82);
        double[] doubleArray86 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray46, doubleArray82);
        double[] doubleArray87 = array2DRowRealMatrix29.preMultiply(doubleArray46);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition88 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray21, doubleArray46);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix89 = eigenDecomposition88.getSquareRoot();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathUnsupportedOperationException; message: unsupported operation");
        } catch (org.apache.commons.math3.exception.MathUnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 50 + "'", int19 == 50);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 61.886993787063204d + "'", double30 == 61.886993787063204d);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Array2DRowRealMatrix{{32.0},{0.0},{52.0},{-1.0},{10.0},{-1.0}}" + "'", str31.equals("Array2DRowRealMatrix{{32.0},{0.0},{52.0},{-1.0},{10.0},{-1.0}}"));
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertNotNull(doubleArray87);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        float float1 = org.apache.commons.math3.util.FastMath.ulp((float) 52);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 3.8146973E-6f + "'", float1 == 3.8146973E-6f);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        double double1 = org.apache.commons.math3.util.FastMath.expm1((-4.5451856292264253E18d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) (short) -1, (java.lang.Number) (-4.5451856292264253E18d), false);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        int[] intArray6 = new int[] { (byte) 100 };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister7 = new org.apache.commons.math3.random.MersenneTwister(intArray6);
        double double8 = mersenneTwister7.nextGaussian();
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker10 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer11 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer((int) 'a', (double) 10, true, (int) (short) -1, 0, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister7, false, pointValuePairConvergenceChecker10);
        long long12 = mersenneTwister7.nextLong();
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.7650730050315234d + "'", double8 == 0.7650730050315234d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-4228292497824268148L) + "'", long12 == (-4228292497824268148L));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix2 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(96, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6, true);
        double[] doubleArray25 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double[] doubleArray33 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray33);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair35 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray25, doubleArray33);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix37 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray25, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix38 = diagonalMatrix18.add(diagonalMatrix37);
        try {
            double[] doubleArray40 = diagonalMatrix37.getRow((-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(diagonalMatrix38);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray6);
        org.apache.commons.math3.linear.RealMatrix realMatrix11 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix((int) (byte) 100, (int) (short) 100);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math3.linear.AnyMatrix) realMatrix8, (org.apache.commons.math3.linear.AnyMatrix) realMatrix11);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 6 != 100");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(realMatrix11);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        double[] doubleArray17 = pointVectorValuePair16.getValue();
        double[] doubleArray18 = pointVectorValuePair16.getPointRef();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray18);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector19);
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor21 = null;
        try {
            double double24 = arrayRealVector19.walkInDefaultOrder(realVectorChangingVisitor21, (int) 'a', 2147483647);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (97)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6, true);
        double[] doubleArray25 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double[] doubleArray33 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray33);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair35 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray25, doubleArray33);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix37 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray25, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix38 = diagonalMatrix18.add(diagonalMatrix37);
        double[] doubleArray46 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix47 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray46);
        double[] doubleArray54 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix55 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray54);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair56 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray46, doubleArray54);
        org.apache.commons.math3.optim.InitialGuess initialGuess57 = new org.apache.commons.math3.optim.InitialGuess(doubleArray46);
        double[] doubleArray58 = initialGuess57.getInitialGuess();
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix59 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray58);
        try {
            diagonalMatrix38.setColumn(1085139999, doubleArray58);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (1,085,139,999)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(diagonalMatrix38);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray58);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.apache.commons.math3.exception.MathUnsupportedOperationException mathUnsupportedOperationException0 = new org.apache.commons.math3.exception.MathUnsupportedOperationException();
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException5 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) (short) 100, 100, (int) (byte) -1, (int) (short) 100);
        java.lang.Integer[] intArray6 = matrixDimensionMismatchException5.getWrongDimensions();
        java.lang.Integer[] intArray7 = new java.lang.Integer[] {};
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException8 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray6, intArray7);
        org.apache.commons.math3.exception.ConvergenceException convergenceException9 = new org.apache.commons.math3.exception.ConvergenceException(localizable0, (java.lang.Object[]) intArray7);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray7);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equals(0.0d, (double) 1079508992);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex6 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex((int) (byte) 1, (double) (-1L), (double) (-1L), (double) 100L, (double) (short) 0, (double) 1);
        double[] doubleArray13 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13);
        double double15 = array2DRowRealMatrix14.getFrobeniusNorm();
        java.lang.String str16 = array2DRowRealMatrix14.toString();
        double[] doubleArray23 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray23);
        double[] doubleArray31 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray31);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair33 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray23, doubleArray31);
        double[] doubleArray40 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix41 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray40);
        double[] doubleArray48 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix49 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray48);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair50 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray40, doubleArray48);
        double[] doubleArray51 = pointVectorValuePair50.getFirst();
        double[] doubleArray52 = pointVectorValuePair50.getPointRef();
        double[] doubleArray59 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix60 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray59);
        double[] doubleArray67 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix68 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray67);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair69 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray59, doubleArray67);
        double[] doubleArray70 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray52, doubleArray67);
        double[] doubleArray71 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray31, doubleArray67);
        double[] doubleArray72 = array2DRowRealMatrix14.preMultiply(doubleArray31);
        double[] doubleArray79 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix80 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray79);
        double[] doubleArray87 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix88 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray87);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair89 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray79, doubleArray87);
        org.apache.commons.math3.optim.InitialGuess initialGuess90 = new org.apache.commons.math3.optim.InitialGuess(doubleArray79);
        org.apache.commons.math3.optim.InitialGuess initialGuess91 = new org.apache.commons.math3.optim.InitialGuess(doubleArray79);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition93 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray72, doubleArray79, 2.2250738585072014E-308d);
        try {
            nelderMeadSimplex6.build(doubleArray79);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 6");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 61.886993787063204d + "'", double15 == 61.886993787063204d);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Array2DRowRealMatrix{{32.0},{0.0},{52.0},{-1.0},{10.0},{-1.0}}" + "'", str16.equals("Array2DRowRealMatrix{{32.0},{0.0},{52.0},{-1.0},{10.0},{-1.0}}"));
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertNotNull(doubleArray87);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        double double4 = org.apache.commons.math3.util.MathArrays.linearCombination(0.0d, 1.0E-15d, (double) 10.0f, 31.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 310.0d + "'", double4 == 310.0d);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double double8 = array2DRowRealMatrix7.getFrobeniusNorm();
        double[] doubleArray15 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        double[][] doubleArray17 = array2DRowRealMatrix16.getData();
        double[][] doubleArray18 = array2DRowRealMatrix16.getData();
        double[] doubleArray25 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double double27 = array2DRowRealMatrix26.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix16, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix26);
        org.apache.commons.math3.linear.RealMatrix realMatrix29 = array2DRowRealMatrix7.add((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix16);
        double[] doubleArray36 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix37 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray36);
        org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) realMatrix29, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix37);
        try {
            array2DRowRealMatrix37.addToEntry(0, (int) (short) 10, 1.7522203923062136d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 61.886993787063204d + "'", double8 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 61.886993787063204d + "'", double27 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertNotNull(doubleArray36);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals(310.0d, 0.5267696213326568d, (int) '#');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.apache.commons.math3.exception.MathParseException mathParseException2 = new org.apache.commons.math3.exception.MathParseException("", 1079508992);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6, true);
        double[] doubleArray25 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        org.apache.commons.math3.linear.RealMatrix realMatrix27 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray25);
        org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math3.linear.AnyMatrix) diagonalMatrix18, (org.apache.commons.math3.linear.AnyMatrix) realMatrix27);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition30 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix18, (double) (-9090371258452850456L));
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor31 = null;
        try {
            double double32 = diagonalMatrix18.walkInRowOrder(realMatrixChangingVisitor31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realMatrix27);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.apache.commons.math3.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number) 1);
        java.lang.Number number2 = notPositiveException1.getMin();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0 + "'", number2.equals(0));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math3.exception.DimensionMismatchException(localizable0, (int) (short) 10, 100);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        double double1 = org.apache.commons.math3.util.FastMath.acos((double) 10L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker4 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker((double) ' ', (double) '#');
        org.apache.commons.math3.optim.univariate.BrentOptimizer brentOptimizer5 = new org.apache.commons.math3.optim.univariate.BrentOptimizer((double) 1.0000001f, (double) ' ', (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.univariate.UnivariatePointValuePair>) simpleUnivariateValueChecker4);
        double double6 = brentOptimizer5.getStartValue();
        double double7 = brentOptimizer5.getMax();
        int int8 = brentOptimizer5.getMaxIterations();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2147483647 + "'", int8 == 2147483647);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6, true);
        double[] doubleArray25 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double[] doubleArray33 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray33);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair35 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray25, doubleArray33);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix37 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray25, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix38 = diagonalMatrix18.add(diagonalMatrix37);
        diagonalMatrix37.multiplyEntry((int) (byte) 1, (int) (byte) 100, 1.1125369292536007E-308d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(diagonalMatrix38);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        double double0 = org.apache.commons.math3.util.FastMath.PI;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.141592653589793d + "'", double0 == 3.141592653589793d);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((float) (-9090371258452850456L), (float) 127, 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        double double2 = org.apache.commons.math3.util.FastMath.pow(0.7650730050315234d, (double) 1.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.7650730050315234d + "'", double2 == 0.7650730050315234d);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex1 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex((int) '#');
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math3.exception.DimensionMismatchException(0, (int) (byte) 10);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        double[] doubleArray5 = new double[] { (short) 1, 4.9E-324d, 10.0d, (-0.7249165551445564d), 2147483647 };
        double[] doubleArray11 = new double[] { (short) 1, 4.9E-324d, 10.0d, (-0.7249165551445564d), 2147483647 };
        double[] doubleArray17 = new double[] { (short) 1, 4.9E-324d, 10.0d, (-0.7249165551445564d), 2147483647 };
        double[] doubleArray23 = new double[] { (short) 1, 4.9E-324d, 10.0d, (-0.7249165551445564d), 2147483647 };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray24, false);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix27 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = array2DRowRealMatrix26.add(array2DRowRealMatrix27);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 4x5 but expected 0x0");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equals(0.5267696213326568d, (double) 647325673);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        double[] doubleArray17 = pointVectorValuePair16.getValue();
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder18 = new org.apache.commons.math3.optim.univariate.BracketFinder();
        int int19 = bracketFinder18.getMaxEvaluations();
        boolean boolean20 = pointVectorValuePair16.equals((java.lang.Object) bracketFinder18);
        double[] doubleArray21 = pointVectorValuePair16.getPoint();
        double[] doubleArray28 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray28);
        double double30 = array2DRowRealMatrix29.getFrobeniusNorm();
        java.lang.String str31 = array2DRowRealMatrix29.toString();
        double[] doubleArray38 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix39 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray38);
        double[] doubleArray46 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix47 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray46);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair48 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray38, doubleArray46);
        double[] doubleArray55 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix56 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray55);
        double[] doubleArray63 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix64 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray63);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair65 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray55, doubleArray63);
        double[] doubleArray66 = pointVectorValuePair65.getFirst();
        double[] doubleArray67 = pointVectorValuePair65.getPointRef();
        double[] doubleArray74 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix75 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray74);
        double[] doubleArray82 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix83 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray82);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair84 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray74, doubleArray82);
        double[] doubleArray85 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray67, doubleArray82);
        double[] doubleArray86 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray46, doubleArray82);
        double[] doubleArray87 = array2DRowRealMatrix29.preMultiply(doubleArray46);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition88 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray21, doubleArray46);
        double double90 = eigenDecomposition88.getRealEigenvalue(0);
        org.apache.commons.math3.linear.RealMatrix realMatrix91 = eigenDecomposition88.getD();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 50 + "'", int19 == 50);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 61.886993787063204d + "'", double30 == 61.886993787063204d);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Array2DRowRealMatrix{{32.0},{0.0},{52.0},{-1.0},{10.0},{-1.0}}" + "'", str31.equals("Array2DRowRealMatrix{{32.0},{0.0},{52.0},{-1.0},{10.0},{-1.0}}"));
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + 83.86684335012045d + "'", double90 == 83.86684335012045d);
        org.junit.Assert.assertNotNull(realMatrix91);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        double[] doubleArray17 = pointVectorValuePair16.getValue();
        double[] doubleArray18 = pointVectorValuePair16.getPointRef();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray18);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector19);
        boolean boolean21 = arrayRealVector19.isInfinite();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) (byte) 1);
        java.lang.Number number3 = notStrictlyPositiveException2.getArgument();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + (byte) 1 + "'", number3.equals((byte) 1));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver2 = new org.apache.commons.math3.analysis.solvers.BrentSolver((double) 100L, (double) 'a');
        double double3 = brentSolver2.getStartValue();
        int int4 = brentSolver2.getMaxEvaluations();
        double double5 = brentSolver2.getRelativeAccuracy();
        double double6 = brentSolver2.getMin();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 2147483647, (java.lang.Number) 29937.07086594976d, false);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver2 = new org.apache.commons.math3.analysis.solvers.BrentSolver((double) 100L, (double) 'a');
        double double3 = brentSolver2.getStartValue();
        int int4 = brentSolver2.getEvaluations();
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction6 = null;
        try {
            double double9 = brentSolver2.solve((int) (byte) 0, univariateFunction6, (double) '4', (double) 96);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[][] doubleArray8 = array2DRowRealMatrix7.getData();
        double[][] doubleArray9 = array2DRowRealMatrix7.getData();
        java.lang.String str10 = array2DRowRealMatrix7.toString();
        double[] doubleArray18 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray18);
        double double20 = array2DRowRealMatrix19.getFrobeniusNorm();
        try {
            array2DRowRealMatrix7.setColumnMatrix(127, (org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix19);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (127)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Array2DRowRealMatrix{{32.0},{0.0},{52.0},{-1.0},{10.0},{-1.0}}" + "'", str10.equals("Array2DRowRealMatrix{{32.0},{0.0},{52.0},{-1.0},{10.0},{-1.0}}"));
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 61.886993787063204d + "'", double20 == 61.886993787063204d);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[][] doubleArray8 = array2DRowRealMatrix7.getData();
        double[] doubleArray15 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        double double17 = array2DRowRealMatrix16.getFrobeniusNorm();
        java.lang.String str18 = array2DRowRealMatrix16.toString();
        org.apache.commons.math3.linear.RealMatrix realMatrix19 = array2DRowRealMatrix7.subtract((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix16);
        try {
            org.apache.commons.math3.linear.RealVector realVector21 = array2DRowRealMatrix7.getRowVector(986830553);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (986,830,553)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 61.886993787063204d + "'", double17 == 61.886993787063204d);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Array2DRowRealMatrix{{32.0},{0.0},{52.0},{-1.0},{10.0},{-1.0}}" + "'", str18.equals("Array2DRowRealMatrix{{32.0},{0.0},{52.0},{-1.0},{10.0},{-1.0}}"));
        org.junit.Assert.assertNotNull(realMatrix19);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        int int1 = org.apache.commons.math3.util.FastMath.getExponent((float) (short) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) (short) 100, 100, (int) (byte) -1, (int) (short) 100);
        java.lang.Integer[] intArray5 = matrixDimensionMismatchException4.getWrongDimensions();
        int int6 = matrixDimensionMismatchException4.getExpectedColumnDimension();
        int int7 = matrixDimensionMismatchException4.getWrongRowDimension();
        try {
            int int9 = matrixDimensionMismatchException4.getWrongDimension(50);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 50");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 100 + "'", int7 == 100);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        double[] doubleArray0 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double double8 = array2DRowRealMatrix7.getFrobeniusNorm();
        double[] doubleArray15 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        double[][] doubleArray17 = array2DRowRealMatrix16.getData();
        double[][] doubleArray18 = array2DRowRealMatrix16.getData();
        double[] doubleArray25 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double double27 = array2DRowRealMatrix26.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix16, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix26);
        org.apache.commons.math3.linear.RealMatrix realMatrix29 = array2DRowRealMatrix7.add((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix16);
        double[] doubleArray36 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix37 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray36);
        double[] doubleArray44 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix45 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray44);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair46 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray36, doubleArray44);
        double[] doubleArray47 = pointVectorValuePair46.getFirst();
        double[] doubleArray48 = pointVectorValuePair46.getPointRef();
        try {
            double[] doubleArray49 = array2DRowRealMatrix7.operate(doubleArray48);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 6 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 61.886993787063204d + "'", double8 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 61.886993787063204d + "'", double27 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray48);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        double double1 = org.apache.commons.math3.util.FastMath.asinh(127.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.5373497666891724d + "'", double1 == 5.5373497666891724d);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor8 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double9 = array2DRowRealMatrix7.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor8);
        try {
            org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition10 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix7);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.NonSquareMatrixException; message: non square (6x1) matrix");
        } catch (org.apache.commons.math3.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector2.addToEntry(0, (double) 1.0f);
        org.apache.commons.math3.linear.RealVector realVector7 = arrayRealVector2.mapSubtractToSelf(146.01712228365548d);
        double double8 = arrayRealVector2.getMaxValue();
        double[] doubleArray15 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        double[] doubleArray23 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray23);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair25 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray15, doubleArray23);
        double[] doubleArray26 = pointVectorValuePair25.getValue();
        org.apache.commons.math3.linear.RealVector realVector27 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray26);
        try {
            org.apache.commons.math3.linear.RealVector realVector28 = arrayRealVector2.projection(realVector27);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 6");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realVector7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-135.01712228365548d) + "'", double8 == (-135.01712228365548d));
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(realVector27);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6, true);
        double[] doubleArray25 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double[] doubleArray33 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray33);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair35 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray25, doubleArray33);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix37 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray25, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix38 = diagonalMatrix18.add(diagonalMatrix37);
        try {
            diagonalMatrix18.setEntry(36, (int) (short) -1, (double) 1.0f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: 1 is larger than the maximum (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(diagonalMatrix38);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        double[] doubleArray7 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        double[][] doubleArray9 = array2DRowRealMatrix8.getData();
        double[][] doubleArray10 = array2DRowRealMatrix8.getData();
        double[] doubleArray17 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray17);
        double[] doubleArray25 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair27 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray17, doubleArray25);
        double[] doubleArray28 = pointVectorValuePair27.getFirst();
        double[] doubleArray29 = array2DRowRealMatrix8.preMultiply(doubleArray28);
        org.apache.commons.math3.util.MathArrays.scaleInPlace(83.86684335012045d, doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        int[] intArray6 = new int[] { (byte) 100 };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister7 = new org.apache.commons.math3.random.MersenneTwister(intArray6);
        double double8 = mersenneTwister7.nextGaussian();
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker10 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer11 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer((int) 'a', (double) 10, true, (int) (short) -1, 0, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister7, false, pointValuePairConvergenceChecker10);
        java.util.List<java.lang.Double> doubleList12 = cMAESOptimizer11.getStatisticsSigmaHistory();
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType13 = cMAESOptimizer11.getGoalType();
        java.util.List<org.apache.commons.math3.linear.RealMatrix> realMatrixList14 = cMAESOptimizer11.getStatisticsMeanHistory();
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType15 = cMAESOptimizer11.getGoalType();
        double[] doubleArray16 = cMAESOptimizer11.getStartPoint();
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.7650730050315234d + "'", double8 == 0.7650730050315234d);
        org.junit.Assert.assertNotNull(doubleList12);
        org.junit.Assert.assertNull(goalType13);
        org.junit.Assert.assertNotNull(realMatrixList14);
        org.junit.Assert.assertNull(goalType15);
        org.junit.Assert.assertNull(doubleArray16);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSubMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix0, 35, 36, (int) '4', (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        double[] doubleArray17 = pointVectorValuePair16.getValue();
        org.apache.commons.math3.linear.RealVector realVector18 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray17);
        double[] doubleArray25 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double[] doubleArray33 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray33);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair35 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray25, doubleArray33);
        double[] doubleArray36 = pointVectorValuePair35.getValue();
        org.apache.commons.math3.linear.RealVector realVector37 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray36);
        org.apache.commons.math3.linear.RealVector realVector38 = realVector18.projection(realVector37);
        int int39 = realVector37.getMinIndex();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector42.addToEntry(0, (double) 1.0f);
        double[] doubleArray52 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix53 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray52);
        double[][] doubleArray54 = array2DRowRealMatrix53.getData();
        double[][] doubleArray55 = array2DRowRealMatrix53.getData();
        double[] doubleArray62 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix63 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray62);
        double double64 = array2DRowRealMatrix63.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix53, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix63);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector69 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector69.addToEntry(0, (double) 1.0f);
        arrayRealVector69.unitize();
        array2DRowRealMatrix53.setRowVector(0, (org.apache.commons.math3.linear.RealVector) arrayRealVector69);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector75 = arrayRealVector42.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector69);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector76 = new org.apache.commons.math3.linear.ArrayRealVector(realVector37, arrayRealVector69);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector77 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector76);
        arrayRealVector77.unitize();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(realVector37);
        org.junit.Assert.assertNotNull(realVector38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 5 + "'", int39 == 5);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 61.886993787063204d + "'", double64 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(arrayRealVector75);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray6);
        double[] doubleArray9 = null;
        try {
            org.apache.commons.math3.optim.SimpleBounds simpleBounds10 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray6, doubleArray9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix8);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6, true);
        double[] doubleArray25 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double[] doubleArray33 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray33);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair35 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray25, doubleArray33);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix37 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray25, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix38 = diagonalMatrix18.add(diagonalMatrix37);
        double[] doubleArray39 = diagonalMatrix18.getDataRef();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix40 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray39);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix42 = array2DRowRealMatrix40.getColumnMatrix((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(diagonalMatrix38);
        org.junit.Assert.assertNotNull(doubleArray39);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        double[] doubleArray17 = pointVectorValuePair16.getValue();
        double[] doubleArray18 = pointVectorValuePair16.getPointRef();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray18);
        org.apache.commons.math3.linear.RealVector realVector21 = arrayRealVector19.mapMultiplyToSelf((double) (byte) 1);
        double[] doubleArray29 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix30 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray29);
        double[] doubleArray37 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix38 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray37);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair39 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray29, doubleArray37);
        double[] doubleArray40 = pointVectorValuePair39.getValue();
        org.apache.commons.math3.linear.RealVector realVector41 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray40);
        arrayRealVector19.setSubVector(0, realVector41);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector45.addToEntry(0, (double) 1.0f);
        double[] doubleArray55 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix56 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray55);
        double[][] doubleArray57 = array2DRowRealMatrix56.getData();
        double[][] doubleArray58 = array2DRowRealMatrix56.getData();
        double[] doubleArray65 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix66 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray65);
        double double67 = array2DRowRealMatrix66.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix56, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix66);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector72 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector72.addToEntry(0, (double) 1.0f);
        arrayRealVector72.unitize();
        array2DRowRealMatrix56.setRowVector(0, (org.apache.commons.math3.linear.RealVector) arrayRealVector72);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector78 = arrayRealVector45.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector72);
        org.apache.commons.math3.linear.RealVector realVector79 = arrayRealVector19.append((org.apache.commons.math3.linear.RealVector) arrayRealVector72);
        org.apache.commons.math3.linear.RealVector realVector81 = arrayRealVector72.mapMultiply((double) 5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector21);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(realVector41);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 61.886993787063204d + "'", double67 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(arrayRealVector78);
        org.junit.Assert.assertNotNull(realVector79);
        org.junit.Assert.assertNotNull(realVector81);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        java.text.ParsePosition parsePosition2 = null;
        try {
            boolean boolean3 = org.apache.commons.math3.util.CompositeFormat.parseFixedstring("", "hi!", parsePosition2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker4 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker((double) ' ', (double) '#');
        org.apache.commons.math3.optim.univariate.BrentOptimizer brentOptimizer5 = new org.apache.commons.math3.optim.univariate.BrentOptimizer((double) 1.0000001f, (double) ' ', (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.univariate.UnivariatePointValuePair>) simpleUnivariateValueChecker4);
        double double6 = brentOptimizer5.getMax();
        double double7 = brentOptimizer5.getMin();
        double double8 = brentOptimizer5.getMin();
        double double9 = brentOptimizer5.getMax();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        double[] doubleArray17 = pointVectorValuePair16.getValue();
        double[] doubleArray18 = pointVectorValuePair16.getPointRef();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray18);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector19);
        double double21 = arrayRealVector20.getMaxValue();
        double[] doubleArray22 = arrayRealVector20.getDataRef();
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix24 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray22, true);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 52.0d + "'", double21 == 52.0d);
        org.junit.Assert.assertNotNull(doubleArray22);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[][] doubleArray8 = array2DRowRealMatrix7.getData();
        double[][] doubleArray9 = array2DRowRealMatrix7.getData();
        double[] doubleArray16 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16);
        double double18 = array2DRowRealMatrix17.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix7, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector23.addToEntry(0, (double) 1.0f);
        arrayRealVector23.unitize();
        array2DRowRealMatrix7.setRowVector(0, (org.apache.commons.math3.linear.RealVector) arrayRealVector23);
        double double29 = arrayRealVector23.getNorm();
        java.io.ObjectOutputStream objectOutputStream30 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.serializeRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector23, objectOutputStream30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 61.886993787063204d + "'", double18 == 61.886993787063204d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.0d + "'", double29 == 1.0d);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        java.text.ParsePosition parsePosition1 = null;
        try {
            org.apache.commons.math3.util.CompositeFormat.parseAndIgnoreWhitespace("org.apache.commons.math3.linear.MatrixDimensionMismatchException: got 100x100 but expected -1x100", parsePosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[][] doubleArray8 = array2DRowRealMatrix7.getData();
        double[][] doubleArray9 = array2DRowRealMatrix7.getData();
        double[] doubleArray16 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16);
        double[] doubleArray24 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray24);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair26 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray16, doubleArray24);
        double[] doubleArray27 = pointVectorValuePair26.getFirst();
        double[] doubleArray28 = array2DRowRealMatrix7.preMultiply(doubleArray27);
        try {
            double double31 = array2DRowRealMatrix7.getEntry((int) ' ', 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (32)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double double8 = array2DRowRealMatrix7.getFrobeniusNorm();
        double[] doubleArray15 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        double[][] doubleArray17 = array2DRowRealMatrix16.getData();
        double[][] doubleArray18 = array2DRowRealMatrix16.getData();
        double[] doubleArray25 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double double27 = array2DRowRealMatrix26.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix16, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix26);
        org.apache.commons.math3.linear.RealMatrix realMatrix29 = array2DRowRealMatrix7.add((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix16);
        try {
            double[] doubleArray31 = array2DRowRealMatrix16.getColumn((int) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 61.886993787063204d + "'", double8 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 61.886993787063204d + "'", double27 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(realMatrix29);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.append((double) 0.0f);
        boolean boolean5 = arrayRealVector2.isNaN();
        double[] doubleArray12 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray12);
        double[][] doubleArray14 = array2DRowRealMatrix13.getData();
        double[][] doubleArray15 = array2DRowRealMatrix13.getData();
        double[] doubleArray22 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix23 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray22);
        double double24 = array2DRowRealMatrix23.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix13, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix23);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector29.addToEntry(0, (double) 1.0f);
        arrayRealVector29.unitize();
        array2DRowRealMatrix13.setRowVector(0, (org.apache.commons.math3.linear.RealVector) arrayRealVector29);
        double double35 = arrayRealVector29.getNorm();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = arrayRealVector29.copy();
        double double37 = arrayRealVector2.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector36);
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 61.886993787063204d + "'", double24 == 61.886993787063204d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 1.0d + "'", double35 == 1.0d);
        org.junit.Assert.assertNotNull(arrayRealVector36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 9.0d + "'", double37 == 9.0d);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[][] doubleArray8 = array2DRowRealMatrix7.getData();
        double[][] doubleArray9 = array2DRowRealMatrix7.getData();
        try {
            double[] doubleArray11 = array2DRowRealMatrix7.getColumn(5);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (5)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        int int3 = org.apache.commons.math3.util.Precision.compareTo((double) 97.00001f, (double) (byte) 10, (double) (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.apache.commons.math3.exception.ConvergenceException convergenceException0 = new org.apache.commons.math3.exception.ConvergenceException();
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[][] doubleArray8 = array2DRowRealMatrix7.getData();
        double[][] doubleArray9 = array2DRowRealMatrix7.getData();
        double[] doubleArray16 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16);
        double double18 = array2DRowRealMatrix17.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix7, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector23.addToEntry(0, (double) 1.0f);
        arrayRealVector23.unitize();
        array2DRowRealMatrix7.setRowVector(0, (org.apache.commons.math3.linear.RealVector) arrayRealVector23);
        double[] doubleArray35 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray35);
        double[] doubleArray43 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix44 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray43);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair45 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray35, doubleArray43);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix47 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray35, true);
        double[] doubleArray54 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix55 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray54);
        double[] doubleArray62 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix63 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray62);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair64 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray54, doubleArray62);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix66 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray54, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix67 = diagonalMatrix47.add(diagonalMatrix66);
        diagonalMatrix66.multiplyEntry((int) 'a', (-127), (double) 1.0f);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix7, (org.apache.commons.math3.linear.AnyMatrix) diagonalMatrix66);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 6");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 61.886993787063204d + "'", double18 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(diagonalMatrix67);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder0 = new org.apache.commons.math3.optim.univariate.BracketFinder();
        int int1 = bracketFinder0.getEvaluations();
        double double2 = bracketFinder0.getLo();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6, true);
        double[] doubleArray25 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double[] doubleArray33 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray33);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair35 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray25, doubleArray33);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix37 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray25, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix38 = diagonalMatrix18.add(diagonalMatrix37);
        diagonalMatrix37.multiplyEntry((int) 'a', (-127), (double) 1.0f);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor43 = null;
        try {
            double double44 = diagonalMatrix37.walkInRowOrder(realMatrixChangingVisitor43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(diagonalMatrix38);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer powellOptimizer2 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer((double) (short) 100, (double) (byte) 1);
        int int3 = powellOptimizer2.getEvaluations();
        int int4 = powellOptimizer2.getEvaluations();
        double[] doubleArray5 = powellOptimizer2.getStartPoint();
        double[] doubleArray6 = powellOptimizer2.getUpperBound();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNull(doubleArray5);
        org.junit.Assert.assertNull(doubleArray6);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.apache.commons.math3.optim.SimpleVectorValueChecker simpleVectorValueChecker3 = new org.apache.commons.math3.optim.SimpleVectorValueChecker(0.0d, 29937.07086594976d, 50);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        int[] intArray6 = new int[] { (byte) 100 };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister7 = new org.apache.commons.math3.random.MersenneTwister(intArray6);
        double double8 = mersenneTwister7.nextGaussian();
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker10 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer11 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer((int) 'a', (double) 10, true, (int) (short) -1, 0, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister7, false, pointValuePairConvergenceChecker10);
        java.util.List<java.lang.Double> doubleList12 = cMAESOptimizer11.getStatisticsSigmaHistory();
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType13 = cMAESOptimizer11.getGoalType();
        java.util.List<org.apache.commons.math3.linear.RealMatrix> realMatrixList14 = cMAESOptimizer11.getStatisticsMeanHistory();
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType15 = cMAESOptimizer11.getGoalType();
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType16 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE;
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex18 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(1);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex20 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(1);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex23 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex((int) '#', (double) 100.0f);
        org.apache.commons.math3.analysis.function.Sinc sinc24 = new org.apache.commons.math3.analysis.function.Sinc();
        org.apache.commons.math3.optim.univariate.UnivariateObjectiveFunction univariateObjectiveFunction25 = new org.apache.commons.math3.optim.univariate.UnivariateObjectiveFunction((org.apache.commons.math3.analysis.UnivariateFunction) sinc24);
        org.apache.commons.math3.analysis.MultivariateVectorFunction multivariateVectorFunction26 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.ObjectiveFunctionGradient objectiveFunctionGradient27 = new org.apache.commons.math3.optim.nonlinear.scalar.ObjectiveFunctionGradient(multivariateVectorFunction26);
        org.apache.commons.math3.optim.OptimizationData[] optimizationDataArray28 = new org.apache.commons.math3.optim.OptimizationData[] { goalType16, multiDirectionalSimplex18, multiDirectionalSimplex20, nelderMeadSimplex23, univariateObjectiveFunction25, objectiveFunctionGradient27 };
        try {
            org.apache.commons.math3.optim.PointValuePair pointValuePair29 = cMAESOptimizer11.optimize(optimizationDataArray28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.7650730050315234d + "'", double8 == 0.7650730050315234d);
        org.junit.Assert.assertNotNull(doubleList12);
        org.junit.Assert.assertNull(goalType13);
        org.junit.Assert.assertNotNull(realMatrixList14);
        org.junit.Assert.assertNull(goalType15);
        org.junit.Assert.assertTrue("'" + goalType16 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE + "'", goalType16.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE));
        org.junit.Assert.assertNotNull(optimizationDataArray28);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double double8 = array2DRowRealMatrix7.getFrobeniusNorm();
        java.lang.String str9 = array2DRowRealMatrix7.toString();
        try {
            org.apache.commons.math3.linear.RealVector realVector11 = array2DRowRealMatrix7.getRowVector(127);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (127)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 61.886993787063204d + "'", double8 == 61.886993787063204d);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Array2DRowRealMatrix{{32.0},{0.0},{52.0},{-1.0},{10.0},{-1.0}}" + "'", str9.equals("Array2DRowRealMatrix{{32.0},{0.0},{52.0},{-1.0},{10.0},{-1.0}}"));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        double[] doubleArray17 = pointVectorValuePair16.getValue();
        double[] doubleArray18 = pointVectorValuePair16.getPointRef();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray18);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector19);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor21 = null;
        try {
            double double24 = arrayRealVector20.walkInDefaultOrder(realVectorPreservingVisitor21, 1, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooSmallException; message: initial row 1 after final row 0");
        } catch (org.apache.commons.math3.exception.NumberIsTooSmallException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        int[] intArray1 = new int[] { (byte) 100 };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister2 = new org.apache.commons.math3.random.MersenneTwister(intArray1);
        float float3 = mersenneTwister2.nextFloat();
        mersenneTwister2.setSeed(100L);
        int[] intArray7 = new int[] { (byte) 100 };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister8 = new org.apache.commons.math3.random.MersenneTwister(intArray7);
        mersenneTwister2.setSeed(intArray7);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.14566922f + "'", float3 == 0.14566922f);
        org.junit.Assert.assertNotNull(intArray7);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.apache.commons.math3.optim.SimpleVectorValueChecker simpleVectorValueChecker3 = new org.apache.commons.math3.optim.SimpleVectorValueChecker(Double.NEGATIVE_INFINITY, 0.7615942060206032d);
        double double4 = simpleVectorValueChecker3.getAbsoluteThreshold();
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer gaussNewtonOptimizer5 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer((org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair>) simpleVectorValueChecker3);
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer gaussNewtonOptimizer6 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer((org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair>) simpleVectorValueChecker3);
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer11 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer(52.0d, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair>) simpleVectorValueChecker3, (double) 96L, 0.0d, (double) 36, 29937.07086594976d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.7615942060206032d + "'", double4 == 0.7615942060206032d);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        try {
            double double3 = org.apache.commons.math3.util.Precision.round((double) (-1L), 127, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        double double4 = org.apache.commons.math3.util.MathArrays.linearCombination((-0.9999999999999999d), 0.5403023058681398d, 0.0d, (double) (short) 100);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-0.5403023058681397d) + "'", double4 == (-0.5403023058681397d));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        boolean boolean3 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.isSequence((-135.01712228365548d), (double) (byte) 100, (double) 6);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 146.01712228365548d, (java.lang.Number) 31.0d, true);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.apache.commons.math3.analysis.function.Sinc sinc0 = new org.apache.commons.math3.analysis.function.Sinc();
        double double3 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.solve((org.apache.commons.math3.analysis.UnivariateFunction) sinc0, (double) (-9090371258452850456L), (double) ' ');
        try {
            double[] doubleArray8 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.bracket((org.apache.commons.math3.analysis.UnivariateFunction) sinc0, 0.7615942060206032d, (double) (-1.0f), 4.9E-324d, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: bad value for maximum iterations number: 0");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-4.5451856292264253E18d) + "'", double3 == (-4.5451856292264253E18d));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6, true);
        double[] doubleArray25 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double[] doubleArray33 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray33);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair35 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray25, doubleArray33);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix37 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray25, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix38 = diagonalMatrix18.add(diagonalMatrix37);
        diagonalMatrix37.multiplyEntry((int) 'a', (-127), (double) 1.0f);
        org.apache.commons.math3.linear.RealVector realVector43 = null;
        try {
            org.apache.commons.math3.linear.RealVector realVector44 = diagonalMatrix37.operate(realVector43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(diagonalMatrix38);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker3 = new org.apache.commons.math3.optim.SimpleValueChecker(0.0d, 0.0d, (int) '#');
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        org.apache.commons.math3.optim.InitialGuess initialGuess17 = new org.apache.commons.math3.optim.InitialGuess(doubleArray6);
        double[] doubleArray18 = initialGuess17.getInitialGuess();
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix19 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray18);
        double[] doubleArray26 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix27 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray26);
        double[] doubleArray34 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix35 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray34);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair36 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray26, doubleArray34);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix38 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray26, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix39 = diagonalMatrix19.multiply(diagonalMatrix38);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix41 = diagonalMatrix38.getRowMatrix((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 6");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(diagonalMatrix39);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        double[] doubleArray5 = new double[] { (short) 1, 4.9E-324d, 10.0d, (-0.7249165551445564d), 2147483647 };
        double[] doubleArray11 = new double[] { (short) 1, 4.9E-324d, 10.0d, (-0.7249165551445564d), 2147483647 };
        double[] doubleArray17 = new double[] { (short) 1, 4.9E-324d, 10.0d, (-0.7249165551445564d), 2147483647 };
        double[] doubleArray23 = new double[] { (short) 1, 4.9E-324d, 10.0d, (-0.7249165551445564d), 2147483647 };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray24, false);
        org.apache.commons.math3.linear.RealVector realVector27 = null;
        try {
            org.apache.commons.math3.linear.RealVector realVector28 = array2DRowRealMatrix26.operateTranspose(realVector27);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer simplexOptimizer2 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer((double) 96, (double) 3.8146973E-6f);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equalsIncludingNaN(5.5373497666891724d, 61.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        int int3 = org.apache.commons.math3.util.Precision.compareTo(0.0d, (double) 96L, (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        short short2 = org.apache.commons.math3.util.MathUtils.copySign((short) (byte) 100, (short) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        double double1 = org.apache.commons.math3.util.FastMath.signum(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair2 = new org.apache.commons.math3.optim.univariate.UnivariatePointValuePair(0.0d, (double) 1.0f);
        double double3 = univariatePointValuePair2.getPoint();
        double double4 = univariatePointValuePair2.getValue();
        double double5 = univariatePointValuePair2.getPoint();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double double1 = arrayRealVector0.getNorm();
        int int2 = arrayRealVector0.getMaxIndex();
        double[] doubleArray9 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray9);
        double[][] doubleArray11 = array2DRowRealMatrix10.getData();
        double[][] doubleArray12 = array2DRowRealMatrix10.getData();
        double[] doubleArray19 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray19);
        double double21 = array2DRowRealMatrix20.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix10, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix20);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector26.addToEntry(0, (double) 1.0f);
        arrayRealVector26.unitize();
        array2DRowRealMatrix10.setRowVector(0, (org.apache.commons.math3.linear.RealVector) arrayRealVector26);
        double double32 = arrayRealVector26.getNorm();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = arrayRealVector26.copy();
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = arrayRealVector0.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector33);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 61.886993787063204d + "'", double21 == 61.886993787063204d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.0d + "'", double32 == 1.0d);
        org.junit.Assert.assertNotNull(arrayRealVector33);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        int[] intArray1 = new int[] { (byte) 100 };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister2 = new org.apache.commons.math3.random.MersenneTwister(intArray1);
        float float3 = mersenneTwister2.nextFloat();
        mersenneTwister2.clear();
        int[] intArray8 = new int[] { (byte) 1, (byte) 100, '4' };
        int[] intArray13 = new int[] { 'a', (short) 1, (byte) 100, 'a' };
        double double14 = org.apache.commons.math3.util.MathArrays.distance(intArray8, intArray13);
        org.apache.commons.math3.random.MersenneTwister mersenneTwister15 = new org.apache.commons.math3.random.MersenneTwister(intArray8);
        mersenneTwister2.setSeed(intArray8);
        long long18 = mersenneTwister2.nextLong((long) 35);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.14566922f + "'", float3 == 0.14566922f);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 146.01712228365548d + "'", double14 == 146.01712228365548d);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 13L + "'", long18 == 13L);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        double[] doubleArray17 = pointVectorValuePair16.getValue();
        double[] doubleArray18 = pointVectorValuePair16.getPointRef();
        double[] doubleArray19 = pointVectorValuePair16.getFirst();
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex24 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray19, (double) (short) 10, (double) 100.0f, 0.7615942060206032d, (double) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.ZeroException; message: equal vertices 0 and {1} in simplex configuration");
        } catch (org.apache.commons.math3.exception.ZeroException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) (short) 100, 100, (int) (byte) -1, (int) (short) 100);
        java.lang.Integer[] intArray5 = matrixDimensionMismatchException4.getWrongDimensions();
        int int7 = matrixDimensionMismatchException4.getExpectedDimension((int) (short) 0);
        int int8 = matrixDimensionMismatchException4.getWrongRowDimension();
        int int9 = matrixDimensionMismatchException4.getWrongRowDimension();
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[][] doubleArray8 = array2DRowRealMatrix7.getData();
        double[][] doubleArray9 = array2DRowRealMatrix7.getData();
        double[] doubleArray16 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16);
        double double18 = array2DRowRealMatrix17.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix7, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector23.addToEntry(0, (double) 1.0f);
        arrayRealVector23.unitize();
        array2DRowRealMatrix7.setRowVector(0, (org.apache.commons.math3.linear.RealVector) arrayRealVector23);
        int int29 = array2DRowRealMatrix7.getRowDimension();
        try {
            array2DRowRealMatrix7.setEntry(6, (int) (byte) 0, (-4.5451856292264253E18d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (6)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 61.886993787063204d + "'", double18 == 61.886993787063204d);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 6 + "'", int29 == 6);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        float float2 = org.apache.commons.math3.util.FastMath.copySign(0.0f, (float) 0L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker4 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker((double) ' ', (double) '#');
        org.apache.commons.math3.optim.univariate.BrentOptimizer brentOptimizer5 = new org.apache.commons.math3.optim.univariate.BrentOptimizer((double) 1.0000001f, (double) ' ', (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.univariate.UnivariatePointValuePair>) simpleUnivariateValueChecker4);
        int int6 = brentOptimizer5.getMaxEvaluations();
        int int7 = brentOptimizer5.getMaxIterations();
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.univariate.UnivariatePointValuePair> univariatePointValuePairConvergenceChecker8 = brentOptimizer5.getConvergenceChecker();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2147483647 + "'", int7 == 2147483647);
        org.junit.Assert.assertNotNull(univariatePointValuePairConvergenceChecker8);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        double[] doubleArray17 = pointVectorValuePair16.getValue();
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder18 = new org.apache.commons.math3.optim.univariate.BracketFinder();
        int int19 = bracketFinder18.getMaxEvaluations();
        boolean boolean20 = pointVectorValuePair16.equals((java.lang.Object) bracketFinder18);
        double[] doubleArray21 = pointVectorValuePair16.getSecond();
        double[] doubleArray28 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray28);
        double[] doubleArray36 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix37 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray36);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair38 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray28, doubleArray36);
        double[] doubleArray39 = pointVectorValuePair38.getFirst();
        double[] doubleArray40 = pointVectorValuePair38.getPointRef();
        double[] doubleArray47 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix48 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray47);
        double[] doubleArray55 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix56 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray55);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair57 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray47, doubleArray55);
        double[] doubleArray58 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray40, doubleArray55);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection59 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        boolean boolean61 = org.apache.commons.math3.util.MathArrays.isMonotonic(doubleArray40, orderDirection59, true);
        boolean boolean64 = org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray21, orderDirection59, false, false);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 50 + "'", int19 == 50);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + orderDirection59 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection59.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector2.addToEntry(0, (double) 1.0f);
        org.apache.commons.math3.linear.RealVector realVector7 = arrayRealVector2.mapSubtractToSelf(146.01712228365548d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, true);
        org.junit.Assert.assertNotNull(realVector7);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double double8 = array2DRowRealMatrix7.getFrobeniusNorm();
        java.lang.String str9 = array2DRowRealMatrix7.toString();
        double[] doubleArray16 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16);
        double[] doubleArray24 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray24);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair26 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray16, doubleArray24);
        double[] doubleArray33 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray33);
        double[] doubleArray41 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix42 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray41);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair43 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray33, doubleArray41);
        double[] doubleArray44 = pointVectorValuePair43.getFirst();
        double[] doubleArray45 = pointVectorValuePair43.getPointRef();
        double[] doubleArray52 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix53 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray52);
        double[] doubleArray60 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix61 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray60);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair62 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray52, doubleArray60);
        double[] doubleArray63 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray45, doubleArray60);
        double[] doubleArray64 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray24, doubleArray60);
        double[] doubleArray65 = array2DRowRealMatrix7.preMultiply(doubleArray24);
        double[] doubleArray72 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix73 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray72);
        double[][] doubleArray74 = array2DRowRealMatrix73.getData();
        double[][] doubleArray75 = array2DRowRealMatrix73.getData();
        double[] doubleArray82 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix83 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray82);
        double double84 = array2DRowRealMatrix83.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix73, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix83);
        org.apache.commons.math3.linear.RealMatrix realMatrix86 = array2DRowRealMatrix7.add((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix73);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 61.886993787063204d + "'", double8 == 61.886993787063204d);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Array2DRowRealMatrix{{32.0},{0.0},{52.0},{-1.0},{10.0},{-1.0}}" + "'", str9.equals("Array2DRowRealMatrix{{32.0},{0.0},{52.0},{-1.0},{10.0},{-1.0}}"));
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 61.886993787063204d + "'", double84 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(realMatrix86);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        double double1 = org.apache.commons.math3.util.FastMath.asin((double) 1085139999);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor1 = null;
        try {
            double double4 = arrayRealVector0.walkInDefaultOrder(realVectorPreservingVisitor1, 127, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (127)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.apache.commons.math3.analysis.function.Sinc sinc0 = new org.apache.commons.math3.analysis.function.Sinc();
        org.apache.commons.math3.optim.univariate.UnivariateObjectiveFunction univariateObjectiveFunction1 = new org.apache.commons.math3.optim.univariate.UnivariateObjectiveFunction((org.apache.commons.math3.analysis.UnivariateFunction) sinc0);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction2 = univariateObjectiveFunction1.getObjectiveFunction();
        try {
            double[] doubleArray7 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.bracket(univariateFunction2, (double) 647325673, (double) 1L, (double) 'a', (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: bad value for maximum iterations number: -1");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(univariateFunction2);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6, true);
        double[] doubleArray25 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double[] doubleArray33 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray33);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair35 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray25, doubleArray33);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix37 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray25, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix38 = diagonalMatrix18.add(diagonalMatrix37);
        diagonalMatrix38.multiplyEntry(50, (int) '4', (-0.5d));
        double[] doubleArray49 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix50 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray49);
        double[] doubleArray57 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix58 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray57);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair59 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray49, doubleArray57);
        double[] doubleArray60 = pointVectorValuePair59.getValue();
        double[] doubleArray61 = pointVectorValuePair59.getPointRef();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector62 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray61);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector63 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector62);
        double double64 = arrayRealVector63.getMaxValue();
        double[] doubleArray65 = arrayRealVector63.getDataRef();
        double[] doubleArray66 = diagonalMatrix38.operate(doubleArray65);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix68 = diagonalMatrix38.scalarAdd((double) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: 100 is larger than the maximum (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(diagonalMatrix38);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 52.0d + "'", double64 == 52.0d);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray66);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double double8 = array2DRowRealMatrix7.getFrobeniusNorm();
        java.lang.String str9 = array2DRowRealMatrix7.toString();
        double[] doubleArray16 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16);
        double[] doubleArray24 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray24);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair26 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray16, doubleArray24);
        double[] doubleArray33 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray33);
        double[] doubleArray41 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix42 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray41);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair43 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray33, doubleArray41);
        double[] doubleArray44 = pointVectorValuePair43.getFirst();
        double[] doubleArray45 = pointVectorValuePair43.getPointRef();
        double[] doubleArray52 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix53 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray52);
        double[] doubleArray60 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix61 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray60);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair62 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray52, doubleArray60);
        double[] doubleArray63 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray45, doubleArray60);
        double[] doubleArray64 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray24, doubleArray60);
        double[] doubleArray65 = array2DRowRealMatrix7.preMultiply(doubleArray24);
        double[] doubleArray72 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix73 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray72);
        double[] doubleArray80 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix81 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray80);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair82 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray72, doubleArray80);
        org.apache.commons.math3.optim.InitialGuess initialGuess83 = new org.apache.commons.math3.optim.InitialGuess(doubleArray72);
        org.apache.commons.math3.optim.InitialGuess initialGuess84 = new org.apache.commons.math3.optim.InitialGuess(doubleArray72);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition86 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray65, doubleArray72, 2.2250738585072014E-308d);
        double[] doubleArray87 = eigenDecomposition86.getRealEigenvalues();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 61.886993787063204d + "'", double8 == 61.886993787063204d);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Array2DRowRealMatrix{{32.0},{0.0},{52.0},{-1.0},{10.0},{-1.0}}" + "'", str9.equals("Array2DRowRealMatrix{{32.0},{0.0},{52.0},{-1.0},{10.0},{-1.0}}"));
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertNotNull(doubleArray87);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double double8 = array2DRowRealMatrix7.getFrobeniusNorm();
        java.lang.String str9 = array2DRowRealMatrix7.toString();
        double[] doubleArray16 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16);
        double[] doubleArray24 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray24);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair26 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray16, doubleArray24);
        double[] doubleArray33 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray33);
        double[] doubleArray41 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix42 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray41);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair43 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray33, doubleArray41);
        double[] doubleArray44 = pointVectorValuePair43.getFirst();
        double[] doubleArray45 = pointVectorValuePair43.getPointRef();
        double[] doubleArray52 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix53 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray52);
        double[] doubleArray60 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix61 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray60);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair62 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray52, doubleArray60);
        double[] doubleArray63 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray45, doubleArray60);
        double[] doubleArray64 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray24, doubleArray60);
        double[] doubleArray65 = array2DRowRealMatrix7.preMultiply(doubleArray24);
        java.lang.String str66 = array2DRowRealMatrix7.toString();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 61.886993787063204d + "'", double8 == 61.886993787063204d);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Array2DRowRealMatrix{{32.0},{0.0},{52.0},{-1.0},{10.0},{-1.0}}" + "'", str9.equals("Array2DRowRealMatrix{{32.0},{0.0},{52.0},{-1.0},{10.0},{-1.0}}"));
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "Array2DRowRealMatrix{{32.0},{0.0},{52.0},{-1.0},{10.0},{-1.0}}" + "'", str66.equals("Array2DRowRealMatrix{{32.0},{0.0},{52.0},{-1.0},{10.0},{-1.0}}"));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer5 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer((double) (short) -1, (double) 10, (double) (-1L), (double) (byte) -1, 0.0d);
        double[] doubleArray6 = levenbergMarquardtOptimizer5.getLowerBound();
        int int7 = levenbergMarquardtOptimizer5.getMaxIterations();
        org.junit.Assert.assertNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2147483647 + "'", int7 == 2147483647);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        java.text.NumberFormat numberFormat6 = org.apache.commons.math3.util.CompositeFormat.getDefaultNumberFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat7 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat6);
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat8 = new org.apache.commons.math3.linear.RealMatrixFormat("", "org.apache.commons.math3.linear.NonSymmetricMatrixException: non symmetric matrix: the difference between entries at (1,0) and (0,1) is larger than 0", "", "hi!", "{", "hi!", numberFormat6);
        java.text.NumberFormat numberFormat9 = realMatrixFormat8.getFormat();
        double[] doubleArray16 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16);
        double[] doubleArray24 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray24);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair26 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray16, doubleArray24);
        org.apache.commons.math3.optim.InitialGuess initialGuess27 = new org.apache.commons.math3.optim.InitialGuess(doubleArray16);
        double[] doubleArray28 = initialGuess27.getInitialGuess();
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix29 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray28);
        double[] doubleArray36 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix37 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray36);
        double[] doubleArray44 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix45 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray44);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair46 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray36, doubleArray44);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix48 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray36, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix49 = diagonalMatrix29.multiply(diagonalMatrix48);
        java.lang.StringBuffer stringBuffer50 = null;
        java.text.FieldPosition fieldPosition51 = null;
        try {
            java.lang.StringBuffer stringBuffer52 = realMatrixFormat8.format((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix49, stringBuffer50, fieldPosition51);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat6);
        org.junit.Assert.assertNotNull(numberFormat9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(diagonalMatrix49);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula0 = org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.POLAK_RIBIERE;
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker4 = new org.apache.commons.math3.optim.SimpleValueChecker((-135.01712228365548d), 96.0d, 6);
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver7 = new org.apache.commons.math3.analysis.solvers.BrentSolver((double) 100L, (double) 'a');
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.Preconditioner preconditioner8 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer9 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker4, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver7, preconditioner8);
        org.apache.commons.math3.optim.OptimizationData[] optimizationDataArray10 = null;
        try {
            org.apache.commons.math3.optim.PointValuePair pointValuePair11 = nonLinearConjugateGradientOptimizer9.optimize(optimizationDataArray10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + formula0 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.POLAK_RIBIERE + "'", formula0.equals(org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.POLAK_RIBIERE));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[][] doubleArray8 = array2DRowRealMatrix7.getData();
        double[][] doubleArray9 = array2DRowRealMatrix7.getData();
        double[] doubleArray16 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16);
        double[] doubleArray24 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray24);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair26 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray16, doubleArray24);
        double[] doubleArray27 = pointVectorValuePair26.getFirst();
        double[] doubleArray28 = array2DRowRealMatrix7.preMultiply(doubleArray27);
        java.io.ObjectOutputStream objectOutputStream29 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.serializeRealMatrix((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix7, objectOutputStream29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer5 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer((double) (short) -1, (double) 10, (double) (-1L), (double) (byte) -1, 0.0d);
        double[] doubleArray6 = levenbergMarquardtOptimizer5.getLowerBound();
        double[] doubleArray7 = levenbergMarquardtOptimizer5.getUpperBound();
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair> pointVectorValuePairConvergenceChecker8 = levenbergMarquardtOptimizer5.getConvergenceChecker();
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair> pointVectorValuePairConvergenceChecker9 = levenbergMarquardtOptimizer5.getConvergenceChecker();
        org.junit.Assert.assertNull(doubleArray6);
        org.junit.Assert.assertNull(doubleArray7);
        org.junit.Assert.assertNull(pointVectorValuePairConvergenceChecker8);
        org.junit.Assert.assertNull(pointVectorValuePairConvergenceChecker9);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[][] doubleArray8 = array2DRowRealMatrix7.getData();
        double[][] doubleArray9 = array2DRowRealMatrix7.getData();
        double[] doubleArray16 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16);
        double[] doubleArray24 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray24);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair26 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray16, doubleArray24);
        double[] doubleArray27 = pointVectorValuePair26.getFirst();
        double[] doubleArray28 = pointVectorValuePair26.getPointRef();
        double[] doubleArray35 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray35);
        double[] doubleArray43 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix44 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray43);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair45 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray35, doubleArray43);
        double[] doubleArray46 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray28, doubleArray43);
        double[] doubleArray47 = array2DRowRealMatrix7.preMultiply(doubleArray43);
        try {
            array2DRowRealMatrix7.addToEntry(1, (int) ' ', (-0.6321205588285577d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (32)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.apache.commons.math3.optim.SimpleVectorValueChecker simpleVectorValueChecker2 = new org.apache.commons.math3.optim.SimpleVectorValueChecker(3830.0d, (double) (-1));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        org.apache.commons.math3.optim.InitialGuess initialGuess17 = new org.apache.commons.math3.optim.InitialGuess(doubleArray6);
        org.apache.commons.math3.optim.InitialGuess initialGuess18 = new org.apache.commons.math3.optim.InitialGuess(doubleArray6);
        org.apache.commons.math3.linear.RealMatrix realMatrix19 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray6);
        double[] doubleArray26 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix27 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray26);
        org.apache.commons.math3.linear.RealMatrix realMatrix28 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray26);
        boolean boolean29 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray6, doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realMatrix19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) (short) 100, 100, (int) (byte) -1, (int) (short) 100);
        java.lang.Integer[] intArray5 = matrixDimensionMismatchException4.getWrongDimensions();
        int int7 = matrixDimensionMismatchException4.getExpectedDimension((int) (short) 0);
        int int8 = matrixDimensionMismatchException4.getExpectedRowDimension();
        java.lang.Integer[] intArray9 = matrixDimensionMismatchException4.getWrongDimensions();
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(intArray9);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex2 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex((int) '#', (double) 100.0f);
        int int3 = nelderMeadSimplex2.getDimension();
        double[] doubleArray10 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray10);
        double[] doubleArray18 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray18);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair20 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray10, doubleArray18);
        double[] doubleArray27 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray27);
        double double29 = array2DRowRealMatrix28.getFrobeniusNorm();
        java.lang.String str30 = array2DRowRealMatrix28.toString();
        double[] doubleArray37 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix38 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray37);
        double[] doubleArray45 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix46 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray45);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair47 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray37, doubleArray45);
        double[] doubleArray54 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix55 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray54);
        double[] doubleArray62 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix63 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray62);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair64 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray54, doubleArray62);
        double[] doubleArray65 = pointVectorValuePair64.getFirst();
        double[] doubleArray66 = pointVectorValuePair64.getPointRef();
        double[] doubleArray73 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix74 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray73);
        double[] doubleArray81 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix82 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray81);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair83 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray73, doubleArray81);
        double[] doubleArray84 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray66, doubleArray81);
        double[] doubleArray85 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray45, doubleArray81);
        double[] doubleArray86 = array2DRowRealMatrix28.preMultiply(doubleArray45);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair87 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray10, doubleArray45);
        try {
            nelderMeadSimplex2.build(doubleArray10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 35 != 6");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 35 + "'", int3 == 35);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 61.886993787063204d + "'", double29 == 61.886993787063204d);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Array2DRowRealMatrix{{32.0},{0.0},{52.0},{-1.0},{10.0},{-1.0}}" + "'", str30.equals("Array2DRowRealMatrix{{32.0},{0.0},{52.0},{-1.0},{10.0},{-1.0}}"));
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertNotNull(doubleArray86);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        double double1 = org.apache.commons.math3.util.FastMath.signum(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        float float1 = org.apache.commons.math3.util.FastMath.nextUp((float) '#');
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 35.000004f + "'", float1 == 35.000004f);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        int int1 = org.apache.commons.math3.util.MathUtils.hash(0.7615942060206032d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-266497663) + "'", int1 == (-266497663));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        double[] doubleArray17 = pointVectorValuePair16.getValue();
        double[] doubleArray18 = pointVectorValuePair16.getPointRef();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray18, arrayRealVector21);
        double[] doubleArray29 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix30 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray29);
        double[] doubleArray37 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix38 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray37);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair39 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray29, doubleArray37);
        double[] doubleArray40 = pointVectorValuePair39.getFirst();
        double[] doubleArray41 = pointVectorValuePair39.getPointRef();
        double[] doubleArray48 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix49 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray48);
        double[] doubleArray56 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix57 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray56);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair58 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray48, doubleArray56);
        double[] doubleArray59 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray41, doubleArray56);
        double[] doubleArray60 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray18, doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray60);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.apache.commons.math3.optim.MaxEval maxEval0 = org.apache.commons.math3.optim.MaxEval.unlimited();
        int int1 = maxEval0.getMaxEval();
        int int2 = maxEval0.getMaxEval();
        org.junit.Assert.assertNotNull(maxEval0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2147483647 + "'", int1 == 2147483647);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker4 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker((double) ' ', (double) '#');
        org.apache.commons.math3.optim.univariate.BrentOptimizer brentOptimizer5 = new org.apache.commons.math3.optim.univariate.BrentOptimizer((double) 1.0000001f, (double) ' ', (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.univariate.UnivariatePointValuePair>) simpleUnivariateValueChecker4);
        int int6 = brentOptimizer5.getMaxEvaluations();
        org.apache.commons.math3.optim.OptimizationData[] optimizationDataArray7 = new org.apache.commons.math3.optim.OptimizationData[] {};
        try {
            org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair8 = brentOptimizer5.optimize(optimizationDataArray7);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.TooManyEvaluationsException; message: illegal state: maximal count (0) exceeded: evaluations");
        } catch (org.apache.commons.math3.exception.TooManyEvaluationsException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(optimizationDataArray7);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        double[] doubleArray17 = pointVectorValuePair16.getValue();
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder18 = new org.apache.commons.math3.optim.univariate.BracketFinder();
        int int19 = bracketFinder18.getMaxEvaluations();
        boolean boolean20 = pointVectorValuePair16.equals((java.lang.Object) bracketFinder18);
        int int21 = bracketFinder18.getMaxEvaluations();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 50 + "'", int19 == 50);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 50 + "'", int21 == 50);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.append((double) 0.0f);
        boolean boolean5 = arrayRealVector2.isNaN();
        boolean boolean6 = arrayRealVector2.isInfinite();
        try {
            arrayRealVector2.addToEntry(5, 29937.07086594976d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (5)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        java.text.ParsePosition parsePosition1 = null;
        try {
            org.apache.commons.math3.util.CompositeFormat.parseAndIgnoreWhitespace("Array2DRowRealMatrix{{32.0},{0.0},{52.0},{-1.0},{10.0},{-1.0}}", parsePosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.apache.commons.math3.util.Incrementor incrementor1 = new org.apache.commons.math3.util.Incrementor(100);
        incrementor1.setMaximalCount((int) (byte) 0);
        int int4 = incrementor1.getMaximalCount();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[][] doubleArray8 = array2DRowRealMatrix7.getData();
        double[][] doubleArray9 = array2DRowRealMatrix7.getData();
        double[] doubleArray16 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16);
        double double18 = array2DRowRealMatrix17.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix7, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix17);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor20 = null;
        try {
            double double25 = array2DRowRealMatrix7.walkInColumnOrder(realMatrixChangingVisitor20, (int) (short) 100, 35, (int) (short) 0, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 61.886993787063204d + "'", double18 == 61.886993787063204d);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        double[] doubleArray17 = pointVectorValuePair16.getValue();
        double[] doubleArray18 = pointVectorValuePair16.getPointRef();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray18);
        org.apache.commons.math3.linear.RealVector realVector21 = arrayRealVector19.mapAdd(0.0d);
        arrayRealVector19.set((double) 10);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector21);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) (short) 100, 100, (int) (byte) -1, (int) (short) 100);
        java.lang.Integer[] intArray5 = matrixDimensionMismatchException4.getWrongDimensions();
        int int7 = matrixDimensionMismatchException4.getExpectedDimension((int) (short) 0);
        int int8 = matrixDimensionMismatchException4.getExpectedRowDimension();
        int int9 = matrixDimensionMismatchException4.getWrongColumnDimension();
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector2.addToEntry(0, (double) 1.0f);
        double[] doubleArray12 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray12);
        double[][] doubleArray14 = array2DRowRealMatrix13.getData();
        double[][] doubleArray15 = array2DRowRealMatrix13.getData();
        double[] doubleArray22 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix23 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray22);
        double double24 = array2DRowRealMatrix23.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix13, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix23);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector29.addToEntry(0, (double) 1.0f);
        arrayRealVector29.unitize();
        array2DRowRealMatrix13.setRowVector(0, (org.apache.commons.math3.linear.RealVector) arrayRealVector29);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = arrayRealVector2.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector29);
        double[] doubleArray43 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix44 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray43);
        double[] doubleArray51 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix52 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray51);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair53 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray43, doubleArray51);
        double[] doubleArray54 = pointVectorValuePair53.getFirst();
        double[] doubleArray55 = pointVectorValuePair53.getPointRef();
        double[] doubleArray62 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix63 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray62);
        double[] doubleArray70 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix71 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray70);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair72 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray62, doubleArray70);
        double[] doubleArray73 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray55, doubleArray70);
        double[] doubleArray78 = new double[] { (short) 10, 10L, 'a', 0.7650730050315234d };
        org.apache.commons.math3.optim.SimpleBounds simpleBounds79 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray73, doubleArray78);
        try {
            arrayRealVector35.setSubVector(5, doubleArray73);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (5)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 61.886993787063204d + "'", double24 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(arrayRealVector35);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray78);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.append((double) 0.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector10.addToEntry(0, (double) 1.0f);
        double[] doubleArray20 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray20);
        double[][] doubleArray22 = array2DRowRealMatrix21.getData();
        double[][] doubleArray23 = array2DRowRealMatrix21.getData();
        double[] doubleArray30 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30);
        double double32 = array2DRowRealMatrix31.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix21, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix31);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector37.addToEntry(0, (double) 1.0f);
        arrayRealVector37.unitize();
        array2DRowRealMatrix21.setRowVector(0, (org.apache.commons.math3.linear.RealVector) arrayRealVector37);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector43 = arrayRealVector10.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector37);
        double double44 = arrayRealVector7.cosine((org.apache.commons.math3.linear.RealVector) arrayRealVector43);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = arrayRealVector2.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = new org.apache.commons.math3.linear.ArrayRealVector();
        double double47 = arrayRealVector46.getNorm();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector2, arrayRealVector46);
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 61.886993787063204d + "'", double32 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(arrayRealVector43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 1.0d + "'", double44 == 1.0d);
        org.junit.Assert.assertNotNull(arrayRealVector45);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat6 = new org.apache.commons.math3.linear.RealMatrixFormat("", "hi!", "org.apache.commons.math3.linear.NonSymmetricMatrixException: non symmetric matrix: the difference between entries at (1,0) and (0,1) is larger than 0", "Array2DRowRealMatrix{{32.0},{0.0},{52.0},{-1.0},{10.0},{-1.0}}", "Array2DRowRealMatrix{{32.0},{0.0},{52.0},{-1.0},{10.0},{-1.0}}", "hi!");
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        java.text.NumberFormat numberFormat6 = org.apache.commons.math3.util.CompositeFormat.getDefaultNumberFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat7 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat6);
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat8 = new org.apache.commons.math3.linear.RealMatrixFormat("", "org.apache.commons.math3.linear.NonSymmetricMatrixException: non symmetric matrix: the difference between entries at (1,0) and (0,1) is larger than 0", "", "hi!", "{", "hi!", numberFormat6);
        java.text.NumberFormat numberFormat9 = realMatrixFormat8.getFormat();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix11 = realMatrixFormat8.parse("org.apache.commons.math3.linear.NonSymmetricMatrixException: non symmetric matrix: the difference between entries at (1,0) and (0,1) is larger than 0");
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathParseException; message: illegal state: string \"org.apache.commons.math3.linear.NonSymmetricMatrixException: non symmetric matrix: the difference between entries at (1,0) and (0,1) is larger than 0\" unparseable (from position 0) as an object of type org.apache.commons.math3.linear.Array2DRowRealMatrix");
        } catch (org.apache.commons.math3.exception.MathParseException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat6);
        org.junit.Assert.assertNotNull(numberFormat9);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        try {
            org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.verifyInterval((double) (byte) 10, (double) 5);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [10, 5]");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.apache.commons.math3.util.Incrementor incrementor1 = new org.apache.commons.math3.util.Incrementor(100);
        boolean boolean2 = incrementor1.canIncrement();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) (short) 100, 100, (int) (byte) -1, (int) (short) 100);
        java.lang.Integer[] intArray5 = matrixDimensionMismatchException4.getWrongDimensions();
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException10 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) (short) 100, 100, (int) (byte) -1, (int) (short) 100);
        java.lang.Integer[] intArray11 = matrixDimensionMismatchException10.getWrongDimensions();
        java.lang.Integer[] intArray12 = new java.lang.Integer[] {};
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException13 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray11, intArray12);
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException14 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray5, intArray11);
        try {
            int int16 = multiDimensionMismatchException14.getExpectedDimension(2147483647);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2147483647");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray12);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.apache.commons.math3.linear.RealMatrix realMatrix0 = null;
        org.apache.commons.math3.linear.RealVector realVector1 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.solveUpperTriangularSystem(realMatrix0, realVector1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((double) 84L, (double) (short) 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        double double1 = org.apache.commons.math3.util.FastMath.asin(35.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[][] doubleArray8 = array2DRowRealMatrix7.getData();
        double[] doubleArray15 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        double double17 = array2DRowRealMatrix16.getFrobeniusNorm();
        java.lang.String str18 = array2DRowRealMatrix16.toString();
        org.apache.commons.math3.linear.RealMatrix realMatrix19 = array2DRowRealMatrix7.subtract((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix16);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor20 = null;
        try {
            double double21 = array2DRowRealMatrix7.walkInRowOrder(realMatrixChangingVisitor20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 61.886993787063204d + "'", double17 == 61.886993787063204d);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Array2DRowRealMatrix{{32.0},{0.0},{52.0},{-1.0},{10.0},{-1.0}}" + "'", str18.equals("Array2DRowRealMatrix{{32.0},{0.0},{52.0},{-1.0},{10.0},{-1.0}}"));
        org.junit.Assert.assertNotNull(realMatrix19);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder0 = new org.apache.commons.math3.optim.univariate.BracketFinder();
        int int1 = bracketFinder0.getMaxEvaluations();
        int int2 = bracketFinder0.getMaxEvaluations();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 50 + "'", int1 == 50);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 50 + "'", int2 == 50);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        double double2 = org.apache.commons.math3.util.Precision.representableDelta(1.0E-15d, (double) (short) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.apache.commons.math3.analysis.function.Sinc sinc1 = new org.apache.commons.math3.analysis.function.Sinc(true);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.append((double) 0.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector7.addToEntry(0, (double) 1.0f);
        double[] doubleArray17 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray17);
        double[][] doubleArray19 = array2DRowRealMatrix18.getData();
        double[][] doubleArray20 = array2DRowRealMatrix18.getData();
        double[] doubleArray27 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray27);
        double double29 = array2DRowRealMatrix28.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix18, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix28);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector34.addToEntry(0, (double) 1.0f);
        arrayRealVector34.unitize();
        array2DRowRealMatrix18.setRowVector(0, (org.apache.commons.math3.linear.RealVector) arrayRealVector34);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = arrayRealVector7.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector34);
        double[] doubleArray41 = arrayRealVector34.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, doubleArray41);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, false);
        try {
            double double46 = arrayRealVector44.getEntry((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 61.886993787063204d + "'", double29 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(arrayRealVector40);
        org.junit.Assert.assertNotNull(doubleArray41);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (-266497663));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -266,497,663 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        float float2 = org.apache.commons.math3.util.FastMath.copySign((float) (-7910618197763358337L), (float) 986830553);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 7.9106184E18f + "'", float2 == 7.9106184E18f);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer3 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer((-1.0d), 35.0d, (double) ' ');
        org.apache.commons.math3.analysis.function.Sinc sinc4 = new org.apache.commons.math3.analysis.function.Sinc();
        org.apache.commons.math3.optim.univariate.UnivariateObjectiveFunction univariateObjectiveFunction5 = new org.apache.commons.math3.optim.univariate.UnivariateObjectiveFunction((org.apache.commons.math3.analysis.UnivariateFunction) sinc4);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction6 = univariateObjectiveFunction5.getObjectiveFunction();
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction7 = univariateObjectiveFunction5.getObjectiveFunction();
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        double[] doubleArray22 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix23 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray22);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair24 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray14, doubleArray22);
        org.apache.commons.math3.optim.InitialGuess initialGuess25 = new org.apache.commons.math3.optim.InitialGuess(doubleArray14);
        org.apache.commons.math3.analysis.function.Sinc sinc26 = new org.apache.commons.math3.analysis.function.Sinc();
        org.apache.commons.math3.optim.univariate.UnivariateObjectiveFunction univariateObjectiveFunction27 = new org.apache.commons.math3.optim.univariate.UnivariateObjectiveFunction((org.apache.commons.math3.analysis.UnivariateFunction) sinc26);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction28 = univariateObjectiveFunction27.getObjectiveFunction();
        org.apache.commons.math3.optim.MaxEval maxEval30 = new org.apache.commons.math3.optim.MaxEval(1);
        org.apache.commons.math3.analysis.MultivariateVectorFunction multivariateVectorFunction31 = null;
        org.apache.commons.math3.optim.nonlinear.vector.ModelFunction modelFunction32 = new org.apache.commons.math3.optim.nonlinear.vector.ModelFunction(multivariateVectorFunction31);
        double[] doubleArray39 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix40 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray39);
        double[] doubleArray47 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix48 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray47);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair49 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray39, doubleArray47);
        double[] doubleArray50 = pointVectorValuePair49.getFirst();
        double[] doubleArray51 = pointVectorValuePair49.getPointRef();
        double[] doubleArray58 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix59 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray58);
        double[] doubleArray66 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix67 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray66);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair68 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray58, doubleArray66);
        double[] doubleArray69 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray51, doubleArray66);
        double[] doubleArray74 = new double[] { (short) 10, 10L, 'a', 0.7650730050315234d };
        org.apache.commons.math3.optim.SimpleBounds simpleBounds75 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray69, doubleArray74);
        org.apache.commons.math3.optim.OptimizationData[] optimizationDataArray76 = new org.apache.commons.math3.optim.OptimizationData[] { univariateObjectiveFunction5, initialGuess25, univariateObjectiveFunction27, maxEval30, modelFunction32, simpleBounds75 };
        try {
            org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair77 = levenbergMarquardtOptimizer3.optimize(optimizationDataArray76);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooSmallException; message: 32 is smaller than the minimum (64)");
        } catch (org.apache.commons.math3.exception.NumberIsTooSmallException e) {
        }
        org.junit.Assert.assertNotNull(univariateFunction6);
        org.junit.Assert.assertNotNull(univariateFunction7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(univariateFunction28);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(optimizationDataArray76);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder0 = new org.apache.commons.math3.optim.univariate.BracketFinder();
        double double1 = bracketFinder0.getHi();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = org.apache.commons.math3.linear.RealVectorFormat.getInstance();
        java.lang.String str1 = realVectorFormat0.getSuffix();
        org.junit.Assert.assertNotNull(realVectorFormat0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "}" + "'", str1.equals("}"));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[][] doubleArray3 = org.apache.commons.math3.linear.BlockRealMatrix.createBlocksLayout((int) (short) -1, (int) (short) 10);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException4 = new org.apache.commons.math3.exception.MathArithmeticException(localizable0, (java.lang.Object[]) doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray3);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        double double1 = org.apache.commons.math3.util.FastMath.log((double) (-1));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.apache.commons.math3.analysis.function.Sinc sinc0 = new org.apache.commons.math3.analysis.function.Sinc();
        org.apache.commons.math3.optim.univariate.UnivariateObjectiveFunction univariateObjectiveFunction1 = new org.apache.commons.math3.optim.univariate.UnivariateObjectiveFunction((org.apache.commons.math3.analysis.UnivariateFunction) sinc0);
        double double3 = sinc0.value(0.0d);
        try {
            double double7 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.solve((org.apache.commons.math3.analysis.UnivariateFunction) sinc0, (double) 97.00001f, (double) (-127), 310.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [97, -15]");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6, true);
        double[] doubleArray25 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double[] doubleArray33 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray33);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair35 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray25, doubleArray33);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix37 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray25, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix38 = diagonalMatrix18.add(diagonalMatrix37);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition40 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix18, (double) 1.0f);
        org.apache.commons.math3.linear.RealMatrix realMatrix41 = lUDecomposition40.getP();
        double double42 = lUDecomposition40.getDeterminant();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(diagonalMatrix38);
        org.junit.Assert.assertNull(realMatrix41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        int[] intArray6 = new int[] { (byte) 100 };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister7 = new org.apache.commons.math3.random.MersenneTwister(intArray6);
        double double8 = mersenneTwister7.nextGaussian();
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker10 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer11 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer((int) 'a', (double) 10, true, (int) (short) -1, 0, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister7, false, pointValuePairConvergenceChecker10);
        java.util.List<java.lang.Double> doubleList12 = cMAESOptimizer11.getStatisticsSigmaHistory();
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType13 = cMAESOptimizer11.getGoalType();
        java.util.List<org.apache.commons.math3.linear.RealMatrix> realMatrixList14 = cMAESOptimizer11.getStatisticsDHistory();
        java.util.List<java.lang.Double> doubleList15 = cMAESOptimizer11.getStatisticsFitnessHistory();
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.7650730050315234d + "'", double8 == 0.7650730050315234d);
        org.junit.Assert.assertNotNull(doubleList12);
        org.junit.Assert.assertNull(goalType13);
        org.junit.Assert.assertNotNull(realMatrixList14);
        org.junit.Assert.assertNotNull(doubleList15);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder0 = new org.apache.commons.math3.optim.univariate.BracketFinder();
        int int1 = bracketFinder0.getEvaluations();
        double double2 = bracketFinder0.getFLo();
        org.apache.commons.math3.analysis.function.Sinc sinc3 = new org.apache.commons.math3.analysis.function.Sinc();
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType4 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE;
        bracketFinder0.search((org.apache.commons.math3.analysis.UnivariateFunction) sinc3, goalType4, 0.9835877454343449d, 0.0d);
        try {
            org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.verifyBracketing((org.apache.commons.math3.analysis.UnivariateFunction) sinc3, 310.0d, (-0.6321205588285577d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [310, -0.632]");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + goalType4 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE + "'", goalType4.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        double double2 = org.apache.commons.math3.util.FastMath.log((double) 0.14566922f, (double) 2147483647);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-11.154160537197155d) + "'", double2 == (-11.154160537197155d));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.BracketingStep bracketingStep1 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.BracketingStep((double) 1.0f);
        double double2 = bracketingStep1.getBracketingStep();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6, true);
        double[] doubleArray25 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double[] doubleArray33 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray33);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair35 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray25, doubleArray33);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix37 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray25, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix38 = diagonalMatrix18.add(diagonalMatrix37);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition40 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix18, (double) 1.0f);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix43 = diagonalMatrix18.createMatrix((int) (short) -1, (-127));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: -1 != -127");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(diagonalMatrix38);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[][] doubleArray8 = array2DRowRealMatrix7.getData();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        org.apache.commons.math3.linear.RealVector realVector13 = arrayRealVector11.append((double) 0.0f);
        boolean boolean14 = arrayRealVector11.isNaN();
        boolean boolean15 = arrayRealVector11.isInfinite();
        try {
            org.apache.commons.math3.linear.RealVector realVector16 = array2DRowRealMatrix7.operateTranspose((org.apache.commons.math3.linear.RealVector) arrayRealVector11);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker2 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker((double) 1L, 0.0d);
        double double3 = simpleUnivariateValueChecker2.getRelativeThreshold();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex3 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex((int) ' ', Double.NEGATIVE_INFINITY, 0.0d);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double[] doubleArray7 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        double[] doubleArray15 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair17 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray7, doubleArray15);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix19 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray7, true);
        double[] doubleArray26 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix27 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray26);
        org.apache.commons.math3.linear.RealMatrix realMatrix28 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray26);
        org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math3.linear.AnyMatrix) diagonalMatrix19, (org.apache.commons.math3.linear.AnyMatrix) realMatrix28);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix30 = array2DRowRealMatrix0.preMultiply(realMatrix28);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 6 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(realMatrix28);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        int[] intArray3 = new int[] { (byte) 1, (byte) 100, '4' };
        int[] intArray8 = new int[] { 'a', (short) 1, (byte) 100, 'a' };
        double double9 = org.apache.commons.math3.util.MathArrays.distance(intArray3, intArray8);
        int[] intArray13 = new int[] { (byte) 1, (byte) 100, '4' };
        int[] intArray18 = new int[] { 'a', (short) 1, (byte) 100, 'a' };
        double double19 = org.apache.commons.math3.util.MathArrays.distance(intArray13, intArray18);
        int int20 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray3, intArray13);
        int[] intArray22 = new int[] { (byte) 1 };
        int[] intArray26 = new int[] { (byte) 1, (byte) 100, '4' };
        int[] intArray31 = new int[] { 'a', (short) 1, (byte) 100, 'a' };
        double double32 = org.apache.commons.math3.util.MathArrays.distance(intArray26, intArray31);
        int int33 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray22, intArray31);
        int int34 = org.apache.commons.math3.util.MathArrays.distance1(intArray13, intArray31);
        try {
            int[] intArray36 = org.apache.commons.math3.util.MathArrays.copyOf(intArray13, (-127));
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 146.01712228365548d + "'", double9 == 146.01712228365548d);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 146.01712228365548d + "'", double19 == 146.01712228365548d);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 146.01712228365548d + "'", double32 == 146.01712228365548d);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 96 + "'", int33 == 96);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 243 + "'", int34 == 243);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        int[] intArray1 = new int[] { (byte) 100 };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister2 = new org.apache.commons.math3.random.MersenneTwister(intArray1);
        double double3 = mersenneTwister2.nextGaussian();
        double double4 = mersenneTwister2.nextDouble();
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.7650730050315234d + "'", double3 == 0.7650730050315234d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.7707837995104119d + "'", double4 == 0.7707837995104119d);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double double8 = array2DRowRealMatrix7.getFrobeniusNorm();
        double[] doubleArray15 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        double[][] doubleArray17 = array2DRowRealMatrix16.getData();
        double[][] doubleArray18 = array2DRowRealMatrix16.getData();
        double[] doubleArray25 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double double27 = array2DRowRealMatrix26.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix16, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix26);
        org.apache.commons.math3.linear.RealMatrix realMatrix29 = array2DRowRealMatrix7.add((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix16);
        double[] doubleArray36 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix37 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray36);
        double[][] doubleArray38 = array2DRowRealMatrix37.getData();
        double[][] doubleArray39 = array2DRowRealMatrix37.getData();
        double[] doubleArray46 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix47 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray46);
        double[] doubleArray54 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix55 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray54);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair56 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray46, doubleArray54);
        double[] doubleArray57 = pointVectorValuePair56.getFirst();
        double[] doubleArray58 = pointVectorValuePair56.getPointRef();
        double[] doubleArray65 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix66 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray65);
        double[] doubleArray73 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix74 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray73);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair75 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray65, doubleArray73);
        double[] doubleArray76 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray58, doubleArray73);
        double[] doubleArray77 = array2DRowRealMatrix37.preMultiply(doubleArray73);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix78 = array2DRowRealMatrix16.subtract(array2DRowRealMatrix37);
        double[] doubleArray85 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix86 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray85);
        double[][] doubleArray87 = array2DRowRealMatrix86.getData();
        double[][] doubleArray88 = array2DRowRealMatrix86.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix89 = array2DRowRealMatrix37.add(array2DRowRealMatrix86);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor90 = null;
        try {
            double double91 = array2DRowRealMatrix86.walkInColumnOrder(realMatrixChangingVisitor90);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 61.886993787063204d + "'", double8 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 61.886993787063204d + "'", double27 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix78);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix89);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        double[] doubleArray17 = pointVectorValuePair16.getValue();
        double[] doubleArray18 = pointVectorValuePair16.getPointRef();
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix19 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray18);
        org.apache.commons.math3.linear.RealMatrix realMatrix20 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray18);
        int[] intArray24 = new int[] { (byte) 1, (byte) 100, '4' };
        int[] intArray29 = new int[] { 'a', (short) 1, (byte) 100, 'a' };
        double double30 = org.apache.commons.math3.util.MathArrays.distance(intArray24, intArray29);
        org.apache.commons.math3.random.MersenneTwister mersenneTwister31 = new org.apache.commons.math3.random.MersenneTwister(intArray24);
        int[] intArray35 = new int[] { (byte) 1, (byte) 100, '4' };
        int[] intArray40 = new int[] { 'a', (short) 1, (byte) 100, 'a' };
        double double41 = org.apache.commons.math3.util.MathArrays.distance(intArray35, intArray40);
        int[] intArray45 = new int[] { (byte) 1, (byte) 100, '4' };
        int[] intArray50 = new int[] { 'a', (short) 1, (byte) 100, 'a' };
        double double51 = org.apache.commons.math3.util.MathArrays.distance(intArray45, intArray50);
        int int52 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray35, intArray45);
        int[] intArray54 = new int[] { (byte) 1 };
        int[] intArray58 = new int[] { (byte) 1, (byte) 100, '4' };
        int[] intArray63 = new int[] { 'a', (short) 1, (byte) 100, 'a' };
        double double64 = org.apache.commons.math3.util.MathArrays.distance(intArray58, intArray63);
        int int65 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray54, intArray63);
        int int66 = org.apache.commons.math3.util.MathArrays.distance1(intArray45, intArray63);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSubMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) realMatrix20, intArray24, intArray45);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 146.01712228365548d + "'", double30 == 146.01712228365548d);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 146.01712228365548d + "'", double41 == 146.01712228365548d);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 146.01712228365548d + "'", double51 == 146.01712228365548d);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertNotNull(intArray54);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertNotNull(intArray63);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 146.01712228365548d + "'", double64 == 146.01712228365548d);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 96 + "'", int65 == 96);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 243 + "'", int66 == 243);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[][] doubleArray8 = array2DRowRealMatrix7.getData();
        double[][] doubleArray9 = array2DRowRealMatrix7.getData();
        double[] doubleArray16 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16);
        double[] doubleArray24 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray24);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair26 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray16, doubleArray24);
        double[] doubleArray27 = pointVectorValuePair26.getFirst();
        double[] doubleArray28 = pointVectorValuePair26.getPointRef();
        double[] doubleArray35 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray35);
        double[] doubleArray43 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix44 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray43);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair45 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray35, doubleArray43);
        double[] doubleArray46 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray28, doubleArray43);
        double[] doubleArray47 = array2DRowRealMatrix7.preMultiply(doubleArray43);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex48 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray47);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder0 = new org.apache.commons.math3.optim.univariate.BracketFinder();
        int int1 = bracketFinder0.getMaxEvaluations();
        int int2 = bracketFinder0.getEvaluations();
        double double3 = bracketFinder0.getFMid();
        double double4 = bracketFinder0.getMid();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 50 + "'", int1 == 50);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        double double1 = org.apache.commons.math3.util.FastMath.toDegrees(310.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 17761.69164905552d + "'", double1 == 17761.69164905552d);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[][] doubleArray8 = array2DRowRealMatrix7.getData();
        double[] doubleArray15 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        double double17 = array2DRowRealMatrix16.getFrobeniusNorm();
        java.lang.String str18 = array2DRowRealMatrix16.toString();
        org.apache.commons.math3.linear.RealMatrix realMatrix19 = array2DRowRealMatrix7.subtract((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix16);
        double double20 = array2DRowRealMatrix16.getNorm();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor21 = null;
        try {
            double double22 = array2DRowRealMatrix16.walkInColumnOrder(realMatrixChangingVisitor21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 61.886993787063204d + "'", double17 == 61.886993787063204d);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Array2DRowRealMatrix{{32.0},{0.0},{52.0},{-1.0},{10.0},{-1.0}}" + "'", str18.equals("Array2DRowRealMatrix{{32.0},{0.0},{52.0},{-1.0},{10.0},{-1.0}}"));
        org.junit.Assert.assertNotNull(realMatrix19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 96.0d + "'", double20 == 96.0d);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        double[] doubleArray23 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray23);
        double[] doubleArray31 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray31);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair33 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray23, doubleArray31);
        double[] doubleArray34 = pointVectorValuePair33.getFirst();
        double[] doubleArray35 = pointVectorValuePair33.getPointRef();
        double[] doubleArray42 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix43 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray42);
        double[] doubleArray50 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix51 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray50);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair52 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray42, doubleArray50);
        double[] doubleArray53 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray35, doubleArray50);
        double[] doubleArray54 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray14, doubleArray50);
        double[] doubleArray61 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix62 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray61);
        double[] doubleArray69 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix70 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray69);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair71 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray61, doubleArray69);
        double[] doubleArray72 = pointVectorValuePair71.getValue();
        double[] doubleArray73 = pointVectorValuePair71.getPointRef();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector74 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray73);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector75 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector74);
        double double76 = arrayRealVector75.getMaxValue();
        double[] doubleArray77 = arrayRealVector75.getDataRef();
        double[] doubleArray78 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray14, doubleArray77);
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex79 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray14);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.ZeroException; message: equal vertices 0 and {1} in simplex configuration");
        } catch (org.apache.commons.math3.exception.ZeroException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 52.0d + "'", double76 == 52.0d);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray78);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        double[] doubleArray17 = pointVectorValuePair16.getValue();
        double[] doubleArray18 = pointVectorValuePair16.getPointRef();
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix19 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray18);
        org.apache.commons.math3.linear.RealMatrix realMatrix20 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray18);
        double[] doubleArray21 = new double[] {};
        double[] doubleArray28 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray28);
        double[][] doubleArray30 = array2DRowRealMatrix29.getData();
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray21, doubleArray30);
        try {
            org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray18, doubleArray30);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 6");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray30);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((float) 1, 10.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver2 = new org.apache.commons.math3.analysis.solvers.BrentSolver(0.0d, 1.1180339887498947d);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver3 = new org.apache.commons.math3.analysis.solvers.BrentSolver(0.0d, 1.1125369292536007E-308d, 9.0d);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[][] doubleArray8 = array2DRowRealMatrix7.getData();
        double[][] doubleArray9 = array2DRowRealMatrix7.getData();
        double[] doubleArray16 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16);
        double double18 = array2DRowRealMatrix17.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix7, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector23.addToEntry(0, (double) 1.0f);
        arrayRealVector23.unitize();
        array2DRowRealMatrix7.setRowVector(0, (org.apache.commons.math3.linear.RealVector) arrayRealVector23);
        org.apache.commons.math3.linear.RealVector realVector30 = array2DRowRealMatrix7.getRowVector(0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 61.886993787063204d + "'", double18 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(realVector30);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        double[] doubleArray22 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix23 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray22);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair24 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray14, doubleArray22);
        double[] doubleArray25 = pointVectorValuePair24.getFirst();
        double[] doubleArray26 = pointVectorValuePair24.getPointRef();
        double[] doubleArray33 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray33);
        double[] doubleArray41 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix42 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray41);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair43 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray33, doubleArray41);
        double[] doubleArray44 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray26, doubleArray41);
        double[] doubleArray49 = new double[] { (short) 10, 10L, 'a', 0.7650730050315234d };
        org.apache.commons.math3.optim.SimpleBounds simpleBounds50 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray44, doubleArray49);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair52 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray44, false);
        org.apache.commons.math3.linear.RealMatrix realMatrix53 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray6);
        org.apache.commons.math3.optim.InitialGuess initialGuess54 = new org.apache.commons.math3.optim.InitialGuess(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(realMatrix53);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[][] doubleArray8 = array2DRowRealMatrix7.getData();
        double[] doubleArray15 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        double double17 = array2DRowRealMatrix16.getFrobeniusNorm();
        java.lang.String str18 = array2DRowRealMatrix16.toString();
        org.apache.commons.math3.linear.RealMatrix realMatrix19 = array2DRowRealMatrix7.subtract((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix16);
        double[] doubleArray20 = null;
        try {
            double[] doubleArray21 = array2DRowRealMatrix7.preMultiply(doubleArray20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 61.886993787063204d + "'", double17 == 61.886993787063204d);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Array2DRowRealMatrix{{32.0},{0.0},{52.0},{-1.0},{10.0},{-1.0}}" + "'", str18.equals("Array2DRowRealMatrix{{32.0},{0.0},{52.0},{-1.0},{10.0},{-1.0}}"));
        org.junit.Assert.assertNotNull(realMatrix19);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        double[] doubleArray17 = pointVectorValuePair16.getValue();
        org.apache.commons.math3.linear.RealVector realVector18 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray17);
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma19 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray17);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException; message: -1 is smaller than the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(realVector18);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        int int1 = org.apache.commons.math3.util.FastMath.getExponent((float) 986830553);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 29 + "'", int1 == 29);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        byte byte2 = org.apache.commons.math3.util.MathUtils.copySign((byte) -1, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        double double2 = org.apache.commons.math3.util.MathUtils.normalizeAngle((double) (short) -1, (double) (-4228292497824268148L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-4.2282924978242678E18d) + "'", double2 == (-4.2282924978242678E18d));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double double8 = array2DRowRealMatrix7.getFrobeniusNorm();
        double[] doubleArray15 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        double[][] doubleArray17 = array2DRowRealMatrix16.getData();
        double[][] doubleArray18 = array2DRowRealMatrix16.getData();
        double[] doubleArray25 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double double27 = array2DRowRealMatrix26.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix16, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix26);
        org.apache.commons.math3.linear.RealMatrix realMatrix29 = array2DRowRealMatrix7.add((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix16);
        double[] doubleArray36 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix37 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray36);
        org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) realMatrix29, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix37);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkRowIndex((org.apache.commons.math3.linear.AnyMatrix) realMatrix29, 50);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (50)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 61.886993787063204d + "'", double8 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 61.886993787063204d + "'", double27 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertNotNull(doubleArray36);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[][] doubleArray8 = array2DRowRealMatrix7.getData();
        double[][] doubleArray9 = array2DRowRealMatrix7.getData();
        double[] doubleArray16 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16);
        double[] doubleArray24 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray24);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair26 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray16, doubleArray24);
        double[] doubleArray27 = pointVectorValuePair26.getFirst();
        double[] doubleArray28 = array2DRowRealMatrix7.preMultiply(doubleArray27);
        double[] doubleArray35 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray35);
        double[][] doubleArray37 = array2DRowRealMatrix36.getData();
        double[][] doubleArray38 = array2DRowRealMatrix36.getData();
        try {
            org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray27, doubleArray38);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 6");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        double double2 = org.apache.commons.math3.util.FastMath.nextAfter(Double.NaN, (double) 29);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.apache.commons.math3.linear.RealMatrix realMatrix1 = org.apache.commons.math3.linear.MatrixUtils.createRealIdentityMatrix(127);
        org.junit.Assert.assertNotNull(realMatrix1);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        double[] doubleArray17 = pointVectorValuePair16.getValue();
        org.apache.commons.math3.linear.RealVector realVector18 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray17);
        double[] doubleArray25 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double[] doubleArray33 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray33);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair35 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray25, doubleArray33);
        double[] doubleArray36 = pointVectorValuePair35.getValue();
        org.apache.commons.math3.linear.RealVector realVector37 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray36);
        org.apache.commons.math3.linear.RealVector realVector38 = realVector18.projection(realVector37);
        int int39 = realVector37.getMinIndex();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector42.addToEntry(0, (double) 1.0f);
        double[] doubleArray52 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix53 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray52);
        double[][] doubleArray54 = array2DRowRealMatrix53.getData();
        double[][] doubleArray55 = array2DRowRealMatrix53.getData();
        double[] doubleArray62 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix63 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray62);
        double double64 = array2DRowRealMatrix63.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix53, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix63);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector69 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector69.addToEntry(0, (double) 1.0f);
        arrayRealVector69.unitize();
        array2DRowRealMatrix53.setRowVector(0, (org.apache.commons.math3.linear.RealVector) arrayRealVector69);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector75 = arrayRealVector42.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector69);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector76 = new org.apache.commons.math3.linear.ArrayRealVector(realVector37, arrayRealVector69);
        org.apache.commons.math3.linear.RealVector realVector77 = realVector37.unitVector();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(realVector37);
        org.junit.Assert.assertNotNull(realVector38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 5 + "'", int39 == 5);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 61.886993787063204d + "'", double64 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(arrayRealVector75);
        org.junit.Assert.assertNotNull(realVector77);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        double double1 = org.apache.commons.math3.util.FastMath.exp((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.36787944117144233d + "'", double1 == 0.36787944117144233d);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double double8 = array2DRowRealMatrix7.getFrobeniusNorm();
        double[] doubleArray15 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        double[][] doubleArray17 = array2DRowRealMatrix16.getData();
        double[][] doubleArray18 = array2DRowRealMatrix16.getData();
        double[] doubleArray25 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double double27 = array2DRowRealMatrix26.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix16, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix26);
        org.apache.commons.math3.linear.RealMatrix realMatrix29 = array2DRowRealMatrix7.add((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix16);
        boolean boolean30 = array2DRowRealMatrix7.isSquare();
        double[] doubleArray37 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix38 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray37);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor39 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double40 = array2DRowRealMatrix38.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor39);
        try {
            double double45 = array2DRowRealMatrix7.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor39, 6, 10, (int) (short) 10, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (6)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 61.886993787063204d + "'", double8 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 61.886993787063204d + "'", double27 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 100, (int) (byte) 10);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.createMatrix(50, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 100, (int) (byte) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix4 = null;
        try {
            blockRealMatrix2.setColumnMatrix((int) (short) 1, realMatrix4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        short short2 = org.apache.commons.math3.util.MathUtils.copySign((short) 0, (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 100, (int) (byte) 10);
        double[] doubleArray10 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray10);
        double[] doubleArray18 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray18);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair20 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray10, doubleArray18);
        double[] doubleArray27 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray27);
        double[] doubleArray35 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray35);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair37 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray27, doubleArray35);
        double[] doubleArray38 = pointVectorValuePair37.getFirst();
        double[] doubleArray39 = pointVectorValuePair37.getPointRef();
        double[] doubleArray46 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix47 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray46);
        double[] doubleArray54 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix55 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray54);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair56 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray46, doubleArray54);
        double[] doubleArray57 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray39, doubleArray54);
        double[] doubleArray58 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray18, doubleArray54);
        double[] doubleArray65 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix66 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray65);
        double[] doubleArray73 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix74 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray73);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair75 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray65, doubleArray73);
        double[] doubleArray76 = pointVectorValuePair75.getValue();
        double[] doubleArray77 = pointVectorValuePair75.getPointRef();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector78 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray77);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector79 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector78);
        double double80 = arrayRealVector79.getMaxValue();
        double[] doubleArray81 = arrayRealVector79.getDataRef();
        double[] doubleArray82 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray18, doubleArray81);
        try {
            blockRealMatrix2.setColumn((-127), doubleArray18);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (-127)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 52.0d + "'", double80 == 52.0d);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(doubleArray82);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector2.addToEntry(0, (double) 1.0f);
        int int6 = arrayRealVector2.getMaxIndex();
        org.apache.commons.math3.linear.RealVector realVector7 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = arrayRealVector2.ebeDivide(realVector7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }
}

