import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        double[] doubleArray22 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix23 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray22);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair24 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray14, doubleArray22);
        double[] doubleArray25 = pointVectorValuePair24.getFirst();
        double[] doubleArray26 = pointVectorValuePair24.getPointRef();
        double[] doubleArray33 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray33);
        double[] doubleArray41 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix42 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray41);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair43 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray33, doubleArray41);
        double[] doubleArray44 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray26, doubleArray41);
        double[] doubleArray49 = new double[] { (short) 10, 10L, 'a', 0.7650730050315234d };
        org.apache.commons.math3.optim.SimpleBounds simpleBounds50 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray44, doubleArray49);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair52 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray44, false);
        double[] doubleArray53 = pointVectorValuePair52.getSecond();
        double[] doubleArray54 = pointVectorValuePair52.getFirst();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray54);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula0 = org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.POLAK_RIBIERE;
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker4 = new org.apache.commons.math3.optim.SimpleValueChecker((-135.01712228365548d), 96.0d, 6);
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver7 = new org.apache.commons.math3.analysis.solvers.BrentSolver((double) 100L, (double) 'a');
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.Preconditioner preconditioner8 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer9 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker4, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver7, preconditioner8);
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType10 = nonLinearConjugateGradientOptimizer9.getGoalType();
        org.junit.Assert.assertTrue("'" + formula0 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.POLAK_RIBIERE + "'", formula0.equals(org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.POLAK_RIBIERE));
        org.junit.Assert.assertNull(goalType10);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 100, (int) (byte) 10);
        double[] doubleArray10 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray10);
        double[] doubleArray18 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray18);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair20 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray10, doubleArray18);
        org.apache.commons.math3.optim.InitialGuess initialGuess21 = new org.apache.commons.math3.optim.InitialGuess(doubleArray10);
        double[] doubleArray22 = initialGuess21.getInitialGuess();
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray22);
        double[] doubleArray25 = diagonalMatrix23.getRow(1);
        org.apache.commons.math3.linear.RealMatrix realMatrix28 = diagonalMatrix23.createMatrix((int) (byte) 1, (int) (short) 1);
        try {
            blockRealMatrix2.setColumnMatrix(1, (org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 6x6 but expected 100x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realMatrix28);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.apache.commons.math3.linear.NonSquareMatrixException nonSquareMatrixException2 = new org.apache.commons.math3.linear.NonSquareMatrixException(0, (int) '4');
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[][] doubleArray8 = array2DRowRealMatrix7.getData();
        double[][] doubleArray9 = array2DRowRealMatrix7.getData();
        double[] doubleArray16 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16);
        double[] doubleArray24 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray24);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair26 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray16, doubleArray24);
        double[] doubleArray27 = pointVectorValuePair26.getFirst();
        double[] doubleArray28 = pointVectorValuePair26.getPointRef();
        double[] doubleArray35 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray35);
        double[] doubleArray43 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix44 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray43);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair45 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray35, doubleArray43);
        double[] doubleArray46 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray28, doubleArray43);
        double[] doubleArray47 = array2DRowRealMatrix7.preMultiply(doubleArray43);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray43);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector53 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector53.addToEntry(0, (double) 1.0f);
        int int57 = arrayRealVector53.getMaxIndex();
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector58 = arrayRealVector48.combine((double) 9.536743E-7f, (-1.0728086555169287d), (org.apache.commons.math3.linear.RealVector) arrayRealVector53);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 6 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder0 = new org.apache.commons.math3.optim.univariate.BracketFinder();
        int int1 = bracketFinder0.getEvaluations();
        double double2 = bracketFinder0.getFLo();
        org.apache.commons.math3.analysis.function.Sinc sinc3 = new org.apache.commons.math3.analysis.function.Sinc();
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType4 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE;
        bracketFinder0.search((org.apache.commons.math3.analysis.UnivariateFunction) sinc3, goalType4, 0.9835877454343449d, 0.0d);
        try {
            double[] doubleArray11 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.bracket((org.apache.commons.math3.analysis.UnivariateFunction) sinc3, 93.82298495129156d, (-1.0d), 35.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [93.823, 35]");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + goalType4 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE + "'", goalType4.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.apache.commons.math3.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math3.exception.NoBracketingException((double) (-127), (double) ' ', (double) ' ', (double) 1.0000001f);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder0 = new org.apache.commons.math3.optim.univariate.BracketFinder();
        int int1 = bracketFinder0.getMaxEvaluations();
        int int2 = bracketFinder0.getEvaluations();
        double double3 = bracketFinder0.getLo();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 50 + "'", int1 == 50);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        int[] intArray6 = new int[] { (byte) 100 };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister7 = new org.apache.commons.math3.random.MersenneTwister(intArray6);
        double double8 = mersenneTwister7.nextGaussian();
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker10 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer11 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer((int) 'a', (double) 10, true, (int) (short) -1, 0, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister7, false, pointValuePairConvergenceChecker10);
        mersenneTwister7.setSeed((long) (byte) 10);
        long long14 = mersenneTwister7.nextLong();
        int[] intArray18 = new int[] { (byte) 1, (byte) 100, '4' };
        int[] intArray23 = new int[] { 'a', (short) 1, (byte) 100, 'a' };
        double double24 = org.apache.commons.math3.util.MathArrays.distance(intArray18, intArray23);
        int[] intArray28 = new int[] { (byte) 1, (byte) 100, '4' };
        int[] intArray33 = new int[] { 'a', (short) 1, (byte) 100, 'a' };
        double double34 = org.apache.commons.math3.util.MathArrays.distance(intArray28, intArray33);
        int int35 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray18, intArray28);
        int[] intArray39 = new int[] { (byte) 1, (byte) 100, '4' };
        int[] intArray44 = new int[] { 'a', (short) 1, (byte) 100, 'a' };
        double double45 = org.apache.commons.math3.util.MathArrays.distance(intArray39, intArray44);
        int[] intArray49 = new int[] { (byte) 1, (byte) 100, '4' };
        int[] intArray54 = new int[] { 'a', (short) 1, (byte) 100, 'a' };
        double double55 = org.apache.commons.math3.util.MathArrays.distance(intArray49, intArray54);
        int int56 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray39, intArray49);
        int int57 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray28, intArray49);
        mersenneTwister7.setSeed(intArray49);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.7650730050315234d + "'", double8 == 0.7650730050315234d);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-7910618197763358337L) + "'", long14 == (-7910618197763358337L));
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 146.01712228365548d + "'", double24 == 146.01712228365548d);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 146.01712228365548d + "'", double34 == 146.01712228365548d);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 146.01712228365548d + "'", double45 == 146.01712228365548d);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertNotNull(intArray54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 146.01712228365548d + "'", double55 == 146.01712228365548d);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        double[] doubleArray17 = pointVectorValuePair16.getValue();
        double[] doubleArray18 = pointVectorValuePair16.getPointRef();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray18);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector19);
        org.apache.commons.math3.linear.RealVector realVector22 = arrayRealVector20.append((double) 36);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector26.addToEntry(0, (double) 1.0f);
        double[] doubleArray36 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix37 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray36);
        double[][] doubleArray38 = array2DRowRealMatrix37.getData();
        double[][] doubleArray39 = array2DRowRealMatrix37.getData();
        double[] doubleArray46 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix47 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray46);
        double double48 = array2DRowRealMatrix47.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix37, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix47);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector53 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector53.addToEntry(0, (double) 1.0f);
        arrayRealVector53.unitize();
        array2DRowRealMatrix37.setRowVector(0, (org.apache.commons.math3.linear.RealVector) arrayRealVector53);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector59 = arrayRealVector26.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector53);
        try {
            arrayRealVector20.setSubVector((-266497663), (org.apache.commons.math3.linear.RealVector) arrayRealVector53);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (-266,497,663)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 61.886993787063204d + "'", double48 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(arrayRealVector59);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6, true);
        double[] doubleArray25 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double[] doubleArray33 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray33);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair35 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray25, doubleArray33);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix37 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray25, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix38 = diagonalMatrix18.add(diagonalMatrix37);
        diagonalMatrix38.multiplyEntry(50, (int) '4', (-0.5d));
        double[] doubleArray49 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix50 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray49);
        org.apache.commons.math3.linear.RealMatrix realMatrix51 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray49);
        double[] doubleArray52 = diagonalMatrix38.operate(doubleArray49);
        java.lang.Object obj53 = null;
        boolean boolean54 = diagonalMatrix38.equals(obj53);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(diagonalMatrix38);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(realMatrix51);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer powellOptimizer4 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer(17761.69164905552d, (double) 1.0000001f, (double) '4', (-1.0d));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 100, (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        double[] doubleArray10 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray10);
        double double12 = array2DRowRealMatrix11.getFrobeniusNorm();
        double[] doubleArray19 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray19);
        double[][] doubleArray21 = array2DRowRealMatrix20.getData();
        double[][] doubleArray22 = array2DRowRealMatrix20.getData();
        double[] doubleArray29 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix30 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray29);
        double double31 = array2DRowRealMatrix30.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix20, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix30);
        org.apache.commons.math3.linear.RealMatrix realMatrix33 = array2DRowRealMatrix11.add((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix20);
        double[] doubleArray40 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix41 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray40);
        double[][] doubleArray42 = array2DRowRealMatrix41.getData();
        double[][] doubleArray43 = array2DRowRealMatrix41.getData();
        double[] doubleArray50 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix51 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray50);
        double[] doubleArray58 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix59 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray58);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair60 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray50, doubleArray58);
        double[] doubleArray61 = pointVectorValuePair60.getFirst();
        double[] doubleArray62 = pointVectorValuePair60.getPointRef();
        double[] doubleArray69 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix70 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray69);
        double[] doubleArray77 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix78 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray77);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair79 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray69, doubleArray77);
        double[] doubleArray80 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray62, doubleArray77);
        double[] doubleArray81 = array2DRowRealMatrix41.preMultiply(doubleArray77);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix82 = array2DRowRealMatrix20.subtract(array2DRowRealMatrix41);
        double[] doubleArray89 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix90 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray89);
        double[][] doubleArray91 = array2DRowRealMatrix90.getData();
        double[][] doubleArray92 = array2DRowRealMatrix90.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix93 = array2DRowRealMatrix41.add(array2DRowRealMatrix90);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix94 = blockRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix41);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 100x10 but expected 6x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 61.886993787063204d + "'", double12 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 61.886993787063204d + "'", double31 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(realMatrix33);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix82);
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertNotNull(doubleArray91);
        org.junit.Assert.assertNotNull(doubleArray92);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix93);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        float float2 = org.apache.commons.math3.util.FastMath.nextAfter((float) 96L, (double) (byte) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 95.99999f + "'", float2 == 95.99999f);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver2 = new org.apache.commons.math3.analysis.solvers.BrentSolver((double) 100L, (double) 'a');
        double double3 = brentSolver2.getStartValue();
        int int4 = brentSolver2.getEvaluations();
        double double5 = brentSolver2.getAbsoluteAccuracy();
        double double6 = brentSolver2.getMax();
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder8 = new org.apache.commons.math3.optim.univariate.BracketFinder();
        int int9 = bracketFinder8.getEvaluations();
        double double10 = bracketFinder8.getFLo();
        org.apache.commons.math3.analysis.function.Sinc sinc11 = new org.apache.commons.math3.analysis.function.Sinc();
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType12 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE;
        bracketFinder8.search((org.apache.commons.math3.analysis.UnivariateFunction) sinc11, goalType12, 0.9835877454343449d, 0.0d);
        try {
            double double17 = brentSolver2.solve((int) (byte) -1, (org.apache.commons.math3.analysis.UnivariateFunction) sinc11, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.TooManyEvaluationsException; message: illegal state: maximal count (-1) exceeded: evaluations");
        } catch (org.apache.commons.math3.exception.TooManyEvaluationsException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 97.0d + "'", double5 == 97.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + goalType12 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE + "'", goalType12.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double double1 = arrayRealVector0.getNorm();
        double double2 = arrayRealVector0.getMinValue();
        double[] doubleArray9 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray9);
        double[][] doubleArray11 = array2DRowRealMatrix10.getData();
        double[][] doubleArray12 = array2DRowRealMatrix10.getData();
        double[] doubleArray19 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray19);
        double double21 = array2DRowRealMatrix20.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix10, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix20);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector26.addToEntry(0, (double) 1.0f);
        arrayRealVector26.unitize();
        array2DRowRealMatrix10.setRowVector(0, (org.apache.commons.math3.linear.RealVector) arrayRealVector26);
        org.apache.commons.math3.linear.RealVector realVector32 = arrayRealVector0.append((org.apache.commons.math3.linear.RealVector) arrayRealVector26);
        double[] doubleArray33 = arrayRealVector26.toArray();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 61.886993787063204d + "'", double21 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(realVector32);
        org.junit.Assert.assertNotNull(doubleArray33);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker4 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker((double) ' ', (double) '#');
        org.apache.commons.math3.optim.univariate.BrentOptimizer brentOptimizer5 = new org.apache.commons.math3.optim.univariate.BrentOptimizer((double) 1.0000001f, (double) ' ', (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.univariate.UnivariatePointValuePair>) simpleUnivariateValueChecker4);
        double double6 = brentOptimizer5.getMax();
        double double7 = brentOptimizer5.getMin();
        double double8 = brentOptimizer5.getMin();
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType9 = brentOptimizer5.getGoalType();
        double double10 = brentOptimizer5.getMax();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNull(goalType9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 100, (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        try {
            double[] doubleArray5 = blockRealMatrix2.getRow((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector2.addToEntry(0, (double) 1.0f);
        org.apache.commons.math3.linear.RealVector realVector7 = arrayRealVector2.mapSubtractToSelf(146.01712228365548d);
        double double8 = arrayRealVector2.getMaxValue();
        double[] doubleArray15 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        double[] doubleArray23 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray23);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair25 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray15, doubleArray23);
        double[] doubleArray26 = pointVectorValuePair25.getValue();
        double[] doubleArray27 = pointVectorValuePair25.getPointRef();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray27);
        org.apache.commons.math3.linear.RealVector realVector30 = arrayRealVector28.mapMultiplyToSelf((double) (byte) 1);
        double[] doubleArray38 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix39 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray38);
        double[] doubleArray46 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix47 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray46);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair48 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray38, doubleArray46);
        double[] doubleArray49 = pointVectorValuePair48.getValue();
        org.apache.commons.math3.linear.RealVector realVector50 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray49);
        arrayRealVector28.setSubVector(0, realVector50);
        org.apache.commons.math3.linear.RealVector realVector53 = arrayRealVector28.mapAdd(146.01712228365548d);
        try {
            double double54 = arrayRealVector2.cosine((org.apache.commons.math3.linear.RealVector) arrayRealVector28);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 6");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realVector7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-135.01712228365548d) + "'", double8 == (-135.01712228365548d));
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(realVector30);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(realVector50);
        org.junit.Assert.assertNotNull(realVector53);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        double[] doubleArray17 = pointVectorValuePair16.getValue();
        org.apache.commons.math3.linear.RealVector realVector18 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray17);
        double[] doubleArray25 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double[] doubleArray33 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray33);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair35 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray25, doubleArray33);
        double[] doubleArray36 = pointVectorValuePair35.getValue();
        org.apache.commons.math3.linear.RealVector realVector37 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray36);
        org.apache.commons.math3.linear.RealVector realVector38 = realVector18.projection(realVector37);
        int int39 = realVector18.getMaxIndex();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(realVector37);
        org.junit.Assert.assertNotNull(realVector38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2 + "'", int39 == 2);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        double double1 = org.apache.commons.math3.util.FastMath.floor((double) (short) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException0 = new org.apache.commons.math3.exception.MathIllegalStateException();
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray8 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray8);
        double[][] doubleArray10 = array2DRowRealMatrix9.getData();
        double[][] doubleArray11 = array2DRowRealMatrix9.getData();
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException12 = new org.apache.commons.math3.exception.MaxCountExceededException(localizable0, (java.lang.Number) 83.86684335012045d, (java.lang.Object[]) doubleArray11);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext13 = maxCountExceededException12.getContext();
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(exceptionContext13);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[][] doubleArray8 = array2DRowRealMatrix7.getData();
        double[] doubleArray15 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor17 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double18 = array2DRowRealMatrix16.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor17);
        double double19 = array2DRowRealMatrix7.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor17);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor20 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        defaultRealMatrixPreservingVisitor20.visit(0, (int) (short) 0, (double) '#');
        defaultRealMatrixPreservingVisitor20.start((int) (short) 1, 100, 50, 6, 50, 2147483647);
        try {
            double double36 = array2DRowRealMatrix7.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor20, (int) (byte) -1, 0, 2147483647, (-266497663));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        double[] doubleArray17 = pointVectorValuePair16.getValue();
        org.apache.commons.math3.linear.RealVector realVector18 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray17);
        double[] doubleArray25 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double[] doubleArray33 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray33);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair35 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray25, doubleArray33);
        double[] doubleArray36 = pointVectorValuePair35.getValue();
        org.apache.commons.math3.linear.RealVector realVector37 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray36);
        org.apache.commons.math3.linear.RealVector realVector38 = realVector18.projection(realVector37);
        int int39 = realVector37.getMinIndex();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector42.addToEntry(0, (double) 1.0f);
        double[] doubleArray52 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix53 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray52);
        double[][] doubleArray54 = array2DRowRealMatrix53.getData();
        double[][] doubleArray55 = array2DRowRealMatrix53.getData();
        double[] doubleArray62 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix63 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray62);
        double double64 = array2DRowRealMatrix63.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix53, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix63);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector69 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector69.addToEntry(0, (double) 1.0f);
        arrayRealVector69.unitize();
        array2DRowRealMatrix53.setRowVector(0, (org.apache.commons.math3.linear.RealVector) arrayRealVector69);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector75 = arrayRealVector42.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector69);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector76 = new org.apache.commons.math3.linear.ArrayRealVector(realVector37, arrayRealVector69);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector77 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector76);
        int int78 = arrayRealVector76.getMinIndex();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(realVector37);
        org.junit.Assert.assertNotNull(realVector38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 5 + "'", int39 == 5);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 61.886993787063204d + "'", double64 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(arrayRealVector75);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 5 + "'", int78 == 5);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex3 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex((int) (byte) -1, 0.0d, (-1.0665888468632587E-7d));
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 100, (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.scalarAdd(0.0d);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor6 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        defaultRealMatrixPreservingVisitor6.visit(0, (int) (short) 0, (double) '#');
        defaultRealMatrixPreservingVisitor6.start((int) (short) 1, 100, 50, 6, 50, 2147483647);
        defaultRealMatrixPreservingVisitor6.visit(5, (int) (short) 0, 127.0d);
        try {
            double double26 = blockRealMatrix5.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor6, 96, 986830553, (-1), (-266497663));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (986,830,553)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        org.apache.commons.math3.optim.InitialGuess initialGuess17 = new org.apache.commons.math3.optim.InitialGuess(doubleArray6);
        double[] doubleArray18 = initialGuess17.getInitialGuess();
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix19 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray18);
        double[] doubleArray26 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix27 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray26);
        double[] doubleArray34 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix35 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray34);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair36 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray26, doubleArray34);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix38 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray26, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix39 = diagonalMatrix19.multiply(diagonalMatrix38);
        double[] doubleArray40 = diagonalMatrix19.getDataRef();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(diagonalMatrix39);
        org.junit.Assert.assertNotNull(doubleArray40);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double double8 = array2DRowRealMatrix7.getFrobeniusNorm();
        java.lang.String str9 = array2DRowRealMatrix7.toString();
        double[] doubleArray16 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16);
        double[] doubleArray24 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray24);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair26 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray16, doubleArray24);
        double[] doubleArray33 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray33);
        double[] doubleArray41 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix42 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray41);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair43 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray33, doubleArray41);
        double[] doubleArray44 = pointVectorValuePair43.getFirst();
        double[] doubleArray45 = pointVectorValuePair43.getPointRef();
        double[] doubleArray52 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix53 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray52);
        double[] doubleArray60 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix61 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray60);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair62 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray52, doubleArray60);
        double[] doubleArray63 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray45, doubleArray60);
        double[] doubleArray64 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray24, doubleArray60);
        double[] doubleArray65 = array2DRowRealMatrix7.preMultiply(doubleArray24);
        try {
            array2DRowRealMatrix7.setEntry(100, 50, Double.NEGATIVE_INFINITY);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 61.886993787063204d + "'", double8 == 61.886993787063204d);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Array2DRowRealMatrix{{32.0},{0.0},{52.0},{-1.0},{10.0},{-1.0}}" + "'", str9.equals("Array2DRowRealMatrix{{32.0},{0.0},{52.0},{-1.0},{10.0},{-1.0}}"));
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray65);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        org.apache.commons.math3.optim.InitialGuess initialGuess17 = new org.apache.commons.math3.optim.InitialGuess(doubleArray6);
        double[] doubleArray18 = initialGuess17.getInitialGuess();
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix19 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray18);
        double[] doubleArray26 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix27 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray26);
        double double28 = array2DRowRealMatrix27.getFrobeniusNorm();
        double[] doubleArray35 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray35);
        double[][] doubleArray37 = array2DRowRealMatrix36.getData();
        double[][] doubleArray38 = array2DRowRealMatrix36.getData();
        double[] doubleArray45 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix46 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray45);
        double double47 = array2DRowRealMatrix46.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix36, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix46);
        org.apache.commons.math3.linear.RealMatrix realMatrix49 = array2DRowRealMatrix27.add((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix36);
        double[][] doubleArray50 = array2DRowRealMatrix27.getDataRef();
        try {
            diagonalMatrix19.setSubMatrix(doubleArray50, 10, 29);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 61.886993787063204d + "'", double28 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 61.886993787063204d + "'", double47 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(realMatrix49);
        org.junit.Assert.assertNotNull(doubleArray50);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        double[] doubleArray17 = pointVectorValuePair16.getValue();
        double[] doubleArray18 = pointVectorValuePair16.getPointRef();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray18);
        double[] doubleArray26 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix27 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray26);
        double[] doubleArray34 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix35 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray34);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair36 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray26, doubleArray34);
        double[] doubleArray37 = pointVectorValuePair36.getFirst();
        double[] doubleArray38 = pointVectorValuePair36.getPointRef();
        double[] doubleArray45 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix46 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray45);
        double[] doubleArray53 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix54 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray53);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair55 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray45, doubleArray53);
        double[] doubleArray56 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray38, doubleArray53);
        double[] doubleArray61 = new double[] { (short) 10, 10L, 'a', 0.7650730050315234d };
        org.apache.commons.math3.optim.SimpleBounds simpleBounds62 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray56, doubleArray61);
        double[] doubleArray63 = simpleBounds62.getUpper();
        org.apache.commons.math3.util.Pair<double[], double[]> doubleArrayPair64 = new org.apache.commons.math3.util.Pair<double[], double[]>(doubleArray18, doubleArray63);
        org.apache.commons.math3.optim.SimpleVectorValueChecker simpleVectorValueChecker67 = new org.apache.commons.math3.optim.SimpleVectorValueChecker(Double.NEGATIVE_INFINITY, 0.7615942060206032d);
        double double68 = simpleVectorValueChecker67.getAbsoluteThreshold();
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer gaussNewtonOptimizer69 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer((org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair>) simpleVectorValueChecker67);
        double[] doubleArray70 = gaussNewtonOptimizer69.getStartPoint();
        boolean boolean71 = doubleArrayPair64.equals((java.lang.Object) doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.7615942060206032d + "'", double68 == 0.7615942060206032d);
        org.junit.Assert.assertNull(doubleArray70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6, true);
        double[] doubleArray25 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double[] doubleArray33 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray33);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair35 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray25, doubleArray33);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix37 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray25, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix38 = diagonalMatrix18.add(diagonalMatrix37);
        diagonalMatrix38.multiplyEntry(50, (int) '4', (-0.5d));
        double[] doubleArray49 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix50 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray49);
        double[] doubleArray57 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix58 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray57);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair59 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray49, doubleArray57);
        double[] doubleArray60 = pointVectorValuePair59.getValue();
        double[] doubleArray61 = pointVectorValuePair59.getPointRef();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector62 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray61);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector63 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector62);
        double double64 = arrayRealVector63.getMaxValue();
        double[] doubleArray65 = arrayRealVector63.getDataRef();
        double[] doubleArray66 = diagonalMatrix38.operate(doubleArray65);
        int int67 = diagonalMatrix38.getColumnDimension();
        double[] doubleArray73 = new double[] { (short) 1, 4.9E-324d, 10.0d, (-0.7249165551445564d), 2147483647 };
        double[] doubleArray79 = new double[] { (short) 1, 4.9E-324d, 10.0d, (-0.7249165551445564d), 2147483647 };
        double[] doubleArray85 = new double[] { (short) 1, 4.9E-324d, 10.0d, (-0.7249165551445564d), 2147483647 };
        double[] doubleArray91 = new double[] { (short) 1, 4.9E-324d, 10.0d, (-0.7249165551445564d), 2147483647 };
        double[][] doubleArray92 = new double[][] { doubleArray73, doubleArray79, doubleArray85, doubleArray91 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix94 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray92, false);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math3.linear.AnyMatrix) diagonalMatrix38, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix94);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 6 != 4");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(diagonalMatrix38);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 52.0d + "'", double64 == 52.0d);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 6 + "'", int67 == 6);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertNotNull(doubleArray91);
        org.junit.Assert.assertNotNull(doubleArray92);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        int int8 = array2DRowRealMatrix7.getRowDimension();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        double[] doubleArray17 = pointVectorValuePair16.getValue();
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder18 = new org.apache.commons.math3.optim.univariate.BracketFinder();
        int int19 = bracketFinder18.getMaxEvaluations();
        boolean boolean20 = pointVectorValuePair16.equals((java.lang.Object) bracketFinder18);
        double[] doubleArray21 = pointVectorValuePair16.getPoint();
        double[] doubleArray28 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray28);
        double double30 = array2DRowRealMatrix29.getFrobeniusNorm();
        java.lang.String str31 = array2DRowRealMatrix29.toString();
        double[] doubleArray38 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix39 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray38);
        double[] doubleArray46 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix47 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray46);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair48 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray38, doubleArray46);
        double[] doubleArray55 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix56 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray55);
        double[] doubleArray63 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix64 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray63);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair65 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray55, doubleArray63);
        double[] doubleArray66 = pointVectorValuePair65.getFirst();
        double[] doubleArray67 = pointVectorValuePair65.getPointRef();
        double[] doubleArray74 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix75 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray74);
        double[] doubleArray82 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix83 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray82);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair84 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray74, doubleArray82);
        double[] doubleArray85 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray67, doubleArray82);
        double[] doubleArray86 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray46, doubleArray82);
        double[] doubleArray87 = array2DRowRealMatrix29.preMultiply(doubleArray46);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition88 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray21, doubleArray46);
        double double89 = eigenDecomposition88.getDeterminant();
        double double90 = eigenDecomposition88.getDeterminant();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 50 + "'", int19 == 50);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 61.886993787063204d + "'", double30 == 61.886993787063204d);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Array2DRowRealMatrix{{32.0},{0.0},{52.0},{-1.0},{10.0},{-1.0}}" + "'", str31.equals("Array2DRowRealMatrix{{32.0},{0.0},{52.0},{-1.0},{10.0},{-1.0}}"));
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + (-3.104890880000001E8d) + "'", double89 == (-3.104890880000001E8d));
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + (-3.104890880000001E8d) + "'", double90 == (-3.104890880000001E8d));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.apache.commons.math3.linear.NonSymmetricMatrixException nonSymmetricMatrixException3 = new org.apache.commons.math3.linear.NonSymmetricMatrixException((int) (byte) 1, 0, 1.1102230246251565E-16d);
        int int4 = nonSymmetricMatrixException3.getColumn();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        long[] longArray6 = new long[] { (short) 0, 'a', 'a', (byte) -1, (short) 1, (byte) 10 };
        long[][] longArray7 = new long[][] { longArray6 };
        org.apache.commons.math3.util.MathArrays.checkRectangular(longArray7);
        try {
            org.apache.commons.math3.util.MathArrays.checkNonNegative(longArray7);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException; message: -1 is smaller than the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotPositiveException e) {
        }
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertNotNull(longArray7);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double double8 = array2DRowRealMatrix7.getFrobeniusNorm();
        double[] doubleArray15 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        double[][] doubleArray17 = array2DRowRealMatrix16.getData();
        double[][] doubleArray18 = array2DRowRealMatrix16.getData();
        double[] doubleArray25 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double double27 = array2DRowRealMatrix26.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix16, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix26);
        org.apache.commons.math3.linear.RealMatrix realMatrix29 = array2DRowRealMatrix7.add((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix16);
        double[] doubleArray36 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix37 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray36);
        double[] doubleArray44 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix45 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray44);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair46 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray36, doubleArray44);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix48 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray36, true);
        double[] doubleArray55 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix56 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray55);
        double[] doubleArray63 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix64 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray63);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair65 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray55, doubleArray63);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix67 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray55, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix68 = diagonalMatrix48.add(diagonalMatrix67);
        diagonalMatrix67.multiplyEntry((int) 'a', (-127), (double) 1.0f);
        org.apache.commons.math3.linear.RealMatrix realMatrix73 = array2DRowRealMatrix16.preMultiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix67);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 61.886993787063204d + "'", double8 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 61.886993787063204d + "'", double27 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(diagonalMatrix68);
        org.junit.Assert.assertNotNull(realMatrix73);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.apache.commons.math3.optim.SimpleVectorValueChecker simpleVectorValueChecker2 = new org.apache.commons.math3.optim.SimpleVectorValueChecker((double) 1L, (double) (-7910618197763358337L));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        int[] intArray1 = new int[] { (byte) 1 };
        int[] intArray5 = new int[] { (byte) 1, (byte) 100, '4' };
        int[] intArray10 = new int[] { 'a', (short) 1, (byte) 100, 'a' };
        double double11 = org.apache.commons.math3.util.MathArrays.distance(intArray5, intArray10);
        int int12 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray1, intArray10);
        int[] intArray16 = new int[] { (byte) 1, (byte) 100, '4' };
        int[] intArray21 = new int[] { 'a', (short) 1, (byte) 100, 'a' };
        double double22 = org.apache.commons.math3.util.MathArrays.distance(intArray16, intArray21);
        int[] intArray26 = new int[] { (byte) 1, (byte) 100, '4' };
        int[] intArray31 = new int[] { 'a', (short) 1, (byte) 100, 'a' };
        double double32 = org.apache.commons.math3.util.MathArrays.distance(intArray26, intArray31);
        int int33 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray16, intArray26);
        int[] intArray37 = new int[] { (byte) 1, (byte) 100, '4' };
        int[] intArray42 = new int[] { 'a', (short) 1, (byte) 100, 'a' };
        double double43 = org.apache.commons.math3.util.MathArrays.distance(intArray37, intArray42);
        int[] intArray47 = new int[] { (byte) 1, (byte) 100, '4' };
        int[] intArray52 = new int[] { 'a', (short) 1, (byte) 100, 'a' };
        double double53 = org.apache.commons.math3.util.MathArrays.distance(intArray47, intArray52);
        int int54 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray37, intArray47);
        int int55 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray26, intArray47);
        try {
            int int56 = org.apache.commons.math3.util.MathArrays.distance1(intArray10, intArray47);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 146.01712228365548d + "'", double11 == 146.01712228365548d);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 96 + "'", int12 == 96);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 146.01712228365548d + "'", double22 == 146.01712228365548d);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 146.01712228365548d + "'", double32 == 146.01712228365548d);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 146.01712228365548d + "'", double43 == 146.01712228365548d);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 146.01712228365548d + "'", double53 == 146.01712228365548d);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        int int1 = org.apache.commons.math3.util.FastMath.abs(50);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 50 + "'", int1 == 50);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        double[] doubleArray17 = pointVectorValuePair16.getValue();
        double[] doubleArray18 = pointVectorValuePair16.getPointRef();
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix19 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray18);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector22.addToEntry(0, (double) 1.0f);
        double[] doubleArray32 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray32);
        double[][] doubleArray34 = array2DRowRealMatrix33.getData();
        double[][] doubleArray35 = array2DRowRealMatrix33.getData();
        double[] doubleArray42 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix43 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray42);
        double double44 = array2DRowRealMatrix43.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix33, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix43);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector49.addToEntry(0, (double) 1.0f);
        arrayRealVector49.unitize();
        array2DRowRealMatrix33.setRowVector(0, (org.apache.commons.math3.linear.RealVector) arrayRealVector49);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector55 = arrayRealVector22.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector49);
        boolean boolean56 = diagonalMatrix19.equals((java.lang.Object) arrayRealVector55);
        double[] doubleArray63 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix64 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray63);
        double[] doubleArray71 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix72 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray71);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair73 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray63, doubleArray71);
        double[] doubleArray74 = pointVectorValuePair73.getValue();
        double[] doubleArray75 = pointVectorValuePair73.getPointRef();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector76 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray75);
        org.apache.commons.math3.linear.RealVector realVector78 = arrayRealVector76.mapMultiplyToSelf((double) (byte) 1);
        org.apache.commons.math3.linear.RealVector realVector79 = diagonalMatrix19.preMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector76);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 61.886993787063204d + "'", double44 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(arrayRealVector55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(realVector78);
        org.junit.Assert.assertNotNull(realVector79);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 100.0f, (java.lang.Number) 1.0d, false);
        boolean boolean5 = numberIsTooLargeException4.getBoundIsAllowed();
        boolean boolean6 = numberIsTooLargeException4.getBoundIsAllowed();
        try {
            java.lang.String str7 = numberIsTooLargeException4.toString();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double double8 = array2DRowRealMatrix7.getFrobeniusNorm();
        double[] doubleArray15 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        double[][] doubleArray17 = array2DRowRealMatrix16.getData();
        double[][] doubleArray18 = array2DRowRealMatrix16.getData();
        double[] doubleArray25 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double double27 = array2DRowRealMatrix26.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix16, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix26);
        org.apache.commons.math3.linear.RealMatrix realMatrix29 = array2DRowRealMatrix7.add((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix16);
        double[] doubleArray36 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix37 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray36);
        double[][] doubleArray38 = array2DRowRealMatrix37.getData();
        double[][] doubleArray39 = array2DRowRealMatrix37.getData();
        double[] doubleArray46 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix47 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray46);
        double[] doubleArray54 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix55 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray54);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair56 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray46, doubleArray54);
        double[] doubleArray57 = pointVectorValuePair56.getFirst();
        double[] doubleArray58 = pointVectorValuePair56.getPointRef();
        double[] doubleArray65 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix66 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray65);
        double[] doubleArray73 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix74 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray73);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair75 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray65, doubleArray73);
        double[] doubleArray76 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray58, doubleArray73);
        double[] doubleArray77 = array2DRowRealMatrix37.preMultiply(doubleArray73);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix78 = array2DRowRealMatrix16.subtract(array2DRowRealMatrix37);
        double[] doubleArray85 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix86 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray85);
        double[][] doubleArray87 = array2DRowRealMatrix86.getData();
        double[][] doubleArray88 = array2DRowRealMatrix86.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix89 = array2DRowRealMatrix37.add(array2DRowRealMatrix86);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor90 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        try {
            double double95 = array2DRowRealMatrix37.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor90, 243, 29, 1, 6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (243)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 61.886993787063204d + "'", double8 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 61.886993787063204d + "'", double27 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix78);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix89);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) (short) 100, 100, (int) (byte) -1, (int) (short) 100);
        try {
            int int6 = matrixDimensionMismatchException4.getExpectedDimension(1085139999);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1085139999");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        try {
            org.apache.commons.math3.optim.MaxEval maxEval1 = new org.apache.commons.math3.optim.MaxEval(0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver2 = new org.apache.commons.math3.analysis.solvers.BrentSolver(0.7650730050315234d, (double) (short) 0);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder0 = new org.apache.commons.math3.optim.univariate.BracketFinder();
        int int1 = bracketFinder0.getEvaluations();
        double double2 = bracketFinder0.getFLo();
        org.apache.commons.math3.analysis.function.Sinc sinc3 = new org.apache.commons.math3.analysis.function.Sinc();
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType4 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE;
        bracketFinder0.search((org.apache.commons.math3.analysis.UnivariateFunction) sinc3, goalType4, 0.9835877454343449d, 0.0d);
        org.apache.commons.math3.optim.univariate.UnivariateObjectiveFunction univariateObjectiveFunction8 = new org.apache.commons.math3.optim.univariate.UnivariateObjectiveFunction((org.apache.commons.math3.analysis.UnivariateFunction) sinc3);
        try {
            org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.verifyBracketing((org.apache.commons.math3.analysis.UnivariateFunction) sinc3, 127.0d, 96.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [127, 96]");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + goalType4 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE + "'", goalType4.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        float float1 = org.apache.commons.math3.util.FastMath.nextUp((float) 1085139999);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0851401E9f + "'", float1 == 1.0851401E9f);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        double[] doubleArray5 = new double[] { (short) 1, 4.9E-324d, 10.0d, (-0.7249165551445564d), 2147483647 };
        double[] doubleArray11 = new double[] { (short) 1, 4.9E-324d, 10.0d, (-0.7249165551445564d), 2147483647 };
        double[] doubleArray17 = new double[] { (short) 1, 4.9E-324d, 10.0d, (-0.7249165551445564d), 2147483647 };
        double[] doubleArray23 = new double[] { (short) 1, 4.9E-324d, 10.0d, (-0.7249165551445564d), 2147483647 };
        double[][] doubleArray24 = new double[][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray24, false);
        double[] doubleArray34 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix35 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray34);
        double[] doubleArray42 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix43 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray42);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair44 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray34, doubleArray42);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix46 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray34, true);
        double[] doubleArray53 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix54 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray53);
        double[] doubleArray61 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix62 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray61);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair63 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray53, doubleArray61);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix65 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray53, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix66 = diagonalMatrix46.add(diagonalMatrix65);
        double[] doubleArray67 = diagonalMatrix46.getDataRef();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix68 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray67);
        try {
            array2DRowRealMatrix26.setColumn(29, doubleArray67);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (29)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(diagonalMatrix66);
        org.junit.Assert.assertNotNull(doubleArray67);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double double8 = array2DRowRealMatrix7.getFrobeniusNorm();
        java.lang.String str9 = array2DRowRealMatrix7.toString();
        double[] doubleArray16 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16);
        double[][] doubleArray18 = array2DRowRealMatrix17.getData();
        double[][] doubleArray19 = array2DRowRealMatrix17.getData();
        double[] doubleArray26 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix27 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray26);
        double double28 = array2DRowRealMatrix27.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix17, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix27);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix30 = array2DRowRealMatrix7.preMultiply((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix17);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 6");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 61.886993787063204d + "'", double8 == 61.886993787063204d);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Array2DRowRealMatrix{{32.0},{0.0},{52.0},{-1.0},{10.0},{-1.0}}" + "'", str9.equals("Array2DRowRealMatrix{{32.0},{0.0},{52.0},{-1.0},{10.0},{-1.0}}"));
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 61.886993787063204d + "'", double28 == 61.886993787063204d);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6, true);
        double[] doubleArray25 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double[] doubleArray33 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray33);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair35 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray25, doubleArray33);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix37 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray25, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix38 = diagonalMatrix18.add(diagonalMatrix37);
        double double39 = diagonalMatrix38.getNorm();
        org.apache.commons.math3.linear.RealMatrix realMatrix40 = diagonalMatrix38.copy();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(diagonalMatrix38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 104.0d + "'", double39 == 104.0d);
        org.junit.Assert.assertNotNull(realMatrix40);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker2 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker((double) 1L, 0.0d);
        org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair6 = new org.apache.commons.math3.optim.univariate.UnivariatePointValuePair(0.0d, (double) 1.0f);
        double double7 = univariatePointValuePair6.getPoint();
        double double8 = univariatePointValuePair6.getValue();
        org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair11 = new org.apache.commons.math3.optim.univariate.UnivariatePointValuePair(0.0d, (double) 1.0f);
        boolean boolean12 = simpleUnivariateValueChecker2.converged(127, univariatePointValuePair6, univariatePointValuePair11);
        double double13 = simpleUnivariateValueChecker2.getRelativeThreshold();
        double double14 = simpleUnivariateValueChecker2.getRelativeThreshold();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 100, (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.scalarAdd(0.0d);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 100, (int) (byte) 10);
        double double9 = blockRealMatrix8.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix8.scalarAdd(0.0d);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix12 = blockRealMatrix2.multiply(blockRealMatrix11);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 10 != 100");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        double[] doubleArray0 = null;
        double[] doubleArray7 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        double[] doubleArray15 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair17 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray7, doubleArray15);
        double[] doubleArray24 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray24);
        double[] doubleArray32 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray32);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair34 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray24, doubleArray32);
        double[] doubleArray35 = pointVectorValuePair34.getFirst();
        double[] doubleArray36 = pointVectorValuePair34.getPointRef();
        double[] doubleArray43 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix44 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray43);
        double[] doubleArray51 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix52 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray51);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair53 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray43, doubleArray51);
        double[] doubleArray54 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray36, doubleArray51);
        double[] doubleArray55 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray15, doubleArray51);
        double[] doubleArray62 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix63 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray62);
        double[] doubleArray70 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix71 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray70);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair72 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray62, doubleArray70);
        double double73 = org.apache.commons.math3.util.MathArrays.linearCombination(doubleArray51, doubleArray62);
        double[] doubleArray80 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix81 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray80);
        double[] doubleArray88 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix89 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray88);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair90 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray80, doubleArray88);
        org.apache.commons.math3.optim.InitialGuess initialGuess91 = new org.apache.commons.math3.optim.InitialGuess(doubleArray80);
        boolean boolean92 = org.apache.commons.math3.util.MathArrays.equals(doubleArray51, doubleArray80);
        try {
            double[] doubleArray93 = org.apache.commons.math3.util.MathArrays.ebeSubtract(doubleArray0, doubleArray51);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 3830.0d + "'", double73 == 3830.0d);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + true + "'", boolean92 == true);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        float float1 = org.apache.commons.math3.util.FastMath.signum(9.536743E-7f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        double double1 = org.apache.commons.math3.util.FastMath.signum((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        int int1 = org.apache.commons.math3.util.FastMath.getExponent((float) (-266497663));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 27 + "'", int1 == 27);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        double[] doubleArray17 = pointVectorValuePair16.getValue();
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder18 = new org.apache.commons.math3.optim.univariate.BracketFinder();
        int int19 = bracketFinder18.getMaxEvaluations();
        boolean boolean20 = pointVectorValuePair16.equals((java.lang.Object) bracketFinder18);
        double[] doubleArray21 = pointVectorValuePair16.getPoint();
        double[] doubleArray28 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray28);
        double double30 = array2DRowRealMatrix29.getFrobeniusNorm();
        java.lang.String str31 = array2DRowRealMatrix29.toString();
        double[] doubleArray38 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix39 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray38);
        double[] doubleArray46 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix47 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray46);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair48 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray38, doubleArray46);
        double[] doubleArray55 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix56 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray55);
        double[] doubleArray63 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix64 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray63);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair65 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray55, doubleArray63);
        double[] doubleArray66 = pointVectorValuePair65.getFirst();
        double[] doubleArray67 = pointVectorValuePair65.getPointRef();
        double[] doubleArray74 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix75 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray74);
        double[] doubleArray82 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix83 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray82);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair84 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray74, doubleArray82);
        double[] doubleArray85 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray67, doubleArray82);
        double[] doubleArray86 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray46, doubleArray82);
        double[] doubleArray87 = array2DRowRealMatrix29.preMultiply(doubleArray46);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition88 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray21, doubleArray46);
        double double89 = eigenDecomposition88.getDeterminant();
        org.apache.commons.math3.linear.DecompositionSolver decompositionSolver90 = eigenDecomposition88.getSolver();
        org.apache.commons.math3.linear.DecompositionSolver decompositionSolver91 = eigenDecomposition88.getSolver();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 50 + "'", int19 == 50);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 61.886993787063204d + "'", double30 == 61.886993787063204d);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Array2DRowRealMatrix{{32.0},{0.0},{52.0},{-1.0},{10.0},{-1.0}}" + "'", str31.equals("Array2DRowRealMatrix{{32.0},{0.0},{52.0},{-1.0},{10.0},{-1.0}}"));
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + (-3.104890880000001E8d) + "'", double89 == (-3.104890880000001E8d));
        org.junit.Assert.assertNotNull(decompositionSolver90);
        org.junit.Assert.assertNotNull(decompositionSolver91);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 100, (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.getRowMatrix(29);
        try {
            blockRealMatrix5.setEntry(0, 50, 96.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (50)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        double double2 = org.apache.commons.math3.util.FastMath.max((double) 1.0f, (double) 84L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 84.0d + "'", double2 == 84.0d);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        double double8 = org.apache.commons.math3.util.MathArrays.linearCombination((double) (-127), (double) (-1.0f), 0.5267696213326568d, (double) (byte) -1, (double) 100.0f, (double) 2, 10.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 326.4732303786673d + "'", double8 == 326.4732303786673d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[][] doubleArray8 = array2DRowRealMatrix7.getData();
        double[][] doubleArray9 = array2DRowRealMatrix7.getData();
        double[] doubleArray16 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16);
        double double18 = array2DRowRealMatrix17.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix7, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix17);
        boolean boolean20 = array2DRowRealMatrix7.isSquare();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix22 = array2DRowRealMatrix7.getColumnMatrix((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 61.886993787063204d + "'", double18 == 61.886993787063204d);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        int[] intArray1 = new int[] { (byte) 100 };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister2 = new org.apache.commons.math3.random.MersenneTwister(intArray1);
        byte[] byteArray6 = new byte[] { (byte) 0, (byte) 100, (byte) 0 };
        mersenneTwister2.nextBytes(byteArray6);
        long long9 = mersenneTwister2.nextLong((long) 1085139999);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 393591323L + "'", long9 == 393591323L);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        java.text.NumberFormat numberFormat7 = org.apache.commons.math3.util.CompositeFormat.getDefaultNumberFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat8 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat7);
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat9 = new org.apache.commons.math3.linear.RealMatrixFormat("", "org.apache.commons.math3.linear.NonSymmetricMatrixException: non symmetric matrix: the difference between entries at (1,0) and (0,1) is larger than 0", "", "hi!", "{", "hi!", numberFormat7);
        java.text.NumberFormat numberFormat10 = realMatrixFormat9.getFormat();
        java.text.ParsePosition parsePosition11 = null;
        try {
            java.lang.Number number12 = org.apache.commons.math3.util.CompositeFormat.parseNumber("Array2DRowRealMatrix{{32.0},{0.0},{52.0},{-1.0},{10.0},{-1.0}}", numberFormat10, parsePosition11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat7);
        org.junit.Assert.assertNotNull(numberFormat10);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        long long1 = org.apache.commons.math3.util.FastMath.round(9.0d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 9L + "'", long1 == 9L);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        double[] doubleArray17 = pointVectorValuePair16.getValue();
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder18 = new org.apache.commons.math3.optim.univariate.BracketFinder();
        int int19 = bracketFinder18.getMaxEvaluations();
        boolean boolean20 = pointVectorValuePair16.equals((java.lang.Object) bracketFinder18);
        double[] doubleArray21 = pointVectorValuePair16.getPoint();
        double[] doubleArray28 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray28);
        double double30 = array2DRowRealMatrix29.getFrobeniusNorm();
        java.lang.String str31 = array2DRowRealMatrix29.toString();
        double[] doubleArray38 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix39 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray38);
        double[] doubleArray46 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix47 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray46);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair48 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray38, doubleArray46);
        double[] doubleArray55 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix56 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray55);
        double[] doubleArray63 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix64 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray63);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair65 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray55, doubleArray63);
        double[] doubleArray66 = pointVectorValuePair65.getFirst();
        double[] doubleArray67 = pointVectorValuePair65.getPointRef();
        double[] doubleArray74 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix75 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray74);
        double[] doubleArray82 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix83 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray82);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair84 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray74, doubleArray82);
        double[] doubleArray85 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray67, doubleArray82);
        double[] doubleArray86 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray46, doubleArray82);
        double[] doubleArray87 = array2DRowRealMatrix29.preMultiply(doubleArray46);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition88 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray21, doubleArray46);
        org.apache.commons.math3.linear.RealMatrix realMatrix89 = eigenDecomposition88.getV();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 50 + "'", int19 == 50);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 61.886993787063204d + "'", double30 == 61.886993787063204d);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Array2DRowRealMatrix{{32.0},{0.0},{52.0},{-1.0},{10.0},{-1.0}}" + "'", str31.equals("Array2DRowRealMatrix{{32.0},{0.0},{52.0},{-1.0},{10.0},{-1.0}}"));
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertNotNull(realMatrix89);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer();
        int int1 = levenbergMarquardtOptimizer0.getEvaluations();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.apache.commons.math3.exception.ZeroException zeroException0 = new org.apache.commons.math3.exception.ZeroException();
        java.lang.Number number1 = zeroException0.getArgument();
        org.junit.Assert.assertTrue("'" + number1 + "' != '" + 0 + "'", number1.equals(0));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        double double1 = org.apache.commons.math3.util.FastMath.log10((double) (-7910618197763358337L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        double[] doubleArray17 = pointVectorValuePair16.getValue();
        double[] doubleArray18 = pointVectorValuePair16.getPointRef();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray18);
        org.apache.commons.math3.linear.RealVector realVector21 = arrayRealVector19.mapMultiplyToSelf((double) (byte) 1);
        double[] doubleArray29 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix30 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray29);
        double[] doubleArray37 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix38 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray37);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair39 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray29, doubleArray37);
        double[] doubleArray40 = pointVectorValuePair39.getValue();
        org.apache.commons.math3.linear.RealVector realVector41 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray40);
        arrayRealVector19.setSubVector(0, realVector41);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector45.addToEntry(0, (double) 1.0f);
        double[] doubleArray55 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix56 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray55);
        double[][] doubleArray57 = array2DRowRealMatrix56.getData();
        double[][] doubleArray58 = array2DRowRealMatrix56.getData();
        double[] doubleArray65 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix66 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray65);
        double double67 = array2DRowRealMatrix66.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix56, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix66);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector72 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector72.addToEntry(0, (double) 1.0f);
        arrayRealVector72.unitize();
        array2DRowRealMatrix56.setRowVector(0, (org.apache.commons.math3.linear.RealVector) arrayRealVector72);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector78 = arrayRealVector45.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector72);
        org.apache.commons.math3.linear.RealVector realVector79 = arrayRealVector19.append((org.apache.commons.math3.linear.RealVector) arrayRealVector72);
        org.apache.commons.math3.linear.RealVector realVector81 = arrayRealVector72.mapDivide((double) (-4228292497824268148L));
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector83 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector72, true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector86 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector86.addToEntry(0, (double) 1.0f);
        org.apache.commons.math3.linear.RealVector realVector91 = arrayRealVector86.mapSubtractToSelf(146.01712228365548d);
        double double92 = arrayRealVector86.getMaxValue();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector93 = arrayRealVector72.add((org.apache.commons.math3.linear.RealVector) arrayRealVector86);
        org.apache.commons.math3.linear.RealVector realVector95 = arrayRealVector86.mapDivide((double) 100);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector21);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(realVector41);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 61.886993787063204d + "'", double67 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(arrayRealVector78);
        org.junit.Assert.assertNotNull(realVector79);
        org.junit.Assert.assertNotNull(realVector81);
        org.junit.Assert.assertNotNull(realVector91);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + (-135.01712228365548d) + "'", double92 == (-135.01712228365548d));
        org.junit.Assert.assertNotNull(arrayRealVector93);
        org.junit.Assert.assertNotNull(realVector95);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.apache.commons.math3.util.Incrementor incrementor1 = new org.apache.commons.math3.util.Incrementor(100);
        int int2 = incrementor1.getMaximalCount();
        int int3 = incrementor1.getMaximalCount();
        int int4 = incrementor1.getCount();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        double double2 = org.apache.commons.math3.util.FastMath.max((-0.6321205588285577d), (double) 2);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.0d + "'", double2 == 2.0d);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        int[] intArray6 = new int[] { (byte) 100 };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister7 = new org.apache.commons.math3.random.MersenneTwister(intArray6);
        double double8 = mersenneTwister7.nextGaussian();
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker10 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer11 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer((int) 'a', (double) 10, true, (int) (short) -1, 0, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister7, false, pointValuePairConvergenceChecker10);
        java.util.List<java.lang.Double> doubleList12 = cMAESOptimizer11.getStatisticsSigmaHistory();
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType13 = cMAESOptimizer11.getGoalType();
        java.util.List<java.lang.Double> doubleList14 = cMAESOptimizer11.getStatisticsFitnessHistory();
        double[] doubleArray15 = cMAESOptimizer11.getStartPoint();
        java.util.List<org.apache.commons.math3.linear.RealMatrix> realMatrixList16 = cMAESOptimizer11.getStatisticsDHistory();
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.7650730050315234d + "'", double8 == 0.7650730050315234d);
        org.junit.Assert.assertNotNull(doubleList12);
        org.junit.Assert.assertNull(goalType13);
        org.junit.Assert.assertNotNull(doubleList14);
        org.junit.Assert.assertNull(doubleArray15);
        org.junit.Assert.assertNotNull(realMatrixList16);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        double double1 = org.apache.commons.math3.util.FastMath.toDegrees(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.apache.commons.math3.linear.NonSymmetricMatrixException nonSymmetricMatrixException3 = new org.apache.commons.math3.linear.NonSymmetricMatrixException((int) (byte) 10, 0, 100.0d);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        float float2 = org.apache.commons.math3.util.FastMath.copySign((float) 1, (float) (byte) 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        double double4 = org.apache.commons.math3.util.MathArrays.linearCombination((double) 99, (double) 1.0851401E9f, (double) 2147483647, 29937.07086594976d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 6.439679899321124E13d + "'", double4 == 6.439679899321124E13d);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula4 = org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.POLAK_RIBIERE;
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker8 = new org.apache.commons.math3.optim.SimpleValueChecker((-135.01712228365548d), 96.0d, 6);
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver11 = new org.apache.commons.math3.analysis.solvers.BrentSolver((double) 100L, (double) 'a');
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.Preconditioner preconditioner12 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer13 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula4, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker8, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver11, preconditioner12);
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer powellOptimizer14 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer((double) 13L, 0.0d, 310.0d, (-0.8813735870195429d), (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker8);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + formula4 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.POLAK_RIBIERE + "'", formula4.equals(org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.POLAK_RIBIERE));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.apache.commons.math3.linear.RealMatrix realMatrix2 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix((int) (byte) 10, (int) (short) 10);
        org.junit.Assert.assertNotNull(realMatrix2);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double double1 = arrayRealVector0.getNorm();
        double double2 = arrayRealVector0.getMinValue();
        double[] doubleArray9 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray9);
        double[][] doubleArray11 = array2DRowRealMatrix10.getData();
        double[][] doubleArray12 = array2DRowRealMatrix10.getData();
        double[] doubleArray19 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray19);
        double double21 = array2DRowRealMatrix20.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix10, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix20);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector26.addToEntry(0, (double) 1.0f);
        arrayRealVector26.unitize();
        array2DRowRealMatrix10.setRowVector(0, (org.apache.commons.math3.linear.RealVector) arrayRealVector26);
        org.apache.commons.math3.linear.RealVector realVector32 = arrayRealVector0.append((org.apache.commons.math3.linear.RealVector) arrayRealVector26);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector35.addToEntry(0, (double) 1.0f);
        arrayRealVector35.unitize();
        org.apache.commons.math3.linear.RealVector realVector40 = arrayRealVector26.projection((org.apache.commons.math3.linear.RealVector) arrayRealVector35);
        double[] doubleArray49 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix50 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray49);
        double[] doubleArray57 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix58 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray57);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair59 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray49, doubleArray57);
        double[] doubleArray60 = pointVectorValuePair59.getValue();
        double[] doubleArray61 = pointVectorValuePair59.getPointRef();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector62 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray61);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector63 = arrayRealVector26.combineToSelf((-0.7249165551445564d), (-4.5451856292264253E18d), (org.apache.commons.math3.linear.RealVector) arrayRealVector62);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 6");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 61.886993787063204d + "'", double21 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(realVector32);
        org.junit.Assert.assertNotNull(realVector40);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray61);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        double[] doubleArray22 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix23 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray22);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair24 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray14, doubleArray22);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray14, true);
        double[] doubleArray33 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray33);
        org.apache.commons.math3.linear.RealMatrix realMatrix35 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray33);
        org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math3.linear.AnyMatrix) diagonalMatrix26, (org.apache.commons.math3.linear.AnyMatrix) realMatrix35);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition37 = new org.apache.commons.math3.linear.LUDecomposition(realMatrix35);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix7, (org.apache.commons.math3.linear.AnyMatrix) realMatrix35);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 6");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(realMatrix35);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        org.apache.commons.math3.optim.InitialGuess initialGuess17 = new org.apache.commons.math3.optim.InitialGuess(doubleArray6);
        double[] doubleArray18 = initialGuess17.getInitialGuess();
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix19 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray18);
        double[] doubleArray21 = diagonalMatrix19.getRow(1);
        org.apache.commons.math3.linear.RealMatrix realMatrix24 = diagonalMatrix19.createMatrix((int) (byte) 1, (int) (short) 1);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math3.linear.AnyMatrix) diagonalMatrix19, 99);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (99)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(realMatrix24);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 100, (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.scalarAdd(0.0d);
        double[] doubleArray13 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13);
        double[] doubleArray21 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray21);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair23 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray13, doubleArray21);
        double[] doubleArray24 = pointVectorValuePair23.getFirst();
        double[] doubleArray25 = pointVectorValuePair23.getPointRef();
        double[] doubleArray32 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray32);
        double[] doubleArray40 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix41 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray40);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair42 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray32, doubleArray40);
        double[] doubleArray43 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray25, doubleArray40);
        double[] doubleArray48 = new double[] { (short) 10, 10L, 'a', 0.7650730050315234d };
        org.apache.commons.math3.optim.SimpleBounds simpleBounds49 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray43, doubleArray48);
        double[] doubleArray50 = simpleBounds49.getUpper();
        try {
            blockRealMatrix2.setColumn((int) '4', doubleArray50);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray50);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        float float2 = org.apache.commons.math3.util.FastMath.copySign((float) 647325673, (float) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 6.473257E8f + "'", float2 == 6.473257E8f);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        double double1 = org.apache.commons.math3.util.FastMath.log1p(5.5373497666891724d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.8775318488882415d + "'", double1 == 1.8775318488882415d);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector2.addToEntry(0, (double) 1.0f);
        org.apache.commons.math3.linear.RealVector realVector7 = arrayRealVector2.mapSubtractToSelf(146.01712228365548d);
        double double8 = arrayRealVector2.getNorm();
        org.junit.Assert.assertNotNull(realVector7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 135.01712228365548d + "'", double8 == 135.01712228365548d);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6, true);
        double[] doubleArray25 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double[] doubleArray33 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray33);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair35 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray25, doubleArray33);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix37 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray25, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix38 = diagonalMatrix18.add(diagonalMatrix37);
        diagonalMatrix38.multiplyEntry(50, (int) '4', (-0.5d));
        double[] doubleArray49 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix50 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray49);
        double[] doubleArray57 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix58 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray57);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair59 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray49, doubleArray57);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix61 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray49, true);
        double[] doubleArray68 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix69 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray68);
        double[] doubleArray76 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix77 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray76);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair78 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray68, doubleArray76);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix80 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray68, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix81 = diagonalMatrix61.add(diagonalMatrix80);
        diagonalMatrix80.multiplyEntry((int) 'a', (-127), (double) 1.0f);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix86 = diagonalMatrix38.multiply(diagonalMatrix80);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSubMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) diagonalMatrix80, (-1), 50, (int) (short) -1, 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(diagonalMatrix38);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(diagonalMatrix81);
        org.junit.Assert.assertNotNull(diagonalMatrix86);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        double double1 = org.apache.commons.math3.util.FastMath.log((double) (short) -1);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        double double2 = org.apache.commons.math3.util.FastMath.pow((double) 0.0f, 99);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder0 = new org.apache.commons.math3.optim.univariate.BracketFinder();
        int int1 = bracketFinder0.getEvaluations();
        double double2 = bracketFinder0.getFLo();
        org.apache.commons.math3.analysis.function.Sinc sinc3 = new org.apache.commons.math3.analysis.function.Sinc();
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType4 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE;
        bracketFinder0.search((org.apache.commons.math3.analysis.UnivariateFunction) sinc3, goalType4, 0.9835877454343449d, 0.0d);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction8 = sinc3.derivative();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + goalType4 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE + "'", goalType4.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE));
        org.junit.Assert.assertNotNull(univariateFunction8);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double double1 = array2DRowRealMatrix0.getTrace();
        org.apache.commons.math3.linear.RealMatrix realMatrix4 = array2DRowRealMatrix0.createMatrix(243, 27);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix4);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.append((double) 0.0f);
        boolean boolean5 = arrayRealVector2.isNaN();
        boolean boolean6 = arrayRealVector2.isInfinite();
        double[] doubleArray7 = arrayRealVector2.toArray();
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(doubleArray7);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        double double2 = org.apache.commons.math3.util.FastMath.log(1.0d, (double) (-266497663));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double double8 = array2DRowRealMatrix7.getFrobeniusNorm();
        java.lang.String str9 = array2DRowRealMatrix7.toString();
        int int10 = array2DRowRealMatrix7.getColumnDimension();
        boolean boolean12 = org.apache.commons.math3.linear.MatrixUtils.isSymmetric((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix7, 127.00393694685216d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 61.886993787063204d + "'", double8 == 61.886993787063204d);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Array2DRowRealMatrix{{32.0},{0.0},{52.0},{-1.0},{10.0},{-1.0}}" + "'", str9.equals("Array2DRowRealMatrix{{32.0},{0.0},{52.0},{-1.0},{10.0},{-1.0}}"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.apache.commons.math3.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math3.exception.TooManyEvaluationsException((java.lang.Number) (-9090371258452850456L));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer simplexOptimizer2 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer((-0.5403023058681397d), (double) (short) 100);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        double[] doubleArray17 = pointVectorValuePair16.getValue();
        org.apache.commons.math3.linear.RealVector realVector18 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray17);
        double[] doubleArray25 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double[] doubleArray33 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray33);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair35 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray25, doubleArray33);
        double[] doubleArray36 = pointVectorValuePair35.getValue();
        org.apache.commons.math3.linear.RealVector realVector37 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray36);
        org.apache.commons.math3.linear.RealVector realVector38 = realVector18.projection(realVector37);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector41.addToEntry(0, (double) 1.0f);
        double[] doubleArray51 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix52 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray51);
        double[][] doubleArray53 = array2DRowRealMatrix52.getData();
        double[][] doubleArray54 = array2DRowRealMatrix52.getData();
        double[] doubleArray61 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix62 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray61);
        double double63 = array2DRowRealMatrix62.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix52, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix62);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector68 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector68.addToEntry(0, (double) 1.0f);
        arrayRealVector68.unitize();
        array2DRowRealMatrix52.setRowVector(0, (org.apache.commons.math3.linear.RealVector) arrayRealVector68);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector74 = arrayRealVector41.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector68);
        try {
            double double75 = realVector37.cosine((org.apache.commons.math3.linear.RealVector) arrayRealVector74);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 6 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(realVector37);
        org.junit.Assert.assertNotNull(realVector38);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 61.886993787063204d + "'", double63 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(arrayRealVector74);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double double8 = array2DRowRealMatrix7.getFrobeniusNorm();
        double[] doubleArray15 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        double[][] doubleArray17 = array2DRowRealMatrix16.getData();
        double[][] doubleArray18 = array2DRowRealMatrix16.getData();
        double[] doubleArray25 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double double27 = array2DRowRealMatrix26.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix16, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix26);
        org.apache.commons.math3.linear.RealMatrix realMatrix29 = array2DRowRealMatrix7.add((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix16);
        double[] doubleArray36 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix37 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray36);
        double[][] doubleArray38 = array2DRowRealMatrix37.getData();
        double[][] doubleArray39 = array2DRowRealMatrix37.getData();
        double[] doubleArray46 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix47 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray46);
        double[] doubleArray54 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix55 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray54);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair56 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray46, doubleArray54);
        double[] doubleArray57 = pointVectorValuePair56.getFirst();
        double[] doubleArray58 = pointVectorValuePair56.getPointRef();
        double[] doubleArray65 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix66 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray65);
        double[] doubleArray73 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix74 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray73);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair75 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray65, doubleArray73);
        double[] doubleArray76 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray58, doubleArray73);
        double[] doubleArray77 = array2DRowRealMatrix37.preMultiply(doubleArray73);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix78 = array2DRowRealMatrix16.subtract(array2DRowRealMatrix37);
        double[][] doubleArray79 = array2DRowRealMatrix78.getData();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 61.886993787063204d + "'", double8 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 61.886993787063204d + "'", double27 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix78);
        org.junit.Assert.assertNotNull(doubleArray79);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.apache.commons.math3.optim.SimpleVectorValueChecker simpleVectorValueChecker2 = new org.apache.commons.math3.optim.SimpleVectorValueChecker(Double.NEGATIVE_INFINITY, 0.7615942060206032d);
        double double3 = simpleVectorValueChecker2.getAbsoluteThreshold();
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer gaussNewtonOptimizer4 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer((org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair>) simpleVectorValueChecker2);
        double double5 = simpleVectorValueChecker2.getRelativeThreshold();
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer6 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer((org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair>) simpleVectorValueChecker2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.7615942060206032d + "'", double3 == 0.7615942060206032d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.NEGATIVE_INFINITY + "'", double5 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 3830.0d, (java.lang.Number) 0.0d, 1079508992);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection4 = nonMonotonicSequenceException3.getDirection();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection5 = nonMonotonicSequenceException3.getDirection();
        boolean boolean6 = nonMonotonicSequenceException3.getStrict();
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection4.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection5 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection5.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        double[] doubleArray9 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray9);
        double[][] doubleArray11 = array2DRowRealMatrix10.getData();
        double[][] doubleArray12 = array2DRowRealMatrix10.getData();
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException13 = new org.apache.commons.math3.exception.NullArgumentException(localizable2, (java.lang.Object[]) doubleArray12);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray12);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) -1, (int) '#', doubleArray12, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex4 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(100, (double) ' ', (double) (short) -1, 0.0d);
        org.apache.commons.math3.analysis.MultivariateFunction multivariateFunction5 = null;
        java.util.Comparator<org.apache.commons.math3.optim.PointValuePair> pointValuePairComparator6 = null;
        try {
            multiDirectionalSimplex4.iterate(multivariateFunction5, pointValuePairComparator6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver2 = new org.apache.commons.math3.analysis.solvers.BrentSolver((double) 100L, (double) 'a');
        double double3 = brentSolver2.getStartValue();
        int int4 = brentSolver2.getMaxEvaluations();
        java.io.ObjectInputStream objectInputStream6 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.deserializeRealMatrix((java.lang.Object) int4, "", objectInputStream6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.apache.commons.math3.util.Incrementor incrementor1 = new org.apache.commons.math3.util.Incrementor(100);
        incrementor1.resetCount();
        int int3 = incrementor1.getCount();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 100, (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.scalarAdd(0.0d);
        double[] doubleArray12 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray12);
        double[] doubleArray20 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray20);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair22 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray12, doubleArray20);
        double[] doubleArray29 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix30 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray29);
        double[] doubleArray37 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix38 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray37);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair39 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray29, doubleArray37);
        double[] doubleArray40 = pointVectorValuePair39.getFirst();
        double[] doubleArray41 = pointVectorValuePair39.getPointRef();
        double[] doubleArray48 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix49 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray48);
        double[] doubleArray56 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix57 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray56);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair58 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray48, doubleArray56);
        double[] doubleArray59 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray41, doubleArray56);
        double[] doubleArray60 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray20, doubleArray56);
        double[] doubleArray67 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix68 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray67);
        double[] doubleArray75 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix76 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray75);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair77 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray67, doubleArray75);
        double double78 = org.apache.commons.math3.util.MathArrays.linearCombination(doubleArray56, doubleArray67);
        try {
            double[] doubleArray79 = blockRealMatrix5.operate(doubleArray56);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 6 != 10");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 3830.0d + "'", double78 == 3830.0d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) (short) 100, 100, (int) (byte) -1, (int) (short) 100);
        java.lang.Integer[] intArray5 = matrixDimensionMismatchException4.getWrongDimensions();
        int int7 = matrixDimensionMismatchException4.getExpectedDimension((int) (short) 0);
        int int8 = matrixDimensionMismatchException4.getWrongRowDimension();
        int int9 = matrixDimensionMismatchException4.getWrongColumnDimension();
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math3.random.MersenneTwister();
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        long long1 = org.apache.commons.math3.util.FastMath.round((double) 13L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 13L + "'", long1 == 13L);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        double[] doubleArray17 = pointVectorValuePair16.getValue();
        double[] doubleArray18 = pointVectorValuePair16.getPointRef();
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix19 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray18);
        org.apache.commons.math3.linear.RealMatrix realMatrix20 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray18);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector23.addToEntry(0, (double) 1.0f);
        org.apache.commons.math3.linear.RealVector realVector28 = arrayRealVector23.mapSubtractToSelf(146.01712228365548d);
        try {
            org.apache.commons.math3.linear.MatrixUtils.solveLowerTriangularSystem(realMatrix20, realVector28);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.NonSquareMatrixException; message: non square (1x6) matrix");
        } catch (org.apache.commons.math3.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(realVector28);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder0 = new org.apache.commons.math3.optim.univariate.BracketFinder();
        int int1 = bracketFinder0.getEvaluations();
        int int2 = bracketFinder0.getEvaluations();
        double double3 = bracketFinder0.getMid();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math3.exception.DimensionMismatchException(0, 1079508992);
        java.lang.Number number3 = dimensionMismatchException2.getArgument();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.apache.commons.math3.analysis.function.Sinc sinc0 = new org.apache.commons.math3.analysis.function.Sinc();
        org.apache.commons.math3.optim.univariate.UnivariateObjectiveFunction univariateObjectiveFunction1 = new org.apache.commons.math3.optim.univariate.UnivariateObjectiveFunction((org.apache.commons.math3.analysis.UnivariateFunction) sinc0);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction2 = univariateObjectiveFunction1.getObjectiveFunction();
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction3 = univariateObjectiveFunction1.getObjectiveFunction();
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction4 = univariateObjectiveFunction1.getObjectiveFunction();
        org.junit.Assert.assertNotNull(univariateFunction2);
        org.junit.Assert.assertNotNull(univariateFunction3);
        org.junit.Assert.assertNotNull(univariateFunction4);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        int[] intArray1 = new int[] { (byte) 100 };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister2 = new org.apache.commons.math3.random.MersenneTwister(intArray1);
        float float3 = mersenneTwister2.nextFloat();
        float float4 = mersenneTwister2.nextFloat();
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.14566922f + "'", float3 == 0.14566922f);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.45952868f + "'", float4 == 0.45952868f);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        java.text.NumberFormat numberFormat6 = org.apache.commons.math3.util.CompositeFormat.getDefaultNumberFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat7 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat6);
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat8 = new org.apache.commons.math3.linear.RealMatrixFormat("", "org.apache.commons.math3.linear.NonSymmetricMatrixException: non symmetric matrix: the difference between entries at (1,0) and (0,1) is larger than 0", "", "hi!", "{", "hi!", numberFormat6);
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat9 = new org.apache.commons.math3.linear.RealMatrixFormat(numberFormat6);
        java.lang.String str10 = realMatrixFormat9.getColumnSeparator();
        org.junit.Assert.assertNotNull(numberFormat6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "," + "'", str10.equals(","));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver3 = new org.apache.commons.math3.analysis.solvers.BrentSolver((double) 2147483647, (double) 100, (double) (-1L));
        java.lang.Class<?> wildcardClass4 = brentSolver3.getClass();
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double double8 = array2DRowRealMatrix7.getFrobeniusNorm();
        int int9 = array2DRowRealMatrix7.getColumnDimension();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 61.886993787063204d + "'", double8 == 61.886993787063204d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat3 = new org.apache.commons.math3.linear.RealVectorFormat("hi!", "hi!", "");
        java.text.NumberFormat numberFormat4 = realVectorFormat3.getFormat();
        org.junit.Assert.assertNotNull(numberFormat4);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6, true);
        double[] doubleArray25 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double[] doubleArray33 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray33);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair35 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray25, doubleArray33);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix37 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray25, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix38 = diagonalMatrix18.add(diagonalMatrix37);
        double[] doubleArray46 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix47 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray46);
        double[] doubleArray54 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix55 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray54);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair56 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray46, doubleArray54);
        org.apache.commons.math3.optim.InitialGuess initialGuess57 = new org.apache.commons.math3.optim.InitialGuess(doubleArray46);
        org.apache.commons.math3.optim.InitialGuess initialGuess58 = new org.apache.commons.math3.optim.InitialGuess(doubleArray46);
        org.apache.commons.math3.linear.RealMatrix realMatrix59 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray46);
        try {
            diagonalMatrix38.setRowMatrix(243, realMatrix59);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (243)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(diagonalMatrix38);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(realMatrix59);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.apache.commons.math3.optim.SimpleBounds simpleBounds1 = org.apache.commons.math3.optim.SimpleBounds.unbounded((int) (short) 1);
        org.junit.Assert.assertNotNull(simpleBounds1);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        double[] doubleArray17 = pointVectorValuePair16.getValue();
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder18 = new org.apache.commons.math3.optim.univariate.BracketFinder();
        int int19 = bracketFinder18.getMaxEvaluations();
        boolean boolean20 = pointVectorValuePair16.equals((java.lang.Object) bracketFinder18);
        double[] doubleArray21 = pointVectorValuePair16.getPoint();
        double[] doubleArray28 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray28);
        double double30 = array2DRowRealMatrix29.getFrobeniusNorm();
        java.lang.String str31 = array2DRowRealMatrix29.toString();
        double[] doubleArray38 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix39 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray38);
        double[] doubleArray46 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix47 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray46);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair48 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray38, doubleArray46);
        double[] doubleArray55 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix56 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray55);
        double[] doubleArray63 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix64 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray63);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair65 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray55, doubleArray63);
        double[] doubleArray66 = pointVectorValuePair65.getFirst();
        double[] doubleArray67 = pointVectorValuePair65.getPointRef();
        double[] doubleArray74 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix75 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray74);
        double[] doubleArray82 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix83 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray82);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair84 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray74, doubleArray82);
        double[] doubleArray85 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray67, doubleArray82);
        double[] doubleArray86 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray46, doubleArray82);
        double[] doubleArray87 = array2DRowRealMatrix29.preMultiply(doubleArray46);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition88 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray21, doubleArray46);
        double double89 = eigenDecomposition88.getDeterminant();
        org.apache.commons.math3.linear.DecompositionSolver decompositionSolver90 = eigenDecomposition88.getSolver();
        org.apache.commons.math3.linear.RealMatrix realMatrix91 = eigenDecomposition88.getVT();
        try {
            double double93 = eigenDecomposition88.getRealEigenvalue(35);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 35");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 50 + "'", int19 == 50);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 61.886993787063204d + "'", double30 == 61.886993787063204d);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Array2DRowRealMatrix{{32.0},{0.0},{52.0},{-1.0},{10.0},{-1.0}}" + "'", str31.equals("Array2DRowRealMatrix{{32.0},{0.0},{52.0},{-1.0},{10.0},{-1.0}}"));
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + (-3.104890880000001E8d) + "'", double89 == (-3.104890880000001E8d));
        org.junit.Assert.assertNotNull(decompositionSolver90);
        org.junit.Assert.assertNotNull(realMatrix91);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair2 = new org.apache.commons.math3.optim.univariate.UnivariatePointValuePair(35.0d, 0.0d);
        double double3 = univariatePointValuePair2.getPoint();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 35.0d + "'", double3 == 35.0d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        double double3 = org.apache.commons.math3.util.MathUtils.reduce(0.5403023058681398d, (-10761.089105465297d), 2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10758.911125942706d + "'", double3 == 10758.911125942706d);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        int int1 = org.apache.commons.math3.util.FastMath.abs((int) ' ');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 32 + "'", int1 == 32);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException0 = new org.apache.commons.math3.exception.MathArithmeticException();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext1 = mathArithmeticException0.getContext();
        org.junit.Assert.assertNotNull(exceptionContext1);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 100, (int) (byte) 10);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 100, (int) (byte) 10);
        double double7 = blockRealMatrix6.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = blockRealMatrix6.scalarAdd(0.0d);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix6.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 100, (int) (byte) 10);
        double double14 = blockRealMatrix13.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = blockRealMatrix13.scalarAdd(0.0d);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix13.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix10.multiply(blockRealMatrix13);
        try {
            blockRealMatrix2.setRowMatrix((-1), blockRealMatrix10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix9);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix16);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.apache.commons.math3.optim.univariate.BrentOptimizer brentOptimizer2 = new org.apache.commons.math3.optim.univariate.BrentOptimizer((double) 1L, 0.9086743489308475d);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        int[] intArray6 = new int[] { (byte) 100 };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister7 = new org.apache.commons.math3.random.MersenneTwister(intArray6);
        double double8 = mersenneTwister7.nextGaussian();
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker10 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer11 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer((int) 'a', (double) 10, true, (int) (short) -1, 0, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister7, false, pointValuePairConvergenceChecker10);
        mersenneTwister7.setSeed((long) (byte) 10);
        mersenneTwister7.setSeed((long) (short) 1);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.7650730050315234d + "'", double8 == 0.7650730050315234d);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.apache.commons.math3.optim.SimpleVectorValueChecker simpleVectorValueChecker3 = new org.apache.commons.math3.optim.SimpleVectorValueChecker(Double.NEGATIVE_INFINITY, 0.7615942060206032d);
        double double4 = simpleVectorValueChecker3.getAbsoluteThreshold();
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer gaussNewtonOptimizer5 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer(true, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair>) simpleVectorValueChecker3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.7615942060206032d + "'", double4 == 0.7615942060206032d);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.apache.commons.math3.optim.SimpleVectorValueChecker simpleVectorValueChecker3 = new org.apache.commons.math3.optim.SimpleVectorValueChecker(0.0d, (double) (short) 0, 1079508992);
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer4 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer((org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair>) simpleVectorValueChecker3);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        double double4 = org.apache.commons.math3.util.MathArrays.linearCombination(1.1102230246251565E-16d, (double) 100.0f, 1.8775318488882415d, (double) 0.14566922f);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.2734986034788211d + "'", double4 == 0.2734986034788211d);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        double[] doubleArray0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        double[][] doubleArray5 = org.apache.commons.math3.linear.BlockRealMatrix.createBlocksLayout((int) (short) -1, (int) (byte) 100);
        org.apache.commons.math3.exception.MathUnsupportedOperationException mathUnsupportedOperationException6 = new org.apache.commons.math3.exception.MathUnsupportedOperationException(localizable2, (java.lang.Object[]) doubleArray5);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException7 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable1, (java.lang.Object[]) doubleArray5);
        try {
            org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray0, doubleArray5);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6, true);
        double[] doubleArray25 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double[] doubleArray33 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray33);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair35 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray25, doubleArray33);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix37 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray25, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix38 = diagonalMatrix18.add(diagonalMatrix37);
        diagonalMatrix38.multiplyEntry(50, (int) '4', (-0.5d));
        double[] doubleArray49 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix50 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray49);
        double[] doubleArray57 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix58 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray57);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair59 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray49, doubleArray57);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix61 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray49, true);
        double[] doubleArray68 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix69 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray68);
        double[] doubleArray76 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix77 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray76);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair78 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray68, doubleArray76);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix80 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray68, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix81 = diagonalMatrix61.add(diagonalMatrix80);
        diagonalMatrix80.multiplyEntry((int) 'a', (-127), (double) 1.0f);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix86 = diagonalMatrix38.multiply(diagonalMatrix80);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor87 = null;
        try {
            double double92 = diagonalMatrix80.walkInColumnOrder(realMatrixChangingVisitor87, (int) (byte) 0, 0, 35, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(diagonalMatrix38);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(diagonalMatrix81);
        org.junit.Assert.assertNotNull(diagonalMatrix86);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        java.text.NumberFormat numberFormat9 = org.apache.commons.math3.util.CompositeFormat.getDefaultNumberFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat10 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat9);
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat11 = new org.apache.commons.math3.linear.RealMatrixFormat("", "org.apache.commons.math3.linear.NonSymmetricMatrixException: non symmetric matrix: the difference between entries at (1,0) and (0,1) is larger than 0", "", "hi!", "{", "hi!", numberFormat9);
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat12 = new org.apache.commons.math3.linear.RealMatrixFormat(numberFormat9);
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat13 = new org.apache.commons.math3.linear.RealVectorFormat("org.apache.commons.math3.linear.MatrixDimensionMismatchException: got 100x100 but expected -1x100", "}", "org.apache.commons.math3.linear.MatrixDimensionMismatchException: got 100x100 but expected -1x100", numberFormat9);
        org.junit.Assert.assertNotNull(numberFormat9);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        double[] doubleArray17 = pointVectorValuePair16.getValue();
        double[] doubleArray18 = pointVectorValuePair16.getPointRef();
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix19 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray18);
        org.apache.commons.math3.linear.RealMatrix realMatrix20 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray18);
        try {
            org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray18);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException; message: points 0 and 1 are not strictly increasing (32 >= 0)");
        } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realMatrix20);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        double[] doubleArray17 = pointVectorValuePair16.getValue();
        org.apache.commons.math3.linear.RealVector realVector18 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray17);
        double[] doubleArray25 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double[] doubleArray33 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray33);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair35 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray25, doubleArray33);
        double[] doubleArray36 = pointVectorValuePair35.getValue();
        org.apache.commons.math3.linear.RealVector realVector37 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray36);
        org.apache.commons.math3.linear.RealVector realVector38 = realVector18.projection(realVector37);
        int int39 = realVector37.getMinIndex();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector42.addToEntry(0, (double) 1.0f);
        double[] doubleArray52 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix53 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray52);
        double[][] doubleArray54 = array2DRowRealMatrix53.getData();
        double[][] doubleArray55 = array2DRowRealMatrix53.getData();
        double[] doubleArray62 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix63 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray62);
        double double64 = array2DRowRealMatrix63.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix53, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix63);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector69 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector69.addToEntry(0, (double) 1.0f);
        arrayRealVector69.unitize();
        array2DRowRealMatrix53.setRowVector(0, (org.apache.commons.math3.linear.RealVector) arrayRealVector69);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector75 = arrayRealVector42.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector69);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector76 = new org.apache.commons.math3.linear.ArrayRealVector(realVector37, arrayRealVector69);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector77 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector76);
        org.apache.commons.math3.linear.RealVector realVector79 = arrayRealVector77.mapAdd((double) 1079508992);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(realVector37);
        org.junit.Assert.assertNotNull(realVector38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 5 + "'", int39 == 5);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 61.886993787063204d + "'", double64 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(arrayRealVector75);
        org.junit.Assert.assertNotNull(realVector79);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6, true);
        double[] doubleArray25 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double[] doubleArray33 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray33);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair35 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray25, doubleArray33);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix37 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray25, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix38 = diagonalMatrix18.add(diagonalMatrix37);
        diagonalMatrix38.multiplyEntry(50, (int) '4', (-0.5d));
        diagonalMatrix38.addToEntry(0, (int) (byte) 10, (double) (byte) 0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(diagonalMatrix38);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.apache.commons.math3.optim.SimpleVectorValueChecker simpleVectorValueChecker2 = new org.apache.commons.math3.optim.SimpleVectorValueChecker(Double.NEGATIVE_INFINITY, 0.7615942060206032d);
        double double3 = simpleVectorValueChecker2.getAbsoluteThreshold();
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer gaussNewtonOptimizer4 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer((org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair>) simpleVectorValueChecker2);
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer gaussNewtonOptimizer5 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer((org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair>) simpleVectorValueChecker2);
        int int6 = gaussNewtonOptimizer5.getEvaluations();
        double[] doubleArray7 = gaussNewtonOptimizer5.getLowerBound();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.7615942060206032d + "'", double3 == 0.7615942060206032d);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNull(doubleArray7);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6, true);
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray6, (double) 2147483647);
        double[] doubleArray21 = pointValuePair20.getPointRef();
        java.lang.Double double22 = pointValuePair20.getValue();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 2.147483647E9d + "'", double22.equals(2.147483647E9d));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        double double1 = org.apache.commons.math3.util.FastMath.log(0.36787944117144233d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[][] doubleArray8 = array2DRowRealMatrix7.getData();
        double[][] doubleArray9 = array2DRowRealMatrix7.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray9);
        double[][] doubleArray11 = array2DRowRealMatrix10.getData();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double double8 = array2DRowRealMatrix7.getFrobeniusNorm();
        double[] doubleArray15 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        double[][] doubleArray17 = array2DRowRealMatrix16.getData();
        double[][] doubleArray18 = array2DRowRealMatrix16.getData();
        double[] doubleArray25 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double double27 = array2DRowRealMatrix26.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix16, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix26);
        org.apache.commons.math3.linear.RealMatrix realMatrix29 = array2DRowRealMatrix7.add((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix16);
        double[][] doubleArray34 = null;
        try {
            array2DRowRealMatrix7.copySubMatrix(2, 2, 29, (int) (byte) 1, doubleArray34);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (29)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 61.886993787063204d + "'", double8 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 61.886993787063204d + "'", double27 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(realMatrix29);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        double double2 = org.apache.commons.math3.util.FastMath.pow(0.0d, (double) 7.9106184E18f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.apache.commons.math3.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math3.exception.TooManyEvaluationsException((java.lang.Number) 1085139999);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        double[] doubleArray10 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray10);
        double[][] doubleArray12 = array2DRowRealMatrix11.getData();
        double[][] doubleArray13 = array2DRowRealMatrix11.getData();
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException14 = new org.apache.commons.math3.exception.MaxCountExceededException(localizable2, (java.lang.Number) 83.86684335012045d, (java.lang.Object[]) doubleArray13);
        double[][] doubleArray15 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray13);
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException16 = new org.apache.commons.math3.exception.MaxCountExceededException(localizable0, (java.lang.Number) 243, (java.lang.Object[]) doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.apache.commons.math3.optim.SimpleVectorValueChecker simpleVectorValueChecker4 = new org.apache.commons.math3.optim.SimpleVectorValueChecker(0.0d, (double) (short) 0, 1079508992);
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer9 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer(0.0d, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair>) simpleVectorValueChecker4, (double) (short) 100, 0.0d, 326.4732303786673d, 0.0d);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[][] doubleArray8 = array2DRowRealMatrix7.getData();
        double[] doubleArray15 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        double double17 = array2DRowRealMatrix16.getFrobeniusNorm();
        java.lang.String str18 = array2DRowRealMatrix16.toString();
        org.apache.commons.math3.linear.RealMatrix realMatrix19 = array2DRowRealMatrix7.subtract((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix16);
        org.apache.commons.math3.linear.RealMatrix realMatrix21 = array2DRowRealMatrix16.scalarAdd((-0.6321205588285577d));
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 61.886993787063204d + "'", double17 == 61.886993787063204d);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Array2DRowRealMatrix{{32.0},{0.0},{52.0},{-1.0},{10.0},{-1.0}}" + "'", str18.equals("Array2DRowRealMatrix{{32.0},{0.0},{52.0},{-1.0},{10.0},{-1.0}}"));
        org.junit.Assert.assertNotNull(realMatrix19);
        org.junit.Assert.assertNotNull(realMatrix21);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        long long2 = org.apache.commons.math3.util.FastMath.min((long) 2, (long) 97);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2L + "'", long2 == 2L);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6, true);
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray6, (double) 2147483647);
        double[] doubleArray21 = pointValuePair20.getPointRef();
        double[] doubleArray22 = pointValuePair20.getPointRef();
        double[] doubleArray23 = pointValuePair20.getPointRef();
        java.lang.Double double24 = pointValuePair20.getSecond();
        java.lang.Double double25 = pointValuePair20.getSecond();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 2.147483647E9d + "'", double24.equals(2.147483647E9d));
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 2.147483647E9d + "'", double25.equals(2.147483647E9d));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        double double1 = org.apache.commons.math3.util.FastMath.abs((double) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 52.0d + "'", double1 == 52.0d);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 100, (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        double[] doubleArray10 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray10);
        double[] doubleArray18 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray18);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair20 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray10, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix22 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray10, true);
        double[] doubleArray29 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix30 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray29);
        double[] doubleArray37 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix38 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray37);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair39 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray29, doubleArray37);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix41 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray29, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix42 = diagonalMatrix22.add(diagonalMatrix41);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix43 = blockRealMatrix2.multiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix42);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 10 != 6");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(diagonalMatrix42);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        long long1 = org.apache.commons.math3.util.FastMath.abs((long) (short) 100);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 100L + "'", long1 == 100L);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 100, (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.scalarAdd(0.0d);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.transpose();
        org.apache.commons.math3.exception.util.Localizable localizable7 = null;
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        double[][] doubleArray16 = array2DRowRealMatrix15.getData();
        double[][] doubleArray17 = array2DRowRealMatrix15.getData();
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException18 = new org.apache.commons.math3.exception.NullArgumentException(localizable7, (java.lang.Object[]) doubleArray17);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray17);
        try {
            blockRealMatrix2.setSubMatrix(doubleArray17, 36, 647325673);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (647,325,673)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        double double1 = org.apache.commons.math3.util.FastMath.acos(127.00393694685216d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        double[] doubleArray17 = pointVectorValuePair16.getValue();
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder18 = new org.apache.commons.math3.optim.univariate.BracketFinder();
        int int19 = bracketFinder18.getMaxEvaluations();
        boolean boolean20 = pointVectorValuePair16.equals((java.lang.Object) bracketFinder18);
        double[] doubleArray21 = pointVectorValuePair16.getSecond();
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray21, false);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 50 + "'", int19 == 50);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex4 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(100, (double) ' ', (double) (short) -1, 0.0d);
        int int5 = multiDirectionalSimplex4.getDimension();
        org.apache.commons.math3.analysis.MultivariateFunction multivariateFunction6 = null;
        java.util.Comparator<org.apache.commons.math3.optim.PointValuePair> pointValuePairComparator7 = null;
        try {
            multiDirectionalSimplex4.iterate(multivariateFunction6, pointValuePairComparator7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 100 + "'", int5 == 100);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 100, (int) (byte) 10);
        double[][] doubleArray3 = blockRealMatrix2.getData();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor4 = null;
        try {
            double double5 = blockRealMatrix2.walkInRowOrder(realMatrixChangingVisitor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6, true);
        double[] doubleArray25 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double[] doubleArray33 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray33);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair35 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray25, doubleArray33);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix37 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray25, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix38 = diagonalMatrix18.add(diagonalMatrix37);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition40 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix18, (double) 1.0f);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight41 = new org.apache.commons.math3.optim.nonlinear.vector.Weight((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix18);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor42 = null;
        try {
            double double47 = diagonalMatrix18.walkInOptimizedOrder(realMatrixChangingVisitor42, (int) (byte) -1, 647325673, (-1), 29);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(diagonalMatrix38);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.apache.commons.math3.util.Incrementor.MaxCountExceededCallback maxCountExceededCallback1 = null;
        try {
            org.apache.commons.math3.util.Incrementor incrementor2 = new org.apache.commons.math3.util.Incrementor(97, maxCountExceededCallback1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number) 5.5373497666891724d);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex1 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(1);
        org.apache.commons.math3.analysis.MultivariateFunction multivariateFunction2 = null;
        java.util.Comparator<org.apache.commons.math3.optim.PointValuePair> pointValuePairComparator3 = null;
        try {
            multiDirectionalSimplex1.evaluate(multivariateFunction2, pointValuePairComparator3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(35, (double) (short) 10);
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat6 = new org.apache.commons.math3.linear.RealVectorFormat(",", "", "");
        double[] doubleArray13 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13);
        double[] doubleArray21 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray21);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair23 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray13, doubleArray21);
        double[] doubleArray24 = pointVectorValuePair23.getValue();
        org.apache.commons.math3.linear.RealVector realVector25 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray24);
        double[] doubleArray32 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray32);
        double[] doubleArray40 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix41 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray40);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair42 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray32, doubleArray40);
        double[] doubleArray43 = pointVectorValuePair42.getValue();
        org.apache.commons.math3.linear.RealVector realVector44 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray43);
        org.apache.commons.math3.linear.RealVector realVector45 = realVector25.projection(realVector44);
        java.lang.String str46 = realVectorFormat6.format(realVector45);
        try {
            org.apache.commons.math3.linear.RealVector realVector47 = arrayRealVector2.projection(realVector45);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 35 != 6");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realVector25);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(realVector44);
        org.junit.Assert.assertNotNull(realVector45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + ",32052-110-1" + "'", str46.equals(",32052-110-1"));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.apache.commons.math3.analysis.MultivariateVectorFunction multivariateVectorFunction0 = null;
        org.apache.commons.math3.optim.nonlinear.vector.ModelFunction modelFunction1 = new org.apache.commons.math3.optim.nonlinear.vector.ModelFunction(multivariateVectorFunction0);
        org.apache.commons.math3.analysis.MultivariateVectorFunction multivariateVectorFunction2 = modelFunction1.getModelFunction();
        org.junit.Assert.assertNull(multivariateVectorFunction2);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        java.text.NumberFormat numberFormat6 = org.apache.commons.math3.util.CompositeFormat.getDefaultNumberFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat7 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat6);
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat8 = new org.apache.commons.math3.linear.RealMatrixFormat("", "org.apache.commons.math3.linear.NonSymmetricMatrixException: non symmetric matrix: the difference between entries at (1,0) and (0,1) is larger than 0", "", "hi!", "{", "hi!", numberFormat6);
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat9 = new org.apache.commons.math3.linear.RealMatrixFormat(numberFormat6);
        java.lang.String str10 = realMatrixFormat9.getPrefix();
        org.junit.Assert.assertNotNull(numberFormat6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "{" + "'", str10.equals("{"));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double double8 = array2DRowRealMatrix7.getFrobeniusNorm();
        double[] doubleArray15 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        double[][] doubleArray17 = array2DRowRealMatrix16.getData();
        double[][] doubleArray18 = array2DRowRealMatrix16.getData();
        double[] doubleArray25 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double double27 = array2DRowRealMatrix26.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix16, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix26);
        org.apache.commons.math3.linear.RealMatrix realMatrix29 = array2DRowRealMatrix7.add((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix16);
        double[] doubleArray36 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix37 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray36);
        double[][] doubleArray38 = array2DRowRealMatrix37.getData();
        double[][] doubleArray39 = array2DRowRealMatrix37.getData();
        double[] doubleArray46 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix47 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray46);
        double[] doubleArray54 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix55 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray54);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair56 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray46, doubleArray54);
        double[] doubleArray57 = pointVectorValuePair56.getFirst();
        double[] doubleArray58 = pointVectorValuePair56.getPointRef();
        double[] doubleArray65 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix66 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray65);
        double[] doubleArray73 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix74 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray73);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair75 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray65, doubleArray73);
        double[] doubleArray76 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray58, doubleArray73);
        double[] doubleArray77 = array2DRowRealMatrix37.preMultiply(doubleArray73);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix78 = array2DRowRealMatrix16.subtract(array2DRowRealMatrix37);
        double[] doubleArray85 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix86 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray85);
        double[][] doubleArray87 = array2DRowRealMatrix86.getData();
        double[][] doubleArray88 = array2DRowRealMatrix86.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix89 = array2DRowRealMatrix37.add(array2DRowRealMatrix86);
        double[] doubleArray96 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix97 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray96);
        org.apache.commons.math3.linear.RealMatrix realMatrix98 = array2DRowRealMatrix89.subtract((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix97);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 61.886993787063204d + "'", double8 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 61.886993787063204d + "'", double27 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix78);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix89);
        org.junit.Assert.assertNotNull(doubleArray96);
        org.junit.Assert.assertNotNull(realMatrix98);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        long[] longArray3 = new long[] { 35, 52, (-7910618197763358337L) };
        try {
            org.apache.commons.math3.util.MathArrays.checkNonNegative(longArray3);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException; message: -7,910,618,197,763,358,337 is smaller than the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotPositiveException e) {
        }
        org.junit.Assert.assertNotNull(longArray3);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray2 = new java.lang.Object[] {};
        org.apache.commons.math3.exception.MathInternalError mathInternalError3 = new org.apache.commons.math3.exception.MathInternalError(localizable1, objArray2);
        java.lang.Throwable[] throwableArray4 = mathInternalError3.getSuppressed();
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException5 = new org.apache.commons.math3.exception.NullArgumentException(localizable0, (java.lang.Object[]) throwableArray4);
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(throwableArray4);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6, true);
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray6, (double) 2147483647);
        double[] doubleArray21 = pointValuePair20.getPointRef();
        double[] doubleArray22 = pointValuePair20.getPointRef();
        double[] doubleArray23 = pointValuePair20.getPointRef();
        java.lang.Double double24 = pointValuePair20.getSecond();
        double[] doubleArray25 = pointValuePair20.getKey();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 2.147483647E9d + "'", double24.equals(2.147483647E9d));
        org.junit.Assert.assertNotNull(doubleArray25);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double double8 = array2DRowRealMatrix7.getFrobeniusNorm();
        double[] doubleArray15 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        double[][] doubleArray17 = array2DRowRealMatrix16.getData();
        double[][] doubleArray18 = array2DRowRealMatrix16.getData();
        double[] doubleArray25 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double double27 = array2DRowRealMatrix26.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix16, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix26);
        org.apache.commons.math3.linear.RealMatrix realMatrix29 = array2DRowRealMatrix7.add((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix16);
        double[][] doubleArray30 = array2DRowRealMatrix7.getDataRef();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30);
        org.apache.commons.math3.linear.RealMatrix realMatrix33 = array2DRowRealMatrix31.scalarMultiply(0.0d);
        try {
            array2DRowRealMatrix31.setEntry((int) (byte) 1, 2147483647, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (2,147,483,647)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 61.886993787063204d + "'", double8 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 61.886993787063204d + "'", double27 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(realMatrix33);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        double double4 = org.apache.commons.math3.util.MathArrays.linearCombination((double) 0.14566922f, 0.0d, (double) 1079508992, (double) 0.0f);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 61.0d, (java.lang.Number) 10.0d, (int) (short) -1);
        java.lang.Number number4 = nonMonotonicSequenceException3.getArgument();
        int int5 = nonMonotonicSequenceException3.getIndex();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 61.0d + "'", number4.equals(61.0d));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6, true);
        double[] doubleArray25 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        org.apache.commons.math3.linear.RealMatrix realMatrix27 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray25);
        org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math3.linear.AnyMatrix) diagonalMatrix18, (org.apache.commons.math3.linear.AnyMatrix) realMatrix27);
        double[] doubleArray29 = diagonalMatrix18.getDataRef();
        try {
            double double32 = diagonalMatrix18.getEntry((int) 'a', (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (97)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realMatrix27);
        org.junit.Assert.assertNotNull(doubleArray29);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 100, (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.scalarAdd(0.0d);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix5.getSubMatrix(32, (-127), 1, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-127)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.apache.commons.math3.exception.MathInternalError mathInternalError0 = new org.apache.commons.math3.exception.MathInternalError();
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 100, (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.scalarAdd(0.0d);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 100, (int) (byte) 10);
        double double10 = blockRealMatrix9.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix12 = blockRealMatrix9.scalarAdd(0.0d);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = blockRealMatrix9.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix14 = blockRealMatrix6.multiply(blockRealMatrix9);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = blockRealMatrix6.add((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix15);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 10x100 but expected 0x0");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix12);
        org.junit.Assert.assertNotNull(blockRealMatrix13);
        org.junit.Assert.assertNotNull(blockRealMatrix14);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException(0, 50, 99, (int) (byte) 0);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) (short) 100, 100, (int) (byte) -1, (int) (short) 100);
        java.lang.Integer[] intArray5 = matrixDimensionMismatchException4.getWrongDimensions();
        int int6 = matrixDimensionMismatchException4.getExpectedColumnDimension();
        int int7 = matrixDimensionMismatchException4.getExpectedRowDimension();
        try {
            int int9 = matrixDimensionMismatchException4.getExpectedDimension(1079508992);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1079508992");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex1 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex((int) ' ');
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(0, 27);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver1 = new org.apache.commons.math3.analysis.solvers.BrentSolver(35.0d);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[][] doubleArray8 = array2DRowRealMatrix7.getData();
        double[][] doubleArray9 = array2DRowRealMatrix7.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray9);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor11 = null;
        try {
            double double16 = array2DRowRealMatrix10.walkInColumnOrder(realMatrixChangingVisitor11, (-1), (int) (short) 1, 0, 35);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 3830.0d, (java.lang.Number) 0.0d, 1079508992);
        int int4 = nonMonotonicSequenceException3.getIndex();
        java.lang.Number number5 = nonMonotonicSequenceException3.getPrevious();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1079508992 + "'", int4 == 1079508992);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0d + "'", number5.equals(0.0d));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        java.text.NumberFormat numberFormat3 = null;
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat4 = new org.apache.commons.math3.linear.RealVectorFormat("hi!", "hi!", "", numberFormat3);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = realVectorFormat4.parse(",32052-110-1");
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathParseException; message: illegal state: string \",32052-110-1\" unparseable (from position 0) as an object of type org.apache.commons.math3.linear.ArrayRealVector");
        } catch (org.apache.commons.math3.exception.MathParseException e) {
        }
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 100, (int) (byte) 10);
        double[][] doubleArray3 = blockRealMatrix2.getData();
        double[] doubleArray10 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray10);
        double[] doubleArray18 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray18);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair20 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray10, doubleArray18);
        double[] doubleArray21 = pointVectorValuePair20.getValue();
        double[] doubleArray22 = pointVectorValuePair20.getPointRef();
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray22);
        org.apache.commons.math3.linear.RealMatrix realMatrix24 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray22);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix25 = blockRealMatrix2.multiply(realMatrix24);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 10 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(realMatrix24);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula0 = org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES;
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker1 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer2 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, pointValuePairConvergenceChecker1);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula3 = org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.POLAK_RIBIERE;
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker7 = new org.apache.commons.math3.optim.SimpleValueChecker((-135.01712228365548d), 96.0d, 6);
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver10 = new org.apache.commons.math3.analysis.solvers.BrentSolver((double) 100L, (double) 'a');
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.Preconditioner preconditioner11 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer12 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula3, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker7, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver10, preconditioner11);
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver16 = new org.apache.commons.math3.analysis.solvers.BrentSolver((double) 9.536743E-7f, (double) 0.14566922f, 0.0d);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.Preconditioner preconditioner17 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer18 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker7, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver16, preconditioner17);
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = null;
        double[] doubleArray27 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray27);
        double[] doubleArray35 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray35);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair37 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray27, doubleArray35);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix39 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray27, true);
        org.apache.commons.math3.optim.PointValuePair pointValuePair41 = new org.apache.commons.math3.optim.PointValuePair(doubleArray27, (double) 2147483647);
        double[] doubleArray42 = pointValuePair41.getPointRef();
        boolean boolean43 = simpleValueChecker7.converged((int) '#', pointValuePair20, pointValuePair41);
        org.junit.Assert.assertTrue("'" + formula0 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES + "'", formula0.equals(org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES));
        org.junit.Assert.assertTrue("'" + formula3 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.POLAK_RIBIERE + "'", formula3.equals(org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.POLAK_RIBIERE));
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[][] doubleArray8 = array2DRowRealMatrix7.getData();
        double[][] doubleArray9 = array2DRowRealMatrix7.getData();
        double[] doubleArray16 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16);
        double[] doubleArray24 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray24);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair26 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray16, doubleArray24);
        double[] doubleArray27 = pointVectorValuePair26.getFirst();
        double[] doubleArray28 = array2DRowRealMatrix7.preMultiply(doubleArray27);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        double double1 = org.apache.commons.math3.util.FastMath.log10(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.apache.commons.math3.util.Incrementor.MaxCountExceededCallback maxCountExceededCallback1 = null;
        try {
            org.apache.commons.math3.util.Incrementor incrementor2 = new org.apache.commons.math3.util.Incrementor(27, maxCountExceededCallback1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        double double1 = org.apache.commons.math3.util.FastMath.cos((-11.154160537197155d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.1579223549310333d + "'", double1 == 0.1579223549310333d);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double double8 = array2DRowRealMatrix7.getFrobeniusNorm();
        double[] doubleArray15 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        double[][] doubleArray17 = array2DRowRealMatrix16.getData();
        double[][] doubleArray18 = array2DRowRealMatrix16.getData();
        double[] doubleArray25 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double double27 = array2DRowRealMatrix26.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix16, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix26);
        org.apache.commons.math3.linear.RealMatrix realMatrix29 = array2DRowRealMatrix7.add((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix16);
        double[] doubleArray36 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix37 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray36);
        org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) realMatrix29, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix37);
        double[] doubleArray49 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix50 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray49);
        double[] doubleArray57 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix58 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray57);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair59 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray49, doubleArray57);
        org.apache.commons.math3.optim.InitialGuess initialGuess60 = new org.apache.commons.math3.optim.InitialGuess(doubleArray49);
        double[] doubleArray61 = initialGuess60.getInitialGuess();
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix62 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray61);
        double[] doubleArray69 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix70 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray69);
        double[] doubleArray77 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix78 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray77);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair79 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray69, doubleArray77);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix81 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray69, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix82 = diagonalMatrix62.multiply(diagonalMatrix81);
        double[][] doubleArray83 = diagonalMatrix82.getData();
        try {
            array2DRowRealMatrix37.copySubMatrix(2, (int) (byte) 0, 50, 2147483647, doubleArray83);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooSmallException; message: initial row 2 after final row 0");
        } catch (org.apache.commons.math3.exception.NumberIsTooSmallException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 61.886993787063204d + "'", double8 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 61.886993787063204d + "'", double27 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(diagonalMatrix82);
        org.junit.Assert.assertNotNull(doubleArray83);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        double double1 = org.apache.commons.math3.util.FastMath.floor((double) 100L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1 == 100.0d);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker4 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker((double) ' ', (double) '#');
        org.apache.commons.math3.optim.univariate.BrentOptimizer brentOptimizer5 = new org.apache.commons.math3.optim.univariate.BrentOptimizer((double) 1.0000001f, (double) ' ', (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.univariate.UnivariatePointValuePair>) simpleUnivariateValueChecker4);
        double double6 = brentOptimizer5.getMax();
        double double7 = brentOptimizer5.getMin();
        double double8 = brentOptimizer5.getMax();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6, true);
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray6, (double) 2147483647);
        double[] doubleArray21 = pointValuePair20.getFirst();
        double[] doubleArray22 = pointValuePair20.getFirst();
        double[] doubleArray23 = pointValuePair20.getKey();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.apache.commons.math3.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math3.exception.TooManyEvaluationsException((java.lang.Number) 100);
        java.lang.Number number2 = tooManyEvaluationsException1.getMax();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 100 + "'", number2.equals(100));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double double8 = array2DRowRealMatrix7.getFrobeniusNorm();
        double[] doubleArray15 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        double[][] doubleArray17 = array2DRowRealMatrix16.getData();
        double[][] doubleArray18 = array2DRowRealMatrix16.getData();
        double[] doubleArray25 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double double27 = array2DRowRealMatrix26.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix16, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix26);
        org.apache.commons.math3.linear.RealMatrix realMatrix29 = array2DRowRealMatrix7.add((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix16);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector36.addToEntry(0, (double) 1.0f);
        double[] doubleArray46 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix47 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray46);
        double[][] doubleArray48 = array2DRowRealMatrix47.getData();
        double[][] doubleArray49 = array2DRowRealMatrix47.getData();
        double[] doubleArray56 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix57 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray56);
        double double58 = array2DRowRealMatrix57.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix47, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix57);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector63 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector63.addToEntry(0, (double) 1.0f);
        arrayRealVector63.unitize();
        array2DRowRealMatrix47.setRowVector(0, (org.apache.commons.math3.linear.RealVector) arrayRealVector63);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector69 = arrayRealVector36.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector63);
        double double70 = arrayRealVector33.cosine((org.apache.commons.math3.linear.RealVector) arrayRealVector69);
        double[] doubleArray77 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix78 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray77);
        double[] doubleArray85 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix86 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray85);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair87 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray77, doubleArray85);
        double[] doubleArray88 = pointVectorValuePair87.getValue();
        double[] doubleArray89 = pointVectorValuePair87.getPointRef();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector90 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray89);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector91 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector90);
        double double92 = arrayRealVector91.getMaxValue();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector93 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector69, arrayRealVector91);
        array2DRowRealMatrix7.setRowVector(0, (org.apache.commons.math3.linear.RealVector) arrayRealVector69);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 61.886993787063204d + "'", double8 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 61.886993787063204d + "'", double27 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 61.886993787063204d + "'", double58 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(arrayRealVector69);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 1.0d + "'", double70 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 52.0d + "'", double92 == 52.0d);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) (byte) -1, (java.lang.Number) 0.0f, false);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6, true);
        double[] doubleArray25 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double[] doubleArray33 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray33);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair35 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray25, doubleArray33);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix37 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray25, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix38 = diagonalMatrix18.add(diagonalMatrix37);
        double[] doubleArray39 = diagonalMatrix18.getDataRef();
        double double40 = diagonalMatrix18.getNorm();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(diagonalMatrix38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 52.0d + "'", double40 == 52.0d);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        float float2 = org.apache.commons.math3.util.Precision.round((float) (byte) 100, 986830553);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer powellOptimizer2 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer((double) (short) 100, (double) (byte) 1);
        int int3 = powellOptimizer2.getEvaluations();
        int int4 = powellOptimizer2.getEvaluations();
        double[] doubleArray5 = powellOptimizer2.getStartPoint();
        int int6 = powellOptimizer2.getMaxEvaluations();
        int int7 = powellOptimizer2.getEvaluations();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 100, (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.scalarAdd(0.0d);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 100, (int) (byte) 10);
        double double10 = blockRealMatrix9.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix12 = blockRealMatrix9.getRowMatrix(29);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = blockRealMatrix2.subtract(blockRealMatrix12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 100x10 but expected 1x10");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix12);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        double double1 = org.apache.commons.math3.util.FastMath.asin(3830.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double[] doubleArray7 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        double[] doubleArray15 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair17 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray7, doubleArray15);
        org.apache.commons.math3.optim.InitialGuess initialGuess18 = new org.apache.commons.math3.optim.InitialGuess(doubleArray7);
        org.apache.commons.math3.optim.InitialGuess initialGuess19 = new org.apache.commons.math3.optim.InitialGuess(doubleArray7);
        try {
            double[] doubleArray20 = array2DRowRealMatrix0.preMultiply(doubleArray7);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 6 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray15);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        int[] intArray6 = new int[] { (byte) 100 };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister7 = new org.apache.commons.math3.random.MersenneTwister(intArray6);
        double double8 = mersenneTwister7.nextGaussian();
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker10 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer11 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer((int) 'a', (double) 10, true, (int) (short) -1, 0, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister7, false, pointValuePairConvergenceChecker10);
        java.util.List<java.lang.Double> doubleList12 = cMAESOptimizer11.getStatisticsSigmaHistory();
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType13 = cMAESOptimizer11.getGoalType();
        java.util.List<java.lang.Double> doubleList14 = cMAESOptimizer11.getStatisticsFitnessHistory();
        double[] doubleArray15 = cMAESOptimizer11.getStartPoint();
        java.util.List<java.lang.Double> doubleList16 = cMAESOptimizer11.getStatisticsSigmaHistory();
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.7650730050315234d + "'", double8 == 0.7650730050315234d);
        org.junit.Assert.assertNotNull(doubleList12);
        org.junit.Assert.assertNull(goalType13);
        org.junit.Assert.assertNotNull(doubleList14);
        org.junit.Assert.assertNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleList16);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        double double1 = org.apache.commons.math3.util.FastMath.signum((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        float float1 = org.apache.commons.math3.util.FastMath.ulp((float) 100);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 7.6293945E-6f + "'", float1 == 7.6293945E-6f);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        org.apache.commons.math3.optim.InitialGuess initialGuess17 = new org.apache.commons.math3.optim.InitialGuess(doubleArray6);
        org.apache.commons.math3.optim.InitialGuess initialGuess18 = new org.apache.commons.math3.optim.InitialGuess(doubleArray6);
        org.apache.commons.math3.linear.RealMatrix realMatrix19 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray6);
        try {
            org.apache.commons.math3.optim.nonlinear.vector.Weight weight20 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(realMatrix19);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.NonSquareMatrixException; message: non square (6x1) matrix");
        } catch (org.apache.commons.math3.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realMatrix19);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        double[] doubleArray17 = pointVectorValuePair16.getFirst();
        double[] doubleArray18 = pointVectorValuePair16.getPointRef();
        double[] doubleArray25 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double[] doubleArray33 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray33);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair35 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray25, doubleArray33);
        double[] doubleArray36 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray18, doubleArray33);
        double[] doubleArray41 = new double[] { (short) 10, 10L, 'a', 0.7650730050315234d };
        org.apache.commons.math3.optim.SimpleBounds simpleBounds42 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray36, doubleArray41);
        double[] doubleArray49 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix50 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray49);
        double[] doubleArray57 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix58 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray57);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair59 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray49, doubleArray57);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair61 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray36, doubleArray57, false);
        double[] doubleArray68 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix69 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray68);
        double[] doubleArray76 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix77 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray76);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair78 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray68, doubleArray76);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix80 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray68, true);
        org.apache.commons.math3.optim.PointValuePair pointValuePair82 = new org.apache.commons.math3.optim.PointValuePair(doubleArray68, (double) 2147483647);
        double[] doubleArray83 = pointValuePair82.getPointRef();
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition84 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray57, doubleArray83);
        try {
            org.apache.commons.math3.linear.RealVector realVector86 = eigenDecomposition84.getEigenvector((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray83);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        double[] doubleArray17 = pointVectorValuePair16.getValue();
        double[] doubleArray18 = pointVectorValuePair16.getPointRef();
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix19 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray18);
        double[] doubleArray26 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix27 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray26);
        double[] doubleArray34 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix35 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray34);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair36 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray26, doubleArray34);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix38 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray26, true);
        org.apache.commons.math3.optim.PointValuePair pointValuePair40 = new org.apache.commons.math3.optim.PointValuePair(doubleArray26, (double) 2147483647);
        double[] doubleArray41 = pointValuePair40.getPointRef();
        double[] doubleArray42 = pointValuePair40.getPointRef();
        double[] doubleArray43 = pointValuePair40.getPointRef();
        boolean boolean44 = diagonalMatrix19.equals((java.lang.Object) pointValuePair40);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        int int1 = org.apache.commons.math3.util.FastMath.getExponent(6.439679899321124E13d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 45 + "'", int1 == 45);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer();
        double double1 = levenbergMarquardtOptimizer0.getChiSquare();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector2.addToEntry(0, (double) 1.0f);
        org.apache.commons.math3.linear.RealVector realVector7 = arrayRealVector2.mapSubtractToSelf(146.01712228365548d);
        double double8 = arrayRealVector2.getMinValue();
        org.junit.Assert.assertNotNull(realVector7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-135.01712228365548d) + "'", double8 == (-135.01712228365548d));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6, true);
        double[] doubleArray25 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double[] doubleArray33 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray33);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair35 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray25, doubleArray33);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix37 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray25, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix38 = diagonalMatrix18.add(diagonalMatrix37);
        double[] doubleArray39 = diagonalMatrix18.getDataRef();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix40 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray39);
        int int41 = org.apache.commons.math3.util.MathUtils.hash(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(diagonalMatrix38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-2007483583) + "'", int41 == (-2007483583));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex6 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex((int) 'a', (-11.154160537197155d), 146.01712228365548d, 1.1102230246251565E-16d, 104.0d, (double) 1079508992);
        org.apache.commons.math3.analysis.MultivariateFunction multivariateFunction7 = null;
        java.util.Comparator<org.apache.commons.math3.optim.PointValuePair> pointValuePairComparator8 = null;
        try {
            nelderMeadSimplex6.iterate(multivariateFunction7, pointValuePairComparator8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 100, (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.scalarAdd(0.0d);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = null;
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix2.subtract(blockRealMatrix6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double double8 = array2DRowRealMatrix7.getFrobeniusNorm();
        double[] doubleArray15 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        double[][] doubleArray17 = array2DRowRealMatrix16.getData();
        double[][] doubleArray18 = array2DRowRealMatrix16.getData();
        double[] doubleArray25 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double double27 = array2DRowRealMatrix26.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix16, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix26);
        org.apache.commons.math3.linear.RealMatrix realMatrix29 = array2DRowRealMatrix7.add((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix16);
        double[] doubleArray36 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix37 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray36);
        double[][] doubleArray38 = array2DRowRealMatrix37.getData();
        double[][] doubleArray39 = array2DRowRealMatrix37.getData();
        double[] doubleArray46 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix47 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray46);
        double[] doubleArray54 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix55 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray54);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair56 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray46, doubleArray54);
        double[] doubleArray57 = pointVectorValuePair56.getFirst();
        double[] doubleArray58 = pointVectorValuePair56.getPointRef();
        double[] doubleArray65 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix66 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray65);
        double[] doubleArray73 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix74 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray73);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair75 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray65, doubleArray73);
        double[] doubleArray76 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray58, doubleArray73);
        double[] doubleArray77 = array2DRowRealMatrix37.preMultiply(doubleArray73);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix78 = array2DRowRealMatrix16.subtract(array2DRowRealMatrix37);
        double[] doubleArray85 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix86 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray85);
        double[][] doubleArray87 = array2DRowRealMatrix86.getData();
        double[][] doubleArray88 = array2DRowRealMatrix86.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix89 = array2DRowRealMatrix37.add(array2DRowRealMatrix86);
        double[] doubleArray96 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix97 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray96);
        double double98 = array2DRowRealMatrix97.getFrobeniusNorm();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix99 = array2DRowRealMatrix89.add(array2DRowRealMatrix97);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 61.886993787063204d + "'", double8 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 61.886993787063204d + "'", double27 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix78);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix89);
        org.junit.Assert.assertNotNull(doubleArray96);
        org.junit.Assert.assertTrue("'" + double98 + "' != '" + 61.886993787063204d + "'", double98 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix99);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[][] doubleArray8 = array2DRowRealMatrix7.getData();
        double[] doubleArray15 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        double double17 = array2DRowRealMatrix16.getFrobeniusNorm();
        java.lang.String str18 = array2DRowRealMatrix16.toString();
        org.apache.commons.math3.linear.RealMatrix realMatrix19 = array2DRowRealMatrix7.subtract((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix16);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor20 = null;
        try {
            double double25 = array2DRowRealMatrix7.walkInRowOrder(realMatrixChangingVisitor20, (int) (byte) 1, 1079508992, 27, 29);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1,079,508,992)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 61.886993787063204d + "'", double17 == 61.886993787063204d);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Array2DRowRealMatrix{{32.0},{0.0},{52.0},{-1.0},{10.0},{-1.0}}" + "'", str18.equals("Array2DRowRealMatrix{{32.0},{0.0},{52.0},{-1.0},{10.0},{-1.0}}"));
        org.junit.Assert.assertNotNull(realMatrix19);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.RealMatrixFormat.getInstance();
        org.junit.Assert.assertNotNull(realMatrixFormat0);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[][] doubleArray8 = array2DRowRealMatrix7.getData();
        double[] doubleArray15 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        double double17 = array2DRowRealMatrix16.getFrobeniusNorm();
        java.lang.String str18 = array2DRowRealMatrix16.toString();
        org.apache.commons.math3.linear.RealMatrix realMatrix19 = array2DRowRealMatrix7.subtract((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix16);
        org.apache.commons.math3.linear.RealMatrix realMatrix21 = array2DRowRealMatrix16.scalarMultiply(0.9086743489308475d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 61.886993787063204d + "'", double17 == 61.886993787063204d);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Array2DRowRealMatrix{{32.0},{0.0},{52.0},{-1.0},{10.0},{-1.0}}" + "'", str18.equals("Array2DRowRealMatrix{{32.0},{0.0},{52.0},{-1.0},{10.0},{-1.0}}"));
        org.junit.Assert.assertNotNull(realMatrix19);
        org.junit.Assert.assertNotNull(realMatrix21);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double double8 = array2DRowRealMatrix7.getFrobeniusNorm();
        double[] doubleArray15 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        double[][] doubleArray17 = array2DRowRealMatrix16.getData();
        double[][] doubleArray18 = array2DRowRealMatrix16.getData();
        double[] doubleArray25 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double double27 = array2DRowRealMatrix26.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix16, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix26);
        org.apache.commons.math3.linear.RealMatrix realMatrix29 = array2DRowRealMatrix7.add((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix16);
        double[] doubleArray36 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix37 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray36);
        double[][] doubleArray38 = array2DRowRealMatrix37.getData();
        double[][] doubleArray39 = array2DRowRealMatrix37.getData();
        double[] doubleArray46 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix47 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray46);
        double[] doubleArray54 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix55 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray54);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair56 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray46, doubleArray54);
        double[] doubleArray57 = pointVectorValuePair56.getFirst();
        double[] doubleArray58 = pointVectorValuePair56.getPointRef();
        double[] doubleArray65 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix66 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray65);
        double[] doubleArray73 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix74 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray73);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair75 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray65, doubleArray73);
        double[] doubleArray76 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray58, doubleArray73);
        double[] doubleArray77 = array2DRowRealMatrix37.preMultiply(doubleArray73);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix78 = array2DRowRealMatrix16.subtract(array2DRowRealMatrix37);
        double[] doubleArray85 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix86 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray85);
        double[][] doubleArray87 = array2DRowRealMatrix86.getData();
        double[][] doubleArray88 = array2DRowRealMatrix86.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix89 = array2DRowRealMatrix37.add(array2DRowRealMatrix86);
        double double90 = array2DRowRealMatrix86.getFrobeniusNorm();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 61.886993787063204d + "'", double8 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 61.886993787063204d + "'", double27 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix78);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix89);
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + 61.886993787063204d + "'", double90 == 61.886993787063204d);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double double8 = array2DRowRealMatrix7.getFrobeniusNorm();
        double[] doubleArray15 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        double[][] doubleArray17 = array2DRowRealMatrix16.getData();
        double[][] doubleArray18 = array2DRowRealMatrix16.getData();
        double[] doubleArray25 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double double27 = array2DRowRealMatrix26.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix16, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix26);
        org.apache.commons.math3.linear.RealMatrix realMatrix29 = array2DRowRealMatrix7.add((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix16);
        double[][] doubleArray30 = array2DRowRealMatrix7.getDataRef();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix33 = array2DRowRealMatrix31.getColumnMatrix(27);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (27)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 61.886993787063204d + "'", double8 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 61.886993787063204d + "'", double27 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertNotNull(doubleArray30);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.append((double) 0.0f);
        boolean boolean5 = arrayRealVector2.isNaN();
        boolean boolean6 = arrayRealVector2.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        org.apache.commons.math3.linear.RealVector realVector11 = arrayRealVector9.append((double) 0.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector14.addToEntry(0, (double) 1.0f);
        double[] doubleArray24 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray24);
        double[][] doubleArray26 = array2DRowRealMatrix25.getData();
        double[][] doubleArray27 = array2DRowRealMatrix25.getData();
        double[] doubleArray34 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix35 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray34);
        double double36 = array2DRowRealMatrix35.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix25, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix35);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector41.addToEntry(0, (double) 1.0f);
        arrayRealVector41.unitize();
        array2DRowRealMatrix25.setRowVector(0, (org.apache.commons.math3.linear.RealVector) arrayRealVector41);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = arrayRealVector14.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector41);
        double[] doubleArray48 = arrayRealVector41.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector9, doubleArray48);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector51 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector9, false);
        double double52 = arrayRealVector2.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector51);
        boolean boolean53 = arrayRealVector2.isInfinite();
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(realVector11);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 61.886993787063204d + "'", double36 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(arrayRealVector47);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.apache.commons.math3.optim.SimpleVectorValueChecker simpleVectorValueChecker2 = new org.apache.commons.math3.optim.SimpleVectorValueChecker(83.86684335012045d, 2.718281828459045d);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        float float1 = org.apache.commons.math3.util.FastMath.abs(0.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 100, (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.scalarAdd(0.0d);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 100, (int) (byte) 10);
        double double10 = blockRealMatrix9.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix12 = blockRealMatrix9.scalarAdd(0.0d);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = blockRealMatrix9.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix14 = blockRealMatrix6.multiply(blockRealMatrix9);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor15 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        defaultRealMatrixPreservingVisitor15.visit(0, (int) (short) 0, (double) '#');
        double double20 = blockRealMatrix6.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor15);
        double[] doubleArray28 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray28);
        double[] doubleArray36 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix37 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray36);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair38 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray28, doubleArray36);
        double[] doubleArray39 = pointVectorValuePair38.getValue();
        double[] doubleArray40 = pointVectorValuePair38.getPointRef();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector43 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray40, arrayRealVector43);
        try {
            blockRealMatrix6.setColumnVector((int) (short) 0, (org.apache.commons.math3.linear.RealVector) arrayRealVector44);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 7x1 but expected 10x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix12);
        org.junit.Assert.assertNotNull(blockRealMatrix13);
        org.junit.Assert.assertNotNull(blockRealMatrix14);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 5, (java.lang.Number) 3830.0d, false);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        double double1 = org.apache.commons.math3.util.FastMath.abs((double) 127);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 127.0d + "'", double1 == 127.0d);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex5 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(0, 100.0d, (double) 1085139999, (double) 96L, (-0.6321205588285577d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.ZeroException; message: zero not allowed here");
        } catch (org.apache.commons.math3.exception.ZeroException e) {
        }
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.append((double) 0.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector7.addToEntry(0, (double) 1.0f);
        double[] doubleArray17 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray17);
        double[][] doubleArray19 = array2DRowRealMatrix18.getData();
        double[][] doubleArray20 = array2DRowRealMatrix18.getData();
        double[] doubleArray27 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray27);
        double double29 = array2DRowRealMatrix28.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix18, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix28);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector34.addToEntry(0, (double) 1.0f);
        arrayRealVector34.unitize();
        array2DRowRealMatrix18.setRowVector(0, (org.apache.commons.math3.linear.RealVector) arrayRealVector34);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = arrayRealVector7.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector34);
        double[] doubleArray41 = arrayRealVector34.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, doubleArray41);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector47.addToEntry(0, (double) 1.0f);
        double[] doubleArray57 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix58 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray57);
        double[][] doubleArray59 = array2DRowRealMatrix58.getData();
        double[][] doubleArray60 = array2DRowRealMatrix58.getData();
        double[] doubleArray67 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix68 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray67);
        double double69 = array2DRowRealMatrix68.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix58, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix68);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector74 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector74.addToEntry(0, (double) 1.0f);
        arrayRealVector74.unitize();
        array2DRowRealMatrix58.setRowVector(0, (org.apache.commons.math3.linear.RealVector) arrayRealVector74);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector80 = arrayRealVector47.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector74);
        double double81 = arrayRealVector2.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector47);
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor82 = null;
        try {
            double double83 = arrayRealVector2.walkInDefaultOrder(realVectorChangingVisitor82);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 61.886993787063204d + "'", double29 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(arrayRealVector40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 61.886993787063204d + "'", double69 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(arrayRealVector80);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 110.0d + "'", double81 == 110.0d);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        try {
            org.apache.commons.math3.optim.MaxEval maxEval1 = new org.apache.commons.math3.optim.MaxEval((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        try {
            org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.verifySequence((double) 9.536743E-7f, (double) 95.99999f, (double) 9.536743E-7f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [96, 0]");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6, true);
        double[] doubleArray25 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double[] doubleArray33 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray33);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair35 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray25, doubleArray33);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix37 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray25, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix38 = diagonalMatrix18.add(diagonalMatrix37);
        diagonalMatrix38.multiplyEntry(50, (int) '4', (-0.5d));
        double[] doubleArray49 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix50 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray49);
        double[] doubleArray57 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix58 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray57);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair59 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray49, doubleArray57);
        double[] doubleArray60 = pointVectorValuePair59.getValue();
        double[] doubleArray61 = pointVectorValuePair59.getPointRef();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector62 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray61);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector63 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector62);
        double double64 = arrayRealVector63.getMaxValue();
        double[] doubleArray65 = arrayRealVector63.getDataRef();
        double[] doubleArray66 = diagonalMatrix38.operate(doubleArray65);
        int int67 = diagonalMatrix38.getColumnDimension();
        int[] intArray71 = new int[] { (byte) 1, (byte) 100, '4' };
        int[] intArray76 = new int[] { 'a', (short) 1, (byte) 100, 'a' };
        double double77 = org.apache.commons.math3.util.MathArrays.distance(intArray71, intArray76);
        int[] intArray78 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSubMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) diagonalMatrix38, intArray71, intArray78);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(diagonalMatrix38);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 52.0d + "'", double64 == 52.0d);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 6 + "'", int67 == 6);
        org.junit.Assert.assertNotNull(intArray71);
        org.junit.Assert.assertNotNull(intArray76);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 146.01712228365548d + "'", double77 == 146.01712228365548d);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.append((double) 0.0f);
        boolean boolean5 = arrayRealVector2.isNaN();
        int int6 = arrayRealVector2.getMaxIndex();
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 100, (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.scalarAdd(0.0d);
        int int6 = blockRealMatrix5.getRowDimension();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat3 = new org.apache.commons.math3.linear.RealVectorFormat("", "Array2DRowRealMatrix{{32.0},{0.0},{52.0},{-1.0},{10.0},{-1.0}}", "");
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = realVectorFormat3.parse("hi!");
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathParseException; message: illegal state: string \"hi!\" unparseable (from position 0) as an object of type org.apache.commons.math3.linear.ArrayRealVector");
        } catch (org.apache.commons.math3.exception.MathParseException e) {
        }
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double double8 = array2DRowRealMatrix7.getFrobeniusNorm();
        double[] doubleArray15 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        double[][] doubleArray17 = array2DRowRealMatrix16.getData();
        double[][] doubleArray18 = array2DRowRealMatrix16.getData();
        double[] doubleArray25 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double double27 = array2DRowRealMatrix26.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix16, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix26);
        org.apache.commons.math3.linear.RealMatrix realMatrix29 = array2DRowRealMatrix7.add((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix16);
        double[][] doubleArray30 = array2DRowRealMatrix7.getDataRef();
        double[] doubleArray41 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix42 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray41);
        double double43 = array2DRowRealMatrix42.getFrobeniusNorm();
        double[] doubleArray50 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix51 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray50);
        double[][] doubleArray52 = array2DRowRealMatrix51.getData();
        double[][] doubleArray53 = array2DRowRealMatrix51.getData();
        double[] doubleArray60 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix61 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray60);
        double double62 = array2DRowRealMatrix61.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix51, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix61);
        org.apache.commons.math3.linear.RealMatrix realMatrix64 = array2DRowRealMatrix42.add((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix51);
        double[][] doubleArray65 = array2DRowRealMatrix42.getDataRef();
        try {
            array2DRowRealMatrix7.copySubMatrix(243, 32, 27, (int) '4', doubleArray65);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (243)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 61.886993787063204d + "'", double8 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 61.886993787063204d + "'", double27 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 61.886993787063204d + "'", double43 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 61.886993787063204d + "'", double62 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(realMatrix64);
        org.junit.Assert.assertNotNull(doubleArray65);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        int int2 = org.apache.commons.math3.util.FastMath.min(2147483647, 1085139999);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1085139999 + "'", int2 == 1085139999);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double double8 = array2DRowRealMatrix7.getFrobeniusNorm();
        double[] doubleArray15 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        double[][] doubleArray17 = array2DRowRealMatrix16.getData();
        double[][] doubleArray18 = array2DRowRealMatrix16.getData();
        double[] doubleArray25 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double double27 = array2DRowRealMatrix26.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix16, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix26);
        org.apache.commons.math3.linear.RealMatrix realMatrix29 = array2DRowRealMatrix7.add((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix16);
        double[] doubleArray36 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix37 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray36);
        double[][] doubleArray38 = array2DRowRealMatrix37.getData();
        double[][] doubleArray39 = array2DRowRealMatrix37.getData();
        double[] doubleArray46 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix47 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray46);
        double[] doubleArray54 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix55 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray54);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair56 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray46, doubleArray54);
        double[] doubleArray57 = pointVectorValuePair56.getFirst();
        double[] doubleArray58 = pointVectorValuePair56.getPointRef();
        double[] doubleArray65 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix66 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray65);
        double[] doubleArray73 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix74 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray73);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair75 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray65, doubleArray73);
        double[] doubleArray76 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray58, doubleArray73);
        double[] doubleArray77 = array2DRowRealMatrix37.preMultiply(doubleArray73);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix78 = array2DRowRealMatrix16.subtract(array2DRowRealMatrix37);
        int int79 = array2DRowRealMatrix37.getColumnDimension();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 61.886993787063204d + "'", double8 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 61.886993787063204d + "'", double27 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix78);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 1 + "'", int79 == 1);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 100, (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.getRowMatrix(29);
        double[] doubleArray13 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13);
        double[] doubleArray21 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray21);
        double[] doubleArray29 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix30 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray29);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair31 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray21, doubleArray29);
        double[] doubleArray32 = pointVectorValuePair31.getFirst();
        double[] doubleArray33 = pointVectorValuePair31.getPointRef();
        double[] doubleArray40 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix41 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray40);
        double[] doubleArray48 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix49 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray48);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair50 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray40, doubleArray48);
        double[] doubleArray51 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray33, doubleArray48);
        double[] doubleArray56 = new double[] { (short) 10, 10L, 'a', 0.7650730050315234d };
        org.apache.commons.math3.optim.SimpleBounds simpleBounds57 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray51, doubleArray56);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair59 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray13, doubleArray51, false);
        org.apache.commons.math3.linear.RealMatrix realMatrix60 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray13);
        try {
            blockRealMatrix2.setRow(6, doubleArray13);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 1x6 but expected 1x10");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(realMatrix60);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        double[] doubleArray0 = null;
        org.apache.commons.math3.optim.PointValuePair pointValuePair2 = new org.apache.commons.math3.optim.PointValuePair(doubleArray0, (double) (short) 100);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.MatrixUtils.OCTAVE_FORMAT;
        java.text.NumberFormat numberFormat1 = realMatrixFormat0.getFormat();
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertNotNull(numberFormat1);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        double[] doubleArray17 = pointVectorValuePair16.getValue();
        org.apache.commons.math3.linear.RealVector realVector18 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray17);
        double[] doubleArray25 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double[] doubleArray33 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray33);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair35 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray25, doubleArray33);
        double[] doubleArray36 = pointVectorValuePair35.getValue();
        org.apache.commons.math3.linear.RealVector realVector37 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray36);
        org.apache.commons.math3.linear.RealVector realVector38 = realVector18.projection(realVector37);
        int int39 = realVector37.getMinIndex();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector42.addToEntry(0, (double) 1.0f);
        double[] doubleArray52 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix53 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray52);
        double[][] doubleArray54 = array2DRowRealMatrix53.getData();
        double[][] doubleArray55 = array2DRowRealMatrix53.getData();
        double[] doubleArray62 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix63 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray62);
        double double64 = array2DRowRealMatrix63.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix53, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix63);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector69 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector69.addToEntry(0, (double) 1.0f);
        arrayRealVector69.unitize();
        array2DRowRealMatrix53.setRowVector(0, (org.apache.commons.math3.linear.RealVector) arrayRealVector69);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector75 = arrayRealVector42.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector69);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector76 = new org.apache.commons.math3.linear.ArrayRealVector(realVector37, arrayRealVector69);
        double double77 = arrayRealVector76.getMaxValue();
        double double78 = arrayRealVector76.getNorm();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(realVector37);
        org.junit.Assert.assertNotNull(realVector38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 5 + "'", int39 == 5);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 61.886993787063204d + "'", double64 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(arrayRealVector75);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 52.0d + "'", double77 == 52.0d);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 61.89507250177513d + "'", double78 == 61.89507250177513d);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat3 = new org.apache.commons.math3.linear.RealVectorFormat(",", "", "");
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = realVectorFormat3.parse("org.apache.commons.math3.linear.MatrixDimensionMismatchException: got 100x100 but expected -1x100");
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathParseException; message: illegal state: string \"org.apache.commons.math3.linear.MatrixDimensionMismatchException: got 100x100 but expected -1x100\" unparseable (from position 0) as an object of type org.apache.commons.math3.linear.ArrayRealVector");
        } catch (org.apache.commons.math3.exception.MathParseException e) {
        }
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        org.apache.commons.math3.optim.InitialGuess initialGuess17 = new org.apache.commons.math3.optim.InitialGuess(doubleArray6);
        double[] doubleArray18 = initialGuess17.getInitialGuess();
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix19 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray18);
        double[] doubleArray26 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix27 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray26);
        double[] doubleArray34 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix35 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray34);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair36 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray26, doubleArray34);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix38 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray26, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix39 = diagonalMatrix19.multiply(diagonalMatrix38);
        double[][] doubleArray40 = diagonalMatrix39.getData();
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex45 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray40, 0.2734986034788211d, 127.0d, 0.9835877454343449d, (double) 13L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 6 != 5");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(diagonalMatrix39);
        org.junit.Assert.assertNotNull(doubleArray40);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        int[] intArray3 = new int[] { (byte) 1, (byte) 100, '4' };
        int[] intArray8 = new int[] { 'a', (short) 1, (byte) 100, 'a' };
        double double9 = org.apache.commons.math3.util.MathArrays.distance(intArray3, intArray8);
        org.apache.commons.math3.random.MersenneTwister mersenneTwister10 = new org.apache.commons.math3.random.MersenneTwister(intArray3);
        int[] intArray12 = new int[] { (byte) 1 };
        int[] intArray16 = new int[] { (byte) 1, (byte) 100, '4' };
        int[] intArray21 = new int[] { 'a', (short) 1, (byte) 100, 'a' };
        double double22 = org.apache.commons.math3.util.MathArrays.distance(intArray16, intArray21);
        int int23 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray12, intArray21);
        try {
            int int24 = org.apache.commons.math3.util.MathArrays.distance1(intArray3, intArray12);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 146.01712228365548d + "'", double9 == 146.01712228365548d);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 146.01712228365548d + "'", double22 == 146.01712228365548d);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 96 + "'", int23 == 96);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[][] doubleArray8 = array2DRowRealMatrix7.getData();
        double[] doubleArray15 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        double double17 = array2DRowRealMatrix16.getFrobeniusNorm();
        java.lang.String str18 = array2DRowRealMatrix16.toString();
        org.apache.commons.math3.linear.RealMatrix realMatrix19 = array2DRowRealMatrix7.subtract((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix16);
        boolean boolean20 = array2DRowRealMatrix7.isSquare();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 61.886993787063204d + "'", double17 == 61.886993787063204d);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Array2DRowRealMatrix{{32.0},{0.0},{52.0},{-1.0},{10.0},{-1.0}}" + "'", str18.equals("Array2DRowRealMatrix{{32.0},{0.0},{52.0},{-1.0},{10.0},{-1.0}}"));
        org.junit.Assert.assertNotNull(realMatrix19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        double[] doubleArray0 = null;
        double[] doubleArray7 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        double[] doubleArray15 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair17 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray7, doubleArray15);
        org.apache.commons.math3.optim.InitialGuess initialGuess18 = new org.apache.commons.math3.optim.InitialGuess(doubleArray7);
        double[] doubleArray19 = initialGuess18.getInitialGuess();
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix20 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray19);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equals(doubleArray0, doubleArray19);
        org.apache.commons.math3.optim.InitialGuess initialGuess22 = new org.apache.commons.math3.optim.InitialGuess(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        int int1 = org.apache.commons.math3.util.FastMath.getExponent((double) 52);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 5 + "'", int1 == 5);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.apache.commons.math3.analysis.MultivariateFunction multivariateFunction0 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.ObjectiveFunction objectiveFunction1 = new org.apache.commons.math3.optim.nonlinear.scalar.ObjectiveFunction(multivariateFunction0);
        org.apache.commons.math3.analysis.MultivariateFunction multivariateFunction2 = objectiveFunction1.getObjectiveFunction();
        org.apache.commons.math3.analysis.MultivariateFunction multivariateFunction3 = objectiveFunction1.getObjectiveFunction();
        org.junit.Assert.assertNull(multivariateFunction2);
        org.junit.Assert.assertNull(multivariateFunction3);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6, true);
        double[] doubleArray25 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        org.apache.commons.math3.linear.RealMatrix realMatrix27 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray25);
        org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math3.linear.AnyMatrix) diagonalMatrix18, (org.apache.commons.math3.linear.AnyMatrix) realMatrix27);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition29 = new org.apache.commons.math3.linear.LUDecomposition(realMatrix27);
        org.apache.commons.math3.linear.DecompositionSolver decompositionSolver30 = lUDecomposition29.getSolver();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realMatrix27);
        org.junit.Assert.assertNotNull(decompositionSolver30);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        double[] doubleArray17 = pointVectorValuePair16.getValue();
        org.apache.commons.math3.linear.RealVector realVector18 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray17);
        double[] doubleArray25 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double[] doubleArray33 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray33);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair35 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray25, doubleArray33);
        double[] doubleArray36 = pointVectorValuePair35.getValue();
        org.apache.commons.math3.linear.RealVector realVector37 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray36);
        org.apache.commons.math3.linear.RealVector realVector38 = realVector18.projection(realVector37);
        int int39 = realVector37.getMinIndex();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector42.addToEntry(0, (double) 1.0f);
        double[] doubleArray52 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix53 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray52);
        double[][] doubleArray54 = array2DRowRealMatrix53.getData();
        double[][] doubleArray55 = array2DRowRealMatrix53.getData();
        double[] doubleArray62 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix63 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray62);
        double double64 = array2DRowRealMatrix63.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix53, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix63);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector69 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector69.addToEntry(0, (double) 1.0f);
        arrayRealVector69.unitize();
        array2DRowRealMatrix53.setRowVector(0, (org.apache.commons.math3.linear.RealVector) arrayRealVector69);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector75 = arrayRealVector42.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector69);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector76 = new org.apache.commons.math3.linear.ArrayRealVector(realVector37, arrayRealVector69);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector77 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector76);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector80 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector80.addToEntry(0, (double) 1.0f);
        org.apache.commons.math3.linear.RealVector realVector85 = arrayRealVector80.mapSubtractToSelf(146.01712228365548d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector86 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector77, arrayRealVector80);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(realVector37);
        org.junit.Assert.assertNotNull(realVector38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 5 + "'", int39 == 5);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 61.886993787063204d + "'", double64 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(arrayRealVector75);
        org.junit.Assert.assertNotNull(realVector85);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        try {
            double double3 = org.apache.commons.math3.util.Precision.round((double) (byte) -1, 1079508992, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        java.text.ParsePosition parsePosition1 = null;
        try {
            char char2 = org.apache.commons.math3.util.CompositeFormat.parseNextCharacter("}", parsePosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.apache.commons.math3.linear.NonSymmetricMatrixException nonSymmetricMatrixException3 = new org.apache.commons.math3.linear.NonSymmetricMatrixException(45, (int) (byte) 0, 0.0d);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer5 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer((double) (short) -1, (double) 10, (double) (-1L), (double) (byte) -1, 0.0d);
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair> pointVectorValuePairConvergenceChecker6 = levenbergMarquardtOptimizer5.getConvergenceChecker();
        double double7 = levenbergMarquardtOptimizer5.getChiSquare();
        org.junit.Assert.assertNull(pointVectorValuePairConvergenceChecker6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        float float3 = org.apache.commons.math3.util.Precision.round(9.536743E-7f, 1079508992, (int) (byte) 0);
        org.junit.Assert.assertEquals((float) float3, Float.NaN, 0);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) (-4228292497824268148L), (java.lang.Number) 45, false);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6, true);
        double[] doubleArray25 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double[] doubleArray33 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray33);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair35 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray25, doubleArray33);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix37 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray25, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix38 = diagonalMatrix18.add(diagonalMatrix37);
        diagonalMatrix38.multiplyEntry(50, (int) '4', (-0.5d));
        double[] doubleArray49 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix50 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray49);
        double[] doubleArray57 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix58 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray57);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair59 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray49, doubleArray57);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix61 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray49, true);
        double[] doubleArray68 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix69 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray68);
        double[] doubleArray76 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix77 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray76);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair78 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray68, doubleArray76);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix80 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray68, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix81 = diagonalMatrix61.add(diagonalMatrix80);
        diagonalMatrix80.multiplyEntry((int) 'a', (-127), (double) 1.0f);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix86 = diagonalMatrix38.multiply(diagonalMatrix80);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix88 = new org.apache.commons.math3.linear.DiagonalMatrix(100);
        try {
            org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix89 = diagonalMatrix80.subtract(diagonalMatrix88);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 6x6 but expected 100x100");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(diagonalMatrix38);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(diagonalMatrix81);
        org.junit.Assert.assertNotNull(diagonalMatrix86);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker3 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker(0.0d, (double) (short) 0, (int) (short) 100);
        double double4 = simpleUnivariateValueChecker3.getAbsoluteThreshold();
        org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair8 = new org.apache.commons.math3.optim.univariate.UnivariatePointValuePair(35.0d, 0.0d);
        org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair9 = null;
        try {
            boolean boolean10 = simpleUnivariateValueChecker3.converged(35, univariatePointValuePair8, univariatePointValuePair9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6, true);
        org.apache.commons.math3.linear.RealMatrix realMatrix19 = diagonalMatrix18.transpose();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realMatrix19);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        int int2 = org.apache.commons.math3.util.FastMath.min((int) (byte) 10, 27);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        double double1 = org.apache.commons.math3.util.FastMath.ulp((double) 6);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.881784197001252E-16d + "'", double1 == 8.881784197001252E-16d);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker4 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker((double) ' ', (double) '#');
        org.apache.commons.math3.optim.univariate.BrentOptimizer brentOptimizer5 = new org.apache.commons.math3.optim.univariate.BrentOptimizer((double) 1.0000001f, (double) ' ', (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.univariate.UnivariatePointValuePair>) simpleUnivariateValueChecker4);
        double double6 = brentOptimizer5.getMax();
        int int7 = brentOptimizer5.getEvaluations();
        double double8 = brentOptimizer5.getStartValue();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 100, (int) (byte) 10);
        org.apache.commons.math3.linear.RealVector realVector4 = blockRealMatrix2.getRowVector(0);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = blockRealMatrix2.getSubMatrix(50, (int) (short) 10, 0, 243);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooSmallException; message: initial row 50 after final row 10");
        } catch (org.apache.commons.math3.exception.NumberIsTooSmallException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector2.addToEntry(0, (double) 1.0f);
        double[] doubleArray12 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray12);
        double[][] doubleArray14 = array2DRowRealMatrix13.getData();
        double[][] doubleArray15 = array2DRowRealMatrix13.getData();
        double[] doubleArray22 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix23 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray22);
        double double24 = array2DRowRealMatrix23.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix13, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix23);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector29.addToEntry(0, (double) 1.0f);
        arrayRealVector29.unitize();
        array2DRowRealMatrix13.setRowVector(0, (org.apache.commons.math3.linear.RealVector) arrayRealVector29);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = arrayRealVector2.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector29);
        double[] doubleArray36 = arrayRealVector29.toArray();
        org.apache.commons.math3.linear.RealVector realVector38 = arrayRealVector29.mapMultiplyToSelf(1.0E-15d);
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor39 = null;
        try {
            double double40 = arrayRealVector29.walkInOptimizedOrder(realVectorChangingVisitor39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 61.886993787063204d + "'", double24 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(arrayRealVector35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(realVector38);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        int[] intArray1 = new int[] { (byte) 100 };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister2 = new org.apache.commons.math3.random.MersenneTwister(intArray1);
        mersenneTwister2.clear();
        int int5 = mersenneTwister2.nextInt((int) 'a');
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 61 + "'", int5 == 61);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        double double1 = org.apache.commons.math3.util.FastMath.asinh((double) 2147483647);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22.180709777452588d + "'", double1 == 22.180709777452588d);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        java.text.NumberFormat numberFormat6 = org.apache.commons.math3.util.CompositeFormat.getDefaultNumberFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat7 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat6);
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat8 = new org.apache.commons.math3.linear.RealMatrixFormat("", "org.apache.commons.math3.linear.NonSymmetricMatrixException: non symmetric matrix: the difference between entries at (1,0) and (0,1) is larger than 0", "", "hi!", "{", "hi!", numberFormat6);
        java.text.NumberFormat numberFormat9 = realMatrixFormat8.getFormat();
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix11 = new org.apache.commons.math3.linear.DiagonalMatrix(100);
        int int12 = diagonalMatrix11.getRowDimension();
        java.lang.String str13 = realMatrixFormat8.format((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix11);
        org.junit.Assert.assertNotNull(numberFormat6);
        org.junit.Assert.assertNotNull(numberFormat9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        double[] doubleArray17 = pointVectorValuePair16.getValue();
        double[] doubleArray18 = pointVectorValuePair16.getPointRef();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray18);
        org.apache.commons.math3.linear.RealVector realVector21 = arrayRealVector19.mapMultiplyToSelf((double) (byte) 1);
        double[] doubleArray29 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix30 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray29);
        double[] doubleArray37 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix38 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray37);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair39 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray29, doubleArray37);
        double[] doubleArray40 = pointVectorValuePair39.getValue();
        org.apache.commons.math3.linear.RealVector realVector41 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray40);
        arrayRealVector19.setSubVector(0, realVector41);
        arrayRealVector19.setEntry((int) (short) 1, (double) 1);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector21);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(realVector41);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math3.random.MersenneTwister(0L);
        int int2 = mersenneTwister1.nextInt();
        mersenneTwister1.setSeed((long) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 647325673 + "'", int2 == 647325673);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        java.text.ParsePosition parsePosition2 = null;
        try {
            boolean boolean3 = org.apache.commons.math3.util.CompositeFormat.parseFixedstring("{1}", "{1}", parsePosition2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        java.text.NumberFormat numberFormat6 = org.apache.commons.math3.util.CompositeFormat.getDefaultNumberFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat7 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat6);
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat8 = new org.apache.commons.math3.linear.RealMatrixFormat("", "org.apache.commons.math3.linear.NonSymmetricMatrixException: non symmetric matrix: the difference between entries at (1,0) and (0,1) is larger than 0", "", "hi!", "{", "hi!", numberFormat6);
        java.text.NumberFormat numberFormat9 = realMatrixFormat8.getFormat();
        java.lang.String str10 = realMatrixFormat8.getRowSuffix();
        org.junit.Assert.assertNotNull(numberFormat6);
        org.junit.Assert.assertNotNull(numberFormat9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.apache.commons.math3.linear.NonSymmetricMatrixException nonSymmetricMatrixException3 = new org.apache.commons.math3.linear.NonSymmetricMatrixException((int) (byte) 1, 0, 1.1102230246251565E-16d);
        int int4 = nonSymmetricMatrixException3.getRow();
        java.lang.String str5 = nonSymmetricMatrixException3.toString();
        double double6 = nonSymmetricMatrixException3.getThreshold();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math3.linear.NonSymmetricMatrixException: non symmetric matrix: the difference between entries at (1,0) and (0,1) is larger than 0" + "'", str5.equals("org.apache.commons.math3.linear.NonSymmetricMatrixException: non symmetric matrix: the difference between entries at (1,0) and (0,1) is larger than 0"));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.1102230246251565E-16d + "'", double6 == 1.1102230246251565E-16d);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer powellOptimizer2 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer((double) (short) 100, (double) (byte) 1);
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType3 = powellOptimizer2.getGoalType();
        double[] doubleArray4 = powellOptimizer2.getUpperBound();
        org.junit.Assert.assertNull(goalType3);
        org.junit.Assert.assertNull(doubleArray4);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker9 = new org.apache.commons.math3.optim.SimpleValueChecker((-135.01712228365548d), 96.0d, 6);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer powellOptimizer10 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer((double) 10L, 2.718281828459045d, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker9);
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer powellOptimizer11 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer((double) (byte) 10, 0.0d, 0.0d, 0.0d, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equals((float) (short) 1, (float) 243);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        double[] doubleArray17 = pointVectorValuePair16.getValue();
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder18 = new org.apache.commons.math3.optim.univariate.BracketFinder();
        int int19 = bracketFinder18.getMaxEvaluations();
        boolean boolean20 = pointVectorValuePair16.equals((java.lang.Object) bracketFinder18);
        double[] doubleArray21 = pointVectorValuePair16.getPoint();
        double[] doubleArray28 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray28);
        double double30 = array2DRowRealMatrix29.getFrobeniusNorm();
        java.lang.String str31 = array2DRowRealMatrix29.toString();
        double[] doubleArray38 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix39 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray38);
        double[] doubleArray46 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix47 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray46);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair48 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray38, doubleArray46);
        double[] doubleArray55 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix56 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray55);
        double[] doubleArray63 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix64 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray63);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair65 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray55, doubleArray63);
        double[] doubleArray66 = pointVectorValuePair65.getFirst();
        double[] doubleArray67 = pointVectorValuePair65.getPointRef();
        double[] doubleArray74 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix75 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray74);
        double[] doubleArray82 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix83 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray82);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair84 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray74, doubleArray82);
        double[] doubleArray85 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray67, doubleArray82);
        double[] doubleArray86 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray46, doubleArray82);
        double[] doubleArray87 = array2DRowRealMatrix29.preMultiply(doubleArray46);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition88 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray21, doubleArray46);
        double double89 = eigenDecomposition88.getDeterminant();
        org.apache.commons.math3.linear.DecompositionSolver decompositionSolver90 = eigenDecomposition88.getSolver();
        org.apache.commons.math3.linear.RealMatrix realMatrix91 = eigenDecomposition88.getVT();
        boolean boolean92 = eigenDecomposition88.hasComplexEigenvalues();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 50 + "'", int19 == 50);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 61.886993787063204d + "'", double30 == 61.886993787063204d);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Array2DRowRealMatrix{{32.0},{0.0},{52.0},{-1.0},{10.0},{-1.0}}" + "'", str31.equals("Array2DRowRealMatrix{{32.0},{0.0},{52.0},{-1.0},{10.0},{-1.0}}"));
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + (-3.104890880000001E8d) + "'", double89 == (-3.104890880000001E8d));
        org.junit.Assert.assertNotNull(decompositionSolver90);
        org.junit.Assert.assertNotNull(realMatrix91);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex2 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex((int) (short) 1, 35.0d);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double double1 = arrayRealVector0.getNorm();
        double[] doubleArray8 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray8);
        double[] doubleArray16 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair18 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray8, doubleArray16);
        double[] doubleArray19 = pointVectorValuePair18.getValue();
        org.apache.commons.math3.linear.RealVector realVector20 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray19);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray19);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(realVector20);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        double double2 = org.apache.commons.math3.util.FastMath.pow((-0.9999999999999999d), (int) (short) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.9999999999999999d) + "'", double2 == (-0.9999999999999999d));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        double[] doubleArray22 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix23 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray22);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair24 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray14, doubleArray22);
        double[] doubleArray25 = pointVectorValuePair24.getFirst();
        double[] doubleArray26 = pointVectorValuePair24.getPointRef();
        double[] doubleArray33 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray33);
        double[] doubleArray41 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix42 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray41);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair43 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray33, doubleArray41);
        double[] doubleArray44 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray26, doubleArray41);
        double[] doubleArray49 = new double[] { (short) 10, 10L, 'a', 0.7650730050315234d };
        org.apache.commons.math3.optim.SimpleBounds simpleBounds50 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray44, doubleArray49);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair52 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray44, false);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight53 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray49);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((float) 99, (float) 6);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        java.text.NumberFormat numberFormat6 = org.apache.commons.math3.util.CompositeFormat.getDefaultNumberFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat7 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat6);
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat8 = new org.apache.commons.math3.linear.RealMatrixFormat("", "org.apache.commons.math3.linear.NonSymmetricMatrixException: non symmetric matrix: the difference between entries at (1,0) and (0,1) is larger than 0", "", "hi!", "{", "hi!", numberFormat6);
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat9 = new org.apache.commons.math3.linear.RealMatrixFormat(numberFormat6);
        java.lang.String str10 = realMatrixFormat9.getRowPrefix();
        org.junit.Assert.assertNotNull(numberFormat6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "{" + "'", str10.equals("{"));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.apache.commons.math3.linear.NonSymmetricMatrixException nonSymmetricMatrixException3 = new org.apache.commons.math3.linear.NonSymmetricMatrixException((-2007483583), (int) (short) 10, (double) 2);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.apache.commons.math3.optim.SimpleBounds simpleBounds1 = org.apache.commons.math3.optim.SimpleBounds.unbounded(127);
        org.junit.Assert.assertNotNull(simpleBounds1);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6, true);
        double[] doubleArray25 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double[] doubleArray33 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray33);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair35 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray25, doubleArray33);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix37 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray25, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix38 = diagonalMatrix18.add(diagonalMatrix37);
        diagonalMatrix38.multiplyEntry(50, (int) '4', (-0.5d));
        double[] doubleArray49 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix50 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray49);
        double[] doubleArray57 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix58 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray57);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair59 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray49, doubleArray57);
        double[] doubleArray60 = pointVectorValuePair59.getValue();
        double[] doubleArray61 = pointVectorValuePair59.getPointRef();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector62 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray61);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector63 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector62);
        double double64 = arrayRealVector63.getMaxValue();
        double[] doubleArray65 = arrayRealVector63.getDataRef();
        double[] doubleArray66 = diagonalMatrix38.operate(doubleArray65);
        double double67 = diagonalMatrix38.getTrace();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(diagonalMatrix38);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 52.0d + "'", double64 == 52.0d);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 184.0d + "'", double67 == 184.0d);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        int[] intArray1 = new int[] { (byte) 100 };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister2 = new org.apache.commons.math3.random.MersenneTwister(intArray1);
        int int3 = mersenneTwister2.nextInt();
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 625644691 + "'", int3 == 625644691);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.apache.commons.math3.optim.SimpleVectorValueChecker simpleVectorValueChecker3 = new org.apache.commons.math3.optim.SimpleVectorValueChecker(0.7615942060206032d, (double) 2147483647, 36);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6, true);
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray6, (double) 2147483647);
        double[] doubleArray21 = pointValuePair20.getPointRef();
        double[] doubleArray22 = pointValuePair20.getPointRef();
        double[] doubleArray23 = pointValuePair20.getPointRef();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector29.addToEntry(0, (double) 1.0f);
        double[] doubleArray39 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix40 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray39);
        double[][] doubleArray41 = array2DRowRealMatrix40.getData();
        double[][] doubleArray42 = array2DRowRealMatrix40.getData();
        double[] doubleArray49 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix50 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray49);
        double double51 = array2DRowRealMatrix50.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix40, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix50);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector56 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector56.addToEntry(0, (double) 1.0f);
        arrayRealVector56.unitize();
        array2DRowRealMatrix40.setRowVector(0, (org.apache.commons.math3.linear.RealVector) arrayRealVector56);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector62 = arrayRealVector29.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector56);
        double double63 = arrayRealVector26.cosine((org.apache.commons.math3.linear.RealVector) arrayRealVector62);
        double[] doubleArray70 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix71 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray70);
        double[] doubleArray78 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix79 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray78);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair80 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray70, doubleArray78);
        double[] doubleArray81 = pointVectorValuePair80.getValue();
        double[] doubleArray82 = pointVectorValuePair80.getPointRef();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector83 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray82);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector84 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector83);
        double double85 = arrayRealVector84.getMaxValue();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector86 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector62, arrayRealVector84);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector88 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector86, true);
        boolean boolean89 = pointValuePair20.equals((java.lang.Object) arrayRealVector88);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 61.886993787063204d + "'", double51 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(arrayRealVector62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 1.0d + "'", double63 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 52.0d + "'", double85 == 52.0d);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.apache.commons.math3.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math3.exception.NoBracketingException((double) 6.473257E8f, (double) 29, (double) 35, (-0.7249165551445564d));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector2.addToEntry(0, (double) 1.0f);
        int int6 = arrayRealVector2.getMaxIndex();
        arrayRealVector2.unitize();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[][] doubleArray8 = array2DRowRealMatrix7.getData();
        double[] doubleArray15 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor17 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double18 = array2DRowRealMatrix16.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor17);
        double double19 = array2DRowRealMatrix7.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor17);
        defaultRealMatrixPreservingVisitor17.start((int) (byte) -1, 0, 986830553, 50, 0, 0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector2.addToEntry(0, (double) 1.0f);
        double[] doubleArray12 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray12);
        double[][] doubleArray14 = array2DRowRealMatrix13.getData();
        double[][] doubleArray15 = array2DRowRealMatrix13.getData();
        double[] doubleArray22 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix23 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray22);
        double double24 = array2DRowRealMatrix23.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix13, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix23);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector29.addToEntry(0, (double) 1.0f);
        arrayRealVector29.unitize();
        array2DRowRealMatrix13.setRowVector(0, (org.apache.commons.math3.linear.RealVector) arrayRealVector29);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = arrayRealVector2.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector29);
        int int36 = arrayRealVector29.getMaxIndex();
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 61.886993787063204d + "'", double24 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(arrayRealVector35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.apache.commons.math3.linear.RealMatrix realMatrix0 = null;
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix2 = org.apache.commons.math3.linear.MatrixUtils.blockInverse(realMatrix0, 1079508992);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.append((double) 0.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector7.addToEntry(0, (double) 1.0f);
        double[] doubleArray17 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray17);
        double[][] doubleArray19 = array2DRowRealMatrix18.getData();
        double[][] doubleArray20 = array2DRowRealMatrix18.getData();
        double[] doubleArray27 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray27);
        double double29 = array2DRowRealMatrix28.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix18, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix28);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector34.addToEntry(0, (double) 1.0f);
        arrayRealVector34.unitize();
        array2DRowRealMatrix18.setRowVector(0, (org.apache.commons.math3.linear.RealVector) arrayRealVector34);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = arrayRealVector7.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector34);
        double[] doubleArray41 = arrayRealVector34.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, doubleArray41);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, false);
        double[] doubleArray51 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix52 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray51);
        double[] doubleArray59 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix60 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray59);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair61 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray51, doubleArray59);
        double[] doubleArray62 = pointVectorValuePair61.getValue();
        double[] doubleArray63 = pointVectorValuePair61.getPointRef();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector64 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray63);
        org.apache.commons.math3.linear.RealVector realVector66 = arrayRealVector64.mapMultiplyToSelf((double) (byte) 1);
        double[] doubleArray74 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix75 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray74);
        double[] doubleArray82 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix83 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray82);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair84 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray74, doubleArray82);
        double[] doubleArray85 = pointVectorValuePair84.getValue();
        org.apache.commons.math3.linear.RealVector realVector86 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray85);
        arrayRealVector64.setSubVector(0, realVector86);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector88 = arrayRealVector2.subtract(realVector86);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 6");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 61.886993787063204d + "'", double29 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(arrayRealVector40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(realVector66);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertNotNull(realVector86);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        int int2 = org.apache.commons.math3.util.FastMath.min(0, 986830553);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        double[] doubleArray17 = pointVectorValuePair16.getValue();
        double[] doubleArray18 = pointVectorValuePair16.getPointRef();
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix19 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray18);
        double[] doubleArray26 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix27 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray26);
        double[] doubleArray34 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix35 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray34);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair36 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray26, doubleArray34);
        org.apache.commons.math3.optim.InitialGuess initialGuess37 = new org.apache.commons.math3.optim.InitialGuess(doubleArray26);
        double[] doubleArray38 = initialGuess37.getInitialGuess();
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix39 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray38);
        double[] doubleArray46 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix47 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray46);
        double[] doubleArray54 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix55 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray54);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair56 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray46, doubleArray54);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix58 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray46, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix59 = diagonalMatrix39.multiply(diagonalMatrix58);
        org.apache.commons.math3.linear.RealMatrix realMatrix60 = diagonalMatrix19.multiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix39);
        diagonalMatrix39.addToEntry((-127), 1079508992, 0.0d);
        org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math3.linear.AnyMatrix) diagonalMatrix39, 0);
        double[] doubleArray74 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix75 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray74);
        double[] doubleArray82 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix83 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray82);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair84 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray74, doubleArray82);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix86 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray74, true);
        org.apache.commons.math3.optim.PointValuePair pointValuePair88 = new org.apache.commons.math3.optim.PointValuePair(doubleArray74, (double) 2147483647);
        double[] doubleArray89 = pointValuePair88.getPointRef();
        try {
            diagonalMatrix39.setRow(35, doubleArray89);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(diagonalMatrix59);
        org.junit.Assert.assertNotNull(realMatrix60);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray89);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        double[] doubleArray1 = null;
        try {
            org.apache.commons.math3.util.MathArrays.scaleInPlace((-1.0728086555169287d), doubleArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math3.exception.DimensionMismatchException(1, (-127));
        java.lang.String str3 = dimensionMismatchException2.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.apache.commons.math3.exception.DimensionMismatchException: 1 != -127" + "'", str3.equals("org.apache.commons.math3.exception.DimensionMismatchException: 1 != -127"));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker5 = new org.apache.commons.math3.optim.SimpleValueChecker((-135.01712228365548d), 96.0d, 6);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer powellOptimizer6 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer((double) 10L, 2.718281828459045d, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker5);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer simplexOptimizer7 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer((org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker5);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 100, (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.scalarAdd(0.0d);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.RealVector realVector8 = blockRealMatrix6.getRowVector(0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(realVector8);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        double[] doubleArray17 = pointVectorValuePair16.getValue();
        org.apache.commons.math3.linear.RealVector realVector18 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray17);
        double[] doubleArray25 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double[] doubleArray33 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray33);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair35 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray25, doubleArray33);
        double[] doubleArray36 = pointVectorValuePair35.getValue();
        org.apache.commons.math3.linear.RealVector realVector37 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray36);
        org.apache.commons.math3.linear.RealVector realVector38 = realVector18.projection(realVector37);
        int int39 = realVector37.getMinIndex();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector42.addToEntry(0, (double) 1.0f);
        double[] doubleArray52 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix53 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray52);
        double[][] doubleArray54 = array2DRowRealMatrix53.getData();
        double[][] doubleArray55 = array2DRowRealMatrix53.getData();
        double[] doubleArray62 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix63 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray62);
        double double64 = array2DRowRealMatrix63.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix53, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix63);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector69 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector69.addToEntry(0, (double) 1.0f);
        arrayRealVector69.unitize();
        array2DRowRealMatrix53.setRowVector(0, (org.apache.commons.math3.linear.RealVector) arrayRealVector69);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector75 = arrayRealVector42.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector69);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector76 = new org.apache.commons.math3.linear.ArrayRealVector(realVector37, arrayRealVector69);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector77 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector76);
        org.apache.commons.math3.analysis.function.Sinc sinc78 = new org.apache.commons.math3.analysis.function.Sinc();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector79 = arrayRealVector76.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc78);
        org.apache.commons.math3.linear.RealVector realVector80 = null;
        try {
            double double81 = arrayRealVector79.getLInfDistance(realVector80);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(realVector37);
        org.junit.Assert.assertNotNull(realVector38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 5 + "'", int39 == 5);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 61.886993787063204d + "'", double64 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(arrayRealVector75);
        org.junit.Assert.assertNotNull(arrayRealVector79);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[][] doubleArray8 = array2DRowRealMatrix7.getData();
        double[][] doubleArray9 = array2DRowRealMatrix7.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray9);
        try {
            array2DRowRealMatrix10.multiplyEntry(50, 52, (double) 9L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (50)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder0 = new org.apache.commons.math3.optim.univariate.BracketFinder();
        int int1 = bracketFinder0.getEvaluations();
        double double2 = bracketFinder0.getFHi();
        int int3 = bracketFinder0.getEvaluations();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        byte byte2 = org.apache.commons.math3.util.MathUtils.copySign((byte) 0, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        int[] intArray6 = new int[] { (byte) 100 };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister7 = new org.apache.commons.math3.random.MersenneTwister(intArray6);
        double double8 = mersenneTwister7.nextGaussian();
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker10 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer11 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer((int) 'a', (double) 10, true, (int) (short) -1, 0, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister7, false, pointValuePairConvergenceChecker10);
        java.util.List<org.apache.commons.math3.linear.RealMatrix> realMatrixList12 = cMAESOptimizer11.getStatisticsDHistory();
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.7650730050315234d + "'", double8 == 0.7650730050315234d);
        org.junit.Assert.assertNotNull(realMatrixList12);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker5 = new org.apache.commons.math3.optim.SimpleValueChecker((-135.01712228365548d), 96.0d, 6);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer simplexOptimizer6 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer((org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker5);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer powellOptimizer7 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer(9.0d, (double) 9.536743E-7f, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker5);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        double[] doubleArray7 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        double[] doubleArray15 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair17 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray7, doubleArray15);
        double[] doubleArray24 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray24);
        double double26 = array2DRowRealMatrix25.getFrobeniusNorm();
        java.lang.String str27 = array2DRowRealMatrix25.toString();
        double[] doubleArray34 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix35 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray34);
        double[] doubleArray42 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix43 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray42);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair44 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray34, doubleArray42);
        double[] doubleArray51 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix52 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray51);
        double[] doubleArray59 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix60 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray59);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair61 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray51, doubleArray59);
        double[] doubleArray62 = pointVectorValuePair61.getFirst();
        double[] doubleArray63 = pointVectorValuePair61.getPointRef();
        double[] doubleArray70 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix71 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray70);
        double[] doubleArray78 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix79 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray78);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair80 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray70, doubleArray78);
        double[] doubleArray81 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray63, doubleArray78);
        double[] doubleArray82 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray42, doubleArray78);
        double[] doubleArray83 = array2DRowRealMatrix25.preMultiply(doubleArray42);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair84 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray7, doubleArray42);
        double[] doubleArray85 = org.apache.commons.math3.util.MathArrays.scale((double) 1085139999, doubleArray7);
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma86 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray7);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException; message: -1 is smaller than the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 61.886993787063204d + "'", double26 == 61.886993787063204d);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Array2DRowRealMatrix{{32.0},{0.0},{52.0},{-1.0},{10.0},{-1.0}}" + "'", str27.equals("Array2DRowRealMatrix{{32.0},{0.0},{52.0},{-1.0},{10.0},{-1.0}}"));
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertNotNull(doubleArray85);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        double double0 = org.apache.commons.math3.util.MathUtils.TWO_PI;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 6.283185307179586d + "'", double0 == 6.283185307179586d);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        try {
            float float3 = org.apache.commons.math3.util.Precision.round((float) 1079508992, (int) (short) -1, 50);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: invalid rounding method 50, valid methods: ROUND_CEILING (2), ROUND_DOWN (1), ROUND_FLOOR (3), ROUND_HALF_DOWN (5), ROUND_HALF_EVEN (6), ROUND_HALF_UP (4), ROUND_UNNECESSARY (7), ROUND_UP (0)");
        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
        }
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        float float2 = org.apache.commons.math3.util.FastMath.min((float) 32, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        double[] doubleArray17 = pointVectorValuePair16.getValue();
        double[] doubleArray24 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray24);
        double[] doubleArray32 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray32);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair34 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray24, doubleArray32);
        double[] doubleArray35 = pointVectorValuePair34.getFirst();
        double[] doubleArray36 = pointVectorValuePair34.getPointRef();
        double[] doubleArray43 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix44 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray43);
        double[] doubleArray51 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix52 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray51);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair53 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray43, doubleArray51);
        double[] doubleArray54 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray36, doubleArray51);
        double[] doubleArray59 = new double[] { (short) 10, 10L, 'a', 0.7650730050315234d };
        org.apache.commons.math3.optim.SimpleBounds simpleBounds60 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray54, doubleArray59);
        double[] doubleArray61 = simpleBounds60.getUpper();
        try {
            double[] doubleArray62 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray17, doubleArray61);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 6 != 4");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray61);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.apache.commons.math3.optim.SimpleVectorValueChecker simpleVectorValueChecker2 = new org.apache.commons.math3.optim.SimpleVectorValueChecker(Double.NEGATIVE_INFINITY, 0.7615942060206032d);
        double double3 = simpleVectorValueChecker2.getAbsoluteThreshold();
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer gaussNewtonOptimizer4 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer((org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair>) simpleVectorValueChecker2);
        double double5 = simpleVectorValueChecker2.getRelativeThreshold();
        double double6 = simpleVectorValueChecker2.getAbsoluteThreshold();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.7615942060206032d + "'", double3 == 0.7615942060206032d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.NEGATIVE_INFINITY + "'", double5 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.7615942060206032d + "'", double6 == 0.7615942060206032d);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        try {
            org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder2 = new org.apache.commons.math3.optim.univariate.BracketFinder((double) 0, 99);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double double8 = array2DRowRealMatrix7.getFrobeniusNorm();
        java.lang.String str9 = array2DRowRealMatrix7.toString();
        double[] doubleArray16 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16);
        double[] doubleArray24 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray24);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair26 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray16, doubleArray24);
        double[] doubleArray33 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray33);
        double[] doubleArray41 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix42 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray41);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair43 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray33, doubleArray41);
        double[] doubleArray44 = pointVectorValuePair43.getFirst();
        double[] doubleArray45 = pointVectorValuePair43.getPointRef();
        double[] doubleArray52 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix53 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray52);
        double[] doubleArray60 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix61 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray60);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair62 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray52, doubleArray60);
        double[] doubleArray63 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray45, doubleArray60);
        double[] doubleArray64 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray24, doubleArray60);
        double[] doubleArray65 = array2DRowRealMatrix7.preMultiply(doubleArray24);
        double[] doubleArray72 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix73 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray72);
        double[] doubleArray80 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix81 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray80);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair82 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray72, doubleArray80);
        org.apache.commons.math3.optim.InitialGuess initialGuess83 = new org.apache.commons.math3.optim.InitialGuess(doubleArray72);
        org.apache.commons.math3.optim.InitialGuess initialGuess84 = new org.apache.commons.math3.optim.InitialGuess(doubleArray72);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition86 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray65, doubleArray72, 2.2250738585072014E-308d);
        double double87 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 61.886993787063204d + "'", double8 == 61.886993787063204d);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Array2DRowRealMatrix{{32.0},{0.0},{52.0},{-1.0},{10.0},{-1.0}}" + "'", str9.equals("Array2DRowRealMatrix{{32.0},{0.0},{52.0},{-1.0},{10.0},{-1.0}}"));
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 3830.0d + "'", double87 == 3830.0d);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray5 = null;
        org.apache.commons.math3.exception.NoBracketingException noBracketingException6 = new org.apache.commons.math3.exception.NoBracketingException(localizable0, (double) 96L, Double.NaN, (double) (byte) 0, 0.0d, objArray5);
        double double7 = noBracketingException6.getHi();
        double double8 = noBracketingException6.getFHi();
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        java.text.NumberFormat numberFormat6 = org.apache.commons.math3.util.CompositeFormat.getDefaultNumberFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat7 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat6);
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat8 = new org.apache.commons.math3.linear.RealMatrixFormat("", "org.apache.commons.math3.linear.NonSymmetricMatrixException: non symmetric matrix: the difference between entries at (1,0) and (0,1) is larger than 0", "", "hi!", "{", "hi!", numberFormat6);
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat9 = new org.apache.commons.math3.linear.RealMatrixFormat(numberFormat6);
        java.text.ParsePosition parsePosition11 = null;
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix12 = realMatrixFormat9.parse("", parsePosition11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat6);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        org.apache.commons.math3.optim.InitialGuess initialGuess17 = new org.apache.commons.math3.optim.InitialGuess(doubleArray6);
        org.apache.commons.math3.optim.InitialGuess initialGuess18 = new org.apache.commons.math3.optim.InitialGuess(doubleArray6);
        org.apache.commons.math3.linear.RealMatrix realMatrix19 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray6);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math3.linear.AnyMatrix) realMatrix19, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realMatrix19);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer3 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer(0.0d, 0.0d, (double) (-2007483583));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 100, (int) (byte) 10);
        double[][] doubleArray4 = blockRealMatrix3.getData();
        double[][] doubleArray5 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray4);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException6 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number) 0.1579223549310333d, (java.lang.Object[]) doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        double[] doubleArray17 = pointVectorValuePair16.getValue();
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder18 = new org.apache.commons.math3.optim.univariate.BracketFinder();
        int int19 = bracketFinder18.getMaxEvaluations();
        boolean boolean20 = pointVectorValuePair16.equals((java.lang.Object) bracketFinder18);
        double[] doubleArray21 = pointVectorValuePair16.getSecond();
        double[] doubleArray22 = pointVectorValuePair16.getSecond();
        org.apache.commons.math3.optim.PointValuePair pointValuePair25 = new org.apache.commons.math3.optim.PointValuePair(doubleArray22, (double) 29, true);
        double[] doubleArray32 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray32);
        double[][] doubleArray34 = array2DRowRealMatrix33.getData();
        try {
            org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray22, doubleArray34);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 6");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 50 + "'", int19 == 50);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder0 = new org.apache.commons.math3.optim.univariate.BracketFinder();
        int int1 = bracketFinder0.getMaxEvaluations();
        double double2 = bracketFinder0.getFMid();
        double double3 = bracketFinder0.getFMid();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 50 + "'", int1 == 50);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 100, (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.scalarAdd(0.0d);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 100, (int) (byte) 10);
        double double10 = blockRealMatrix9.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix12 = blockRealMatrix9.scalarAdd(0.0d);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = blockRealMatrix9.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix14 = blockRealMatrix6.multiply(blockRealMatrix9);
        double double15 = blockRealMatrix14.getNorm();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix12);
        org.junit.Assert.assertNotNull(blockRealMatrix13);
        org.junit.Assert.assertNotNull(blockRealMatrix14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector2.addToEntry(0, (double) 1.0f);
        double[] doubleArray12 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray12);
        double[][] doubleArray14 = array2DRowRealMatrix13.getData();
        double[][] doubleArray15 = array2DRowRealMatrix13.getData();
        double[] doubleArray22 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix23 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray22);
        double double24 = array2DRowRealMatrix23.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix13, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix23);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector29.addToEntry(0, (double) 1.0f);
        arrayRealVector29.unitize();
        array2DRowRealMatrix13.setRowVector(0, (org.apache.commons.math3.linear.RealVector) arrayRealVector29);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = arrayRealVector2.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector29);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        org.apache.commons.math3.linear.RealVector realVector40 = arrayRealVector38.append((double) 0.0f);
        boolean boolean41 = arrayRealVector38.isNaN();
        boolean boolean42 = arrayRealVector38.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        org.apache.commons.math3.linear.RealVector realVector47 = arrayRealVector45.append((double) 0.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector50.addToEntry(0, (double) 1.0f);
        double[] doubleArray60 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix61 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray60);
        double[][] doubleArray62 = array2DRowRealMatrix61.getData();
        double[][] doubleArray63 = array2DRowRealMatrix61.getData();
        double[] doubleArray70 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix71 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray70);
        double double72 = array2DRowRealMatrix71.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix61, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix71);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector77 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector77.addToEntry(0, (double) 1.0f);
        arrayRealVector77.unitize();
        array2DRowRealMatrix61.setRowVector(0, (org.apache.commons.math3.linear.RealVector) arrayRealVector77);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector83 = arrayRealVector50.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector77);
        double[] doubleArray84 = arrayRealVector77.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector85 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector45, doubleArray84);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector87 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector45, false);
        double double88 = arrayRealVector38.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector87);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector89 = arrayRealVector35.add((org.apache.commons.math3.linear.RealVector) arrayRealVector87);
        boolean boolean90 = arrayRealVector87.isNaN();
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 61.886993787063204d + "'", double24 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(arrayRealVector35);
        org.junit.Assert.assertNotNull(realVector40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(realVector47);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 61.886993787063204d + "'", double72 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(arrayRealVector83);
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 0.0d + "'", double88 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector89);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.apache.commons.math3.optim.SimpleVectorValueChecker simpleVectorValueChecker2 = new org.apache.commons.math3.optim.SimpleVectorValueChecker(Double.NEGATIVE_INFINITY, 0.7615942060206032d);
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer3 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer((org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair>) simpleVectorValueChecker2);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6, true);
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray6, (double) 2147483647);
        double[] doubleArray21 = pointValuePair20.getFirst();
        double[] doubleArray28 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray28);
        double[] doubleArray36 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix37 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray36);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair38 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray28, doubleArray36);
        double[] doubleArray39 = pointVectorValuePair38.getValue();
        double[] doubleArray40 = pointVectorValuePair38.getPointRef();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray40);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector41);
        double double43 = arrayRealVector42.getMaxValue();
        double[] doubleArray44 = arrayRealVector42.getDataRef();
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition46 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray21, doubleArray44, 0.0d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 52.0d + "'", double43 == 52.0d);
        org.junit.Assert.assertNotNull(doubleArray44);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        double[] doubleArray17 = pointVectorValuePair16.getFirst();
        double[] doubleArray18 = pointVectorValuePair16.getPointRef();
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException23 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) (short) 100, 100, (int) (byte) -1, (int) (short) 100);
        java.lang.Integer[] intArray24 = matrixDimensionMismatchException23.getWrongDimensions();
        int int26 = matrixDimensionMismatchException23.getExpectedDimension((int) (short) 0);
        int int27 = matrixDimensionMismatchException23.getExpectedRowDimension();
        boolean boolean28 = pointVectorValuePair16.equals((java.lang.Object) int27);
        double[] doubleArray35 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray35);
        double[] doubleArray43 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix44 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray43);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair45 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray35, doubleArray43);
        double[] doubleArray46 = pointVectorValuePair45.getFirst();
        double[] doubleArray47 = pointVectorValuePair45.getPointRef();
        double[] doubleArray54 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix55 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray54);
        double[] doubleArray62 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix63 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray62);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair64 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray54, doubleArray62);
        double[] doubleArray65 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray47, doubleArray62);
        double[] doubleArray70 = new double[] { (short) 10, 10L, 'a', 0.7650730050315234d };
        org.apache.commons.math3.optim.SimpleBounds simpleBounds71 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray65, doubleArray70);
        boolean boolean72 = pointVectorValuePair16.equals((java.lang.Object) doubleArray70);
        double[] doubleArray73 = pointVectorValuePair16.getSecond();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(doubleArray73);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        long long2 = org.apache.commons.math3.util.FastMath.max((long) 61, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 61L + "'", long2 == 61L);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker4 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker((double) ' ', (double) '#');
        org.apache.commons.math3.optim.univariate.BrentOptimizer brentOptimizer5 = new org.apache.commons.math3.optim.univariate.BrentOptimizer((double) 1.0000001f, (double) ' ', (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.univariate.UnivariatePointValuePair>) simpleUnivariateValueChecker4);
        double double6 = brentOptimizer5.getMax();
        double double7 = brentOptimizer5.getMin();
        double double8 = brentOptimizer5.getMin();
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType9 = brentOptimizer5.getGoalType();
        int int10 = brentOptimizer5.getMaxEvaluations();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNull(goalType9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver2 = new org.apache.commons.math3.analysis.solvers.BrentSolver((double) 100L, (double) 'a');
        double double3 = brentSolver2.getFunctionValueAccuracy();
        java.lang.Enum<org.apache.commons.math3.optim.nonlinear.scalar.GoalType> goalTypeEnum4 = null;
        org.apache.commons.math3.util.Pair<org.apache.commons.math3.analysis.solvers.BrentSolver, java.lang.Enum<org.apache.commons.math3.optim.nonlinear.scalar.GoalType>> brentSolverPair5 = new org.apache.commons.math3.util.Pair<org.apache.commons.math3.analysis.solvers.BrentSolver, java.lang.Enum<org.apache.commons.math3.optim.nonlinear.scalar.GoalType>>(brentSolver2, goalTypeEnum4);
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder7 = new org.apache.commons.math3.optim.univariate.BracketFinder();
        int int8 = bracketFinder7.getEvaluations();
        double double9 = bracketFinder7.getFLo();
        org.apache.commons.math3.analysis.function.Sinc sinc10 = new org.apache.commons.math3.analysis.function.Sinc();
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType11 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE;
        bracketFinder7.search((org.apache.commons.math3.analysis.UnivariateFunction) sinc10, goalType11, 0.9835877454343449d, 0.0d);
        try {
            double double18 = brentSolver2.solve((int) '#', (org.apache.commons.math3.analysis.UnivariateFunction) sinc10, (double) Float.NaN, (double) (-127), (-1.0665888468632587E-7d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [-0, -127]");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E-15d + "'", double3 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + goalType11 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE + "'", goalType11.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 100, (int) (byte) 10);
        double[][] doubleArray3 = blockRealMatrix2.getData();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor4 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double5 = blockRealMatrix2.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor4);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 0.7615942060206032d, (java.lang.Number) (-135.01712228365548d), (int) (byte) -1);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6, true);
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray6, (double) 2147483647);
        double[] doubleArray21 = pointValuePair20.getFirst();
        double[] doubleArray22 = pointValuePair20.getFirst();
        double[] doubleArray29 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix30 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray29);
        double[][] doubleArray31 = array2DRowRealMatrix30.getData();
        double[][] doubleArray32 = array2DRowRealMatrix30.getData();
        double[] doubleArray39 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix40 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray39);
        double[] doubleArray47 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix48 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray47);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair49 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray39, doubleArray47);
        double[] doubleArray50 = pointVectorValuePair49.getFirst();
        double[] doubleArray51 = array2DRowRealMatrix30.preMultiply(doubleArray50);
        org.apache.commons.math3.util.Pair<double[], double[]> doubleArrayPair52 = new org.apache.commons.math3.util.Pair<double[], double[]>(doubleArray22, doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray51);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 100, (int) (byte) 10);
        org.apache.commons.math3.linear.RealVector realVector4 = blockRealMatrix2.getRowVector(0);
        org.apache.commons.math3.exception.util.Localizable localizable5 = null;
        double[] doubleArray12 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray12);
        double[][] doubleArray14 = array2DRowRealMatrix13.getData();
        double[][] doubleArray15 = array2DRowRealMatrix13.getData();
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException16 = new org.apache.commons.math3.exception.NullArgumentException(localizable5, (java.lang.Object[]) doubleArray15);
        try {
            blockRealMatrix2.setSubMatrix(doubleArray15, 52, 2147483647);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (2,147,483,647)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        org.apache.commons.math3.optim.InitialGuess initialGuess17 = new org.apache.commons.math3.optim.InitialGuess(doubleArray6);
        double[] doubleArray18 = initialGuess17.getInitialGuess();
        org.apache.commons.math3.optim.PointValuePair pointValuePair21 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, 84.0d, false);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray18);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        double[] doubleArray17 = pointVectorValuePair16.getFirst();
        double[] doubleArray18 = pointVectorValuePair16.getPointRef();
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException23 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) (short) 100, 100, (int) (byte) -1, (int) (short) 100);
        java.lang.Integer[] intArray24 = matrixDimensionMismatchException23.getWrongDimensions();
        int int26 = matrixDimensionMismatchException23.getExpectedDimension((int) (short) 0);
        int int27 = matrixDimensionMismatchException23.getExpectedRowDimension();
        boolean boolean28 = pointVectorValuePair16.equals((java.lang.Object) int27);
        double[] doubleArray35 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray35);
        double[] doubleArray43 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix44 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray43);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair45 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray35, doubleArray43);
        double[] doubleArray46 = pointVectorValuePair45.getFirst();
        double[] doubleArray47 = pointVectorValuePair45.getPointRef();
        double[] doubleArray54 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix55 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray54);
        double[] doubleArray62 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix63 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray62);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair64 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray54, doubleArray62);
        double[] doubleArray65 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray47, doubleArray62);
        double[] doubleArray70 = new double[] { (short) 10, 10L, 'a', 0.7650730050315234d };
        org.apache.commons.math3.optim.SimpleBounds simpleBounds71 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray65, doubleArray70);
        boolean boolean72 = pointVectorValuePair16.equals((java.lang.Object) doubleArray70);
        double[] doubleArray73 = pointVectorValuePair16.getValue();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(doubleArray73);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        double[] doubleArray0 = null;
        double[] doubleArray7 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        double[] doubleArray15 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair17 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray7, doubleArray15);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix19 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray7, true);
        double[] doubleArray26 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix27 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray26);
        double[] doubleArray34 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix35 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray34);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair36 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray26, doubleArray34);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix38 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray26, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix39 = diagonalMatrix19.add(diagonalMatrix38);
        double[] doubleArray40 = diagonalMatrix19.getDataRef();
        try {
            double[] doubleArray41 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray0, doubleArray40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(diagonalMatrix39);
        org.junit.Assert.assertNotNull(doubleArray40);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 100, (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.scalarAdd(0.0d);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 100, (int) (byte) 10);
        double double10 = blockRealMatrix9.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix12 = blockRealMatrix9.scalarAdd(0.0d);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = blockRealMatrix9.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix14 = blockRealMatrix6.multiply(blockRealMatrix9);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor15 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        defaultRealMatrixPreservingVisitor15.visit(0, (int) (short) 0, (double) '#');
        double double20 = blockRealMatrix6.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor15);
        org.apache.commons.math3.linear.RealVector realVector22 = blockRealMatrix6.getColumnVector((int) 'a');
        double[] doubleArray24 = new double[] {};
        double[] doubleArray31 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray31);
        double[][] doubleArray33 = array2DRowRealMatrix32.getData();
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray24, doubleArray33);
        try {
            blockRealMatrix6.setColumn((int) (short) 0, doubleArray24);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 0x1 but expected 10x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix12);
        org.junit.Assert.assertNotNull(blockRealMatrix13);
        org.junit.Assert.assertNotNull(blockRealMatrix14);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals(0.7650730050315234d, (double) (-1L), (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.IdentityPreconditioner identityPreconditioner0 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.IdentityPreconditioner();
        double[] doubleArray3 = new double[] { 17761.69164905552d, 326.4732303786673d };
        double[] doubleArray4 = null;
        try {
            double[] doubleArray5 = identityPreconditioner0.precondition(doubleArray3, doubleArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        try {
            org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) (byte) 0, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker4 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker((double) ' ', (double) '#');
        org.apache.commons.math3.optim.univariate.BrentOptimizer brentOptimizer5 = new org.apache.commons.math3.optim.univariate.BrentOptimizer((double) 1.0000001f, (double) ' ', (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.univariate.UnivariatePointValuePair>) simpleUnivariateValueChecker4);
        double double6 = brentOptimizer5.getMax();
        int int7 = brentOptimizer5.getMaxIterations();
        int int8 = brentOptimizer5.getEvaluations();
        int int9 = brentOptimizer5.getMaxEvaluations();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2147483647 + "'", int7 == 2147483647);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.apache.commons.math3.linear.NonSquareMatrixException nonSquareMatrixException2 = new org.apache.commons.math3.linear.NonSquareMatrixException(0, (int) 'a');
        int int3 = nonSquareMatrixException2.getDimension();
        int int4 = nonSquareMatrixException2.getDimension();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 97 + "'", int3 == 97);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 97 + "'", int4 == 97);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 52, (java.lang.Number) 2.718281828459045d, (int) '#');
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.verifyInterval((double) 10.0f, (double) 2147483647);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 100.0f, (java.lang.Number) 1.0d, false);
        boolean boolean5 = numberIsTooLargeException4.getBoundIsAllowed();
        boolean boolean6 = numberIsTooLargeException4.getBoundIsAllowed();
        java.lang.Number number7 = numberIsTooLargeException4.getMax();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 1.0d + "'", number7.equals(1.0d));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[][] doubleArray8 = array2DRowRealMatrix7.getData();
        double[][] doubleArray9 = array2DRowRealMatrix7.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray9);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkRowIndex((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix10, 243);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (243)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        float float2 = org.apache.commons.math3.util.FastMath.nextAfter((float) 84L, (double) 97.00001f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 84.00001f + "'", float2 == 84.00001f);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        double[] doubleArray17 = pointVectorValuePair16.getValue();
        double[] doubleArray18 = pointVectorValuePair16.getPointRef();
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix19 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray18);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector22.addToEntry(0, (double) 1.0f);
        double[] doubleArray32 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray32);
        double[][] doubleArray34 = array2DRowRealMatrix33.getData();
        double[][] doubleArray35 = array2DRowRealMatrix33.getData();
        double[] doubleArray42 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix43 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray42);
        double double44 = array2DRowRealMatrix43.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix33, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix43);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector49.addToEntry(0, (double) 1.0f);
        arrayRealVector49.unitize();
        array2DRowRealMatrix33.setRowVector(0, (org.apache.commons.math3.linear.RealVector) arrayRealVector49);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector55 = arrayRealVector22.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector49);
        boolean boolean56 = diagonalMatrix19.equals((java.lang.Object) arrayRealVector55);
        double[] doubleArray63 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix64 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray63);
        double[] doubleArray71 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix72 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray71);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair73 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray63, doubleArray71);
        double[] doubleArray74 = pointVectorValuePair73.getValue();
        double[] doubleArray75 = pointVectorValuePair73.getPointRef();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector78 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector79 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray75, arrayRealVector78);
        try {
            org.apache.commons.math3.linear.MatrixUtils.solveLowerTriangularSystem((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix19, (org.apache.commons.math3.linear.RealVector) arrayRealVector79);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 6 != 7");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 61.886993787063204d + "'", double44 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(arrayRealVector55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray75);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder0 = new org.apache.commons.math3.optim.univariate.BracketFinder();
        int int1 = bracketFinder0.getMaxEvaluations();
        double double2 = bracketFinder0.getFMid();
        double double3 = bracketFinder0.getLo();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 50 + "'", int1 == 50);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        float[] floatArray4 = new float[] { ' ', (byte) 1, 10.0f, 97.00001f };
        float[] floatArray10 = new float[] { (short) 0, 36, (short) 10, (short) -1, 1079508992 };
        boolean boolean11 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(floatArray4, floatArray10);
        float[] floatArray14 = new float[] { 50, 1.0000001f };
        boolean boolean15 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(floatArray4, floatArray14);
        float[] floatArray20 = new float[] { ' ', (byte) 1, 10.0f, 97.00001f };
        float[] floatArray26 = new float[] { (short) 0, 36, (short) 10, (short) -1, 1079508992 };
        boolean boolean27 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(floatArray20, floatArray26);
        float[] floatArray30 = new float[] { 50, 1.0000001f };
        boolean boolean31 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(floatArray20, floatArray30);
        boolean boolean32 = org.apache.commons.math3.util.MathArrays.equals(floatArray14, floatArray30);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        long long2 = org.apache.commons.math3.util.MathUtils.copySign((long) (byte) 1, (long) 35);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) (short) 100, 100, (int) (byte) -1, (int) (short) 100);
        java.lang.Integer[] intArray5 = matrixDimensionMismatchException4.getWrongDimensions();
        int int6 = matrixDimensionMismatchException4.getExpectedColumnDimension();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext7 = matrixDimensionMismatchException4.getContext();
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertNotNull(exceptionContext7);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker6 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker((double) ' ', (double) '#');
        org.apache.commons.math3.optim.univariate.BrentOptimizer brentOptimizer7 = new org.apache.commons.math3.optim.univariate.BrentOptimizer((double) 1.0000001f, (double) ' ', (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.univariate.UnivariatePointValuePair>) simpleUnivariateValueChecker6);
        double double8 = simpleUnivariateValueChecker6.getAbsoluteThreshold();
        try {
            org.apache.commons.math3.optim.univariate.BrentOptimizer brentOptimizer9 = new org.apache.commons.math3.optim.univariate.BrentOptimizer((double) (short) 1, (double) (-127), (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.univariate.UnivariatePointValuePair>) simpleUnivariateValueChecker6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -127 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 35.0d + "'", double8 == 35.0d);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        int int1 = org.apache.commons.math3.util.FastMath.round(97.00001f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 97 + "'", int1 == 97);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        double[] doubleArray17 = pointVectorValuePair16.getValue();
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder18 = new org.apache.commons.math3.optim.univariate.BracketFinder();
        int int19 = bracketFinder18.getMaxEvaluations();
        boolean boolean20 = pointVectorValuePair16.equals((java.lang.Object) bracketFinder18);
        double[] doubleArray21 = pointVectorValuePair16.getPoint();
        double[] doubleArray28 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray28);
        double double30 = array2DRowRealMatrix29.getFrobeniusNorm();
        java.lang.String str31 = array2DRowRealMatrix29.toString();
        double[] doubleArray38 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix39 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray38);
        double[] doubleArray46 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix47 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray46);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair48 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray38, doubleArray46);
        double[] doubleArray55 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix56 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray55);
        double[] doubleArray63 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix64 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray63);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair65 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray55, doubleArray63);
        double[] doubleArray66 = pointVectorValuePair65.getFirst();
        double[] doubleArray67 = pointVectorValuePair65.getPointRef();
        double[] doubleArray74 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix75 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray74);
        double[] doubleArray82 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix83 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray82);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair84 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray74, doubleArray82);
        double[] doubleArray85 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray67, doubleArray82);
        double[] doubleArray86 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray46, doubleArray82);
        double[] doubleArray87 = array2DRowRealMatrix29.preMultiply(doubleArray46);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition88 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray21, doubleArray46);
        double[] doubleArray89 = eigenDecomposition88.getImagEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix90 = eigenDecomposition88.getV();
        double[] doubleArray91 = eigenDecomposition88.getImagEigenvalues();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 50 + "'", int19 == 50);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 61.886993787063204d + "'", double30 == 61.886993787063204d);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Array2DRowRealMatrix{{32.0},{0.0},{52.0},{-1.0},{10.0},{-1.0}}" + "'", str31.equals("Array2DRowRealMatrix{{32.0},{0.0},{52.0},{-1.0},{10.0},{-1.0}}"));
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertNotNull(realMatrix90);
        org.junit.Assert.assertNotNull(doubleArray91);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        double[] doubleArray17 = pointVectorValuePair16.getValue();
        double[] doubleArray18 = pointVectorValuePair16.getPointRef();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray18);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector19);
        double double21 = arrayRealVector20.getMaxValue();
        double[] doubleArray22 = arrayRealVector20.getDataRef();
        org.apache.commons.math3.linear.RealVector realVector24 = arrayRealVector20.append(0.7650730050315234d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 52.0d + "'", double21 == 52.0d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(realVector24);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair2 = new org.apache.commons.math3.optim.univariate.UnivariatePointValuePair(0.0d, (double) 1.0f);
        double double3 = univariatePointValuePair2.getPoint();
        double double4 = univariatePointValuePair2.getPoint();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        double[] doubleArray17 = pointVectorValuePair16.getFirst();
        double[] doubleArray18 = pointVectorValuePair16.getPointRef();
        double[] doubleArray19 = pointVectorValuePair16.getFirst();
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker24 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker((double) ' ', (double) '#');
        org.apache.commons.math3.optim.univariate.BrentOptimizer brentOptimizer25 = new org.apache.commons.math3.optim.univariate.BrentOptimizer((double) 1.0000001f, (double) ' ', (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.univariate.UnivariatePointValuePair>) simpleUnivariateValueChecker24);
        double double26 = brentOptimizer25.getMax();
        int int27 = brentOptimizer25.getMaxIterations();
        int int28 = brentOptimizer25.getIterations();
        double double29 = brentOptimizer25.getStartValue();
        boolean boolean30 = pointVectorValuePair16.equals((java.lang.Object) double29);
        double[] doubleArray31 = pointVectorValuePair16.getPoint();
        double[] doubleArray38 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix39 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray38);
        double[] doubleArray46 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix47 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray46);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair48 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray38, doubleArray46);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix50 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray38, true);
        double[] doubleArray57 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix58 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray57);
        double[] doubleArray65 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix66 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray65);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair67 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray57, doubleArray65);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix69 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray57, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix70 = diagonalMatrix50.add(diagonalMatrix69);
        double[] doubleArray71 = diagonalMatrix50.getDataRef();
        double[] doubleArray72 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray31, doubleArray71);
        double[] doubleArray73 = null;
        try {
            org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition75 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray72, doubleArray73, 1.0E-15d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2147483647 + "'", int27 == 2147483647);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(diagonalMatrix70);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray72);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer5 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer((double) (short) -1, (double) 10, (double) (-1L), (double) (byte) -1, 0.0d);
        double[] doubleArray6 = levenbergMarquardtOptimizer5.getLowerBound();
        double double7 = levenbergMarquardtOptimizer5.getChiSquare();
        org.junit.Assert.assertNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        double[] doubleArray17 = pointVectorValuePair16.getFirst();
        double[] doubleArray18 = pointVectorValuePair16.getPointRef();
        double[] doubleArray19 = pointVectorValuePair16.getFirst();
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker24 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker((double) ' ', (double) '#');
        org.apache.commons.math3.optim.univariate.BrentOptimizer brentOptimizer25 = new org.apache.commons.math3.optim.univariate.BrentOptimizer((double) 1.0000001f, (double) ' ', (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.univariate.UnivariatePointValuePair>) simpleUnivariateValueChecker24);
        double double26 = brentOptimizer25.getMax();
        int int27 = brentOptimizer25.getMaxIterations();
        int int28 = brentOptimizer25.getIterations();
        double double29 = brentOptimizer25.getStartValue();
        boolean boolean30 = pointVectorValuePair16.equals((java.lang.Object) double29);
        double[] doubleArray31 = pointVectorValuePair16.getPoint();
        double[][] doubleArray34 = org.apache.commons.math3.linear.BlockRealMatrix.createBlocksLayout((int) (short) -1, (int) (short) 10);
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray31, doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2147483647 + "'", int27 == 2147483647);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray34);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat3 = new org.apache.commons.math3.linear.RealVectorFormat("", "Array2DRowRealMatrix{{32.0},{0.0},{52.0},{-1.0},{10.0},{-1.0}}", "");
        java.text.ParsePosition parsePosition5 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = realVectorFormat3.parse("org.apache.commons.math3.exception.DimensionMismatchException: 1 != -127", parsePosition5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        int int2 = org.apache.commons.math3.util.FastMath.min(0, 97);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.append((double) 0.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector7.addToEntry(0, (double) 1.0f);
        double[] doubleArray17 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray17);
        double[][] doubleArray19 = array2DRowRealMatrix18.getData();
        double[][] doubleArray20 = array2DRowRealMatrix18.getData();
        double[] doubleArray27 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray27);
        double double29 = array2DRowRealMatrix28.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix18, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix28);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector34.addToEntry(0, (double) 1.0f);
        arrayRealVector34.unitize();
        array2DRowRealMatrix18.setRowVector(0, (org.apache.commons.math3.linear.RealVector) arrayRealVector34);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = arrayRealVector7.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector34);
        double[] doubleArray41 = arrayRealVector34.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, doubleArray41);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, false);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector47.addToEntry(0, (double) 1.0f);
        double[] doubleArray57 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix58 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray57);
        double[][] doubleArray59 = array2DRowRealMatrix58.getData();
        double[][] doubleArray60 = array2DRowRealMatrix58.getData();
        double[] doubleArray67 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix68 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray67);
        double double69 = array2DRowRealMatrix68.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix58, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix68);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector74 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector74.addToEntry(0, (double) 1.0f);
        arrayRealVector74.unitize();
        array2DRowRealMatrix58.setRowVector(0, (org.apache.commons.math3.linear.RealVector) arrayRealVector74);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector80 = arrayRealVector47.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector74);
        double double81 = arrayRealVector2.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector47);
        org.apache.commons.math3.linear.RealVector realVector83 = arrayRealVector47.mapAddToSelf(0.7615942060206032d);
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 61.886993787063204d + "'", double29 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(arrayRealVector40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 61.886993787063204d + "'", double69 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(arrayRealVector80);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 110.0d + "'", double81 == 110.0d);
        org.junit.Assert.assertNotNull(realVector83);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException(localizable0, (java.lang.Number) 184.0d, (java.lang.Number) Float.NaN, (java.lang.Number) 0.14566922f);
        java.lang.Number number5 = outOfRangeException4.getHi();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.14566922f + "'", number5.equals(0.14566922f));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double double8 = array2DRowRealMatrix7.getFrobeniusNorm();
        double[] doubleArray15 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        double[][] doubleArray17 = array2DRowRealMatrix16.getData();
        double[][] doubleArray18 = array2DRowRealMatrix16.getData();
        double[] doubleArray25 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double double27 = array2DRowRealMatrix26.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix16, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix26);
        org.apache.commons.math3.linear.RealMatrix realMatrix29 = array2DRowRealMatrix7.add((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix16);
        double[] doubleArray36 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix37 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray36);
        org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) realMatrix29, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix37);
        org.apache.commons.math3.linear.RealVector realVector40 = array2DRowRealMatrix37.getColumnVector(0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 61.886993787063204d + "'", double8 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 61.886993787063204d + "'", double27 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(realVector40);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat1 = org.apache.commons.math3.linear.RealVectorFormat.getInstance();
        java.text.NumberFormat numberFormat2 = realVectorFormat1.getFormat();
        java.text.ParsePosition parsePosition3 = null;
        try {
            java.lang.Number number4 = org.apache.commons.math3.util.CompositeFormat.parseNumber("", numberFormat2, parsePosition3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realVectorFormat1);
        org.junit.Assert.assertNotNull(numberFormat2);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[][] doubleArray8 = array2DRowRealMatrix7.getData();
        double[][] doubleArray9 = array2DRowRealMatrix7.getData();
        double[] doubleArray16 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16);
        double double18 = array2DRowRealMatrix17.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix7, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix17);
        try {
            array2DRowRealMatrix17.setEntry((int) 'a', 243, 100.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (97)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 61.886993787063204d + "'", double18 == 61.886993787063204d);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        double[] doubleArray17 = pointVectorValuePair16.getValue();
        double[] doubleArray18 = pointVectorValuePair16.getPointRef();
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix19 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray18);
        double[] doubleArray26 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix27 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray26);
        double[] doubleArray34 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix35 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray34);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair36 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray26, doubleArray34);
        org.apache.commons.math3.optim.InitialGuess initialGuess37 = new org.apache.commons.math3.optim.InitialGuess(doubleArray26);
        double[] doubleArray38 = initialGuess37.getInitialGuess();
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix39 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray38);
        double[] doubleArray46 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix47 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray46);
        double[] doubleArray54 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix55 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray54);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair56 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray46, doubleArray54);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix58 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray46, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix59 = diagonalMatrix39.multiply(diagonalMatrix58);
        org.apache.commons.math3.linear.RealMatrix realMatrix60 = diagonalMatrix19.multiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix39);
        org.apache.commons.math3.linear.RealVector realVector61 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.solveLowerTriangularSystem((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix19, realVector61);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 6 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(diagonalMatrix59);
        org.junit.Assert.assertNotNull(realMatrix60);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 100, (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.getRowMatrix(29);
        java.lang.String str6 = blockRealMatrix2.toString();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "BlockRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}" + "'", str6.equals("BlockRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}}"));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        double double2 = org.apache.commons.math3.util.FastMath.min((-0.5403023058681397d), (double) 10.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.5403023058681397d) + "'", double2 == (-0.5403023058681397d));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        double[] doubleArray17 = pointVectorValuePair16.getValue();
        org.apache.commons.math3.linear.RealVector realVector18 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray17);
        double[] doubleArray25 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double[] doubleArray33 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray33);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair35 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray25, doubleArray33);
        double[] doubleArray36 = pointVectorValuePair35.getValue();
        org.apache.commons.math3.linear.RealVector realVector37 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray36);
        org.apache.commons.math3.linear.RealVector realVector38 = realVector18.projection(realVector37);
        int int39 = realVector37.getMinIndex();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector42.addToEntry(0, (double) 1.0f);
        double[] doubleArray52 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix53 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray52);
        double[][] doubleArray54 = array2DRowRealMatrix53.getData();
        double[][] doubleArray55 = array2DRowRealMatrix53.getData();
        double[] doubleArray62 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix63 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray62);
        double double64 = array2DRowRealMatrix63.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix53, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix63);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector69 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector69.addToEntry(0, (double) 1.0f);
        arrayRealVector69.unitize();
        array2DRowRealMatrix53.setRowVector(0, (org.apache.commons.math3.linear.RealVector) arrayRealVector69);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector75 = arrayRealVector42.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector69);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector76 = new org.apache.commons.math3.linear.ArrayRealVector(realVector37, arrayRealVector69);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector77 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector76);
        org.apache.commons.math3.analysis.function.Sinc sinc78 = new org.apache.commons.math3.analysis.function.Sinc();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector79 = arrayRealVector76.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc78);
        org.apache.commons.math3.optim.univariate.UnivariateObjectiveFunction univariateObjectiveFunction80 = new org.apache.commons.math3.optim.univariate.UnivariateObjectiveFunction((org.apache.commons.math3.analysis.UnivariateFunction) sinc78);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(realVector37);
        org.junit.Assert.assertNotNull(realVector38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 5 + "'", int39 == 5);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 61.886993787063204d + "'", double64 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(arrayRealVector75);
        org.junit.Assert.assertNotNull(arrayRealVector79);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[][] doubleArray8 = array2DRowRealMatrix7.getData();
        double[] doubleArray15 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        double double17 = array2DRowRealMatrix16.getFrobeniusNorm();
        java.lang.String str18 = array2DRowRealMatrix16.toString();
        org.apache.commons.math3.linear.RealMatrix realMatrix19 = array2DRowRealMatrix7.subtract((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix16);
        double double20 = array2DRowRealMatrix16.getNorm();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor21 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        defaultRealMatrixPreservingVisitor21.visit(0, (int) (short) 0, (double) '#');
        defaultRealMatrixPreservingVisitor21.start((int) (short) 1, 100, 50, 6, 50, 2147483647);
        defaultRealMatrixPreservingVisitor21.visit(5, (int) (short) 0, 127.0d);
        try {
            double double41 = array2DRowRealMatrix16.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor21, 99, 986830553, 45, 45);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (99)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 61.886993787063204d + "'", double17 == 61.886993787063204d);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Array2DRowRealMatrix{{32.0},{0.0},{52.0},{-1.0},{10.0},{-1.0}}" + "'", str18.equals("Array2DRowRealMatrix{{32.0},{0.0},{52.0},{-1.0},{10.0},{-1.0}}"));
        org.junit.Assert.assertNotNull(realMatrix19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 96.0d + "'", double20 == 96.0d);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[][] doubleArray8 = array2DRowRealMatrix7.getData();
        double[][] doubleArray9 = array2DRowRealMatrix7.getData();
        double[] doubleArray16 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16);
        double[] doubleArray24 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray24);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair26 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray16, doubleArray24);
        double[] doubleArray27 = pointVectorValuePair26.getFirst();
        double[] doubleArray28 = pointVectorValuePair26.getPointRef();
        double[] doubleArray35 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray35);
        double[] doubleArray43 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix44 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray43);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair45 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray35, doubleArray43);
        double[] doubleArray46 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray28, doubleArray43);
        double[] doubleArray47 = array2DRowRealMatrix7.preMultiply(doubleArray43);
        org.apache.commons.math3.util.MathArrays.checkPositive(doubleArray47);
        int int49 = org.apache.commons.math3.util.MathUtils.hash(doubleArray47);
        java.io.ObjectInputStream objectInputStream51 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.deserializeRealVector((java.lang.Object) int49, "}", objectInputStream51);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1085139999 + "'", int49 == 1085139999);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat3 = new org.apache.commons.math3.linear.RealVectorFormat("hi!", "hi!", "");
        java.lang.String str4 = realVectorFormat3.getSuffix();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        double[] doubleArray17 = pointVectorValuePair16.getValue();
        double[] doubleArray18 = pointVectorValuePair16.getPointRef();
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix19 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray18);
        org.apache.commons.math3.optim.PointValuePair pointValuePair22 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, 0.0d, true);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        double double1 = org.apache.commons.math3.util.FastMath.exp((-0.9999999999999999d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3678794411714424d + "'", double1 == 0.3678794411714424d);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        org.apache.commons.math3.analysis.MultivariateVectorFunction multivariateVectorFunction0 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.ObjectiveFunctionGradient objectiveFunctionGradient1 = new org.apache.commons.math3.optim.nonlinear.scalar.ObjectiveFunctionGradient(multivariateVectorFunction0);
        org.apache.commons.math3.analysis.MultivariateVectorFunction multivariateVectorFunction2 = objectiveFunctionGradient1.getObjectiveFunctionGradient();
        org.junit.Assert.assertNull(multivariateVectorFunction2);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        double[] doubleArray17 = pointVectorValuePair16.getFirst();
        double[] doubleArray18 = pointVectorValuePair16.getPointRef();
        double[] doubleArray25 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double[] doubleArray33 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray33);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair35 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray25, doubleArray33);
        double[] doubleArray36 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray18, doubleArray33);
        double[] doubleArray41 = new double[] { (short) 10, 10L, 'a', 0.7650730050315234d };
        org.apache.commons.math3.optim.SimpleBounds simpleBounds42 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray36, doubleArray41);
        double[] doubleArray43 = null;
        try {
            double double44 = org.apache.commons.math3.util.MathArrays.distance(doubleArray41, doubleArray43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray41);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector2.addToEntry(0, (double) 1.0f);
        double[] doubleArray12 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray12);
        double[][] doubleArray14 = array2DRowRealMatrix13.getData();
        double[][] doubleArray15 = array2DRowRealMatrix13.getData();
        double[] doubleArray22 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix23 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray22);
        double double24 = array2DRowRealMatrix23.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix13, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix23);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector29.addToEntry(0, (double) 1.0f);
        arrayRealVector29.unitize();
        array2DRowRealMatrix13.setRowVector(0, (org.apache.commons.math3.linear.RealVector) arrayRealVector29);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = arrayRealVector2.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector29);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        org.apache.commons.math3.linear.RealVector realVector40 = arrayRealVector38.append((double) 0.0f);
        boolean boolean41 = arrayRealVector38.isNaN();
        boolean boolean42 = arrayRealVector38.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        org.apache.commons.math3.linear.RealVector realVector47 = arrayRealVector45.append((double) 0.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector50.addToEntry(0, (double) 1.0f);
        double[] doubleArray60 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix61 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray60);
        double[][] doubleArray62 = array2DRowRealMatrix61.getData();
        double[][] doubleArray63 = array2DRowRealMatrix61.getData();
        double[] doubleArray70 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix71 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray70);
        double double72 = array2DRowRealMatrix71.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix61, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix71);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector77 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector77.addToEntry(0, (double) 1.0f);
        arrayRealVector77.unitize();
        array2DRowRealMatrix61.setRowVector(0, (org.apache.commons.math3.linear.RealVector) arrayRealVector77);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector83 = arrayRealVector50.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector77);
        double[] doubleArray84 = arrayRealVector77.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector85 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector45, doubleArray84);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector87 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector45, false);
        double double88 = arrayRealVector38.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector87);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector89 = arrayRealVector35.add((org.apache.commons.math3.linear.RealVector) arrayRealVector87);
        try {
            double double91 = arrayRealVector89.getEntry((-2007483583));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (-2,007,483,583)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 61.886993787063204d + "'", double24 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(arrayRealVector35);
        org.junit.Assert.assertNotNull(realVector40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(realVector47);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 61.886993787063204d + "'", double72 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(arrayRealVector83);
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 0.0d + "'", double88 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector89);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        org.apache.commons.math3.linear.AnyMatrix anyMatrix0 = null;
        int[] intArray2 = new int[] { (byte) 100 };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math3.random.MersenneTwister(intArray2);
        int[] intArray5 = new int[] { (byte) 1 };
        int[] intArray9 = new int[] { (byte) 1, (byte) 100, '4' };
        int[] intArray14 = new int[] { 'a', (short) 1, (byte) 100, 'a' };
        double double15 = org.apache.commons.math3.util.MathArrays.distance(intArray9, intArray14);
        int int16 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray5, intArray14);
        int int17 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray2, intArray5);
        int[] intArray21 = new int[] { (byte) 1, (byte) 100, '4' };
        int[] intArray26 = new int[] { 'a', (short) 1, (byte) 100, 'a' };
        double double27 = org.apache.commons.math3.util.MathArrays.distance(intArray21, intArray26);
        org.apache.commons.math3.random.MersenneTwister mersenneTwister28 = new org.apache.commons.math3.random.MersenneTwister(intArray21);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSubMatrixIndex(anyMatrix0, intArray2, intArray21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 146.01712228365548d + "'", double15 == 146.01712228365548d);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 96 + "'", int16 == 96);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 99 + "'", int17 == 99);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 146.01712228365548d + "'", double27 == 146.01712228365548d);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        java.text.ParsePosition parsePosition1 = null;
        try {
            char char2 = org.apache.commons.math3.util.CompositeFormat.parseNextCharacter(",32052-110-1", parsePosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        java.text.NumberFormat numberFormat0 = org.apache.commons.math3.util.CompositeFormat.getDefaultNumberFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat1 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat0);
        double[] doubleArray8 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray8);
        double[][] doubleArray10 = array2DRowRealMatrix9.getData();
        double[][] doubleArray11 = array2DRowRealMatrix9.getData();
        double[] doubleArray18 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray18);
        double double20 = array2DRowRealMatrix19.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix9, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix19);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector25.addToEntry(0, (double) 1.0f);
        arrayRealVector25.unitize();
        array2DRowRealMatrix9.setRowVector(0, (org.apache.commons.math3.linear.RealVector) arrayRealVector25);
        double double31 = arrayRealVector25.getNorm();
        java.lang.String str32 = realVectorFormat1.format((org.apache.commons.math3.linear.RealVector) arrayRealVector25);
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor33 = null;
        try {
            double double36 = arrayRealVector25.walkInDefaultOrder(realVectorChangingVisitor33, (int) ' ', (-2007483583));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (32)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat0);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 61.886993787063204d + "'", double20 == 61.886993787063204d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 1.0d + "'", double31 == 1.0d);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "{1}" + "'", str32.equals("{1}"));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.MatrixUtils.DEFAULT_FORMAT;
        java.lang.String str1 = realMatrixFormat0.getRowPrefix();
        java.lang.String str2 = realMatrixFormat0.getRowPrefix();
        java.text.NumberFormat numberFormat3 = realMatrixFormat0.getFormat();
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "{" + "'", str1.equals("{"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{" + "'", str2.equals("{"));
        org.junit.Assert.assertNotNull(numberFormat3);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        int[] intArray1 = new int[] { (byte) 100 };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister2 = new org.apache.commons.math3.random.MersenneTwister(intArray1);
        float float3 = mersenneTwister2.nextFloat();
        mersenneTwister2.setSeed(100L);
        double double6 = mersenneTwister2.nextGaussian();
        int[] intArray8 = new int[] { (byte) 100 };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister9 = new org.apache.commons.math3.random.MersenneTwister(intArray8);
        int[] intArray11 = new int[] { (byte) 1 };
        int[] intArray15 = new int[] { (byte) 1, (byte) 100, '4' };
        int[] intArray20 = new int[] { 'a', (short) 1, (byte) 100, 'a' };
        double double21 = org.apache.commons.math3.util.MathArrays.distance(intArray15, intArray20);
        int int22 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray11, intArray20);
        int int23 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray8, intArray11);
        mersenneTwister2.setSeed(intArray8);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.14566922f + "'", float3 == 0.14566922f);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.9086743489308475d + "'", double6 == 0.9086743489308475d);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 146.01712228365548d + "'", double21 == 146.01712228365548d);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 96 + "'", int22 == 96);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 99 + "'", int23 == 99);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        org.apache.commons.math3.optim.SimpleVectorValueChecker simpleVectorValueChecker2 = new org.apache.commons.math3.optim.SimpleVectorValueChecker(Double.NEGATIVE_INFINITY, 0.7615942060206032d);
        double double3 = simpleVectorValueChecker2.getRelativeThreshold();
        double double4 = simpleVectorValueChecker2.getRelativeThreshold();
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer gaussNewtonOptimizer5 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer((org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair>) simpleVectorValueChecker2);
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer gaussNewtonOptimizer6 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer((org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair>) simpleVectorValueChecker2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + Double.NEGATIVE_INFINITY + "'", double3 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + Double.NEGATIVE_INFINITY + "'", double4 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        double double1 = org.apache.commons.math3.util.FastMath.sqrt(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        double[] doubleArray22 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix23 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray22);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair24 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray14, doubleArray22);
        double[] doubleArray25 = pointVectorValuePair24.getFirst();
        double[] doubleArray26 = pointVectorValuePair24.getPointRef();
        double[] doubleArray33 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray33);
        double[] doubleArray41 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix42 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray41);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair43 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray33, doubleArray41);
        double[] doubleArray44 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray26, doubleArray41);
        double[] doubleArray49 = new double[] { (short) 10, 10L, 'a', 0.7650730050315234d };
        org.apache.commons.math3.optim.SimpleBounds simpleBounds50 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray44, doubleArray49);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair52 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray44, false);
        double[] doubleArray53 = pointVectorValuePair52.getValueRef();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray53);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[][] doubleArray8 = array2DRowRealMatrix7.getData();
        double[][] doubleArray9 = array2DRowRealMatrix7.getData();
        double[] doubleArray16 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16);
        double[] doubleArray24 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray24);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair26 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray16, doubleArray24);
        double[] doubleArray27 = pointVectorValuePair26.getFirst();
        double[] doubleArray28 = pointVectorValuePair26.getPointRef();
        double[] doubleArray35 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray35);
        double[] doubleArray43 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix44 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray43);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair45 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray35, doubleArray43);
        double[] doubleArray46 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray28, doubleArray43);
        double[] doubleArray47 = array2DRowRealMatrix7.preMultiply(doubleArray43);
        org.apache.commons.math3.util.MathArrays.checkPositive(doubleArray47);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma49 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray47);
        double[] doubleArray50 = sigma49.getSigma();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray50);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double double8 = array2DRowRealMatrix7.getFrobeniusNorm();
        double[] doubleArray15 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        double[][] doubleArray17 = array2DRowRealMatrix16.getData();
        double[][] doubleArray18 = array2DRowRealMatrix16.getData();
        double[] doubleArray25 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double double27 = array2DRowRealMatrix26.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix16, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix26);
        org.apache.commons.math3.linear.RealMatrix realMatrix29 = array2DRowRealMatrix7.add((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix16);
        double[] doubleArray36 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix37 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray36);
        org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) realMatrix29, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix37);
        org.apache.commons.math3.linear.RealMatrix realMatrix40 = array2DRowRealMatrix37.scalarAdd((-10761.089105465297d));
        int int41 = array2DRowRealMatrix37.getColumnDimension();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor42 = null;
        try {
            double double43 = array2DRowRealMatrix37.walkInRowOrder(realMatrixChangingVisitor42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 61.886993787063204d + "'", double8 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 61.886993787063204d + "'", double27 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(realMatrix40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double double8 = array2DRowRealMatrix7.getFrobeniusNorm();
        java.lang.String str9 = array2DRowRealMatrix7.toString();
        int int10 = array2DRowRealMatrix7.getColumnDimension();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor11 = null;
        try {
            double double16 = array2DRowRealMatrix7.walkInColumnOrder(realMatrixChangingVisitor11, 0, (int) (byte) 10, 61, 6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 61.886993787063204d + "'", double8 == 61.886993787063204d);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Array2DRowRealMatrix{{32.0},{0.0},{52.0},{-1.0},{10.0},{-1.0}}" + "'", str9.equals("Array2DRowRealMatrix{{32.0},{0.0},{52.0},{-1.0},{10.0},{-1.0}}"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer5 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer((double) 35, 0.7650730050315234d, (double) 1079508992, (double) (short) 100, (double) 13L);
        int int6 = levenbergMarquardtOptimizer5.getMaxEvaluations();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        float float1 = org.apache.commons.math3.util.FastMath.ulp((float) (-266497663));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 16.0f + "'", float1 == 16.0f);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        org.apache.commons.math3.optim.MaxIter maxIter1 = new org.apache.commons.math3.optim.MaxIter(36);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        org.apache.commons.math3.linear.RealMatrix realMatrix2 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix((int) (byte) 100, (int) (short) 100);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition4 = new org.apache.commons.math3.linear.LUDecomposition(realMatrix2, (double) 2);
        org.junit.Assert.assertNotNull(realMatrix2);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        int[] intArray5 = new int[] { (short) 100, (-127), '#', 0, 29 };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math3.random.MersenneTwister(intArray5);
        int[] intArray7 = org.apache.commons.math3.util.MathArrays.copyOf(intArray5);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray7);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        org.apache.commons.math3.optim.InitialGuess initialGuess17 = new org.apache.commons.math3.optim.InitialGuess(doubleArray6);
        double[] doubleArray18 = initialGuess17.getInitialGuess();
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix19 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray18);
        double[] doubleArray26 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix27 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray26);
        double[] doubleArray34 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix35 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray34);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair36 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray26, doubleArray34);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix38 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray26, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix39 = diagonalMatrix19.multiply(diagonalMatrix38);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor40 = null;
        try {
            double double45 = diagonalMatrix19.walkInOptimizedOrder(realMatrixChangingVisitor40, 0, (int) (short) 10, (int) 'a', 35);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(diagonalMatrix39);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        double[] doubleArray10 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray10);
        double[][] doubleArray12 = array2DRowRealMatrix11.getData();
        double[][] doubleArray13 = array2DRowRealMatrix11.getData();
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException14 = new org.apache.commons.math3.exception.MaxCountExceededException(localizable2, (java.lang.Number) 83.86684335012045d, (java.lang.Object[]) doubleArray13);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable1, (java.lang.Object[]) doubleArray13);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13, false);
        org.apache.commons.math3.exception.MathInternalError mathInternalError18 = new org.apache.commons.math3.exception.MathInternalError(localizable0, (java.lang.Object[]) doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver2 = new org.apache.commons.math3.analysis.solvers.BrentSolver((double) 100L, (double) 'a');
        double double3 = brentSolver2.getStartValue();
        int int4 = brentSolver2.getMaxEvaluations();
        double double5 = brentSolver2.getRelativeAccuracy();
        double double6 = brentSolver2.getRelativeAccuracy();
        double double7 = brentSolver2.getMax();
        double double8 = brentSolver2.getMax();
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction10 = null;
        try {
            double double14 = brentSolver2.solve(35, univariateFunction10, 1.1125369292536007E-308d, 11.0d, 0.3678794411714424d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.0d + "'", double6 == 100.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        double[] doubleArray17 = pointVectorValuePair16.getValue();
        org.apache.commons.math3.linear.RealVector realVector18 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray17);
        double[] doubleArray25 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double[] doubleArray33 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray33);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair35 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray25, doubleArray33);
        double[] doubleArray36 = pointVectorValuePair35.getValue();
        org.apache.commons.math3.linear.RealVector realVector37 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray36);
        org.apache.commons.math3.linear.RealVector realVector38 = realVector18.projection(realVector37);
        int int39 = realVector37.getMinIndex();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector42.addToEntry(0, (double) 1.0f);
        double[] doubleArray52 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix53 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray52);
        double[][] doubleArray54 = array2DRowRealMatrix53.getData();
        double[][] doubleArray55 = array2DRowRealMatrix53.getData();
        double[] doubleArray62 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix63 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray62);
        double double64 = array2DRowRealMatrix63.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix53, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix63);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector69 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector69.addToEntry(0, (double) 1.0f);
        arrayRealVector69.unitize();
        array2DRowRealMatrix53.setRowVector(0, (org.apache.commons.math3.linear.RealVector) arrayRealVector69);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector75 = arrayRealVector42.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector69);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector76 = new org.apache.commons.math3.linear.ArrayRealVector(realVector37, arrayRealVector69);
        double[] doubleArray77 = arrayRealVector76.toArray();
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor78 = null;
        try {
            double double79 = arrayRealVector76.walkInDefaultOrder(realVectorPreservingVisitor78);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(realVector37);
        org.junit.Assert.assertNotNull(realVector38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 5 + "'", int39 == 5);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 61.886993787063204d + "'", double64 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(arrayRealVector75);
        org.junit.Assert.assertNotNull(doubleArray77);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        java.text.ParsePosition parsePosition2 = null;
        try {
            boolean boolean3 = org.apache.commons.math3.util.CompositeFormat.parseFixedstring("{", "}", parsePosition2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        double double2 = org.apache.commons.math3.util.Precision.round(100.0d, 32);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat3 = new org.apache.commons.math3.linear.RealVectorFormat("hi!", "hi!", "");
        java.lang.String str4 = realVectorFormat3.getSeparator();
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = realVectorFormat3.parse("Array2DRowRealMatrix{{32.0},{0.0},{52.0},{-1.0},{10.0},{-1.0}}");
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathParseException; message: illegal state: string \"Array2DRowRealMatrix{{32.0},{0.0},{52.0},{-1.0},{10.0},{-1.0}}\" unparseable (from position 0) as an object of type org.apache.commons.math3.linear.ArrayRealVector");
        } catch (org.apache.commons.math3.exception.MathParseException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((float) (-127), (float) 1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker4 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker((double) ' ', (double) '#');
        org.apache.commons.math3.optim.univariate.BrentOptimizer brentOptimizer5 = new org.apache.commons.math3.optim.univariate.BrentOptimizer((double) 1.0000001f, (double) ' ', (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.univariate.UnivariatePointValuePair>) simpleUnivariateValueChecker4);
        double double6 = brentOptimizer5.getMax();
        double double7 = brentOptimizer5.getMin();
        int int8 = brentOptimizer5.getIterations();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        double double1 = org.apache.commons.math3.util.FastMath.ceil((double) 100L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1 == 100.0d);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(localizable0, number1, (java.lang.Number) (short) -1, false);
        java.lang.Number number5 = numberIsTooLargeException4.getMax();
        java.lang.Number number6 = numberIsTooLargeException4.getMax();
        boolean boolean7 = numberIsTooLargeException4.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (short) -1 + "'", number5.equals((short) -1));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (short) -1 + "'", number6.equals((short) -1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        double[] doubleArray17 = pointVectorValuePair16.getFirst();
        double[] doubleArray18 = pointVectorValuePair16.getValue();
        double[] doubleArray19 = pointVectorValuePair16.getPoint();
        java.lang.Object obj20 = null;
        boolean boolean21 = pointVectorValuePair16.equals(obj20);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair> pointVectorValuePairConvergenceChecker1 = null;
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer gaussNewtonOptimizer2 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer(true, pointVectorValuePairConvergenceChecker1);
        double[] doubleArray3 = gaussNewtonOptimizer2.getLowerBound();
        org.junit.Assert.assertNull(doubleArray3);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        float float2 = org.apache.commons.math3.util.FastMath.scalb((float) '#', 986830553);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + Float.POSITIVE_INFINITY + "'", float2 == Float.POSITIVE_INFINITY);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker4 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker((double) ' ', (double) '#');
        org.apache.commons.math3.optim.univariate.BrentOptimizer brentOptimizer5 = new org.apache.commons.math3.optim.univariate.BrentOptimizer((double) 1.0000001f, (double) ' ', (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.univariate.UnivariatePointValuePair>) simpleUnivariateValueChecker4);
        double double6 = brentOptimizer5.getMax();
        double double7 = brentOptimizer5.getMin();
        double double8 = brentOptimizer5.getMin();
        double double9 = brentOptimizer5.getMin();
        double double10 = brentOptimizer5.getStartValue();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        java.io.ObjectInputStream objectInputStream2 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.deserializeRealVector((java.lang.Object) (-127), "hi!", objectInputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 100, (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.scalarAdd(0.0d);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix5.scalarAdd((double) 7.6293945E-6f);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = blockRealMatrix7.getRowMatrix(243);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (243)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder2 = new org.apache.commons.math3.optim.univariate.BracketFinder(3.141592653589793d, (int) (byte) 1);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        double double3 = arrayRealVector2.getL1Norm();
        double[] doubleArray4 = arrayRealVector2.getDataRef();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        short short2 = org.apache.commons.math3.util.MathUtils.copySign((short) 1, (short) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        java.text.ParsePosition parsePosition2 = null;
        try {
            boolean boolean3 = org.apache.commons.math3.util.CompositeFormat.parseFixedstring(",", "", parsePosition2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        double double1 = org.apache.commons.math3.util.FastMath.log((double) 9.536743E-7f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-13.862943611198906d) + "'", double1 == (-13.862943611198906d));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula0 = org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES;
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker1 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer2 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, pointValuePairConvergenceChecker1);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula3 = org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.POLAK_RIBIERE;
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker7 = new org.apache.commons.math3.optim.SimpleValueChecker((-135.01712228365548d), 96.0d, 6);
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver10 = new org.apache.commons.math3.analysis.solvers.BrentSolver((double) 100L, (double) 'a');
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.Preconditioner preconditioner11 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer12 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula3, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker7, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver10, preconditioner11);
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver16 = new org.apache.commons.math3.analysis.solvers.BrentSolver((double) 9.536743E-7f, (double) 0.14566922f, 0.0d);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.Preconditioner preconditioner17 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer18 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker7, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver16, preconditioner17);
        double double19 = simpleValueChecker7.getAbsoluteThreshold();
        double[] doubleArray27 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray27);
        double[] doubleArray35 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray35);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair37 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray27, doubleArray35);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix39 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray27, true);
        org.apache.commons.math3.optim.PointValuePair pointValuePair41 = new org.apache.commons.math3.optim.PointValuePair(doubleArray27, (double) 2147483647);
        double[] doubleArray42 = pointValuePair41.getPointRef();
        double[] doubleArray49 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix50 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray49);
        double[] doubleArray57 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix58 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray57);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair59 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray49, doubleArray57);
        double[] doubleArray60 = pointVectorValuePair59.getValue();
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder61 = new org.apache.commons.math3.optim.univariate.BracketFinder();
        int int62 = bracketFinder61.getMaxEvaluations();
        boolean boolean63 = pointVectorValuePair59.equals((java.lang.Object) bracketFinder61);
        double[] doubleArray64 = pointVectorValuePair59.getSecond();
        double[] doubleArray65 = pointVectorValuePair59.getSecond();
        org.apache.commons.math3.optim.PointValuePair pointValuePair68 = new org.apache.commons.math3.optim.PointValuePair(doubleArray65, (double) 29, true);
        boolean boolean69 = simpleValueChecker7.converged(1085139999, pointValuePair41, pointValuePair68);
        java.lang.Double double70 = pointValuePair41.getValue();
        org.junit.Assert.assertTrue("'" + formula0 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES + "'", formula0.equals(org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES));
        org.junit.Assert.assertTrue("'" + formula3 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.POLAK_RIBIERE + "'", formula3.equals(org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.POLAK_RIBIERE));
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 96.0d + "'", double19 == 96.0d);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 50 + "'", int62 == 50);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 2.147483647E9d + "'", double70.equals(2.147483647E9d));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6, true);
        double[] doubleArray25 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double[] doubleArray33 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray33);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair35 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray25, doubleArray33);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix37 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray25, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix38 = diagonalMatrix18.add(diagonalMatrix37);
        diagonalMatrix38.multiplyEntry(50, (int) '4', (-0.5d));
        double[] doubleArray49 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix50 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray49);
        double[] doubleArray57 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix58 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray57);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair59 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray49, doubleArray57);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix61 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray49, true);
        double[] doubleArray68 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix69 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray68);
        double[] doubleArray76 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix77 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray76);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair78 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray68, doubleArray76);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix80 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray68, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix81 = diagonalMatrix61.add(diagonalMatrix80);
        diagonalMatrix80.multiplyEntry((int) 'a', (-127), (double) 1.0f);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix86 = diagonalMatrix38.multiply(diagonalMatrix80);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition87 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix86);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(diagonalMatrix38);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(diagonalMatrix81);
        org.junit.Assert.assertNotNull(diagonalMatrix86);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        java.lang.Number number0 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException(number0, (java.lang.Number) (-9090371258452850456L), true);
        org.apache.commons.math3.exception.util.Localizable localizable4 = null;
        java.lang.Object[] objArray5 = null;
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException6 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooLargeException3, localizable4, objArray5);
        boolean boolean7 = numberIsTooLargeException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex6 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(27, 17761.69164905552d, Double.NEGATIVE_INFINITY, 8.881784197001252E-16d, (-11.154160537197155d), (double) 3.8146973E-6f);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver2 = new org.apache.commons.math3.analysis.solvers.BrentSolver((double) 100L, (double) 'a');
        double double3 = brentSolver2.getStartValue();
        int int4 = brentSolver2.getEvaluations();
        double double5 = brentSolver2.getRelativeAccuracy();
        double double6 = brentSolver2.getRelativeAccuracy();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.0d + "'", double6 == 100.0d);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (-1.0728086555169287d), (java.lang.Number) 0.45952868f, false);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        double[] doubleArray17 = pointVectorValuePair16.getValue();
        double[] doubleArray18 = pointVectorValuePair16.getValueRef();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        double double1 = arrayRealVector0.getNorm();
        int int2 = arrayRealVector0.getMaxIndex();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        org.apache.commons.math3.linear.RealVector realVector7 = arrayRealVector5.append((double) 0.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector10.addToEntry(0, (double) 1.0f);
        double[] doubleArray20 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray20);
        double[][] doubleArray22 = array2DRowRealMatrix21.getData();
        double[][] doubleArray23 = array2DRowRealMatrix21.getData();
        double[] doubleArray30 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray30);
        double double32 = array2DRowRealMatrix31.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix21, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix31);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector37.addToEntry(0, (double) 1.0f);
        arrayRealVector37.unitize();
        array2DRowRealMatrix21.setRowVector(0, (org.apache.commons.math3.linear.RealVector) arrayRealVector37);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector43 = arrayRealVector10.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector37);
        double[] doubleArray44 = arrayRealVector37.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector5, doubleArray44);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector5, false);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = arrayRealVector0.add((org.apache.commons.math3.linear.RealVector) arrayRealVector5);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(realVector7);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 61.886993787063204d + "'", double32 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(arrayRealVector43);
        org.junit.Assert.assertNotNull(doubleArray44);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 100, (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.scalarAdd(0.0d);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix5.scalarAdd((double) 7.6293945E-6f);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        double double16 = array2DRowRealMatrix15.getFrobeniusNorm();
        java.lang.String str17 = array2DRowRealMatrix15.toString();
        int int18 = array2DRowRealMatrix15.getColumnDimension();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor19 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double20 = array2DRowRealMatrix15.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor19);
        try {
            double double25 = blockRealMatrix5.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor19, 647325673, 5, 1085139999, 29);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (647,325,673)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 61.886993787063204d + "'", double16 == 61.886993787063204d);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Array2DRowRealMatrix{{32.0},{0.0},{52.0},{-1.0},{10.0},{-1.0}}" + "'", str17.equals("Array2DRowRealMatrix{{32.0},{0.0},{52.0},{-1.0},{10.0},{-1.0}}"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        double double1 = org.apache.commons.math3.util.FastMath.atanh((double) 96L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 0.9835877454343449d, (java.lang.Number) 99, true);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        org.apache.commons.math3.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math3.exception.TooManyEvaluationsException((java.lang.Number) 0.7707837995104119d);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker5 = new org.apache.commons.math3.optim.SimpleValueChecker((-135.01712228365548d), 96.0d, 6);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer powellOptimizer6 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer((double) 10L, 2.718281828459045d, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker5);
        int int7 = powellOptimizer6.getEvaluations();
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        double double1 = org.apache.commons.math3.util.FastMath.ulp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 100, (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.scalarAdd(0.0d);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.copy();
        org.apache.commons.math3.linear.RealVector realVector8 = null;
        try {
            blockRealMatrix6.setColumnVector(36, realVector8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        int[] intArray1 = new int[] { (byte) 100 };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister2 = new org.apache.commons.math3.random.MersenneTwister(intArray1);
        int[] intArray4 = new int[] { (byte) 1 };
        int[] intArray8 = new int[] { (byte) 1, (byte) 100, '4' };
        int[] intArray13 = new int[] { 'a', (short) 1, (byte) 100, 'a' };
        double double14 = org.apache.commons.math3.util.MathArrays.distance(intArray8, intArray13);
        int int15 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray4, intArray13);
        int int16 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray1, intArray4);
        int[] intArray18 = org.apache.commons.math3.util.MathArrays.copyOf(intArray4, 6);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 146.01712228365548d + "'", double14 == 146.01712228365548d);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 96 + "'", int15 == 96);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 99 + "'", int16 == 99);
        org.junit.Assert.assertNotNull(intArray18);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(29, 35);
        double[] doubleArray10 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray10);
        double[] doubleArray18 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray18);
        double[] doubleArray26 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix27 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray26);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair28 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray18, doubleArray26);
        double[] doubleArray29 = pointVectorValuePair28.getFirst();
        double[] doubleArray30 = pointVectorValuePair28.getPointRef();
        double[] doubleArray37 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix38 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray37);
        double[] doubleArray45 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix46 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray45);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair47 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray37, doubleArray45);
        double[] doubleArray48 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray30, doubleArray45);
        double[] doubleArray53 = new double[] { (short) 10, 10L, 'a', 0.7650730050315234d };
        org.apache.commons.math3.optim.SimpleBounds simpleBounds54 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray48, doubleArray53);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair56 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray10, doubleArray48, false);
        org.apache.commons.math3.linear.RealMatrix realMatrix57 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray10);
        org.apache.commons.math3.linear.MatrixUtils.checkSymmetric(realMatrix57, 310.0d);
        try {
            array2DRowRealMatrix2.setRowMatrix(45, realMatrix57);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (45)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(realMatrix57);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 0.1579223549310333d);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder2 = new org.apache.commons.math3.optim.univariate.BracketFinder((double) 1.0851401E9f, 1079508992);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 647325673, (java.lang.Number) 0.5403023058681398d, true);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 3830.0d, (java.lang.Number) 0.0d, 1079508992);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection4 = nonMonotonicSequenceException3.getDirection();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection5 = nonMonotonicSequenceException3.getDirection();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection6 = nonMonotonicSequenceException3.getDirection();
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection4.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection5 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection5.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double double8 = array2DRowRealMatrix7.getFrobeniusNorm();
        double[] doubleArray15 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        double[][] doubleArray17 = array2DRowRealMatrix16.getData();
        double[][] doubleArray18 = array2DRowRealMatrix16.getData();
        double[] doubleArray25 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double double27 = array2DRowRealMatrix26.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix16, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix26);
        org.apache.commons.math3.linear.RealMatrix realMatrix29 = array2DRowRealMatrix7.add((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix16);
        double[] doubleArray36 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix37 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray36);
        double[][] doubleArray38 = array2DRowRealMatrix37.getData();
        double[][] doubleArray39 = array2DRowRealMatrix37.getData();
        double[] doubleArray46 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix47 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray46);
        double[] doubleArray54 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix55 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray54);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair56 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray46, doubleArray54);
        double[] doubleArray57 = pointVectorValuePair56.getFirst();
        double[] doubleArray58 = pointVectorValuePair56.getPointRef();
        double[] doubleArray65 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix66 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray65);
        double[] doubleArray73 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix74 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray73);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair75 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray65, doubleArray73);
        double[] doubleArray76 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray58, doubleArray73);
        double[] doubleArray77 = array2DRowRealMatrix37.preMultiply(doubleArray73);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix78 = array2DRowRealMatrix16.subtract(array2DRowRealMatrix37);
        double[] doubleArray85 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix86 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray85);
        double[][] doubleArray87 = array2DRowRealMatrix86.getData();
        double[][] doubleArray88 = array2DRowRealMatrix86.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix89 = array2DRowRealMatrix37.add(array2DRowRealMatrix86);
        try {
            array2DRowRealMatrix86.setEntry(127, (int) (byte) 10, 1.0E-15d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (127)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 61.886993787063204d + "'", double8 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 61.886993787063204d + "'", double27 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix78);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix89);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math3.random.MersenneTwister(5);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula8 = org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES;
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker9 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer10 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula8, pointValuePairConvergenceChecker9);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula11 = org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.POLAK_RIBIERE;
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker15 = new org.apache.commons.math3.optim.SimpleValueChecker((-135.01712228365548d), 96.0d, 6);
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver18 = new org.apache.commons.math3.analysis.solvers.BrentSolver((double) 100L, (double) 'a');
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.Preconditioner preconditioner19 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer20 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula11, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker15, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver18, preconditioner19);
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver24 = new org.apache.commons.math3.analysis.solvers.BrentSolver((double) 9.536743E-7f, (double) 0.14566922f, 0.0d);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.Preconditioner preconditioner25 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer26 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula8, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker15, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver24, preconditioner25);
        double double27 = simpleValueChecker15.getAbsoluteThreshold();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer28 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer(5, (double) 61, false, 0, 243, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister6, false, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker15);
        java.util.List<java.lang.Double> doubleList29 = cMAESOptimizer28.getStatisticsFitnessHistory();
        org.junit.Assert.assertTrue("'" + formula8 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES + "'", formula8.equals(org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES));
        org.junit.Assert.assertTrue("'" + formula11 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.POLAK_RIBIERE + "'", formula11.equals(org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.POLAK_RIBIERE));
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 96.0d + "'", double27 == 96.0d);
        org.junit.Assert.assertNotNull(doubleList29);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 3830.0d, (java.lang.Number) 0.0d, 1079508992);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection4 = nonMonotonicSequenceException3.getDirection();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection5 = nonMonotonicSequenceException3.getDirection();
        java.lang.Number number6 = nonMonotonicSequenceException3.getPrevious();
        int int7 = nonMonotonicSequenceException3.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection4.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection5 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection5.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0.0d + "'", number6.equals(0.0d));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1079508992 + "'", int7 == 1079508992);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair2 = new org.apache.commons.math3.optim.univariate.UnivariatePointValuePair((double) Float.POSITIVE_INFINITY, (double) (-2007483583));
        double double3 = univariatePointValuePair2.getPoint();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + Double.POSITIVE_INFINITY + "'", double3 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        int[] intArray1 = new int[] { (byte) 100 };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister2 = new org.apache.commons.math3.random.MersenneTwister(intArray1);
        float float3 = mersenneTwister2.nextFloat();
        mersenneTwister2.setSeed(100L);
        double double6 = mersenneTwister2.nextGaussian();
        float float7 = mersenneTwister2.nextFloat();
        int[] intArray11 = new int[] { (byte) 1, (byte) 100, '4' };
        int[] intArray16 = new int[] { 'a', (short) 1, (byte) 100, 'a' };
        double double17 = org.apache.commons.math3.util.MathArrays.distance(intArray11, intArray16);
        int[] intArray21 = new int[] { (byte) 1, (byte) 100, '4' };
        int[] intArray26 = new int[] { 'a', (short) 1, (byte) 100, 'a' };
        double double27 = org.apache.commons.math3.util.MathArrays.distance(intArray21, intArray26);
        int int28 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray11, intArray21);
        int[] intArray32 = new int[] { (byte) 1, (byte) 100, '4' };
        int[] intArray37 = new int[] { 'a', (short) 1, (byte) 100, 'a' };
        double double38 = org.apache.commons.math3.util.MathArrays.distance(intArray32, intArray37);
        int[] intArray42 = new int[] { (byte) 1, (byte) 100, '4' };
        int[] intArray47 = new int[] { 'a', (short) 1, (byte) 100, 'a' };
        double double48 = org.apache.commons.math3.util.MathArrays.distance(intArray42, intArray47);
        int int49 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray32, intArray42);
        int int50 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray21, intArray42);
        mersenneTwister2.setSeed(intArray21);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.14566922f + "'", float3 == 0.14566922f);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.9086743489308475d + "'", double6 == 0.9086743489308475d);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.7567276f + "'", float7 == 0.7567276f);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 146.01712228365548d + "'", double17 == 146.01712228365548d);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 146.01712228365548d + "'", double27 == 146.01712228365548d);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 146.01712228365548d + "'", double38 == 146.01712228365548d);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 146.01712228365548d + "'", double48 == 146.01712228365548d);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        org.apache.commons.math3.optim.InitialGuess initialGuess17 = new org.apache.commons.math3.optim.InitialGuess(doubleArray6);
        double[] doubleArray18 = initialGuess17.getInitialGuess();
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix19 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray18);
        double[] doubleArray26 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix27 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray26);
        double[] doubleArray34 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix35 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray34);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair36 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray26, doubleArray34);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix38 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray26, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix39 = diagonalMatrix19.multiply(diagonalMatrix38);
        double[][] doubleArray40 = diagonalMatrix39.getData();
        boolean boolean41 = diagonalMatrix39.isTransposable();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(diagonalMatrix39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector2.addToEntry(0, (double) 1.0f);
        double[] doubleArray12 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray12);
        double[][] doubleArray14 = array2DRowRealMatrix13.getData();
        double[][] doubleArray15 = array2DRowRealMatrix13.getData();
        double[] doubleArray22 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix23 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray22);
        double double24 = array2DRowRealMatrix23.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix13, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix23);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector29.addToEntry(0, (double) 1.0f);
        arrayRealVector29.unitize();
        array2DRowRealMatrix13.setRowVector(0, (org.apache.commons.math3.linear.RealVector) arrayRealVector29);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = arrayRealVector2.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector29);
        double[] doubleArray36 = arrayRealVector29.toArray();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix37 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 61.886993787063204d + "'", double24 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(arrayRealVector35);
        org.junit.Assert.assertNotNull(doubleArray36);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 100, (int) (byte) 10);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.getRowMatrix(29);
        org.apache.commons.math3.exception.util.Localizable localizable6 = null;
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        double[][] doubleArray16 = array2DRowRealMatrix15.getData();
        double[][] doubleArray17 = array2DRowRealMatrix15.getData();
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException18 = new org.apache.commons.math3.exception.MaxCountExceededException(localizable6, (java.lang.Number) 83.86684335012045d, (java.lang.Object[]) doubleArray17);
        try {
            blockRealMatrix2.setSubMatrix(doubleArray17, 0, (int) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6, true);
        double[] doubleArray25 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double[] doubleArray33 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray33);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair35 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray25, doubleArray33);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix37 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray25, true);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix38 = diagonalMatrix18.add(diagonalMatrix37);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor39 = null;
        try {
            double double44 = diagonalMatrix38.walkInColumnOrder(realMatrixChangingVisitor39, (int) '4', 1079508992, 36, 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(diagonalMatrix38);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        int[] intArray6 = new int[] { (byte) 100 };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister7 = new org.apache.commons.math3.random.MersenneTwister(intArray6);
        double double8 = mersenneTwister7.nextGaussian();
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker10 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer11 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer((int) 'a', (double) 10, true, (int) (short) -1, 0, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister7, false, pointValuePairConvergenceChecker10);
        java.util.List<java.lang.Double> doubleList12 = cMAESOptimizer11.getStatisticsSigmaHistory();
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType13 = cMAESOptimizer11.getGoalType();
        java.util.List<java.lang.Double> doubleList14 = cMAESOptimizer11.getStatisticsFitnessHistory();
        double[] doubleArray15 = cMAESOptimizer11.getStartPoint();
        double[] doubleArray16 = cMAESOptimizer11.getLowerBound();
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.7650730050315234d + "'", double8 == 0.7650730050315234d);
        org.junit.Assert.assertNotNull(doubleList12);
        org.junit.Assert.assertNull(goalType13);
        org.junit.Assert.assertNotNull(doubleList14);
        org.junit.Assert.assertNull(doubleArray15);
        org.junit.Assert.assertNull(doubleArray16);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        int int1 = org.apache.commons.math3.util.MathUtils.hash((double) 10.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1076101120 + "'", int1 == 1076101120);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        long long2 = org.apache.commons.math3.util.FastMath.min((long) (byte) 0, (long) (short) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        double[] doubleArray0 = null;
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex3 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(doubleArray0, (double) 1, 100.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker3 = new org.apache.commons.math3.optim.SimpleValueChecker((double) '#', (double) (-127), 5);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        double[] doubleArray17 = pointVectorValuePair16.getFirst();
        double[] doubleArray18 = pointVectorValuePair16.getPointRef();
        double[] doubleArray25 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double[] doubleArray33 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray33);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair35 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray25, doubleArray33);
        double[] doubleArray36 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray18, doubleArray33);
        double[] doubleArray41 = new double[] { (short) 10, 10L, 'a', 0.7650730050315234d };
        org.apache.commons.math3.optim.SimpleBounds simpleBounds42 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray36, doubleArray41);
        double[] doubleArray43 = simpleBounds42.getUpper();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix44 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray43);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex47 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(doubleArray43, 0.0d, 135.01712228365548d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray43);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat3 = new org.apache.commons.math3.linear.RealVectorFormat("hi!", "hi!", "");
        double[] doubleArray10 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray10);
        double[] doubleArray18 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray18);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair20 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray10, doubleArray18);
        double[] doubleArray21 = pointVectorValuePair20.getValue();
        double[] doubleArray22 = pointVectorValuePair20.getPointRef();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray22);
        org.apache.commons.math3.linear.RealVector realVector25 = arrayRealVector23.mapMultiplyToSelf((double) (byte) 1);
        double[] doubleArray33 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray33);
        double[] doubleArray41 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix42 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray41);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair43 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray33, doubleArray41);
        double[] doubleArray44 = pointVectorValuePair43.getValue();
        org.apache.commons.math3.linear.RealVector realVector45 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray44);
        arrayRealVector23.setSubVector(0, realVector45);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector49.addToEntry(0, (double) 1.0f);
        double[] doubleArray59 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix60 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray59);
        double[][] doubleArray61 = array2DRowRealMatrix60.getData();
        double[][] doubleArray62 = array2DRowRealMatrix60.getData();
        double[] doubleArray69 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix70 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray69);
        double double71 = array2DRowRealMatrix70.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix60, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix70);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector76 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector76.addToEntry(0, (double) 1.0f);
        arrayRealVector76.unitize();
        array2DRowRealMatrix60.setRowVector(0, (org.apache.commons.math3.linear.RealVector) arrayRealVector76);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector82 = arrayRealVector49.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector76);
        org.apache.commons.math3.linear.RealVector realVector83 = arrayRealVector23.append((org.apache.commons.math3.linear.RealVector) arrayRealVector76);
        org.apache.commons.math3.linear.RealVector realVector85 = arrayRealVector76.mapDivide((double) (-4228292497824268148L));
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector87 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector76, true);
        java.lang.String str88 = realVectorFormat3.format((org.apache.commons.math3.linear.RealVector) arrayRealVector76);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(realVector25);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(realVector45);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 61.886993787063204d + "'", double71 == 61.886993787063204d);
        org.junit.Assert.assertNotNull(arrayRealVector82);
        org.junit.Assert.assertNotNull(realVector83);
        org.junit.Assert.assertNotNull(realVector85);
        org.junit.Assert.assertTrue("'" + str88 + "' != '" + "hi!1hi!" + "'", str88.equals("hi!1hi!"));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double double8 = array2DRowRealMatrix7.getFrobeniusNorm();
        java.lang.String str9 = array2DRowRealMatrix7.toString();
        double[] doubleArray16 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16);
        double[] doubleArray24 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray24);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair26 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray16, doubleArray24);
        double[] doubleArray33 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray33);
        double[] doubleArray41 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix42 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray41);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair43 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray33, doubleArray41);
        double[] doubleArray44 = pointVectorValuePair43.getFirst();
        double[] doubleArray45 = pointVectorValuePair43.getPointRef();
        double[] doubleArray52 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix53 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray52);
        double[] doubleArray60 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix61 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray60);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair62 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray52, doubleArray60);
        double[] doubleArray63 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray45, doubleArray60);
        double[] doubleArray64 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray24, doubleArray60);
        double[] doubleArray65 = array2DRowRealMatrix7.preMultiply(doubleArray24);
        double[] doubleArray72 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix73 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray72);
        double[] doubleArray80 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix81 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray80);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair82 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray72, doubleArray80);
        org.apache.commons.math3.optim.InitialGuess initialGuess83 = new org.apache.commons.math3.optim.InitialGuess(doubleArray72);
        org.apache.commons.math3.optim.InitialGuess initialGuess84 = new org.apache.commons.math3.optim.InitialGuess(doubleArray72);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition86 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray65, doubleArray72, 2.2250738585072014E-308d);
        double[] doubleArray87 = eigenDecomposition86.getImagEigenvalues();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 61.886993787063204d + "'", double8 == 61.886993787063204d);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Array2DRowRealMatrix{{32.0},{0.0},{52.0},{-1.0},{10.0},{-1.0}}" + "'", str9.equals("Array2DRowRealMatrix{{32.0},{0.0},{52.0},{-1.0},{10.0},{-1.0}}"));
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertNotNull(doubleArray87);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        java.text.NumberFormat numberFormat0 = org.apache.commons.math3.util.CompositeFormat.getDefaultNumberFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat1 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat0);
        double[] doubleArray8 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray8);
        double[][] doubleArray10 = array2DRowRealMatrix9.getData();
        double[][] doubleArray11 = array2DRowRealMatrix9.getData();
        double[] doubleArray18 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray18);
        double double20 = array2DRowRealMatrix19.getFrobeniusNorm();
        org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix9, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix19);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector(1, (double) 10L);
        arrayRealVector25.addToEntry(0, (double) 1.0f);
        arrayRealVector25.unitize();
        array2DRowRealMatrix9.setRowVector(0, (org.apache.commons.math3.linear.RealVector) arrayRealVector25);
        double double31 = arrayRealVector25.getNorm();
        java.lang.String str32 = realVectorFormat1.format((org.apache.commons.math3.linear.RealVector) arrayRealVector25);
        java.lang.String str33 = realVectorFormat1.getSuffix();
        org.junit.Assert.assertNotNull(numberFormat0);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 61.886993787063204d + "'", double20 == 61.886993787063204d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 1.0d + "'", double31 == 1.0d);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "{1}" + "'", str32.equals("{1}"));
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "}" + "'", str33.equals("}"));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        org.apache.commons.math3.optim.InitialGuess initialGuess17 = new org.apache.commons.math3.optim.InitialGuess(doubleArray6);
        double[] doubleArray18 = initialGuess17.getInitialGuess();
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix19 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray18);
        double[] doubleArray21 = diagonalMatrix19.getRow(1);
        org.apache.commons.math3.linear.RealMatrix realMatrix24 = diagonalMatrix19.createMatrix((int) (byte) 1, (int) (short) 1);
        try {
            org.apache.commons.math3.linear.RealVector realVector26 = diagonalMatrix19.getRowVector(625644691);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (625,644,691)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(realMatrix24);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat1 = org.apache.commons.math3.linear.MatrixUtils.DEFAULT_FORMAT;
        java.lang.String str2 = realMatrixFormat1.getRowSeparator();
        java.text.NumberFormat numberFormat3 = realMatrixFormat1.getFormat();
        java.text.ParsePosition parsePosition4 = null;
        try {
            java.lang.Number number5 = org.apache.commons.math3.util.CompositeFormat.parseNumber("hi!", numberFormat3, parsePosition4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrixFormat1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "," + "'", str2.equals(","));
        org.junit.Assert.assertNotNull(numberFormat3);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        double[] doubleArray17 = pointVectorValuePair16.getValue();
        double[] doubleArray24 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray24);
        double[] doubleArray32 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray32);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair34 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray24, doubleArray32);
        double[] doubleArray35 = pointVectorValuePair34.getFirst();
        double[] doubleArray36 = pointVectorValuePair34.getValue();
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair38 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray17, doubleArray36, false);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        org.apache.commons.math3.optim.SimpleVectorValueChecker simpleVectorValueChecker3 = new org.apache.commons.math3.optim.SimpleVectorValueChecker(0.0d, (double) (short) 0, 1079508992);
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer gaussNewtonOptimizer4 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer((org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair>) simpleVectorValueChecker3);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        double[] doubleArray6 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray14 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray14);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray14);
        double[] doubleArray17 = pointVectorValuePair16.getValue();
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder18 = new org.apache.commons.math3.optim.univariate.BracketFinder();
        int int19 = bracketFinder18.getMaxEvaluations();
        boolean boolean20 = pointVectorValuePair16.equals((java.lang.Object) bracketFinder18);
        double[] doubleArray21 = pointVectorValuePair16.getPoint();
        double[] doubleArray28 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray28);
        double double30 = array2DRowRealMatrix29.getFrobeniusNorm();
        java.lang.String str31 = array2DRowRealMatrix29.toString();
        double[] doubleArray38 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix39 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray38);
        double[] doubleArray46 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix47 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray46);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair48 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray38, doubleArray46);
        double[] doubleArray55 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix56 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray55);
        double[] doubleArray63 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix64 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray63);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair65 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray55, doubleArray63);
        double[] doubleArray66 = pointVectorValuePair65.getFirst();
        double[] doubleArray67 = pointVectorValuePair65.getPointRef();
        double[] doubleArray74 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix75 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray74);
        double[] doubleArray82 = new double[] { ' ', 0.0f, '4', (-1L), 10.0d, (short) -1 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix83 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray82);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair84 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray74, doubleArray82);
        double[] doubleArray85 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray67, doubleArray82);
        double[] doubleArray86 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray46, doubleArray82);
        double[] doubleArray87 = array2DRowRealMatrix29.preMultiply(doubleArray46);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition88 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray21, doubleArray46);
        double double89 = eigenDecomposition88.getDeterminant();
        org.apache.commons.math3.linear.RealMatrix realMatrix90 = eigenDecomposition88.getV();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 50 + "'", int19 == 50);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 61.886993787063204d + "'", double30 == 61.886993787063204d);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Array2DRowRealMatrix{{32.0},{0.0},{52.0},{-1.0},{10.0},{-1.0}}" + "'", str31.equals("Array2DRowRealMatrix{{32.0},{0.0},{52.0},{-1.0},{10.0},{-1.0}}"));
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + (-3.104890880000001E8d) + "'", double89 == (-3.104890880000001E8d));
        org.junit.Assert.assertNotNull(realMatrix90);
    }
}

