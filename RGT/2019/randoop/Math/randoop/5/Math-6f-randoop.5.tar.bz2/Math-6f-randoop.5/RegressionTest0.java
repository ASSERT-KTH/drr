import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        int int0 = org.apache.commons.math3.linear.BlockFieldMatrix.BLOCK_SIZE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 36 + "'", int0 == 36);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        java.text.ParsePosition parsePosition1 = null;
        try {
            char char2 = org.apache.commons.math3.util.CompositeFormat.parseNextCharacter("hi!", parsePosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        float float2 = org.apache.commons.math3.util.Precision.round((float) 1, (-1));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        double double1 = org.apache.commons.math3.util.FastMath.log((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        double double1 = org.apache.commons.math3.util.FastMath.tan(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        double double1 = org.apache.commons.math3.util.FastMath.rint((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1 == 100.0d);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.apache.commons.math3.linear.FieldMatrix<org.apache.commons.math3.fraction.BigFraction> bigFractionFieldMatrix0 = null;
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix1 = org.apache.commons.math3.linear.MatrixUtils.bigFractionMatrixToRealMatrix(bigFractionFieldMatrix0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        double double2 = org.apache.commons.math3.util.Precision.round(0.0d, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = null;
        double[] doubleArray7 = new double[] { 1.0f, 0L, 1.0f, (byte) 100, (short) 1, 'a' };
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, doubleArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix1 = org.apache.commons.math3.linear.MatrixUtils.createRealIdentityMatrix(0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals(0.0d, (double) (byte) 10, 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        double double1 = org.apache.commons.math3.util.FastMath.exp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        long long1 = org.apache.commons.math3.util.FastMath.abs((long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker0 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer simplexOptimizer1 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer(pointValuePairConvergenceChecker0);
        double[] doubleArray2 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight3 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray2);
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight5 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray4);
        double[] doubleArray6 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight7 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray6);
        double[] doubleArray8 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight9 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray8);
        org.apache.commons.math3.optim.OptimizationData[] optimizationDataArray10 = new org.apache.commons.math3.optim.OptimizationData[] { weight3, weight5, weight7, weight9 };
        try {
            org.apache.commons.math3.optim.PointValuePair pointValuePair11 = simplexOptimizer1.optimize(optimizationDataArray10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(optimizationDataArray10);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex1 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.ZeroException; message: zero not allowed here");
        } catch (org.apache.commons.math3.exception.ZeroException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        double[] doubleArray0 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray0, 125, 125);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        int int3 = org.apache.commons.math3.util.Precision.compareTo((double) '4', (double) (byte) 100, 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        double double2 = org.apache.commons.math3.util.FastMath.IEEEremainder((double) 10.0f, (double) (short) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.apache.commons.math3.linear.AnyMatrix anyMatrix0 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkRowIndex(anyMatrix0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        float float2 = org.apache.commons.math3.util.FastMath.max((float) 100L, (float) (-1L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) 100L, (java.lang.Number) 10.0d, (java.lang.Number) 0L);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        double double1 = org.apache.commons.math3.util.FastMath.cosh((double) 125);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.677880210178613E53d + "'", double1 == 9.677880210178613E53d);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
        org.apache.commons.math3.optim.nonlinear.vector.Target target2 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray0);
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex7 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray0, (double) '4', (double) (byte) 1, (double) 'a', (double) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.ZeroException; message: zero not allowed here");
        } catch (org.apache.commons.math3.exception.ZeroException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        double[] doubleArray3 = new double[] { '#', (byte) 100, (short) 100 };
        double[] doubleArray7 = new double[] { '#', (byte) 100, (short) 100 };
        double[] doubleArray11 = new double[] { '#', (byte) 100, (short) 100 };
        double[] doubleArray15 = new double[] { '#', (byte) 100, (short) 100 };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        double[][] doubleArray17 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray16);
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex18 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray16);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: equal vertices 1 and 0 in simplex configuration");
        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.BracketingStep bracketingStep1 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.BracketingStep((double) (byte) 0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equalsIncludingNaN(1.0E-14d, (double) ' ');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer5 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer((double) 100L, (double) 'a', (double) (byte) 1, (double) (short) -1, (double) (short) 1);
        double[] doubleArray6 = null;
        try {
            double[][] doubleArray8 = levenbergMarquardtOptimizer5.computeCovariances(doubleArray6, 1.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
        org.apache.commons.math3.optim.nonlinear.vector.Target target2 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix3 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray0);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = diagonalMatrix3.power((int) ' ');
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkRowIndex((org.apache.commons.math3.linear.AnyMatrix) diagonalMatrix3, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(realMatrix5);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        double[][] doubleArray0 = new double[][] {};
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex1 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(doubleArray0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: simplex must contain at least one point");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        int int2 = org.apache.commons.math3.util.FastMath.max((int) '#', (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.BracketingStep bracketingStep1 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.BracketingStep(0.0d);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        double double1 = org.apache.commons.math3.util.FastMath.asin(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.apache.commons.math3.optim.MaxIter maxIter0 = org.apache.commons.math3.optim.MaxIter.unlimited();
        org.junit.Assert.assertNotNull(maxIter0);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((float) 100, (float) 100L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
        org.apache.commons.math3.optim.nonlinear.vector.Target target2 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix3 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray0);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = diagonalMatrix3.power((int) ' ');
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math3.linear.AnyMatrix) realMatrix5, (int) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(realMatrix5);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker0 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer simplexOptimizer1 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer(pointValuePairConvergenceChecker0);
        int int2 = simplexOptimizer1.getEvaluations();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer powellOptimizer2 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer(0.0d, 1.0E-14d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooSmallException; message: 0 is smaller than the minimum (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooSmallException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker0 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer simplexOptimizer1 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer(pointValuePairConvergenceChecker0);
        double[] doubleArray2 = simplexOptimizer1.getLowerBound();
        int int3 = simplexOptimizer1.getMaxEvaluations();
        org.junit.Assert.assertNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        double double3 = org.apache.commons.math3.util.MathUtils.reduce((double) '4', (double) (short) -1, (double) 0L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray4 = new double[] { '#', (byte) 100, (short) 100 };
        double[] doubleArray8 = new double[] { '#', (byte) 100, (short) 100 };
        double[] doubleArray12 = new double[] { '#', (byte) 100, (short) 100 };
        double[] doubleArray16 = new double[] { '#', (byte) 100, (short) 100 };
        double[][] doubleArray17 = new double[][] { doubleArray4, doubleArray8, doubleArray12, doubleArray16 };
        double[][] doubleArray18 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray17);
        org.apache.commons.math3.linear.NonSquareMatrixException nonSquareMatrixException21 = new org.apache.commons.math3.linear.NonSquareMatrixException((int) (short) 1, (int) (short) 10);
        org.apache.commons.math3.util.Pair<java.lang.Object[], org.apache.commons.math3.exception.MathIllegalNumberException> objArrayPair22 = new org.apache.commons.math3.util.Pair<java.lang.Object[], org.apache.commons.math3.exception.MathIllegalNumberException>((java.lang.Object[]) doubleArray17, (org.apache.commons.math3.exception.MathIllegalNumberException) nonSquareMatrixException21);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException23 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable0, (java.lang.Object[]) doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
        org.apache.commons.math3.optim.nonlinear.vector.Target target2 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix3 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray0);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = diagonalMatrix3.power((int) ' ');
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix8 = diagonalMatrix3.createMatrix((int) 'a', 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 97 != 100");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(realMatrix5);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((double) 125, (double) ' ', (int) '#');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer powellOptimizer4 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer((double) 10, (double) 36, (double) (short) 100, (double) 0.0f);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
        org.apache.commons.math3.optim.nonlinear.vector.Target target2 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix3 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray0);
        try {
            double[] doubleArray5 = diagonalMatrix3.getRow((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        int int3 = org.apache.commons.math3.util.Precision.compareTo(0.0d, 100.0d, (double) 10L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        double double6 = org.apache.commons.math3.util.MathArrays.linearCombination((double) 0, (double) 100.0f, (double) 1L, (double) 0, (double) (short) 100, (double) 36);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 3600.0d + "'", double6 == 3600.0d);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
        org.apache.commons.math3.optim.nonlinear.vector.Target target2 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix3 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray0);
        double double4 = diagonalMatrix3.getFrobeniusNorm();
        try {
            org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition6 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix3, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        double double2 = org.apache.commons.math3.util.FastMath.copySign((double) '4', 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 52.0d + "'", double2 == 52.0d);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math3.exception.DimensionMismatchException((-1), 0);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        double double1 = org.apache.commons.math3.util.FastMath.sin((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8414709848078965d + "'", double1 == 0.8414709848078965d);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        float float1 = org.apache.commons.math3.util.FastMath.abs((float) 100);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 100.0f + "'", float1 == 100.0f);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction0 = null;
        try {
            boolean boolean3 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.isBracketing(univariateFunction0, (double) (byte) 1, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType0 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE;
        org.junit.Assert.assertTrue("'" + goalType0 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE + "'", goalType0.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair2 = new org.apache.commons.math3.optim.univariate.UnivariatePointValuePair((double) (byte) 1, (double) 0);
        double double3 = univariatePointValuePair2.getPoint();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        long long2 = org.apache.commons.math3.util.MathUtils.copySign((long) 10, (long) 36);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        double double1 = org.apache.commons.math3.util.FastMath.asinh((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8813735870195429d) + "'", double1 == (-0.8813735870195429d));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        double double6 = org.apache.commons.math3.util.MathArrays.linearCombination((double) (byte) 100, (double) 97, (double) 10, (double) (short) -1, 52.0d, 100.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 14890.0d + "'", double6 == 14890.0d);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer powellOptimizer4 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer((double) (byte) 100, (double) (short) 0, (double) 'a', (double) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker4 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker(0.0d, (double) 0.0f);
        try {
            org.apache.commons.math3.optim.univariate.BrentOptimizer brentOptimizer5 = new org.apache.commons.math3.optim.univariate.BrentOptimizer(3600.0d, (double) (-1L), (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.univariate.UnivariatePointValuePair>) simpleUnivariateValueChecker4);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        try {
            org.apache.commons.math3.optim.univariate.SearchInterval searchInterval2 = new org.apache.commons.math3.optim.univariate.SearchInterval((double) (-1L), (-1.0d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: -1 is larger than, or equal to, the maximum (-1)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        double double2 = org.apache.commons.math3.util.FastMath.atan2((-1.0d), 3600.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-2.777777706332879E-4d) + "'", double2 == (-2.777777706332879E-4d));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        double double2 = org.apache.commons.math3.util.FastMath.nextAfter((double) 10.0f, (-0.8813735870195429d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.999999999999998d + "'", double2 == 9.999999999999998d);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.apache.commons.math3.optim.SimpleVectorValueChecker simpleVectorValueChecker4 = new org.apache.commons.math3.optim.SimpleVectorValueChecker((double) '4', (double) 10L, 125);
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer gaussNewtonOptimizer5 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer(false, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair>) simpleVectorValueChecker4);
        double[] doubleArray6 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight7 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray6);
        org.apache.commons.math3.optim.nonlinear.vector.Target target8 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray6);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.BracketingStep bracketingStep10 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.BracketingStep((double) (byte) 0);
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType11 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE;
        org.apache.commons.math3.analysis.MultivariateFunction multivariateFunction12 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.ObjectiveFunction objectiveFunction13 = new org.apache.commons.math3.optim.nonlinear.scalar.ObjectiveFunction(multivariateFunction12);
        org.apache.commons.math3.optim.OptimizationData[] optimizationDataArray14 = new org.apache.commons.math3.optim.OptimizationData[] { target8, bracketingStep10, goalType11, objectiveFunction13 };
        try {
            org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair15 = gaussNewtonOptimizer5.optimize(optimizationDataArray14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + goalType11 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE + "'", goalType11.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE));
        org.junit.Assert.assertNotNull(optimizationDataArray14);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        double double1 = org.apache.commons.math3.util.FastMath.sinh((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1752011936438014d + "'", double1 == 1.1752011936438014d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver0 = new org.apache.commons.math3.analysis.solvers.BrentSolver();
        double double1 = brentSolver0.getRelativeAccuracy();
        double double2 = brentSolver0.getFunctionValueAccuracy();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0E-14d + "'", double1 == 1.0E-14d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E-15d + "'", double2 == 1.0E-15d);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.apache.commons.math3.linear.AnyMatrix anyMatrix0 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkRowIndex(anyMatrix0, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer5 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer((double) 100L, (double) 'a', (double) (byte) 1, (double) (short) -1, (double) (short) 1);
        int int6 = levenbergMarquardtOptimizer5.getEvaluations();
        org.apache.commons.math3.optim.MaxIter maxIter7 = org.apache.commons.math3.optim.MaxIter.unlimited();
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.BracketingStep bracketingStep9 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.BracketingStep(0.0d);
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType10 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE;
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight12 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray11);
        org.apache.commons.math3.optim.nonlinear.vector.Target target13 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray11);
        org.apache.commons.math3.analysis.MultivariateFunction multivariateFunction14 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.ObjectiveFunction objectiveFunction15 = new org.apache.commons.math3.optim.nonlinear.scalar.ObjectiveFunction(multivariateFunction14);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.BracketingStep bracketingStep17 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.BracketingStep((double) (byte) 0);
        org.apache.commons.math3.optim.OptimizationData[] optimizationDataArray18 = new org.apache.commons.math3.optim.OptimizationData[] { maxIter7, bracketingStep9, goalType10, target13, objectiveFunction15, bracketingStep17 };
        try {
            org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair19 = levenbergMarquardtOptimizer5.optimize(optimizationDataArray18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(maxIter7);
        org.junit.Assert.assertTrue("'" + goalType10 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE + "'", goalType10.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(optimizationDataArray18);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        double[] doubleArray2 = new double[] { '#', (short) 100 };
        double[] doubleArray3 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight4 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray3);
        org.apache.commons.math3.optim.nonlinear.vector.Target target5 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray3);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix6 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray2, doubleArray3);
        double[] doubleArray11 = new double[] { '#', (byte) 100, (short) 100 };
        double[] doubleArray15 = new double[] { '#', (byte) 100, (short) 100 };
        double[] doubleArray19 = new double[] { '#', (byte) 100, (short) 100 };
        double[] doubleArray23 = new double[] { '#', (byte) 100, (short) 100 };
        double[][] doubleArray24 = new double[][] { doubleArray11, doubleArray15, doubleArray19, doubleArray23 };
        double[][] doubleArray25 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray24);
        double[][] doubleArray26 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray25);
        try {
            org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray2, doubleArray25);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 12 != 2");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
        org.apache.commons.math3.optim.nonlinear.vector.Target target2 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix3 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray0);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix4 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
        org.apache.commons.math3.optim.nonlinear.vector.Target target2 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix3 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray0);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = diagonalMatrix3.power((int) ' ');
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = diagonalMatrix3.power((int) ' ');
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix12 = diagonalMatrix3.getSubMatrix((int) (byte) 0, 100, (int) '#', (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (0)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(realMatrix7);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        float float2 = org.apache.commons.math3.util.FastMath.min(0.0f, (float) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
        org.apache.commons.math3.optim.nonlinear.vector.Target target2 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix3 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray0);
        double double4 = diagonalMatrix3.getFrobeniusNorm();
        double[] doubleArray5 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight6 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray5);
        org.apache.commons.math3.optim.nonlinear.vector.Target target7 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray5);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix8 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5);
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = diagonalMatrix8.power((int) ' ');
        org.apache.commons.math3.linear.RealMatrix realMatrix12 = diagonalMatrix8.power((int) ' ');
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix13 = diagonalMatrix3.subtract(realMatrix12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertNotNull(realMatrix12);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
        org.apache.commons.math3.optim.nonlinear.vector.Target target2 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix3 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray0);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = diagonalMatrix3.power((int) ' ');
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix7 = diagonalMatrix3.getRowMatrix((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(realMatrix5);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        double[] doubleArray2 = new double[] { '#', (short) 100 };
        double[] doubleArray3 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight4 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray3);
        org.apache.commons.math3.optim.nonlinear.vector.Target target5 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray3);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix6 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray2, doubleArray3);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.mapAdd(0.0d);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor10 = null;
        try {
            double double11 = arrayRealVector7.walkInOptimizedOrder(realVectorPreservingVisitor10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(realVector9);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
        org.apache.commons.math3.optim.nonlinear.vector.Target target2 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix3 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray0);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = diagonalMatrix3.power((int) ' ');
        boolean boolean6 = diagonalMatrix3.isTransposable();
        double[] doubleArray9 = new double[] { (short) 1 };
        double[] doubleArray12 = new double[] { '#', (short) 100 };
        double[] doubleArray13 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight14 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray13);
        org.apache.commons.math3.optim.nonlinear.vector.Target target15 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray13);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix16 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray13);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray12, doubleArray13);
        org.apache.commons.math3.linear.RealVector realVector19 = arrayRealVector17.mapAdd(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray9, arrayRealVector17);
        try {
            diagonalMatrix3.setRowVector((int) ' ', (org.apache.commons.math3.linear.RealVector) arrayRealVector20);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (32)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector19);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        double[] doubleArray0 = null;
        double[] doubleArray1 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight2 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray1);
        org.apache.commons.math3.optim.nonlinear.vector.Target target3 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray1);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray1);
        org.apache.commons.math3.linear.RealMatrix realMatrix6 = diagonalMatrix4.power((int) ' ');
        double[] doubleArray7 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight8 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray7);
        org.apache.commons.math3.optim.nonlinear.vector.Target target9 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray7);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix10 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray7);
        double[] doubleArray11 = diagonalMatrix4.operate(doubleArray7);
        try {
            org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition12 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray0, doubleArray11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        long long2 = org.apache.commons.math3.util.FastMath.min((long) (byte) -1, (long) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.apache.commons.math3.util.Incrementor incrementor1 = new org.apache.commons.math3.util.Incrementor(0);
        try {
            incrementor1.incrementCount(1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MaxCountExceededException; message: illegal state: maximal count (0) exceeded");
        } catch (org.apache.commons.math3.exception.MaxCountExceededException e) {
        }
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
        org.apache.commons.math3.optim.nonlinear.vector.Target target2 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix3 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray0);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = diagonalMatrix3.power((int) ' ');
        try {
            diagonalMatrix3.setEntry((int) '#', (-1), (double) 'a');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: 97 is larger than the maximum (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(realMatrix5);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        double double1 = org.apache.commons.math3.util.FastMath.tanh(100.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        byte byte2 = org.apache.commons.math3.util.MathUtils.copySign((byte) 1, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        double double1 = org.apache.commons.math3.util.FastMath.ceil(10.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        int int2 = org.apache.commons.math3.util.FastMath.max((int) '4', (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.apache.commons.math3.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number) 100.0d);
        java.lang.Number number2 = notPositiveException1.getArgument();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 100.0d + "'", number2.equals(100.0d));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        double double1 = org.apache.commons.math3.util.FastMath.atan((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7853981633974483d + "'", double1 == 0.7853981633974483d);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        double double0 = org.apache.commons.math3.util.Precision.SAFE_MIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.2250738585072014E-308d + "'", double0 == 2.2250738585072014E-308d);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex6 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(0, 14890.0d, (double) (short) 10, (double) 100, (double) (byte) 0, (double) 97);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.ZeroException; message: zero not allowed here");
        } catch (org.apache.commons.math3.exception.ZeroException e) {
        }
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.apache.commons.math3.exception.MathInternalError mathInternalError0 = new org.apache.commons.math3.exception.MathInternalError();
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair> pointVectorValuePairConvergenceChecker0 = null;
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer gaussNewtonOptimizer1 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer(pointVectorValuePairConvergenceChecker0);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix2 = gaussNewtonOptimizer1.getWeight();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        long[] longArray6 = new long[] { (short) 1, (short) 10, (byte) 100, 10L, (short) 100, 1L };
        org.apache.commons.math3.util.MathArrays.checkNonNegative(longArray6);
        org.junit.Assert.assertNotNull(longArray6);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction0 = null;
        try {
            double double4 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.solve(univariateFunction0, 0.0d, 14890.0d, (double) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix0 = null;
        try {
            org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix1 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.apache.commons.math3.analysis.MultivariateFunction multivariateFunction0 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.ObjectiveFunction objectiveFunction1 = new org.apache.commons.math3.optim.nonlinear.scalar.ObjectiveFunction(multivariateFunction0);
        org.apache.commons.math3.analysis.MultivariateFunction multivariateFunction2 = objectiveFunction1.getObjectiveFunction();
        org.junit.Assert.assertNull(multivariateFunction2);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        double[] doubleArray0 = null;
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection1 = null;
        try {
            org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray0, orderDirection1, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.apache.commons.math3.linear.FieldMatrix<org.apache.commons.math3.fraction.Fraction> fractionFieldMatrix0 = null;
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix1 = org.apache.commons.math3.linear.MatrixUtils.fractionMatrixToRealMatrix(fractionFieldMatrix0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction0 = null;
        try {
            org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.verifyBracketing(univariateFunction0, 0.8414709848078965d, (double) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
        org.apache.commons.math3.optim.nonlinear.vector.Target target2 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix3 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray0);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = diagonalMatrix3.power((int) ' ');
        boolean boolean6 = diagonalMatrix3.isTransposable();
        diagonalMatrix3.setEntry(100, (int) ' ', (double) 0L);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor11 = null;
        try {
            double double12 = diagonalMatrix3.walkInOptimizedOrder(realMatrixChangingVisitor11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        long[] longArray1 = new long[] { (byte) 0 };
        long[] longArray3 = new long[] { (byte) 0 };
        long[] longArray5 = new long[] { (byte) 0 };
        long[] longArray7 = new long[] { (byte) 0 };
        long[] longArray9 = new long[] { (byte) 0 };
        long[] longArray11 = new long[] { (byte) 0 };
        long[][] longArray12 = new long[][] { longArray1, longArray3, longArray5, longArray7, longArray9, longArray11 };
        org.apache.commons.math3.util.MathArrays.checkRectangular(longArray12);
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(longArray9);
        org.junit.Assert.assertNotNull(longArray11);
        org.junit.Assert.assertNotNull(longArray12);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { (short) 1 };
        double[] doubleArray5 = new double[] { '#', (short) 100 };
        double[] doubleArray6 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight7 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray6);
        org.apache.commons.math3.optim.nonlinear.vector.Target target8 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray6);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix9 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5, doubleArray6);
        org.apache.commons.math3.linear.RealVector realVector12 = arrayRealVector10.mapAdd(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray2, arrayRealVector10);
        try {
            org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition15 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray0, doubleArray2, (double) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector12);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        try {
            org.apache.commons.math3.optim.univariate.SearchInterval searchInterval3 = new org.apache.commons.math3.optim.univariate.SearchInterval((double) 100L, 0.7853981633974483d, (double) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: 100 is larger than, or equal to, the maximum (0.785)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction0 = null;
        try {
            double[] doubleArray5 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.bracket(univariateFunction0, (double) ' ', (double) (byte) 1, (double) 100.0f, 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.IdentityPreconditioner identityPreconditioner0 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.IdentityPreconditioner();
        double[] doubleArray1 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight2 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray1);
        org.apache.commons.math3.optim.nonlinear.vector.Target target3 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray1);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray1);
        org.apache.commons.math3.linear.RealMatrix realMatrix6 = diagonalMatrix4.power((int) ' ');
        double[] doubleArray7 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight8 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray7);
        org.apache.commons.math3.optim.nonlinear.vector.Target target9 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray7);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix10 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray7);
        double[] doubleArray11 = diagonalMatrix4.operate(doubleArray7);
        double[] doubleArray12 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight13 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray12);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds14 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray11, doubleArray12);
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight16 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray15);
        double[] doubleArray17 = identityPreconditioner0.precondition(doubleArray12, doubleArray15);
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex18 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(doubleArray15);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.ZeroException; message: zero not allowed here");
        } catch (org.apache.commons.math3.exception.ZeroException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex2 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(0, (-0.8813735870195429d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.ZeroException; message: zero not allowed here");
        } catch (org.apache.commons.math3.exception.ZeroException e) {
        }
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        double double4 = org.apache.commons.math3.util.MathArrays.linearCombination(0.0d, (double) (-1), (double) 1076101151, (double) '#');
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 3.7663540285E10d + "'", double4 == 3.7663540285E10d);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        double[] doubleArray1 = new double[] { (short) 1 };
        double[] doubleArray4 = new double[] { '#', (short) 100 };
        double[] doubleArray5 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight6 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray5);
        org.apache.commons.math3.optim.nonlinear.vector.Target target7 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray5);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix8 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4, doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector11 = arrayRealVector9.mapAdd(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1, arrayRealVector9);
        org.apache.commons.math3.linear.RealVector realVector13 = null;
        try {
            org.apache.commons.math3.linear.RealVector realVector14 = arrayRealVector12.append(realVector13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector11);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex1 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex((int) (short) 10);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.IdentityPreconditioner identityPreconditioner2 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.IdentityPreconditioner();
        double[] doubleArray3 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight4 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray3);
        org.apache.commons.math3.optim.nonlinear.vector.Target target5 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray3);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix6 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = diagonalMatrix6.power((int) ' ');
        double[] doubleArray9 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight10 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray9);
        org.apache.commons.math3.optim.nonlinear.vector.Target target11 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray9);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix12 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray9);
        double[] doubleArray13 = diagonalMatrix6.operate(doubleArray9);
        double[] doubleArray14 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight15 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray14);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds16 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray13, doubleArray14);
        double[] doubleArray17 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight18 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray17);
        double[] doubleArray19 = identityPreconditioner2.precondition(doubleArray14, doubleArray17);
        try {
            multiDirectionalSimplex1.build(doubleArray14);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 10 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
        org.apache.commons.math3.optim.nonlinear.vector.Target target2 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix3 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray0);
        double double4 = diagonalMatrix3.getFrobeniusNorm();
        boolean boolean5 = diagonalMatrix3.isSquare();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor6 = null;
        try {
            double double7 = diagonalMatrix3.walkInColumnOrder(realMatrixChangingVisitor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        long long1 = org.apache.commons.math3.util.FastMath.abs((long) 100);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 100L + "'", long1 == 100L);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
        org.apache.commons.math3.optim.nonlinear.vector.Target target2 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix3 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray0);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = diagonalMatrix3.power((int) ' ');
        boolean boolean6 = diagonalMatrix3.isTransposable();
        diagonalMatrix3.setEntry(100, (int) ' ', (double) 0L);
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor11 = null;
        try {
            double double16 = diagonalMatrix3.walkInRowOrder(realMatrixPreservingVisitor11, (int) (byte) 100, (int) (short) 0, (int) (byte) 10, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula0 = org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES;
        org.apache.commons.math3.random.MersenneTwister mersenneTwister7 = new org.apache.commons.math3.random.MersenneTwister((int) '#');
        double double8 = mersenneTwister7.nextDouble();
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker12 = new org.apache.commons.math3.optim.SimpleValueChecker((double) (byte) 1, (double) (short) 100);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer13 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer((int) '#', (double) (short) 1, true, 36, 10, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister7, true, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker12);
        double double14 = simpleValueChecker12.getAbsoluteThreshold();
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver15 = new org.apache.commons.math3.analysis.solvers.BrentSolver();
        double double16 = brentSolver15.getRelativeAccuracy();
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer17 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker12, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver15);
        int int18 = nonLinearConjugateGradientOptimizer17.getMaxIterations();
        org.junit.Assert.assertTrue("'" + formula0 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES + "'", formula0.equals(org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.45805495157532494d + "'", double8 == 0.45805495157532494d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 100.0d + "'", double14 == 100.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0E-14d + "'", double16 == 1.0E-14d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2147483647 + "'", int18 == 2147483647);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula0 = org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES;
        org.apache.commons.math3.random.MersenneTwister mersenneTwister7 = new org.apache.commons.math3.random.MersenneTwister((int) '#');
        double double8 = mersenneTwister7.nextDouble();
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker12 = new org.apache.commons.math3.optim.SimpleValueChecker((double) (byte) 1, (double) (short) 100);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer13 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer((int) '#', (double) (short) 1, true, 36, 10, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister7, true, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker12);
        double double14 = simpleValueChecker12.getAbsoluteThreshold();
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver15 = new org.apache.commons.math3.analysis.solvers.BrentSolver();
        double double16 = brentSolver15.getRelativeAccuracy();
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer17 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker12, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver15);
        int int18 = nonLinearConjugateGradientOptimizer17.getIterations();
        org.junit.Assert.assertTrue("'" + formula0 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES + "'", formula0.equals(org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.45805495157532494d + "'", double8 == 0.45805495157532494d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 100.0d + "'", double14 == 100.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0E-14d + "'", double16 == 1.0E-14d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        try {
            org.apache.commons.math3.optim.univariate.SearchInterval searchInterval3 = new org.apache.commons.math3.optim.univariate.SearchInterval(0.0d, (double) 100, (double) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: -1 out of [0, 100] range");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
        org.apache.commons.math3.optim.nonlinear.vector.Target target2 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix3 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray0);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = diagonalMatrix3.power((int) ' ');
        double[] doubleArray6 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight7 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray6);
        org.apache.commons.math3.optim.nonlinear.vector.Target target8 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray6);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix9 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6);
        double[] doubleArray10 = diagonalMatrix3.operate(doubleArray6);
        boolean boolean11 = diagonalMatrix3.isSquare();
        try {
            double double14 = diagonalMatrix3.getEntry(52, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
        org.apache.commons.math3.optim.nonlinear.vector.Target target2 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix3 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray0);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = diagonalMatrix3.power((int) ' ');
        double[] doubleArray6 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight7 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray6);
        org.apache.commons.math3.optim.nonlinear.vector.Target target8 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray6);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix9 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6);
        double[] doubleArray10 = diagonalMatrix3.operate(doubleArray6);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight12 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray11);
        org.apache.commons.math3.optim.nonlinear.vector.Target target13 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray11);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix14 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray11);
        org.apache.commons.math3.linear.RealMatrix realMatrix16 = diagonalMatrix14.power((int) ' ');
        double[] doubleArray17 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight18 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray17);
        org.apache.commons.math3.optim.nonlinear.vector.Target target19 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray17);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix20 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray17);
        double[] doubleArray21 = diagonalMatrix14.operate(doubleArray17);
        double[] doubleArray22 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight23 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray22);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds24 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray21, doubleArray22);
        double[] doubleArray25 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight26 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray25);
        org.apache.commons.math3.optim.nonlinear.vector.Target target27 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray25);
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray22, doubleArray25);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix30 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray22, true);
        try {
            double double31 = org.apache.commons.math3.util.MathArrays.linearCombination(doubleArray10, doubleArray22);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray28);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        double[] doubleArray2 = new double[] { '#', (short) 100 };
        double[] doubleArray3 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight4 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray3);
        org.apache.commons.math3.optim.nonlinear.vector.Target target5 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray3);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix6 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray2, doubleArray3);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.mapAdd(0.0d);
        double[] doubleArray11 = new double[] { (short) 1 };
        double[] doubleArray14 = new double[] { '#', (short) 100 };
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight16 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray15);
        org.apache.commons.math3.optim.nonlinear.vector.Target target17 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray15);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray15);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14, doubleArray15);
        org.apache.commons.math3.linear.RealVector realVector21 = arrayRealVector19.mapAdd(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray11, arrayRealVector19);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = arrayRealVector7.add((org.apache.commons.math3.linear.RealVector) arrayRealVector22);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 2 != 3");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realVector21);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.PopulationSize populationSize1 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.PopulationSize(36);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
        org.apache.commons.math3.linear.RealMatrix realMatrix2 = weight1.getWeight();
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(realMatrix2);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
        org.apache.commons.math3.optim.nonlinear.vector.Target target2 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix3 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray0);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = diagonalMatrix3.power((int) ' ');
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = diagonalMatrix3.power((int) ' ');
        double[] doubleArray8 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight9 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray8);
        org.apache.commons.math3.optim.nonlinear.vector.Target target10 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray8);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix11 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray8);
        org.apache.commons.math3.linear.RealMatrix realMatrix13 = diagonalMatrix11.power((int) ' ');
        double[] doubleArray14 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight15 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray14);
        org.apache.commons.math3.optim.nonlinear.vector.Target target16 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray14);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix17 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray14);
        double[] doubleArray18 = diagonalMatrix11.operate(doubleArray14);
        double[] doubleArray19 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight20 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray19);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds21 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray18, doubleArray19);
        double[] doubleArray22 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight23 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray22);
        org.apache.commons.math3.optim.nonlinear.vector.Target target24 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray22);
        double[] doubleArray25 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray19, doubleArray22);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix27 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray19, true);
        org.apache.commons.math3.linear.RealMatrix realMatrix28 = diagonalMatrix3.preMultiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix27);
        java.lang.String str29 = diagonalMatrix27.toString();
        org.apache.commons.math3.linear.RealMatrix realMatrix30 = null;
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix31 = diagonalMatrix27.multiply(realMatrix30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "DiagonalMatrix{}" + "'", str29.equals("DiagonalMatrix{}"));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException0 = new org.apache.commons.math3.exception.NullArgumentException();
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.apache.commons.math3.util.MathUtils.checkFinite((double) ' ');
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.MatrixUtils.DEFAULT_FORMAT;
        java.lang.String str1 = realMatrixFormat0.getPrefix();
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "{" + "'", str1.equals("{"));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math3.random.MersenneTwister((int) '#');
        mersenneTwister1.clear();
        boolean boolean3 = mersenneTwister1.nextBoolean();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.IdentityPreconditioner identityPreconditioner0 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.IdentityPreconditioner();
        double[] doubleArray1 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight2 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray1);
        org.apache.commons.math3.optim.nonlinear.vector.Target target3 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray1);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray1);
        org.apache.commons.math3.linear.RealMatrix realMatrix6 = diagonalMatrix4.power((int) ' ');
        double[] doubleArray7 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight8 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray7);
        org.apache.commons.math3.optim.nonlinear.vector.Target target9 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray7);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix10 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray7);
        double[] doubleArray11 = diagonalMatrix4.operate(doubleArray7);
        double[] doubleArray12 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight13 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray12);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds14 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray11, doubleArray12);
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight16 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray15);
        double[] doubleArray17 = identityPreconditioner0.precondition(doubleArray12, doubleArray15);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection18 = null;
        try {
            boolean boolean20 = org.apache.commons.math3.util.MathArrays.isMonotonic(doubleArray15, orderDirection18, true);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex1 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex((int) (short) 10);
        double[] doubleArray2 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight3 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray2);
        org.apache.commons.math3.optim.nonlinear.vector.Target target4 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray2);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix5 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray2);
        try {
            multiDirectionalSimplex1.build(doubleArray2);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 10 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.apache.commons.math3.linear.RealMatrix realMatrix1 = org.apache.commons.math3.linear.MatrixUtils.createRealIdentityMatrix((int) (short) 100);
        org.junit.Assert.assertNotNull(realMatrix1);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.apache.commons.math3.analysis.function.Sinc sinc0 = new org.apache.commons.math3.analysis.function.Sinc();
        org.apache.commons.math3.analysis.differentiation.DerivativeStructure derivativeStructure1 = null;
        try {
            org.apache.commons.math3.analysis.differentiation.DerivativeStructure derivativeStructure2 = sinc0.value(derivativeStructure1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        double double2 = org.apache.commons.math3.util.FastMath.pow((-2.777777706332879E-4d), 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-2.777777706332879E-4d) + "'", double2 == (-2.777777706332879E-4d));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        double[] doubleArray2 = new double[] { '#', (short) 100 };
        double[] doubleArray3 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight4 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray3);
        org.apache.commons.math3.optim.nonlinear.vector.Target target5 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray3);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix6 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray2, doubleArray3);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.mapAdd(0.0d);
        double[] doubleArray10 = arrayRealVector7.toArray();
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction11 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = arrayRealVector7.mapToSelf(univariateFunction11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(doubleArray10);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        long long2 = org.apache.commons.math3.util.FastMath.min((long) (byte) 100, (long) (short) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        double[] doubleArray2 = new double[] { '#', (short) 100 };
        double[] doubleArray3 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight4 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray3);
        org.apache.commons.math3.optim.nonlinear.vector.Target target5 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray3);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix6 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray2, doubleArray3);
        double[] doubleArray8 = arrayRealVector7.toArray();
        org.apache.commons.math3.linear.RealVector realVector9 = null;
        try {
            org.apache.commons.math3.linear.RealVector realVector10 = arrayRealVector7.append(realVector9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
        org.apache.commons.math3.optim.nonlinear.vector.Target target2 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix3 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray0);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = diagonalMatrix3.power((int) ' ');
        double[] doubleArray6 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight7 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray6);
        org.apache.commons.math3.optim.nonlinear.vector.Target target8 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray6);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix9 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6);
        double[] doubleArray10 = diagonalMatrix3.operate(doubleArray6);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight12 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray11);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds13 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray10, doubleArray11);
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex18 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray10, (-1.0d), (double) 1L, (double) (-1L), (double) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.ZeroException; message: zero not allowed here");
        } catch (org.apache.commons.math3.exception.ZeroException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat6 = new org.apache.commons.math3.linear.RealMatrixFormat(", ", ", ", ", ", "", "hi!", ", ");
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = realMatrixFormat6.parse(", ");
        org.junit.Assert.assertNull(realMatrix8);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
        org.apache.commons.math3.optim.nonlinear.vector.Target target2 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix3 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray0);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = diagonalMatrix3.power((int) ' ');
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = diagonalMatrix3.power((int) ' ');
        double[] doubleArray8 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight9 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray8);
        org.apache.commons.math3.optim.nonlinear.vector.Target target10 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray8);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix11 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray8);
        org.apache.commons.math3.linear.RealMatrix realMatrix13 = diagonalMatrix11.power((int) ' ');
        double[] doubleArray14 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight15 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray14);
        org.apache.commons.math3.optim.nonlinear.vector.Target target16 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray14);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix17 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray14);
        double[] doubleArray18 = diagonalMatrix11.operate(doubleArray14);
        double[] doubleArray19 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight20 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray19);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds21 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray18, doubleArray19);
        double[] doubleArray22 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight23 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray22);
        org.apache.commons.math3.optim.nonlinear.vector.Target target24 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray22);
        double[] doubleArray25 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray19, doubleArray22);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix27 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray19, true);
        org.apache.commons.math3.linear.RealMatrix realMatrix28 = diagonalMatrix3.preMultiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix27);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor29 = null;
        try {
            double double30 = diagonalMatrix3.walkInColumnOrder(realMatrixChangingVisitor29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realMatrix28);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        double double1 = org.apache.commons.math3.util.FastMath.abs(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        java.lang.String[] strArray5 = new java.lang.String[] { ",", "hi!", ",", ", ", "hi!" };
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection6 = null;
        try {
            boolean boolean8 = org.apache.commons.math3.util.MathArrays.isMonotonic(strArray5, orderDirection6, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        double double1 = org.apache.commons.math3.util.FastMath.tan(2.2250738585072014E-308d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.2250738585072014E-308d + "'", double1 == 2.2250738585072014E-308d);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
        org.apache.commons.math3.optim.nonlinear.vector.Target target2 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix3 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray0);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = diagonalMatrix3.power((int) ' ');
        double[] doubleArray6 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight7 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray6);
        org.apache.commons.math3.optim.nonlinear.vector.Target target8 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray6);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix9 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6);
        double[] doubleArray10 = diagonalMatrix3.operate(doubleArray6);
        boolean boolean11 = diagonalMatrix3.isSquare();
        double[] doubleArray13 = new double[] { (short) 1 };
        double[] doubleArray16 = new double[] { '#', (short) 100 };
        double[] doubleArray17 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight18 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray17);
        org.apache.commons.math3.optim.nonlinear.vector.Target target19 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray17);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix20 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray16, doubleArray17);
        org.apache.commons.math3.linear.RealVector realVector23 = arrayRealVector21.mapAdd(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray13, arrayRealVector21);
        try {
            double[] doubleArray25 = diagonalMatrix3.operate(doubleArray13);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(realVector23);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair> pointVectorValuePairConvergenceChecker0 = null;
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer gaussNewtonOptimizer1 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer(pointVectorValuePairConvergenceChecker0);
        double[] doubleArray2 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight3 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray2);
        org.apache.commons.math3.optim.nonlinear.vector.Target target4 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray2);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix5 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray2);
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = diagonalMatrix5.power((int) ' ');
        double[] doubleArray8 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight9 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray8);
        org.apache.commons.math3.optim.nonlinear.vector.Target target10 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray8);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix11 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray8);
        double[] doubleArray12 = diagonalMatrix5.operate(doubleArray8);
        double[] doubleArray13 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight14 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray13);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds15 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray12, doubleArray13);
        double[] doubleArray16 = simpleBounds15.getLower();
        try {
            double[] doubleArray18 = gaussNewtonOptimizer1.computeSigma(doubleArray16, (double) 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
        org.apache.commons.math3.optim.nonlinear.vector.Target target2 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix3 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray0);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = diagonalMatrix3.power((int) ' ');
        double[] doubleArray6 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight7 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray6);
        org.apache.commons.math3.optim.nonlinear.vector.Target target8 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray6);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix9 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6);
        double[] doubleArray10 = diagonalMatrix3.operate(doubleArray6);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight12 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray11);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds13 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray10, doubleArray11);
        double[] doubleArray14 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight15 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray14);
        org.apache.commons.math3.optim.nonlinear.vector.Target target16 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray14);
        double[] doubleArray17 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray11, doubleArray14);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix19 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray11, true);
        double[] doubleArray20 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight21 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray20);
        org.apache.commons.math3.optim.nonlinear.vector.Target target22 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray20);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray20);
        org.apache.commons.math3.linear.RealMatrix realMatrix25 = diagonalMatrix23.power((int) ' ');
        boolean boolean26 = diagonalMatrix23.isTransposable();
        int int27 = diagonalMatrix23.getRowDimension();
        double[][] doubleArray28 = diagonalMatrix23.getData();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix29 = diagonalMatrix19.subtract((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(realMatrix25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(doubleArray28);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
        org.apache.commons.math3.optim.nonlinear.vector.Target target2 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix3 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray0);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = diagonalMatrix3.power((int) ' ');
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = diagonalMatrix3.power((int) ' ');
        double[] doubleArray8 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight9 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray8);
        org.apache.commons.math3.optim.nonlinear.vector.Target target10 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray8);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix11 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray8);
        org.apache.commons.math3.linear.RealMatrix realMatrix13 = diagonalMatrix11.power((int) ' ');
        double[] doubleArray14 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight15 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray14);
        org.apache.commons.math3.optim.nonlinear.vector.Target target16 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray14);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix17 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray14);
        double[] doubleArray18 = diagonalMatrix11.operate(doubleArray14);
        double[] doubleArray19 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight20 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray19);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds21 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray18, doubleArray19);
        double[] doubleArray22 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight23 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray22);
        org.apache.commons.math3.optim.nonlinear.vector.Target target24 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray22);
        double[] doubleArray25 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray19, doubleArray22);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix27 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray19, true);
        org.apache.commons.math3.linear.RealMatrix realMatrix28 = diagonalMatrix3.preMultiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix27);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSubMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) realMatrix28, (int) (short) 0, (int) (short) 1, 52, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (0)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realMatrix28);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable5 = null;
        double[] doubleArray9 = new double[] { '#', (byte) 100, (short) 100 };
        double[] doubleArray13 = new double[] { '#', (byte) 100, (short) 100 };
        double[] doubleArray17 = new double[] { '#', (byte) 100, (short) 100 };
        double[] doubleArray21 = new double[] { '#', (byte) 100, (short) 100 };
        double[][] doubleArray22 = new double[][] { doubleArray9, doubleArray13, doubleArray17, doubleArray21 };
        double[][] doubleArray23 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray22);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException24 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable5, (java.lang.Object[]) doubleArray23);
        org.apache.commons.math3.exception.NoBracketingException noBracketingException25 = new org.apache.commons.math3.exception.NoBracketingException(localizable0, (double) 10L, (double) (byte) -1, (double) 1, (double) 1, (java.lang.Object[]) doubleArray23);
        double double26 = noBracketingException25.getHi();
        double double27 = noBracketingException25.getFLo();
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + (-1.0d) + "'", double26 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 1.0d + "'", double27 == 1.0d);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
        org.apache.commons.math3.optim.nonlinear.vector.Target target2 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix3 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray0);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = diagonalMatrix3.power((int) ' ');
        double[] doubleArray6 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight7 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray6);
        org.apache.commons.math3.optim.nonlinear.vector.Target target8 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray6);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix9 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6);
        double[] doubleArray10 = diagonalMatrix3.operate(doubleArray6);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix11 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6);
        double[] doubleArray13 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight14 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray13);
        org.apache.commons.math3.optim.nonlinear.vector.Target target15 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray13);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix16 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray13);
        org.apache.commons.math3.linear.RealMatrix realMatrix18 = diagonalMatrix16.power((int) ' ');
        org.apache.commons.math3.linear.RealMatrix realMatrix20 = diagonalMatrix16.power((int) ' ');
        double[] doubleArray21 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight22 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray21);
        org.apache.commons.math3.optim.nonlinear.vector.Target target23 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray21);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix24 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray21);
        org.apache.commons.math3.linear.RealMatrix realMatrix26 = diagonalMatrix24.power((int) ' ');
        double[] doubleArray27 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight28 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray27);
        org.apache.commons.math3.optim.nonlinear.vector.Target target29 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray27);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix30 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray27);
        double[] doubleArray31 = diagonalMatrix24.operate(doubleArray27);
        double[] doubleArray32 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight33 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray32);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds34 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray31, doubleArray32);
        double[] doubleArray35 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight36 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray35);
        org.apache.commons.math3.optim.nonlinear.vector.Target target37 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray35);
        double[] doubleArray38 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray32, doubleArray35);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix40 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray32, true);
        org.apache.commons.math3.linear.RealMatrix realMatrix41 = diagonalMatrix16.preMultiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix40);
        org.apache.commons.math3.linear.RealMatrix realMatrix43 = diagonalMatrix40.power((int) (byte) 100);
        try {
            diagonalMatrix11.setRowMatrix(1, (org.apache.commons.math3.linear.RealMatrix) diagonalMatrix40);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realMatrix18);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(realMatrix26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(realMatrix41);
        org.junit.Assert.assertNotNull(realMatrix43);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        java.text.ParsePosition parsePosition2 = null;
        try {
            boolean boolean3 = org.apache.commons.math3.util.CompositeFormat.parseFixedstring("{", "", parsePosition2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        double double2 = org.apache.commons.math3.util.MathUtils.normalizeAngle(2.2250738585072014E-308d, 1.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.2250738585072014E-308d + "'", double2 == 2.2250738585072014E-308d);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix1 = new org.apache.commons.math3.linear.DiagonalMatrix(125);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.IdentityPreconditioner identityPreconditioner3 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.IdentityPreconditioner();
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight5 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray4);
        org.apache.commons.math3.optim.nonlinear.vector.Target target6 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray4);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray4);
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = diagonalMatrix7.power((int) ' ');
        double[] doubleArray10 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight11 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray10);
        org.apache.commons.math3.optim.nonlinear.vector.Target target12 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray10);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix13 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray10);
        double[] doubleArray14 = diagonalMatrix7.operate(doubleArray10);
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight16 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray15);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds17 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray14, doubleArray15);
        double[] doubleArray18 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight19 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray18);
        double[] doubleArray20 = identityPreconditioner3.precondition(doubleArray15, doubleArray18);
        try {
            diagonalMatrix1.setRow(0, doubleArray15);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 1x0 but expected 1x125");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
        org.apache.commons.math3.optim.nonlinear.vector.Target target2 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix3 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray0);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = diagonalMatrix3.power((int) ' ');
        double[] doubleArray6 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight7 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray6);
        org.apache.commons.math3.optim.nonlinear.vector.Target target8 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray6);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix9 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6);
        double[] doubleArray10 = diagonalMatrix3.operate(doubleArray6);
        boolean boolean11 = diagonalMatrix3.isSquare();
        double[][] doubleArray12 = diagonalMatrix3.getData();
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor13 = null;
        try {
            double double14 = diagonalMatrix3.walkInRowOrder(realMatrixPreservingVisitor13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(doubleArray12);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math3.random.MersenneTwister((int) '#');
        double double7 = mersenneTwister6.nextDouble();
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker11 = new org.apache.commons.math3.optim.SimpleValueChecker((double) (byte) 1, (double) (short) 100);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer12 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer((int) '#', (double) (short) 1, true, 36, 10, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister6, true, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker11);
        java.util.List<java.lang.Double> doubleList13 = cMAESOptimizer12.getStatisticsSigmaHistory();
        java.util.List<org.apache.commons.math3.linear.RealMatrix> realMatrixList14 = cMAESOptimizer12.getStatisticsMeanHistory();
        double[] doubleArray15 = cMAESOptimizer12.getUpperBound();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.45805495157532494d + "'", double7 == 0.45805495157532494d);
        org.junit.Assert.assertNotNull(doubleList13);
        org.junit.Assert.assertNotNull(realMatrixList14);
        org.junit.Assert.assertNull(doubleArray15);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        double double1 = org.apache.commons.math3.util.FastMath.abs((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1 == 100.0d);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
        org.apache.commons.math3.optim.nonlinear.vector.Target target2 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix3 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray0);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = diagonalMatrix3.power((int) ' ');
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = diagonalMatrix3.power((int) ' ');
        double[] doubleArray8 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight9 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray8);
        org.apache.commons.math3.optim.nonlinear.vector.Target target10 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray8);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix11 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray8);
        org.apache.commons.math3.linear.RealMatrix realMatrix13 = diagonalMatrix11.power((int) ' ');
        double[] doubleArray14 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight15 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray14);
        org.apache.commons.math3.optim.nonlinear.vector.Target target16 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray14);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix17 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray14);
        double[] doubleArray18 = diagonalMatrix11.operate(doubleArray14);
        double[] doubleArray19 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight20 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray19);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds21 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray18, doubleArray19);
        double[] doubleArray22 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight23 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray22);
        org.apache.commons.math3.optim.nonlinear.vector.Target target24 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray22);
        double[] doubleArray25 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray19, doubleArray22);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix27 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray19, true);
        org.apache.commons.math3.linear.RealMatrix realMatrix28 = diagonalMatrix3.preMultiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix27);
        java.lang.String str29 = diagonalMatrix27.toString();
        double[] doubleArray30 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight31 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray30);
        org.apache.commons.math3.optim.nonlinear.vector.Target target32 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray30);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix33 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray30);
        org.apache.commons.math3.linear.RealMatrix realMatrix35 = diagonalMatrix33.power((int) ' ');
        double[] doubleArray36 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight37 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray36);
        org.apache.commons.math3.optim.nonlinear.vector.Target target38 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray36);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix39 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray36);
        double[] doubleArray40 = diagonalMatrix33.operate(doubleArray36);
        double[] doubleArray41 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight42 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray41);
        org.apache.commons.math3.optim.nonlinear.vector.Target target43 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray41);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix44 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray41);
        double[] doubleArray45 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray40, doubleArray41);
        double[] doubleArray46 = diagonalMatrix27.operate(doubleArray41);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix48 = diagonalMatrix27.scalarAdd(0.45805495157532494d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "DiagonalMatrix{}" + "'", str29.equals("DiagonalMatrix{}"));
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(realMatrix35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        int int1 = org.apache.commons.math3.util.FastMath.getExponent((float) (byte) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        double[] doubleArray2 = new double[] { '#', (short) 100 };
        double[] doubleArray3 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight4 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray3);
        org.apache.commons.math3.optim.nonlinear.vector.Target target5 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray3);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix6 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray2, doubleArray3);
        double[] doubleArray8 = arrayRealVector7.toArray();
        org.apache.commons.math3.linear.RealVector realVector11 = arrayRealVector7.getSubVector(0, 0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realVector11);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        double[] doubleArray0 = null;
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix1 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable5 = null;
        double[] doubleArray9 = new double[] { '#', (byte) 100, (short) 100 };
        double[] doubleArray13 = new double[] { '#', (byte) 100, (short) 100 };
        double[] doubleArray17 = new double[] { '#', (byte) 100, (short) 100 };
        double[] doubleArray21 = new double[] { '#', (byte) 100, (short) 100 };
        double[][] doubleArray22 = new double[][] { doubleArray9, doubleArray13, doubleArray17, doubleArray21 };
        double[][] doubleArray23 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray22);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException24 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable5, (java.lang.Object[]) doubleArray23);
        org.apache.commons.math3.exception.NoBracketingException noBracketingException25 = new org.apache.commons.math3.exception.NoBracketingException(localizable0, (double) 10L, (double) (byte) -1, (double) 1, (double) 1, (java.lang.Object[]) doubleArray23);
        double[][] doubleArray26 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray26);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex6 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(36, 100.0d, (-1.0d), (double) ' ', 3.7663540285E10d, 0.7853981633974483d);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        int int1 = org.apache.commons.math3.util.FastMath.getExponent(0.0d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1023) + "'", int1 == (-1023));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        double[] doubleArray2 = new double[] { '#', (short) 100 };
        double[] doubleArray3 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight4 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray3);
        org.apache.commons.math3.optim.nonlinear.vector.Target target5 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray3);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix6 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray2, doubleArray3);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.mapAdd(0.0d);
        double[] doubleArray10 = arrayRealVector7.toArray();
        double[] doubleArray12 = new double[] { (short) 1 };
        double[] doubleArray15 = new double[] { '#', (short) 100 };
        double[] doubleArray16 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight17 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray16);
        org.apache.commons.math3.optim.nonlinear.vector.Target target18 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray16);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix19 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray16);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray15, doubleArray16);
        org.apache.commons.math3.linear.RealVector realVector22 = arrayRealVector20.mapAdd(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray12, arrayRealVector20);
        double double24 = arrayRealVector23.getL1Norm();
        double[] doubleArray28 = new double[] { (short) 1 };
        double[] doubleArray31 = new double[] { '#', (short) 100 };
        double[] doubleArray32 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight33 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray32);
        org.apache.commons.math3.optim.nonlinear.vector.Target target34 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray32);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix35 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray32);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray31, doubleArray32);
        org.apache.commons.math3.linear.RealVector realVector38 = arrayRealVector36.mapAdd(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray28, arrayRealVector36);
        org.apache.commons.math3.linear.RealVector realVector41 = arrayRealVector39.mapAdd((double) (byte) 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = arrayRealVector23.combine((double) 100L, (double) (byte) 1, (org.apache.commons.math3.linear.RealVector) arrayRealVector39);
        try {
            double double43 = arrayRealVector7.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector42);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 2 != 3");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 136.0d + "'", double24 == 136.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(realVector38);
        org.junit.Assert.assertNotNull(realVector41);
        org.junit.Assert.assertNotNull(arrayRealVector42);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        java.text.NumberFormat numberFormat1 = null;
        java.text.ParsePosition parsePosition2 = null;
        try {
            java.lang.Number number3 = org.apache.commons.math3.util.CompositeFormat.parseNumber("", numberFormat1, parsePosition2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.IdentityPreconditioner identityPreconditioner0 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.IdentityPreconditioner();
        double[] doubleArray1 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight2 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray1);
        org.apache.commons.math3.optim.nonlinear.vector.Target target3 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray1);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray1);
        org.apache.commons.math3.linear.RealMatrix realMatrix6 = diagonalMatrix4.power((int) ' ');
        double[] doubleArray7 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight8 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray7);
        org.apache.commons.math3.optim.nonlinear.vector.Target target9 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray7);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix10 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray7);
        double[] doubleArray11 = diagonalMatrix4.operate(doubleArray7);
        double[] doubleArray12 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight13 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray12);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds14 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray11, doubleArray12);
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight16 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray15);
        double[] doubleArray17 = identityPreconditioner0.precondition(doubleArray12, doubleArray15);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix18 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray15);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(0, 100.0d);
        try {
            arrayRealVector2.unitize();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException; message: zero norm");
        } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
        }
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
        org.apache.commons.math3.optim.nonlinear.vector.Target target2 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix3 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray0);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = diagonalMatrix3.power((int) ' ');
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = diagonalMatrix3.power((int) ' ');
        double[] doubleArray8 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight9 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray8);
        org.apache.commons.math3.optim.nonlinear.vector.Target target10 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray8);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix11 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray8);
        org.apache.commons.math3.linear.RealMatrix realMatrix13 = diagonalMatrix11.power((int) ' ');
        double[] doubleArray14 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight15 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray14);
        org.apache.commons.math3.optim.nonlinear.vector.Target target16 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray14);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix17 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray14);
        double[] doubleArray18 = diagonalMatrix11.operate(doubleArray14);
        double[] doubleArray19 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight20 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray19);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds21 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray18, doubleArray19);
        double[] doubleArray22 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight23 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray22);
        org.apache.commons.math3.optim.nonlinear.vector.Target target24 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray22);
        double[] doubleArray25 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray19, doubleArray22);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix27 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray19, true);
        org.apache.commons.math3.linear.RealMatrix realMatrix28 = diagonalMatrix3.preMultiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix27);
        java.lang.String str29 = diagonalMatrix27.toString();
        double[] doubleArray30 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight31 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray30);
        org.apache.commons.math3.optim.nonlinear.vector.Target target32 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray30);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix33 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray30);
        org.apache.commons.math3.linear.RealMatrix realMatrix35 = diagonalMatrix33.power((int) ' ');
        double[] doubleArray36 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight37 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray36);
        org.apache.commons.math3.optim.nonlinear.vector.Target target38 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray36);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix39 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray36);
        double[] doubleArray40 = diagonalMatrix33.operate(doubleArray36);
        double[] doubleArray41 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight42 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray41);
        org.apache.commons.math3.optim.nonlinear.vector.Target target43 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray41);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix44 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray41);
        double[] doubleArray45 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray40, doubleArray41);
        double[] doubleArray46 = diagonalMatrix27.operate(doubleArray41);
        java.io.ObjectOutputStream objectOutputStream47 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.serializeRealMatrix((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix27, objectOutputStream47);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "DiagonalMatrix{}" + "'", str29.equals("DiagonalMatrix{}"));
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(realMatrix35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker2 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer powellOptimizer3 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer((double) 10L, (double) (byte) 10, pointValuePairConvergenceChecker2);
        double[] doubleArray4 = powellOptimizer3.getStartPoint();
        org.junit.Assert.assertNull(doubleArray4);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        double[] doubleArray1 = new double[] { (short) 1 };
        double[] doubleArray4 = new double[] { '#', (short) 100 };
        double[] doubleArray5 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight6 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray5);
        org.apache.commons.math3.optim.nonlinear.vector.Target target7 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray5);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix8 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4, doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector11 = arrayRealVector9.mapAdd(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1, arrayRealVector9);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(0, 100.0d);
        try {
            double double16 = arrayRealVector12.cosine((org.apache.commons.math3.linear.RealVector) arrayRealVector15);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException; message: zero norm");
        } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector11);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        try {
            org.apache.commons.math3.optim.MaxIter maxIter1 = new org.apache.commons.math3.optim.MaxIter((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 0.45805495157532494d, 0.7853981633974483d, 1.1752011936438014d, 0.45805495157532494d, 3.7663540285E10d, (-0.8813735870195429d) };
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, (-1), (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        float float2 = org.apache.commons.math3.util.FastMath.copySign((float) (byte) 10, (float) 10L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction0 = null;
        try {
            double[] doubleArray5 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.bracket(univariateFunction0, 52.0d, 0.0d, (double) 36, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker2 = new org.apache.commons.math3.optim.SimpleValueChecker((double) (short) 10, 0.0d);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        double[] doubleArray1 = new double[] { (short) 1 };
        double[] doubleArray4 = new double[] { '#', (short) 100 };
        double[] doubleArray5 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight6 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray5);
        org.apache.commons.math3.optim.nonlinear.vector.Target target7 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray5);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix8 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4, doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector11 = arrayRealVector9.mapAdd(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1, arrayRealVector9);
        double[] doubleArray13 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight14 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray13);
        org.apache.commons.math3.optim.nonlinear.vector.Target target15 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray13);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix16 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray13);
        org.apache.commons.math3.linear.RealMatrix realMatrix18 = diagonalMatrix16.power((int) ' ');
        double[] doubleArray19 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight20 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray19);
        org.apache.commons.math3.optim.nonlinear.vector.Target target21 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray19);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix22 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray19);
        double[] doubleArray23 = diagonalMatrix16.operate(doubleArray19);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray23);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector12, arrayRealVector24);
        java.io.ObjectOutputStream objectOutputStream26 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.serializeRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector12, objectOutputStream26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realMatrix18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray23);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
        org.apache.commons.math3.optim.nonlinear.vector.Target target2 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix3 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray0);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = diagonalMatrix3.power((int) ' ');
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = diagonalMatrix3.power((int) ' ');
        double[] doubleArray8 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight9 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray8);
        org.apache.commons.math3.optim.nonlinear.vector.Target target10 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray8);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix11 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray8);
        org.apache.commons.math3.linear.RealMatrix realMatrix13 = diagonalMatrix11.power((int) ' ');
        double[] doubleArray14 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight15 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray14);
        org.apache.commons.math3.optim.nonlinear.vector.Target target16 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray14);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix17 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray14);
        double[] doubleArray18 = diagonalMatrix11.operate(doubleArray14);
        double[] doubleArray19 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight20 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray19);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds21 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray18, doubleArray19);
        double[] doubleArray22 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight23 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray22);
        org.apache.commons.math3.optim.nonlinear.vector.Target target24 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray22);
        double[] doubleArray25 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray19, doubleArray22);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix27 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray19, true);
        org.apache.commons.math3.linear.RealMatrix realMatrix28 = diagonalMatrix3.preMultiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix27);
        java.lang.String str29 = diagonalMatrix27.toString();
        try {
            diagonalMatrix27.addToEntry((int) '4', (int) (short) -1, (double) 97);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: 97 is larger than the maximum (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "DiagonalMatrix{}" + "'", str29.equals("DiagonalMatrix{}"));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math3.random.MersenneTwister(1076101151);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
        org.apache.commons.math3.optim.nonlinear.vector.Target target2 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix3 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray0);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = diagonalMatrix3.power((int) ' ');
        boolean boolean6 = diagonalMatrix3.isTransposable();
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = diagonalMatrix3.copy();
        try {
            org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix3, (double) 1.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(realMatrix7);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
        org.apache.commons.math3.optim.nonlinear.vector.Target target2 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix3 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray0);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = diagonalMatrix3.power((int) ' ');
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = diagonalMatrix3.power((int) ' ');
        double[] doubleArray8 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight9 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray8);
        org.apache.commons.math3.optim.nonlinear.vector.Target target10 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray8);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix11 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray8);
        org.apache.commons.math3.linear.RealMatrix realMatrix13 = diagonalMatrix11.power((int) ' ');
        double[] doubleArray14 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight15 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray14);
        org.apache.commons.math3.optim.nonlinear.vector.Target target16 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray14);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix17 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray14);
        double[] doubleArray18 = diagonalMatrix11.operate(doubleArray14);
        double[] doubleArray19 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight20 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray19);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds21 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray18, doubleArray19);
        double[] doubleArray22 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight23 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray22);
        org.apache.commons.math3.optim.nonlinear.vector.Target target24 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray22);
        double[] doubleArray25 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray19, doubleArray22);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix27 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray19, true);
        org.apache.commons.math3.linear.RealMatrix realMatrix28 = diagonalMatrix3.preMultiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix27);
        org.apache.commons.math3.linear.RealMatrix realMatrix30 = diagonalMatrix27.power((int) (byte) 100);
        double[] doubleArray33 = new double[] { (short) 1 };
        double[] doubleArray36 = new double[] { '#', (short) 100 };
        double[] doubleArray37 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight38 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray37);
        org.apache.commons.math3.optim.nonlinear.vector.Target target39 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray37);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix40 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray37);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray36, doubleArray37);
        org.apache.commons.math3.linear.RealVector realVector43 = arrayRealVector41.mapAdd(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray33, arrayRealVector41);
        try {
            diagonalMatrix27.setColumnVector((int) (short) -1, (org.apache.commons.math3.linear.RealVector) arrayRealVector41);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(realVector43);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat6 = org.apache.commons.math3.linear.MatrixUtils.OCTAVE_FORMAT;
        java.text.NumberFormat numberFormat7 = realMatrixFormat6.getFormat();
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat8 = new org.apache.commons.math3.linear.RealMatrixFormat(", ", "hi!", "{", "", ", ", "DiagonalMatrix{}", numberFormat7);
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat9 = new org.apache.commons.math3.linear.RealMatrixFormat(numberFormat7);
        java.lang.String str10 = realMatrixFormat9.getColumnSeparator();
        org.junit.Assert.assertNotNull(realMatrixFormat6);
        org.junit.Assert.assertNotNull(numberFormat7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "," + "'", str10.equals(","));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
        org.apache.commons.math3.optim.nonlinear.vector.Target target2 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix3 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray0);
        double double4 = diagonalMatrix3.getFrobeniusNorm();
        boolean boolean5 = diagonalMatrix3.isSquare();
        try {
            diagonalMatrix3.setEntry(0, 125, (double) 10L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: 10 is larger than the maximum (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.apache.commons.math3.linear.RealMatrix realMatrix2 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix((int) (short) 100, (int) ' ');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        try {
            org.apache.commons.math3.linear.MatrixUtils.solveLowerTriangularSystem(realMatrix2, (org.apache.commons.math3.linear.RealVector) arrayRealVector3);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 100 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix2);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula0 = org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES;
        org.apache.commons.math3.random.MersenneTwister mersenneTwister7 = new org.apache.commons.math3.random.MersenneTwister((int) '#');
        double double8 = mersenneTwister7.nextDouble();
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker12 = new org.apache.commons.math3.optim.SimpleValueChecker((double) (byte) 1, (double) (short) 100);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer13 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer((int) '#', (double) (short) 1, true, 36, 10, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister7, true, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker12);
        double double14 = simpleValueChecker12.getAbsoluteThreshold();
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver15 = new org.apache.commons.math3.analysis.solvers.BrentSolver();
        double double16 = brentSolver15.getRelativeAccuracy();
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer17 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker12, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver15);
        double double18 = brentSolver15.getAbsoluteAccuracy();
        org.junit.Assert.assertTrue("'" + formula0 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES + "'", formula0.equals(org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.45805495157532494d + "'", double8 == 0.45805495157532494d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 100.0d + "'", double14 == 100.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0E-14d + "'", double16 == 1.0E-14d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0E-6d + "'", double18 == 1.0E-6d);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula0 = org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES;
        org.apache.commons.math3.random.MersenneTwister mersenneTwister7 = new org.apache.commons.math3.random.MersenneTwister((int) '#');
        double double8 = mersenneTwister7.nextDouble();
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker12 = new org.apache.commons.math3.optim.SimpleValueChecker((double) (byte) 1, (double) (short) 100);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer13 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer((int) '#', (double) (short) 1, true, 36, 10, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister7, true, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker12);
        double double14 = simpleValueChecker12.getAbsoluteThreshold();
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver15 = new org.apache.commons.math3.analysis.solvers.BrentSolver();
        double double16 = brentSolver15.getRelativeAccuracy();
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer17 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker12, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver15);
        double double18 = brentSolver15.getMax();
        org.junit.Assert.assertTrue("'" + formula0 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES + "'", formula0.equals(org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.45805495157532494d + "'", double8 == 0.45805495157532494d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 100.0d + "'", double14 == 100.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0E-14d + "'", double16 == 1.0E-14d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math3.random.MersenneTwister((int) '#');
        double double7 = mersenneTwister6.nextDouble();
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker11 = new org.apache.commons.math3.optim.SimpleValueChecker((double) (byte) 1, (double) (short) 100);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer12 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer((int) '#', (double) (short) 1, true, 36, 10, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister6, true, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker11);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex19 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(36, 100.0d, (-1.0d), (double) ' ', 3.7663540285E10d, 0.7853981633974483d);
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType20 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE;
        org.apache.commons.math3.analysis.MultivariateFunction multivariateFunction21 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.ObjectiveFunction objectiveFunction22 = new org.apache.commons.math3.optim.nonlinear.scalar.ObjectiveFunction(multivariateFunction21);
        org.apache.commons.math3.optim.OptimizationData[] optimizationDataArray23 = new org.apache.commons.math3.optim.OptimizationData[] { nelderMeadSimplex19, goalType20, objectiveFunction22 };
        try {
            org.apache.commons.math3.optim.PointValuePair pointValuePair24 = cMAESOptimizer12.optimize(optimizationDataArray23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.45805495157532494d + "'", double7 == 0.45805495157532494d);
        org.junit.Assert.assertTrue("'" + goalType20 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE + "'", goalType20.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE));
        org.junit.Assert.assertNotNull(optimizationDataArray23);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
        org.apache.commons.math3.optim.nonlinear.vector.Target target2 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix3 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray0);
        double double4 = diagonalMatrix3.getFrobeniusNorm();
        boolean boolean5 = diagonalMatrix3.isSquare();
        org.apache.commons.math3.exception.util.Localizable localizable10 = null;
        double[] doubleArray14 = new double[] { '#', (byte) 100, (short) 100 };
        double[] doubleArray18 = new double[] { '#', (byte) 100, (short) 100 };
        double[] doubleArray22 = new double[] { '#', (byte) 100, (short) 100 };
        double[] doubleArray26 = new double[] { '#', (byte) 100, (short) 100 };
        double[][] doubleArray27 = new double[][] { doubleArray14, doubleArray18, doubleArray22, doubleArray26 };
        double[][] doubleArray28 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray27);
        double[][] doubleArray29 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray28);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException30 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable10, (java.lang.Object[]) doubleArray28);
        try {
            diagonalMatrix3.copySubMatrix((int) ' ', (int) (short) 1, (int) (short) 0, (int) (byte) -1, doubleArray28);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (32)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.IdentityPreconditioner identityPreconditioner0 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.IdentityPreconditioner();
        double[] doubleArray1 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight2 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray1);
        org.apache.commons.math3.optim.nonlinear.vector.Target target3 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray1);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray1);
        org.apache.commons.math3.linear.RealMatrix realMatrix6 = diagonalMatrix4.power((int) ' ');
        double[] doubleArray7 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight8 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray7);
        org.apache.commons.math3.optim.nonlinear.vector.Target target9 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray7);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix10 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray7);
        double[] doubleArray11 = diagonalMatrix4.operate(doubleArray7);
        double[] doubleArray12 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight13 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray12);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds14 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray11, doubleArray12);
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight16 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray15);
        double[] doubleArray17 = identityPreconditioner0.precondition(doubleArray12, doubleArray15);
        double[] doubleArray20 = new double[] { '#', (short) 100 };
        double[] doubleArray21 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight22 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray21);
        org.apache.commons.math3.optim.nonlinear.vector.Target target23 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray21);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix24 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray21);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray20, doubleArray21);
        double double26 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray15, doubleArray21);
        try {
            double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray21, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        double double1 = org.apache.commons.math3.util.FastMath.floor((double) (short) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 1.0E-15d, (java.lang.Number) 97, false);
        boolean boolean5 = numberIsTooLargeException4.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        double double1 = org.apache.commons.math3.util.FastMath.ceil((double) 5688046246375236535L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.6880462463752366E18d + "'", double1 == 5.6880462463752366E18d);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        double double1 = org.apache.commons.math3.util.FastMath.acos((double) (short) 100);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker0 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer simplexOptimizer1 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer(pointValuePairConvergenceChecker0);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.BracketingStep bracketingStep3 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.BracketingStep((double) (byte) 0);
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight5 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray4);
        org.apache.commons.math3.linear.RealMatrix realMatrix6 = weight5.getWeight();
        double[] doubleArray7 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight8 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray7);
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = weight8.getWeight();
        double[] doubleArray11 = new double[] { (short) 1 };
        double[] doubleArray14 = new double[] { '#', (short) 100 };
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight16 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray15);
        org.apache.commons.math3.optim.nonlinear.vector.Target target17 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray15);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray15);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14, doubleArray15);
        org.apache.commons.math3.linear.RealVector realVector21 = arrayRealVector19.mapAdd(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray11, arrayRealVector19);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex23 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray11);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex28 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray11, (-1.0d), (-1.0d), 0.8414709848078965d, (double) 36);
        double[] doubleArray29 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight30 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray29);
        org.apache.commons.math3.optim.nonlinear.vector.Target target31 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray29);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix32 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray29);
        org.apache.commons.math3.linear.RealMatrix realMatrix34 = diagonalMatrix32.power((int) ' ');
        double[] doubleArray35 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight36 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray35);
        org.apache.commons.math3.optim.nonlinear.vector.Target target37 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray35);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix38 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray35);
        double[] doubleArray39 = diagonalMatrix32.operate(doubleArray35);
        double[] doubleArray40 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight41 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray40);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds42 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray39, doubleArray40);
        double[] doubleArray43 = simpleBounds42.getLower();
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType44 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE;
        org.apache.commons.math3.optim.OptimizationData[] optimizationDataArray45 = new org.apache.commons.math3.optim.OptimizationData[] { bracketingStep3, weight5, weight8, nelderMeadSimplex28, simpleBounds42, goalType44 };
        try {
            org.apache.commons.math3.optim.PointValuePair pointValuePair46 = simplexOptimizer1.optimize(optimizationDataArray45);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathUnsupportedOperationException; message: constraint");
        } catch (org.apache.commons.math3.exception.MathUnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realVector21);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(realMatrix34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + goalType44 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE + "'", goalType44.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE));
        org.junit.Assert.assertNotNull(optimizationDataArray45);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer5 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer((double) 0.0f, (double) (-1L), 52.0d, (double) '4', 0.0d);
        int int6 = levenbergMarquardtOptimizer5.getEvaluations();
        double[] doubleArray7 = levenbergMarquardtOptimizer5.getUpperBound();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNull(doubleArray7);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException3 = new org.apache.commons.math3.exception.NotFiniteNumberException(localizable0, (java.lang.Number) 1.1752011936438014d, objArray2);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math3.random.MersenneTwister((int) '#');
        double double7 = mersenneTwister6.nextDouble();
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker11 = new org.apache.commons.math3.optim.SimpleValueChecker((double) (byte) 1, (double) (short) 100);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer12 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer((int) '#', (double) (short) 1, true, 36, 10, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister6, true, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker11);
        java.util.List<java.lang.Double> doubleList13 = cMAESOptimizer12.getStatisticsSigmaHistory();
        java.util.List<org.apache.commons.math3.linear.RealMatrix> realMatrixList14 = cMAESOptimizer12.getStatisticsMeanHistory();
        int int15 = cMAESOptimizer12.getEvaluations();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.45805495157532494d + "'", double7 == 0.45805495157532494d);
        org.junit.Assert.assertNotNull(doubleList13);
        org.junit.Assert.assertNotNull(realMatrixList14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math3.random.MersenneTwister((int) '#');
        double double7 = mersenneTwister6.nextDouble();
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker11 = new org.apache.commons.math3.optim.SimpleValueChecker((double) (byte) 1, (double) (short) 100);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer12 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer((int) '#', (double) (short) 1, true, 36, 10, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister6, true, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker11);
        java.util.List<org.apache.commons.math3.linear.RealMatrix> realMatrixList13 = cMAESOptimizer12.getStatisticsDHistory();
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker14 = cMAESOptimizer12.getConvergenceChecker();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.45805495157532494d + "'", double7 == 0.45805495157532494d);
        org.junit.Assert.assertNotNull(realMatrixList13);
        org.junit.Assert.assertNotNull(pointValuePairConvergenceChecker14);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        double[] doubleArray1 = new double[] { (short) 1 };
        double[] doubleArray4 = new double[] { '#', (short) 100 };
        double[] doubleArray5 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight6 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray5);
        org.apache.commons.math3.optim.nonlinear.vector.Target target7 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray5);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix8 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4, doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector11 = arrayRealVector9.mapAdd(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1, arrayRealVector9);
        double double13 = arrayRealVector12.getL1Norm();
        double[] doubleArray17 = new double[] { (short) 1 };
        double[] doubleArray20 = new double[] { '#', (short) 100 };
        double[] doubleArray21 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight22 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray21);
        org.apache.commons.math3.optim.nonlinear.vector.Target target23 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray21);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix24 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray21);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray20, doubleArray21);
        org.apache.commons.math3.linear.RealVector realVector27 = arrayRealVector25.mapAdd(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray17, arrayRealVector25);
        org.apache.commons.math3.linear.RealVector realVector30 = arrayRealVector28.mapAdd((double) (byte) 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = arrayRealVector12.combine((double) 100L, (double) (byte) 1, (org.apache.commons.math3.linear.RealVector) arrayRealVector28);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector();
        try {
            double double33 = arrayRealVector12.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector32);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 3 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 136.0d + "'", double13 == 136.0d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(realVector27);
        org.junit.Assert.assertNotNull(realVector30);
        org.junit.Assert.assertNotNull(arrayRealVector31);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
        org.apache.commons.math3.optim.nonlinear.vector.Target target2 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix3 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray0);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = diagonalMatrix3.power((int) ' ');
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = diagonalMatrix3.power((int) ' ');
        double double8 = diagonalMatrix3.getNorm();
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula0 = org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula1 = org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula[] formulaArray2 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula[] { formula0, formula1 };
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection3 = null;
        try {
            boolean boolean5 = org.apache.commons.math3.util.MathArrays.isMonotonic(formulaArray2, orderDirection3, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + formula0 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES + "'", formula0.equals(org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES));
        org.junit.Assert.assertTrue("'" + formula1 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES + "'", formula1.equals(org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES));
        org.junit.Assert.assertNotNull(formulaArray2);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        int int2 = org.apache.commons.math3.util.FastMath.max((int) (short) 0, 125);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 125 + "'", int2 == 125);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
        org.apache.commons.math3.optim.nonlinear.vector.Target target2 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix3 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray0);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = diagonalMatrix3.power((int) ' ');
        boolean boolean6 = diagonalMatrix3.isTransposable();
        int int7 = diagonalMatrix3.getRowDimension();
        double[] doubleArray10 = new double[] { '#', (short) 100 };
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight12 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray11);
        org.apache.commons.math3.optim.nonlinear.vector.Target target13 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray11);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix14 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray11);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray10, doubleArray11);
        org.apache.commons.math3.linear.RealVector realVector17 = arrayRealVector15.mapAdd(0.0d);
        double[] doubleArray18 = arrayRealVector15.toArray();
        try {
            org.apache.commons.math3.linear.RealVector realVector19 = diagonalMatrix3.operateTranspose((org.apache.commons.math3.linear.RealVector) arrayRealVector15);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertNotNull(doubleArray18);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer3 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer((double) 100.0f, 0.0d, 0.0d);
        int int4 = levenbergMarquardtOptimizer3.getMaxIterations();
        int int5 = levenbergMarquardtOptimizer3.getIterations();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2147483647 + "'", int4 == 2147483647);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
        org.apache.commons.math3.optim.nonlinear.vector.Target target2 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix3 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray0);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = diagonalMatrix3.power((int) ' ');
        boolean boolean6 = diagonalMatrix3.isTransposable();
        int int7 = diagonalMatrix3.getRowDimension();
        double[][] doubleArray8 = diagonalMatrix3.getData();
        double[] doubleArray9 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight10 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray9);
        org.apache.commons.math3.optim.nonlinear.vector.Target target11 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray9);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix12 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray9);
        org.apache.commons.math3.linear.RealMatrix realMatrix14 = diagonalMatrix12.power((int) ' ');
        boolean boolean15 = diagonalMatrix12.isTransposable();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix16 = diagonalMatrix3.subtract((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
        org.apache.commons.math3.optim.nonlinear.vector.Target target2 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix3 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray0);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = diagonalMatrix3.power((int) ' ');
        double[] doubleArray6 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight7 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray6);
        org.apache.commons.math3.optim.nonlinear.vector.Target target8 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray6);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix9 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6);
        double[] doubleArray10 = diagonalMatrix3.operate(doubleArray6);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight12 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray11);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds13 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray10, doubleArray11);
        double[] doubleArray14 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight15 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray14);
        org.apache.commons.math3.optim.nonlinear.vector.Target target16 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray14);
        double[] doubleArray17 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray11, doubleArray14);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix19 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray11, true);
        double[] doubleArray20 = null;
        try {
            org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition22 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray11, doubleArray20, (double) 1.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        double[] doubleArray2 = new double[] { '#', (short) 100 };
        double[] doubleArray3 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight4 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray3);
        org.apache.commons.math3.optim.nonlinear.vector.Target target5 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray3);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix6 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray2, doubleArray3);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.mapDivide((double) 10.0f);
        org.apache.commons.math3.linear.RealVector realVector11 = arrayRealVector7.mapMultiplyToSelf(1.0E-15d);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(realVector11);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        double double2 = org.apache.commons.math3.util.Precision.round((double) 0L, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
        org.apache.commons.math3.optim.nonlinear.vector.Target target2 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix3 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray0);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = diagonalMatrix3.power((int) ' ');
        boolean boolean6 = diagonalMatrix3.isTransposable();
        diagonalMatrix3.setEntry(100, (int) ' ', (double) 0L);
        try {
            diagonalMatrix3.setEntry((int) '4', (int) (short) 10, (-0.8813735870195429d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: 0.881 is larger than the maximum (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        double double2 = org.apache.commons.math3.util.Precision.representableDelta(0.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math3.exception.NotPositiveException(localizable0, (java.lang.Number) 100);
        try {
            org.apache.commons.math3.exception.MathInternalError mathInternalError3 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable) notPositiveException2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        byte byte2 = org.apache.commons.math3.util.MathUtils.copySign((byte) -1, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        double[] doubleArray0 = null;
        try {
            org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix2 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray0, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
        org.apache.commons.math3.optim.nonlinear.vector.Target target2 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix3 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray0);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = diagonalMatrix3.power((int) ' ');
        boolean boolean6 = diagonalMatrix3.isTransposable();
        int int7 = diagonalMatrix3.getRowDimension();
        double[][] doubleArray8 = diagonalMatrix3.getData();
        try {
            double double11 = diagonalMatrix3.getEntry((int) (short) 1, 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math3.random.MersenneTwister((int) '#');
        byte[] byteArray4 = new byte[] { (byte) -1, (byte) 0 };
        mersenneTwister1.nextBytes(byteArray4);
        org.junit.Assert.assertNotNull(byteArray4);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        int[] intArray0 = null;
        try {
            int[] intArray2 = org.apache.commons.math3.util.MathArrays.copyOf(intArray0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math3.random.MersenneTwister((long) (short) 100);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NoDataException noDataException1 = new org.apache.commons.math3.exception.NoDataException(localizable0);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext2 = noDataException1.getContext();
        org.junit.Assert.assertNotNull(exceptionContext2);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
        org.apache.commons.math3.optim.nonlinear.vector.Target target2 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix3 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray0);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = diagonalMatrix3.power((int) ' ');
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = diagonalMatrix3.power((int) ' ');
        double[] doubleArray8 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight9 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray8);
        org.apache.commons.math3.optim.nonlinear.vector.Target target10 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray8);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix11 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray8);
        org.apache.commons.math3.linear.RealMatrix realMatrix13 = diagonalMatrix11.power((int) ' ');
        double[] doubleArray14 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight15 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray14);
        org.apache.commons.math3.optim.nonlinear.vector.Target target16 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray14);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix17 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray14);
        double[] doubleArray18 = diagonalMatrix11.operate(doubleArray14);
        double[] doubleArray19 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight20 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray19);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds21 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray18, doubleArray19);
        double[] doubleArray22 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight23 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray22);
        org.apache.commons.math3.optim.nonlinear.vector.Target target24 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray22);
        double[] doubleArray25 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray19, doubleArray22);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix27 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray19, true);
        org.apache.commons.math3.linear.RealMatrix realMatrix28 = diagonalMatrix3.preMultiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix27);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.IdentityPreconditioner identityPreconditioner30 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.IdentityPreconditioner();
        double[] doubleArray31 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight32 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray31);
        org.apache.commons.math3.optim.nonlinear.vector.Target target33 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray31);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix34 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray31);
        org.apache.commons.math3.linear.RealMatrix realMatrix36 = diagonalMatrix34.power((int) ' ');
        double[] doubleArray37 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight38 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray37);
        org.apache.commons.math3.optim.nonlinear.vector.Target target39 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray37);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix40 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray37);
        double[] doubleArray41 = diagonalMatrix34.operate(doubleArray37);
        double[] doubleArray42 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight43 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray42);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds44 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray41, doubleArray42);
        double[] doubleArray45 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight46 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray45);
        double[] doubleArray47 = identityPreconditioner30.precondition(doubleArray42, doubleArray45);
        try {
            diagonalMatrix3.setColumn(10, doubleArray42);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(realMatrix36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray47);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        double double1 = org.apache.commons.math3.util.FastMath.cosh((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11013.232920103323d + "'", double1 == 11013.232920103323d);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
        org.apache.commons.math3.optim.nonlinear.vector.Target target2 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix3 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray0);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = diagonalMatrix3.power((int) ' ');
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = diagonalMatrix3.power((int) ' ');
        double[] doubleArray8 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight9 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray8);
        org.apache.commons.math3.optim.nonlinear.vector.Target target10 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray8);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix11 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray8);
        org.apache.commons.math3.linear.RealMatrix realMatrix13 = diagonalMatrix11.power((int) ' ');
        double[] doubleArray14 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight15 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray14);
        org.apache.commons.math3.optim.nonlinear.vector.Target target16 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray14);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix17 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray14);
        double[] doubleArray18 = diagonalMatrix11.operate(doubleArray14);
        double[] doubleArray19 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight20 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray19);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds21 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray18, doubleArray19);
        double[] doubleArray22 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight23 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray22);
        org.apache.commons.math3.optim.nonlinear.vector.Target target24 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray22);
        double[] doubleArray25 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray19, doubleArray22);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix27 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray19, true);
        org.apache.commons.math3.linear.RealMatrix realMatrix28 = diagonalMatrix3.preMultiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix27);
        java.lang.String str29 = diagonalMatrix27.toString();
        org.apache.commons.math3.linear.RealVector realVector31 = null;
        try {
            diagonalMatrix27.setColumnVector((-1023), realVector31);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (-1,023)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "DiagonalMatrix{}" + "'", str29.equals("DiagonalMatrix{}"));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
        org.apache.commons.math3.optim.nonlinear.vector.Target target2 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix3 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray0);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = diagonalMatrix3.power((int) ' ');
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = diagonalMatrix3.power((int) ' ');
        double[] doubleArray8 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight9 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray8);
        org.apache.commons.math3.optim.nonlinear.vector.Target target10 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray8);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix11 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray8);
        org.apache.commons.math3.linear.RealMatrix realMatrix13 = diagonalMatrix11.power((int) ' ');
        double[] doubleArray14 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight15 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray14);
        org.apache.commons.math3.optim.nonlinear.vector.Target target16 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray14);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix17 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray14);
        double[] doubleArray18 = diagonalMatrix11.operate(doubleArray14);
        double[] doubleArray19 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight20 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray19);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds21 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray18, doubleArray19);
        double[] doubleArray22 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight23 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray22);
        org.apache.commons.math3.optim.nonlinear.vector.Target target24 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray22);
        double[] doubleArray25 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray19, doubleArray22);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix27 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray19, true);
        org.apache.commons.math3.linear.RealMatrix realMatrix28 = diagonalMatrix3.preMultiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix27);
        double[] doubleArray29 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight30 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray29);
        org.apache.commons.math3.optim.nonlinear.vector.Target target31 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray29);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix32 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray29);
        org.apache.commons.math3.linear.RealMatrix realMatrix34 = diagonalMatrix32.power((int) ' ');
        double[] doubleArray35 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight36 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray35);
        org.apache.commons.math3.optim.nonlinear.vector.Target target37 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray35);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix38 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray35);
        double[] doubleArray39 = diagonalMatrix32.operate(doubleArray35);
        double[] doubleArray40 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray39);
        double[] doubleArray41 = diagonalMatrix3.operate(doubleArray39);
        int[] intArray44 = new int[] { 100, 36 };
        int[] intArray51 = new int[] { 1, (short) 10, (short) 1, (byte) 10, (byte) 1, (short) -1 };
        int int52 = org.apache.commons.math3.util.MathArrays.distance1(intArray44, intArray51);
        int[] intArray57 = new int[] { 36, 0, 10, (short) -1 };
        int[] intArray58 = org.apache.commons.math3.util.MathArrays.copyOf(intArray57);
        double[][] doubleArray59 = null;
        try {
            diagonalMatrix3.copySubMatrix(intArray51, intArray58, doubleArray59);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(realMatrix34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 125 + "'", int52 == 125);
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertNotNull(intArray58);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsWithRelativeTolerance((double) 36, (double) '#', 1.88317701425E10d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.apache.commons.math3.analysis.MultivariateVectorFunction multivariateVectorFunction0 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.ObjectiveFunctionGradient objectiveFunctionGradient1 = new org.apache.commons.math3.optim.nonlinear.scalar.ObjectiveFunctionGradient(multivariateVectorFunction0);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        double double0 = org.apache.commons.math3.util.FastMath.PI;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.141592653589793d + "'", double0 == 3.141592653589793d);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat7 = org.apache.commons.math3.linear.MatrixUtils.OCTAVE_FORMAT;
        java.text.NumberFormat numberFormat8 = realMatrixFormat7.getFormat();
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat9 = new org.apache.commons.math3.linear.RealMatrixFormat(", ", "hi!", "{", "", ", ", "DiagonalMatrix{}", numberFormat8);
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat10 = new org.apache.commons.math3.linear.RealMatrixFormat(numberFormat8);
        java.lang.StringBuffer stringBuffer11 = null;
        java.text.FieldPosition fieldPosition12 = null;
        try {
            java.lang.StringBuffer stringBuffer13 = org.apache.commons.math3.util.CompositeFormat.formatDouble((double) 1076101151, numberFormat8, stringBuffer11, fieldPosition12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrixFormat7);
        org.junit.Assert.assertNotNull(numberFormat8);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
        org.apache.commons.math3.optim.nonlinear.vector.Target target2 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix3 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray0);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = diagonalMatrix3.power((int) ' ');
        double[] doubleArray6 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight7 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray6);
        org.apache.commons.math3.optim.nonlinear.vector.Target target8 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray6);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix9 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6);
        double[] doubleArray10 = diagonalMatrix3.operate(doubleArray6);
        boolean boolean11 = diagonalMatrix3.isSquare();
        double[][] doubleArray12 = diagonalMatrix3.getData();
        double[] doubleArray15 = new double[] { '#', (short) 100 };
        double[] doubleArray16 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight17 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray16);
        org.apache.commons.math3.optim.nonlinear.vector.Target target18 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray16);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix19 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray16);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray15, doubleArray16);
        double[] doubleArray21 = arrayRealVector20.toArray();
        try {
            double[] doubleArray22 = diagonalMatrix3.preMultiply(doubleArray21);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 2");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        double double2 = org.apache.commons.math3.util.FastMath.IEEEremainder(1.0E-15d, (double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E-15d + "'", double2 == 1.0E-15d);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.MatrixUtils.DEFAULT_FORMAT;
        java.lang.String str1 = realMatrixFormat0.getRowSeparator();
        double[] doubleArray2 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight3 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray2);
        org.apache.commons.math3.optim.nonlinear.vector.Target target4 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray2);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix5 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray2);
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = diagonalMatrix5.power((int) ' ');
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = diagonalMatrix5.power((int) ' ');
        double[] doubleArray10 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight11 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray10);
        org.apache.commons.math3.optim.nonlinear.vector.Target target12 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray10);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix13 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray10);
        org.apache.commons.math3.linear.RealMatrix realMatrix15 = diagonalMatrix13.power((int) ' ');
        double[] doubleArray16 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight17 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray16);
        org.apache.commons.math3.optim.nonlinear.vector.Target target18 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray16);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix19 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray16);
        double[] doubleArray20 = diagonalMatrix13.operate(doubleArray16);
        double[] doubleArray21 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight22 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray21);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds23 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray20, doubleArray21);
        double[] doubleArray24 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight25 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray24);
        org.apache.commons.math3.optim.nonlinear.vector.Target target26 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray24);
        double[] doubleArray27 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray21, doubleArray24);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix29 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray21, true);
        org.apache.commons.math3.linear.RealMatrix realMatrix30 = diagonalMatrix5.preMultiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix29);
        java.lang.String str31 = diagonalMatrix29.toString();
        double[] doubleArray32 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight33 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray32);
        org.apache.commons.math3.optim.nonlinear.vector.Target target34 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray32);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix35 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray32);
        org.apache.commons.math3.linear.RealMatrix realMatrix37 = diagonalMatrix35.power((int) ' ');
        double[] doubleArray38 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight39 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray38);
        org.apache.commons.math3.optim.nonlinear.vector.Target target40 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray38);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix41 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray38);
        double[] doubleArray42 = diagonalMatrix35.operate(doubleArray38);
        double[] doubleArray43 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight44 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray43);
        org.apache.commons.math3.optim.nonlinear.vector.Target target45 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray43);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix46 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray43);
        double[] doubleArray47 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray42, doubleArray43);
        double[] doubleArray48 = diagonalMatrix29.operate(doubleArray43);
        java.lang.String str49 = realMatrixFormat0.format((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix29);
        try {
            org.apache.commons.math3.linear.RealVector realVector51 = diagonalMatrix29.getRowVector((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (0)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "," + "'", str1.equals(","));
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(realMatrix15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "DiagonalMatrix{}" + "'", str31.equals("DiagonalMatrix{}"));
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(realMatrix37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "{}" + "'", str49.equals("{}"));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        double double1 = org.apache.commons.math3.util.FastMath.acos((double) '#');
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.apache.commons.math3.exception.MathParseException mathParseException2 = new org.apache.commons.math3.exception.MathParseException("hi!", 1076101151);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        double double1 = org.apache.commons.math3.util.FastMath.log10((double) (-1.0f));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.IdentityPreconditioner identityPreconditioner0 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.IdentityPreconditioner();
        double[] doubleArray1 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight2 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray1);
        org.apache.commons.math3.optim.nonlinear.vector.Target target3 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray1);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray1);
        org.apache.commons.math3.linear.RealMatrix realMatrix6 = diagonalMatrix4.power((int) ' ');
        double[] doubleArray7 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight8 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray7);
        org.apache.commons.math3.optim.nonlinear.vector.Target target9 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray7);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix10 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray7);
        double[] doubleArray11 = diagonalMatrix4.operate(doubleArray7);
        double[] doubleArray12 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight13 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray12);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds14 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray11, doubleArray12);
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight16 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray15);
        double[] doubleArray17 = identityPreconditioner0.precondition(doubleArray12, doubleArray15);
        double[] doubleArray20 = new double[] { '#', (short) 100 };
        double[] doubleArray21 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight22 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray21);
        org.apache.commons.math3.optim.nonlinear.vector.Target target23 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray21);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix24 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray21);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray20, doubleArray21);
        double double26 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray15, doubleArray21);
        double[] doubleArray27 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray27);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        java.util.Locale locale0 = null;
        try {
            org.apache.commons.math3.linear.RealVectorFormat realVectorFormat1 = org.apache.commons.math3.linear.RealVectorFormat.getInstance(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException3 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number) 125);
        java.lang.Throwable[] throwableArray4 = maxCountExceededException3.getSuppressed();
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException5 = new org.apache.commons.math3.exception.NotFiniteNumberException(localizable0, (java.lang.Number) 10.0d, (java.lang.Object[]) throwableArray4);
        org.apache.commons.math3.exception.util.Localizable localizable6 = null;
        java.lang.Integer[] intArray12 = new java.lang.Integer[] { 36, 125, 100, 10, 100 };
        java.lang.Integer[] intArray14 = new java.lang.Integer[] { 36 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException15 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray12, intArray14);
        java.lang.Integer[] intArray21 = new java.lang.Integer[] { 36, 125, 100, 10, 100 };
        java.lang.Integer[] intArray23 = new java.lang.Integer[] { 36 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException24 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray21, intArray23);
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException25 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray12, intArray23);
        try {
            org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException26 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) notFiniteNumberException5, localizable6, (java.lang.Object[]) intArray12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray23);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
        org.apache.commons.math3.optim.nonlinear.vector.Target target2 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix3 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray0);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = diagonalMatrix3.power((int) ' ');
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = diagonalMatrix3.power((int) ' ');
        double[] doubleArray8 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight9 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray8);
        org.apache.commons.math3.optim.nonlinear.vector.Target target10 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray8);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix11 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray8);
        org.apache.commons.math3.linear.RealMatrix realMatrix13 = diagonalMatrix11.power((int) ' ');
        double[] doubleArray14 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight15 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray14);
        org.apache.commons.math3.optim.nonlinear.vector.Target target16 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray14);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix17 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray14);
        double[] doubleArray18 = diagonalMatrix11.operate(doubleArray14);
        double[] doubleArray19 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight20 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray19);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds21 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray18, doubleArray19);
        double[] doubleArray22 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight23 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray22);
        org.apache.commons.math3.optim.nonlinear.vector.Target target24 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray22);
        double[] doubleArray25 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray19, doubleArray22);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix27 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray19, true);
        org.apache.commons.math3.linear.RealMatrix realMatrix28 = diagonalMatrix3.preMultiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix27);
        java.lang.String str29 = diagonalMatrix27.toString();
        double[] doubleArray30 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight31 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray30);
        org.apache.commons.math3.optim.nonlinear.vector.Target target32 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray30);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix33 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray30);
        org.apache.commons.math3.linear.RealMatrix realMatrix35 = diagonalMatrix33.power((int) ' ');
        double[] doubleArray36 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight37 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray36);
        org.apache.commons.math3.optim.nonlinear.vector.Target target38 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray36);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix39 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray36);
        double[] doubleArray40 = diagonalMatrix33.operate(doubleArray36);
        double[] doubleArray41 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight42 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray41);
        org.apache.commons.math3.optim.nonlinear.vector.Target target43 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray41);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix44 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray41);
        double[] doubleArray45 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray40, doubleArray41);
        double[] doubleArray46 = diagonalMatrix27.operate(doubleArray41);
        diagonalMatrix27.multiplyEntry(36, 1, (double) (short) -1);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "DiagonalMatrix{}" + "'", str29.equals("DiagonalMatrix{}"));
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(realMatrix35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException(localizable0, (java.lang.Number) 9.677880210178613E53d, (java.lang.Number) 1.0E-14d, (java.lang.Number) 100.0d);
        java.lang.Number number5 = outOfRangeException4.getLo();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1.0E-14d + "'", number5.equals(1.0E-14d));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        double double1 = org.apache.commons.math3.util.FastMath.asin((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5707963267948966d) + "'", double1 == (-1.5707963267948966d));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
        org.apache.commons.math3.optim.nonlinear.vector.Target target2 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix3 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray0);
        double double4 = diagonalMatrix3.getFrobeniusNorm();
        java.io.ObjectOutputStream objectOutputStream5 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.serializeRealMatrix((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix3, objectOutputStream5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        int int1 = org.apache.commons.math3.util.FastMath.round((float) 1076101151);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1076101120 + "'", int1 == 1076101120);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        float float2 = org.apache.commons.math3.util.FastMath.max((float) (byte) -1, (float) 97);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 97.0f + "'", float2 == 97.0f);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        double double1 = org.apache.commons.math3.util.FastMath.tanh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.apache.commons.math3.analysis.MultivariateMatrixFunction multivariateMatrixFunction0 = null;
        org.apache.commons.math3.optim.nonlinear.vector.ModelFunctionJacobian modelFunctionJacobian1 = new org.apache.commons.math3.optim.nonlinear.vector.ModelFunctionJacobian(multivariateMatrixFunction0);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer powellOptimizer4 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer(0.0d, 0.0d, 1.1752011936438014d, 3.141592653589793d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooSmallException; message: 0 is smaller than the minimum (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooSmallException e) {
        }
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.MatrixUtils.OCTAVE_FORMAT;
        java.text.NumberFormat numberFormat1 = realMatrixFormat0.getFormat();
        java.lang.String str2 = realMatrixFormat0.getColumnSeparator();
        java.lang.String str3 = realMatrixFormat0.getPrefix();
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ", " + "'", str2.equals(", "));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "[" + "'", str3.equals("["));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula0 = org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.POLAK_RIBIERE;
        org.junit.Assert.assertTrue("'" + formula0 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.POLAK_RIBIERE + "'", formula0.equals(org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.POLAK_RIBIERE));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        double double1 = org.apache.commons.math3.util.FastMath.floor((double) 'a');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 97.0d + "'", double1 == 97.0d);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        double[] doubleArray4 = new double[] { 0.45805495157532494d, 100.0f, (-1), 36 };
        double[] doubleArray6 = new double[] { (short) 1 };
        double[] doubleArray9 = new double[] { '#', (short) 100 };
        double[] doubleArray10 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight11 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray10);
        org.apache.commons.math3.optim.nonlinear.vector.Target target12 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray10);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix13 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray9, doubleArray10);
        org.apache.commons.math3.linear.RealVector realVector16 = arrayRealVector14.mapAdd(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, arrayRealVector14);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex18 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray6);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex23 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray6, (-1.0d), (-1.0d), 0.8414709848078965d, (double) 36);
        try {
            double[] doubleArray24 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray4, doubleArray6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 4 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(realVector16);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        int int1 = org.apache.commons.math3.util.FastMath.round((float) 10L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
        org.apache.commons.math3.optim.nonlinear.vector.Target target2 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix3 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray0);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = diagonalMatrix3.power((int) ' ');
        boolean boolean6 = diagonalMatrix3.isTransposable();
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = diagonalMatrix3.copy();
        diagonalMatrix3.setEntry((int) (short) 100, 97, (double) 0.0f);
        boolean boolean12 = diagonalMatrix3.isTransposable();
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver1 = new org.apache.commons.math3.analysis.solvers.BrentSolver(14890.0d);
        double double2 = brentSolver1.getMin();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula0 = org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES;
        org.apache.commons.math3.random.MersenneTwister mersenneTwister7 = new org.apache.commons.math3.random.MersenneTwister((int) '#');
        double double8 = mersenneTwister7.nextDouble();
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker12 = new org.apache.commons.math3.optim.SimpleValueChecker((double) (byte) 1, (double) (short) 100);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer13 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer((int) '#', (double) (short) 1, true, 36, 10, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister7, true, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker12);
        double double14 = simpleValueChecker12.getAbsoluteThreshold();
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver15 = new org.apache.commons.math3.analysis.solvers.BrentSolver();
        double double16 = brentSolver15.getRelativeAccuracy();
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer17 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker12, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver15);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula18 = org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES;
        org.apache.commons.math3.random.MersenneTwister mersenneTwister25 = new org.apache.commons.math3.random.MersenneTwister((int) '#');
        double double26 = mersenneTwister25.nextDouble();
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker30 = new org.apache.commons.math3.optim.SimpleValueChecker((double) (byte) 1, (double) (short) 100);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer31 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer((int) '#', (double) (short) 1, true, 36, 10, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister25, true, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker30);
        double double32 = simpleValueChecker30.getAbsoluteThreshold();
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver33 = new org.apache.commons.math3.analysis.solvers.BrentSolver();
        double double34 = brentSolver33.getRelativeAccuracy();
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer35 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula18, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker30, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver33);
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver39 = new org.apache.commons.math3.analysis.solvers.BrentSolver(1.0E-14d, (double) (byte) 0, 0.7853981633974483d);
        org.apache.commons.math3.analysis.function.Sinc sinc41 = new org.apache.commons.math3.analysis.function.Sinc();
        double double44 = brentSolver39.solve((int) (short) 100, (org.apache.commons.math3.analysis.UnivariateFunction) sinc41, 0.0d, 3.7663540285E10d);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer45 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker30, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver39);
        org.apache.commons.math3.optim.OptimizationData[] optimizationDataArray46 = null;
        try {
            org.apache.commons.math3.optim.PointValuePair pointValuePair47 = nonLinearConjugateGradientOptimizer45.optimize(optimizationDataArray46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + formula0 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES + "'", formula0.equals(org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.45805495157532494d + "'", double8 == 0.45805495157532494d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 100.0d + "'", double14 == 100.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0E-14d + "'", double16 == 1.0E-14d);
        org.junit.Assert.assertTrue("'" + formula18 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES + "'", formula18.equals(org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES));
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.45805495157532494d + "'", double26 == 0.45805495157532494d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 100.0d + "'", double32 == 100.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 1.0E-14d + "'", double34 == 1.0E-14d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 1.88317701425E10d + "'", double44 == 1.88317701425E10d);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
        org.apache.commons.math3.optim.nonlinear.vector.Target target2 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix3 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray0);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = diagonalMatrix3.power((int) ' ');
        double[] doubleArray6 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight7 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray6);
        org.apache.commons.math3.optim.nonlinear.vector.Target target8 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray6);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix9 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6);
        double[] doubleArray10 = diagonalMatrix3.operate(doubleArray6);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix11 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6);
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex12 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.ZeroException; message: zero not allowed here");
        } catch (org.apache.commons.math3.exception.ZeroException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math3.random.MersenneTwister((int) '#');
        mersenneTwister1.setSeed(1076101120);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((float) '#', 0.0f, (float) 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.apache.commons.math3.util.Incrementor incrementor1 = new org.apache.commons.math3.util.Incrementor(0);
        try {
            incrementor1.incrementCount();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MaxCountExceededException; message: illegal state: maximal count (0) exceeded");
        } catch (org.apache.commons.math3.exception.MaxCountExceededException e) {
        }
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
        org.apache.commons.math3.optim.nonlinear.vector.Target target2 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix3 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray0);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = diagonalMatrix3.power((int) ' ');
        org.apache.commons.math3.linear.RealVector realVector7 = null;
        try {
            diagonalMatrix3.setRowVector((int) (short) 0, realVector7);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (0)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(realMatrix5);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        double double1 = org.apache.commons.math3.util.FastMath.acosh((double) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.993222846126381d + "'", double1 == 2.993222846126381d);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.MatrixUtils.DEFAULT_FORMAT;
        java.lang.String str1 = realMatrixFormat0.getRowSeparator();
        double[] doubleArray2 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight3 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray2);
        org.apache.commons.math3.optim.nonlinear.vector.Target target4 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray2);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix5 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray2);
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = diagonalMatrix5.power((int) ' ');
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = diagonalMatrix5.power((int) ' ');
        double[] doubleArray10 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight11 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray10);
        org.apache.commons.math3.optim.nonlinear.vector.Target target12 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray10);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix13 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray10);
        org.apache.commons.math3.linear.RealMatrix realMatrix15 = diagonalMatrix13.power((int) ' ');
        double[] doubleArray16 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight17 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray16);
        org.apache.commons.math3.optim.nonlinear.vector.Target target18 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray16);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix19 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray16);
        double[] doubleArray20 = diagonalMatrix13.operate(doubleArray16);
        double[] doubleArray21 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight22 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray21);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds23 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray20, doubleArray21);
        double[] doubleArray24 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight25 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray24);
        org.apache.commons.math3.optim.nonlinear.vector.Target target26 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray24);
        double[] doubleArray27 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray21, doubleArray24);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix29 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray21, true);
        org.apache.commons.math3.linear.RealMatrix realMatrix30 = diagonalMatrix5.preMultiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix29);
        java.lang.String str31 = diagonalMatrix29.toString();
        double[] doubleArray32 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight33 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray32);
        org.apache.commons.math3.optim.nonlinear.vector.Target target34 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray32);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix35 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray32);
        org.apache.commons.math3.linear.RealMatrix realMatrix37 = diagonalMatrix35.power((int) ' ');
        double[] doubleArray38 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight39 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray38);
        org.apache.commons.math3.optim.nonlinear.vector.Target target40 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray38);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix41 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray38);
        double[] doubleArray42 = diagonalMatrix35.operate(doubleArray38);
        double[] doubleArray43 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight44 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray43);
        org.apache.commons.math3.optim.nonlinear.vector.Target target45 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray43);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix46 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray43);
        double[] doubleArray47 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray42, doubleArray43);
        double[] doubleArray48 = diagonalMatrix29.operate(doubleArray43);
        java.lang.String str49 = realMatrixFormat0.format((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix29);
        double[] doubleArray51 = new double[] { (short) 1 };
        double[] doubleArray54 = new double[] { '#', (short) 100 };
        double[] doubleArray55 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight56 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray55);
        org.apache.commons.math3.optim.nonlinear.vector.Target target57 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray55);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix58 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray55);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector59 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray54, doubleArray55);
        org.apache.commons.math3.linear.RealVector realVector61 = arrayRealVector59.mapAdd(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector62 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray51, arrayRealVector59);
        double[] doubleArray63 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight64 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray63);
        org.apache.commons.math3.optim.nonlinear.vector.Target target65 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray63);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix66 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray63);
        org.apache.commons.math3.linear.RealMatrix realMatrix68 = diagonalMatrix66.power((int) ' ');
        double[] doubleArray69 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight70 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray69);
        org.apache.commons.math3.optim.nonlinear.vector.Target target71 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray69);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix72 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray69);
        double[] doubleArray73 = diagonalMatrix66.operate(doubleArray69);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector74 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray73);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector75 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector62, arrayRealVector74);
        org.apache.commons.math3.linear.MatrixUtils.solveLowerTriangularSystem((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix29, (org.apache.commons.math3.linear.RealVector) arrayRealVector74);
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "," + "'", str1.equals(","));
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(realMatrix15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "DiagonalMatrix{}" + "'", str31.equals("DiagonalMatrix{}"));
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(realMatrix37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "{}" + "'", str49.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(realVector61);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(realMatrix68);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray73);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat1 = org.apache.commons.math3.linear.MatrixUtils.OCTAVE_FORMAT;
        java.text.NumberFormat numberFormat2 = realMatrixFormat1.getFormat();
        java.text.ParsePosition parsePosition3 = null;
        try {
            java.lang.Number number4 = org.apache.commons.math3.util.CompositeFormat.parseNumber("", numberFormat2, parsePosition3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrixFormat1);
        org.junit.Assert.assertNotNull(numberFormat2);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
        org.apache.commons.math3.optim.nonlinear.vector.Target target2 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix3 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray0);
        org.apache.commons.math3.optim.InitialGuess initialGuess4 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray0);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        double double2 = org.apache.commons.math3.util.FastMath.nextAfter(14890.0d, (double) (short) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 14889.999999999998d + "'", double2 == 14889.999999999998d);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        int int0 = org.apache.commons.math3.linear.BlockRealMatrix.BLOCK_SIZE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 52 + "'", int0 == 52);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
        org.apache.commons.math3.optim.nonlinear.vector.Target target2 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix3 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray0);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = diagonalMatrix3.power((int) ' ');
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = diagonalMatrix3.power((int) ' ');
        double[] doubleArray8 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight9 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray8);
        org.apache.commons.math3.optim.nonlinear.vector.Target target10 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray8);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix11 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray8);
        org.apache.commons.math3.linear.RealMatrix realMatrix13 = diagonalMatrix11.power((int) ' ');
        double[] doubleArray14 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight15 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray14);
        org.apache.commons.math3.optim.nonlinear.vector.Target target16 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray14);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix17 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray14);
        double[] doubleArray18 = diagonalMatrix11.operate(doubleArray14);
        double[] doubleArray19 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight20 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray19);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds21 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray18, doubleArray19);
        double[] doubleArray22 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight23 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray22);
        org.apache.commons.math3.optim.nonlinear.vector.Target target24 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray22);
        double[] doubleArray25 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray19, doubleArray22);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix27 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray19, true);
        org.apache.commons.math3.linear.RealMatrix realMatrix28 = diagonalMatrix3.preMultiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix27);
        java.lang.String str29 = diagonalMatrix27.toString();
        double[] doubleArray30 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight31 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray30);
        org.apache.commons.math3.optim.nonlinear.vector.Target target32 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray30);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix33 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray30);
        org.apache.commons.math3.linear.RealMatrix realMatrix35 = diagonalMatrix33.power((int) ' ');
        double[] doubleArray36 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight37 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray36);
        org.apache.commons.math3.optim.nonlinear.vector.Target target38 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray36);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix39 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray36);
        double[] doubleArray40 = diagonalMatrix33.operate(doubleArray36);
        double[] doubleArray41 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight42 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray41);
        org.apache.commons.math3.optim.nonlinear.vector.Target target43 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray41);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix44 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray41);
        double[] doubleArray45 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray40, doubleArray41);
        double[] doubleArray46 = diagonalMatrix27.operate(doubleArray41);
        double[] doubleArray47 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight48 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray47);
        org.apache.commons.math3.optim.nonlinear.vector.Target target49 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray47);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix50 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray47);
        org.apache.commons.math3.linear.RealMatrix realMatrix52 = diagonalMatrix50.power((int) ' ');
        org.apache.commons.math3.linear.RealMatrix realMatrix54 = diagonalMatrix50.power((int) ' ');
        double[] doubleArray55 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight56 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray55);
        org.apache.commons.math3.optim.nonlinear.vector.Target target57 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray55);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix58 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray55);
        org.apache.commons.math3.linear.RealMatrix realMatrix60 = diagonalMatrix58.power((int) ' ');
        double[] doubleArray61 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight62 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray61);
        org.apache.commons.math3.optim.nonlinear.vector.Target target63 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray61);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix64 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray61);
        double[] doubleArray65 = diagonalMatrix58.operate(doubleArray61);
        double[] doubleArray66 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight67 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray66);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds68 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray65, doubleArray66);
        double[] doubleArray69 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight70 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray69);
        org.apache.commons.math3.optim.nonlinear.vector.Target target71 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray69);
        double[] doubleArray72 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray66, doubleArray69);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix74 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray66, true);
        org.apache.commons.math3.linear.RealMatrix realMatrix75 = diagonalMatrix50.preMultiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix74);
        double[] doubleArray76 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight77 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray76);
        org.apache.commons.math3.optim.nonlinear.vector.Target target78 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray76);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix79 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray76);
        org.apache.commons.math3.linear.RealMatrix realMatrix81 = diagonalMatrix79.power((int) ' ');
        double[] doubleArray82 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight83 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray82);
        org.apache.commons.math3.optim.nonlinear.vector.Target target84 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray82);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix85 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray82);
        double[] doubleArray86 = diagonalMatrix79.operate(doubleArray82);
        double[] doubleArray87 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray86);
        double[] doubleArray88 = diagonalMatrix50.operate(doubleArray86);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix89 = diagonalMatrix27.add(diagonalMatrix50);
        double[] doubleArray91 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight92 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray91);
        org.apache.commons.math3.optim.nonlinear.vector.Target target93 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray91);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix94 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray91);
        org.apache.commons.math3.linear.RealMatrix realMatrix96 = diagonalMatrix94.power((int) ' ');
        boolean boolean97 = diagonalMatrix94.isTransposable();
        int int98 = diagonalMatrix94.getRowDimension();
        try {
            diagonalMatrix50.setRowMatrix((int) (byte) 0, (org.apache.commons.math3.linear.RealMatrix) diagonalMatrix94);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (0)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "DiagonalMatrix{}" + "'", str29.equals("DiagonalMatrix{}"));
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(realMatrix35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(realMatrix52);
        org.junit.Assert.assertNotNull(realMatrix54);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(realMatrix60);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(realMatrix75);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(realMatrix81);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertNotNull(diagonalMatrix89);
        org.junit.Assert.assertNotNull(doubleArray91);
        org.junit.Assert.assertNotNull(realMatrix96);
        org.junit.Assert.assertTrue("'" + boolean97 + "' != '" + false + "'", boolean97 == false);
        org.junit.Assert.assertTrue("'" + int98 + "' != '" + 0 + "'", int98 == 0);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        double double1 = org.apache.commons.math3.util.FastMath.ulp(9.999999999999998d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7763568394002505E-15d + "'", double1 == 1.7763568394002505E-15d);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray4 = new double[] { '#', (byte) 100, (short) 100 };
        double[] doubleArray8 = new double[] { '#', (byte) 100, (short) 100 };
        double[] doubleArray12 = new double[] { '#', (byte) 100, (short) 100 };
        double[] doubleArray16 = new double[] { '#', (byte) 100, (short) 100 };
        double[][] doubleArray17 = new double[][] { doubleArray4, doubleArray8, doubleArray12, doubleArray16 };
        double[][] doubleArray18 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray17);
        org.apache.commons.math3.exception.MathInternalError mathInternalError19 = new org.apache.commons.math3.exception.MathInternalError(localizable0, (java.lang.Object[]) doubleArray17);
        double[][] doubleArray20 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
        org.apache.commons.math3.optim.nonlinear.vector.Target target2 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix3 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray0);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = diagonalMatrix3.power((int) ' ');
        double[] doubleArray6 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight7 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray6);
        org.apache.commons.math3.optim.nonlinear.vector.Target target8 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray6);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix9 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6);
        double[] doubleArray10 = diagonalMatrix3.operate(doubleArray6);
        double[] doubleArray11 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray10);
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex12 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(doubleArray11);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.ZeroException; message: zero not allowed here");
        } catch (org.apache.commons.math3.exception.ZeroException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
        org.apache.commons.math3.optim.nonlinear.vector.Target target2 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix3 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray0);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = diagonalMatrix3.power((int) ' ');
        boolean boolean6 = diagonalMatrix3.isTransposable();
        diagonalMatrix3.setEntry(100, (int) ' ', (double) 0L);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor11 = null;
        try {
            double double16 = diagonalMatrix3.walkInOptimizedOrder(realMatrixChangingVisitor11, (int) (byte) 0, 0, 0, 1076101120);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (0)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        double double2 = org.apache.commons.math3.util.FastMath.IEEEremainder(0.0d, 100.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math3.random.MersenneTwister((int) '#');
        double double2 = mersenneTwister1.nextDouble();
        long long3 = mersenneTwister1.nextLong();
        int[] intArray5 = new int[] { 125 };
        mersenneTwister1.setSeed(intArray5);
        int[] intArray7 = null;
        try {
            double double8 = org.apache.commons.math3.util.MathArrays.distance(intArray5, intArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.45805495157532494d + "'", double2 == 0.45805495157532494d);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 5688046246375236535L + "'", long3 == 5688046246375236535L);
        org.junit.Assert.assertNotNull(intArray5);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        double[] doubleArray1 = new double[] { (short) 1 };
        double[] doubleArray4 = new double[] { '#', (short) 100 };
        double[] doubleArray5 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight6 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray5);
        org.apache.commons.math3.optim.nonlinear.vector.Target target7 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray5);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix8 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4, doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector11 = arrayRealVector9.mapAdd(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1, arrayRealVector9);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex13 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray1);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex18 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray1, (-1.0d), (-1.0d), 0.8414709848078965d, (double) 36);
        int int19 = org.apache.commons.math3.util.MathUtils.hash(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector11);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1072693279 + "'", int19 == 1072693279);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        int int3 = org.apache.commons.math3.util.Precision.compareTo((double) 97, (double) (short) -1, 1.0E-14d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(125, (int) (byte) 100);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix2.getSubMatrix(1076101120, 125, 97, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1,076,101,120)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        double double1 = org.apache.commons.math3.util.FastMath.atanh(0.7853981633974483d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.059306170823243d + "'", double1 == 1.059306170823243d);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        java.text.ParsePosition parsePosition1 = null;
        try {
            char char2 = org.apache.commons.math3.util.CompositeFormat.parseNextCharacter(", ", parsePosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
        org.apache.commons.math3.optim.nonlinear.vector.Target target2 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix3 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray0);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = diagonalMatrix3.power((int) ' ');
        double[] doubleArray6 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight7 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray6);
        org.apache.commons.math3.optim.nonlinear.vector.Target target8 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray6);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix9 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6);
        double[] doubleArray10 = diagonalMatrix3.operate(doubleArray6);
        double[] doubleArray11 = null;
        try {
            double[] doubleArray12 = org.apache.commons.math3.util.MathArrays.ebeSubtract(doubleArray6, doubleArray11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        long long1 = org.apache.commons.math3.util.FastMath.abs((long) 1072693279);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1072693279L + "'", long1 == 1072693279L);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.apache.commons.math3.analysis.function.Sinc sinc1 = new org.apache.commons.math3.analysis.function.Sinc();
        double double3 = sinc1.value(11013.232920103323d);
        org.apache.commons.math3.analysis.solvers.BracketedUnivariateSolver<org.apache.commons.math3.analysis.UnivariateFunction> univariateFunctionBracketedUnivariateSolver4 = null;
        org.apache.commons.math3.analysis.solvers.AllowedSolution allowedSolution8 = null;
        try {
            double double9 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.forceSide(97, (org.apache.commons.math3.analysis.UnivariateFunction) sinc1, univariateFunctionBracketedUnivariateSolver4, 9.999999999999998d, (double) 10L, Double.NaN, allowedSolution8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-8.432689677745178E-5d) + "'", double3 == (-8.432689677745178E-5d));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
        org.apache.commons.math3.optim.nonlinear.vector.Target target2 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix3 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray0);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = diagonalMatrix3.power((int) ' ');
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = diagonalMatrix3.power((int) ' ');
        double[] doubleArray8 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight9 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray8);
        org.apache.commons.math3.optim.nonlinear.vector.Target target10 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray8);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix11 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray8);
        org.apache.commons.math3.linear.RealMatrix realMatrix13 = diagonalMatrix11.power((int) ' ');
        double[] doubleArray14 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight15 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray14);
        org.apache.commons.math3.optim.nonlinear.vector.Target target16 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray14);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix17 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray14);
        double[] doubleArray18 = diagonalMatrix11.operate(doubleArray14);
        double[] doubleArray19 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight20 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray19);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds21 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray18, doubleArray19);
        double[] doubleArray22 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight23 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray22);
        org.apache.commons.math3.optim.nonlinear.vector.Target target24 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray22);
        double[] doubleArray25 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray19, doubleArray22);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix27 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray19, true);
        org.apache.commons.math3.linear.RealMatrix realMatrix28 = diagonalMatrix3.preMultiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix27);
        double[] doubleArray31 = new double[] { '#', (short) 100 };
        double[] doubleArray32 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight33 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray32);
        org.apache.commons.math3.optim.nonlinear.vector.Target target34 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray32);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix35 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray32);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray31, doubleArray32);
        org.apache.commons.math3.linear.RealVector realVector38 = arrayRealVector36.mapAdd(0.0d);
        org.apache.commons.math3.linear.RealVector realVector40 = arrayRealVector36.mapSubtract(2.2250738585072014E-308d);
        org.apache.commons.math3.linear.RealVector realVector42 = arrayRealVector36.mapAddToSelf(1.0E-15d);
        try {
            org.apache.commons.math3.linear.MatrixUtils.solveLowerTriangularSystem(realMatrix28, realVector42);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 2");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(realVector38);
        org.junit.Assert.assertNotNull(realVector40);
        org.junit.Assert.assertNotNull(realVector42);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        java.lang.Integer[] intArray5 = new java.lang.Integer[] { 36, 125, 100, 10, 100 };
        java.lang.Integer[] intArray7 = new java.lang.Integer[] { 36 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException8 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray5, intArray7);
        java.lang.Integer[] intArray9 = multiDimensionMismatchException8.getExpectedDimensions();
        java.lang.Integer[] intArray10 = multiDimensionMismatchException8.getExpectedDimensions();
        try {
            int int12 = multiDimensionMismatchException8.getExpectedDimension((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray10);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.apache.commons.math3.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number) 1.0d);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
        org.apache.commons.math3.optim.nonlinear.vector.Target target2 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix3 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray0);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = diagonalMatrix3.power((int) ' ');
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = diagonalMatrix3.power((int) ' ');
        try {
            org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition(realMatrix7, (double) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(realMatrix7);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType0 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE;
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType1 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE;
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType2 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE;
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType[] goalTypeArray3 = new org.apache.commons.math3.optim.nonlinear.scalar.GoalType[] { goalType0, goalType1, goalType2 };
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection4 = null;
        try {
            boolean boolean6 = org.apache.commons.math3.util.MathArrays.isMonotonic(goalTypeArray3, orderDirection4, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + goalType0 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE + "'", goalType0.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE));
        org.junit.Assert.assertTrue("'" + goalType1 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE + "'", goalType1.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE));
        org.junit.Assert.assertTrue("'" + goalType2 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE + "'", goalType2.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE));
        org.junit.Assert.assertNotNull(goalTypeArray3);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType0 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE;
        org.junit.Assert.assertTrue("'" + goalType0 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE + "'", goalType0.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        double[] doubleArray1 = new double[] { (short) 1 };
        double[] doubleArray4 = new double[] { '#', (short) 100 };
        double[] doubleArray5 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight6 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray5);
        org.apache.commons.math3.optim.nonlinear.vector.Target target7 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray5);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix8 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4, doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector11 = arrayRealVector9.mapAdd(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1, arrayRealVector9);
        org.apache.commons.math3.optim.PointValuePair pointValuePair14 = new org.apache.commons.math3.optim.PointValuePair(doubleArray1, (double) 10);
        java.lang.Double double15 = pointValuePair14.getSecond();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector11);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 10.0d + "'", double15.equals(10.0d));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        float float1 = org.apache.commons.math3.util.FastMath.nextUp((float) 1072693279L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.07269331E9f + "'", float1 == 1.07269331E9f);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(125, (int) (byte) 100);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix2.getSubMatrix(1076101151, (int) (byte) 1, 10, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1,076,101,151)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number) 100);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(125, (int) (byte) 100);
        double[] doubleArray6 = new double[] { '#', (short) 100 };
        double[] doubleArray7 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight8 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray7);
        org.apache.commons.math3.optim.nonlinear.vector.Target target9 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray7);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix10 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, doubleArray7);
        org.apache.commons.math3.linear.RealVector realVector13 = arrayRealVector11.mapAdd(0.0d);
        org.apache.commons.math3.linear.RealVector realVector15 = arrayRealVector11.mapSubtract(2.2250738585072014E-308d);
        org.apache.commons.math3.linear.RealVector realVector17 = arrayRealVector11.mapAddToSelf(1.0E-15d);
        try {
            blockRealMatrix2.setColumnVector((int) (short) 0, realVector17);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 2x1 but expected 125x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(realVector17);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer5 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer((double) 100L, (double) 'a', (double) (byte) 1, (double) (short) -1, (double) (short) 1);
        int int6 = levenbergMarquardtOptimizer5.getEvaluations();
        double[] doubleArray7 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight8 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray7);
        org.apache.commons.math3.optim.nonlinear.vector.Target target9 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray7);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix10 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray7);
        org.apache.commons.math3.linear.RealMatrix realMatrix12 = diagonalMatrix10.power((int) ' ');
        double[] doubleArray13 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight14 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray13);
        org.apache.commons.math3.optim.nonlinear.vector.Target target15 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray13);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix16 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray13);
        double[] doubleArray17 = diagonalMatrix10.operate(doubleArray13);
        org.apache.commons.math3.util.MathUtils.checkFinite(doubleArray13);
        double[] doubleArray19 = null;
        boolean boolean20 = org.apache.commons.math3.util.MathArrays.equals(doubleArray13, doubleArray19);
        try {
            double[][] doubleArray22 = levenbergMarquardtOptimizer5.computeCovariances(doubleArray13, (double) 97.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(realMatrix12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        double double1 = org.apache.commons.math3.util.FastMath.asinh(9.677880210178613E53d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 125.0d + "'", double1 == 125.0d);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Integer[] intArray10 = new java.lang.Integer[] { 36, 125, 100, 10, 100 };
        java.lang.Integer[] intArray12 = new java.lang.Integer[] { 36 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException13 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray10, intArray12);
        org.apache.commons.math3.exception.NoBracketingException noBracketingException14 = new org.apache.commons.math3.exception.NoBracketingException(localizable0, 3600.0d, 0.8414709848078965d, (double) 125, 2.2250738585072014E-308d, (java.lang.Object[]) intArray10);
        double double15 = noBracketingException14.getHi();
        double double16 = noBracketingException14.getFLo();
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.8414709848078965d + "'", double15 == 0.8414709848078965d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 125.0d + "'", double16 == 125.0d);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
        org.apache.commons.math3.optim.nonlinear.vector.Target target2 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix3 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray0);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = diagonalMatrix3.power((int) ' ');
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = diagonalMatrix3.power((int) ' ');
        double[] doubleArray8 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight9 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray8);
        org.apache.commons.math3.optim.nonlinear.vector.Target target10 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray8);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix11 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray8);
        org.apache.commons.math3.linear.RealMatrix realMatrix13 = diagonalMatrix11.power((int) ' ');
        double[] doubleArray14 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight15 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray14);
        org.apache.commons.math3.optim.nonlinear.vector.Target target16 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray14);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix17 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray14);
        double[] doubleArray18 = diagonalMatrix11.operate(doubleArray14);
        double[] doubleArray19 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight20 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray19);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds21 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray18, doubleArray19);
        double[] doubleArray22 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight23 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray22);
        org.apache.commons.math3.optim.nonlinear.vector.Target target24 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray22);
        double[] doubleArray25 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray19, doubleArray22);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix27 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray19, true);
        org.apache.commons.math3.linear.RealMatrix realMatrix28 = diagonalMatrix3.preMultiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix27);
        java.lang.String str29 = diagonalMatrix27.toString();
        double[] doubleArray30 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight31 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray30);
        org.apache.commons.math3.optim.nonlinear.vector.Target target32 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray30);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix33 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray30);
        org.apache.commons.math3.linear.RealMatrix realMatrix35 = diagonalMatrix33.power((int) ' ');
        double[] doubleArray36 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight37 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray36);
        org.apache.commons.math3.optim.nonlinear.vector.Target target38 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray36);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix39 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray36);
        double[] doubleArray40 = diagonalMatrix33.operate(doubleArray36);
        double[] doubleArray41 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight42 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray41);
        org.apache.commons.math3.optim.nonlinear.vector.Target target43 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray41);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix44 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray41);
        double[] doubleArray45 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray40, doubleArray41);
        double[] doubleArray46 = diagonalMatrix27.operate(doubleArray41);
        double[] doubleArray47 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight48 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray47);
        org.apache.commons.math3.optim.nonlinear.vector.Target target49 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray47);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix50 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray47);
        org.apache.commons.math3.linear.RealMatrix realMatrix52 = diagonalMatrix50.power((int) ' ');
        org.apache.commons.math3.linear.RealMatrix realMatrix54 = diagonalMatrix50.power((int) ' ');
        double[] doubleArray55 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight56 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray55);
        org.apache.commons.math3.optim.nonlinear.vector.Target target57 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray55);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix58 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray55);
        org.apache.commons.math3.linear.RealMatrix realMatrix60 = diagonalMatrix58.power((int) ' ');
        double[] doubleArray61 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight62 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray61);
        org.apache.commons.math3.optim.nonlinear.vector.Target target63 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray61);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix64 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray61);
        double[] doubleArray65 = diagonalMatrix58.operate(doubleArray61);
        double[] doubleArray66 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight67 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray66);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds68 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray65, doubleArray66);
        double[] doubleArray69 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight70 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray69);
        org.apache.commons.math3.optim.nonlinear.vector.Target target71 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray69);
        double[] doubleArray72 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray66, doubleArray69);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix74 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray66, true);
        org.apache.commons.math3.linear.RealMatrix realMatrix75 = diagonalMatrix50.preMultiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix74);
        double[] doubleArray76 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight77 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray76);
        org.apache.commons.math3.optim.nonlinear.vector.Target target78 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray76);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix79 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray76);
        org.apache.commons.math3.linear.RealMatrix realMatrix81 = diagonalMatrix79.power((int) ' ');
        double[] doubleArray82 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight83 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray82);
        org.apache.commons.math3.optim.nonlinear.vector.Target target84 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray82);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix85 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray82);
        double[] doubleArray86 = diagonalMatrix79.operate(doubleArray82);
        double[] doubleArray87 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray86);
        double[] doubleArray88 = diagonalMatrix50.operate(doubleArray86);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix89 = diagonalMatrix27.add(diagonalMatrix50);
        double[][] doubleArray90 = diagonalMatrix27.getData();
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "DiagonalMatrix{}" + "'", str29.equals("DiagonalMatrix{}"));
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(realMatrix35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(realMatrix52);
        org.junit.Assert.assertNotNull(realMatrix54);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(realMatrix60);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(realMatrix75);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(realMatrix81);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertNotNull(diagonalMatrix89);
        org.junit.Assert.assertNotNull(doubleArray90);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        double double1 = org.apache.commons.math3.util.FastMath.cbrt((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.154434690031884d + "'", double1 == 2.154434690031884d);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
        org.apache.commons.math3.optim.nonlinear.vector.Target target2 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix3 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray0);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = diagonalMatrix3.power((int) ' ');
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = diagonalMatrix3.power((int) ' ');
        double[] doubleArray8 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight9 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray8);
        org.apache.commons.math3.optim.nonlinear.vector.Target target10 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray8);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix11 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray8);
        org.apache.commons.math3.linear.RealMatrix realMatrix13 = diagonalMatrix11.power((int) ' ');
        double[] doubleArray14 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight15 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray14);
        org.apache.commons.math3.optim.nonlinear.vector.Target target16 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray14);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix17 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray14);
        double[] doubleArray18 = diagonalMatrix11.operate(doubleArray14);
        double[] doubleArray19 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight20 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray19);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds21 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray18, doubleArray19);
        double[] doubleArray22 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight23 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray22);
        org.apache.commons.math3.optim.nonlinear.vector.Target target24 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray22);
        double[] doubleArray25 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray19, doubleArray22);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix27 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray19, true);
        org.apache.commons.math3.linear.RealMatrix realMatrix28 = diagonalMatrix3.preMultiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix27);
        org.apache.commons.math3.linear.RealMatrix realMatrix30 = diagonalMatrix27.power((int) (byte) 100);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor31 = null;
        try {
            double double36 = diagonalMatrix27.walkInColumnOrder(realMatrixChangingVisitor31, (int) ' ', 97, (int) ' ', 125);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (32)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertNotNull(realMatrix30);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.IdentityPreconditioner identityPreconditioner0 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.IdentityPreconditioner();
        double[] doubleArray1 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight2 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray1);
        org.apache.commons.math3.optim.nonlinear.vector.Target target3 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray1);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray1);
        org.apache.commons.math3.linear.RealMatrix realMatrix6 = diagonalMatrix4.power((int) ' ');
        double[] doubleArray7 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight8 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray7);
        org.apache.commons.math3.optim.nonlinear.vector.Target target9 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray7);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix10 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray7);
        double[] doubleArray11 = diagonalMatrix4.operate(doubleArray7);
        double[] doubleArray12 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight13 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray12);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds14 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray11, doubleArray12);
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight16 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray15);
        double[] doubleArray17 = identityPreconditioner0.precondition(doubleArray12, doubleArray15);
        double[] doubleArray18 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight19 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray18);
        org.apache.commons.math3.optim.nonlinear.vector.Target target20 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix21 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray18);
        org.apache.commons.math3.linear.RealMatrix realMatrix23 = diagonalMatrix21.power((int) ' ');
        double[] doubleArray24 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight25 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray24);
        org.apache.commons.math3.optim.nonlinear.vector.Target target26 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray24);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix27 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray24);
        double[] doubleArray28 = diagonalMatrix21.operate(doubleArray24);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds29 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray12, doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realMatrix23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray28);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
        org.apache.commons.math3.optim.nonlinear.vector.Target target2 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix3 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray0);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = diagonalMatrix3.power((int) ' ');
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = diagonalMatrix3.power((int) ' ');
        double[] doubleArray8 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight9 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray8);
        org.apache.commons.math3.optim.nonlinear.vector.Target target10 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray8);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix11 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray8);
        org.apache.commons.math3.linear.RealMatrix realMatrix13 = diagonalMatrix11.power((int) ' ');
        double[] doubleArray14 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight15 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray14);
        org.apache.commons.math3.optim.nonlinear.vector.Target target16 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray14);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix17 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray14);
        double[] doubleArray18 = diagonalMatrix11.operate(doubleArray14);
        double[] doubleArray19 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight20 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray19);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds21 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray18, doubleArray19);
        double[] doubleArray22 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight23 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray22);
        org.apache.commons.math3.optim.nonlinear.vector.Target target24 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray22);
        double[] doubleArray25 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray19, doubleArray22);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix27 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray19, true);
        org.apache.commons.math3.linear.RealMatrix realMatrix28 = diagonalMatrix3.preMultiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix27);
        double[] doubleArray29 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight30 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray29);
        org.apache.commons.math3.optim.nonlinear.vector.Target target31 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray29);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix32 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray29);
        org.apache.commons.math3.linear.RealMatrix realMatrix34 = diagonalMatrix32.power((int) ' ');
        double[] doubleArray35 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight36 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray35);
        org.apache.commons.math3.optim.nonlinear.vector.Target target37 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray35);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix38 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray35);
        double[] doubleArray39 = diagonalMatrix32.operate(doubleArray35);
        double[] doubleArray40 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray39);
        double[] doubleArray41 = diagonalMatrix3.operate(doubleArray39);
        int[] intArray44 = new int[] { 1, 52 };
        int[] intArray47 = new int[] { 100, 36 };
        int[] intArray54 = new int[] { 1, (short) 10, (short) 1, (byte) 10, (byte) 1, (short) -1 };
        int int55 = org.apache.commons.math3.util.MathArrays.distance1(intArray47, intArray54);
        int[] intArray60 = new int[] { 36, 0, 10, (short) -1 };
        int[] intArray61 = org.apache.commons.math3.util.MathArrays.copyOf(intArray60);
        int int62 = org.apache.commons.math3.util.MathArrays.distance1(intArray47, intArray61);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix63 = diagonalMatrix3.getSubMatrix(intArray44, intArray47);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(realMatrix34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertNotNull(intArray54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 125 + "'", int55 == 125);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 100 + "'", int62 == 100);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
        org.apache.commons.math3.optim.nonlinear.vector.Target target2 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix3 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray0);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = diagonalMatrix3.power((int) ' ');
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = diagonalMatrix3.power((int) ' ');
        double[] doubleArray8 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight9 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray8);
        org.apache.commons.math3.optim.nonlinear.vector.Target target10 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray8);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix11 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray8);
        org.apache.commons.math3.linear.RealMatrix realMatrix13 = diagonalMatrix11.power((int) ' ');
        double[] doubleArray14 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight15 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray14);
        org.apache.commons.math3.optim.nonlinear.vector.Target target16 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray14);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix17 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray14);
        double[] doubleArray18 = diagonalMatrix11.operate(doubleArray14);
        double[] doubleArray19 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight20 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray19);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds21 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray18, doubleArray19);
        double[] doubleArray22 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight23 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray22);
        org.apache.commons.math3.optim.nonlinear.vector.Target target24 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray22);
        double[] doubleArray25 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray19, doubleArray22);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix27 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray19, true);
        org.apache.commons.math3.linear.RealMatrix realMatrix28 = diagonalMatrix3.preMultiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix27);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor29 = null;
        try {
            double double34 = diagonalMatrix3.walkInOptimizedOrder(realMatrixChangingVisitor29, 0, (-1), (int) (byte) -1, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (0)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realMatrix28);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver1 = new org.apache.commons.math3.analysis.solvers.BrentSolver((double) 100L);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.apache.commons.math3.analysis.function.Sinc sinc0 = new org.apache.commons.math3.analysis.function.Sinc();
        double double2 = sinc0.value(0.0d);
        try {
            double double5 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.solve((org.apache.commons.math3.analysis.UnivariateFunction) sinc0, 10.0d, 2.993222846126381d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [10, 6.497]");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(125, (int) (byte) 100);
        double double3 = blockRealMatrix2.getNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = null;
        try {
            blockRealMatrix2.setRowMatrix((int) (short) 0, blockRealMatrix5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker2 = new org.apache.commons.math3.optim.SimpleValueChecker(9.999999999999998d, 136.0d);
        double double3 = simpleValueChecker2.getAbsoluteThreshold();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 136.0d + "'", double3 == 136.0d);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.apache.commons.math3.analysis.MultivariateVectorFunction multivariateVectorFunction0 = null;
        org.apache.commons.math3.optim.nonlinear.vector.ModelFunction modelFunction1 = new org.apache.commons.math3.optim.nonlinear.vector.ModelFunction(multivariateVectorFunction0);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat3 = new org.apache.commons.math3.linear.RealVectorFormat("hi!", "{", ",");
        double[] doubleArray5 = new double[] { (short) 1 };
        double[] doubleArray8 = new double[] { '#', (short) 100 };
        double[] doubleArray9 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight10 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray9);
        org.apache.commons.math3.optim.nonlinear.vector.Target target11 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray9);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix12 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray9);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray8, doubleArray9);
        org.apache.commons.math3.linear.RealVector realVector15 = arrayRealVector13.mapAdd(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5, arrayRealVector13);
        org.apache.commons.math3.linear.RealVector realVector18 = arrayRealVector16.mapAdd((double) (byte) 0);
        java.lang.String str19 = realVectorFormat3.format(realVector18);
        double[] doubleArray22 = new double[] { '#', (short) 100 };
        double[] doubleArray23 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight24 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray23);
        org.apache.commons.math3.optim.nonlinear.vector.Target target25 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray23);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray23);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray22, doubleArray23);
        org.apache.commons.math3.linear.RealVector realVector29 = arrayRealVector27.mapAdd(0.0d);
        org.apache.commons.math3.linear.RealVector realVector31 = arrayRealVector27.mapSubtract(2.2250738585072014E-308d);
        org.apache.commons.math3.linear.RealVector realVector33 = arrayRealVector27.mapAddToSelf(1.0E-15d);
        org.apache.commons.math3.linear.RealVector realVector35 = arrayRealVector27.mapAddToSelf((double) (short) 1);
        java.lang.String str36 = realVectorFormat3.format((org.apache.commons.math3.linear.RealVector) arrayRealVector27);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi!1,35,100{" + "'", str19.equals("hi!1,35,100{"));
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(realVector29);
        org.junit.Assert.assertNotNull(realVector31);
        org.junit.Assert.assertNotNull(realVector33);
        org.junit.Assert.assertNotNull(realVector35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "hi!36,101{" + "'", str36.equals("hi!36,101{"));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        int[] intArray2 = new int[] { 100, 36 };
        int[] intArray9 = new int[] { 1, (short) 10, (short) 1, (byte) 10, (byte) 1, (short) -1 };
        int int10 = org.apache.commons.math3.util.MathArrays.distance1(intArray2, intArray9);
        org.apache.commons.math3.random.MersenneTwister mersenneTwister12 = new org.apache.commons.math3.random.MersenneTwister((int) '#');
        double double13 = mersenneTwister12.nextDouble();
        long long14 = mersenneTwister12.nextLong();
        int[] intArray16 = new int[] { 125 };
        mersenneTwister12.setSeed(intArray16);
        try {
            int int18 = org.apache.commons.math3.util.MathArrays.distance1(intArray2, intArray16);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 125 + "'", int10 == 125);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.45805495157532494d + "'", double13 == 0.45805495157532494d);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 5688046246375236535L + "'", long14 == 5688046246375236535L);
        org.junit.Assert.assertNotNull(intArray16);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        java.lang.Integer[] intArray5 = new java.lang.Integer[] { 36, 125, 100, 10, 100 };
        java.lang.Integer[] intArray7 = new java.lang.Integer[] { 36 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException8 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray5, intArray7);
        java.lang.Integer[] intArray14 = new java.lang.Integer[] { 36, 125, 100, 10, 100 };
        java.lang.Integer[] intArray16 = new java.lang.Integer[] { 36 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException17 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray14, intArray16);
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException18 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray5, intArray16);
        java.lang.Throwable[] throwableArray19 = multiDimensionMismatchException18.getSuppressed();
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(throwableArray19);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(125, (int) (byte) 100);
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight5 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray4);
        org.apache.commons.math3.optim.nonlinear.vector.Target target6 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray4);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray4);
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = diagonalMatrix7.power((int) ' ');
        double[] doubleArray10 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight11 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray10);
        org.apache.commons.math3.optim.nonlinear.vector.Target target12 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray10);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix13 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray10);
        double[] doubleArray14 = diagonalMatrix7.operate(doubleArray10);
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight16 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray15);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds17 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray14, doubleArray15);
        double[] doubleArray18 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight19 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray18);
        org.apache.commons.math3.optim.nonlinear.vector.Target target20 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray18);
        double[] doubleArray21 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray15, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray15, true);
        try {
            blockRealMatrix2.setColumn((int) '4', doubleArray15);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 0x1 but expected 125x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray21);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        java.lang.Integer[] intArray5 = new java.lang.Integer[] { 36, 125, 100, 10, 100 };
        java.lang.Integer[] intArray7 = new java.lang.Integer[] { 36 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException8 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray5, intArray7);
        java.lang.Integer[] intArray9 = multiDimensionMismatchException8.getExpectedDimensions();
        java.lang.Integer[] intArray10 = multiDimensionMismatchException8.getExpectedDimensions();
        java.lang.Integer[] intArray11 = null;
        try {
            org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException12 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray10, intArray11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray10);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = org.apache.commons.math3.linear.RealVectorFormat.getInstance();
        org.junit.Assert.assertNotNull(realVectorFormat0);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.MatrixUtils.DEFAULT_FORMAT;
        java.lang.String str1 = realMatrixFormat0.getRowSeparator();
        double[] doubleArray2 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight3 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray2);
        org.apache.commons.math3.optim.nonlinear.vector.Target target4 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray2);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix5 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray2);
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = diagonalMatrix5.power((int) ' ');
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = diagonalMatrix5.power((int) ' ');
        double[] doubleArray10 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight11 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray10);
        org.apache.commons.math3.optim.nonlinear.vector.Target target12 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray10);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix13 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray10);
        org.apache.commons.math3.linear.RealMatrix realMatrix15 = diagonalMatrix13.power((int) ' ');
        double[] doubleArray16 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight17 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray16);
        org.apache.commons.math3.optim.nonlinear.vector.Target target18 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray16);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix19 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray16);
        double[] doubleArray20 = diagonalMatrix13.operate(doubleArray16);
        double[] doubleArray21 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight22 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray21);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds23 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray20, doubleArray21);
        double[] doubleArray24 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight25 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray24);
        org.apache.commons.math3.optim.nonlinear.vector.Target target26 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray24);
        double[] doubleArray27 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray21, doubleArray24);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix29 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray21, true);
        org.apache.commons.math3.linear.RealMatrix realMatrix30 = diagonalMatrix5.preMultiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix29);
        java.lang.String str31 = diagonalMatrix29.toString();
        double[] doubleArray32 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight33 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray32);
        org.apache.commons.math3.optim.nonlinear.vector.Target target34 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray32);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix35 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray32);
        org.apache.commons.math3.linear.RealMatrix realMatrix37 = diagonalMatrix35.power((int) ' ');
        double[] doubleArray38 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight39 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray38);
        org.apache.commons.math3.optim.nonlinear.vector.Target target40 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray38);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix41 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray38);
        double[] doubleArray42 = diagonalMatrix35.operate(doubleArray38);
        double[] doubleArray43 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight44 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray43);
        org.apache.commons.math3.optim.nonlinear.vector.Target target45 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray43);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix46 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray43);
        double[] doubleArray47 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray42, doubleArray43);
        double[] doubleArray48 = diagonalMatrix29.operate(doubleArray43);
        java.lang.String str49 = realMatrixFormat0.format((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix29);
        java.lang.String str50 = diagonalMatrix29.toString();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor51 = null;
        try {
            double double52 = diagonalMatrix29.walkInOptimizedOrder(realMatrixChangingVisitor51);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "," + "'", str1.equals(","));
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(realMatrix15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "DiagonalMatrix{}" + "'", str31.equals("DiagonalMatrix{}"));
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(realMatrix37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "{}" + "'", str49.equals("{}"));
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "DiagonalMatrix{}" + "'", str50.equals("DiagonalMatrix{}"));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((float) 1072693279L, (float) (byte) 1, 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        boolean boolean3 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.isSequence((double) (byte) 10, (double) 10.0f, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException(localizable0, (java.lang.Number) (-8.432689677745178E-5d), (java.lang.Number) 1.0f, (java.lang.Number) 11013.232920103323d);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        double double1 = org.apache.commons.math3.util.FastMath.acos((double) 10.0f);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        java.lang.Double[] doubleArray0 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        float float2 = org.apache.commons.math3.util.FastMath.scalb(1.07269331E9f, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.09843795E12f + "'", float2 == 1.09843795E12f);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer5 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer((double) 100L, (double) 'a', (double) (byte) 1, (double) (short) -1, (double) (short) 1);
        int int6 = levenbergMarquardtOptimizer5.getEvaluations();
        double[] doubleArray7 = levenbergMarquardtOptimizer5.getStartPoint();
        double[] doubleArray8 = levenbergMarquardtOptimizer5.getUpperBound();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNull(doubleArray7);
        org.junit.Assert.assertNull(doubleArray8);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math3.random.MersenneTwister((int) '#');
        double double7 = mersenneTwister6.nextDouble();
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker11 = new org.apache.commons.math3.optim.SimpleValueChecker((double) (byte) 1, (double) (short) 100);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer12 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer((int) '#', (double) (short) 1, true, 36, 10, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister6, true, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker11);
        mersenneTwister6.setSeed((-1L));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.45805495157532494d + "'", double7 == 0.45805495157532494d);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.apache.commons.math3.util.Incrementor incrementor0 = new org.apache.commons.math3.util.Incrementor();
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        int int2 = org.apache.commons.math3.util.MathUtils.copySign((int) '4', (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-52) + "'", int2 == (-52));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat6 = org.apache.commons.math3.linear.MatrixUtils.OCTAVE_FORMAT;
        java.text.NumberFormat numberFormat7 = realMatrixFormat6.getFormat();
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat8 = new org.apache.commons.math3.linear.RealMatrixFormat(", ", "hi!", "{", "", ", ", "DiagonalMatrix{}", numberFormat7);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = new org.apache.commons.math3.linear.BlockRealMatrix(125, (int) (byte) 100);
        java.lang.StringBuffer stringBuffer12 = null;
        java.text.FieldPosition fieldPosition13 = null;
        try {
            java.lang.StringBuffer stringBuffer14 = realMatrixFormat8.format((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix11, stringBuffer12, fieldPosition13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrixFormat6);
        org.junit.Assert.assertNotNull(numberFormat7);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(125, (int) (byte) 100);
        double[] doubleArray4 = new double[] { (short) 1 };
        double[] doubleArray7 = new double[] { '#', (short) 100 };
        double[] doubleArray8 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight9 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray8);
        org.apache.commons.math3.optim.nonlinear.vector.Target target10 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray8);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix11 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray7, doubleArray8);
        org.apache.commons.math3.linear.RealVector realVector14 = arrayRealVector12.mapAdd(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4, arrayRealVector12);
        org.apache.commons.math3.optim.PointValuePair pointValuePair17 = new org.apache.commons.math3.optim.PointValuePair(doubleArray4, (double) 10);
        double[] doubleArray18 = pointValuePair17.getFirst();
        try {
            double[] doubleArray19 = blockRealMatrix2.operate(doubleArray18);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 100");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertNotNull(doubleArray18);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        double double4 = org.apache.commons.math3.util.MathArrays.linearCombination(5.6880462463752366E18d, (double) (short) 100, (-0.8813735870195429d), (double) (short) -1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 5.6880462463752366E20d + "'", double4 == 5.6880462463752366E20d);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Integer[] intArray6 = new java.lang.Integer[] { 36, 125, 100, 10, 100 };
        java.lang.Integer[] intArray8 = new java.lang.Integer[] { 36 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException9 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray6, intArray8);
        java.lang.Integer[] intArray10 = multiDimensionMismatchException9.getExpectedDimensions();
        org.apache.commons.math3.exception.ZeroException zeroException11 = new org.apache.commons.math3.exception.ZeroException(localizable0, (java.lang.Object[]) intArray10);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray10);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.apache.commons.math3.util.Incrementor.MaxCountExceededCallback maxCountExceededCallback1 = null;
        try {
            org.apache.commons.math3.util.Incrementor incrementor2 = new org.apache.commons.math3.util.Incrementor(0, maxCountExceededCallback1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
        org.apache.commons.math3.optim.nonlinear.vector.Target target2 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix3 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray0);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = diagonalMatrix3.power((int) ' ');
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = diagonalMatrix3.power((int) ' ');
        double[] doubleArray8 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight9 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray8);
        org.apache.commons.math3.optim.nonlinear.vector.Target target10 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray8);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix11 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray8);
        org.apache.commons.math3.linear.RealMatrix realMatrix13 = diagonalMatrix11.power((int) ' ');
        double[] doubleArray14 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight15 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray14);
        org.apache.commons.math3.optim.nonlinear.vector.Target target16 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray14);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix17 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray14);
        double[] doubleArray18 = diagonalMatrix11.operate(doubleArray14);
        double[] doubleArray19 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight20 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray19);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds21 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray18, doubleArray19);
        double[] doubleArray22 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight23 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray22);
        org.apache.commons.math3.optim.nonlinear.vector.Target target24 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray22);
        double[] doubleArray25 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray19, doubleArray22);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix27 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray19, true);
        org.apache.commons.math3.linear.RealMatrix realMatrix28 = diagonalMatrix3.preMultiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix27);
        java.lang.String str29 = diagonalMatrix27.toString();
        try {
            diagonalMatrix27.setEntry(1, (int) 'a', (double) (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: 1 is larger than the maximum (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "DiagonalMatrix{}" + "'", str29.equals("DiagonalMatrix{}"));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
        org.apache.commons.math3.optim.nonlinear.vector.Target target2 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix3 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray0);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = diagonalMatrix3.power((int) ' ');
        boolean boolean6 = diagonalMatrix3.isTransposable();
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = diagonalMatrix3.copy();
        diagonalMatrix3.setEntry((int) (short) 100, 97, (double) 0.0f);
        org.apache.commons.math3.linear.RealMatrix realMatrix12 = diagonalMatrix3.copy();
        double[] doubleArray13 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight14 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray13);
        org.apache.commons.math3.optim.nonlinear.vector.Target target15 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray13);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix16 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray13);
        org.apache.commons.math3.linear.RealMatrix realMatrix18 = diagonalMatrix16.power((int) ' ');
        double[] doubleArray19 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight20 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray19);
        org.apache.commons.math3.optim.nonlinear.vector.Target target21 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray19);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix22 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray19);
        double[] doubleArray23 = diagonalMatrix16.operate(doubleArray19);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix24 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray19);
        org.apache.commons.math3.linear.RealMatrix realMatrix25 = diagonalMatrix3.multiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix24);
        try {
            double double28 = diagonalMatrix24.getEntry(52, 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(realMatrix12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realMatrix18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(realMatrix25);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
        org.apache.commons.math3.optim.nonlinear.vector.Target target2 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix3 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray0);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = diagonalMatrix3.power((int) ' ');
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = diagonalMatrix3.power((int) ' ');
        double[] doubleArray8 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight9 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray8);
        org.apache.commons.math3.optim.nonlinear.vector.Target target10 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray8);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix11 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray8);
        org.apache.commons.math3.linear.RealMatrix realMatrix13 = diagonalMatrix11.power((int) ' ');
        double[] doubleArray14 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight15 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray14);
        org.apache.commons.math3.optim.nonlinear.vector.Target target16 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray14);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix17 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray14);
        double[] doubleArray18 = diagonalMatrix11.operate(doubleArray14);
        double[] doubleArray19 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight20 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray19);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds21 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray18, doubleArray19);
        double[] doubleArray22 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight23 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray22);
        org.apache.commons.math3.optim.nonlinear.vector.Target target24 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray22);
        double[] doubleArray25 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray19, doubleArray22);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix27 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray19, true);
        org.apache.commons.math3.linear.RealMatrix realMatrix28 = diagonalMatrix3.preMultiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix27);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix30 = diagonalMatrix3.scalarAdd(100.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realMatrix28);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
        org.apache.commons.math3.optim.nonlinear.vector.Target target2 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix3 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray0);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = diagonalMatrix3.power((int) ' ');
        boolean boolean6 = diagonalMatrix3.isTransposable();
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = diagonalMatrix3.copy();
        try {
            org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition8 = new org.apache.commons.math3.linear.EigenDecomposition(realMatrix7);
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(realMatrix7);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver0 = new org.apache.commons.math3.analysis.solvers.BrentSolver();
        int int1 = brentSolver0.getEvaluations();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        double double8 = org.apache.commons.math3.util.MathArrays.linearCombination((double) (byte) 10, 1.0E-14d, 0.0d, (double) 1, (double) 1076101151, Double.NaN, Double.NaN, (double) 1.0f);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix2 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix((int) (short) 0, 97);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.apache.commons.math3.optim.SimpleVectorValueChecker simpleVectorValueChecker3 = new org.apache.commons.math3.optim.SimpleVectorValueChecker((double) (byte) 0, (double) 0L, 125);
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer4 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer((org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair>) simpleVectorValueChecker3);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math3.random.MersenneTwister((int) '#');
        double double2 = mersenneTwister1.nextDouble();
        mersenneTwister1.setSeed((int) (byte) 0);
        float float5 = mersenneTwister1.nextFloat();
        int int6 = mersenneTwister1.nextInt();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.45805495157532494d + "'", double2 == 0.45805495157532494d);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.54881346f + "'", float5 == 0.54881346f);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1748719057) + "'", int6 == (-1748719057));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math3.random.MersenneTwister((int) '#');
        double double7 = mersenneTwister6.nextDouble();
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker11 = new org.apache.commons.math3.optim.SimpleValueChecker((double) (byte) 1, (double) (short) 100);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer12 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer((int) '#', (double) (short) 1, true, 36, 10, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister6, true, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker11);
        java.util.List<org.apache.commons.math3.linear.RealMatrix> realMatrixList13 = cMAESOptimizer12.getStatisticsDHistory();
        java.util.List<java.lang.Double> doubleList14 = cMAESOptimizer12.getStatisticsSigmaHistory();
        java.util.List<java.lang.Double> doubleList15 = cMAESOptimizer12.getStatisticsFitnessHistory();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.45805495157532494d + "'", double7 == 0.45805495157532494d);
        org.junit.Assert.assertNotNull(realMatrixList13);
        org.junit.Assert.assertNotNull(doubleList14);
        org.junit.Assert.assertNotNull(doubleList15);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        double[] doubleArray3 = new double[] { '#', (byte) 100, (short) 100 };
        double[] doubleArray7 = new double[] { '#', (byte) 100, (short) 100 };
        double[] doubleArray11 = new double[] { '#', (byte) 100, (short) 100 };
        double[] doubleArray15 = new double[] { '#', (byte) 100, (short) 100 };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        double[][] doubleArray17 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray16);
        org.apache.commons.math3.linear.NonSquareMatrixException nonSquareMatrixException20 = new org.apache.commons.math3.linear.NonSquareMatrixException((int) (short) 1, (int) (short) 10);
        org.apache.commons.math3.util.Pair<java.lang.Object[], org.apache.commons.math3.exception.MathIllegalNumberException> objArrayPair21 = new org.apache.commons.math3.util.Pair<java.lang.Object[], org.apache.commons.math3.exception.MathIllegalNumberException>((java.lang.Object[]) doubleArray16, (org.apache.commons.math3.exception.MathIllegalNumberException) nonSquareMatrixException20);
        java.lang.Object[] objArray22 = objArrayPair21.getFirst();
        boolean boolean24 = objArrayPair21.equals((java.lang.Object) 1.09843795E12f);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
        org.apache.commons.math3.optim.nonlinear.vector.Target target2 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix3 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray0);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = diagonalMatrix3.power((int) ' ');
        boolean boolean6 = diagonalMatrix3.isTransposable();
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = diagonalMatrix3.copy();
        diagonalMatrix3.setEntry((int) (short) 100, 97, (double) 0.0f);
        org.apache.commons.math3.linear.RealMatrix realMatrix12 = diagonalMatrix3.copy();
        double[] doubleArray13 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight14 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray13);
        org.apache.commons.math3.optim.nonlinear.vector.Target target15 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray13);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix16 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray13);
        org.apache.commons.math3.linear.RealMatrix realMatrix18 = diagonalMatrix16.power((int) ' ');
        double[] doubleArray19 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight20 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray19);
        org.apache.commons.math3.optim.nonlinear.vector.Target target21 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray19);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix22 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray19);
        double[] doubleArray23 = diagonalMatrix16.operate(doubleArray19);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix24 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray19);
        org.apache.commons.math3.linear.RealMatrix realMatrix25 = diagonalMatrix3.multiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix24);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor26 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        defaultRealMatrixPreservingVisitor26.visit((int) ' ', (int) 'a', (double) 5688046246375236535L);
        try {
            double double35 = diagonalMatrix24.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor26, 125, (int) 'a', (int) '#', (int) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (125)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(realMatrix12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realMatrix18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(realMatrix25);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        double double1 = org.apache.commons.math3.util.FastMath.toRadians(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.017453292519943295d + "'", double1 == 0.017453292519943295d);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(125, (int) (byte) 100);
        double double3 = blockRealMatrix2.getNorm();
        try {
            blockRealMatrix2.multiplyEntry(0, (-1023), (double) (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (-1,023)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
        org.apache.commons.math3.optim.nonlinear.vector.Target target2 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix3 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray0);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = diagonalMatrix3.power((int) ' ');
        double[] doubleArray6 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight7 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray6);
        org.apache.commons.math3.optim.nonlinear.vector.Target target8 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray6);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix9 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6);
        double[] doubleArray10 = diagonalMatrix3.operate(doubleArray6);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight12 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray11);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds13 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray10, doubleArray11);
        double[] doubleArray14 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight15 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray14);
        org.apache.commons.math3.optim.nonlinear.vector.Target target16 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray14);
        double[] doubleArray17 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray11, doubleArray14);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix19 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray11, true);
        double[][] doubleArray20 = diagonalMatrix19.getData();
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray20);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
        org.apache.commons.math3.optim.nonlinear.vector.Target target2 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix3 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray0);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = diagonalMatrix3.power((int) ' ');
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = diagonalMatrix3.power((int) ' ');
        double[] doubleArray8 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight9 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray8);
        org.apache.commons.math3.optim.nonlinear.vector.Target target10 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray8);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix11 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray8);
        org.apache.commons.math3.linear.RealMatrix realMatrix13 = diagonalMatrix11.power((int) ' ');
        double[] doubleArray14 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight15 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray14);
        org.apache.commons.math3.optim.nonlinear.vector.Target target16 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray14);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix17 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray14);
        double[] doubleArray18 = diagonalMatrix11.operate(doubleArray14);
        double[] doubleArray19 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight20 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray19);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds21 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray18, doubleArray19);
        double[] doubleArray22 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight23 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray22);
        org.apache.commons.math3.optim.nonlinear.vector.Target target24 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray22);
        double[] doubleArray25 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray19, doubleArray22);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix27 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray19, true);
        org.apache.commons.math3.linear.RealMatrix realMatrix28 = diagonalMatrix3.preMultiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix27);
        double[] doubleArray29 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight30 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray29);
        org.apache.commons.math3.optim.nonlinear.vector.Target target31 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray29);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix32 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray29);
        org.apache.commons.math3.linear.RealMatrix realMatrix34 = diagonalMatrix32.power((int) ' ');
        double[] doubleArray35 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight36 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray35);
        org.apache.commons.math3.optim.nonlinear.vector.Target target37 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray35);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix38 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray35);
        double[] doubleArray39 = diagonalMatrix32.operate(doubleArray35);
        double[] doubleArray40 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight41 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray40);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds42 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray39, doubleArray40);
        double[] doubleArray43 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight44 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray43);
        org.apache.commons.math3.optim.nonlinear.vector.Target target45 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray43);
        double[] doubleArray46 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray40, doubleArray43);
        double[] doubleArray47 = diagonalMatrix27.preMultiply(doubleArray46);
        double[] doubleArray49 = new double[] { (short) 1 };
        double[] doubleArray52 = new double[] { '#', (short) 100 };
        double[] doubleArray53 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight54 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray53);
        org.apache.commons.math3.optim.nonlinear.vector.Target target55 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray53);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix56 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray53);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector57 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray52, doubleArray53);
        org.apache.commons.math3.linear.RealVector realVector59 = arrayRealVector57.mapAdd(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector60 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray49, arrayRealVector57);
        double double61 = arrayRealVector60.getL1Norm();
        double[] doubleArray62 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight63 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray62);
        org.apache.commons.math3.optim.nonlinear.vector.Target target64 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray62);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix65 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray62);
        org.apache.commons.math3.linear.RealMatrix realMatrix67 = diagonalMatrix65.power((int) ' ');
        double[] doubleArray68 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight69 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray68);
        org.apache.commons.math3.optim.nonlinear.vector.Target target70 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray68);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix71 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray68);
        double[] doubleArray72 = diagonalMatrix65.operate(doubleArray68);
        double[] doubleArray73 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray72);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector74 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector60, doubleArray73);
        try {
            org.apache.commons.math3.linear.MatrixUtils.solveLowerTriangularSystem((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix27, (org.apache.commons.math3.linear.RealVector) arrayRealVector60);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 3");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(realMatrix34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(realVector59);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 136.0d + "'", double61 == 136.0d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(realMatrix67);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray73);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        double[] doubleArray2 = new double[] { '#', (short) 100 };
        double[] doubleArray3 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight4 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray3);
        org.apache.commons.math3.optim.nonlinear.vector.Target target5 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray3);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix6 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray2, doubleArray3);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.mapDivide((double) 10.0f);
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat15 = new org.apache.commons.math3.linear.RealVectorFormat("hi!", "{", ",");
        double[] doubleArray17 = new double[] { (short) 1 };
        double[] doubleArray20 = new double[] { '#', (short) 100 };
        double[] doubleArray21 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight22 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray21);
        org.apache.commons.math3.optim.nonlinear.vector.Target target23 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray21);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix24 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray21);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray20, doubleArray21);
        org.apache.commons.math3.linear.RealVector realVector27 = arrayRealVector25.mapAdd(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray17, arrayRealVector25);
        org.apache.commons.math3.linear.RealVector realVector30 = arrayRealVector28.mapAdd((double) (byte) 0);
        java.lang.String str31 = realVectorFormat15.format(realVector30);
        org.apache.commons.math3.linear.RealVector realVector33 = realVector30.mapDivide(9.999999999999998d);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = arrayRealVector7.combine(9.677880210178613E53d, (double) 'a', realVector30);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 2 != 3");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(realVector27);
        org.junit.Assert.assertNotNull(realVector30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "hi!1,35,100{" + "'", str31.equals("hi!1,35,100{"));
        org.junit.Assert.assertNotNull(realVector33);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver1 = new org.apache.commons.math3.analysis.solvers.BrentSolver(0.0d);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        try {
            org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder2 = new org.apache.commons.math3.optim.univariate.BracketFinder(2.154434690031884d, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker2 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker(3.7663540285E10d, 0.0d);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        double[] doubleArray2 = new double[] { '#', (short) 100 };
        double[] doubleArray3 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight4 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray3);
        org.apache.commons.math3.optim.nonlinear.vector.Target target5 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray3);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix6 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray2, doubleArray3);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.mapAdd(0.0d);
        double[] doubleArray10 = arrayRealVector7.toArray();
        boolean boolean11 = arrayRealVector7.isInfinite();
        org.apache.commons.math3.linear.RealVector realVector13 = arrayRealVector7.mapDivide((double) 5688046246375236535L);
        org.apache.commons.math3.analysis.function.Sinc sinc14 = new org.apache.commons.math3.analysis.function.Sinc();
        double double16 = sinc14.value(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = arrayRealVector7.map((org.apache.commons.math3.analysis.UnivariateFunction) sinc14);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertNotNull(arrayRealVector17);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
        org.apache.commons.math3.optim.nonlinear.vector.Target target2 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix3 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray0);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = diagonalMatrix3.power((int) ' ');
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = diagonalMatrix3.power((int) ' ');
        double[] doubleArray8 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight9 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray8);
        org.apache.commons.math3.optim.nonlinear.vector.Target target10 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray8);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix11 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray8);
        org.apache.commons.math3.linear.RealMatrix realMatrix13 = diagonalMatrix11.power((int) ' ');
        double[] doubleArray14 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight15 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray14);
        org.apache.commons.math3.optim.nonlinear.vector.Target target16 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray14);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix17 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray14);
        double[] doubleArray18 = diagonalMatrix11.operate(doubleArray14);
        double[] doubleArray19 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight20 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray19);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds21 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray18, doubleArray19);
        double[] doubleArray22 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight23 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray22);
        org.apache.commons.math3.optim.nonlinear.vector.Target target24 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray22);
        double[] doubleArray25 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray19, doubleArray22);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix27 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray19, true);
        org.apache.commons.math3.linear.RealMatrix realMatrix28 = diagonalMatrix3.preMultiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix27);
        double[] doubleArray29 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight30 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray29);
        org.apache.commons.math3.optim.nonlinear.vector.Target target31 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray29);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix32 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray29);
        org.apache.commons.math3.linear.RealMatrix realMatrix34 = diagonalMatrix32.power((int) ' ');
        double[] doubleArray35 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight36 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray35);
        org.apache.commons.math3.optim.nonlinear.vector.Target target37 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray35);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix38 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray35);
        double[] doubleArray39 = diagonalMatrix32.operate(doubleArray35);
        double[] doubleArray40 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray39);
        double[] doubleArray41 = diagonalMatrix3.operate(doubleArray39);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor42 = null;
        try {
            double double47 = diagonalMatrix3.walkInRowOrder(realMatrixChangingVisitor42, (-1023), (int) '#', 125, (int) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1,023)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(realMatrix34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        float float2 = org.apache.commons.math3.util.FastMath.scalb((float) 10, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(125, (int) (byte) 100);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor3 = null;
        try {
            double double8 = blockRealMatrix2.walkInRowOrder(realMatrixChangingVisitor3, 1, (int) (short) 10, 1076101151, 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (1,076,101,151)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder0 = new org.apache.commons.math3.optim.univariate.BracketFinder();
        double double1 = bracketFinder0.getFMid();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math3.random.MersenneTwister((int) '#');
        double double2 = mersenneTwister1.nextDouble();
        mersenneTwister1.setSeed((int) (byte) 0);
        mersenneTwister1.clear();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.45805495157532494d + "'", double2 == 0.45805495157532494d);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat3 = new org.apache.commons.math3.linear.RealVectorFormat("hi!", "{", ",");
        java.text.NumberFormat numberFormat4 = realVectorFormat3.getFormat();
        org.junit.Assert.assertNotNull(numberFormat4);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        float[] floatArray0 = null;
        float[] floatArray3 = new float[] { (-1L), '4' };
        boolean boolean4 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(floatArray0, floatArray3);
        float[] floatArray6 = new float[] { (byte) 1 };
        float[] floatArray7 = null;
        boolean boolean8 = org.apache.commons.math3.util.MathArrays.equals(floatArray6, floatArray7);
        boolean boolean9 = org.apache.commons.math3.util.MathArrays.equals(floatArray0, floatArray6);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        double[] doubleArray2 = new double[] { '#', (short) 100 };
        double[] doubleArray3 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight4 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray3);
        org.apache.commons.math3.optim.nonlinear.vector.Target target5 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray3);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix6 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray2, doubleArray3);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.mapAdd(0.0d);
        org.apache.commons.math3.linear.RealVector realVector11 = arrayRealVector7.mapSubtract(2.2250738585072014E-308d);
        org.apache.commons.math3.linear.RealVector realVector13 = arrayRealVector7.mapAddToSelf(1.0E-15d);
        double[] doubleArray15 = new double[] { (short) 1 };
        double[] doubleArray18 = new double[] { '#', (short) 100 };
        double[] doubleArray19 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight20 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray19);
        org.apache.commons.math3.optim.nonlinear.vector.Target target21 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray19);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix22 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray19);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray18, doubleArray19);
        org.apache.commons.math3.linear.RealVector realVector25 = arrayRealVector23.mapAdd(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray15, arrayRealVector23);
        double[] doubleArray27 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight28 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray27);
        org.apache.commons.math3.optim.nonlinear.vector.Target target29 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray27);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix30 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray27);
        org.apache.commons.math3.linear.RealMatrix realMatrix32 = diagonalMatrix30.power((int) ' ');
        double[] doubleArray33 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight34 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray33);
        org.apache.commons.math3.optim.nonlinear.vector.Target target35 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray33);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix36 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray33);
        double[] doubleArray37 = diagonalMatrix30.operate(doubleArray33);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray37);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector26, arrayRealVector38);
        try {
            double double40 = arrayRealVector7.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector39);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 2 != 3");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(realVector11);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(realVector25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(realMatrix32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray37);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(125, (int) (byte) 100);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor3 = null;
        try {
            double double4 = blockRealMatrix2.walkInOptimizedOrder(realMatrixChangingVisitor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 125.0d, (java.lang.Number) 36, false);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
        org.apache.commons.math3.optim.nonlinear.vector.Target target2 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix3 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray0);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = diagonalMatrix3.power((int) ' ');
        boolean boolean6 = diagonalMatrix3.isTransposable();
        diagonalMatrix3.setEntry(100, (int) ' ', (double) 0L);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkRowIndex((org.apache.commons.math3.linear.AnyMatrix) diagonalMatrix3, 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(125, (int) (byte) 100);
        double[] doubleArray3 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight4 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray3);
        org.apache.commons.math3.optim.nonlinear.vector.Target target5 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray3);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix6 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = diagonalMatrix6.power((int) ' ');
        double[] doubleArray9 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight10 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray9);
        org.apache.commons.math3.optim.nonlinear.vector.Target target11 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray9);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix12 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray9);
        double[] doubleArray13 = diagonalMatrix6.operate(doubleArray9);
        double[] doubleArray14 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight15 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray14);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds16 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray13, doubleArray14);
        double[] doubleArray17 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight18 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray17);
        org.apache.commons.math3.optim.nonlinear.vector.Target target19 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray17);
        double[] doubleArray20 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray14, doubleArray17);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix22 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray14, true);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor23 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double24 = defaultRealMatrixPreservingVisitor23.end();
        double double25 = diagonalMatrix22.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor23);
        org.apache.commons.math3.linear.RealMatrix realMatrix26 = diagonalMatrix22.copy();
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = blockRealMatrix2.multiply(realMatrix26);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 100 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix26);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(125, (int) (byte) 100);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor3 = null;
        try {
            double double8 = blockRealMatrix2.walkInOptimizedOrder(realMatrixChangingVisitor3, 10, 0, 1076101151, (-52));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooSmallException; message: initial row 10 after final row 0");
        } catch (org.apache.commons.math3.exception.NumberIsTooSmallException e) {
        }
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.apache.commons.math3.linear.NonSymmetricMatrixException nonSymmetricMatrixException3 = new org.apache.commons.math3.linear.NonSymmetricMatrixException(0, (int) (byte) 10, (double) 0.54881346f);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        double[] doubleArray3 = new double[] { '#', (byte) 100, (short) 100 };
        double[] doubleArray7 = new double[] { '#', (byte) 100, (short) 100 };
        double[] doubleArray11 = new double[] { '#', (byte) 100, (short) 100 };
        double[] doubleArray15 = new double[] { '#', (byte) 100, (short) 100 };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        double[][] doubleArray17 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray16);
        org.apache.commons.math3.linear.NonSquareMatrixException nonSquareMatrixException20 = new org.apache.commons.math3.linear.NonSquareMatrixException((int) (short) 1, (int) (short) 10);
        org.apache.commons.math3.util.Pair<java.lang.Object[], org.apache.commons.math3.exception.MathIllegalNumberException> objArrayPair21 = new org.apache.commons.math3.util.Pair<java.lang.Object[], org.apache.commons.math3.exception.MathIllegalNumberException>((java.lang.Object[]) doubleArray16, (org.apache.commons.math3.exception.MathIllegalNumberException) nonSquareMatrixException20);
        java.lang.Object[] objArray22 = objArrayPair21.getKey();
        org.apache.commons.math3.exception.util.Localizable localizable23 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer powellOptimizer29 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer((double) 10, (double) 36, (double) (short) 100, (double) 0.0f);
        java.lang.Object[] objArray30 = new java.lang.Object[] { 1.09843795E12f, 10 };
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) objArrayPair21, localizable23, objArray30);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(objArray30);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(125, (int) (byte) 100);
        double double3 = blockRealMatrix2.getNorm();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor4 = null;
        try {
            double double5 = blockRealMatrix2.walkInRowOrder(realMatrixChangingVisitor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat3 = new org.apache.commons.math3.linear.RealVectorFormat("hi!", "{", ",");
        double[] doubleArray5 = new double[] { (short) 1 };
        double[] doubleArray8 = new double[] { '#', (short) 100 };
        double[] doubleArray9 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight10 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray9);
        org.apache.commons.math3.optim.nonlinear.vector.Target target11 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray9);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix12 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray9);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray8, doubleArray9);
        org.apache.commons.math3.linear.RealVector realVector15 = arrayRealVector13.mapAdd(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5, arrayRealVector13);
        org.apache.commons.math3.linear.RealVector realVector18 = arrayRealVector16.mapAdd((double) (byte) 0);
        java.lang.String str19 = realVectorFormat3.format(realVector18);
        java.lang.String str20 = realVectorFormat3.getPrefix();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi!1,35,100{" + "'", str19.equals("hi!1,35,100{"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hi!" + "'", str20.equals("hi!"));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
        org.apache.commons.math3.optim.nonlinear.vector.Target target2 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix3 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray0);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = diagonalMatrix3.power((int) ' ');
        boolean boolean6 = diagonalMatrix3.isTransposable();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor7 = null;
        try {
            double double8 = diagonalMatrix3.walkInOptimizedOrder(realMatrixChangingVisitor7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        double[] doubleArray3 = new double[] { '#', (byte) 100, (short) 100 };
        double[] doubleArray7 = new double[] { '#', (byte) 100, (short) 100 };
        double[] doubleArray11 = new double[] { '#', (byte) 100, (short) 100 };
        double[] doubleArray15 = new double[] { '#', (byte) 100, (short) 100 };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        double[][] doubleArray17 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray16);
        org.apache.commons.math3.linear.NonSquareMatrixException nonSquareMatrixException20 = new org.apache.commons.math3.linear.NonSquareMatrixException((int) (short) 1, (int) (short) 10);
        org.apache.commons.math3.util.Pair<java.lang.Object[], org.apache.commons.math3.exception.MathIllegalNumberException> objArrayPair21 = new org.apache.commons.math3.util.Pair<java.lang.Object[], org.apache.commons.math3.exception.MathIllegalNumberException>((java.lang.Object[]) doubleArray16, (org.apache.commons.math3.exception.MathIllegalNumberException) nonSquareMatrixException20);
        java.lang.Object[] objArray22 = objArrayPair21.getFirst();
        org.apache.commons.math3.exception.MathIllegalNumberException mathIllegalNumberException23 = objArrayPair21.getSecond();
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(mathIllegalNumberException23);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        double[] doubleArray2 = new double[] { '#', (short) 100 };
        double[] doubleArray3 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight4 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray3);
        org.apache.commons.math3.optim.nonlinear.vector.Target target5 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray3);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix6 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray2, doubleArray3);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.mapAdd(0.0d);
        org.apache.commons.math3.linear.RealVector realVector11 = arrayRealVector7.mapDivideToSelf((double) 97);
        arrayRealVector7.set((double) 100L);
        int int14 = arrayRealVector7.getDimension();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(realVector11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        short short2 = org.apache.commons.math3.util.MathUtils.copySign((short) 0, (short) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.apache.commons.math3.optim.univariate.BrentOptimizer brentOptimizer2 = new org.apache.commons.math3.optim.univariate.BrentOptimizer(0.7853981633974483d, 1.0E-15d);
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType3 = brentOptimizer2.getGoalType();
        double double4 = brentOptimizer2.getStartValue();
        double double5 = brentOptimizer2.getMin();
        double[] doubleArray6 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight7 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray6);
        org.apache.commons.math3.optim.nonlinear.vector.Target target8 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray6);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix9 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6);
        org.apache.commons.math3.optim.InitialGuess initialGuess10 = new org.apache.commons.math3.optim.InitialGuess(doubleArray6);
        org.apache.commons.math3.analysis.MultivariateFunction multivariateFunction11 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.ObjectiveFunction objectiveFunction12 = new org.apache.commons.math3.optim.nonlinear.scalar.ObjectiveFunction(multivariateFunction11);
        double[] doubleArray13 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight14 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray13);
        org.apache.commons.math3.optim.nonlinear.vector.Target target15 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray13);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex17 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex((int) (short) 10);
        org.apache.commons.math3.analysis.MultivariateVectorFunction multivariateVectorFunction18 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.ObjectiveFunctionGradient objectiveFunctionGradient19 = new org.apache.commons.math3.optim.nonlinear.scalar.ObjectiveFunctionGradient(multivariateVectorFunction18);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.PopulationSize populationSize21 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.PopulationSize(36);
        org.apache.commons.math3.optim.OptimizationData[] optimizationDataArray22 = new org.apache.commons.math3.optim.OptimizationData[] { initialGuess10, objectiveFunction12, target15, multiDirectionalSimplex17, objectiveFunctionGradient19, populationSize21 };
        try {
            org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair23 = brentOptimizer2.optimize(optimizationDataArray22);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.TooManyEvaluationsException; message: illegal state: maximal count (0) exceeded: evaluations");
        } catch (org.apache.commons.math3.exception.TooManyEvaluationsException e) {
        }
        org.junit.Assert.assertNull(goalType3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(optimizationDataArray22);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.apache.commons.math3.linear.AnyMatrix anyMatrix0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        double[] doubleArray5 = new double[] { '#', (byte) 100, (short) 100 };
        double[] doubleArray9 = new double[] { '#', (byte) 100, (short) 100 };
        double[] doubleArray13 = new double[] { '#', (byte) 100, (short) 100 };
        double[] doubleArray17 = new double[] { '#', (byte) 100, (short) 100 };
        double[][] doubleArray18 = new double[][] { doubleArray5, doubleArray9, doubleArray13, doubleArray17 };
        double[][] doubleArray19 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray18);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException20 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable1, (java.lang.Object[]) doubleArray19);
        org.apache.commons.math3.linear.RealMatrix realMatrix21 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray19);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible(anyMatrix0, (org.apache.commons.math3.linear.AnyMatrix) realMatrix21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(realMatrix21);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat1 = org.apache.commons.math3.linear.MatrixUtils.OCTAVE_FORMAT;
        java.text.NumberFormat numberFormat2 = realMatrixFormat1.getFormat();
        java.lang.StringBuffer stringBuffer3 = null;
        java.text.FieldPosition fieldPosition4 = null;
        try {
            java.lang.StringBuffer stringBuffer5 = org.apache.commons.math3.util.CompositeFormat.formatDouble(9.999999999999998d, numberFormat2, stringBuffer3, fieldPosition4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrixFormat1);
        org.junit.Assert.assertNotNull(numberFormat2);
    }

//    @Test
//    public void test362() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test362");
//        double double0 = org.apache.commons.math3.util.FastMath.random();
//        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.026263128777403777d + "'", double0 == 0.026263128777403777d);
//    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { (short) 1 };
        double[] doubleArray5 = new double[] { '#', (short) 100 };
        double[] doubleArray6 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight7 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray6);
        org.apache.commons.math3.optim.nonlinear.vector.Target target8 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray6);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix9 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5, doubleArray6);
        org.apache.commons.math3.linear.RealVector realVector12 = arrayRealVector10.mapAdd(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray2, arrayRealVector10);
        double double14 = arrayRealVector13.getL1Norm();
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight16 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray15);
        org.apache.commons.math3.optim.nonlinear.vector.Target target17 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray15);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray15);
        org.apache.commons.math3.linear.RealMatrix realMatrix20 = diagonalMatrix18.power((int) ' ');
        double[] doubleArray21 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight22 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray21);
        org.apache.commons.math3.optim.nonlinear.vector.Target target23 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray21);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix24 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray21);
        double[] doubleArray25 = diagonalMatrix18.operate(doubleArray21);
        double[] doubleArray26 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray25);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector13, doubleArray26);
        try {
            double double28 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray0, doubleArray26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 136.0d + "'", double14 == 136.0d);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        double double1 = org.apache.commons.math3.util.FastMath.expm1(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN(0.54881346f, (float) 1076101151, 36);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
        org.apache.commons.math3.optim.nonlinear.vector.Target target2 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix3 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray0);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = diagonalMatrix3.power((int) ' ');
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = diagonalMatrix3.power((int) ' ');
        double[] doubleArray8 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight9 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray8);
        org.apache.commons.math3.optim.nonlinear.vector.Target target10 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray8);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix11 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray8);
        org.apache.commons.math3.linear.RealMatrix realMatrix13 = diagonalMatrix11.power((int) ' ');
        double[] doubleArray14 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight15 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray14);
        org.apache.commons.math3.optim.nonlinear.vector.Target target16 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray14);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix17 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray14);
        double[] doubleArray18 = diagonalMatrix11.operate(doubleArray14);
        double[] doubleArray19 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight20 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray19);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds21 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray18, doubleArray19);
        double[] doubleArray22 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight23 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray22);
        org.apache.commons.math3.optim.nonlinear.vector.Target target24 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray22);
        double[] doubleArray25 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray19, doubleArray22);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix27 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray19, true);
        org.apache.commons.math3.linear.RealMatrix realMatrix28 = diagonalMatrix3.preMultiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix27);
        java.lang.String str29 = diagonalMatrix27.toString();
        double[] doubleArray30 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight31 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray30);
        org.apache.commons.math3.optim.nonlinear.vector.Target target32 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray30);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix33 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray30);
        org.apache.commons.math3.linear.RealMatrix realMatrix35 = diagonalMatrix33.power((int) ' ');
        double[] doubleArray36 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight37 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray36);
        org.apache.commons.math3.optim.nonlinear.vector.Target target38 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray36);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix39 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray36);
        double[] doubleArray40 = diagonalMatrix33.operate(doubleArray36);
        double[] doubleArray41 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight42 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray41);
        org.apache.commons.math3.optim.nonlinear.vector.Target target43 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray41);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix44 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray41);
        double[] doubleArray45 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray40, doubleArray41);
        double[] doubleArray46 = diagonalMatrix27.operate(doubleArray41);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix48 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray41, false);
        try {
            diagonalMatrix48.addToEntry((int) (byte) -1, (int) 'a', 1.059306170823243d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: 1.059 is larger than the maximum (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "DiagonalMatrix{}" + "'", str29.equals("DiagonalMatrix{}"));
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(realMatrix35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        long[] longArray3 = new long[] { 52, 100, 97 };
        long[] longArray7 = new long[] { 52, 100, 97 };
        long[] longArray11 = new long[] { 52, 100, 97 };
        long[] longArray15 = new long[] { 52, 100, 97 };
        long[] longArray19 = new long[] { 52, 100, 97 };
        long[][] longArray20 = new long[][] { longArray3, longArray7, longArray11, longArray15, longArray19 };
        org.apache.commons.math3.util.MathArrays.checkRectangular(longArray20);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(longArray11);
        org.junit.Assert.assertNotNull(longArray15);
        org.junit.Assert.assertNotNull(longArray19);
        org.junit.Assert.assertNotNull(longArray20);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.apache.commons.math3.optim.SimpleVectorValueChecker simpleVectorValueChecker3 = new org.apache.commons.math3.optim.SimpleVectorValueChecker((double) (byte) 0, (double) 0L, 125);
        double double4 = simpleVectorValueChecker3.getRelativeThreshold();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula0 = org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES;
        org.apache.commons.math3.random.MersenneTwister mersenneTwister7 = new org.apache.commons.math3.random.MersenneTwister((int) '#');
        double double8 = mersenneTwister7.nextDouble();
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker12 = new org.apache.commons.math3.optim.SimpleValueChecker((double) (byte) 1, (double) (short) 100);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer13 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer((int) '#', (double) (short) 1, true, 36, 10, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister7, true, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker12);
        double double14 = simpleValueChecker12.getAbsoluteThreshold();
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver15 = new org.apache.commons.math3.analysis.solvers.BrentSolver();
        double double16 = brentSolver15.getRelativeAccuracy();
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer17 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker12, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver15);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula18 = org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES;
        org.apache.commons.math3.random.MersenneTwister mersenneTwister25 = new org.apache.commons.math3.random.MersenneTwister((int) '#');
        double double26 = mersenneTwister25.nextDouble();
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker30 = new org.apache.commons.math3.optim.SimpleValueChecker((double) (byte) 1, (double) (short) 100);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer31 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer((int) '#', (double) (short) 1, true, 36, 10, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister25, true, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker30);
        double double32 = simpleValueChecker30.getAbsoluteThreshold();
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver33 = new org.apache.commons.math3.analysis.solvers.BrentSolver();
        double double34 = brentSolver33.getRelativeAccuracy();
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer35 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula18, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker30, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver33);
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver39 = new org.apache.commons.math3.analysis.solvers.BrentSolver(1.0E-14d, (double) (byte) 0, 0.7853981633974483d);
        org.apache.commons.math3.analysis.function.Sinc sinc41 = new org.apache.commons.math3.analysis.function.Sinc();
        double double44 = brentSolver39.solve((int) (short) 100, (org.apache.commons.math3.analysis.UnivariateFunction) sinc41, 0.0d, 3.7663540285E10d);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer45 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker30, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver39);
        double double46 = brentSolver39.getAbsoluteAccuracy();
        org.junit.Assert.assertTrue("'" + formula0 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES + "'", formula0.equals(org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.45805495157532494d + "'", double8 == 0.45805495157532494d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 100.0d + "'", double14 == 100.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0E-14d + "'", double16 == 1.0E-14d);
        org.junit.Assert.assertTrue("'" + formula18 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES + "'", formula18.equals(org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES));
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.45805495157532494d + "'", double26 == 0.45805495157532494d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 100.0d + "'", double32 == 100.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 1.0E-14d + "'", double34 == 1.0E-14d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 1.88317701425E10d + "'", double44 == 1.88317701425E10d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        double double2 = org.apache.commons.math3.util.FastMath.IEEEremainder((double) 0.54881346f, 0.0d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.apache.commons.math3.util.Incrementor incrementor1 = new org.apache.commons.math3.util.Incrementor(0);
        int int2 = incrementor1.getMaximalCount();
        boolean boolean3 = incrementor1.canIncrement();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer5 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer((double) 100L, (double) 'a', (double) (byte) 1, (double) (short) -1, (double) (short) 1);
        int int6 = levenbergMarquardtOptimizer5.getEvaluations();
        double[] doubleArray7 = levenbergMarquardtOptimizer5.getStartPoint();
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair> pointVectorValuePairConvergenceChecker8 = levenbergMarquardtOptimizer5.getConvergenceChecker();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNull(doubleArray7);
        org.junit.Assert.assertNull(pointVectorValuePairConvergenceChecker8);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        int[] intArray2 = new int[] { 100, 36 };
        int[] intArray9 = new int[] { 1, (short) 10, (short) 1, (byte) 10, (byte) 1, (short) -1 };
        int int10 = org.apache.commons.math3.util.MathArrays.distance1(intArray2, intArray9);
        int[] intArray15 = new int[] { 36, 0, 10, (short) -1 };
        int[] intArray16 = org.apache.commons.math3.util.MathArrays.copyOf(intArray15);
        int int17 = org.apache.commons.math3.util.MathArrays.distance1(intArray2, intArray16);
        int[] intArray22 = new int[] { 36, 0, 10, (short) -1 };
        int[] intArray23 = org.apache.commons.math3.util.MathArrays.copyOf(intArray22);
        int int24 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray2, intArray23);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 125 + "'", int10 == 125);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 100 + "'", int17 == 100);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 64 + "'", int24 == 64);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        double double2 = org.apache.commons.math3.util.FastMath.hypot((double) ' ', (double) 1072693279);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0726932790000005E9d + "'", double2 == 1.0726932790000005E9d);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
        org.apache.commons.math3.optim.nonlinear.vector.Target target2 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix3 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray0);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = diagonalMatrix3.power((int) ' ');
        boolean boolean6 = diagonalMatrix3.isTransposable();
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = diagonalMatrix3.copy();
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.IdentityPreconditioner identityPreconditioner8 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.IdentityPreconditioner();
        double[] doubleArray9 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight10 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray9);
        org.apache.commons.math3.optim.nonlinear.vector.Target target11 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray9);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix12 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray9);
        org.apache.commons.math3.linear.RealMatrix realMatrix14 = diagonalMatrix12.power((int) ' ');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight16 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray15);
        org.apache.commons.math3.optim.nonlinear.vector.Target target17 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray15);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray15);
        double[] doubleArray19 = diagonalMatrix12.operate(doubleArray15);
        double[] doubleArray20 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight21 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray20);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds22 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray19, doubleArray20);
        double[] doubleArray23 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight24 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray23);
        double[] doubleArray25 = identityPreconditioner8.precondition(doubleArray20, doubleArray23);
        double[] doubleArray28 = new double[] { '#', (short) 100 };
        double[] doubleArray29 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight30 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray29);
        org.apache.commons.math3.optim.nonlinear.vector.Target target31 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray29);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix32 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray29);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray28, doubleArray29);
        double double34 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray23, doubleArray29);
        org.apache.commons.math3.linear.RealVector realVector35 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray23);
        double[] doubleArray36 = diagonalMatrix3.preMultiply(doubleArray23);
        org.apache.commons.math3.optim.PointValuePair pointValuePair39 = new org.apache.commons.math3.optim.PointValuePair(doubleArray36, 9.999999999999998d, false);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(realVector35);
        org.junit.Assert.assertNotNull(doubleArray36);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        try {
            float float3 = org.apache.commons.math3.util.Precision.round((float) 1072693279, (int) 'a', 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: invalid rounding method 100, valid methods: ROUND_CEILING (2), ROUND_DOWN (1), ROUND_FLOOR (3), ROUND_HALF_DOWN (5), ROUND_HALF_EVEN (6), ROUND_HALF_UP (4), ROUND_UNNECESSARY (7), ROUND_UP (0)");
        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
        }
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { 10L, (-1), (-1), 100.0f, (byte) 100, (short) 0 };
        org.apache.commons.math3.exception.ZeroException zeroException9 = new org.apache.commons.math3.exception.ZeroException(localizable1, objArray8);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException10 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable0, objArray8);
        java.lang.Throwable[] throwableArray11 = mathIllegalStateException10.getSuppressed();
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(throwableArray11);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder0 = new org.apache.commons.math3.optim.univariate.BracketFinder();
        double double1 = bracketFinder0.getLo();
        int int2 = bracketFinder0.getEvaluations();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        short short2 = org.apache.commons.math3.util.MathUtils.copySign((short) 0, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        java.lang.Object[] objArray1 = new java.lang.Object[] {};
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException2 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number) 0, objArray1);
        org.junit.Assert.assertNotNull(objArray1);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair> pointVectorValuePairConvergenceChecker0 = null;
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer gaussNewtonOptimizer1 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer(pointVectorValuePairConvergenceChecker0);
        double[] doubleArray3 = new double[] { (short) 1 };
        double[] doubleArray6 = new double[] { '#', (short) 100 };
        double[] doubleArray7 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight8 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray7);
        org.apache.commons.math3.optim.nonlinear.vector.Target target9 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray7);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix10 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, doubleArray7);
        org.apache.commons.math3.linear.RealVector realVector13 = arrayRealVector11.mapAdd(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray3, arrayRealVector11);
        org.apache.commons.math3.optim.PointValuePair pointValuePair16 = new org.apache.commons.math3.optim.PointValuePair(doubleArray3, (double) 10);
        double[] doubleArray17 = pointValuePair16.getFirst();
        org.apache.commons.math3.optim.InitialGuess initialGuess18 = new org.apache.commons.math3.optim.InitialGuess(doubleArray17);
        try {
            double[][] doubleArray20 = gaussNewtonOptimizer1.computeCovariances(doubleArray17, (double) 100.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertNotNull(doubleArray17);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
        double[] doubleArray2 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight3 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray2);
        boolean boolean4 = org.apache.commons.math3.util.MathArrays.equals(doubleArray0, doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        double double1 = org.apache.commons.math3.util.FastMath.signum((double) 1.09843795E12f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        double[] doubleArray1 = new double[] { (short) 1 };
        double[] doubleArray4 = new double[] { '#', (short) 100 };
        double[] doubleArray5 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight6 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray5);
        org.apache.commons.math3.optim.nonlinear.vector.Target target7 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray5);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix8 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4, doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector11 = arrayRealVector9.mapAdd(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1, arrayRealVector9);
        boolean boolean13 = arrayRealVector12.isNaN();
        org.apache.commons.math3.linear.RealVector realVector15 = arrayRealVector12.mapSubtract(0.0d);
        org.apache.commons.math3.linear.RealVector realVector17 = arrayRealVector12.mapMultiply(1.1752011936438014d);
        double[] doubleArray20 = new double[] { '#', (short) 100 };
        double[] doubleArray21 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight22 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray21);
        org.apache.commons.math3.optim.nonlinear.vector.Target target23 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray21);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix24 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray21);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray20, doubleArray21);
        org.apache.commons.math3.linear.RealVector realVector27 = arrayRealVector25.mapAdd(0.0d);
        org.apache.commons.math3.linear.RealVector realVector29 = arrayRealVector25.mapDivideToSelf((double) 97);
        try {
            double double30 = arrayRealVector12.getDistance(realVector29);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 3 != 2");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(realVector27);
        org.junit.Assert.assertNotNull(realVector29);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.apache.commons.math3.optim.univariate.BrentOptimizer brentOptimizer2 = new org.apache.commons.math3.optim.univariate.BrentOptimizer(0.7853981633974483d, 1.0E-15d);
        int int3 = brentOptimizer2.getEvaluations();
        int int4 = brentOptimizer2.getIterations();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.MatrixUtils.OCTAVE_FORMAT;
        java.text.NumberFormat numberFormat1 = realMatrixFormat0.getFormat();
        java.lang.String str2 = realMatrixFormat0.getColumnSeparator();
        java.lang.String str3 = realMatrixFormat0.getSuffix();
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ", " + "'", str2.equals(", "));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "]" + "'", str3.equals("]"));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.apache.commons.math3.linear.SingularMatrixException singularMatrixException0 = new org.apache.commons.math3.linear.SingularMatrixException();
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        double[] doubleArray2 = new double[] { '#', (short) 100 };
        double[] doubleArray3 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight4 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray3);
        org.apache.commons.math3.optim.nonlinear.vector.Target target5 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray3);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix6 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray2, doubleArray3);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.mapAdd(0.0d);
        double[] doubleArray10 = arrayRealVector7.toArray();
        org.apache.commons.math3.linear.RealVector realVector12 = arrayRealVector7.mapDivide(52.0d);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(realVector12);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(125, (int) (byte) 100);
        double double3 = blockRealMatrix2.getNorm();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor4 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double5 = defaultRealMatrixPreservingVisitor4.end();
        double double6 = blockRealMatrix2.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor4);
        double[] doubleArray8 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight9 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray8);
        org.apache.commons.math3.optim.nonlinear.vector.Target target10 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray8);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix11 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray8);
        org.apache.commons.math3.linear.RealMatrix realMatrix13 = diagonalMatrix11.power((int) ' ');
        double[] doubleArray14 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight15 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray14);
        org.apache.commons.math3.optim.nonlinear.vector.Target target16 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray14);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix17 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray14);
        org.apache.commons.math3.linear.RealMatrix realMatrix19 = diagonalMatrix17.power((int) ' ');
        double[] doubleArray20 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight21 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray20);
        org.apache.commons.math3.optim.nonlinear.vector.Target target22 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray20);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray20);
        double[] doubleArray24 = diagonalMatrix17.operate(doubleArray20);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray24);
        double[] doubleArray26 = diagonalMatrix11.preMultiply(doubleArray24);
        try {
            blockRealMatrix2.setRowMatrix(2147483647, (org.apache.commons.math3.linear.RealMatrix) diagonalMatrix11);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (2,147,483,647)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realMatrix19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.MatrixUtils.DEFAULT_FORMAT;
        java.lang.String str1 = realMatrixFormat0.getRowSeparator();
        java.lang.String str2 = realMatrixFormat0.getRowPrefix();
        java.lang.String str3 = realMatrixFormat0.getRowSeparator();
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "," + "'", str1.equals(","));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{" + "'", str2.equals("{"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "," + "'", str3.equals(","));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula0 = org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES;
        org.apache.commons.math3.random.MersenneTwister mersenneTwister7 = new org.apache.commons.math3.random.MersenneTwister((int) '#');
        double double8 = mersenneTwister7.nextDouble();
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker12 = new org.apache.commons.math3.optim.SimpleValueChecker((double) (byte) 1, (double) (short) 100);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer13 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer((int) '#', (double) (short) 1, true, 36, 10, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister7, true, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker12);
        double double14 = simpleValueChecker12.getAbsoluteThreshold();
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver15 = new org.apache.commons.math3.analysis.solvers.BrentSolver();
        double double16 = brentSolver15.getRelativeAccuracy();
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer17 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker12, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver15);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula18 = org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES;
        org.apache.commons.math3.random.MersenneTwister mersenneTwister25 = new org.apache.commons.math3.random.MersenneTwister((int) '#');
        double double26 = mersenneTwister25.nextDouble();
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker30 = new org.apache.commons.math3.optim.SimpleValueChecker((double) (byte) 1, (double) (short) 100);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer31 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer((int) '#', (double) (short) 1, true, 36, 10, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister25, true, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker30);
        double double32 = simpleValueChecker30.getAbsoluteThreshold();
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver33 = new org.apache.commons.math3.analysis.solvers.BrentSolver();
        double double34 = brentSolver33.getRelativeAccuracy();
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer35 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula18, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker30, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver33);
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver39 = new org.apache.commons.math3.analysis.solvers.BrentSolver(1.0E-14d, (double) (byte) 0, 0.7853981633974483d);
        org.apache.commons.math3.analysis.function.Sinc sinc41 = new org.apache.commons.math3.analysis.function.Sinc();
        double double44 = brentSolver39.solve((int) (short) 100, (org.apache.commons.math3.analysis.UnivariateFunction) sinc41, 0.0d, 3.7663540285E10d);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer45 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker30, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver39);
        int int46 = brentSolver39.getEvaluations();
        int int47 = brentSolver39.getEvaluations();
        org.junit.Assert.assertTrue("'" + formula0 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES + "'", formula0.equals(org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.45805495157532494d + "'", double8 == 0.45805495157532494d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 100.0d + "'", double14 == 100.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0E-14d + "'", double16 == 1.0E-14d);
        org.junit.Assert.assertTrue("'" + formula18 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES + "'", formula18.equals(org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES));
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.45805495157532494d + "'", double26 == 0.45805495157532494d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 100.0d + "'", double32 == 100.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 1.0E-14d + "'", double34 == 1.0E-14d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 1.88317701425E10d + "'", double44 == 1.88317701425E10d);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
        org.apache.commons.math3.optim.nonlinear.vector.Target target2 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix3 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray0);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = diagonalMatrix3.power((int) ' ');
        boolean boolean6 = diagonalMatrix3.isTransposable();
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = diagonalMatrix3.copy();
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.IdentityPreconditioner identityPreconditioner8 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.IdentityPreconditioner();
        double[] doubleArray9 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight10 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray9);
        org.apache.commons.math3.optim.nonlinear.vector.Target target11 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray9);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix12 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray9);
        org.apache.commons.math3.linear.RealMatrix realMatrix14 = diagonalMatrix12.power((int) ' ');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight16 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray15);
        org.apache.commons.math3.optim.nonlinear.vector.Target target17 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray15);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray15);
        double[] doubleArray19 = diagonalMatrix12.operate(doubleArray15);
        double[] doubleArray20 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight21 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray20);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds22 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray19, doubleArray20);
        double[] doubleArray23 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight24 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray23);
        double[] doubleArray25 = identityPreconditioner8.precondition(doubleArray20, doubleArray23);
        double[] doubleArray28 = new double[] { '#', (short) 100 };
        double[] doubleArray29 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight30 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray29);
        org.apache.commons.math3.optim.nonlinear.vector.Target target31 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray29);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix32 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray29);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray28, doubleArray29);
        double double34 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray23, doubleArray29);
        org.apache.commons.math3.linear.RealVector realVector35 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray23);
        double[] doubleArray36 = diagonalMatrix3.preMultiply(doubleArray23);
        java.io.ObjectInputStream objectInputStream38 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.deserializeRealVector((java.lang.Object) diagonalMatrix3, "hi!1,35,100{", objectInputStream38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(realVector35);
        org.junit.Assert.assertNotNull(doubleArray36);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
        org.apache.commons.math3.optim.nonlinear.vector.Target target2 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix3 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray0);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = diagonalMatrix3.power((int) ' ');
        double[] doubleArray6 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight7 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray6);
        org.apache.commons.math3.optim.nonlinear.vector.Target target8 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray6);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix9 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6);
        double[] doubleArray10 = diagonalMatrix3.operate(doubleArray6);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight12 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray11);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds13 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray10, doubleArray11);
        double[] doubleArray14 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight15 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray14);
        org.apache.commons.math3.optim.nonlinear.vector.Target target16 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray14);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix17 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray14);
        org.apache.commons.math3.linear.RealMatrix realMatrix19 = diagonalMatrix17.power((int) ' ');
        double[] doubleArray20 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight21 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray20);
        org.apache.commons.math3.optim.nonlinear.vector.Target target22 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray20);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray20);
        double[] doubleArray24 = diagonalMatrix17.operate(doubleArray20);
        double[] doubleArray25 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight26 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray25);
        org.apache.commons.math3.optim.nonlinear.vector.Target target27 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray25);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix28 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray25);
        double[] doubleArray29 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray24, doubleArray25);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray11, doubleArray25);
        double[] doubleArray31 = null;
        try {
            double[] doubleArray32 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray25, doubleArray31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realMatrix19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        double[] doubleArray1 = new double[] { (short) 1 };
        double[] doubleArray4 = new double[] { '#', (short) 100 };
        double[] doubleArray5 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight6 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray5);
        org.apache.commons.math3.optim.nonlinear.vector.Target target7 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray5);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix8 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4, doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector11 = arrayRealVector9.mapAdd(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1, arrayRealVector9);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex13 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray1);
        double[] doubleArray14 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight15 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray14);
        org.apache.commons.math3.optim.nonlinear.vector.Target target16 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray14);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix17 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray14);
        org.apache.commons.math3.linear.RealMatrix realMatrix19 = diagonalMatrix17.power((int) ' ');
        double[] doubleArray20 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight21 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray20);
        org.apache.commons.math3.optim.nonlinear.vector.Target target22 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray20);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray20);
        double[] doubleArray24 = diagonalMatrix17.operate(doubleArray20);
        double[] doubleArray25 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight26 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray25);
        org.apache.commons.math3.optim.nonlinear.vector.Target target27 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray25);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix28 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray25);
        double[] doubleArray29 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray24, doubleArray25);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1, doubleArray24);
        org.apache.commons.math3.linear.RealVector realVector32 = arrayRealVector30.mapDivide(1.1752011936438014d);
        double[] doubleArray35 = new double[] { (short) 1 };
        double[] doubleArray38 = new double[] { '#', (short) 100 };
        double[] doubleArray39 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight40 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray39);
        org.apache.commons.math3.optim.nonlinear.vector.Target target41 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray39);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix42 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray39);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector43 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray38, doubleArray39);
        org.apache.commons.math3.linear.RealVector realVector45 = arrayRealVector43.mapAdd(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray35, arrayRealVector43);
        org.apache.commons.math3.optim.PointValuePair pointValuePair48 = new org.apache.commons.math3.optim.PointValuePair(doubleArray35, (double) 10);
        double[] doubleArray49 = pointValuePair48.getFirst();
        double[] doubleArray51 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray49, (double) (short) 1);
        try {
            arrayRealVector30.setSubVector(125, doubleArray51);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (125)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realMatrix19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(realVector32);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(realVector45);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray51);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        double[] doubleArray1 = new double[] { (short) 1 };
        double[] doubleArray4 = new double[] { '#', (short) 100 };
        double[] doubleArray5 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight6 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray5);
        org.apache.commons.math3.optim.nonlinear.vector.Target target7 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray5);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix8 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4, doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector11 = arrayRealVector9.mapAdd(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1, arrayRealVector9);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex13 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray1);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex18 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray1, (-1.0d), (-1.0d), 0.8414709848078965d, (double) 36);
        int int19 = nelderMeadSimplex18.getDimension();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector11);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals(0.0d, 0.0d, 10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        double[] doubleArray3 = new double[] { '#', (byte) 100, (short) 100 };
        double[] doubleArray7 = new double[] { '#', (byte) 100, (short) 100 };
        double[] doubleArray11 = new double[] { '#', (byte) 100, (short) 100 };
        double[] doubleArray15 = new double[] { '#', (byte) 100, (short) 100 };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        double[][] doubleArray17 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray16);
        org.apache.commons.math3.linear.NonSquareMatrixException nonSquareMatrixException20 = new org.apache.commons.math3.linear.NonSquareMatrixException((int) (short) 1, (int) (short) 10);
        org.apache.commons.math3.util.Pair<java.lang.Object[], org.apache.commons.math3.exception.MathIllegalNumberException> objArrayPair21 = new org.apache.commons.math3.util.Pair<java.lang.Object[], org.apache.commons.math3.exception.MathIllegalNumberException>((java.lang.Object[]) doubleArray16, (org.apache.commons.math3.exception.MathIllegalNumberException) nonSquareMatrixException20);
        java.lang.Object[] objArray22 = objArrayPair21.getKey();
        java.lang.Object[] objArray23 = objArrayPair21.getFirst();
        java.lang.Object[] objArray24 = objArrayPair21.getKey();
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNotNull(objArray24);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
        org.apache.commons.math3.optim.nonlinear.vector.Target target2 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray0);
        double[] doubleArray3 = target2.getTarget();
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.IdentityPreconditioner identityPreconditioner0 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.IdentityPreconditioner();
        double[] doubleArray1 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight2 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray1);
        org.apache.commons.math3.optim.nonlinear.vector.Target target3 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray1);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray1);
        org.apache.commons.math3.linear.RealMatrix realMatrix6 = diagonalMatrix4.power((int) ' ');
        double[] doubleArray7 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight8 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray7);
        org.apache.commons.math3.optim.nonlinear.vector.Target target9 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray7);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix10 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray7);
        double[] doubleArray11 = diagonalMatrix4.operate(doubleArray7);
        double[] doubleArray12 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight13 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray12);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds14 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray11, doubleArray12);
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight16 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray15);
        double[] doubleArray17 = identityPreconditioner0.precondition(doubleArray12, doubleArray15);
        double[] doubleArray18 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight19 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray18);
        org.apache.commons.math3.optim.nonlinear.vector.Target target20 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix21 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray18);
        org.apache.commons.math3.linear.RealMatrix realMatrix23 = diagonalMatrix21.power((int) ' ');
        double[] doubleArray24 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight25 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray24);
        org.apache.commons.math3.optim.nonlinear.vector.Target target26 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray24);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix27 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray24);
        double[] doubleArray28 = diagonalMatrix21.operate(doubleArray24);
        double[] doubleArray29 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray28);
        double[] doubleArray32 = new double[] { '#', (short) 100 };
        double[] doubleArray33 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight34 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray33);
        org.apache.commons.math3.optim.nonlinear.vector.Target target35 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray33);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix36 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray33);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray32, doubleArray33);
        double[] doubleArray38 = identityPreconditioner0.precondition(doubleArray28, doubleArray33);
        org.apache.commons.math3.linear.RealVector realVector39 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realMatrix23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(realVector39);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equals((float) 64, (float) '#');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        double double0 = org.apache.commons.math3.util.Precision.EPSILON;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.1102230246251565E-16d + "'", double0 == 1.1102230246251565E-16d);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        double[] doubleArray3 = new double[] { '#', (byte) 100, (short) 100 };
        double[] doubleArray7 = new double[] { '#', (byte) 100, (short) 100 };
        double[] doubleArray11 = new double[] { '#', (byte) 100, (short) 100 };
        double[] doubleArray15 = new double[] { '#', (byte) 100, (short) 100 };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        double[][] doubleArray17 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray16);
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex22 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray16, (double) 100L, (double) 2147483647, (-1.0d), 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: equal vertices 1 and 0 in simplex configuration");
        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.apache.commons.math3.util.Incrementor incrementor1 = new org.apache.commons.math3.util.Incrementor(0);
        int int2 = incrementor1.getMaximalCount();
        int int3 = incrementor1.getCount();
        int int4 = incrementor1.getCount();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.IdentityPreconditioner identityPreconditioner0 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.IdentityPreconditioner();
        double[] doubleArray1 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight2 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray1);
        org.apache.commons.math3.optim.nonlinear.vector.Target target3 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray1);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray1);
        org.apache.commons.math3.linear.RealMatrix realMatrix6 = diagonalMatrix4.power((int) ' ');
        double[] doubleArray7 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight8 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray7);
        org.apache.commons.math3.optim.nonlinear.vector.Target target9 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray7);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix10 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray7);
        double[] doubleArray11 = diagonalMatrix4.operate(doubleArray7);
        double[] doubleArray12 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight13 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray12);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds14 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray11, doubleArray12);
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight16 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray15);
        double[] doubleArray17 = identityPreconditioner0.precondition(doubleArray12, doubleArray15);
        double[] doubleArray18 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight19 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray18);
        org.apache.commons.math3.optim.nonlinear.vector.Target target20 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix21 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray18);
        org.apache.commons.math3.linear.RealMatrix realMatrix23 = diagonalMatrix21.power((int) ' ');
        double[] doubleArray24 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight25 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray24);
        org.apache.commons.math3.optim.nonlinear.vector.Target target26 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray24);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix27 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray24);
        double[] doubleArray28 = diagonalMatrix21.operate(doubleArray24);
        double[] doubleArray29 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray28);
        double[] doubleArray32 = new double[] { '#', (short) 100 };
        double[] doubleArray33 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight34 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray33);
        org.apache.commons.math3.optim.nonlinear.vector.Target target35 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray33);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix36 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray33);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray32, doubleArray33);
        double[] doubleArray38 = identityPreconditioner0.precondition(doubleArray28, doubleArray33);
        double[] doubleArray40 = new double[] { (short) 1 };
        double[] doubleArray43 = new double[] { '#', (short) 100 };
        double[] doubleArray44 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight45 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray44);
        org.apache.commons.math3.optim.nonlinear.vector.Target target46 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray44);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix47 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray44);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray43, doubleArray44);
        org.apache.commons.math3.linear.RealVector realVector50 = arrayRealVector48.mapAdd(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector51 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray40, arrayRealVector48);
        org.apache.commons.math3.optim.PointValuePair pointValuePair53 = new org.apache.commons.math3.optim.PointValuePair(doubleArray40, (double) 10);
        double[] doubleArray54 = pointValuePair53.getFirst();
        double[] doubleArray55 = pointValuePair53.getKey();
        try {
            double double56 = org.apache.commons.math3.util.MathArrays.linearCombination(doubleArray33, doubleArray55);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realMatrix23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(realVector50);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray55);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex1 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(10);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        int[] intArray4 = new int[] { 36, 0, 10, (short) -1 };
        int[] intArray5 = org.apache.commons.math3.util.MathArrays.copyOf(intArray4);
        int[] intArray8 = new int[] { 100, 36 };
        int[] intArray15 = new int[] { 1, (short) 10, (short) 1, (byte) 10, (byte) 1, (short) -1 };
        int int16 = org.apache.commons.math3.util.MathArrays.distance1(intArray8, intArray15);
        int[] intArray21 = new int[] { 36, 0, 10, (short) -1 };
        int[] intArray22 = org.apache.commons.math3.util.MathArrays.copyOf(intArray21);
        int int23 = org.apache.commons.math3.util.MathArrays.distance1(intArray8, intArray22);
        int[] intArray28 = new int[] { 36, 0, 10, (short) -1 };
        int[] intArray29 = org.apache.commons.math3.util.MathArrays.copyOf(intArray28);
        int int30 = org.apache.commons.math3.util.MathArrays.distance1(intArray8, intArray29);
        int int31 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray5, intArray29);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 125 + "'", int16 == 125);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 100 + "'", int23 == 100);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 100 + "'", int30 == 100);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        double[] doubleArray1 = new double[] { (short) 1 };
        double[] doubleArray4 = new double[] { '#', (short) 100 };
        double[] doubleArray5 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight6 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray5);
        org.apache.commons.math3.optim.nonlinear.vector.Target target7 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray5);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix8 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4, doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector11 = arrayRealVector9.mapAdd(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1, arrayRealVector9);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex13 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray1);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex18 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray1, (-1.0d), (-1.0d), 0.8414709848078965d, (double) 36);
        double[] doubleArray19 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight20 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray19);
        try {
            nelderMeadSimplex18.build(doubleArray19);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector11);
        org.junit.Assert.assertNotNull(doubleArray19);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex5 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(100, (double) 1.0f, 136.0d, 0.0d, 14889.999999999998d);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
        org.apache.commons.math3.optim.nonlinear.vector.Target target2 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix3 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray0);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = diagonalMatrix3.power((int) ' ');
        double[] doubleArray6 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight7 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray6);
        org.apache.commons.math3.optim.nonlinear.vector.Target target8 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray6);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix9 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6);
        double[] doubleArray10 = diagonalMatrix3.operate(doubleArray6);
        boolean boolean11 = diagonalMatrix3.isSquare();
        double[] doubleArray14 = new double[] { '#', (short) 100 };
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight16 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray15);
        org.apache.commons.math3.optim.nonlinear.vector.Target target17 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray15);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix18 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray15);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14, doubleArray15);
        org.apache.commons.math3.linear.RealVector realVector21 = arrayRealVector19.mapAdd(0.0d);
        org.apache.commons.math3.linear.RealVector realVector23 = arrayRealVector19.mapSubtract(2.2250738585072014E-308d);
        org.apache.commons.math3.linear.RealVector realVector25 = arrayRealVector19.mapAddToSelf(1.0E-15d);
        org.apache.commons.math3.linear.RealVector realVector27 = arrayRealVector19.mapAddToSelf((double) (short) 1);
        try {
            org.apache.commons.math3.linear.RealVector realVector28 = diagonalMatrix3.preMultiply(realVector27);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 2");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realVector21);
        org.junit.Assert.assertNotNull(realVector23);
        org.junit.Assert.assertNotNull(realVector25);
        org.junit.Assert.assertNotNull(realVector27);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer3 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer((double) 100.0f, 0.0d, 0.0d);
        double[] doubleArray4 = null;
        try {
            double[] doubleArray6 = levenbergMarquardtOptimizer3.computeSigma(doubleArray4, (double) 64);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        double[] doubleArray1 = new double[] { (short) 1 };
        double[] doubleArray4 = new double[] { '#', (short) 100 };
        double[] doubleArray5 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight6 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray5);
        org.apache.commons.math3.optim.nonlinear.vector.Target target7 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray5);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix8 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4, doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector11 = arrayRealVector9.mapAdd(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1, arrayRealVector9);
        double double13 = arrayRealVector12.getL1Norm();
        double[] doubleArray17 = new double[] { (short) 1 };
        double[] doubleArray20 = new double[] { '#', (short) 100 };
        double[] doubleArray21 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight22 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray21);
        org.apache.commons.math3.optim.nonlinear.vector.Target target23 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray21);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix24 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray21);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray20, doubleArray21);
        org.apache.commons.math3.linear.RealVector realVector27 = arrayRealVector25.mapAdd(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray17, arrayRealVector25);
        org.apache.commons.math3.linear.RealVector realVector30 = arrayRealVector28.mapAdd((double) (byte) 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = arrayRealVector12.combine((double) 100L, (double) (byte) 1, (org.apache.commons.math3.linear.RealVector) arrayRealVector28);
        arrayRealVector28.set(0.0d);
        try {
            arrayRealVector28.addToEntry((-1748719057), (double) 36);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (-1,748,719,057)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 136.0d + "'", double13 == 136.0d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(realVector27);
        org.junit.Assert.assertNotNull(realVector30);
        org.junit.Assert.assertNotNull(arrayRealVector31);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.MatrixUtils.OCTAVE_FORMAT;
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix2 = realMatrixFormat0.parse("hi!1,35,100{");
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathParseException; message: illegal state: string \"hi!1,35,100{\" unparseable (from position 0) as an object of type org.apache.commons.math3.linear.Array2DRowRealMatrix");
        } catch (org.apache.commons.math3.exception.MathParseException e) {
        }
        org.junit.Assert.assertNotNull(realMatrixFormat0);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        long long2 = org.apache.commons.math3.util.MathUtils.copySign(0L, (long) (byte) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
        org.apache.commons.math3.optim.nonlinear.vector.Target target2 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix3 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray0);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = diagonalMatrix3.power((int) ' ');
        double[] doubleArray6 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight7 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray6);
        org.apache.commons.math3.optim.nonlinear.vector.Target target8 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray6);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix9 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6);
        double[] doubleArray10 = diagonalMatrix3.operate(doubleArray6);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight12 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray11);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds13 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray10, doubleArray11);
        double[] doubleArray14 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight15 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray14);
        org.apache.commons.math3.optim.nonlinear.vector.Target target16 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray14);
        double[] doubleArray17 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray11, doubleArray14);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix19 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray11, true);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor20 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double21 = defaultRealMatrixPreservingVisitor20.end();
        double double22 = diagonalMatrix19.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor20);
        double[] doubleArray23 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight24 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray23);
        org.apache.commons.math3.optim.nonlinear.vector.Target target25 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray23);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray23);
        org.apache.commons.math3.linear.RealMatrix realMatrix28 = diagonalMatrix26.power((int) ' ');
        boolean boolean29 = diagonalMatrix26.isTransposable();
        org.apache.commons.math3.linear.RealMatrix realMatrix30 = diagonalMatrix26.copy();
        diagonalMatrix26.setEntry((int) (short) 100, 97, (double) 0.0f);
        org.apache.commons.math3.linear.RealMatrix realMatrix35 = diagonalMatrix26.copy();
        double[] doubleArray36 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight37 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray36);
        org.apache.commons.math3.optim.nonlinear.vector.Target target38 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray36);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix39 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray36);
        org.apache.commons.math3.linear.RealMatrix realMatrix41 = diagonalMatrix39.power((int) ' ');
        double[] doubleArray42 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight43 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray42);
        org.apache.commons.math3.optim.nonlinear.vector.Target target44 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray42);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix45 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray42);
        double[] doubleArray46 = diagonalMatrix39.operate(doubleArray42);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix47 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray42);
        org.apache.commons.math3.linear.RealMatrix realMatrix48 = diagonalMatrix26.multiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix47);
        org.apache.commons.math3.linear.RealMatrix realMatrix49 = diagonalMatrix19.multiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix47);
        double[] doubleArray51 = new double[] { (short) 1 };
        double[] doubleArray54 = new double[] { '#', (short) 100 };
        double[] doubleArray55 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight56 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray55);
        org.apache.commons.math3.optim.nonlinear.vector.Target target57 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray55);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix58 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray55);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector59 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray54, doubleArray55);
        org.apache.commons.math3.linear.RealVector realVector61 = arrayRealVector59.mapAdd(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector62 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray51, arrayRealVector59);
        try {
            org.apache.commons.math3.linear.MatrixUtils.solveUpperTriangularSystem((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix19, (org.apache.commons.math3.linear.RealVector) arrayRealVector59);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 2");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertNotNull(realMatrix35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(realMatrix41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(realMatrix48);
        org.junit.Assert.assertNotNull(realMatrix49);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(realVector61);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        double double0 = org.apache.commons.math3.util.MathUtils.TWO_PI;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 6.283185307179586d + "'", double0 == 6.283185307179586d);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        double double1 = org.apache.commons.math3.util.FastMath.cos(0.7853981633974483d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7071067811865476d + "'", double1 == 0.7071067811865476d);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula0 = org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES;
        org.apache.commons.math3.random.MersenneTwister mersenneTwister7 = new org.apache.commons.math3.random.MersenneTwister((int) '#');
        double double8 = mersenneTwister7.nextDouble();
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker12 = new org.apache.commons.math3.optim.SimpleValueChecker((double) (byte) 1, (double) (short) 100);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer13 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer((int) '#', (double) (short) 1, true, 36, 10, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister7, true, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker12);
        double double14 = simpleValueChecker12.getAbsoluteThreshold();
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver15 = new org.apache.commons.math3.analysis.solvers.BrentSolver();
        double double16 = brentSolver15.getRelativeAccuracy();
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer17 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker12, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver15);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula18 = org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES;
        org.apache.commons.math3.random.MersenneTwister mersenneTwister25 = new org.apache.commons.math3.random.MersenneTwister((int) '#');
        double double26 = mersenneTwister25.nextDouble();
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker30 = new org.apache.commons.math3.optim.SimpleValueChecker((double) (byte) 1, (double) (short) 100);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer31 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer((int) '#', (double) (short) 1, true, 36, 10, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister25, true, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker30);
        double double32 = simpleValueChecker30.getAbsoluteThreshold();
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver33 = new org.apache.commons.math3.analysis.solvers.BrentSolver();
        double double34 = brentSolver33.getRelativeAccuracy();
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer35 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula18, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker30, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver33);
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver39 = new org.apache.commons.math3.analysis.solvers.BrentSolver(1.0E-14d, (double) (byte) 0, 0.7853981633974483d);
        org.apache.commons.math3.analysis.function.Sinc sinc41 = new org.apache.commons.math3.analysis.function.Sinc();
        double double44 = brentSolver39.solve((int) (short) 100, (org.apache.commons.math3.analysis.UnivariateFunction) sinc41, 0.0d, 3.7663540285E10d);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer45 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker30, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver39);
        int int46 = brentSolver39.getEvaluations();
        double double47 = brentSolver39.getMin();
        org.junit.Assert.assertTrue("'" + formula0 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES + "'", formula0.equals(org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.45805495157532494d + "'", double8 == 0.45805495157532494d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 100.0d + "'", double14 == 100.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0E-14d + "'", double16 == 1.0E-14d);
        org.junit.Assert.assertTrue("'" + formula18 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES + "'", formula18.equals(org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES));
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.45805495157532494d + "'", double26 == 0.45805495157532494d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 100.0d + "'", double32 == 100.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 1.0E-14d + "'", double34 == 1.0E-14d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 1.88317701425E10d + "'", double44 == 1.88317701425E10d);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        double[] doubleArray1 = new double[] { (short) 1 };
        double[] doubleArray4 = new double[] { '#', (short) 100 };
        double[] doubleArray5 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight6 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray5);
        org.apache.commons.math3.optim.nonlinear.vector.Target target7 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray5);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix8 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4, doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector11 = arrayRealVector9.mapAdd(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1, arrayRealVector9);
        double double13 = arrayRealVector12.getL1Norm();
        double[] doubleArray17 = new double[] { (short) 1 };
        double[] doubleArray20 = new double[] { '#', (short) 100 };
        double[] doubleArray21 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight22 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray21);
        org.apache.commons.math3.optim.nonlinear.vector.Target target23 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray21);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix24 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray21);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray20, doubleArray21);
        org.apache.commons.math3.linear.RealVector realVector27 = arrayRealVector25.mapAdd(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray17, arrayRealVector25);
        org.apache.commons.math3.linear.RealVector realVector30 = arrayRealVector28.mapAdd((double) (byte) 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = arrayRealVector12.combine((double) 100L, (double) (byte) 1, (org.apache.commons.math3.linear.RealVector) arrayRealVector28);
        double[] doubleArray32 = arrayRealVector12.getDataRef();
        try {
            arrayRealVector12.setEntry((-1), (double) ' ');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 136.0d + "'", double13 == 136.0d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(realVector27);
        org.junit.Assert.assertNotNull(realVector30);
        org.junit.Assert.assertNotNull(arrayRealVector31);
        org.junit.Assert.assertNotNull(doubleArray32);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        double double1 = org.apache.commons.math3.util.FastMath.toDegrees((double) 100L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5729.5779513082325d + "'", double1 == 5729.5779513082325d);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat3 = new org.apache.commons.math3.linear.RealVectorFormat("hi!", "{", ",");
        double[] doubleArray5 = new double[] { (short) 1 };
        double[] doubleArray8 = new double[] { '#', (short) 100 };
        double[] doubleArray9 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight10 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray9);
        org.apache.commons.math3.optim.nonlinear.vector.Target target11 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray9);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix12 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray9);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray8, doubleArray9);
        org.apache.commons.math3.linear.RealVector realVector15 = arrayRealVector13.mapAdd(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5, arrayRealVector13);
        org.apache.commons.math3.linear.RealVector realVector18 = arrayRealVector16.mapAdd((double) (byte) 0);
        java.lang.String str19 = realVectorFormat3.format(realVector18);
        org.apache.commons.math3.linear.RealVector realVector21 = realVector18.mapDivide(9.999999999999998d);
        double double22 = realVector18.getMinValue();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi!1,35,100{" + "'", str19.equals("hi!1,35,100{"));
        org.junit.Assert.assertNotNull(realVector21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0d + "'", double22 == 1.0d);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math3.random.MersenneTwister((int) '#');
        double double7 = mersenneTwister6.nextDouble();
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker11 = new org.apache.commons.math3.optim.SimpleValueChecker((double) (byte) 1, (double) (short) 100);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer12 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer((int) '#', (double) (short) 1, true, 36, 10, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister6, true, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker11);
        double double13 = simpleValueChecker11.getAbsoluteThreshold();
        double[] doubleArray15 = null;
        org.apache.commons.math3.optim.PointValuePair pointValuePair17 = new org.apache.commons.math3.optim.PointValuePair(doubleArray15, 0.0d);
        double[] doubleArray18 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight19 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray18);
        org.apache.commons.math3.optim.nonlinear.vector.Target target20 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix21 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray18);
        org.apache.commons.math3.optim.PointValuePair pointValuePair24 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) 10, false);
        boolean boolean25 = simpleValueChecker11.converged((int) '4', pointValuePair17, pointValuePair24);
        java.lang.Double double26 = pointValuePair17.getSecond();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.45805495157532494d + "'", double7 == 0.45805495157532494d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 100.0d + "'", double13 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26.equals(0.0d));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException0 = new org.apache.commons.math3.exception.MathIllegalStateException();
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException(125, (int) (short) 100, 97, (-1));
        int int5 = matrixDimensionMismatchException4.getWrongColumnDimension();
        java.lang.Integer[] intArray6 = matrixDimensionMismatchException4.getExpectedDimensions();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 100 + "'", int5 == 100);
        org.junit.Assert.assertNotNull(intArray6);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        java.text.ParsePosition parsePosition1 = null;
        try {
            char char2 = org.apache.commons.math3.util.CompositeFormat.parseNextCharacter("]", parsePosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.apache.commons.math3.optim.SimpleVectorValueChecker simpleVectorValueChecker4 = new org.apache.commons.math3.optim.SimpleVectorValueChecker((double) (-1), 11013.232920103323d, 52);
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer9 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer(0.017453292519943295d, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair>) simpleVectorValueChecker4, (double) 1076101151, (double) 1.0f, 1.0E-15d, (double) 52);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer5 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer(136.0d, (double) (-1), (double) (short) 1, 0.0d, 3600.0d);
        double double6 = levenbergMarquardtOptimizer5.getChiSquare();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula0 = null;
        org.apache.commons.math3.random.MersenneTwister mersenneTwister7 = new org.apache.commons.math3.random.MersenneTwister((int) '#');
        double double8 = mersenneTwister7.nextDouble();
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker12 = new org.apache.commons.math3.optim.SimpleValueChecker((double) (byte) 1, (double) (short) 100);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer13 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer((int) '#', (double) (short) 1, true, 36, 10, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister7, true, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker12);
        double double14 = simpleValueChecker12.getAbsoluteThreshold();
        double double15 = simpleValueChecker12.getRelativeThreshold();
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer16 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker12);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.45805495157532494d + "'", double8 == 0.45805495157532494d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 100.0d + "'", double14 == 100.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer powellOptimizer4 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer(Double.NaN, (double) (byte) 0, (double) 0, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer powellOptimizer2 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer((double) 97.0f, 125.0d);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(125, (int) (byte) 100);
        double double3 = blockRealMatrix2.getNorm();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor4 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double5 = defaultRealMatrixPreservingVisitor4.end();
        double double6 = blockRealMatrix2.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor4);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(125, (int) (byte) 100);
        double double10 = blockRealMatrix9.getNorm();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor11 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double12 = defaultRealMatrixPreservingVisitor11.end();
        double double13 = blockRealMatrix9.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor11);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor14 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        defaultRealMatrixPreservingVisitor14.start((int) 'a', (int) (byte) 1, 97, 0, (-1), 125);
        double double22 = blockRealMatrix9.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor14);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix25 = new org.apache.commons.math3.linear.BlockRealMatrix(125, (int) (byte) 100);
        double double26 = blockRealMatrix25.getNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = blockRealMatrix9.add(blockRealMatrix25);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix29 = blockRealMatrix27.scalarAdd(0.45805495157532494d);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix30 = blockRealMatrix2.subtract(blockRealMatrix29);
        org.apache.commons.math3.linear.RealMatrix realMatrix32 = blockRealMatrix29.scalarMultiply((double) (byte) 10);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor33 = null;
        try {
            double double34 = blockRealMatrix29.walkInRowOrder(realMatrixChangingVisitor33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix27);
        org.junit.Assert.assertNotNull(blockRealMatrix29);
        org.junit.Assert.assertNotNull(blockRealMatrix30);
        org.junit.Assert.assertNotNull(realMatrix32);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat3 = new org.apache.commons.math3.linear.RealVectorFormat("hi!", "{", ",");
        double[] doubleArray5 = new double[] { (short) 1 };
        double[] doubleArray8 = new double[] { '#', (short) 100 };
        double[] doubleArray9 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight10 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray9);
        org.apache.commons.math3.optim.nonlinear.vector.Target target11 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray9);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix12 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray9);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray8, doubleArray9);
        org.apache.commons.math3.linear.RealVector realVector15 = arrayRealVector13.mapAdd(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5, arrayRealVector13);
        org.apache.commons.math3.linear.RealVector realVector18 = arrayRealVector16.mapAdd((double) (byte) 0);
        java.lang.String str19 = realVectorFormat3.format(realVector18);
        double[] doubleArray21 = new double[] { (short) 1 };
        double[] doubleArray24 = new double[] { '#', (short) 100 };
        double[] doubleArray25 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight26 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray25);
        org.apache.commons.math3.optim.nonlinear.vector.Target target27 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray25);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix28 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray25);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray24, doubleArray25);
        org.apache.commons.math3.linear.RealVector realVector31 = arrayRealVector29.mapAdd(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray21, arrayRealVector29);
        double double33 = arrayRealVector32.getL1Norm();
        double[] doubleArray37 = new double[] { (short) 1 };
        double[] doubleArray40 = new double[] { '#', (short) 100 };
        double[] doubleArray41 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight42 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray41);
        org.apache.commons.math3.optim.nonlinear.vector.Target target43 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray41);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix44 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray41);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray40, doubleArray41);
        org.apache.commons.math3.linear.RealVector realVector47 = arrayRealVector45.mapAdd(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray37, arrayRealVector45);
        org.apache.commons.math3.linear.RealVector realVector50 = arrayRealVector48.mapAdd((double) (byte) 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector51 = arrayRealVector32.combine((double) 100L, (double) (byte) 1, (org.apache.commons.math3.linear.RealVector) arrayRealVector48);
        org.apache.commons.math3.linear.RealVector realVector53 = arrayRealVector48.mapDivide((double) 'a');
        java.lang.StringBuffer stringBuffer54 = null;
        java.text.FieldPosition fieldPosition55 = null;
        try {
            java.lang.StringBuffer stringBuffer56 = realVectorFormat3.format((org.apache.commons.math3.linear.RealVector) arrayRealVector48, stringBuffer54, fieldPosition55);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi!1,35,100{" + "'", str19.equals("hi!1,35,100{"));
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realVector31);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 136.0d + "'", double33 == 136.0d);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(realVector47);
        org.junit.Assert.assertNotNull(realVector50);
        org.junit.Assert.assertNotNull(arrayRealVector51);
        org.junit.Assert.assertNotNull(realVector53);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        long[] longArray6 = new long[] { (short) 10, (byte) 0, 'a', ' ', 2147483647, (short) 0 };
        org.apache.commons.math3.util.MathArrays.checkNonNegative(longArray6);
        org.apache.commons.math3.util.MathArrays.checkNonNegative(longArray6);
        org.junit.Assert.assertNotNull(longArray6);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math3.random.MersenneTwister((int) '#');
        double double2 = mersenneTwister1.nextDouble();
        long long3 = mersenneTwister1.nextLong();
        int[] intArray5 = new int[] { 125 };
        mersenneTwister1.setSeed(intArray5);
        int[] intArray9 = new int[] { 100, 36 };
        int[] intArray16 = new int[] { 1, (short) 10, (short) 1, (byte) 10, (byte) 1, (short) -1 };
        int int17 = org.apache.commons.math3.util.MathArrays.distance1(intArray9, intArray16);
        int int18 = org.apache.commons.math3.util.MathArrays.distance1(intArray5, intArray9);
        int[] intArray23 = new int[] { 36, 0, 10, (short) -1 };
        int[] intArray24 = org.apache.commons.math3.util.MathArrays.copyOf(intArray23);
        int int25 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray9, intArray23);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.45805495157532494d + "'", double2 == 0.45805495157532494d);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 5688046246375236535L + "'", long3 == 5688046246375236535L);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 125 + "'", int17 == 125);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 25 + "'", int18 == 25);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 64 + "'", int25 == 64);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
        org.apache.commons.math3.optim.nonlinear.vector.Target target2 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix3 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray0);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = diagonalMatrix3.power((int) ' ');
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = diagonalMatrix3.power((int) ' ');
        double[] doubleArray8 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight9 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray8);
        org.apache.commons.math3.optim.nonlinear.vector.Target target10 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray8);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix11 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray8);
        org.apache.commons.math3.linear.RealMatrix realMatrix13 = diagonalMatrix11.power((int) ' ');
        double[] doubleArray14 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight15 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray14);
        org.apache.commons.math3.optim.nonlinear.vector.Target target16 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray14);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix17 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray14);
        double[] doubleArray18 = diagonalMatrix11.operate(doubleArray14);
        double[] doubleArray19 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight20 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray19);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds21 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray18, doubleArray19);
        double[] doubleArray22 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight23 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray22);
        org.apache.commons.math3.optim.nonlinear.vector.Target target24 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray22);
        double[] doubleArray25 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray19, doubleArray22);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix27 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray19, true);
        org.apache.commons.math3.linear.RealMatrix realMatrix28 = diagonalMatrix3.preMultiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix27);
        org.apache.commons.math3.linear.RealMatrix realMatrix30 = diagonalMatrix27.power((int) (byte) 100);
        double double31 = diagonalMatrix27.getFrobeniusNorm();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix33 = diagonalMatrix27.scalarAdd((double) 97.0f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.apache.commons.math3.linear.AnyMatrix anyMatrix0 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkRowIndex(anyMatrix0, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        double double1 = org.apache.commons.math3.util.FastMath.sinh((double) 1.07269331E9f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
        org.apache.commons.math3.optim.nonlinear.vector.Target target2 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix3 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray0);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = diagonalMatrix3.power((int) ' ');
        boolean boolean6 = diagonalMatrix3.isTransposable();
        diagonalMatrix3.setEntry(100, (int) ' ', (double) 0L);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight12 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray11);
        org.apache.commons.math3.optim.nonlinear.vector.Target target13 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray11);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix14 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray11);
        org.apache.commons.math3.linear.RealMatrix realMatrix16 = diagonalMatrix14.power((int) ' ');
        org.apache.commons.math3.linear.RealMatrix realMatrix18 = diagonalMatrix14.power((int) ' ');
        double[] doubleArray19 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight20 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray19);
        org.apache.commons.math3.optim.nonlinear.vector.Target target21 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray19);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix22 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray19);
        org.apache.commons.math3.linear.RealMatrix realMatrix24 = diagonalMatrix22.power((int) ' ');
        double[] doubleArray25 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight26 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray25);
        org.apache.commons.math3.optim.nonlinear.vector.Target target27 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray25);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix28 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray25);
        double[] doubleArray29 = diagonalMatrix22.operate(doubleArray25);
        double[] doubleArray30 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight31 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray30);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds32 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray29, doubleArray30);
        double[] doubleArray33 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight34 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray33);
        org.apache.commons.math3.optim.nonlinear.vector.Target target35 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray33);
        double[] doubleArray36 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray30, doubleArray33);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix38 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray30, true);
        org.apache.commons.math3.linear.RealMatrix realMatrix39 = diagonalMatrix14.preMultiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix38);
        org.apache.commons.math3.linear.RealMatrix realMatrix40 = diagonalMatrix3.multiply(realMatrix39);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSubMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) diagonalMatrix3, 36, 0, 25, 25);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (36)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertNotNull(realMatrix18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(realMatrix24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(realMatrix39);
        org.junit.Assert.assertNotNull(realMatrix40);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.apache.commons.math3.linear.RealMatrix realMatrix0 = null;
        try {
            org.apache.commons.math3.linear.LUDecomposition lUDecomposition1 = new org.apache.commons.math3.linear.LUDecomposition(realMatrix0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.apache.commons.math3.linear.NonSquareMatrixException nonSquareMatrixException2 = new org.apache.commons.math3.linear.NonSquareMatrixException((int) (short) 1, (int) (short) 10);
        int int3 = nonSquareMatrixException2.getDimension();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        double[] doubleArray2 = new double[] { '#', (short) 100 };
        double[] doubleArray3 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight4 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray3);
        org.apache.commons.math3.optim.nonlinear.vector.Target target5 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray3);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix6 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray2, doubleArray3);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.mapAdd(0.0d);
        double[] doubleArray10 = arrayRealVector7.toArray();
        boolean boolean11 = arrayRealVector7.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector7, true);
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor14 = null;
        try {
            double double17 = arrayRealVector7.walkInDefaultOrder(realVectorChangingVisitor14, 0, 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
        org.apache.commons.math3.optim.nonlinear.vector.Target target2 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix3 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray0);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor4 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double5 = diagonalMatrix3.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor4);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
        org.apache.commons.math3.optim.nonlinear.vector.Target target2 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix3 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray0);
        org.apache.commons.math3.optim.PointValuePair pointValuePair6 = new org.apache.commons.math3.optim.PointValuePair(doubleArray0, (double) 10, false);
        double[] doubleArray7 = pointValuePair6.getPoint();
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray7);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equals((float) 10L, 0.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.IdentityPreconditioner identityPreconditioner0 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.IdentityPreconditioner();
        double[] doubleArray1 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight2 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray1);
        org.apache.commons.math3.optim.nonlinear.vector.Target target3 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray1);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray1);
        org.apache.commons.math3.linear.RealMatrix realMatrix6 = diagonalMatrix4.power((int) ' ');
        double[] doubleArray7 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight8 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray7);
        org.apache.commons.math3.optim.nonlinear.vector.Target target9 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray7);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix10 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray7);
        double[] doubleArray11 = diagonalMatrix4.operate(doubleArray7);
        double[] doubleArray12 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight13 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray12);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds14 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray11, doubleArray12);
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight16 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray15);
        double[] doubleArray17 = identityPreconditioner0.precondition(doubleArray12, doubleArray15);
        double[] doubleArray18 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight19 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray18);
        org.apache.commons.math3.optim.nonlinear.vector.Target target20 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix21 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray18);
        org.apache.commons.math3.linear.RealMatrix realMatrix23 = diagonalMatrix21.power((int) ' ');
        org.apache.commons.math3.linear.RealMatrix realMatrix25 = diagonalMatrix21.power((int) ' ');
        double[] doubleArray26 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight27 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray26);
        org.apache.commons.math3.optim.nonlinear.vector.Target target28 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray26);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix29 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray26);
        org.apache.commons.math3.linear.RealMatrix realMatrix31 = diagonalMatrix29.power((int) ' ');
        double[] doubleArray32 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight33 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray32);
        org.apache.commons.math3.optim.nonlinear.vector.Target target34 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray32);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix35 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray32);
        double[] doubleArray36 = diagonalMatrix29.operate(doubleArray32);
        double[] doubleArray37 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight38 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray37);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds39 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray36, doubleArray37);
        double[] doubleArray40 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight41 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray40);
        org.apache.commons.math3.optim.nonlinear.vector.Target target42 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray40);
        double[] doubleArray43 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray37, doubleArray40);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix45 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray37, true);
        org.apache.commons.math3.linear.RealMatrix realMatrix46 = diagonalMatrix21.preMultiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix45);
        java.lang.String str47 = diagonalMatrix45.toString();
        double[] doubleArray48 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight49 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray48);
        org.apache.commons.math3.optim.nonlinear.vector.Target target50 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray48);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix51 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray48);
        org.apache.commons.math3.linear.RealMatrix realMatrix53 = diagonalMatrix51.power((int) ' ');
        double[] doubleArray54 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight55 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray54);
        org.apache.commons.math3.optim.nonlinear.vector.Target target56 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray54);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix57 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray54);
        double[] doubleArray58 = diagonalMatrix51.operate(doubleArray54);
        double[] doubleArray59 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight60 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray59);
        org.apache.commons.math3.optim.nonlinear.vector.Target target61 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray59);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix62 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray59);
        double[] doubleArray63 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray58, doubleArray59);
        double[] doubleArray64 = diagonalMatrix45.operate(doubleArray59);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.IdentityPreconditioner identityPreconditioner65 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.IdentityPreconditioner();
        double[] doubleArray66 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight67 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray66);
        org.apache.commons.math3.optim.nonlinear.vector.Target target68 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray66);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix69 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray66);
        org.apache.commons.math3.linear.RealMatrix realMatrix71 = diagonalMatrix69.power((int) ' ');
        double[] doubleArray72 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight73 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray72);
        org.apache.commons.math3.optim.nonlinear.vector.Target target74 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray72);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix75 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray72);
        double[] doubleArray76 = diagonalMatrix69.operate(doubleArray72);
        double[] doubleArray77 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight78 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray77);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds79 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray76, doubleArray77);
        double[] doubleArray80 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight81 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray80);
        double[] doubleArray82 = identityPreconditioner65.precondition(doubleArray77, doubleArray80);
        double[] doubleArray85 = new double[] { '#', (short) 100 };
        double[] doubleArray86 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight87 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray86);
        org.apache.commons.math3.optim.nonlinear.vector.Target target88 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray86);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix89 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray86);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector90 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray85, doubleArray86);
        double double91 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray80, doubleArray86);
        double[] doubleArray92 = identityPreconditioner0.precondition(doubleArray59, doubleArray80);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector95 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray59, 1072693279, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: 1,072,693,289 is larger than the maximum (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realMatrix23);
        org.junit.Assert.assertNotNull(realMatrix25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(realMatrix31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(realMatrix46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "DiagonalMatrix{}" + "'", str47.equals("DiagonalMatrix{}"));
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(realMatrix53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(realMatrix71);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 0.0d + "'", double91 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray92);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        double[] doubleArray2 = new double[] { '#', (short) 100 };
        double[] doubleArray3 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight4 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray3);
        org.apache.commons.math3.optim.nonlinear.vector.Target target5 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray3);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix6 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray2, doubleArray3);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.mapAdd(0.0d);
        org.apache.commons.math3.linear.RealVector realVector11 = arrayRealVector7.mapSubtract(2.2250738585072014E-308d);
        org.apache.commons.math3.linear.RealVector realVector13 = arrayRealVector7.mapAddToSelf(1.0E-15d);
        org.apache.commons.math3.linear.RealVector realVector15 = arrayRealVector7.mapAddToSelf((double) (short) 1);
        org.apache.commons.math3.linear.RealVector realVector17 = arrayRealVector7.mapDivideToSelf((double) 1.0f);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.IdentityPreconditioner identityPreconditioner18 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.IdentityPreconditioner();
        double[] doubleArray19 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight20 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray19);
        org.apache.commons.math3.optim.nonlinear.vector.Target target21 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray19);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix22 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray19);
        org.apache.commons.math3.linear.RealMatrix realMatrix24 = diagonalMatrix22.power((int) ' ');
        double[] doubleArray25 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight26 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray25);
        org.apache.commons.math3.optim.nonlinear.vector.Target target27 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray25);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix28 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray25);
        double[] doubleArray29 = diagonalMatrix22.operate(doubleArray25);
        double[] doubleArray30 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight31 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray30);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds32 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray29, doubleArray30);
        double[] doubleArray33 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight34 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray33);
        double[] doubleArray35 = identityPreconditioner18.precondition(doubleArray30, doubleArray33);
        double[] doubleArray36 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight37 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray36);
        org.apache.commons.math3.optim.nonlinear.vector.Target target38 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray36);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix39 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray36);
        org.apache.commons.math3.linear.RealMatrix realMatrix41 = diagonalMatrix39.power((int) ' ');
        double[] doubleArray42 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight43 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray42);
        org.apache.commons.math3.optim.nonlinear.vector.Target target44 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray42);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix45 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray42);
        double[] doubleArray46 = diagonalMatrix39.operate(doubleArray42);
        double[] doubleArray47 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray46);
        double[] doubleArray50 = new double[] { '#', (short) 100 };
        double[] doubleArray51 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight52 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray51);
        org.apache.commons.math3.optim.nonlinear.vector.Target target53 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray51);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix54 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray51);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector55 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray50, doubleArray51);
        double[] doubleArray56 = identityPreconditioner18.precondition(doubleArray46, doubleArray51);
        double[] doubleArray58 = new double[] { (short) 1 };
        double[] doubleArray61 = new double[] { '#', (short) 100 };
        double[] doubleArray62 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight63 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray62);
        org.apache.commons.math3.optim.nonlinear.vector.Target target64 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray62);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix65 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray62);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector66 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray61, doubleArray62);
        org.apache.commons.math3.linear.RealVector realVector68 = arrayRealVector66.mapAdd(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector69 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray58, arrayRealVector66);
        double double70 = arrayRealVector69.getL1Norm();
        double[] doubleArray74 = new double[] { (short) 1 };
        double[] doubleArray77 = new double[] { '#', (short) 100 };
        double[] doubleArray78 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight79 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray78);
        org.apache.commons.math3.optim.nonlinear.vector.Target target80 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray78);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix81 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray78);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector82 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray77, doubleArray78);
        org.apache.commons.math3.linear.RealVector realVector84 = arrayRealVector82.mapAdd(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector85 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray74, arrayRealVector82);
        org.apache.commons.math3.linear.RealVector realVector87 = arrayRealVector85.mapAdd((double) (byte) 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector88 = arrayRealVector69.combine((double) 100L, (double) (byte) 1, (org.apache.commons.math3.linear.RealVector) arrayRealVector85);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector89 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray51, arrayRealVector88);
        org.apache.commons.math3.analysis.function.Sinc sinc90 = new org.apache.commons.math3.analysis.function.Sinc();
        double double92 = sinc90.value(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector93 = arrayRealVector88.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc90);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector94 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector7, (org.apache.commons.math3.linear.RealVector) arrayRealVector93);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(realVector11);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(realMatrix24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(realMatrix41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(realVector68);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 136.0d + "'", double70 == 136.0d);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(realVector84);
        org.junit.Assert.assertNotNull(realVector87);
        org.junit.Assert.assertNotNull(arrayRealVector88);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 1.0d + "'", double92 == 1.0d);
        org.junit.Assert.assertNotNull(arrayRealVector93);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(125, (int) (byte) 100);
        double double3 = blockRealMatrix2.getNorm();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor4 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double5 = defaultRealMatrixPreservingVisitor4.end();
        double double6 = blockRealMatrix2.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor4);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor7 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        defaultRealMatrixPreservingVisitor7.start((int) 'a', (int) (byte) 1, 97, 0, (-1), 125);
        double double15 = blockRealMatrix2.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor7);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = new org.apache.commons.math3.linear.BlockRealMatrix(125, (int) (byte) 100);
        double double19 = blockRealMatrix18.getNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix20 = blockRealMatrix2.add(blockRealMatrix18);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix22 = blockRealMatrix20.scalarAdd(0.45805495157532494d);
        double[] doubleArray23 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight24 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray23);
        org.apache.commons.math3.optim.nonlinear.vector.Target target25 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray23);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray23);
        org.apache.commons.math3.linear.RealMatrix realMatrix28 = diagonalMatrix26.power((int) ' ');
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix29 = blockRealMatrix22.add(realMatrix28);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 125x100 but expected 0x0");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix20);
        org.junit.Assert.assertNotNull(blockRealMatrix22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(realMatrix28);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
        org.apache.commons.math3.optim.nonlinear.vector.Target target2 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix3 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray0);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = diagonalMatrix3.power((int) ' ');
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = diagonalMatrix3.power((int) ' ');
        double[] doubleArray8 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight9 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray8);
        org.apache.commons.math3.optim.nonlinear.vector.Target target10 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray8);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix11 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray8);
        org.apache.commons.math3.linear.RealMatrix realMatrix13 = diagonalMatrix11.power((int) ' ');
        double[] doubleArray14 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight15 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray14);
        org.apache.commons.math3.optim.nonlinear.vector.Target target16 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray14);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix17 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray14);
        double[] doubleArray18 = diagonalMatrix11.operate(doubleArray14);
        double[] doubleArray19 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight20 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray19);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds21 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray18, doubleArray19);
        double[] doubleArray22 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight23 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray22);
        org.apache.commons.math3.optim.nonlinear.vector.Target target24 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray22);
        double[] doubleArray25 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray19, doubleArray22);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix27 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray19, true);
        org.apache.commons.math3.linear.RealMatrix realMatrix28 = diagonalMatrix3.preMultiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix27);
        java.lang.String str29 = diagonalMatrix27.toString();
        double[] doubleArray30 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight31 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray30);
        org.apache.commons.math3.optim.nonlinear.vector.Target target32 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray30);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix33 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray30);
        org.apache.commons.math3.linear.RealMatrix realMatrix35 = diagonalMatrix33.power((int) ' ');
        double[] doubleArray36 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight37 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray36);
        org.apache.commons.math3.optim.nonlinear.vector.Target target38 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray36);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix39 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray36);
        double[] doubleArray40 = diagonalMatrix33.operate(doubleArray36);
        double[] doubleArray41 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight42 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray41);
        org.apache.commons.math3.optim.nonlinear.vector.Target target43 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray41);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix44 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray41);
        double[] doubleArray45 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray40, doubleArray41);
        double[] doubleArray46 = diagonalMatrix27.operate(doubleArray41);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix48 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray41, false);
        boolean boolean49 = diagonalMatrix48.isSquare();
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "DiagonalMatrix{}" + "'", str29.equals("DiagonalMatrix{}"));
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(realMatrix35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
        org.apache.commons.math3.optim.nonlinear.vector.Target target2 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix3 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray0);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = diagonalMatrix3.power((int) ' ');
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = diagonalMatrix3.power((int) ' ');
        double[] doubleArray8 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight9 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray8);
        org.apache.commons.math3.optim.nonlinear.vector.Target target10 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray8);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix11 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray8);
        org.apache.commons.math3.linear.RealMatrix realMatrix13 = diagonalMatrix11.power((int) ' ');
        double[] doubleArray14 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight15 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray14);
        org.apache.commons.math3.optim.nonlinear.vector.Target target16 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray14);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix17 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray14);
        double[] doubleArray18 = diagonalMatrix11.operate(doubleArray14);
        double[] doubleArray19 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight20 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray19);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds21 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray18, doubleArray19);
        double[] doubleArray22 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight23 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray22);
        org.apache.commons.math3.optim.nonlinear.vector.Target target24 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray22);
        double[] doubleArray25 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray19, doubleArray22);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix27 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray19, true);
        org.apache.commons.math3.linear.RealMatrix realMatrix28 = diagonalMatrix3.preMultiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix27);
        double[] doubleArray29 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight30 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray29);
        org.apache.commons.math3.optim.nonlinear.vector.Target target31 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray29);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix32 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray29);
        org.apache.commons.math3.linear.RealMatrix realMatrix34 = diagonalMatrix32.power((int) ' ');
        double[] doubleArray35 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight36 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray35);
        org.apache.commons.math3.optim.nonlinear.vector.Target target37 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray35);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix38 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray35);
        double[] doubleArray39 = diagonalMatrix32.operate(doubleArray35);
        double[] doubleArray40 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight41 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray40);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds42 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray39, doubleArray40);
        double[] doubleArray43 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight44 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray43);
        org.apache.commons.math3.optim.nonlinear.vector.Target target45 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray43);
        double[] doubleArray46 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray40, doubleArray43);
        double[] doubleArray47 = diagonalMatrix27.preMultiply(doubleArray46);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.IdentityPreconditioner identityPreconditioner48 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.IdentityPreconditioner();
        double[] doubleArray49 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight50 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray49);
        org.apache.commons.math3.optim.nonlinear.vector.Target target51 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray49);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix52 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray49);
        org.apache.commons.math3.linear.RealMatrix realMatrix54 = diagonalMatrix52.power((int) ' ');
        double[] doubleArray55 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight56 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray55);
        org.apache.commons.math3.optim.nonlinear.vector.Target target57 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray55);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix58 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray55);
        double[] doubleArray59 = diagonalMatrix52.operate(doubleArray55);
        double[] doubleArray60 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight61 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray60);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds62 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray59, doubleArray60);
        double[] doubleArray63 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight64 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray63);
        double[] doubleArray65 = identityPreconditioner48.precondition(doubleArray60, doubleArray63);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair66 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray47, doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(realMatrix34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(realMatrix54);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray65);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        int[] intArray0 = new int[] {};
        int[] intArray1 = org.apache.commons.math3.util.MathArrays.copyOf(intArray0);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker3 = new org.apache.commons.math3.optim.SimpleValueChecker(6.283185307179586d, 0.0d, 1076101151);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer5 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer((double) 100L, (double) 'a', (double) (byte) 1, (double) (short) -1, (double) (short) 1);
        int int6 = levenbergMarquardtOptimizer5.getEvaluations();
        double[] doubleArray7 = levenbergMarquardtOptimizer5.getStartPoint();
        double[] doubleArray8 = levenbergMarquardtOptimizer5.getLowerBound();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNull(doubleArray7);
        org.junit.Assert.assertNull(doubleArray8);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.apache.commons.math3.linear.NonSquareMatrixException nonSquareMatrixException2 = new org.apache.commons.math3.linear.NonSquareMatrixException((int) (short) 10, (int) (byte) -1);
        java.lang.Number number3 = nonSquareMatrixException2.getArgument();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 10 + "'", number3.equals(10));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        double[] doubleArray1 = new double[] { (short) 1 };
        double[] doubleArray4 = new double[] { '#', (short) 100 };
        double[] doubleArray5 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight6 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray5);
        org.apache.commons.math3.optim.nonlinear.vector.Target target7 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray5);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix8 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4, doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector11 = arrayRealVector9.mapAdd(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1, arrayRealVector9);
        boolean boolean13 = arrayRealVector12.isNaN();
        org.apache.commons.math3.linear.RealVector realVector15 = arrayRealVector12.mapSubtract(0.0d);
        org.apache.commons.math3.linear.RealVector realVector17 = arrayRealVector12.mapMultiply(1.1752011936438014d);
        org.apache.commons.math3.linear.RealVector realVector19 = realVector17.mapAdd(125.0d);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertNotNull(realVector19);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        double[] doubleArray2 = new double[] { '#', (short) 100 };
        double[] doubleArray3 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight4 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray3);
        org.apache.commons.math3.optim.nonlinear.vector.Target target5 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray3);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix6 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray2, doubleArray3);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.mapAdd(0.0d);
        org.apache.commons.math3.linear.RealVector realVector11 = arrayRealVector7.mapSubtract(2.2250738585072014E-308d);
        org.apache.commons.math3.linear.RealVector realVector13 = arrayRealVector7.mapAddToSelf(1.0E-15d);
        org.apache.commons.math3.linear.RealVector realVector15 = arrayRealVector7.mapAddToSelf((double) (short) 1);
        org.apache.commons.math3.linear.RealVector realVector17 = arrayRealVector7.mapDivideToSelf((double) 1.0f);
        try {
            arrayRealVector7.setEntry(125, 2.154434690031884d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (125)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(realVector11);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(realVector17);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        double double1 = org.apache.commons.math3.util.FastMath.ulp((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4210854715202004E-14d + "'", double1 == 1.4210854715202004E-14d);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 1.0E-15d, (java.lang.Number) 6.283185307179586d, (-52));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        float[] floatArray1 = new float[] { (byte) 1 };
        float[] floatArray2 = null;
        boolean boolean3 = org.apache.commons.math3.util.MathArrays.equals(floatArray1, floatArray2);
        float[] floatArray4 = null;
        float[] floatArray7 = new float[] { (-1L), '4' };
        boolean boolean8 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(floatArray4, floatArray7);
        boolean boolean9 = org.apache.commons.math3.util.MathArrays.equals(floatArray1, floatArray7);
        float[] floatArray10 = null;
        float[] floatArray13 = new float[] { (-1L), '4' };
        boolean boolean14 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(floatArray10, floatArray13);
        boolean boolean15 = org.apache.commons.math3.util.MathArrays.equals(floatArray1, floatArray13);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        double[] doubleArray1 = new double[] { (short) 1 };
        double[] doubleArray4 = new double[] { '#', (short) 100 };
        double[] doubleArray5 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight6 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray5);
        org.apache.commons.math3.optim.nonlinear.vector.Target target7 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray5);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix8 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4, doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector11 = arrayRealVector9.mapAdd(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1, arrayRealVector9);
        double[] doubleArray13 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight14 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray13);
        org.apache.commons.math3.optim.nonlinear.vector.Target target15 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray13);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix16 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray13);
        org.apache.commons.math3.linear.RealMatrix realMatrix18 = diagonalMatrix16.power((int) ' ');
        double[] doubleArray19 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight20 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray19);
        org.apache.commons.math3.optim.nonlinear.vector.Target target21 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray19);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix22 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray19);
        double[] doubleArray23 = diagonalMatrix16.operate(doubleArray19);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray23);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector12, arrayRealVector24);
        double[] doubleArray26 = arrayRealVector25.toArray();
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor27 = null;
        try {
            double double30 = arrayRealVector25.walkInDefaultOrder(realVectorChangingVisitor27, (-52), (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (-52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realMatrix18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray26);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver1 = new org.apache.commons.math3.analysis.solvers.BrentSolver(14890.0d);
        double double2 = brentSolver1.getMax();
        int int3 = brentSolver1.getEvaluations();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        double double1 = org.apache.commons.math3.util.FastMath.nextUp((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0000000000000002d + "'", double1 == 1.0000000000000002d);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        double[] doubleArray1 = new double[] { (short) 1 };
        double[] doubleArray4 = new double[] { '#', (short) 100 };
        double[] doubleArray5 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight6 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray5);
        org.apache.commons.math3.optim.nonlinear.vector.Target target7 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray5);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix8 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4, doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector11 = arrayRealVector9.mapAdd(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1, arrayRealVector9);
        double double13 = arrayRealVector12.getL1Norm();
        double[] doubleArray17 = new double[] { (short) 1 };
        double[] doubleArray20 = new double[] { '#', (short) 100 };
        double[] doubleArray21 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight22 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray21);
        org.apache.commons.math3.optim.nonlinear.vector.Target target23 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray21);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix24 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray21);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray20, doubleArray21);
        org.apache.commons.math3.linear.RealVector realVector27 = arrayRealVector25.mapAdd(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray17, arrayRealVector25);
        org.apache.commons.math3.linear.RealVector realVector30 = arrayRealVector28.mapAdd((double) (byte) 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = arrayRealVector12.combine((double) 100L, (double) (byte) 1, (org.apache.commons.math3.linear.RealVector) arrayRealVector28);
        arrayRealVector28.unitize();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 136.0d + "'", double13 == 136.0d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(realVector27);
        org.junit.Assert.assertNotNull(realVector30);
        org.junit.Assert.assertNotNull(arrayRealVector31);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
        org.apache.commons.math3.optim.nonlinear.vector.Target target2 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix3 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray0);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = diagonalMatrix3.power((int) ' ');
        double[] doubleArray6 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight7 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray6);
        org.apache.commons.math3.optim.nonlinear.vector.Target target8 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray6);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix9 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6);
        double[] doubleArray10 = diagonalMatrix3.operate(doubleArray6);
        org.apache.commons.math3.util.MathUtils.checkFinite(doubleArray6);
        org.apache.commons.math3.optim.PointValuePair pointValuePair13 = new org.apache.commons.math3.optim.PointValuePair(doubleArray6, (double) (-1L));
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Double[] doubleArray9 = new java.lang.Double[] { (-2.777777706332879E-4d), 52.0d, 10.0d, 14890.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray9);
        org.apache.commons.math3.exception.NoBracketingException noBracketingException11 = new org.apache.commons.math3.exception.NoBracketingException(localizable0, (double) 1.07269331E9f, 14889.999999999998d, 0.0d, (double) (short) 1, (java.lang.Object[]) doubleArray9);
        double double12 = noBracketingException11.getFHi();
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(125, (int) (byte) 100);
        double double3 = blockRealMatrix2.getNorm();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor4 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double5 = defaultRealMatrixPreservingVisitor4.end();
        double double6 = blockRealMatrix2.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor4);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor7 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        defaultRealMatrixPreservingVisitor7.start((int) 'a', (int) (byte) 1, 97, 0, (-1), 125);
        double double15 = blockRealMatrix2.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor7);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = new org.apache.commons.math3.linear.BlockRealMatrix(125, (int) (byte) 100);
        double double19 = blockRealMatrix18.getNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix20 = blockRealMatrix2.add(blockRealMatrix18);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix22 = blockRealMatrix20.scalarAdd(0.45805495157532494d);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix25 = new org.apache.commons.math3.linear.BlockRealMatrix(125, (int) (byte) 100);
        double double26 = blockRealMatrix25.getNorm();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor27 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double28 = defaultRealMatrixPreservingVisitor27.end();
        double double29 = blockRealMatrix25.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor27);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix32 = new org.apache.commons.math3.linear.BlockRealMatrix(125, (int) (byte) 100);
        double double33 = blockRealMatrix32.getNorm();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor34 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double35 = defaultRealMatrixPreservingVisitor34.end();
        double double36 = blockRealMatrix32.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor34);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor37 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        defaultRealMatrixPreservingVisitor37.start((int) 'a', (int) (byte) 1, 97, 0, (-1), 125);
        double double45 = blockRealMatrix32.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor37);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix48 = new org.apache.commons.math3.linear.BlockRealMatrix(125, (int) (byte) 100);
        double double49 = blockRealMatrix48.getNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix50 = blockRealMatrix32.add(blockRealMatrix48);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix52 = blockRealMatrix50.scalarAdd(0.45805495157532494d);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix53 = blockRealMatrix25.subtract(blockRealMatrix52);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix54 = blockRealMatrix22.add(blockRealMatrix25);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix55 = blockRealMatrix54.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix56 = blockRealMatrix54.copy();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix20);
        org.junit.Assert.assertNotNull(blockRealMatrix22);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix50);
        org.junit.Assert.assertNotNull(blockRealMatrix52);
        org.junit.Assert.assertNotNull(blockRealMatrix53);
        org.junit.Assert.assertNotNull(blockRealMatrix54);
        org.junit.Assert.assertNotNull(blockRealMatrix55);
        org.junit.Assert.assertNotNull(blockRealMatrix56);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        try {
            org.apache.commons.math3.optim.univariate.SearchInterval searchInterval3 = new org.apache.commons.math3.optim.univariate.SearchInterval(3.7663540285E10d, 100.0d, (double) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: 37,663,540,285 is larger than, or equal to, the maximum (100)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        long long2 = org.apache.commons.math3.util.FastMath.min((long) 36, (long) 52);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 36L + "'", long2 == 36L);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(125, (int) (byte) 100);
        double double3 = blockRealMatrix2.getNorm();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor4 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double5 = defaultRealMatrixPreservingVisitor4.end();
        double double6 = blockRealMatrix2.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor4);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor7 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        defaultRealMatrixPreservingVisitor7.start((int) 'a', (int) (byte) 1, 97, 0, (-1), 125);
        double double15 = blockRealMatrix2.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor7);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = new org.apache.commons.math3.linear.BlockRealMatrix(125, (int) (byte) 100);
        double double19 = blockRealMatrix18.getNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix20 = blockRealMatrix2.add(blockRealMatrix18);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix22 = blockRealMatrix20.scalarAdd(0.45805495157532494d);
        org.apache.commons.math3.linear.RealVector realVector24 = null;
        try {
            blockRealMatrix22.setRowVector(64, realVector24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix20);
        org.junit.Assert.assertNotNull(blockRealMatrix22);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
        org.apache.commons.math3.optim.nonlinear.vector.Target target2 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix3 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray0);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = diagonalMatrix3.power((int) ' ');
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = diagonalMatrix3.power((int) ' ');
        double[] doubleArray8 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight9 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray8);
        org.apache.commons.math3.optim.nonlinear.vector.Target target10 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray8);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix11 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray8);
        org.apache.commons.math3.linear.RealMatrix realMatrix13 = diagonalMatrix11.power((int) ' ');
        double[] doubleArray14 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight15 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray14);
        org.apache.commons.math3.optim.nonlinear.vector.Target target16 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray14);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix17 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray14);
        double[] doubleArray18 = diagonalMatrix11.operate(doubleArray14);
        double[] doubleArray19 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight20 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray19);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds21 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray18, doubleArray19);
        double[] doubleArray22 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight23 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray22);
        org.apache.commons.math3.optim.nonlinear.vector.Target target24 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray22);
        double[] doubleArray25 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray19, doubleArray22);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix27 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray19, true);
        org.apache.commons.math3.linear.RealMatrix realMatrix28 = diagonalMatrix3.preMultiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix27);
        double[] doubleArray29 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight30 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray29);
        org.apache.commons.math3.optim.nonlinear.vector.Target target31 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray29);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix32 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray29);
        org.apache.commons.math3.linear.RealMatrix realMatrix34 = diagonalMatrix32.power((int) ' ');
        double[] doubleArray35 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight36 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray35);
        org.apache.commons.math3.optim.nonlinear.vector.Target target37 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray35);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix38 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray35);
        double[] doubleArray39 = diagonalMatrix32.operate(doubleArray35);
        boolean boolean40 = diagonalMatrix32.isSquare();
        double[][] doubleArray41 = diagonalMatrix32.getData();
        try {
            diagonalMatrix3.setSubMatrix(doubleArray41, 2147483647, 2);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NoDataException; message: matrix must have at least one row");
        } catch (org.apache.commons.math3.exception.NoDataException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(realMatrix34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(doubleArray41);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer3 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer((double) 100.0f, 0.0d, 0.0d);
        int int4 = levenbergMarquardtOptimizer3.getMaxIterations();
        org.apache.commons.math3.optim.OptimizationData[] optimizationDataArray5 = null;
        try {
            org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair6 = levenbergMarquardtOptimizer3.optimize(optimizationDataArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2147483647 + "'", int4 == 2147483647);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
        org.apache.commons.math3.optim.nonlinear.vector.Target target2 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix3 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray0);
        double double4 = diagonalMatrix3.getFrobeniusNorm();
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.IdentityPreconditioner identityPreconditioner6 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.IdentityPreconditioner();
        double[] doubleArray7 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight8 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray7);
        org.apache.commons.math3.optim.nonlinear.vector.Target target9 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray7);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix10 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray7);
        org.apache.commons.math3.linear.RealMatrix realMatrix12 = diagonalMatrix10.power((int) ' ');
        double[] doubleArray13 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight14 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray13);
        org.apache.commons.math3.optim.nonlinear.vector.Target target15 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray13);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix16 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray13);
        double[] doubleArray17 = diagonalMatrix10.operate(doubleArray13);
        double[] doubleArray18 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight19 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray18);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds20 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray17, doubleArray18);
        double[] doubleArray21 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight22 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray21);
        double[] doubleArray23 = identityPreconditioner6.precondition(doubleArray18, doubleArray21);
        double[] doubleArray26 = new double[] { '#', (short) 100 };
        double[] doubleArray27 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight28 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray27);
        org.apache.commons.math3.optim.nonlinear.vector.Target target29 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray27);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix30 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray27);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray26, doubleArray27);
        double double32 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray21, doubleArray27);
        org.apache.commons.math3.linear.RealVector realVector33 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray21);
        try {
            diagonalMatrix3.setColumnVector((-1023), realVector33);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (-1,023)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(realMatrix12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(realVector33);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
        org.apache.commons.math3.optim.nonlinear.vector.Target target2 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix3 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray0);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = diagonalMatrix3.power((int) ' ');
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = diagonalMatrix3.power((int) ' ');
        double[] doubleArray8 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight9 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray8);
        org.apache.commons.math3.optim.nonlinear.vector.Target target10 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray8);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix11 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray8);
        org.apache.commons.math3.linear.RealMatrix realMatrix13 = diagonalMatrix11.power((int) ' ');
        double[] doubleArray14 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight15 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray14);
        org.apache.commons.math3.optim.nonlinear.vector.Target target16 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray14);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix17 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray14);
        double[] doubleArray18 = diagonalMatrix11.operate(doubleArray14);
        double[] doubleArray19 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight20 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray19);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds21 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray18, doubleArray19);
        double[] doubleArray22 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight23 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray22);
        org.apache.commons.math3.optim.nonlinear.vector.Target target24 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray22);
        double[] doubleArray25 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray19, doubleArray22);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix27 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray19, true);
        org.apache.commons.math3.linear.RealMatrix realMatrix28 = diagonalMatrix3.preMultiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix27);
        double[] doubleArray29 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight30 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray29);
        org.apache.commons.math3.optim.nonlinear.vector.Target target31 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray29);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix32 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray29);
        org.apache.commons.math3.linear.RealMatrix realMatrix34 = diagonalMatrix32.power((int) ' ');
        double[] doubleArray35 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight36 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray35);
        org.apache.commons.math3.optim.nonlinear.vector.Target target37 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray35);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix38 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray35);
        double[] doubleArray39 = diagonalMatrix32.operate(doubleArray35);
        double[] doubleArray40 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight41 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray40);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds42 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray39, doubleArray40);
        double[] doubleArray43 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight44 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray43);
        org.apache.commons.math3.optim.nonlinear.vector.Target target45 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray43);
        double[] doubleArray46 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray40, doubleArray43);
        double[] doubleArray47 = diagonalMatrix27.preMultiply(doubleArray46);
        org.apache.commons.math3.linear.RealVector realVector48 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray46);
        try {
            double[] doubleArray50 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray46, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(realMatrix34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(realVector48);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker2 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker(0.0d, (double) 0.0f);
        org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair6 = new org.apache.commons.math3.optim.univariate.UnivariatePointValuePair((double) 100, 9.999999999999998d);
        org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair9 = new org.apache.commons.math3.optim.univariate.UnivariatePointValuePair(0.0d, 0.0d);
        double double10 = univariatePointValuePair9.getPoint();
        boolean boolean11 = simpleUnivariateValueChecker2.converged(2147483647, univariatePointValuePair6, univariatePointValuePair9);
        org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair13 = null;
        org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair16 = new org.apache.commons.math3.optim.univariate.UnivariatePointValuePair(0.0d, 0.0d);
        double double17 = univariatePointValuePair16.getPoint();
        try {
            boolean boolean18 = simpleUnivariateValueChecker2.converged(100, univariatePointValuePair13, univariatePointValuePair16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        int int3 = org.apache.commons.math3.util.Precision.compareTo(0.0d, (double) 5688046246375236535L, (double) 10L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder0 = new org.apache.commons.math3.optim.univariate.BracketFinder();
        double double1 = bracketFinder0.getLo();
        double double2 = bracketFinder0.getLo();
        double double3 = bracketFinder0.getFHi();
        double double4 = bracketFinder0.getHi();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        double double2 = org.apache.commons.math3.util.FastMath.min((double) 0, 1.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) 1.0f);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = new org.apache.commons.math3.linear.RealVectorFormat();
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((float) 97, (float) 52, (float) 36);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
        org.apache.commons.math3.optim.nonlinear.vector.Target target2 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix3 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray0);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = diagonalMatrix3.power((int) ' ');
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = diagonalMatrix3.power((int) ' ');
        double[] doubleArray8 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight9 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray8);
        org.apache.commons.math3.optim.nonlinear.vector.Target target10 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray8);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix11 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray8);
        org.apache.commons.math3.linear.RealMatrix realMatrix13 = diagonalMatrix11.power((int) ' ');
        double[] doubleArray14 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight15 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray14);
        org.apache.commons.math3.optim.nonlinear.vector.Target target16 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray14);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix17 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray14);
        double[] doubleArray18 = diagonalMatrix11.operate(doubleArray14);
        double[] doubleArray19 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight20 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray19);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds21 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray18, doubleArray19);
        double[] doubleArray22 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight23 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray22);
        org.apache.commons.math3.optim.nonlinear.vector.Target target24 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray22);
        double[] doubleArray25 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray19, doubleArray22);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix27 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray19, true);
        org.apache.commons.math3.linear.RealMatrix realMatrix28 = diagonalMatrix3.preMultiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix27);
        java.lang.String str29 = diagonalMatrix27.toString();
        double[] doubleArray30 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight31 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray30);
        org.apache.commons.math3.optim.nonlinear.vector.Target target32 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray30);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix33 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray30);
        org.apache.commons.math3.linear.RealMatrix realMatrix35 = diagonalMatrix33.power((int) ' ');
        double[] doubleArray36 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight37 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray36);
        org.apache.commons.math3.optim.nonlinear.vector.Target target38 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray36);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix39 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray36);
        double[] doubleArray40 = diagonalMatrix33.operate(doubleArray36);
        double[] doubleArray41 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight42 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray41);
        org.apache.commons.math3.optim.nonlinear.vector.Target target43 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray41);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix44 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray41);
        double[] doubleArray45 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray40, doubleArray41);
        double[] doubleArray46 = diagonalMatrix27.operate(doubleArray41);
        double[] doubleArray47 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight48 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray47);
        org.apache.commons.math3.optim.nonlinear.vector.Target target49 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray47);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix50 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray47);
        org.apache.commons.math3.linear.RealMatrix realMatrix52 = diagonalMatrix50.power((int) ' ');
        org.apache.commons.math3.linear.RealMatrix realMatrix54 = diagonalMatrix50.power((int) ' ');
        double[] doubleArray55 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight56 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray55);
        org.apache.commons.math3.optim.nonlinear.vector.Target target57 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray55);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix58 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray55);
        org.apache.commons.math3.linear.RealMatrix realMatrix60 = diagonalMatrix58.power((int) ' ');
        double[] doubleArray61 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight62 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray61);
        org.apache.commons.math3.optim.nonlinear.vector.Target target63 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray61);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix64 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray61);
        double[] doubleArray65 = diagonalMatrix58.operate(doubleArray61);
        double[] doubleArray66 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight67 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray66);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds68 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray65, doubleArray66);
        double[] doubleArray69 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight70 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray69);
        org.apache.commons.math3.optim.nonlinear.vector.Target target71 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray69);
        double[] doubleArray72 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray66, doubleArray69);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix74 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray66, true);
        org.apache.commons.math3.linear.RealMatrix realMatrix75 = diagonalMatrix50.preMultiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix74);
        double[] doubleArray76 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight77 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray76);
        org.apache.commons.math3.optim.nonlinear.vector.Target target78 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray76);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix79 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray76);
        org.apache.commons.math3.linear.RealMatrix realMatrix81 = diagonalMatrix79.power((int) ' ');
        double[] doubleArray82 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight83 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray82);
        org.apache.commons.math3.optim.nonlinear.vector.Target target84 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray82);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix85 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray82);
        double[] doubleArray86 = diagonalMatrix79.operate(doubleArray82);
        double[] doubleArray87 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray86);
        double[] doubleArray88 = diagonalMatrix50.operate(doubleArray86);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix89 = diagonalMatrix27.add(diagonalMatrix50);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor90 = null;
        try {
            double double91 = diagonalMatrix89.walkInColumnOrder(realMatrixChangingVisitor90);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "DiagonalMatrix{}" + "'", str29.equals("DiagonalMatrix{}"));
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(realMatrix35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(realMatrix52);
        org.junit.Assert.assertNotNull(realMatrix54);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(realMatrix60);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(realMatrix75);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(realMatrix81);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertNotNull(diagonalMatrix89);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.IdentityPreconditioner identityPreconditioner0 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.IdentityPreconditioner();
        double[] doubleArray1 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight2 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray1);
        org.apache.commons.math3.optim.nonlinear.vector.Target target3 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray1);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray1);
        org.apache.commons.math3.linear.RealMatrix realMatrix6 = diagonalMatrix4.power((int) ' ');
        double[] doubleArray7 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight8 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray7);
        org.apache.commons.math3.optim.nonlinear.vector.Target target9 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray7);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix10 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray7);
        double[] doubleArray11 = diagonalMatrix4.operate(doubleArray7);
        double[] doubleArray12 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight13 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray12);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds14 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray11, doubleArray12);
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight16 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray15);
        double[] doubleArray17 = identityPreconditioner0.precondition(doubleArray12, doubleArray15);
        double[] doubleArray18 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight19 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray18);
        org.apache.commons.math3.optim.nonlinear.vector.Target target20 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix21 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray18);
        org.apache.commons.math3.linear.RealMatrix realMatrix23 = diagonalMatrix21.power((int) ' ');
        double[] doubleArray24 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight25 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray24);
        org.apache.commons.math3.optim.nonlinear.vector.Target target26 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray24);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix27 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray24);
        double[] doubleArray28 = diagonalMatrix21.operate(doubleArray24);
        double[] doubleArray29 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray28);
        double[] doubleArray32 = new double[] { '#', (short) 100 };
        double[] doubleArray33 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight34 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray33);
        org.apache.commons.math3.optim.nonlinear.vector.Target target35 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray33);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix36 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray33);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray32, doubleArray33);
        double[] doubleArray38 = identityPreconditioner0.precondition(doubleArray28, doubleArray33);
        double[] doubleArray40 = new double[] { (short) 1 };
        double[] doubleArray43 = new double[] { '#', (short) 100 };
        double[] doubleArray44 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight45 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray44);
        org.apache.commons.math3.optim.nonlinear.vector.Target target46 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray44);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix47 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray44);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray43, doubleArray44);
        org.apache.commons.math3.linear.RealVector realVector50 = arrayRealVector48.mapAdd(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector51 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray40, arrayRealVector48);
        double double52 = arrayRealVector51.getL1Norm();
        double[] doubleArray56 = new double[] { (short) 1 };
        double[] doubleArray59 = new double[] { '#', (short) 100 };
        double[] doubleArray60 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight61 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray60);
        org.apache.commons.math3.optim.nonlinear.vector.Target target62 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray60);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix63 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray60);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector64 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray59, doubleArray60);
        org.apache.commons.math3.linear.RealVector realVector66 = arrayRealVector64.mapAdd(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector67 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray56, arrayRealVector64);
        org.apache.commons.math3.linear.RealVector realVector69 = arrayRealVector67.mapAdd((double) (byte) 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector70 = arrayRealVector51.combine((double) 100L, (double) (byte) 1, (org.apache.commons.math3.linear.RealVector) arrayRealVector67);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector71 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray33, arrayRealVector70);
        org.apache.commons.math3.analysis.function.Sinc sinc72 = new org.apache.commons.math3.analysis.function.Sinc();
        double double74 = sinc72.value(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector75 = arrayRealVector70.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc72);
        org.apache.commons.math3.analysis.differentiation.DerivativeStructure derivativeStructure76 = null;
        try {
            org.apache.commons.math3.analysis.differentiation.DerivativeStructure derivativeStructure77 = sinc72.value(derivativeStructure76);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realMatrix23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(realVector50);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 136.0d + "'", double52 == 136.0d);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(realVector66);
        org.junit.Assert.assertNotNull(realVector69);
        org.junit.Assert.assertNotNull(arrayRealVector70);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 1.0d + "'", double74 == 1.0d);
        org.junit.Assert.assertNotNull(arrayRealVector75);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(125, (int) (byte) 100);
        double double3 = blockRealMatrix2.getNorm();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor4 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double5 = defaultRealMatrixPreservingVisitor4.end();
        double double6 = blockRealMatrix2.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor4);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor7 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        defaultRealMatrixPreservingVisitor7.start((int) 'a', (int) (byte) 1, 97, 0, (-1), 125);
        double double15 = blockRealMatrix2.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor7);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = new org.apache.commons.math3.linear.BlockRealMatrix(125, (int) (byte) 100);
        double double19 = blockRealMatrix18.getNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix20 = blockRealMatrix2.add(blockRealMatrix18);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix22 = blockRealMatrix20.scalarAdd(0.45805495157532494d);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix25 = new org.apache.commons.math3.linear.BlockRealMatrix(125, (int) (byte) 100);
        double double26 = blockRealMatrix25.getNorm();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor27 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double28 = defaultRealMatrixPreservingVisitor27.end();
        double double29 = blockRealMatrix25.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor27);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix32 = new org.apache.commons.math3.linear.BlockRealMatrix(125, (int) (byte) 100);
        double double33 = blockRealMatrix32.getNorm();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor34 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double35 = defaultRealMatrixPreservingVisitor34.end();
        double double36 = blockRealMatrix32.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor34);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor37 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        defaultRealMatrixPreservingVisitor37.start((int) 'a', (int) (byte) 1, 97, 0, (-1), 125);
        double double45 = blockRealMatrix32.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor37);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix48 = new org.apache.commons.math3.linear.BlockRealMatrix(125, (int) (byte) 100);
        double double49 = blockRealMatrix48.getNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix50 = blockRealMatrix32.add(blockRealMatrix48);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix52 = blockRealMatrix50.scalarAdd(0.45805495157532494d);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix53 = blockRealMatrix25.subtract(blockRealMatrix52);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix54 = blockRealMatrix22.add(blockRealMatrix25);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix55 = blockRealMatrix54.transpose();
        boolean boolean56 = blockRealMatrix55.isSquare();
        org.apache.commons.math3.linear.RealMatrix realMatrix58 = blockRealMatrix55.getColumnMatrix(0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix20);
        org.junit.Assert.assertNotNull(blockRealMatrix22);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix50);
        org.junit.Assert.assertNotNull(blockRealMatrix52);
        org.junit.Assert.assertNotNull(blockRealMatrix53);
        org.junit.Assert.assertNotNull(blockRealMatrix54);
        org.junit.Assert.assertNotNull(blockRealMatrix55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(realMatrix58);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 100, number1, (-1748719057));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        double[] doubleArray3 = new double[] { '#', (byte) 100, (short) 100 };
        double[] doubleArray7 = new double[] { '#', (byte) 100, (short) 100 };
        double[] doubleArray11 = new double[] { '#', (byte) 100, (short) 100 };
        double[] doubleArray15 = new double[] { '#', (byte) 100, (short) 100 };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        double[][] doubleArray17 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray16);
        org.apache.commons.math3.linear.NonSquareMatrixException nonSquareMatrixException20 = new org.apache.commons.math3.linear.NonSquareMatrixException((int) (short) 1, (int) (short) 10);
        org.apache.commons.math3.util.Pair<java.lang.Object[], org.apache.commons.math3.exception.MathIllegalNumberException> objArrayPair21 = new org.apache.commons.math3.util.Pair<java.lang.Object[], org.apache.commons.math3.exception.MathIllegalNumberException>((java.lang.Object[]) doubleArray16, (org.apache.commons.math3.exception.MathIllegalNumberException) nonSquareMatrixException20);
        java.lang.Object[] objArray22 = objArrayPair21.getKey();
        java.lang.Object[] objArray23 = objArrayPair21.getKey();
        org.apache.commons.math3.exception.MathIllegalNumberException mathIllegalNumberException24 = objArrayPair21.getSecond();
        double[] doubleArray26 = new double[] { (short) 1 };
        double[] doubleArray29 = new double[] { '#', (short) 100 };
        double[] doubleArray30 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight31 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray30);
        org.apache.commons.math3.optim.nonlinear.vector.Target target32 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray30);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix33 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray30);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray29, doubleArray30);
        org.apache.commons.math3.linear.RealVector realVector36 = arrayRealVector34.mapAdd(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray26, arrayRealVector34);
        boolean boolean38 = arrayRealVector37.isNaN();
        org.apache.commons.math3.linear.RealVector realVector40 = arrayRealVector37.mapSubtract(0.0d);
        boolean boolean41 = objArrayPair21.equals((java.lang.Object) arrayRealVector37);
        org.apache.commons.math3.linear.RealVector realVector43 = arrayRealVector37.mapDivideToSelf((double) 100.0f);
        int int44 = arrayRealVector37.getMinIndex();
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNotNull(mathIllegalNumberException24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(realVector36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(realVector40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(realVector43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.MatrixUtils.DEFAULT_FORMAT;
        java.lang.String str1 = realMatrixFormat0.getRowSeparator();
        double[] doubleArray2 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight3 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray2);
        org.apache.commons.math3.optim.nonlinear.vector.Target target4 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray2);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix5 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray2);
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = diagonalMatrix5.power((int) ' ');
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = diagonalMatrix5.power((int) ' ');
        double[] doubleArray10 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight11 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray10);
        org.apache.commons.math3.optim.nonlinear.vector.Target target12 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray10);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix13 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray10);
        org.apache.commons.math3.linear.RealMatrix realMatrix15 = diagonalMatrix13.power((int) ' ');
        double[] doubleArray16 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight17 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray16);
        org.apache.commons.math3.optim.nonlinear.vector.Target target18 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray16);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix19 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray16);
        double[] doubleArray20 = diagonalMatrix13.operate(doubleArray16);
        double[] doubleArray21 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight22 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray21);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds23 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray20, doubleArray21);
        double[] doubleArray24 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight25 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray24);
        org.apache.commons.math3.optim.nonlinear.vector.Target target26 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray24);
        double[] doubleArray27 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray21, doubleArray24);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix29 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray21, true);
        org.apache.commons.math3.linear.RealMatrix realMatrix30 = diagonalMatrix5.preMultiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix29);
        java.lang.String str31 = diagonalMatrix29.toString();
        double[] doubleArray32 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight33 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray32);
        org.apache.commons.math3.optim.nonlinear.vector.Target target34 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray32);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix35 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray32);
        org.apache.commons.math3.linear.RealMatrix realMatrix37 = diagonalMatrix35.power((int) ' ');
        double[] doubleArray38 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight39 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray38);
        org.apache.commons.math3.optim.nonlinear.vector.Target target40 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray38);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix41 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray38);
        double[] doubleArray42 = diagonalMatrix35.operate(doubleArray38);
        double[] doubleArray43 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight44 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray43);
        org.apache.commons.math3.optim.nonlinear.vector.Target target45 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray43);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix46 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray43);
        double[] doubleArray47 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray42, doubleArray43);
        double[] doubleArray48 = diagonalMatrix29.operate(doubleArray43);
        java.lang.String str49 = realMatrixFormat0.format((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix29);
        java.lang.String str50 = diagonalMatrix29.toString();
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor51 = null;
        try {
            double double52 = diagonalMatrix29.walkInRowOrder(realMatrixPreservingVisitor51);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "," + "'", str1.equals(","));
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(realMatrix15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "DiagonalMatrix{}" + "'", str31.equals("DiagonalMatrix{}"));
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(realMatrix37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "{}" + "'", str49.equals("{}"));
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "DiagonalMatrix{}" + "'", str50.equals("DiagonalMatrix{}"));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister10 = new org.apache.commons.math3.random.MersenneTwister((int) '#');
        double double11 = mersenneTwister10.nextDouble();
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker15 = new org.apache.commons.math3.optim.SimpleValueChecker((double) (byte) 1, (double) (short) 100);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer16 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer((int) '#', (double) (short) 1, true, 36, 10, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister10, true, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker15);
        double double17 = simpleValueChecker15.getAbsoluteThreshold();
        double double18 = simpleValueChecker15.getRelativeThreshold();
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer powellOptimizer19 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer((double) (-1L), 0.026263128777403777d, (double) 1076101120, 1.0E-6d, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker15);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooSmallException; message: -1 is smaller than the minimum (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooSmallException e) {
        }
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.45805495157532494d + "'", double11 == 0.45805495157532494d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 100.0d + "'", double17 == 100.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker3 = new org.apache.commons.math3.optim.SimpleValueChecker(5.6880462463752366E18d, 11013.232920103323d, 100);
        double double4 = simpleValueChecker3.getRelativeThreshold();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 5.6880462463752366E18d + "'", double4 == 5.6880462463752366E18d);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.apache.commons.math3.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math3.exception.NoBracketingException(5.6880462463752366E18d, 2.2250738585072014E-308d, 1.0E-15d, (double) 10);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        java.lang.Number number0 = null;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(number0, (java.lang.Number) 0.8414709848078965d, (int) (byte) 0);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection4 = nonMonotonicSequenceException3.getDirection();
        int int5 = nonMonotonicSequenceException3.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection4.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer5 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer((double) 10, (double) (short) 1, 9.999999999999998d, (double) (short) 1, (double) 10);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        try {
            org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.verifySequence(3600.0d, (double) (short) 0, (double) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [3,600, 0]");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.apache.commons.math3.optim.SimpleVectorValueChecker simpleVectorValueChecker4 = new org.apache.commons.math3.optim.SimpleVectorValueChecker((double) (byte) 0, (double) 0L, 125);
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer gaussNewtonOptimizer5 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer((org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair>) simpleVectorValueChecker4);
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer gaussNewtonOptimizer6 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer(false, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair>) simpleVectorValueChecker4);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals(0.0d, (double) 'a', 36);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        double[] doubleArray2 = new double[] { '#', (short) 100 };
        double[] doubleArray3 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight4 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray3);
        org.apache.commons.math3.optim.nonlinear.vector.Target target5 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray3);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix6 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray2, doubleArray3);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.mapAdd(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = arrayRealVector7.copy();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(arrayRealVector10);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat6 = org.apache.commons.math3.linear.MatrixUtils.OCTAVE_FORMAT;
        java.text.NumberFormat numberFormat7 = realMatrixFormat6.getFormat();
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat8 = new org.apache.commons.math3.linear.RealMatrixFormat(", ", "hi!", "{", "", ", ", "DiagonalMatrix{}", numberFormat7);
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat9 = new org.apache.commons.math3.linear.RealMatrixFormat(numberFormat7);
        java.lang.String str10 = realMatrixFormat9.getPrefix();
        org.junit.Assert.assertNotNull(realMatrixFormat6);
        org.junit.Assert.assertNotNull(numberFormat7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "{" + "'", str10.equals("{"));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(125, (int) (byte) 100);
        double double3 = blockRealMatrix2.getNorm();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor4 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double5 = defaultRealMatrixPreservingVisitor4.end();
        double double6 = blockRealMatrix2.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor4);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor7 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        defaultRealMatrixPreservingVisitor7.start((int) 'a', (int) (byte) 1, 97, 0, (-1), 125);
        double double15 = blockRealMatrix2.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor7);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = new org.apache.commons.math3.linear.BlockRealMatrix(125, (int) (byte) 100);
        double double19 = blockRealMatrix18.getNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix20 = blockRealMatrix2.add(blockRealMatrix18);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor21 = null;
        try {
            double double22 = blockRealMatrix2.walkInRowOrder(realMatrixChangingVisitor21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix20);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(125, (int) (byte) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix(125, (int) (byte) 100);
        double double6 = blockRealMatrix5.getNorm();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor7 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double8 = defaultRealMatrixPreservingVisitor7.end();
        double double9 = blockRealMatrix5.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor7);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix12 = new org.apache.commons.math3.linear.BlockRealMatrix(125, (int) (byte) 100);
        double double13 = blockRealMatrix12.getNorm();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor14 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double15 = defaultRealMatrixPreservingVisitor14.end();
        double double16 = blockRealMatrix12.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor14);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor17 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        defaultRealMatrixPreservingVisitor17.start((int) 'a', (int) (byte) 1, 97, 0, (-1), 125);
        double double25 = blockRealMatrix12.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor17);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix28 = new org.apache.commons.math3.linear.BlockRealMatrix(125, (int) (byte) 100);
        double double29 = blockRealMatrix28.getNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix30 = blockRealMatrix12.add(blockRealMatrix28);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix32 = blockRealMatrix30.scalarAdd(0.45805495157532494d);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix33 = blockRealMatrix5.subtract(blockRealMatrix32);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix34 = blockRealMatrix2.multiply(blockRealMatrix33);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 100 != 125");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix30);
        org.junit.Assert.assertNotNull(blockRealMatrix32);
        org.junit.Assert.assertNotNull(blockRealMatrix33);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = null;
        double[] doubleArray3 = new double[] { '#', (short) 100 };
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight5 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray4);
        org.apache.commons.math3.optim.nonlinear.vector.Target target6 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray4);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix7 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray4);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray3, doubleArray4);
        org.apache.commons.math3.linear.RealVector realVector10 = arrayRealVector8.mapAdd(0.0d);
        org.apache.commons.math3.linear.RealVector realVector12 = arrayRealVector8.mapSubtract(2.2250738585072014E-308d);
        org.apache.commons.math3.linear.RealVector realVector14 = arrayRealVector8.mapAddToSelf(1.0E-15d);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, (org.apache.commons.math3.linear.RealVector) arrayRealVector8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(realVector10);
        org.junit.Assert.assertNotNull(realVector12);
        org.junit.Assert.assertNotNull(realVector14);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math3.random.MersenneTwister((int) '#');
        double double2 = mersenneTwister1.nextDouble();
        int[] intArray5 = new int[] { 100, 36 };
        int[] intArray12 = new int[] { 1, (short) 10, (short) 1, (byte) 10, (byte) 1, (short) -1 };
        int int13 = org.apache.commons.math3.util.MathArrays.distance1(intArray5, intArray12);
        mersenneTwister1.setSeed(intArray12);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.45805495157532494d + "'", double2 == 0.45805495157532494d);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 125 + "'", int13 == 125);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        double double1 = org.apache.commons.math3.util.FastMath.log10(2.2250738585072014E-308d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-307.6526555685888d) + "'", double1 == (-307.6526555685888d));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        double[] doubleArray3 = new double[] { '#', (byte) 100, (short) 100 };
        double[] doubleArray7 = new double[] { '#', (byte) 100, (short) 100 };
        double[] doubleArray11 = new double[] { '#', (byte) 100, (short) 100 };
        double[] doubleArray15 = new double[] { '#', (byte) 100, (short) 100 };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        double[][] doubleArray17 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray16);
        double[][] doubleArray18 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray17);
        org.apache.commons.math3.linear.RealMatrix realMatrix19 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray18);
        try {
            org.apache.commons.math3.linear.LUDecomposition lUDecomposition21 = new org.apache.commons.math3.linear.LUDecomposition(realMatrix19, 100.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.NonSquareMatrixException; message: non square (1x12) matrix");
        } catch (org.apache.commons.math3.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realMatrix19);
    }
}

