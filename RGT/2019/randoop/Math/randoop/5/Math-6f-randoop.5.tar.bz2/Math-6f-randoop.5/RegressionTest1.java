import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test01");
        org.apache.commons.math3.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math3.exception.TooManyEvaluationsException((java.lang.Number) 14890.0d);
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test02");
        double double1 = org.apache.commons.math3.util.FastMath.sinh(3.7663540285E10d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test03");
        double[] doubleArray2 = new double[] { '#', (short) 100 };
        double[] doubleArray3 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight4 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray3);
        org.apache.commons.math3.optim.nonlinear.vector.Target target5 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray3);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix6 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray2, doubleArray3);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.mapAdd(0.0d);
        double[] doubleArray10 = arrayRealVector7.toArray();
        boolean boolean11 = arrayRealVector7.isInfinite();
        double double12 = arrayRealVector7.getLInfNorm();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 100.0d + "'", double12 == 100.0d);
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test04");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat7 = org.apache.commons.math3.linear.MatrixUtils.OCTAVE_FORMAT;
        java.text.NumberFormat numberFormat8 = realMatrixFormat7.getFormat();
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat9 = new org.apache.commons.math3.linear.RealMatrixFormat(", ", "hi!", "{", "", ", ", "DiagonalMatrix{}", numberFormat8);
        java.text.ParsePosition parsePosition10 = null;
        try {
            java.lang.Number number11 = org.apache.commons.math3.util.CompositeFormat.parseNumber("{}", numberFormat8, parsePosition10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrixFormat7);
        org.junit.Assert.assertNotNull(numberFormat8);
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test05");
        double double1 = org.apache.commons.math3.util.FastMath.cosh(0.7853981633974483d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3246090892520057d + "'", double1 == 1.3246090892520057d);
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test06");
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker0 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer simplexOptimizer1 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer(pointValuePairConvergenceChecker0);
        double[] doubleArray2 = simplexOptimizer1.getLowerBound();
        double[] doubleArray3 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight4 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray3);
        org.apache.commons.math3.optim.nonlinear.vector.Target target5 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray3);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix6 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = diagonalMatrix6.power((int) ' ');
        double[] doubleArray9 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight10 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray9);
        org.apache.commons.math3.optim.nonlinear.vector.Target target11 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray9);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix12 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray9);
        double[] doubleArray13 = diagonalMatrix6.operate(doubleArray9);
        double[] doubleArray14 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight15 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray14);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds16 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray13, doubleArray14);
        double[] doubleArray17 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight18 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray17);
        org.apache.commons.math3.linear.RealMatrix realMatrix19 = weight18.getWeight();
        org.apache.commons.math3.optim.OptimizationData[] optimizationDataArray20 = new org.apache.commons.math3.optim.OptimizationData[] { simpleBounds16, weight18 };
        try {
            org.apache.commons.math3.optim.PointValuePair pointValuePair21 = simplexOptimizer1.optimize(optimizationDataArray20);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(realMatrix19);
        org.junit.Assert.assertNotNull(optimizationDataArray20);
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test07");
        org.apache.commons.math3.optim.MaxEval maxEval1 = new org.apache.commons.math3.optim.MaxEval(1);
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test08");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer simplexOptimizer2 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer(125.0d, (double) 10);
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test09");
        org.apache.commons.math3.util.Incrementor incrementor1 = new org.apache.commons.math3.util.Incrementor(0);
        int int2 = incrementor1.getMaximalCount();
        int int3 = incrementor1.getCount();
        incrementor1.resetCount();
        int int5 = incrementor1.getMaximalCount();
        incrementor1.setMaximalCount((int) (byte) 1);
        incrementor1.setMaximalCount(100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test10");
        double double2 = org.apache.commons.math3.util.MathUtils.normalizeAngle((double) '#', (double) (-1023));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1020.5751316061705d) + "'", double2 == (-1020.5751316061705d));
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test11");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.IdentityPreconditioner identityPreconditioner0 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.IdentityPreconditioner();
        double[] doubleArray1 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight2 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray1);
        org.apache.commons.math3.optim.nonlinear.vector.Target target3 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray1);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray1);
        org.apache.commons.math3.linear.RealMatrix realMatrix6 = diagonalMatrix4.power((int) ' ');
        double[] doubleArray7 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight8 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray7);
        org.apache.commons.math3.optim.nonlinear.vector.Target target9 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray7);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix10 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray7);
        double[] doubleArray11 = diagonalMatrix4.operate(doubleArray7);
        double[] doubleArray12 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight13 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray12);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds14 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray11, doubleArray12);
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight16 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray15);
        double[] doubleArray17 = identityPreconditioner0.precondition(doubleArray12, doubleArray15);
        double[] doubleArray18 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight19 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray18);
        org.apache.commons.math3.optim.nonlinear.vector.Target target20 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix21 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray18);
        org.apache.commons.math3.linear.RealMatrix realMatrix23 = diagonalMatrix21.power((int) ' ');
        double[] doubleArray24 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight25 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray24);
        org.apache.commons.math3.optim.nonlinear.vector.Target target26 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray24);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix27 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray24);
        double[] doubleArray28 = diagonalMatrix21.operate(doubleArray24);
        double[] doubleArray29 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray28);
        double[] doubleArray32 = new double[] { '#', (short) 100 };
        double[] doubleArray33 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight34 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray33);
        org.apache.commons.math3.optim.nonlinear.vector.Target target35 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray33);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix36 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray33);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray32, doubleArray33);
        double[] doubleArray38 = identityPreconditioner0.precondition(doubleArray28, doubleArray33);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma39 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realMatrix23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray38);
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test12");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 2, (java.lang.Number) 1076101120, false);
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test13");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat3 = new org.apache.commons.math3.linear.RealVectorFormat("hi!", "{", ",");
        double[] doubleArray5 = new double[] { (short) 1 };
        double[] doubleArray8 = new double[] { '#', (short) 100 };
        double[] doubleArray9 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight10 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray9);
        org.apache.commons.math3.optim.nonlinear.vector.Target target11 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray9);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix12 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray9);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray8, doubleArray9);
        org.apache.commons.math3.linear.RealVector realVector15 = arrayRealVector13.mapAdd(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5, arrayRealVector13);
        boolean boolean17 = arrayRealVector16.isNaN();
        org.apache.commons.math3.linear.RealVector realVector19 = arrayRealVector16.mapSubtract(0.0d);
        org.apache.commons.math3.linear.RealVector realVector21 = arrayRealVector16.mapMultiply(1.1752011936438014d);
        java.lang.StringBuffer stringBuffer22 = null;
        java.text.FieldPosition fieldPosition23 = null;
        try {
            java.lang.StringBuffer stringBuffer24 = realVectorFormat3.format(realVector21, stringBuffer22, fieldPosition23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(realVector21);
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test14");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.IdentityPreconditioner identityPreconditioner0 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.IdentityPreconditioner();
        double[] doubleArray1 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight2 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray1);
        org.apache.commons.math3.optim.nonlinear.vector.Target target3 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray1);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray1);
        org.apache.commons.math3.linear.RealMatrix realMatrix6 = diagonalMatrix4.power((int) ' ');
        double[] doubleArray7 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight8 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray7);
        org.apache.commons.math3.optim.nonlinear.vector.Target target9 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray7);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix10 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray7);
        double[] doubleArray11 = diagonalMatrix4.operate(doubleArray7);
        double[] doubleArray12 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight13 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray12);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds14 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray11, doubleArray12);
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight16 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray15);
        double[] doubleArray17 = identityPreconditioner0.precondition(doubleArray12, doubleArray15);
        double[] doubleArray18 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight19 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray18);
        org.apache.commons.math3.optim.nonlinear.vector.Target target20 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix21 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray18);
        org.apache.commons.math3.linear.RealMatrix realMatrix23 = diagonalMatrix21.power((int) ' ');
        org.apache.commons.math3.linear.RealMatrix realMatrix25 = diagonalMatrix21.power((int) ' ');
        double[] doubleArray26 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight27 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray26);
        org.apache.commons.math3.optim.nonlinear.vector.Target target28 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray26);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix29 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray26);
        org.apache.commons.math3.linear.RealMatrix realMatrix31 = diagonalMatrix29.power((int) ' ');
        double[] doubleArray32 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight33 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray32);
        org.apache.commons.math3.optim.nonlinear.vector.Target target34 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray32);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix35 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray32);
        double[] doubleArray36 = diagonalMatrix29.operate(doubleArray32);
        double[] doubleArray37 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight38 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray37);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds39 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray36, doubleArray37);
        double[] doubleArray40 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight41 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray40);
        org.apache.commons.math3.optim.nonlinear.vector.Target target42 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray40);
        double[] doubleArray43 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray37, doubleArray40);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix45 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray37, true);
        org.apache.commons.math3.linear.RealMatrix realMatrix46 = diagonalMatrix21.preMultiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix45);
        java.lang.String str47 = diagonalMatrix45.toString();
        double[] doubleArray48 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight49 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray48);
        org.apache.commons.math3.optim.nonlinear.vector.Target target50 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray48);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix51 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray48);
        org.apache.commons.math3.linear.RealMatrix realMatrix53 = diagonalMatrix51.power((int) ' ');
        double[] doubleArray54 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight55 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray54);
        org.apache.commons.math3.optim.nonlinear.vector.Target target56 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray54);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix57 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray54);
        double[] doubleArray58 = diagonalMatrix51.operate(doubleArray54);
        double[] doubleArray59 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight60 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray59);
        org.apache.commons.math3.optim.nonlinear.vector.Target target61 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray59);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix62 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray59);
        double[] doubleArray63 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray58, doubleArray59);
        double[] doubleArray64 = diagonalMatrix45.operate(doubleArray59);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.IdentityPreconditioner identityPreconditioner65 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.IdentityPreconditioner();
        double[] doubleArray66 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight67 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray66);
        org.apache.commons.math3.optim.nonlinear.vector.Target target68 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray66);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix69 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray66);
        org.apache.commons.math3.linear.RealMatrix realMatrix71 = diagonalMatrix69.power((int) ' ');
        double[] doubleArray72 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight73 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray72);
        org.apache.commons.math3.optim.nonlinear.vector.Target target74 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray72);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix75 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray72);
        double[] doubleArray76 = diagonalMatrix69.operate(doubleArray72);
        double[] doubleArray77 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight78 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray77);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds79 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray76, doubleArray77);
        double[] doubleArray80 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight81 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray80);
        double[] doubleArray82 = identityPreconditioner65.precondition(doubleArray77, doubleArray80);
        double[] doubleArray85 = new double[] { '#', (short) 100 };
        double[] doubleArray86 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight87 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray86);
        org.apache.commons.math3.optim.nonlinear.vector.Target target88 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray86);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix89 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray86);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector90 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray85, doubleArray86);
        double double91 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray80, doubleArray86);
        double[] doubleArray92 = identityPreconditioner0.precondition(doubleArray59, doubleArray80);
        try {
            org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray92);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realMatrix23);
        org.junit.Assert.assertNotNull(realMatrix25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(realMatrix31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(realMatrix46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "DiagonalMatrix{}" + "'", str47.equals("DiagonalMatrix{}"));
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(realMatrix53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(realMatrix71);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 0.0d + "'", double91 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray92);
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test15");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(125, (int) (byte) 100);
        double double3 = blockRealMatrix2.getNorm();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor4 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double5 = defaultRealMatrixPreservingVisitor4.end();
        double double6 = blockRealMatrix2.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor4);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(125, (int) (byte) 100);
        double double10 = blockRealMatrix9.getNorm();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor11 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double12 = defaultRealMatrixPreservingVisitor11.end();
        double double13 = blockRealMatrix9.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor11);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor14 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        defaultRealMatrixPreservingVisitor14.start((int) 'a', (int) (byte) 1, 97, 0, (-1), 125);
        double double22 = blockRealMatrix9.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor14);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix25 = new org.apache.commons.math3.linear.BlockRealMatrix(125, (int) (byte) 100);
        double double26 = blockRealMatrix25.getNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = blockRealMatrix9.add(blockRealMatrix25);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix29 = blockRealMatrix27.scalarAdd(0.45805495157532494d);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix30 = blockRealMatrix2.subtract(blockRealMatrix29);
        org.apache.commons.math3.linear.RealMatrix realMatrix32 = blockRealMatrix30.scalarMultiply((double) 1072693279L);
        boolean boolean34 = blockRealMatrix30.equals((java.lang.Object) (byte) 1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix27);
        org.junit.Assert.assertNotNull(blockRealMatrix29);
        org.junit.Assert.assertNotNull(blockRealMatrix30);
        org.junit.Assert.assertNotNull(realMatrix32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test16");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException(125, (int) (short) 100, 97, (-1));
        int int5 = matrixDimensionMismatchException4.getExpectedColumnDimension();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test17");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
        org.apache.commons.math3.optim.nonlinear.vector.Target target2 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix3 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray0);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = diagonalMatrix3.power((int) ' ');
        boolean boolean6 = diagonalMatrix3.isTransposable();
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = diagonalMatrix3.copy();
        diagonalMatrix3.setEntry((int) (short) 100, 97, (double) 0.0f);
        double double12 = diagonalMatrix3.getFrobeniusNorm();
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test18");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
        org.apache.commons.math3.optim.nonlinear.vector.Target target2 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix3 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray0);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = diagonalMatrix3.power((int) ' ');
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = diagonalMatrix3.power((int) ' ');
        double[] doubleArray8 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight9 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray8);
        org.apache.commons.math3.optim.nonlinear.vector.Target target10 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray8);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix11 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray8);
        org.apache.commons.math3.linear.RealMatrix realMatrix13 = diagonalMatrix11.power((int) ' ');
        double[] doubleArray14 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight15 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray14);
        org.apache.commons.math3.optim.nonlinear.vector.Target target16 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray14);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix17 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray14);
        double[] doubleArray18 = diagonalMatrix11.operate(doubleArray14);
        double[] doubleArray19 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight20 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray19);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds21 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray18, doubleArray19);
        double[] doubleArray22 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight23 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray22);
        org.apache.commons.math3.optim.nonlinear.vector.Target target24 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray22);
        double[] doubleArray25 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray19, doubleArray22);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix27 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray19, true);
        org.apache.commons.math3.linear.RealMatrix realMatrix28 = diagonalMatrix3.preMultiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix27);
        double[] doubleArray29 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight30 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray29);
        org.apache.commons.math3.optim.nonlinear.vector.Target target31 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray29);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix32 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray29);
        org.apache.commons.math3.linear.RealMatrix realMatrix34 = diagonalMatrix32.power((int) ' ');
        double[] doubleArray35 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight36 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray35);
        org.apache.commons.math3.optim.nonlinear.vector.Target target37 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray35);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix38 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray35);
        double[] doubleArray39 = diagonalMatrix32.operate(doubleArray35);
        double[] doubleArray40 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray39);
        double[] doubleArray41 = diagonalMatrix3.operate(doubleArray39);
        int int42 = diagonalMatrix3.getRowDimension();
        boolean boolean44 = org.apache.commons.math3.linear.MatrixUtils.isSymmetric((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix3, (double) 2);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(realMatrix34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test19");
        double[] doubleArray2 = new double[] { '#', (short) 100 };
        double[] doubleArray3 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight4 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray3);
        org.apache.commons.math3.optim.nonlinear.vector.Target target5 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray3);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix6 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray2, doubleArray3);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.mapAdd(0.0d);
        double[] doubleArray10 = arrayRealVector7.toArray();
        boolean boolean11 = arrayRealVector7.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector7, true);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor14 = null;
        try {
            double double17 = arrayRealVector13.walkInOptimizedOrder(realVectorPreservingVisitor14, (int) (short) 1, (-1023));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (-1,023)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test20");
        float float2 = org.apache.commons.math3.util.FastMath.scalb((float) (short) 1, (int) 'a');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.58456325E29f + "'", float2 == 1.58456325E29f);
    }

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test21");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(125, (int) (byte) 100);
        double double3 = blockRealMatrix2.getNorm();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor4 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double5 = defaultRealMatrixPreservingVisitor4.end();
        double double6 = blockRealMatrix2.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor4);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(125, (int) (byte) 100);
        double double10 = blockRealMatrix9.getNorm();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor11 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double12 = defaultRealMatrixPreservingVisitor11.end();
        double double13 = blockRealMatrix9.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor11);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor14 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        defaultRealMatrixPreservingVisitor14.start((int) 'a', (int) (byte) 1, 97, 0, (-1), 125);
        double double22 = blockRealMatrix9.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor14);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix25 = new org.apache.commons.math3.linear.BlockRealMatrix(125, (int) (byte) 100);
        double double26 = blockRealMatrix25.getNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix27 = blockRealMatrix9.add(blockRealMatrix25);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix29 = blockRealMatrix27.scalarAdd(0.45805495157532494d);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix30 = blockRealMatrix2.subtract(blockRealMatrix29);
        double[] doubleArray31 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight32 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray31);
        org.apache.commons.math3.optim.nonlinear.vector.Target target33 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray31);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix34 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray31);
        double double35 = diagonalMatrix34.getFrobeniusNorm();
        boolean boolean36 = diagonalMatrix34.isSquare();
        double[] doubleArray37 = diagonalMatrix34.getDataRef();
        double[] doubleArray38 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight39 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray38);
        org.apache.commons.math3.optim.nonlinear.vector.Target target40 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray38);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix41 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray38);
        org.apache.commons.math3.linear.RealMatrix realMatrix43 = diagonalMatrix41.power((int) ' ');
        double[] doubleArray44 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight45 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray44);
        org.apache.commons.math3.optim.nonlinear.vector.Target target46 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray44);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix47 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray44);
        double[] doubleArray48 = diagonalMatrix41.operate(doubleArray44);
        double[] doubleArray49 = diagonalMatrix34.operate(doubleArray44);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix50 = blockRealMatrix2.multiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix34);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 100 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix27);
        org.junit.Assert.assertNotNull(blockRealMatrix29);
        org.junit.Assert.assertNotNull(blockRealMatrix30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(realMatrix43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray49);
    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test22");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(125, (int) (byte) 100);
        double double3 = blockRealMatrix2.getNorm();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor4 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double5 = defaultRealMatrixPreservingVisitor4.end();
        double double6 = blockRealMatrix2.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor4);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor7 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        defaultRealMatrixPreservingVisitor7.start((int) 'a', (int) (byte) 1, 97, 0, (-1), 125);
        double double15 = blockRealMatrix2.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor7);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = new org.apache.commons.math3.linear.BlockRealMatrix(125, (int) (byte) 100);
        double double19 = blockRealMatrix18.getNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix20 = blockRealMatrix2.add(blockRealMatrix18);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix22 = blockRealMatrix20.scalarAdd(0.45805495157532494d);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix25 = new org.apache.commons.math3.linear.BlockRealMatrix(125, (int) (byte) 100);
        double double26 = blockRealMatrix25.getNorm();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor27 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double28 = defaultRealMatrixPreservingVisitor27.end();
        double double29 = blockRealMatrix25.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor27);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix32 = new org.apache.commons.math3.linear.BlockRealMatrix(125, (int) (byte) 100);
        double double33 = blockRealMatrix32.getNorm();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor34 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double35 = defaultRealMatrixPreservingVisitor34.end();
        double double36 = blockRealMatrix32.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor34);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor37 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        defaultRealMatrixPreservingVisitor37.start((int) 'a', (int) (byte) 1, 97, 0, (-1), 125);
        double double45 = blockRealMatrix32.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor37);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix48 = new org.apache.commons.math3.linear.BlockRealMatrix(125, (int) (byte) 100);
        double double49 = blockRealMatrix48.getNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix50 = blockRealMatrix32.add(blockRealMatrix48);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix52 = blockRealMatrix50.scalarAdd(0.45805495157532494d);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix53 = blockRealMatrix25.subtract(blockRealMatrix52);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix54 = blockRealMatrix22.add(blockRealMatrix25);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix57 = new org.apache.commons.math3.linear.BlockRealMatrix(125, (int) (byte) 100);
        double double58 = blockRealMatrix57.getNorm();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor59 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double60 = defaultRealMatrixPreservingVisitor59.end();
        double double61 = blockRealMatrix57.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor59);
        try {
            double double66 = blockRealMatrix25.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor59, (-1), 0, 0, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix20);
        org.junit.Assert.assertNotNull(blockRealMatrix22);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix50);
        org.junit.Assert.assertNotNull(blockRealMatrix52);
        org.junit.Assert.assertNotNull(blockRealMatrix53);
        org.junit.Assert.assertNotNull(blockRealMatrix54);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test23");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Integer[] intArray7 = new java.lang.Integer[] { 36, 125, 100, 10, 100 };
        java.lang.Integer[] intArray9 = new java.lang.Integer[] { 36 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException10 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray7, intArray9);
        java.lang.Integer[] intArray16 = new java.lang.Integer[] { 36, 125, 100, 10, 100 };
        java.lang.Integer[] intArray18 = new java.lang.Integer[] { 36 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException19 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray16, intArray18);
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException20 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray7, intArray18);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException21 = new org.apache.commons.math3.exception.NotFiniteNumberException(localizable0, (java.lang.Number) 3.7663540285E10d, (java.lang.Object[]) intArray7);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray18);
    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test24");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
        org.apache.commons.math3.optim.nonlinear.vector.Target target2 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix3 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray0);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = diagonalMatrix3.power((int) ' ');
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = diagonalMatrix3.power((int) ' ');
        double[] doubleArray8 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight9 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray8);
        org.apache.commons.math3.optim.nonlinear.vector.Target target10 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray8);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix11 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray8);
        org.apache.commons.math3.linear.RealMatrix realMatrix13 = diagonalMatrix11.power((int) ' ');
        double[] doubleArray14 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight15 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray14);
        org.apache.commons.math3.optim.nonlinear.vector.Target target16 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray14);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix17 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray14);
        double[] doubleArray18 = diagonalMatrix11.operate(doubleArray14);
        double[] doubleArray19 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight20 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray19);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds21 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray18, doubleArray19);
        double[] doubleArray22 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight23 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray22);
        org.apache.commons.math3.optim.nonlinear.vector.Target target24 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray22);
        double[] doubleArray25 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray19, doubleArray22);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix27 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray19, true);
        org.apache.commons.math3.linear.RealMatrix realMatrix28 = diagonalMatrix3.preMultiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix27);
        org.apache.commons.math3.linear.RealMatrix realMatrix30 = diagonalMatrix27.power((int) (byte) 100);
        double double31 = diagonalMatrix27.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix34 = new org.apache.commons.math3.linear.BlockRealMatrix(125, (int) (byte) 100);
        double double35 = blockRealMatrix34.getNorm();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor36 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double37 = defaultRealMatrixPreservingVisitor36.end();
        double double38 = blockRealMatrix34.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor36);
        try {
            double double43 = diagonalMatrix27.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor36, 1076101120, (-1023), 0, 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1,076,101,120)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test25");
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer();
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair> pointVectorValuePairConvergenceChecker1 = levenbergMarquardtOptimizer0.getConvergenceChecker();
        org.junit.Assert.assertNull(pointVectorValuePairConvergenceChecker1);
    }

    @Test
    public void test26() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test26");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(125, (int) (byte) 100);
        double double3 = blockRealMatrix2.getNorm();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor4 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double5 = defaultRealMatrixPreservingVisitor4.end();
        double double6 = blockRealMatrix2.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor4);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor7 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        defaultRealMatrixPreservingVisitor7.start((int) 'a', (int) (byte) 1, 97, 0, (-1), 125);
        double double15 = blockRealMatrix2.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor7);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = new org.apache.commons.math3.linear.BlockRealMatrix(125, (int) (byte) 100);
        double double19 = blockRealMatrix18.getNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix20 = blockRealMatrix2.add(blockRealMatrix18);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix22 = blockRealMatrix20.scalarAdd(0.45805495157532494d);
        org.apache.commons.math3.linear.RealMatrix realMatrix24 = blockRealMatrix20.scalarMultiply((double) 52);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix20);
        org.junit.Assert.assertNotNull(blockRealMatrix22);
        org.junit.Assert.assertNotNull(realMatrix24);
    }

    @Test
    public void test27() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test27");
        double[] doubleArray1 = new double[] { (short) 1 };
        double[] doubleArray4 = new double[] { '#', (short) 100 };
        double[] doubleArray5 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight6 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray5);
        org.apache.commons.math3.optim.nonlinear.vector.Target target7 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray5);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix8 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4, doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector11 = arrayRealVector9.mapAdd(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1, arrayRealVector9);
        double double13 = arrayRealVector12.getL1Norm();
        double[] doubleArray17 = new double[] { (short) 1 };
        double[] doubleArray20 = new double[] { '#', (short) 100 };
        double[] doubleArray21 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight22 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray21);
        org.apache.commons.math3.optim.nonlinear.vector.Target target23 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray21);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix24 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray21);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray20, doubleArray21);
        org.apache.commons.math3.linear.RealVector realVector27 = arrayRealVector25.mapAdd(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray17, arrayRealVector25);
        org.apache.commons.math3.linear.RealVector realVector30 = arrayRealVector28.mapAdd((double) (byte) 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = arrayRealVector12.combine((double) 100L, (double) (byte) 1, (org.apache.commons.math3.linear.RealVector) arrayRealVector28);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector12, false);
        boolean boolean34 = arrayRealVector33.isInfinite();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 136.0d + "'", double13 == 136.0d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(realVector27);
        org.junit.Assert.assertNotNull(realVector30);
        org.junit.Assert.assertNotNull(arrayRealVector31);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test28() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test28");
        double[] doubleArray0 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray0, 2147483647, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test29");
        org.apache.commons.math3.util.Incrementor incrementor1 = new org.apache.commons.math3.util.Incrementor(0);
        int int2 = incrementor1.getMaximalCount();
        int int3 = incrementor1.getCount();
        incrementor1.resetCount();
        int int5 = incrementor1.getMaximalCount();
        incrementor1.setMaximalCount((int) (byte) 1);
        incrementor1.setMaximalCount(10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test30() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test30");
        java.lang.Number number0 = null;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(number0, (java.lang.Number) 0.8414709848078965d, (int) (byte) 0);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection4 = nonMonotonicSequenceException3.getDirection();
        java.lang.Number number5 = nonMonotonicSequenceException3.getPrevious();
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection4.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.8414709848078965d + "'", number5.equals(0.8414709848078965d));
    }

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test31");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(125, (int) (byte) 100);
        double double3 = blockRealMatrix2.getNorm();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor4 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double5 = defaultRealMatrixPreservingVisitor4.end();
        double double6 = blockRealMatrix2.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor4);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor7 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        defaultRealMatrixPreservingVisitor7.start((int) 'a', (int) (byte) 1, 97, 0, (-1), 125);
        double double15 = blockRealMatrix2.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor7);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = new org.apache.commons.math3.linear.BlockRealMatrix(125, (int) (byte) 100);
        double double19 = blockRealMatrix18.getNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix20 = blockRealMatrix2.add(blockRealMatrix18);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix22 = blockRealMatrix20.scalarAdd(0.45805495157532494d);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix25 = new org.apache.commons.math3.linear.BlockRealMatrix(125, (int) (byte) 100);
        double double26 = blockRealMatrix25.getNorm();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor27 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double28 = defaultRealMatrixPreservingVisitor27.end();
        double double29 = blockRealMatrix25.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor27);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix32 = new org.apache.commons.math3.linear.BlockRealMatrix(125, (int) (byte) 100);
        double double33 = blockRealMatrix32.getNorm();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor34 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double35 = defaultRealMatrixPreservingVisitor34.end();
        double double36 = blockRealMatrix32.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor34);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor37 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        defaultRealMatrixPreservingVisitor37.start((int) 'a', (int) (byte) 1, 97, 0, (-1), 125);
        double double45 = blockRealMatrix32.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor37);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix48 = new org.apache.commons.math3.linear.BlockRealMatrix(125, (int) (byte) 100);
        double double49 = blockRealMatrix48.getNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix50 = blockRealMatrix32.add(blockRealMatrix48);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix52 = blockRealMatrix50.scalarAdd(0.45805495157532494d);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix53 = blockRealMatrix25.subtract(blockRealMatrix52);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix54 = blockRealMatrix22.add(blockRealMatrix25);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix55 = blockRealMatrix54.transpose();
        try {
            double[] doubleArray57 = blockRealMatrix54.getColumn((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix20);
        org.junit.Assert.assertNotNull(blockRealMatrix22);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix50);
        org.junit.Assert.assertNotNull(blockRealMatrix52);
        org.junit.Assert.assertNotNull(blockRealMatrix53);
        org.junit.Assert.assertNotNull(blockRealMatrix54);
        org.junit.Assert.assertNotNull(blockRealMatrix55);
    }

    @Test
    public void test32() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test32");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
        org.apache.commons.math3.optim.nonlinear.vector.Target target2 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix3 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray0);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = diagonalMatrix3.power((int) ' ');
        double[] doubleArray6 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight7 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray6);
        org.apache.commons.math3.optim.nonlinear.vector.Target target8 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray6);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix9 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6);
        double[] doubleArray10 = diagonalMatrix3.operate(doubleArray6);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight12 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray11);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds13 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray10, doubleArray11);
        double[] doubleArray14 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight15 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray14);
        org.apache.commons.math3.optim.nonlinear.vector.Target target16 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray14);
        double[] doubleArray17 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray11, doubleArray14);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix19 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray11, true);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor20 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double21 = defaultRealMatrixPreservingVisitor20.end();
        double double22 = diagonalMatrix19.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor20);
        try {
            org.apache.commons.math3.linear.RealVector realVector24 = diagonalMatrix19.getRowVector(1076101120);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1,076,101,120)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
    }

    @Test
    public void test33() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test33");
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver2 = new org.apache.commons.math3.analysis.solvers.BrentSolver(9.677880210178613E53d, 0.7071067811865476d);
    }

    @Test
    public void test34() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test34");
        java.util.Locale locale0 = null;
        try {
            java.text.NumberFormat numberFormat1 = org.apache.commons.math3.util.CompositeFormat.getDefaultNumberFormat(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test35() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test35");
        double[] doubleArray1 = new double[] { (short) 1 };
        double[] doubleArray4 = new double[] { '#', (short) 100 };
        double[] doubleArray5 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight6 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray5);
        org.apache.commons.math3.optim.nonlinear.vector.Target target7 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray5);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix8 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4, doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector11 = arrayRealVector9.mapAdd(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1, arrayRealVector9);
        double double13 = arrayRealVector12.getL1Norm();
        double[] doubleArray17 = new double[] { (short) 1 };
        double[] doubleArray20 = new double[] { '#', (short) 100 };
        double[] doubleArray21 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight22 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray21);
        org.apache.commons.math3.optim.nonlinear.vector.Target target23 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray21);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix24 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray21);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray20, doubleArray21);
        org.apache.commons.math3.linear.RealVector realVector27 = arrayRealVector25.mapAdd(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray17, arrayRealVector25);
        org.apache.commons.math3.linear.RealVector realVector30 = arrayRealVector28.mapAdd((double) (byte) 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = arrayRealVector12.combine((double) 100L, (double) (byte) 1, (org.apache.commons.math3.linear.RealVector) arrayRealVector28);
        boolean boolean32 = arrayRealVector28.isNaN();
        int int33 = arrayRealVector28.getMinIndex();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 136.0d + "'", double13 == 136.0d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(realVector27);
        org.junit.Assert.assertNotNull(realVector30);
        org.junit.Assert.assertNotNull(arrayRealVector31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
    }

    @Test
    public void test36() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test36");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula0 = org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES;
        org.apache.commons.math3.random.MersenneTwister mersenneTwister7 = new org.apache.commons.math3.random.MersenneTwister((int) '#');
        double double8 = mersenneTwister7.nextDouble();
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker12 = new org.apache.commons.math3.optim.SimpleValueChecker((double) (byte) 1, (double) (short) 100);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer13 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer((int) '#', (double) (short) 1, true, 36, 10, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister7, true, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker12);
        double double14 = simpleValueChecker12.getAbsoluteThreshold();
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver15 = new org.apache.commons.math3.analysis.solvers.BrentSolver();
        double double16 = brentSolver15.getRelativeAccuracy();
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer17 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker12, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver15);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula18 = org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES;
        org.apache.commons.math3.random.MersenneTwister mersenneTwister25 = new org.apache.commons.math3.random.MersenneTwister((int) '#');
        double double26 = mersenneTwister25.nextDouble();
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker30 = new org.apache.commons.math3.optim.SimpleValueChecker((double) (byte) 1, (double) (short) 100);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer31 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer((int) '#', (double) (short) 1, true, 36, 10, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister25, true, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker30);
        double double32 = simpleValueChecker30.getAbsoluteThreshold();
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver33 = new org.apache.commons.math3.analysis.solvers.BrentSolver();
        double double34 = brentSolver33.getRelativeAccuracy();
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer35 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula18, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker30, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver33);
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver39 = new org.apache.commons.math3.analysis.solvers.BrentSolver(1.0E-14d, (double) (byte) 0, 0.7853981633974483d);
        org.apache.commons.math3.analysis.function.Sinc sinc41 = new org.apache.commons.math3.analysis.function.Sinc();
        double double44 = brentSolver39.solve((int) (short) 100, (org.apache.commons.math3.analysis.UnivariateFunction) sinc41, 0.0d, 3.7663540285E10d);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer45 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker30, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver39);
        org.apache.commons.math3.random.MersenneTwister mersenneTwister52 = new org.apache.commons.math3.random.MersenneTwister((int) '#');
        double double53 = mersenneTwister52.nextDouble();
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker57 = new org.apache.commons.math3.optim.SimpleValueChecker((double) (byte) 1, (double) (short) 100);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer58 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer((int) '#', (double) (short) 1, true, 36, 10, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister52, true, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker57);
        double double59 = simpleValueChecker57.getAbsoluteThreshold();
        double[] doubleArray61 = null;
        org.apache.commons.math3.optim.PointValuePair pointValuePair63 = new org.apache.commons.math3.optim.PointValuePair(doubleArray61, 0.0d);
        double[] doubleArray64 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight65 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray64);
        org.apache.commons.math3.optim.nonlinear.vector.Target target66 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray64);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix67 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray64);
        org.apache.commons.math3.optim.PointValuePair pointValuePair70 = new org.apache.commons.math3.optim.PointValuePair(doubleArray64, (double) 10, false);
        boolean boolean71 = simpleValueChecker57.converged((int) '4', pointValuePair63, pointValuePair70);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer72 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker57);
        org.junit.Assert.assertTrue("'" + formula0 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES + "'", formula0.equals(org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.45805495157532494d + "'", double8 == 0.45805495157532494d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 100.0d + "'", double14 == 100.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0E-14d + "'", double16 == 1.0E-14d);
        org.junit.Assert.assertTrue("'" + formula18 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES + "'", formula18.equals(org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES));
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.45805495157532494d + "'", double26 == 0.45805495157532494d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 100.0d + "'", double32 == 100.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 1.0E-14d + "'", double34 == 1.0E-14d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 1.88317701425E10d + "'", double44 == 1.88317701425E10d);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.45805495157532494d + "'", double53 == 0.45805495157532494d);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 100.0d + "'", double59 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
    }

    @Test
    public void test37() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test37");
        double[] doubleArray1 = new double[] { (short) 1 };
        double[] doubleArray4 = new double[] { '#', (short) 100 };
        double[] doubleArray5 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight6 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray5);
        org.apache.commons.math3.optim.nonlinear.vector.Target target7 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray5);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix8 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4, doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector11 = arrayRealVector9.mapAdd(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1, arrayRealVector9);
        double[] doubleArray13 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight14 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray13);
        org.apache.commons.math3.optim.nonlinear.vector.Target target15 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray13);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix16 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray13);
        org.apache.commons.math3.linear.RealMatrix realMatrix18 = diagonalMatrix16.power((int) ' ');
        double[] doubleArray19 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight20 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray19);
        org.apache.commons.math3.optim.nonlinear.vector.Target target21 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray19);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix22 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray19);
        double[] doubleArray23 = diagonalMatrix16.operate(doubleArray19);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray23);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector12, arrayRealVector24);
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor26 = null;
        try {
            double double29 = arrayRealVector25.walkInOptimizedOrder(realVectorChangingVisitor26, 0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realMatrix18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray23);
    }

    @Test
    public void test38() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test38");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(125, (int) (byte) 100);
        double double3 = blockRealMatrix2.getNorm();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor4 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double5 = defaultRealMatrixPreservingVisitor4.end();
        double double6 = blockRealMatrix2.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor4);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor7 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        defaultRealMatrixPreservingVisitor7.start((int) 'a', (int) (byte) 1, 97, 0, (-1), 125);
        double double15 = blockRealMatrix2.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor7);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = new org.apache.commons.math3.linear.BlockRealMatrix(125, (int) (byte) 100);
        double double19 = blockRealMatrix18.getNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix20 = blockRealMatrix2.add(blockRealMatrix18);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix22 = blockRealMatrix20.scalarAdd(0.45805495157532494d);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix25 = new org.apache.commons.math3.linear.BlockRealMatrix(125, (int) (byte) 100);
        double double26 = blockRealMatrix25.getNorm();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor27 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double28 = defaultRealMatrixPreservingVisitor27.end();
        double double29 = blockRealMatrix25.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor27);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix32 = new org.apache.commons.math3.linear.BlockRealMatrix(125, (int) (byte) 100);
        double double33 = blockRealMatrix32.getNorm();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor34 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double35 = defaultRealMatrixPreservingVisitor34.end();
        double double36 = blockRealMatrix32.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor34);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor37 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        defaultRealMatrixPreservingVisitor37.start((int) 'a', (int) (byte) 1, 97, 0, (-1), 125);
        double double45 = blockRealMatrix32.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor37);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix48 = new org.apache.commons.math3.linear.BlockRealMatrix(125, (int) (byte) 100);
        double double49 = blockRealMatrix48.getNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix50 = blockRealMatrix32.add(blockRealMatrix48);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix52 = blockRealMatrix50.scalarAdd(0.45805495157532494d);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix53 = blockRealMatrix25.subtract(blockRealMatrix52);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix54 = blockRealMatrix22.add(blockRealMatrix25);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix55 = blockRealMatrix54.transpose();
        double[][] doubleArray56 = blockRealMatrix55.getData();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix20);
        org.junit.Assert.assertNotNull(blockRealMatrix22);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix50);
        org.junit.Assert.assertNotNull(blockRealMatrix52);
        org.junit.Assert.assertNotNull(blockRealMatrix53);
        org.junit.Assert.assertNotNull(blockRealMatrix54);
        org.junit.Assert.assertNotNull(blockRealMatrix55);
        org.junit.Assert.assertNotNull(doubleArray56);
    }

    @Test
    public void test39() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test39");
        org.apache.commons.math3.optim.SimpleVectorValueChecker simpleVectorValueChecker3 = new org.apache.commons.math3.optim.SimpleVectorValueChecker((double) (byte) 0, (double) 0L, 125);
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer gaussNewtonOptimizer4 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer((org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair>) simpleVectorValueChecker3);
        double[] doubleArray5 = gaussNewtonOptimizer4.getUpperBound();
        org.junit.Assert.assertNull(doubleArray5);
    }

    @Test
    public void test40() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test40");
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver2 = new org.apache.commons.math3.analysis.solvers.BrentSolver((double) (-1023), (double) 1.09843795E12f);
        org.apache.commons.math3.analysis.function.Sinc sinc4 = new org.apache.commons.math3.analysis.function.Sinc();
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction5 = sinc4.derivative();
        try {
            double double7 = brentSolver2.solve((int) (short) 1, univariateFunction5, 1.1752011936438014d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.TooManyEvaluationsException; message: illegal state: maximal count (1) exceeded: evaluations");
        } catch (org.apache.commons.math3.exception.TooManyEvaluationsException e) {
        }
        org.junit.Assert.assertNotNull(univariateFunction5);
    }

    @Test
    public void test41() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test41");
        java.lang.Number number0 = null;
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException2 = new org.apache.commons.math3.exception.NotFiniteNumberException(number0, objArray1);
    }

    @Test
    public void test42() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test42");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math3.random.MersenneTwister((int) '#');
        double double7 = mersenneTwister6.nextDouble();
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker11 = new org.apache.commons.math3.optim.SimpleValueChecker((double) (byte) 1, (double) (short) 100);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer12 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer((int) '#', (double) (short) 1, true, 36, 10, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister6, true, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker11);
        double double13 = simpleValueChecker11.getAbsoluteThreshold();
        double double14 = simpleValueChecker11.getRelativeThreshold();
        double double15 = simpleValueChecker11.getRelativeThreshold();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.45805495157532494d + "'", double7 == 0.45805495157532494d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 100.0d + "'", double13 == 100.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
    }

    @Test
    public void test43() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test43");
        double[] doubleArray2 = new double[] { '#', (short) 100 };
        double[] doubleArray3 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight4 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray3);
        org.apache.commons.math3.optim.nonlinear.vector.Target target5 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray3);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix6 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray2, doubleArray3);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.mapAdd(0.0d);
        double[] doubleArray10 = arrayRealVector7.toArray();
        boolean boolean11 = arrayRealVector7.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector7, true);
        arrayRealVector7.setEntry(1, (double) (-1L));
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor17 = null;
        try {
            double double20 = arrayRealVector7.walkInOptimizedOrder(realVectorPreservingVisitor17, 2147483647, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (2,147,483,647)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test44() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test44");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals(1.09843795E12f, (float) (-1), 0.0f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test45() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test45");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN(97.0d, (double) 100.0f, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test46() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test46");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
        org.apache.commons.math3.optim.nonlinear.vector.Target target2 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix3 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray0);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = diagonalMatrix3.power((int) ' ');
        double[] doubleArray6 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight7 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray6);
        org.apache.commons.math3.optim.nonlinear.vector.Target target8 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray6);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix9 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6);
        double[] doubleArray10 = diagonalMatrix3.operate(doubleArray6);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight12 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray11);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds13 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray10, doubleArray11);
        double[] doubleArray14 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight15 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray14);
        org.apache.commons.math3.optim.nonlinear.vector.Target target16 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray14);
        double[] doubleArray17 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray11, doubleArray14);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix19 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray11, true);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor20 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double21 = defaultRealMatrixPreservingVisitor20.end();
        double double22 = diagonalMatrix19.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor20);
        double[] doubleArray23 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight24 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray23);
        org.apache.commons.math3.optim.nonlinear.vector.Target target25 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray23);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray23);
        org.apache.commons.math3.linear.RealMatrix realMatrix28 = diagonalMatrix26.power((int) ' ');
        boolean boolean29 = diagonalMatrix26.isTransposable();
        org.apache.commons.math3.linear.RealMatrix realMatrix30 = diagonalMatrix26.copy();
        diagonalMatrix26.setEntry((int) (short) 100, 97, (double) 0.0f);
        org.apache.commons.math3.linear.RealMatrix realMatrix35 = diagonalMatrix26.copy();
        double[] doubleArray36 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight37 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray36);
        org.apache.commons.math3.optim.nonlinear.vector.Target target38 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray36);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix39 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray36);
        org.apache.commons.math3.linear.RealMatrix realMatrix41 = diagonalMatrix39.power((int) ' ');
        double[] doubleArray42 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight43 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray42);
        org.apache.commons.math3.optim.nonlinear.vector.Target target44 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray42);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix45 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray42);
        double[] doubleArray46 = diagonalMatrix39.operate(doubleArray42);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix47 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray42);
        org.apache.commons.math3.linear.RealMatrix realMatrix48 = diagonalMatrix26.multiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix47);
        org.apache.commons.math3.linear.RealMatrix realMatrix49 = diagonalMatrix19.multiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix47);
        double[] doubleArray51 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight52 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray51);
        org.apache.commons.math3.optim.nonlinear.vector.Target target53 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray51);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix54 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray51);
        org.apache.commons.math3.linear.RealMatrix realMatrix56 = diagonalMatrix54.power((int) ' ');
        double[] doubleArray57 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight58 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray57);
        org.apache.commons.math3.optim.nonlinear.vector.Target target59 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray57);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix60 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray57);
        double[] doubleArray61 = diagonalMatrix54.operate(doubleArray57);
        org.apache.commons.math3.util.MathUtils.checkFinite(doubleArray57);
        double[] doubleArray63 = null;
        boolean boolean64 = org.apache.commons.math3.util.MathArrays.equals(doubleArray57, doubleArray63);
        double[] doubleArray66 = new double[] { (short) 1 };
        double[] doubleArray69 = new double[] { '#', (short) 100 };
        double[] doubleArray70 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight71 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray70);
        org.apache.commons.math3.optim.nonlinear.vector.Target target72 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray70);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix73 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray70);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector74 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray69, doubleArray70);
        org.apache.commons.math3.linear.RealVector realVector76 = arrayRealVector74.mapAdd(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector77 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray66, arrayRealVector74);
        org.apache.commons.math3.optim.PointValuePair pointValuePair79 = new org.apache.commons.math3.optim.PointValuePair(doubleArray66, (double) 10);
        double[] doubleArray80 = pointValuePair79.getFirst();
        org.apache.commons.math3.optim.InitialGuess initialGuess81 = new org.apache.commons.math3.optim.InitialGuess(doubleArray80);
        double[] doubleArray82 = initialGuess81.getInitialGuess();
        org.apache.commons.math3.optim.SimpleBounds simpleBounds83 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray57, doubleArray82);
        try {
            diagonalMatrix19.setColumn(0, doubleArray57);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (0)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertNotNull(realMatrix35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(realMatrix41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(realMatrix48);
        org.junit.Assert.assertNotNull(realMatrix49);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(realMatrix56);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(realVector76);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertNotNull(doubleArray82);
    }

    @Test
    public void test47() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test47");
        double double1 = org.apache.commons.math3.util.FastMath.cosh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test48() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test48");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.IdentityPreconditioner identityPreconditioner0 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.IdentityPreconditioner();
        double[] doubleArray1 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight2 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray1);
        org.apache.commons.math3.optim.nonlinear.vector.Target target3 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray1);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix4 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray1);
        org.apache.commons.math3.linear.RealMatrix realMatrix6 = diagonalMatrix4.power((int) ' ');
        double[] doubleArray7 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight8 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray7);
        org.apache.commons.math3.optim.nonlinear.vector.Target target9 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray7);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix10 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray7);
        double[] doubleArray11 = diagonalMatrix4.operate(doubleArray7);
        double[] doubleArray12 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight13 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray12);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds14 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray11, doubleArray12);
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight16 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray15);
        double[] doubleArray17 = identityPreconditioner0.precondition(doubleArray12, doubleArray15);
        double[] doubleArray20 = new double[] { '#', (short) 100 };
        double[] doubleArray21 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight22 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray21);
        org.apache.commons.math3.optim.nonlinear.vector.Target target23 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray21);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix24 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray21);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray20, doubleArray21);
        double double26 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray15, doubleArray21);
        org.apache.commons.math3.linear.RealVector realVector27 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray15);
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15);
        try {
            org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray15);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(realVector27);
        org.junit.Assert.assertNotNull(doubleArray28);
    }

    @Test
    public void test49() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test49");
        double[] doubleArray1 = new double[] { (short) 1 };
        double[] doubleArray4 = new double[] { '#', (short) 100 };
        double[] doubleArray5 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight6 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray5);
        org.apache.commons.math3.optim.nonlinear.vector.Target target7 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray5);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix8 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4, doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector11 = arrayRealVector9.mapAdd(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1, arrayRealVector9);
        double[] doubleArray13 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight14 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray13);
        org.apache.commons.math3.optim.nonlinear.vector.Target target15 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray13);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix16 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray13);
        org.apache.commons.math3.linear.RealMatrix realMatrix18 = diagonalMatrix16.power((int) ' ');
        double[] doubleArray19 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight20 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray19);
        org.apache.commons.math3.optim.nonlinear.vector.Target target21 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray19);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix22 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray19);
        double[] doubleArray23 = diagonalMatrix16.operate(doubleArray19);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray23);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector12, arrayRealVector24);
        double[] doubleArray27 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight28 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray27);
        org.apache.commons.math3.optim.nonlinear.vector.Target target29 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray27);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix30 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray27);
        org.apache.commons.math3.linear.RealMatrix realMatrix32 = diagonalMatrix30.power((int) ' ');
        double[] doubleArray33 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight34 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray33);
        org.apache.commons.math3.optim.nonlinear.vector.Target target35 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray33);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix36 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray33);
        double[] doubleArray37 = diagonalMatrix30.operate(doubleArray33);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix38 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray33);
        arrayRealVector12.setSubVector(0, doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realMatrix18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(realMatrix32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray37);
    }

    @Test
    public void test50() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test50");
        double[] doubleArray0 = null;
        try {
            org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test51() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test51");
        double[] doubleArray1 = new double[] { 10 };
        int int2 = org.apache.commons.math3.util.MathUtils.hash(doubleArray1);
        double[] doubleArray3 = null;
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair4 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray1, doubleArray3);
        double[] doubleArray5 = pointVectorValuePair4.getPointRef();
        double[] doubleArray7 = new double[] { (short) 1 };
        double[] doubleArray10 = new double[] { '#', (short) 100 };
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight12 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray11);
        org.apache.commons.math3.optim.nonlinear.vector.Target target13 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray11);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix14 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray11);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray10, doubleArray11);
        org.apache.commons.math3.linear.RealVector realVector17 = arrayRealVector15.mapAdd(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray7, arrayRealVector15);
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) 10);
        double[] doubleArray21 = pointValuePair20.getFirst();
        double[] doubleArray22 = pointValuePair20.getPointRef();
        double double23 = org.apache.commons.math3.util.MathArrays.distance(doubleArray5, doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1076101151 + "'", int2 == 1076101151);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 9.0d + "'", double23 == 9.0d);
    }

    @Test
    public void test52() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test52");
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver1 = new org.apache.commons.math3.analysis.solvers.BrentSolver((double) 0L);
        org.apache.commons.math3.analysis.function.Sinc sinc3 = new org.apache.commons.math3.analysis.function.Sinc();
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction4 = sinc3.derivative();
        try {
            double double8 = brentSolver1.solve(0, (org.apache.commons.math3.analysis.UnivariateFunction) sinc3, 3.141592653589793d, 9.999999999999998d, (double) 52);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [52, 10]");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(univariateFunction4);
    }

    @Test
    public void test53() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test53");
        org.apache.commons.math3.optim.SimpleVectorValueChecker simpleVectorValueChecker5 = new org.apache.commons.math3.optim.SimpleVectorValueChecker((double) '4', (double) 10L, 125);
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer gaussNewtonOptimizer6 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer((org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair>) simpleVectorValueChecker5);
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer11 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer(1.0726932790000005E9d, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair>) simpleVectorValueChecker5, (-307.6526555685888d), (-1020.5751316061705d), 0.0d, (double) 97);
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer gaussNewtonOptimizer12 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer(false, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair>) simpleVectorValueChecker5);
    }

    @Test
    public void test54() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test54");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(125, (int) (byte) 100);
        double double3 = blockRealMatrix2.getNorm();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor4 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double5 = defaultRealMatrixPreservingVisitor4.end();
        double double6 = blockRealMatrix2.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor4);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor7 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        defaultRealMatrixPreservingVisitor7.start((int) 'a', (int) (byte) 1, 97, 0, (-1), 125);
        double double15 = blockRealMatrix2.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor7);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = new org.apache.commons.math3.linear.BlockRealMatrix(125, (int) (byte) 100);
        double double19 = blockRealMatrix18.getNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix20 = blockRealMatrix2.add(blockRealMatrix18);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix22 = blockRealMatrix20.scalarAdd(0.45805495157532494d);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix25 = new org.apache.commons.math3.linear.BlockRealMatrix(125, (int) (byte) 100);
        double double26 = blockRealMatrix25.getNorm();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor27 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double28 = defaultRealMatrixPreservingVisitor27.end();
        double double29 = blockRealMatrix25.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor27);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix32 = new org.apache.commons.math3.linear.BlockRealMatrix(125, (int) (byte) 100);
        double double33 = blockRealMatrix32.getNorm();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor34 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double35 = defaultRealMatrixPreservingVisitor34.end();
        double double36 = blockRealMatrix32.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor34);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor37 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        defaultRealMatrixPreservingVisitor37.start((int) 'a', (int) (byte) 1, 97, 0, (-1), 125);
        double double45 = blockRealMatrix32.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor37);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix48 = new org.apache.commons.math3.linear.BlockRealMatrix(125, (int) (byte) 100);
        double double49 = blockRealMatrix48.getNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix50 = blockRealMatrix32.add(blockRealMatrix48);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix52 = blockRealMatrix50.scalarAdd(0.45805495157532494d);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix53 = blockRealMatrix25.subtract(blockRealMatrix52);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix54 = blockRealMatrix22.add(blockRealMatrix25);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix55 = blockRealMatrix54.transpose();
        boolean boolean56 = blockRealMatrix55.isSquare();
        double[] doubleArray58 = blockRealMatrix55.getColumn(0);
        double[] doubleArray59 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight60 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray59);
        org.apache.commons.math3.optim.nonlinear.vector.Target target61 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray59);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix62 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray59);
        org.apache.commons.math3.linear.RealMatrix realMatrix64 = diagonalMatrix62.power((int) ' ');
        double[] doubleArray65 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight66 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray65);
        org.apache.commons.math3.optim.nonlinear.vector.Target target67 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray65);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix68 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray65);
        org.apache.commons.math3.linear.RealMatrix realMatrix70 = diagonalMatrix68.power((int) ' ');
        double[] doubleArray71 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight72 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray71);
        org.apache.commons.math3.optim.nonlinear.vector.Target target73 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray71);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix74 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray71);
        double[] doubleArray75 = diagonalMatrix68.operate(doubleArray71);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector76 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray75);
        double[] doubleArray77 = diagonalMatrix62.preMultiply(doubleArray75);
        try {
            double[] doubleArray78 = blockRealMatrix55.preMultiply(doubleArray75);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 100");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix20);
        org.junit.Assert.assertNotNull(blockRealMatrix22);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix50);
        org.junit.Assert.assertNotNull(blockRealMatrix52);
        org.junit.Assert.assertNotNull(blockRealMatrix53);
        org.junit.Assert.assertNotNull(blockRealMatrix54);
        org.junit.Assert.assertNotNull(blockRealMatrix55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(realMatrix64);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(realMatrix70);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray77);
    }

    @Test
    public void test55() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test55");
        double[] doubleArray3 = new double[] { '#', (byte) 100, (short) 100 };
        double[] doubleArray7 = new double[] { '#', (byte) 100, (short) 100 };
        double[] doubleArray11 = new double[] { '#', (byte) 100, (short) 100 };
        double[] doubleArray15 = new double[] { '#', (byte) 100, (short) 100 };
        double[][] doubleArray16 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15 };
        double[][] doubleArray17 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray16);
        double[][] doubleArray18 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray17);
        org.apache.commons.math3.linear.RealMatrix realMatrix19 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray18, false);
        double[][] doubleArray22 = array2DRowRealMatrix21.getData();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor23 = null;
        try {
            double double28 = array2DRowRealMatrix21.walkInColumnOrder(realMatrixChangingVisitor23, (int) '#', 97, 0, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realMatrix19);
        org.junit.Assert.assertNotNull(doubleArray22);
    }

    @Test
    public void test56() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test56");
        double[] doubleArray2 = new double[] { '#', (short) 100 };
        double[] doubleArray3 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight4 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray3);
        org.apache.commons.math3.optim.nonlinear.vector.Target target5 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray3);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix6 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray2, doubleArray3);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.mapAdd(0.0d);
        double[] doubleArray10 = arrayRealVector7.toArray();
        boolean boolean11 = arrayRealVector7.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector7, true);
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat17 = new org.apache.commons.math3.linear.RealVectorFormat("hi!", "{", ",");
        double[] doubleArray19 = new double[] { (short) 1 };
        double[] doubleArray22 = new double[] { '#', (short) 100 };
        double[] doubleArray23 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight24 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray23);
        org.apache.commons.math3.optim.nonlinear.vector.Target target25 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray23);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray23);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray22, doubleArray23);
        org.apache.commons.math3.linear.RealVector realVector29 = arrayRealVector27.mapAdd(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray19, arrayRealVector27);
        org.apache.commons.math3.linear.RealVector realVector32 = arrayRealVector30.mapAdd((double) (byte) 0);
        java.lang.String str33 = realVectorFormat17.format(realVector32);
        org.apache.commons.math3.linear.RealVector realVector35 = realVector32.mapDivide(9.999999999999998d);
        try {
            double double36 = arrayRealVector7.getLInfDistance(realVector35);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 2 != 3");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(realVector29);
        org.junit.Assert.assertNotNull(realVector32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "hi!1,35,100{" + "'", str33.equals("hi!1,35,100{"));
        org.junit.Assert.assertNotNull(realVector35);
    }

    @Test
    public void test57() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test57");
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer5 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer((double) 100L, (double) 'a', (double) (byte) 1, (double) (short) -1, (double) (short) 1);
        double double6 = levenbergMarquardtOptimizer5.getChiSquare();
        int int7 = levenbergMarquardtOptimizer5.getEvaluations();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test58() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test58");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex5 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex((int) (short) 100, (double) 2, (-307.6526555685888d), 14890.0d, (double) 64);
    }

    @Test
    public void test59() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test59");
        double[] doubleArray1 = new double[] { (short) 1 };
        double[] doubleArray4 = new double[] { '#', (short) 100 };
        double[] doubleArray5 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight6 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray5);
        org.apache.commons.math3.optim.nonlinear.vector.Target target7 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray5);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix8 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4, doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector11 = arrayRealVector9.mapAdd(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1, arrayRealVector9);
        boolean boolean13 = arrayRealVector12.isNaN();
        org.apache.commons.math3.linear.RealVector realVector15 = arrayRealVector12.mapSubtract(0.0d);
        org.apache.commons.math3.linear.RealVector realVector17 = arrayRealVector12.mapSubtractToSelf(Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(realVector17);
    }

    @Test
    public void test60() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test60");
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver1 = new org.apache.commons.math3.analysis.solvers.BrentSolver((double) 0);
    }

    @Test
    public void test61() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test61");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
        org.apache.commons.math3.optim.nonlinear.vector.Target target2 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix3 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray0);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = diagonalMatrix3.power((int) ' ');
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = diagonalMatrix3.power((int) ' ');
        double[] doubleArray8 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight9 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray8);
        org.apache.commons.math3.optim.nonlinear.vector.Target target10 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray8);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix11 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray8);
        org.apache.commons.math3.linear.RealMatrix realMatrix13 = diagonalMatrix11.power((int) ' ');
        double[] doubleArray14 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight15 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray14);
        org.apache.commons.math3.optim.nonlinear.vector.Target target16 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray14);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix17 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray14);
        double[] doubleArray18 = diagonalMatrix11.operate(doubleArray14);
        double[] doubleArray19 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight20 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray19);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds21 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray18, doubleArray19);
        double[] doubleArray22 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight23 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray22);
        org.apache.commons.math3.optim.nonlinear.vector.Target target24 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray22);
        double[] doubleArray25 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray19, doubleArray22);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix27 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray19, true);
        org.apache.commons.math3.linear.RealMatrix realMatrix28 = diagonalMatrix3.preMultiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix27);
        java.lang.String str29 = diagonalMatrix27.toString();
        double[] doubleArray30 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight31 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray30);
        org.apache.commons.math3.optim.nonlinear.vector.Target target32 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray30);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix33 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray30);
        org.apache.commons.math3.linear.RealMatrix realMatrix35 = diagonalMatrix33.power((int) ' ');
        double[] doubleArray36 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight37 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray36);
        org.apache.commons.math3.optim.nonlinear.vector.Target target38 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray36);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix39 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray36);
        double[] doubleArray40 = diagonalMatrix33.operate(doubleArray36);
        double[] doubleArray41 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight42 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray41);
        org.apache.commons.math3.optim.nonlinear.vector.Target target43 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray41);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix44 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray41);
        double[] doubleArray45 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray40, doubleArray41);
        double[] doubleArray46 = diagonalMatrix27.operate(doubleArray41);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix48 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray41, false);
        double[] doubleArray50 = new double[] { (short) 1 };
        double[] doubleArray53 = new double[] { '#', (short) 100 };
        double[] doubleArray54 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight55 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray54);
        org.apache.commons.math3.optim.nonlinear.vector.Target target56 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray54);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix57 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray54);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector58 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray53, doubleArray54);
        org.apache.commons.math3.linear.RealVector realVector60 = arrayRealVector58.mapAdd(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector61 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray50, arrayRealVector58);
        org.apache.commons.math3.optim.PointValuePair pointValuePair63 = new org.apache.commons.math3.optim.PointValuePair(doubleArray50, (double) 10);
        double[] doubleArray64 = pointValuePair63.getFirst();
        org.apache.commons.math3.optim.InitialGuess initialGuess65 = new org.apache.commons.math3.optim.InitialGuess(doubleArray64);
        boolean boolean66 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray41, doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "DiagonalMatrix{}" + "'", str29.equals("DiagonalMatrix{}"));
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(realMatrix35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(realVector60);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
    }

    @Test
    public void test62() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test62");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
        org.apache.commons.math3.optim.nonlinear.vector.Target target2 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix3 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray0);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = diagonalMatrix3.power((int) ' ');
        double[] doubleArray6 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight7 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray6);
        org.apache.commons.math3.optim.nonlinear.vector.Target target8 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray6);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix9 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6);
        double[] doubleArray10 = diagonalMatrix3.operate(doubleArray6);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix11 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6);
        try {
            double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray6, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
    }

    @Test
    public void test63() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test63");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
        org.apache.commons.math3.optim.nonlinear.vector.Target target2 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix3 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray0);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = diagonalMatrix3.power((int) ' ');
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = diagonalMatrix3.power((int) ' ');
        double[] doubleArray8 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight9 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray8);
        org.apache.commons.math3.optim.nonlinear.vector.Target target10 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray8);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix11 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray8);
        org.apache.commons.math3.linear.RealMatrix realMatrix13 = diagonalMatrix11.power((int) ' ');
        double[] doubleArray14 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight15 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray14);
        org.apache.commons.math3.optim.nonlinear.vector.Target target16 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray14);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix17 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray14);
        double[] doubleArray18 = diagonalMatrix11.operate(doubleArray14);
        double[] doubleArray19 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight20 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray19);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds21 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray18, doubleArray19);
        double[] doubleArray22 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight23 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray22);
        org.apache.commons.math3.optim.nonlinear.vector.Target target24 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray22);
        double[] doubleArray25 = org.apache.commons.math3.util.MathArrays.ebeAdd(doubleArray19, doubleArray22);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix27 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray19, true);
        org.apache.commons.math3.linear.RealMatrix realMatrix28 = diagonalMatrix3.preMultiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix27);
        org.apache.commons.math3.linear.RealMatrix realMatrix30 = diagonalMatrix27.power((int) (byte) 100);
        double[] doubleArray33 = new double[] { '#', (short) 100 };
        double[] doubleArray34 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight35 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray34);
        org.apache.commons.math3.optim.nonlinear.vector.Target target36 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray34);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix37 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray34);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray33, doubleArray34);
        org.apache.commons.math3.linear.RealVector realVector40 = arrayRealVector38.mapAdd(0.0d);
        org.apache.commons.math3.linear.RealVector realVector42 = arrayRealVector38.mapSubtract(2.2250738585072014E-308d);
        org.apache.commons.math3.linear.RealVector realVector44 = arrayRealVector38.mapAddToSelf(1.0E-15d);
        org.apache.commons.math3.linear.RealVector realVector46 = arrayRealVector38.mapAddToSelf((double) (short) 1);
        try {
            org.apache.commons.math3.linear.MatrixUtils.solveLowerTriangularSystem(realMatrix30, realVector46);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 2");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(realVector40);
        org.junit.Assert.assertNotNull(realVector42);
        org.junit.Assert.assertNotNull(realVector44);
        org.junit.Assert.assertNotNull(realVector46);
    }

    @Test
    public void test64() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test64");
        org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.verifyInterval((double) (-1L), 2.993222846126381d);
    }

    @Test
    public void test65() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test65");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat6 = new org.apache.commons.math3.linear.RealVectorFormat("hi!", "{", ",");
        double[] doubleArray8 = new double[] { (short) 1 };
        double[] doubleArray11 = new double[] { '#', (short) 100 };
        double[] doubleArray12 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight13 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray12);
        org.apache.commons.math3.optim.nonlinear.vector.Target target14 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray12);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix15 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray12);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray11, doubleArray12);
        org.apache.commons.math3.linear.RealVector realVector18 = arrayRealVector16.mapAdd(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray8, arrayRealVector16);
        org.apache.commons.math3.linear.RealVector realVector21 = arrayRealVector19.mapAdd((double) (byte) 0);
        java.lang.String str22 = realVectorFormat6.format(realVector21);
        java.text.NumberFormat numberFormat23 = realVectorFormat6.getFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat24 = new org.apache.commons.math3.linear.RealVectorFormat("]", ",", ", ", numberFormat23);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertNotNull(realVector21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "hi!1,35,100{" + "'", str22.equals("hi!1,35,100{"));
        org.junit.Assert.assertNotNull(numberFormat23);
    }

    @Test
    public void test66() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test66");
        double[] doubleArray1 = new double[] { (short) 1 };
        double[] doubleArray4 = new double[] { '#', (short) 100 };
        double[] doubleArray5 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight6 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray5);
        org.apache.commons.math3.optim.nonlinear.vector.Target target7 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray5);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix8 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4, doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector11 = arrayRealVector9.mapAdd(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1, arrayRealVector9);
        double[] doubleArray15 = new double[] { (short) 1 };
        double[] doubleArray18 = new double[] { '#', (short) 100 };
        double[] doubleArray19 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight20 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray19);
        org.apache.commons.math3.optim.nonlinear.vector.Target target21 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray19);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix22 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray19);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray18, doubleArray19);
        org.apache.commons.math3.linear.RealVector realVector25 = arrayRealVector23.mapAdd(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray15, arrayRealVector23);
        boolean boolean27 = arrayRealVector26.isNaN();
        org.apache.commons.math3.linear.RealVector realVector28 = arrayRealVector26.unitVector();
        double[] doubleArray30 = new double[] { (short) 1 };
        double[] doubleArray33 = new double[] { '#', (short) 100 };
        double[] doubleArray34 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight35 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray34);
        org.apache.commons.math3.optim.nonlinear.vector.Target target36 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray34);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix37 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray34);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray33, doubleArray34);
        org.apache.commons.math3.linear.RealVector realVector40 = arrayRealVector38.mapAdd(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray30, arrayRealVector38);
        boolean boolean42 = arrayRealVector41.isNaN();
        org.apache.commons.math3.linear.RealVector realVector44 = arrayRealVector41.mapSubtract(0.0d);
        org.apache.commons.math3.linear.RealVector realVector46 = arrayRealVector41.mapMultiply(1.1752011936438014d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = arrayRealVector26.subtract(realVector46);
        try {
            arrayRealVector9.setSubVector(0, (org.apache.commons.math3.linear.RealVector) arrayRealVector47);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (2)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(realVector25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(realVector28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(realVector40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(realVector44);
        org.junit.Assert.assertNotNull(realVector46);
        org.junit.Assert.assertNotNull(arrayRealVector47);
    }

    @Test
    public void test67() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test67");
        org.apache.commons.math3.linear.AnyMatrix anyMatrix0 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSubMatrixIndex(anyMatrix0, 1076101151, (-52), (int) (byte) 0, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test68() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test68");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
        org.apache.commons.math3.optim.nonlinear.vector.Target target2 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix3 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray0);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = diagonalMatrix3.power((int) ' ');
        boolean boolean6 = diagonalMatrix3.isTransposable();
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = diagonalMatrix3.copy();
        diagonalMatrix3.setEntry((int) (short) 100, 97, (double) 0.0f);
        org.apache.commons.math3.linear.RealMatrix realMatrix12 = diagonalMatrix3.copy();
        double[] doubleArray13 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight14 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray13);
        org.apache.commons.math3.optim.nonlinear.vector.Target target15 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray13);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix16 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray13);
        org.apache.commons.math3.linear.RealMatrix realMatrix18 = diagonalMatrix16.power((int) ' ');
        double[] doubleArray19 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight20 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray19);
        org.apache.commons.math3.optim.nonlinear.vector.Target target21 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray19);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix22 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray19);
        double[] doubleArray23 = diagonalMatrix16.operate(doubleArray19);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix24 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray19);
        org.apache.commons.math3.linear.RealMatrix realMatrix25 = diagonalMatrix3.multiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix24);
        int int26 = diagonalMatrix24.getColumnDimension();
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(realMatrix12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realMatrix18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(realMatrix25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
    }

    @Test
    public void test69() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test69");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat3 = new org.apache.commons.math3.linear.RealVectorFormat("hi!", "{", ",");
        double[] doubleArray5 = new double[] { (short) 1 };
        double[] doubleArray8 = new double[] { '#', (short) 100 };
        double[] doubleArray9 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight10 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray9);
        org.apache.commons.math3.optim.nonlinear.vector.Target target11 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray9);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix12 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray9);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray8, doubleArray9);
        org.apache.commons.math3.linear.RealVector realVector15 = arrayRealVector13.mapAdd(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5, arrayRealVector13);
        org.apache.commons.math3.linear.RealVector realVector18 = arrayRealVector16.mapAdd((double) (byte) 0);
        java.lang.String str19 = realVectorFormat3.format(realVector18);
        java.text.NumberFormat numberFormat20 = realVectorFormat3.getFormat();
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = realVectorFormat3.parse(", ");
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathParseException; message: illegal state: string \", \" unparseable (from position 0) as an object of type org.apache.commons.math3.linear.ArrayRealVector");
        } catch (org.apache.commons.math3.exception.MathParseException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi!1,35,100{" + "'", str19.equals("hi!1,35,100{"));
        org.junit.Assert.assertNotNull(numberFormat20);
    }

    @Test
    public void test70() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test70");
        double[] doubleArray1 = new double[] { (short) 1 };
        double[] doubleArray4 = new double[] { '#', (short) 100 };
        double[] doubleArray5 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight6 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray5);
        org.apache.commons.math3.optim.nonlinear.vector.Target target7 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray5);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix8 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4, doubleArray5);
        org.apache.commons.math3.linear.RealVector realVector11 = arrayRealVector9.mapAdd(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1, arrayRealVector9);
        org.apache.commons.math3.optim.PointValuePair pointValuePair14 = new org.apache.commons.math3.optim.PointValuePair(doubleArray1, (double) 10);
        double[] doubleArray15 = pointValuePair14.getFirst();
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray17 = initialGuess16.getInitialGuess();
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix19 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray17, false);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
    }

    @Test
    public void test71() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test71");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.MatrixUtils.OCTAVE_FORMAT;
        java.text.NumberFormat numberFormat1 = realMatrixFormat0.getFormat();
        java.lang.String str2 = realMatrixFormat0.getColumnSeparator();
        java.text.NumberFormat numberFormat3 = realMatrixFormat0.getFormat();
        java.lang.Class<?> wildcardClass4 = numberFormat3.getClass();
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ", " + "'", str2.equals(", "));
        org.junit.Assert.assertNotNull(numberFormat3);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test72() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test72");
        org.apache.commons.math3.optim.SimpleVectorValueChecker simpleVectorValueChecker4 = new org.apache.commons.math3.optim.SimpleVectorValueChecker((double) '4', (double) 10L, 125);
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer gaussNewtonOptimizer5 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer((org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair>) simpleVectorValueChecker4);
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer10 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer(1.0726932790000005E9d, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair>) simpleVectorValueChecker4, (-307.6526555685888d), (-1020.5751316061705d), 0.0d, (double) 97);
        double[] doubleArray13 = new double[] { 10 };
        int int14 = org.apache.commons.math3.util.MathUtils.hash(doubleArray13);
        double[] doubleArray15 = null;
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray13, doubleArray15);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair17 = null;
        try {
            boolean boolean18 = simpleVectorValueChecker4.converged((int) (byte) 1, pointVectorValuePair16, pointVectorValuePair17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1076101151 + "'", int14 == 1076101151);
    }

    @Test
    public void test73() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test73");
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker2 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker(0.0d, (double) 0.0f);
        org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair6 = new org.apache.commons.math3.optim.univariate.UnivariatePointValuePair(0.0d, (double) 100);
        org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair9 = new org.apache.commons.math3.optim.univariate.UnivariatePointValuePair(0.0d, 0.0d);
        double double10 = univariatePointValuePair9.getValue();
        boolean boolean11 = simpleUnivariateValueChecker2.converged(125, univariatePointValuePair6, univariatePointValuePair9);
        double double12 = simpleUnivariateValueChecker2.getRelativeThreshold();
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
    }

    @Test
    public void test74() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test74");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray4 = new double[] { '#', (byte) 100, (short) 100 };
        double[] doubleArray8 = new double[] { '#', (byte) 100, (short) 100 };
        double[] doubleArray12 = new double[] { '#', (byte) 100, (short) 100 };
        double[] doubleArray16 = new double[] { '#', (byte) 100, (short) 100 };
        double[][] doubleArray17 = new double[][] { doubleArray4, doubleArray8, doubleArray12, doubleArray16 };
        double[][] doubleArray18 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray17);
        double[][] doubleArray19 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray18);
        org.apache.commons.math3.linear.RealMatrix realMatrix20 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray19);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray19, false);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException23 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable0, (java.lang.Object[]) doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(realMatrix20);
    }

    @Test
    public void test75() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test75");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex1 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(25);
    }

    @Test
    public void test76() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test76");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight1 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray0);
        org.apache.commons.math3.optim.nonlinear.vector.Target target2 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray0);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix3 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray0);
        double double4 = diagonalMatrix3.getFrobeniusNorm();
        boolean boolean5 = diagonalMatrix3.isSquare();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix7 = diagonalMatrix3.scalarMultiply(14889.999999999998d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test77() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test77");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math3.random.MersenneTwister((int) '#');
        double double7 = mersenneTwister6.nextDouble();
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker11 = new org.apache.commons.math3.optim.SimpleValueChecker((double) (byte) 1, (double) (short) 100);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer12 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer((int) '#', (double) (short) 1, true, 36, 10, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister6, true, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker11);
        double double13 = simpleValueChecker11.getAbsoluteThreshold();
        double[] doubleArray15 = null;
        org.apache.commons.math3.optim.PointValuePair pointValuePair17 = new org.apache.commons.math3.optim.PointValuePair(doubleArray15, 0.0d);
        double[] doubleArray18 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight19 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray18);
        org.apache.commons.math3.optim.nonlinear.vector.Target target20 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix21 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray18);
        org.apache.commons.math3.optim.PointValuePair pointValuePair24 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) 10, false);
        boolean boolean25 = simpleValueChecker11.converged((int) '4', pointValuePair17, pointValuePair24);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.IdentityPreconditioner identityPreconditioner26 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.IdentityPreconditioner();
        double[] doubleArray27 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight28 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray27);
        org.apache.commons.math3.optim.nonlinear.vector.Target target29 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray27);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix30 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray27);
        org.apache.commons.math3.linear.RealMatrix realMatrix32 = diagonalMatrix30.power((int) ' ');
        double[] doubleArray33 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight34 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray33);
        org.apache.commons.math3.optim.nonlinear.vector.Target target35 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray33);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix36 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray33);
        double[] doubleArray37 = diagonalMatrix30.operate(doubleArray33);
        double[] doubleArray38 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight39 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray38);
        org.apache.commons.math3.optim.SimpleBounds simpleBounds40 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray37, doubleArray38);
        double[] doubleArray41 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight42 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray41);
        double[] doubleArray43 = identityPreconditioner26.precondition(doubleArray38, doubleArray41);
        double[] doubleArray44 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight45 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray44);
        org.apache.commons.math3.optim.nonlinear.vector.Target target46 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray44);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix47 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray44);
        org.apache.commons.math3.linear.RealMatrix realMatrix49 = diagonalMatrix47.power((int) ' ');
        double[] doubleArray50 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight51 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray50);
        org.apache.commons.math3.optim.nonlinear.vector.Target target52 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray50);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix53 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray50);
        double[] doubleArray54 = diagonalMatrix47.operate(doubleArray50);
        double[] doubleArray55 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray54);
        double[] doubleArray58 = new double[] { '#', (short) 100 };
        double[] doubleArray59 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight60 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray59);
        org.apache.commons.math3.optim.nonlinear.vector.Target target61 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray59);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix62 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray59);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector63 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray58, doubleArray59);
        double[] doubleArray64 = identityPreconditioner26.precondition(doubleArray54, doubleArray59);
        double[] doubleArray66 = new double[] { (short) 1 };
        double[] doubleArray69 = new double[] { '#', (short) 100 };
        double[] doubleArray70 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight71 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray70);
        org.apache.commons.math3.optim.nonlinear.vector.Target target72 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray70);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix73 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray70);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector74 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray69, doubleArray70);
        org.apache.commons.math3.linear.RealVector realVector76 = arrayRealVector74.mapAdd(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector77 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray66, arrayRealVector74);
        double double78 = arrayRealVector77.getL1Norm();
        double[] doubleArray82 = new double[] { (short) 1 };
        double[] doubleArray85 = new double[] { '#', (short) 100 };
        double[] doubleArray86 = new double[] {};
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight87 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray86);
        org.apache.commons.math3.optim.nonlinear.vector.Target target88 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray86);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix89 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray86);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector90 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray85, doubleArray86);
        org.apache.commons.math3.linear.RealVector realVector92 = arrayRealVector90.mapAdd(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector93 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray82, arrayRealVector90);
        org.apache.commons.math3.linear.RealVector realVector95 = arrayRealVector93.mapAdd((double) (byte) 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector96 = arrayRealVector77.combine((double) 100L, (double) (byte) 1, (org.apache.commons.math3.linear.RealVector) arrayRealVector93);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector97 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray59, arrayRealVector96);
        boolean boolean98 = pointValuePair17.equals((java.lang.Object) arrayRealVector96);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.45805495157532494d + "'", double7 == 0.45805495157532494d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 100.0d + "'", double13 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(realMatrix32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(realMatrix49);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(realVector76);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 136.0d + "'", double78 == 136.0d);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertNotNull(realVector92);
        org.junit.Assert.assertNotNull(realVector95);
        org.junit.Assert.assertNotNull(arrayRealVector96);
        org.junit.Assert.assertTrue("'" + boolean98 + "' != '" + false + "'", boolean98 == false);
    }
}

