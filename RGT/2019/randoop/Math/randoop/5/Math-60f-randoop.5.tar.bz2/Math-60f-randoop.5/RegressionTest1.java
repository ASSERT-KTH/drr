import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) ' ', 1.781072417990198d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 479.4917191983082d + "'", double2 == 479.4917191983082d);
    }

//    @Test
//    public void test002() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test002");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (byte) 0, 3.141592653589793d);
//        java.lang.String str5 = randomDataImpl0.nextHexString(52);
//        double double8 = randomDataImpl0.nextGamma(14.154262241479262d, 53.23505843707038d);
//        double double11 = randomDataImpl0.nextCauchy(194.270024143189d, 2.091233300638824d);
//        try {
//            randomDataImpl0.setSecureAlgorithm("72ac4689d9e8052f48269d9311e485f4e3af813dab5c18f99bde", "6accba7669a0e70e4d0e5b16e752922b4756e6b846217a6d2315");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: 6accba7669a0e70e4d0e5b16e752922b4756e6b846217a6d2315");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.3056171131887502d + "'", double3 == 0.3056171131887502d);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "b6ca8baa110a20fcaca031510319afc745ba89f8e563ce12f95a" + "'", str5.equals("b6ca8baa110a20fcaca031510319afc745ba89f8e563ce12f95a"));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 845.6415101634725d + "'", double8 == 845.6415101634725d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 167.34881495614104d + "'", double11 == 167.34881495614104d);
//    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 0.0f, 3.4657359027997265d, 2.749504722793435d);
        double double5 = normalDistributionImpl3.inverseCumulativeProbability(0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.NEGATIVE_INFINITY + "'", double5 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 35, (float) 21L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 21.0f + "'", float2 == 21.0f);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        double double1 = org.apache.commons.math.util.FastMath.tanh(1.540819445899548d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9122579630999029d + "'", double1 == 0.9122579630999029d);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        double double1 = org.apache.commons.math.special.Gamma.logGamma((-8.212797486430139d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(4.571545345114974d, 2.200736691117263E34d, 1.0d);
        double double5 = normalDistributionImpl3.density((double) 32.0f);
        double double6 = normalDistributionImpl3.getMean();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.812766979401334E-35d + "'", double5 == 1.812766979401334E-35d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.571545345114974d + "'", double6 == 4.571545345114974d);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 0, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        double double2 = org.apache.commons.math.util.FastMath.max(97.70870858470293d, (-0.6390480052063447d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 97.70870858470293d + "'", double2 == 97.70870858470293d);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.4400725428656519d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.41370457103898095d + "'", double1 == 0.41370457103898095d);
    }

//    @Test
//    public void test011() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test011");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        int int4 = randomDataImpl0.nextInt(75, (int) 'a');
//        double double7 = randomDataImpl0.nextCauchy(0.8746788966462123d, 28.782429690343378d);
//        randomDataImpl0.reSeedSecure();
//        try {
//            double double11 = randomDataImpl0.nextWeibull((double) 87, (-370.76182023378965d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -370.762 is smaller than, or equal to, the minimum (0): scale (-370.762)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 75 + "'", int4 == 75);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 8.412173284743558d + "'", double7 == 8.412173284743558d);
//    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.006992129485781045d, (java.lang.Number) (-116.20953636056122d), false);
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (short) 0, (java.lang.Number) (short) 0, true);
        java.lang.Throwable[] throwableArray9 = numberIsTooSmallException8.getSuppressed();
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException3, localizable4, (java.lang.Object[]) throwableArray9);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException14 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.006992129485781045d, (java.lang.Number) (-7.231717743255292d), true);
        boolean boolean15 = numberIsTooSmallException14.getBoundIsAllowed();
        mathException10.addSuppressed((java.lang.Throwable) numberIsTooSmallException14);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        long long2 = org.apache.commons.math.util.FastMath.min(0L, (long) 52);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5403023058681398d + "'", double1 == 0.5403023058681398d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable1, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException5.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray12 = mathException11.getArguments();
        java.lang.Throwable[] throwableArray13 = mathException11.getSuppressed();
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException0, localizable6, (java.lang.Object[]) throwableArray13);
        java.lang.Object[] objArray15 = null;
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException(localizable6, objArray15);
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException21 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable17, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable22 = numberIsTooSmallException21.getGeneralPattern();
        java.lang.Number number23 = null;
        java.lang.Number number24 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException26 = new org.apache.commons.math.exception.OutOfRangeException(localizable22, number23, number24, (java.lang.Number) 10);
        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException26);
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException26);
        java.lang.Number number29 = outOfRangeException26.getLo();
        java.lang.Number number30 = outOfRangeException26.getLo();
        java.lang.Number number31 = outOfRangeException26.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable32 = outOfRangeException26.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException37 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable33, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable38 = numberIsTooSmallException37.getGeneralPattern();
        java.lang.Number number39 = null;
        java.lang.Number number40 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException42 = new org.apache.commons.math.exception.OutOfRangeException(localizable38, number39, number40, (java.lang.Number) 10);
        org.apache.commons.math.MathException mathException43 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException42);
        java.lang.Number number44 = outOfRangeException42.getHi();
        java.lang.Throwable[] throwableArray45 = outOfRangeException42.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException(localizable32, (java.lang.Object[]) throwableArray45);
        org.apache.commons.math.MathException mathException49 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable50 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException54 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable50, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable55 = numberIsTooSmallException54.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException59 = new org.apache.commons.math.exception.OutOfRangeException(localizable55, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException60 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray61 = mathException60.getArguments();
        java.lang.Throwable[] throwableArray62 = mathException60.getSuppressed();
        org.apache.commons.math.MathException mathException63 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException49, localizable55, (java.lang.Object[]) throwableArray62);
        org.apache.commons.math.MathException mathException65 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray66 = mathException65.getArguments();
        java.lang.Throwable[] throwableArray67 = mathException65.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException68 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException49, "", (java.lang.Object[]) throwableArray67);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException69 = new org.apache.commons.math.MaxIterationsExceededException(0, "hi!", (java.lang.Object[]) throwableArray67);
        org.apache.commons.math.MathException mathException70 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException16, localizable32, (java.lang.Object[]) throwableArray67);
        org.apache.commons.math.exception.util.Localizable localizable71 = mathException70.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable72 = mathException70.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable74 = null;
        org.apache.commons.math.MathException mathException76 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable77 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException81 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable77, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable82 = numberIsTooSmallException81.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException86 = new org.apache.commons.math.exception.OutOfRangeException(localizable82, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException87 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray88 = mathException87.getArguments();
        java.lang.Throwable[] throwableArray89 = mathException87.getSuppressed();
        org.apache.commons.math.MathException mathException90 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException76, localizable82, (java.lang.Object[]) throwableArray89);
        org.apache.commons.math.ConvergenceException convergenceException91 = new org.apache.commons.math.ConvergenceException("hi!", (java.lang.Object[]) throwableArray89);
        org.apache.commons.math.ConvergenceException convergenceException92 = new org.apache.commons.math.ConvergenceException(localizable74, (java.lang.Object[]) throwableArray89);
        org.apache.commons.math.ConvergenceException convergenceException93 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException70, "a879ec2eb4beef0b2be4114d77aec9eb682", (java.lang.Object[]) throwableArray89);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertTrue("'" + localizable22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable22.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNull(number29);
        org.junit.Assert.assertNull(number30);
        org.junit.Assert.assertNull(number31);
        org.junit.Assert.assertTrue("'" + localizable32 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable32.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable38 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable38.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + number44 + "' != '" + 10 + "'", number44.equals(10));
        org.junit.Assert.assertNotNull(throwableArray45);
        org.junit.Assert.assertTrue("'" + localizable55 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable55.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray61);
        org.junit.Assert.assertNotNull(throwableArray62);
        org.junit.Assert.assertNotNull(objArray66);
        org.junit.Assert.assertNotNull(throwableArray67);
        org.junit.Assert.assertTrue("'" + localizable71 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable71.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable72 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable72.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable82 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable82.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray88);
        org.junit.Assert.assertNotNull(throwableArray89);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(7.083034143026365E7d, 20.999999999999996d, 2.0d, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: maximal number of iterations (0) exceeded");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        double double2 = org.apache.commons.math.util.FastMath.pow((-4.667786224710645d), 0.4065247197838044d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) (short) 1);
        double double3 = normalDistributionImpl2.getStandardDeviation();
        double double6 = normalDistributionImpl2.cumulativeProbability(0.0d, 0.872447858588575d);
        try {
            double[] doubleArray8 = normalDistributionImpl2.sample((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): number of samples (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.3085179492431469d + "'", double6 == 0.3085179492431469d);
    }

//    @Test
//    public void test019() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test019");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        int int4 = randomDataImpl0.nextInt(75, (int) 'a');
//        double double7 = randomDataImpl0.nextCauchy(0.8746788966462123d, 28.782429690343378d);
//        randomDataImpl0.reSeedSecure();
//        try {
//            double double11 = randomDataImpl0.nextBeta((-0.0710722644357374d), 806.4077649578195d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.5 p = 0.99");
//        } catch (org.apache.commons.math.exception.MathUserException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 82 + "'", int4 == 82);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 16.285943324981783d + "'", double7 == 16.285943324981783d);
//    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1.0d, (java.lang.Number) (-1L), true);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooLargeException3.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable10 = numberIsTooSmallException9.getGeneralPattern();
        java.lang.Throwable[] throwableArray11 = numberIsTooSmallException9.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException(localizable4, (java.lang.Object[]) throwableArray11);
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException17 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable13, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable18 = numberIsTooSmallException17.getGeneralPattern();
        java.lang.Number number19 = null;
        java.lang.Number number20 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException22 = new org.apache.commons.math.exception.OutOfRangeException(localizable18, number19, number20, (java.lang.Number) 10);
        org.apache.commons.math.MathException mathException23 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException22);
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException22);
        java.lang.Number number25 = outOfRangeException22.getLo();
        java.lang.Number number26 = outOfRangeException22.getLo();
        java.lang.Number number27 = outOfRangeException22.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable28 = outOfRangeException22.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable29 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException33 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable29, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable34 = numberIsTooSmallException33.getGeneralPattern();
        java.lang.Number number35 = null;
        java.lang.Number number36 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException38 = new org.apache.commons.math.exception.OutOfRangeException(localizable34, number35, number36, (java.lang.Number) 10);
        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException38);
        java.lang.Number number40 = outOfRangeException38.getHi();
        java.lang.Throwable[] throwableArray41 = outOfRangeException38.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException(localizable28, (java.lang.Object[]) throwableArray41);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException44 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable28, (java.lang.Number) 100);
        java.lang.Throwable[] throwableArray45 = notStrictlyPositiveException44.getSuppressed();
        org.apache.commons.math.MathException mathException46 = new org.apache.commons.math.MathException(localizable4, (java.lang.Object[]) throwableArray45);
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertTrue("'" + localizable10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable10.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertTrue("'" + localizable18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable18.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNull(number25);
        org.junit.Assert.assertNull(number26);
        org.junit.Assert.assertNull(number27);
        org.junit.Assert.assertTrue("'" + localizable28 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable28.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable34 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable34.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + number40 + "' != '" + 10 + "'", number40.equals(10));
        org.junit.Assert.assertNotNull(throwableArray41);
        org.junit.Assert.assertNotNull(throwableArray45);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((-0.5872139151569291d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.587213915156929d) + "'", double1 == (-0.587213915156929d));
    }

//    @Test
//    public void test022() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test022");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextCauchy(0.0d, (double) 32);
//        double double6 = randomDataImpl0.nextExponential(359.1342053695754d);
//        randomDataImpl0.reSeedSecure((long) (short) 1);
//        double double10 = randomDataImpl0.nextT(57.29577951308232d);
//        double double13 = randomDataImpl0.nextCauchy(10.0d, (double) 32.0f);
//        randomDataImpl0.reSeedSecure((long) (byte) 100);
//        java.lang.String str17 = randomDataImpl0.nextSecureHexString(52);
//        try {
//            int int21 = randomDataImpl0.nextHypergeometric(0, (int) (short) 1, (int) (byte) 1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): population size (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-27.469259188554716d) + "'", double4 == (-27.469259188554716d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 415.9479095286152d + "'", double6 == 415.9479095286152d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-0.04608459163654888d) + "'", double10 == (-0.04608459163654888d));
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 6.550049324770228d + "'", double13 == 6.550049324770228d);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "f786728cf7c2c1df530c30b7c901062dce0b6bc54183bd8ef841" + "'", str17.equals("f786728cf7c2c1df530c30b7c901062dce0b6bc54183bd8ef841"));
//    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        double double1 = org.apache.commons.math.special.Erf.erf(3.450029527644452d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999989341738639d + "'", double1 == 0.9999989341738639d);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getGeneralPattern();
        java.lang.Number number6 = null;
        java.lang.Number number7 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException9 = new org.apache.commons.math.exception.OutOfRangeException(localizable5, number6, number7, (java.lang.Number) 10);
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException9);
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException9);
        java.lang.Number number12 = outOfRangeException9.getLo();
        java.lang.Number number13 = outOfRangeException9.getLo();
        java.lang.Number number14 = outOfRangeException9.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable15 = outOfRangeException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException20 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable16, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable21 = numberIsTooSmallException20.getGeneralPattern();
        java.lang.Number number22 = null;
        java.lang.Number number23 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException25 = new org.apache.commons.math.exception.OutOfRangeException(localizable21, number22, number23, (java.lang.Number) 10);
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException25);
        java.lang.Number number27 = outOfRangeException25.getHi();
        java.lang.Throwable[] throwableArray28 = outOfRangeException25.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException(localizable15, (java.lang.Object[]) throwableArray28);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException33 = new org.apache.commons.math.exception.OutOfRangeException(localizable15, (java.lang.Number) (-0.8813735870195429d), (java.lang.Number) (byte) 0, (java.lang.Number) 1.3765887979465332d);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException37 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable15, (java.lang.Number) 0.299929460301182d, (java.lang.Number) (-221.3971786708914d), true);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException41 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable15, (java.lang.Number) 2.200736691117263E34d, (java.lang.Number) 2.6881171418161356E43d, false);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertNull(number13);
        org.junit.Assert.assertNull(number14);
        org.junit.Assert.assertTrue("'" + localizable15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable15.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable21.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + number27 + "' != '" + 10 + "'", number27.equals(10));
        org.junit.Assert.assertNotNull(throwableArray28);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(2.8553217231426142d, 0.006992129485781045d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9999998610417296d + "'", double2 == 0.9999998610417296d);
    }

//    @Test
//    public void test026() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test026");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        java.lang.String str3 = randomDataImpl1.nextHexString((int) (short) 10);
//        try {
//            int int6 = randomDataImpl1.nextZipf(97, (-1.8741723893495077d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1.874 is smaller than, or equal to, the minimum (0): exponent (-1.874)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "b23635c7c2" + "'", str3.equals("b23635c7c2"));
//    }

//    @Test
//    public void test027() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test027");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (byte) 0, 3.141592653589793d);
//        java.lang.String str5 = randomDataImpl0.nextHexString(52);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl9 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 97L, (double) (short) 1, (double) (byte) 0);
//        double double11 = normalDistributionImpl9.inverseCumulativeProbability(0.5765158901134363d);
//        double double12 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl9);
//        try {
//            randomDataImpl0.setSecureAlgorithm("61a4f185f4e6dec51618f8734c2c5eaa", "2cc4bca353b0d36733d55b2ff91bbb544b5");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: 2cc4bca353b0d36733d55b2ff91bbb544b5");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.6514922065389425d + "'", double3 == 0.6514922065389425d);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "6956ce4b152a8b71ac1bef6c9e86e4118b92768b826b721f30af" + "'", str5.equals("6956ce4b152a8b71ac1bef6c9e86e4118b92768b826b721f30af"));
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 97.19298818676732d + "'", double11 == 97.19298818676732d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 97.55087945114671d + "'", double12 == 97.55087945114671d);
//    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException4.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) (-24.242513872234355d), (java.lang.Number) 0.7336545584598283d, (java.lang.Number) 330.30579510442254d);
        org.junit.Assert.assertNull(localizable5);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        int int2 = org.apache.commons.math.util.FastMath.max(81, 81);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 81 + "'", int2 == 81);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getGeneralPattern();
        java.lang.Number number6 = null;
        java.lang.Number number7 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException9 = new org.apache.commons.math.exception.OutOfRangeException(localizable5, number6, number7, (java.lang.Number) 10);
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException9);
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException9);
        java.lang.Number number12 = outOfRangeException9.getLo();
        java.lang.Number number13 = outOfRangeException9.getLo();
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException18 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable14, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable19 = numberIsTooSmallException18.getGeneralPattern();
        java.lang.Object[] objArray20 = null;
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException9, localizable19, objArray20);
        org.apache.commons.math.exception.util.Localizable localizable22 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException26 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable22, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable27 = numberIsTooSmallException26.getGeneralPattern();
        java.lang.Number number28 = null;
        java.lang.Number number29 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException31 = new org.apache.commons.math.exception.OutOfRangeException(localizable27, number28, number29, (java.lang.Number) 10);
        org.apache.commons.math.MathException mathException32 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException31);
        org.apache.commons.math.ConvergenceException convergenceException33 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException31);
        java.lang.Number number34 = outOfRangeException31.getLo();
        java.lang.Number number35 = outOfRangeException31.getLo();
        java.lang.Number number36 = outOfRangeException31.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable37 = outOfRangeException31.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable38 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException42 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable38, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable43 = numberIsTooSmallException42.getGeneralPattern();
        java.lang.Number number44 = null;
        java.lang.Number number45 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException47 = new org.apache.commons.math.exception.OutOfRangeException(localizable43, number44, number45, (java.lang.Number) 10);
        org.apache.commons.math.MathException mathException48 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException47);
        java.lang.Number number49 = outOfRangeException47.getHi();
        java.lang.Throwable[] throwableArray50 = outOfRangeException47.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException51 = new org.apache.commons.math.ConvergenceException(localizable37, (java.lang.Object[]) throwableArray50);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException55 = new org.apache.commons.math.exception.OutOfRangeException(localizable37, (java.lang.Number) (-0.8813735870195429d), (java.lang.Number) (byte) 0, (java.lang.Number) 1.3765887979465332d);
        org.apache.commons.math.MathException mathException59 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable60 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException64 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable60, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable65 = numberIsTooSmallException64.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException69 = new org.apache.commons.math.exception.OutOfRangeException(localizable65, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException70 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray71 = mathException70.getArguments();
        java.lang.Throwable[] throwableArray72 = mathException70.getSuppressed();
        org.apache.commons.math.MathException mathException73 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException59, localizable65, (java.lang.Object[]) throwableArray72);
        org.apache.commons.math.ConvergenceException convergenceException74 = new org.apache.commons.math.ConvergenceException("hi!", (java.lang.Object[]) throwableArray72);
        org.apache.commons.math.ConvergenceException convergenceException75 = new org.apache.commons.math.ConvergenceException("2cc4bca353b0d36733d55b2ff91bbb544b5", (java.lang.Object[]) throwableArray72);
        org.apache.commons.math.ConvergenceException convergenceException76 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException55, "{0}", (java.lang.Object[]) throwableArray72);
        org.apache.commons.math.ConvergenceException convergenceException77 = new org.apache.commons.math.ConvergenceException(localizable19, (java.lang.Object[]) throwableArray72);
        org.apache.commons.math.exception.util.Localizable localizable78 = convergenceException77.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertNull(number13);
        org.junit.Assert.assertTrue("'" + localizable19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable19.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizable27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable27.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNull(number34);
        org.junit.Assert.assertNull(number35);
        org.junit.Assert.assertNull(number36);
        org.junit.Assert.assertTrue("'" + localizable37 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable37.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable43 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable43.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + number49 + "' != '" + 10 + "'", number49.equals(10));
        org.junit.Assert.assertNotNull(throwableArray50);
        org.junit.Assert.assertTrue("'" + localizable65 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable65.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray71);
        org.junit.Assert.assertNotNull(throwableArray72);
        org.junit.Assert.assertTrue("'" + localizable78 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable78.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 75);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 75.00000000000001d + "'", double1 == 75.00000000000001d);
    }

//    @Test
//    public void test032() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test032");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (byte) 0, 3.141592653589793d);
//        java.lang.String str5 = randomDataImpl0.nextHexString(52);
//        int int8 = randomDataImpl0.nextPascal(35, 0.9586987012903039d);
//        randomDataImpl0.reSeed((long) 52);
//        try {
//            int int13 = randomDataImpl0.nextInt((int) (byte) 100, (int) (short) -1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100 is larger than, or equal to, the maximum (-1): lower bound (100) must be strictly less than upper bound (-1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.034331691141601825d + "'", double3 == 0.034331691141601825d);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "9aa928ba25abdedcb3e56150d60fab596b114dadb86ca3374fe8" + "'", str5.equals("9aa928ba25abdedcb3e56150d60fab596b114dadb86ca3374fe8"));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.MathException mathException1 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException6 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable2, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable7 = numberIsTooSmallException6.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException11 = new org.apache.commons.math.exception.OutOfRangeException(localizable7, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray13 = mathException12.getArguments();
        java.lang.Throwable[] throwableArray14 = mathException12.getSuppressed();
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException1, localizable7, (java.lang.Object[]) throwableArray14);
        java.lang.Object[] objArray16 = null;
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException(localizable7, objArray16);
        java.lang.Number number19 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException21 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable7, (java.lang.Number) 2.718281828459045d, number19, false);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException25 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable7, (java.lang.Number) 1, (java.lang.Number) 38.40781474984203d, false);
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException30 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable26, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable31 = numberIsTooSmallException30.getGeneralPattern();
        java.lang.Number number32 = null;
        java.lang.Number number33 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException35 = new org.apache.commons.math.exception.OutOfRangeException(localizable31, number32, number33, (java.lang.Number) 10);
        org.apache.commons.math.MathException mathException36 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException35);
        java.lang.Number number37 = outOfRangeException35.getHi();
        java.lang.Throwable[] throwableArray38 = outOfRangeException35.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException39 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, (java.lang.Object[]) throwableArray38);
        org.apache.commons.math.exception.util.Localizable localizable41 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException45 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable41, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable46 = numberIsTooSmallException45.getGeneralPattern();
        java.lang.Throwable[] throwableArray47 = numberIsTooSmallException45.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException48 = new org.apache.commons.math.ConvergenceException("", (java.lang.Object[]) throwableArray47);
        org.apache.commons.math.ConvergenceException convergenceException49 = new org.apache.commons.math.ConvergenceException(throwable0, localizable7, (java.lang.Object[]) throwableArray47);
        java.lang.String str50 = convergenceException49.getPattern();
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertTrue("'" + localizable31 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable31.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + number37 + "' != '" + 10 + "'", number37.equals(10));
        org.junit.Assert.assertNotNull(throwableArray38);
        org.junit.Assert.assertTrue("'" + localizable46 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable46.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(throwableArray47);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "{0} is smaller than the minimum ({1})" + "'", str50.equals("{0} is smaller than the minimum ({1})"));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(2.200736691117263E34d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7182622611710154E36d + "'", double1 == 1.7182622611710154E36d);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

//    @Test
//    public void test036() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test036");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextCauchy(0.0d, (double) 32);
//        double double6 = randomDataImpl0.nextExponential(359.1342053695754d);
//        randomDataImpl0.reSeedSecure((long) (short) 1);
//        double double10 = randomDataImpl0.nextT(57.29577951308232d);
//        randomDataImpl0.reSeed((long) (short) -1);
//        randomDataImpl0.reSeedSecure(12L);
//        randomDataImpl0.reSeedSecure();
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-300.4815966560189d) + "'", double4 == (-300.4815966560189d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.6892497598624547d + "'", double6 == 1.6892497598624547d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-0.2803830370816114d) + "'", double10 == (-0.2803830370816114d));
//    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (short) 0, (java.lang.Number) (short) 0, true);
        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException3);
        java.lang.Object[] objArray5 = numberIsTooSmallException3.getArguments();
        org.junit.Assert.assertNotNull(objArray5);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable1, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException5.getGeneralPattern();
        java.lang.Number number7 = null;
        java.lang.Number number8 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, number7, number8, (java.lang.Number) 10);
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException10);
        mathException0.addSuppressed((java.lang.Throwable) mathException11);
        java.lang.String str13 = mathException0.getPattern();
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "{0}" + "'", str13.equals("{0}"));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) (short) 1);
        normalDistributionImpl2.reseedRandomGenerator((long) (byte) -1);
        normalDistributionImpl2.reseedRandomGenerator((long) (short) 10);
        double double7 = normalDistributionImpl2.getStandardDeviation();
        double double8 = normalDistributionImpl2.sample();
        double double9 = normalDistributionImpl2.sample();
        double[] doubleArray11 = normalDistributionImpl2.sample(52);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.8746788966462123d + "'", double8 == 0.8746788966462123d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-0.9193443348656242d) + "'", double9 == (-0.9193443348656242d));
        org.junit.Assert.assertNotNull(doubleArray11);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        double double1 = org.apache.commons.math.special.Gamma.logGamma((-0.767944870877505d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        double double2 = org.apache.commons.math.util.FastMath.atan2((-87.87237552410505d), 0.3140475121298414d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.567222437126173d) + "'", double2 == (-1.567222437126173d));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0L, (java.lang.Number) 0.0f, false);
        java.lang.Class<?> wildcardClass4 = numberIsTooLargeException3.getClass();
        java.lang.Number number5 = numberIsTooLargeException3.getArgument();
        java.lang.Number number6 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0L + "'", number5.equals(0L));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0.0f + "'", number6.equals(0.0f));
    }

//    @Test
//    public void test043() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test043");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextCauchy(0.0d, (double) 32);
//        double double6 = randomDataImpl0.nextExponential(359.1342053695754d);
//        randomDataImpl0.reSeedSecure((long) (short) 1);
//        double double10 = randomDataImpl0.nextT(57.29577951308232d);
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeed();
//        try {
//            int int16 = randomDataImpl0.nextHypergeometric((int) (short) -1, (int) (short) 10, 100);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): population size (-1)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-210.9293971165472d) + "'", double4 == (-210.9293971165472d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 565.1419155955886d + "'", double6 == 565.1419155955886d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-0.5769871448949634d) + "'", double10 == (-0.5769871448949634d));
//    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 3, (-0.586194128048397d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.7637630371219195d + "'", double2 == 1.7637630371219195d);
    }

//    @Test
//    public void test045() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test045");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (byte) 0, 3.141592653589793d);
//        randomDataImpl0.reSeedSecure();
//        double double7 = randomDataImpl0.nextGaussian(0.0d, 2.993222846126381d);
//        int int10 = randomDataImpl0.nextZipf(3, 75.00000000000001d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.14999862817493861d + "'", double3 == 0.14999862817493861d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.081363306510076d + "'", double7 == 4.081363306510076d);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException(number0, (java.lang.Number) (byte) 10, false);
    }

//    @Test
//    public void test047() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test047");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (byte) 0, 3.141592653589793d);
//        java.lang.String str5 = randomDataImpl0.nextHexString(52);
//        int int8 = randomDataImpl0.nextPascal(35, 0.9586987012903039d);
//        double double11 = randomDataImpl0.nextGamma(0.4400725428656519d, 0.5765158901134363d);
//        try {
//            double double14 = randomDataImpl0.nextF((-0.14764577438328919d), 1.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.148 is smaller than, or equal to, the minimum (0): degrees of freedom (-0.148)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.13255004986612612d + "'", double3 == 0.13255004986612612d);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "4860618ea323df472ec5ba48406e118f06f646a90162a41ba4d7" + "'", str5.equals("4860618ea323df472ec5ba48406e118f06f646a90162a41ba4d7"));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.333477616939687d + "'", double11 == 0.333477616939687d);
//    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        double double2 = org.apache.commons.math.util.FastMath.min(1.3765887979465332d, 54.19772074289467d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.3765887979465332d + "'", double2 == 1.3765887979465332d);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(97.19298818676732d, (double) '4', 0.10672988369442259d, 7);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.3286684140707907E-8d + "'", double4 == 1.3286684140707907E-8d);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.0962373903922824d);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(1.5713413291617189d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.027425079866535983d + "'", double1 == 0.027425079866535983d);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        double double1 = org.apache.commons.math.util.FastMath.log1p((-4.667786224710645d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        double double1 = org.apache.commons.math.util.FastMath.ceil(425.72936743627463d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 426.0d + "'", double1 == 426.0d);
    }

//    @Test
//    public void test054() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test054");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (byte) 0, 3.141592653589793d);
//        java.lang.String str5 = randomDataImpl0.nextHexString(52);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl9 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 97L, (double) (short) 1, (double) (byte) 0);
//        double double11 = normalDistributionImpl9.inverseCumulativeProbability(0.5765158901134363d);
//        double double12 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl9);
//        double double13 = normalDistributionImpl9.sample();
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.046467412076156d + "'", double3 == 3.046467412076156d);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "41f9b4b86b87c45ded549aa77db6f4daa93099871e742578b6ad" + "'", str5.equals("41f9b4b86b87c45ded549aa77db6f4daa93099871e742578b6ad"));
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 97.19298818676732d + "'", double11 == 97.19298818676732d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 97.26737425890234d + "'", double12 == 97.26737425890234d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 97.55660371265007d + "'", double13 == 97.55660371265007d);
//    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.5765158901134363d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5201284964308879d + "'", double1 == 0.5201284964308879d);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(2.732900526423743d, (-1.8741723893495077d), (-1.170522548775396d), (int) (short) 10);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(12.16619972568005d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.2999495720311036d + "'", double1 == 2.2999495720311036d);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable1, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException5.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException16 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable12, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable17 = numberIsTooSmallException16.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException21 = new org.apache.commons.math.exception.OutOfRangeException(localizable17, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray23 = mathException22.getArguments();
        java.lang.Throwable[] throwableArray24 = mathException22.getSuppressed();
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException11, localizable17, (java.lang.Object[]) throwableArray24);
        java.lang.Object[] objArray26 = null;
        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException(localizable17, objArray26);
        org.apache.commons.math.MathException mathException28 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray29 = mathException28.getArguments();
        java.lang.Throwable[] throwableArray30 = mathException28.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException31 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable17, (java.lang.Object[]) throwableArray30);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException32 = new org.apache.commons.math.MaxIterationsExceededException((-1), localizable6, (java.lang.Object[]) throwableArray30);
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException37 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable33, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable38 = numberIsTooSmallException37.getGeneralPattern();
        java.lang.Number number39 = null;
        java.lang.Number number40 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException42 = new org.apache.commons.math.exception.OutOfRangeException(localizable38, number39, number40, (java.lang.Number) 10);
        org.apache.commons.math.MathException mathException43 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException42);
        org.apache.commons.math.ConvergenceException convergenceException44 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException42);
        java.lang.Number number45 = outOfRangeException42.getLo();
        java.lang.Number number46 = outOfRangeException42.getLo();
        java.lang.Number number47 = outOfRangeException42.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable48 = outOfRangeException42.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable49 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException53 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable49, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable54 = numberIsTooSmallException53.getGeneralPattern();
        java.lang.Number number55 = null;
        java.lang.Number number56 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException58 = new org.apache.commons.math.exception.OutOfRangeException(localizable54, number55, number56, (java.lang.Number) 10);
        org.apache.commons.math.MathException mathException59 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException58);
        java.lang.Number number60 = outOfRangeException58.getHi();
        java.lang.Throwable[] throwableArray61 = outOfRangeException58.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException62 = new org.apache.commons.math.ConvergenceException(localizable48, (java.lang.Object[]) throwableArray61);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException64 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable48, (java.lang.Number) 100);
        org.apache.commons.math.MathException mathException65 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable66 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException70 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable66, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable71 = numberIsTooSmallException70.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException75 = new org.apache.commons.math.exception.OutOfRangeException(localizable71, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException76 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray77 = mathException76.getArguments();
        java.lang.Throwable[] throwableArray78 = mathException76.getSuppressed();
        org.apache.commons.math.MathException mathException79 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException65, localizable71, (java.lang.Object[]) throwableArray78);
        org.apache.commons.math.MathException mathException81 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray82 = mathException81.getArguments();
        java.lang.Throwable[] throwableArray83 = mathException81.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException84 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException65, "", (java.lang.Object[]) throwableArray83);
        java.lang.String str85 = convergenceException84.getPattern();
        java.lang.Object[] objArray86 = convergenceException84.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException87 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable48, objArray86);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException88 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, objArray86);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNotNull(throwableArray24);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(throwableArray30);
        org.junit.Assert.assertTrue("'" + localizable38 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable38.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNull(number45);
        org.junit.Assert.assertNull(number46);
        org.junit.Assert.assertNull(number47);
        org.junit.Assert.assertTrue("'" + localizable48 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable48.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable54 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable54.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + number60 + "' != '" + 10 + "'", number60.equals(10));
        org.junit.Assert.assertNotNull(throwableArray61);
        org.junit.Assert.assertTrue("'" + localizable71 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable71.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray77);
        org.junit.Assert.assertNotNull(throwableArray78);
        org.junit.Assert.assertNotNull(objArray82);
        org.junit.Assert.assertNotNull(throwableArray83);
        org.junit.Assert.assertTrue("'" + str85 + "' != '" + "" + "'", str85.equals(""));
        org.junit.Assert.assertNotNull(objArray86);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        double double1 = org.apache.commons.math.util.FastMath.ulp(45.707229400630666d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.105427357601002E-15d + "'", double1 == 7.105427357601002E-15d);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        double double1 = org.apache.commons.math.util.FastMath.tanh(5.916079783099616d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999854659974842d + "'", double1 == 0.9999854659974842d);
    }

//    @Test
//    public void test061() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test061");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextCauchy(0.0d, (double) 32);
//        double double6 = randomDataImpl0.nextChiSquare((double) '4');
//        double double8 = randomDataImpl0.nextT(0.37062698554713475d);
//        try {
//            int int12 = randomDataImpl0.nextHypergeometric((int) '4', 7, 100);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100 is larger than the maximum (52): sample size (100) must be less than or equal to population size (52)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-45.2007547962882d) + "'", double4 == (-45.2007547962882d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 59.585320764727946d + "'", double6 == 59.585320764727946d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-9777.132518314937d) + "'", double8 == (-9777.132518314937d));
//    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.718281828459045d + "'", double1 == 2.718281828459045d);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        int int4 = randomDataImpl0.nextHypergeometric(10, 0, 0);
        try {
            long long7 = randomDataImpl0.nextLong((long) 90, 0L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 90 is larger than, or equal to, the maximum (0): lower bound (90) must be strictly less than upper bound (0)");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        int int2 = org.apache.commons.math.util.FastMath.max(0, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(99.99999999999999d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.010050166663333096d + "'", double1 == 0.010050166663333096d);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0L, (java.lang.Number) 0.0f, false);
        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException3);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (short) 0, (java.lang.Number) (short) 0, true);
        java.lang.Number number4 = numberIsTooSmallException3.getArgument();
        java.lang.Object[] objArray5 = numberIsTooSmallException3.getArguments();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0L, (java.lang.Number) 0.0f, false);
        java.lang.Object[] objArray11 = numberIsTooLargeException10.getArguments();
        java.lang.Throwable[] throwableArray12 = numberIsTooLargeException10.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException3, "2cc4bca353b0d36733d55b2ff91bbb544b5", (java.lang.Object[]) throwableArray12);
        java.lang.Number number14 = numberIsTooSmallException3.getMin();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (short) 0 + "'", number4.equals((short) 0));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + (short) 0 + "'", number14.equals((short) 0));
    }

//    @Test
//    public void test068() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test068");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (byte) 0, 3.141592653589793d);
//        java.lang.String str5 = randomDataImpl0.nextHexString(52);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl9 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 97L, (double) (short) 1, (double) (byte) 0);
//        double double11 = normalDistributionImpl9.inverseCumulativeProbability(0.5765158901134363d);
//        double double12 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl9);
//        int[] intArray15 = randomDataImpl0.nextPermutation(35, (int) (byte) 10);
//        try {
//            java.lang.String str17 = randomDataImpl0.nextHexString((int) (byte) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): length (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.6303962904277965d + "'", double3 == 0.6303962904277965d);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "b2b0d4a240a4fa24ffdf8e6d3a7a3e2bc051cecffa1d788d1488" + "'", str5.equals("b2b0d4a240a4fa24ffdf8e6d3a7a3e2bc051cecffa1d788d1488"));
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 97.19298818676732d + "'", double11 == 97.19298818676732d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 95.79923816922765d + "'", double12 == 95.79923816922765d);
//        org.junit.Assert.assertNotNull(intArray15);
//    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.302585092994046d + "'", double1 == 2.302585092994046d);
    }

//    @Test
//    public void test070() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test070");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 97L, (double) (short) 1, (double) (byte) 0);
//        double double4 = normalDistributionImpl3.sample();
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 96.33889104081075d + "'", double4 == 96.33889104081075d);
//    }

//    @Test
//    public void test071() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test071");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextCauchy(0.0d, (double) 32);
//        double double6 = randomDataImpl0.nextExponential(359.1342053695754d);
//        randomDataImpl0.reSeedSecure((long) (short) 1);
//        double double10 = randomDataImpl0.nextT(57.29577951308232d);
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeed();
//        double double15 = randomDataImpl0.nextUniform(0.0d, 22.835055624293666d);
//        double double17 = randomDataImpl0.nextExponential(14.15426224147926d);
//        try {
//            int int20 = randomDataImpl0.nextZipf((-1), (double) 0.0f);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): dimension (-1)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-38.52387533547908d) + "'", double4 == (-38.52387533547908d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 402.8726361933055d + "'", double6 == 402.8726361933055d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.6777646619108117d + "'", double10 == 0.6777646619108117d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 5.042372266005412d + "'", double15 == 5.042372266005412d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.19083537001642306d + "'", double17 == 0.19083537001642306d);
//    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.6843968673252286d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.815959496133888d + "'", double1 == 0.815959496133888d);
    }

//    @Test
//    public void test073() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test073");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextCauchy(0.0d, (double) 32);
//        double double6 = randomDataImpl0.nextExponential(359.1342053695754d);
//        randomDataImpl0.reSeedSecure((long) (short) 1);
//        double double10 = randomDataImpl0.nextT(57.29577951308232d);
//        randomDataImpl0.reSeed((long) (short) -1);
//        randomDataImpl0.reSeed();
//        double double15 = randomDataImpl0.nextT(27.68855530164479d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-39.23748143647286d) + "'", double4 == (-39.23748143647286d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 102.78180012791051d + "'", double6 == 102.78180012791051d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.3107611006663085d + "'", double10 == 3.3107611006663085d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-0.7921545057154455d) + "'", double15 == (-0.7921545057154455d));
//    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        double double1 = org.apache.commons.math.util.FastMath.ceil(2.732900526423743d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        double double1 = org.apache.commons.math.util.FastMath.acos(30.769482320627947d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(6.164682348792344E11d, 3.802660857303527d, 0.0d, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: maximal number of iterations (0) exceeded");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (short) 100);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 100L + "'", long1 == 100L);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.8326184616337932d, 113.65114113802746d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getSpecificPattern();
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException4);
        java.lang.String str7 = mathException6.getPattern();
        org.junit.Assert.assertNull(localizable5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "{0}" + "'", str7.equals("{0}"));
    }

//    @Test
//    public void test080() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test080");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) (short) 1);
//        double double4 = normalDistributionImpl2.cumulativeProbability((-0.8427007929497151d));
//        double double5 = normalDistributionImpl2.sample();
//        double double6 = normalDistributionImpl2.getMean();
//        double double7 = normalDistributionImpl2.getStandardDeviation();
//        try {
//            double double9 = normalDistributionImpl2.inverseCumulativeProbability(113.65114113802746d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 113.651 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.19969790180335623d + "'", double4 == 0.19969790180335623d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.2348808880420534d) + "'", double5 == (-1.2348808880420534d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
//    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        int int4 = randomDataImpl0.nextHypergeometric(10, 0, 0);
        randomDataImpl0.reSeed();
        randomDataImpl0.reSeedSecure((long) 'a');
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (short) 0, (java.lang.Number) (short) 0, true);
        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException3);
        java.lang.Number number5 = numberIsTooSmallException3.getMin();
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException3.getSpecificPattern();
        java.lang.Object[] objArray7 = numberIsTooSmallException3.getArguments();
        boolean boolean8 = numberIsTooSmallException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (short) 0 + "'", number5.equals((short) 0));
        org.junit.Assert.assertNull(localizable6);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getGeneralPattern();
        java.lang.Number number6 = null;
        java.lang.Number number7 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException9 = new org.apache.commons.math.exception.OutOfRangeException(localizable5, number6, number7, (java.lang.Number) 10);
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException9);
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException9);
        java.lang.Number number12 = outOfRangeException9.getLo();
        java.lang.Number number13 = outOfRangeException9.getLo();
        java.lang.Number number14 = outOfRangeException9.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable15 = outOfRangeException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException21 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable17, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable22 = numberIsTooSmallException21.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException26 = new org.apache.commons.math.exception.OutOfRangeException(localizable22, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable28 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException32 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable28, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable33 = numberIsTooSmallException32.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException37 = new org.apache.commons.math.exception.OutOfRangeException(localizable33, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException38 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray39 = mathException38.getArguments();
        java.lang.Throwable[] throwableArray40 = mathException38.getSuppressed();
        org.apache.commons.math.MathException mathException41 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException27, localizable33, (java.lang.Object[]) throwableArray40);
        java.lang.Object[] objArray42 = null;
        org.apache.commons.math.MathException mathException43 = new org.apache.commons.math.MathException(localizable33, objArray42);
        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray45 = mathException44.getArguments();
        java.lang.Throwable[] throwableArray46 = mathException44.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException47 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable33, (java.lang.Object[]) throwableArray46);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException48 = new org.apache.commons.math.MaxIterationsExceededException((-1), localizable22, (java.lang.Object[]) throwableArray46);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException49 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable15, (java.lang.Object[]) throwableArray46);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException53 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable15, (java.lang.Number) 2.091233300638824d, (java.lang.Number) 4.434659205310982d, false);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertNull(number13);
        org.junit.Assert.assertNull(number14);
        org.junit.Assert.assertTrue("'" + localizable15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable15.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable22.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizable33 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable33.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertNotNull(throwableArray40);
        org.junit.Assert.assertNotNull(objArray45);
        org.junit.Assert.assertNotNull(throwableArray46);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        double double1 = org.apache.commons.math.util.FastMath.abs(8.83139705388539E-11d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.83139705388539E-11d + "'", double1 == 8.83139705388539E-11d);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        double double2 = org.apache.commons.math.util.FastMath.pow(20.999999999999996d, 16.72650105839174d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.3064789982214084E22d + "'", double2 == 1.3064789982214084E22d);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(258.23329197307703d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.5070211831940385d + "'", double1 == 4.5070211831940385d);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0.48670120172084486d, (java.lang.Number) (-4.667786224710645d), false);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable1, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException5.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException16 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable12, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable17 = numberIsTooSmallException16.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException21 = new org.apache.commons.math.exception.OutOfRangeException(localizable17, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray23 = mathException22.getArguments();
        java.lang.Throwable[] throwableArray24 = mathException22.getSuppressed();
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException11, localizable17, (java.lang.Object[]) throwableArray24);
        java.lang.Object[] objArray26 = null;
        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException(localizable17, objArray26);
        org.apache.commons.math.MathException mathException28 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray29 = mathException28.getArguments();
        java.lang.Throwable[] throwableArray30 = mathException28.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException31 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable17, (java.lang.Object[]) throwableArray30);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException32 = new org.apache.commons.math.MaxIterationsExceededException((-1), localizable6, (java.lang.Object[]) throwableArray30);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException36 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (short) 0, (java.lang.Number) (short) 0, true);
        java.lang.Throwable[] throwableArray37 = numberIsTooSmallException36.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException38 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, (java.lang.Object[]) throwableArray37);
        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable40 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException44 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable40, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable45 = numberIsTooSmallException44.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException49 = new org.apache.commons.math.exception.OutOfRangeException(localizable45, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray51 = mathException50.getArguments();
        java.lang.Throwable[] throwableArray52 = mathException50.getSuppressed();
        org.apache.commons.math.MathException mathException53 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException39, localizable45, (java.lang.Object[]) throwableArray52);
        org.apache.commons.math.exception.util.Localizable localizable54 = null;
        org.apache.commons.math.MathException mathException56 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable57 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException61 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable57, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable62 = numberIsTooSmallException61.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException66 = new org.apache.commons.math.exception.OutOfRangeException(localizable62, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException67 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray68 = mathException67.getArguments();
        java.lang.Throwable[] throwableArray69 = mathException67.getSuppressed();
        org.apache.commons.math.MathException mathException70 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException56, localizable62, (java.lang.Object[]) throwableArray69);
        org.apache.commons.math.ConvergenceException convergenceException71 = new org.apache.commons.math.ConvergenceException("hi!", (java.lang.Object[]) throwableArray69);
        org.apache.commons.math.ConvergenceException convergenceException72 = new org.apache.commons.math.ConvergenceException(localizable54, (java.lang.Object[]) throwableArray69);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException73 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, localizable45, (java.lang.Object[]) throwableArray69);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException77 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable6, (java.lang.Number) 688.4375642837603d, (java.lang.Number) 3.3107611006663085d, false);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNotNull(throwableArray24);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(throwableArray30);
        org.junit.Assert.assertNotNull(throwableArray37);
        org.junit.Assert.assertTrue("'" + localizable45 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable45.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray51);
        org.junit.Assert.assertNotNull(throwableArray52);
        org.junit.Assert.assertTrue("'" + localizable62 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable62.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray68);
        org.junit.Assert.assertNotNull(throwableArray69);
    }

//    @Test
//    public void test089() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test089");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        int int4 = randomDataImpl0.nextInt(75, (int) 'a');
//        double double7 = randomDataImpl0.nextCauchy(0.8746788966462123d, 28.782429690343378d);
//        try {
//            long long10 = randomDataImpl0.nextSecureLong((long) 100, (-1L));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100 is larger than, or equal to, the maximum (-1): lower bound (100) must be strictly less than upper bound (-1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 85 + "'", int4 == 85);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-27.124569074021622d) + "'", double7 == (-27.124569074021622d));
//    }

//    @Test
//    public void test090() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test090");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextCauchy(0.0d, (double) 32);
//        int int7 = randomDataImpl0.nextSecureInt(0, (int) (short) 10);
//        double double10 = randomDataImpl0.nextWeibull(0.6843968673252286d, (double) 1L);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-4.758361981209243d) + "'", double4 == (-4.758361981209243d));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 5 + "'", int7 == 5);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.6565482783318198d + "'", double10 == 0.6565482783318198d);
//    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        double double1 = org.apache.commons.math.util.FastMath.cos(33.16711342771793d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.1794138146979451d) + "'", double1 == (-0.1794138146979451d));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 4L, (-1.0d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.8157749899217608d + "'", double2 == 1.8157749899217608d);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((-5.221119010901584d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-5.2211190109015835d) + "'", double1 == (-5.2211190109015835d));
    }

//    @Test
//    public void test094() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test094");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextCauchy(0.0d, (double) 32);
//        double double6 = randomDataImpl0.nextExponential(359.1342053695754d);
//        randomDataImpl0.reSeedSecure((long) (short) 1);
//        double double10 = randomDataImpl0.nextT(57.29577951308232d);
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeed((long) (byte) 0);
//        org.apache.commons.math.distribution.ContinuousDistribution continuousDistribution14 = null;
//        try {
//            double double15 = randomDataImpl0.nextInversionDeviate(continuousDistribution14);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-12.77361276874442d) + "'", double4 == (-12.77361276874442d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 327.5842668390238d + "'", double6 == 327.5842668390238d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.2595848885891867d + "'", double10 == 1.2595848885891867d);
//    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        double double1 = org.apache.commons.math.util.FastMath.ulp(4.5070211831940385d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.881784197001252E-16d + "'", double1 == 8.881784197001252E-16d);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        double double1 = org.apache.commons.math.util.FastMath.exp(31.711141538384357d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.91525927214798E13d + "'", double1 == 5.91525927214798E13d);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        double double1 = org.apache.commons.math.util.FastMath.floor(1.5707963267948966d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

//    @Test
//    public void test098() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test098");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextCauchy(0.0d, (double) 32);
//        double double6 = randomDataImpl0.nextExponential(359.1342053695754d);
//        randomDataImpl0.reSeedSecure((long) (short) 1);
//        double double10 = randomDataImpl0.nextT(57.29577951308232d);
//        randomDataImpl0.reSeed((long) (short) -1);
//        randomDataImpl0.reSeedSecure(12L);
//        try {
//            double double17 = randomDataImpl0.nextBeta((-1.0d), (double) 52L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.5 p = 0.269");
//        } catch (org.apache.commons.math.exception.MathUserException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-13.627223369960152d) + "'", double4 == (-13.627223369960152d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 719.8093822604984d + "'", double6 == 719.8093822604984d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.3725021988139667d) + "'", double10 == (-1.3725021988139667d));
//    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (short) 0, (java.lang.Number) 0.8813735870195429d, false);
        java.lang.Number number4 = numberIsTooSmallException3.getMin();
        java.lang.Number number5 = numberIsTooSmallException3.getMin();
        boolean boolean6 = numberIsTooSmallException3.getBoundIsAllowed();
        boolean boolean7 = numberIsTooSmallException3.getBoundIsAllowed();
        boolean boolean8 = numberIsTooSmallException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.8813735870195429d + "'", number4.equals(0.8813735870195429d));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.8813735870195429d + "'", number5.equals(0.8813735870195429d));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.5845089524363901d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.01020160572739794d + "'", double1 == 0.01020160572739794d);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(359.1342053695754d, 4.5070211831940385d, (-44.0d), 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: maximal number of iterations (0) exceeded");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 5);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 5.0f + "'", float1 == 5.0f);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-7.231717743255291d), number1, false);
    }

//    @Test
//    public void test104() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test104");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (byte) 0, 3.141592653589793d);
//        randomDataImpl0.reSeedSecure();
//        int[] intArray7 = randomDataImpl0.nextPermutation((int) (byte) 100, (int) (byte) 1);
//        double double10 = randomDataImpl0.nextF((double) 100.0f, 100.0d);
//        try {
//            long long13 = randomDataImpl0.nextLong((long) (byte) 100, 1L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100 is larger than, or equal to, the maximum (1): lower bound (100) must be strictly less than upper bound (1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.2287123720270077d + "'", double3 == 1.2287123720270077d);
//        org.junit.Assert.assertNotNull(intArray7);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.9868508977881495d + "'", double10 == 0.9868508977881495d);
//    }

//    @Test
//    public void test105() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test105");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextCauchy(0.0d, (double) 32);
//        double double6 = randomDataImpl0.nextExponential(359.1342053695754d);
//        randomDataImpl0.reSeedSecure((long) (short) 1);
//        double double10 = randomDataImpl0.nextT(57.29577951308232d);
//        double double13 = randomDataImpl0.nextCauchy(10.0d, (double) 32.0f);
//        long long16 = randomDataImpl0.nextLong(10L, 25L);
//        randomDataImpl0.reSeed();
//        long long19 = randomDataImpl0.nextPoisson(0.9457323514842972d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-8.721991427098066d) + "'", double4 == (-8.721991427098066d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 35.56185506115351d + "'", double6 == 35.56185506115351d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-0.016670486925536795d) + "'", double10 == (-0.016670486925536795d));
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 315.9151403123994d + "'", double13 == 315.9151403123994d);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 23L + "'", long16 == 23L);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1L + "'", long19 == 1L);
//    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(2.200736691117263E34d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.543932965884816E-35d + "'", double1 == 4.543932965884816E-35d);
    }

//    @Test
//    public void test107() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test107");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextCauchy(0.0d, (double) 32);
//        java.lang.String str6 = randomDataImpl0.nextHexString(32);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-9.393183240996173d) + "'", double4 == (-9.393183240996173d));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "940d321a94e952fe32618958c0098603" + "'", str6.equals("940d321a94e952fe32618958c0098603"));
//    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0L, (java.lang.Number) 0.0f, false);
        java.lang.Class<?> wildcardClass4 = numberIsTooLargeException3.getClass();
        java.lang.Object[] objArray5 = numberIsTooLargeException3.getArguments();
        boolean boolean6 = numberIsTooLargeException3.getBoundIsAllowed();
        java.lang.Number number7 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 0.0f + "'", number7.equals(0.0f));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.11575187101581663d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.11601052772548931d + "'", double1 == 0.11601052772548931d);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable1, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException5.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray12 = mathException11.getArguments();
        java.lang.Throwable[] throwableArray13 = mathException11.getSuppressed();
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException0, localizable6, (java.lang.Object[]) throwableArray13);
        java.lang.Object[] objArray15 = null;
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException(localizable6, objArray15);
        java.lang.Number number18 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException20 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable6, (java.lang.Number) 2.718281828459045d, number18, false);
        java.lang.Number number22 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException24 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 25L, number22, (java.lang.Number) (short) 0);
        java.lang.Throwable[] throwableArray25 = outOfRangeException24.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException26 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, (java.lang.Object[]) throwableArray25);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertNotNull(throwableArray25);
    }

//    @Test
//    public void test111() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test111");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextCauchy(0.0d, (double) 32);
//        double double6 = randomDataImpl0.nextExponential(359.1342053695754d);
//        randomDataImpl0.reSeedSecure((long) (short) 1);
//        double double10 = randomDataImpl0.nextT(57.29577951308232d);
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeed();
//        double double15 = randomDataImpl0.nextUniform(0.0d, 22.835055624293666d);
//        double double17 = randomDataImpl0.nextExponential(14.15426224147926d);
//        double double20 = randomDataImpl0.nextCauchy(0.9999989341738639d, (double) (byte) 100);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-23.42761930433189d) + "'", double4 == (-23.42761930433189d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 416.6499652502857d + "'", double6 == 416.6499652502857d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.1874577780127846d + "'", double10 == 1.1874577780127846d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 6.828176707102269d + "'", double15 == 6.828176707102269d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.3677943446028048d + "'", double17 == 0.3677943446028048d);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 94.57087667355376d + "'", double20 == 94.57087667355376d);
//    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 32.00000000000001d, (java.lang.Number) 2.7528819228562695d, true);
        java.lang.Number number4 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 2.7528819228562695d + "'", number4.equals(2.7528819228562695d));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.MathException mathException3 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable9 = numberIsTooSmallException8.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException13 = new org.apache.commons.math.exception.OutOfRangeException(localizable9, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray15 = mathException14.getArguments();
        java.lang.Throwable[] throwableArray16 = mathException14.getSuppressed();
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException3, localizable9, (java.lang.Object[]) throwableArray16);
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException("hi!", (java.lang.Object[]) throwableArray16);
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException("2cc4bca353b0d36733d55b2ff91bbb544b5", (java.lang.Object[]) throwableArray16);
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException(localizable0, (java.lang.Object[]) throwableArray16);
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(throwableArray16);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        double double1 = org.apache.commons.math.util.FastMath.expm1(54.0280840833561d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.911379268997749E23d + "'", double1 == 2.911379268997749E23d);
    }

//    @Test
//    public void test115() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test115");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (byte) 0, 3.141592653589793d);
//        java.lang.String str5 = randomDataImpl0.nextHexString(52);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl9 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 97L, (double) (short) 1, (double) (byte) 0);
//        double double11 = normalDistributionImpl9.inverseCumulativeProbability(0.5765158901134363d);
//        double double12 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl9);
//        int[] intArray15 = randomDataImpl0.nextPermutation(35, (int) (byte) 10);
//        java.lang.String str17 = randomDataImpl0.nextHexString(35);
//        long long19 = randomDataImpl0.nextPoisson(45.707229400630666d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.9709242244663496d + "'", double3 == 0.9709242244663496d);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "9735c17cf9ecebd176933a5d5ecc7a466bbebe40cc55b8e78b36" + "'", str5.equals("9735c17cf9ecebd176933a5d5ecc7a466bbebe40cc55b8e78b36"));
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 97.19298818676732d + "'", double11 == 97.19298818676732d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 97.76167459024933d + "'", double12 == 97.76167459024933d);
//        org.junit.Assert.assertNotNull(intArray15);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "627361b67d16b00110c1ddca21777ffc72f" + "'", str17.equals("627361b67d16b00110c1ddca21777ffc72f"));
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 48L + "'", long19 == 48L);
//    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 25L, number1, (java.lang.Number) (short) 0);
        java.lang.Throwable[] throwableArray4 = outOfRangeException3.getSuppressed();
        java.lang.String str5 = outOfRangeException3.toString();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.OutOfRangeException: 25 out of [null, 0] range" + "'", str5.equals("org.apache.commons.math.exception.OutOfRangeException: 25 out of [null, 0] range"));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        double double1 = org.apache.commons.math.util.FastMath.ceil(1.5707963267948966d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getGeneralPattern();
        java.lang.Number number6 = null;
        java.lang.Number number7 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException9 = new org.apache.commons.math.exception.OutOfRangeException(localizable5, number6, number7, (java.lang.Number) 10);
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException9);
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException9);
        java.lang.Number number12 = outOfRangeException9.getLo();
        java.lang.Number number13 = outOfRangeException9.getLo();
        java.lang.Number number14 = outOfRangeException9.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable15 = outOfRangeException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException21 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable17, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable22 = numberIsTooSmallException21.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException26 = new org.apache.commons.math.exception.OutOfRangeException(localizable22, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable28 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException32 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable28, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable33 = numberIsTooSmallException32.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException37 = new org.apache.commons.math.exception.OutOfRangeException(localizable33, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException38 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray39 = mathException38.getArguments();
        java.lang.Throwable[] throwableArray40 = mathException38.getSuppressed();
        org.apache.commons.math.MathException mathException41 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException27, localizable33, (java.lang.Object[]) throwableArray40);
        java.lang.Object[] objArray42 = null;
        org.apache.commons.math.MathException mathException43 = new org.apache.commons.math.MathException(localizable33, objArray42);
        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray45 = mathException44.getArguments();
        java.lang.Throwable[] throwableArray46 = mathException44.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException47 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable33, (java.lang.Object[]) throwableArray46);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException48 = new org.apache.commons.math.MaxIterationsExceededException((-1), localizable22, (java.lang.Object[]) throwableArray46);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException49 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable15, (java.lang.Object[]) throwableArray46);
        org.apache.commons.math.exception.util.Localizable localizable50 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException54 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable50, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable55 = numberIsTooSmallException54.getGeneralPattern();
        java.lang.Throwable[] throwableArray56 = numberIsTooSmallException54.getSuppressed();
        java.lang.Number number57 = numberIsTooSmallException54.getMin();
        mathIllegalArgumentException49.addSuppressed((java.lang.Throwable) numberIsTooSmallException54);
        java.lang.Number number59 = numberIsTooSmallException54.getMin();
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertNull(number13);
        org.junit.Assert.assertNull(number14);
        org.junit.Assert.assertTrue("'" + localizable15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable15.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable22.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizable33 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable33.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertNotNull(throwableArray40);
        org.junit.Assert.assertNotNull(objArray45);
        org.junit.Assert.assertNotNull(throwableArray46);
        org.junit.Assert.assertTrue("'" + localizable55 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable55.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(throwableArray56);
        org.junit.Assert.assertTrue("'" + number57 + "' != '" + 10L + "'", number57.equals(10L));
        org.junit.Assert.assertTrue("'" + number59 + "' != '" + 10L + "'", number59.equals(10L));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (short) 100, (long) (short) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        double double1 = org.apache.commons.math.util.FastMath.acos(200.2390918710703d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.5772156649015329d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.9748169799074695d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8275991692762474d + "'", double1 == 0.8275991692762474d);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getGeneralPattern();
        java.lang.Number number6 = null;
        java.lang.Number number7 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException9 = new org.apache.commons.math.exception.OutOfRangeException(localizable5, number6, number7, (java.lang.Number) 10);
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException9);
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException9);
        java.lang.Number number12 = outOfRangeException9.getLo();
        java.lang.Number number13 = outOfRangeException9.getLo();
        java.lang.Number number14 = outOfRangeException9.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable15 = outOfRangeException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException20 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable16, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable21 = numberIsTooSmallException20.getGeneralPattern();
        java.lang.Number number22 = null;
        java.lang.Number number23 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException25 = new org.apache.commons.math.exception.OutOfRangeException(localizable21, number22, number23, (java.lang.Number) 10);
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException25);
        java.lang.Number number27 = outOfRangeException25.getHi();
        java.lang.Throwable[] throwableArray28 = outOfRangeException25.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException(localizable15, (java.lang.Object[]) throwableArray28);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException33 = new org.apache.commons.math.exception.OutOfRangeException(localizable15, (java.lang.Number) (-0.8813735870195429d), (java.lang.Number) (byte) 0, (java.lang.Number) 1.3765887979465332d);
        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable38 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException42 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable38, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable43 = numberIsTooSmallException42.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException47 = new org.apache.commons.math.exception.OutOfRangeException(localizable43, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException48 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray49 = mathException48.getArguments();
        java.lang.Throwable[] throwableArray50 = mathException48.getSuppressed();
        org.apache.commons.math.MathException mathException51 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException37, localizable43, (java.lang.Object[]) throwableArray50);
        org.apache.commons.math.MathException mathException53 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray54 = mathException53.getArguments();
        java.lang.Throwable[] throwableArray55 = mathException53.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException56 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException37, "", (java.lang.Object[]) throwableArray55);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException57 = new org.apache.commons.math.MaxIterationsExceededException(0, "hi!", (java.lang.Object[]) throwableArray55);
        org.apache.commons.math.MathException mathException58 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException33, "", (java.lang.Object[]) throwableArray55);
        org.apache.commons.math.exception.util.Localizable localizable59 = outOfRangeException33.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertNull(number13);
        org.junit.Assert.assertNull(number14);
        org.junit.Assert.assertTrue("'" + localizable15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable15.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable21.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + number27 + "' != '" + 10 + "'", number27.equals(10));
        org.junit.Assert.assertNotNull(throwableArray28);
        org.junit.Assert.assertTrue("'" + localizable43 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable43.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertNotNull(throwableArray50);
        org.junit.Assert.assertNotNull(objArray54);
        org.junit.Assert.assertNotNull(throwableArray55);
        org.junit.Assert.assertTrue("'" + localizable59 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable59.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        double double1 = org.apache.commons.math.util.FastMath.cos(47.04026509063007d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9965054908341544d) + "'", double1 == (-0.9965054908341544d));
    }

//    @Test
//    public void test125() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test125");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (byte) 0, 3.141592653589793d);
//        randomDataImpl0.reSeedSecure();
//        long long6 = randomDataImpl0.nextPoisson(1.0453603017892203d);
//        long long8 = randomDataImpl0.nextPoisson(113.65114113802746d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.7158642939653999d + "'", double3 == 1.7158642939653999d);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 104L + "'", long8 == 104L);
//    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 97L, (double) (short) 1, (double) (byte) 0);
        normalDistributionImpl3.reseedRandomGenerator((-1L));
        normalDistributionImpl3.reseedRandomGenerator(100L);
        double double9 = normalDistributionImpl3.cumulativeProbability(0.0d);
        double double12 = normalDistributionImpl3.cumulativeProbability(1.7453292519943295d, 83.65140561237826d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
    }

//    @Test
//    public void test127() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test127");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextCauchy(0.0d, (double) 32);
//        double double6 = randomDataImpl0.nextExponential(359.1342053695754d);
//        randomDataImpl0.reSeedSecure((long) (short) 1);
//        double double10 = randomDataImpl0.nextT(57.29577951308232d);
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeed();
//        double double15 = randomDataImpl0.nextUniform(0.0d, 22.835055624293666d);
//        randomDataImpl0.reSeedSecure();
//        try {
//            long long19 = randomDataImpl0.nextLong(5L, (long) (byte) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 5 is larger than, or equal to, the maximum (0): lower bound (5) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-2.5406840104255672d) + "'", double4 == (-2.5406840104255672d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 400.0742590439258d + "'", double6 == 400.0742590439258d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.9069759046718884d + "'", double10 == 0.9069759046718884d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 10.845725043180758d + "'", double15 == 10.845725043180758d);
//    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 11L, (float) 81);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 81.0f + "'", float2 == 81.0f);
    }

//    @Test
//    public void test129() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test129");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextCauchy(0.0d, (double) 32);
//        double double6 = randomDataImpl0.nextExponential(359.1342053695754d);
//        randomDataImpl0.reSeedSecure((long) (short) 1);
//        double double10 = randomDataImpl0.nextT(57.29577951308232d);
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeed();
//        double double15 = randomDataImpl0.nextUniform(0.0d, 22.835055624293666d);
//        java.lang.String str17 = randomDataImpl0.nextSecureHexString((int) '#');
//        double double20 = randomDataImpl0.nextBeta(3.111443690220943d, 0.48670120172084486d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-2.885362261474414d) + "'", double4 == (-2.885362261474414d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 93.43079878226985d + "'", double6 == 93.43079878226985d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-0.03224884652631809d) + "'", double10 == (-0.03224884652631809d));
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 10.751627224624485d + "'", double15 == 10.751627224624485d);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "02373d938d928ddb3c69545f922bf0ef419" + "'", str17.equals("02373d938d928ddb3c69545f922bf0ef419"));
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.9886059519047611d + "'", double20 == 0.9886059519047611d);
//    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 4.641588833612778d, (java.lang.Number) 0.3677943446028048d, (java.lang.Number) (-115.82233084817821d));
    }

//    @Test
//    public void test131() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test131");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextCauchy(0.0d, (double) 32);
//        double double6 = randomDataImpl0.nextExponential(359.1342053695754d);
//        randomDataImpl0.reSeedSecure((long) (short) 1);
//        double double10 = randomDataImpl0.nextT(57.29577951308232d);
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeed();
//        double double15 = randomDataImpl0.nextUniform(0.0d, 22.835055624293666d);
//        randomDataImpl0.reSeedSecure();
//        double double18 = randomDataImpl0.nextChiSquare(1.3112627113980244d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-3.668010642858d) + "'", double4 == (-3.668010642858d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 375.2362071482014d + "'", double6 == 375.2362071482014d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.08259963121850752d + "'", double10 == 0.08259963121850752d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 10.5920710748356d + "'", double15 == 10.5920710748356d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0021778709982886463d + "'", double18 == 0.0021778709982886463d);
//    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        double double2 = org.apache.commons.math.util.FastMath.atan2((-0.8813735870195429d), 96.33889104081075d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.009148423745602654d) + "'", double2 == (-0.009148423745602654d));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) (-7.231717743255291d), number2, (java.lang.Number) 0.23860359374120596d);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0);
        int int2 = maxIterationsExceededException1.getMaxIterations();
        java.lang.Object[] objArray4 = null;
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException1, "hi!", objArray4);
        int int6 = maxIterationsExceededException1.getMaxIterations();
        int int7 = maxIterationsExceededException1.getMaxIterations();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.MathException mathException1 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray2 = mathException1.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException(localizable0, objArray2);
        java.lang.Class<?> wildcardClass4 = convergenceException3.getClass();
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getGeneralPattern();
        java.lang.Number number6 = null;
        java.lang.Number number7 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException9 = new org.apache.commons.math.exception.OutOfRangeException(localizable5, number6, number7, (java.lang.Number) 10);
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException9);
        java.lang.Number number11 = outOfRangeException9.getHi();
        java.lang.Number number12 = outOfRangeException9.getArgument();
        java.lang.Number number13 = outOfRangeException9.getArgument();
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 10 + "'", number11.equals(10));
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertNull(number13);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        double double1 = org.apache.commons.math.util.FastMath.cosh((-0.009148423745602654d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.000041847120375d + "'", double1 == 1.000041847120375d);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        double double1 = org.apache.commons.math.special.Gamma.digamma(23.20403525996744d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.1226234750635724d + "'", double1 == 3.1226234750635724d);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(4.571545345114974d, 0.5403023058681398d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.5715453451149735d + "'", double2 == 4.5715453451149735d);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        double double1 = org.apache.commons.math.special.Gamma.digamma((-0.42160788472003075d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7502736630619933d + "'", double1 == 0.7502736630619933d);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        double double1 = org.apache.commons.math.util.FastMath.cosh(28.64788975654116d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3822622382423977E12d + "'", double1 == 1.3822622382423977E12d);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        int int1 = org.apache.commons.math.util.FastMath.abs(75);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 75 + "'", int1 == 75);
    }

//    @Test
//    public void test143() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test143");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextCauchy(0.0d, (double) 32);
//        double double6 = randomDataImpl0.nextExponential(359.1342053695754d);
//        randomDataImpl0.reSeedSecure((long) (short) 1);
//        double double10 = randomDataImpl0.nextT(57.29577951308232d);
//        randomDataImpl0.reSeed();
//        int int14 = randomDataImpl0.nextZipf((int) (short) 1, 194.270024143189d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-2.3142439597819715d) + "'", double4 == (-2.3142439597819715d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 866.2367402105165d + "'", double6 == 866.2367402105165d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.14771103129377167d + "'", double10 == 0.14771103129377167d);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 0.3044465563407555d, (java.lang.Number) 806.4077649578195d, (java.lang.Number) 2.0988822915763574d);
        org.apache.commons.math.MathException mathException4 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable10 = numberIsTooSmallException9.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException14 = new org.apache.commons.math.exception.OutOfRangeException(localizable10, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray16 = mathException15.getArguments();
        java.lang.Throwable[] throwableArray17 = mathException15.getSuppressed();
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException4, localizable10, (java.lang.Object[]) throwableArray17);
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray20 = mathException19.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException(localizable10, objArray20);
        org.apache.commons.math.exception.util.Localizable localizable22 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException26 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable22, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable27 = numberIsTooSmallException26.getGeneralPattern();
        java.lang.Number number28 = null;
        java.lang.Number number29 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException31 = new org.apache.commons.math.exception.OutOfRangeException(localizable27, number28, number29, (java.lang.Number) 10);
        org.apache.commons.math.MathException mathException32 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException31);
        org.apache.commons.math.ConvergenceException convergenceException33 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException31);
        java.lang.Number number34 = outOfRangeException31.getLo();
        java.lang.Number number35 = outOfRangeException31.getLo();
        java.lang.Number number36 = outOfRangeException31.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable37 = outOfRangeException31.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable38 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException42 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable38, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable43 = numberIsTooSmallException42.getGeneralPattern();
        java.lang.Number number44 = null;
        java.lang.Number number45 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException47 = new org.apache.commons.math.exception.OutOfRangeException(localizable43, number44, number45, (java.lang.Number) 10);
        org.apache.commons.math.MathException mathException48 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException47);
        java.lang.Number number49 = outOfRangeException47.getHi();
        java.lang.Throwable[] throwableArray50 = outOfRangeException47.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException51 = new org.apache.commons.math.ConvergenceException(localizable37, (java.lang.Object[]) throwableArray50);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException55 = new org.apache.commons.math.exception.OutOfRangeException(localizable37, (java.lang.Number) (-0.8813735870195429d), (java.lang.Number) (byte) 0, (java.lang.Number) 1.3765887979465332d);
        org.apache.commons.math.MathException mathException59 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable60 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException64 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable60, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable65 = numberIsTooSmallException64.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException69 = new org.apache.commons.math.exception.OutOfRangeException(localizable65, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException70 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray71 = mathException70.getArguments();
        java.lang.Throwable[] throwableArray72 = mathException70.getSuppressed();
        org.apache.commons.math.MathException mathException73 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException59, localizable65, (java.lang.Object[]) throwableArray72);
        org.apache.commons.math.MathException mathException75 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray76 = mathException75.getArguments();
        java.lang.Throwable[] throwableArray77 = mathException75.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException78 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException59, "", (java.lang.Object[]) throwableArray77);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException79 = new org.apache.commons.math.MaxIterationsExceededException(0, "hi!", (java.lang.Object[]) throwableArray77);
        org.apache.commons.math.MathException mathException80 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException55, "", (java.lang.Object[]) throwableArray77);
        org.apache.commons.math.ConvergenceException convergenceException81 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3, localizable10, (java.lang.Object[]) throwableArray77);
        org.apache.commons.math.exception.util.Localizable localizable82 = convergenceException81.getGeneralPattern();
        java.lang.Throwable[] throwableArray83 = convergenceException81.getSuppressed();
        org.junit.Assert.assertTrue("'" + localizable10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable10.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertTrue("'" + localizable27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable27.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNull(number34);
        org.junit.Assert.assertNull(number35);
        org.junit.Assert.assertNull(number36);
        org.junit.Assert.assertTrue("'" + localizable37 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable37.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable43 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable43.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + number49 + "' != '" + 10 + "'", number49.equals(10));
        org.junit.Assert.assertNotNull(throwableArray50);
        org.junit.Assert.assertTrue("'" + localizable65 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable65.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray71);
        org.junit.Assert.assertNotNull(throwableArray72);
        org.junit.Assert.assertNotNull(objArray76);
        org.junit.Assert.assertNotNull(throwableArray77);
        org.junit.Assert.assertTrue("'" + localizable82 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable82.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(throwableArray83);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.0d, 0.6338492905650115d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.9E-324d + "'", double2 == 4.9E-324d);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        double double1 = org.apache.commons.math.util.FastMath.atan(1303.3950961665462d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.570029099875961d + "'", double1 == 1.570029099875961d);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        int int2 = org.apache.commons.math.util.FastMath.min((int) ' ', 3);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.7541797952357654d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(3.141592653589793d, (-102.95196627228174d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(61.174026178658316d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.016481144048456825d + "'", double1 == 0.016481144048456825d);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        double double1 = org.apache.commons.math.special.Erf.erf((-29.59362978710604d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

//    @Test
//    public void test152() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test152");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (byte) 0, 3.141592653589793d);
//        randomDataImpl0.reSeedSecure();
//        int[] intArray7 = randomDataImpl0.nextPermutation((int) (byte) 100, (int) (byte) 1);
//        double double10 = randomDataImpl0.nextCauchy(0.5845089524363901d, (double) 5L);
//        double double12 = randomDataImpl0.nextChiSquare(0.19969790180335623d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.08824254302930325d + "'", double3 == 0.08824254302930325d);
//        org.junit.Assert.assertNotNull(intArray7);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 6.929379091810299d + "'", double10 == 6.929379091810299d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 6.102543445376307E-4d + "'", double12 == 6.102543445376307E-4d);
//    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable1, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException5.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray12 = mathException11.getArguments();
        java.lang.Throwable[] throwableArray13 = mathException11.getSuppressed();
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException0, localizable6, (java.lang.Object[]) throwableArray13);
        java.lang.Object[] objArray15 = null;
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException(localizable6, objArray15);
        java.lang.Number number18 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException20 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable6, (java.lang.Number) 2.718281828459045d, number18, false);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException22 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable6, (java.lang.Number) (-14.118215865625046d));
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException30 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable26, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable31 = numberIsTooSmallException30.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException35 = new org.apache.commons.math.exception.OutOfRangeException(localizable31, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException36 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray37 = mathException36.getArguments();
        java.lang.Throwable[] throwableArray38 = mathException36.getSuppressed();
        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException25, localizable31, (java.lang.Object[]) throwableArray38);
        java.lang.Object[] objArray40 = null;
        org.apache.commons.math.MathException mathException41 = new org.apache.commons.math.MathException(localizable31, objArray40);
        org.apache.commons.math.exception.util.Localizable localizable42 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException46 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable42, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable47 = numberIsTooSmallException46.getGeneralPattern();
        java.lang.Number number48 = null;
        java.lang.Number number49 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException51 = new org.apache.commons.math.exception.OutOfRangeException(localizable47, number48, number49, (java.lang.Number) 10);
        org.apache.commons.math.MathException mathException52 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException51);
        org.apache.commons.math.ConvergenceException convergenceException53 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException51);
        java.lang.Number number54 = outOfRangeException51.getLo();
        java.lang.Number number55 = outOfRangeException51.getLo();
        java.lang.Number number56 = outOfRangeException51.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable57 = outOfRangeException51.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable58 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException62 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable58, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable63 = numberIsTooSmallException62.getGeneralPattern();
        java.lang.Number number64 = null;
        java.lang.Number number65 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException67 = new org.apache.commons.math.exception.OutOfRangeException(localizable63, number64, number65, (java.lang.Number) 10);
        org.apache.commons.math.MathException mathException68 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException67);
        java.lang.Number number69 = outOfRangeException67.getHi();
        java.lang.Throwable[] throwableArray70 = outOfRangeException67.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException71 = new org.apache.commons.math.ConvergenceException(localizable57, (java.lang.Object[]) throwableArray70);
        org.apache.commons.math.MathException mathException74 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable75 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException79 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable75, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable80 = numberIsTooSmallException79.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException84 = new org.apache.commons.math.exception.OutOfRangeException(localizable80, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException85 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray86 = mathException85.getArguments();
        java.lang.Throwable[] throwableArray87 = mathException85.getSuppressed();
        org.apache.commons.math.MathException mathException88 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException74, localizable80, (java.lang.Object[]) throwableArray87);
        org.apache.commons.math.MathException mathException90 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray91 = mathException90.getArguments();
        java.lang.Throwable[] throwableArray92 = mathException90.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException93 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException74, "", (java.lang.Object[]) throwableArray92);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException94 = new org.apache.commons.math.MaxIterationsExceededException(0, "hi!", (java.lang.Object[]) throwableArray92);
        org.apache.commons.math.MathException mathException95 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException41, localizable57, (java.lang.Object[]) throwableArray92);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException96 = new org.apache.commons.math.MaxIterationsExceededException(35, "346ff53c6dcf49c36e2607360894de97", (java.lang.Object[]) throwableArray92);
        org.apache.commons.math.ConvergenceException convergenceException97 = new org.apache.commons.math.ConvergenceException(localizable6, (java.lang.Object[]) throwableArray92);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertTrue("'" + localizable31 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable31.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertNotNull(throwableArray38);
        org.junit.Assert.assertTrue("'" + localizable47 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable47.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNull(number54);
        org.junit.Assert.assertNull(number55);
        org.junit.Assert.assertNull(number56);
        org.junit.Assert.assertTrue("'" + localizable57 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable57.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable63 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable63.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + number69 + "' != '" + 10 + "'", number69.equals(10));
        org.junit.Assert.assertNotNull(throwableArray70);
        org.junit.Assert.assertTrue("'" + localizable80 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable80.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray86);
        org.junit.Assert.assertNotNull(throwableArray87);
        org.junit.Assert.assertNotNull(objArray91);
        org.junit.Assert.assertNotNull(throwableArray92);
    }

//    @Test
//    public void test154() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test154");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (byte) 0, 3.141592653589793d);
//        randomDataImpl0.reSeedSecure();
//        long long6 = randomDataImpl0.nextPoisson(1.0453603017892203d);
//        try {
//            double double9 = randomDataImpl0.nextUniform(20.999999999999996d, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 21 is larger than, or equal to, the maximum (0): lower bound (21) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.739185648552271d + "'", double3 == 0.739185648552271d);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2L + "'", long6 == 2L);
//    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.MathException mathException3 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable9 = numberIsTooSmallException8.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException13 = new org.apache.commons.math.exception.OutOfRangeException(localizable9, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray15 = mathException14.getArguments();
        java.lang.Throwable[] throwableArray16 = mathException14.getSuppressed();
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException3, localizable9, (java.lang.Object[]) throwableArray16);
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException("hi!", (java.lang.Object[]) throwableArray16);
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException(localizable1, (java.lang.Object[]) throwableArray16);
        org.apache.commons.math.exception.util.Localizable localizable21 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException25 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable21, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable26 = numberIsTooSmallException25.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException30 = new org.apache.commons.math.exception.OutOfRangeException(localizable26, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        java.lang.Object[] objArray31 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException(localizable26, objArray31);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException36 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable26, (java.lang.Number) 0.288405172032595d, (java.lang.Number) (byte) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable37 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException41 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable37, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable42 = numberIsTooSmallException41.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable43 = numberIsTooSmallException41.getGeneralPattern();
        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable45 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException49 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable45, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable50 = numberIsTooSmallException49.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException54 = new org.apache.commons.math.exception.OutOfRangeException(localizable50, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException55 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray56 = mathException55.getArguments();
        java.lang.Throwable[] throwableArray57 = mathException55.getSuppressed();
        org.apache.commons.math.MathException mathException58 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException44, localizable50, (java.lang.Object[]) throwableArray57);
        java.lang.Object[] objArray59 = null;
        org.apache.commons.math.MathException mathException60 = new org.apache.commons.math.MathException(localizable50, objArray59);
        org.apache.commons.math.MathException mathException61 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray62 = mathException61.getArguments();
        java.lang.Throwable[] throwableArray63 = mathException61.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException64 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable50, (java.lang.Object[]) throwableArray63);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException65 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable26, localizable43, (java.lang.Object[]) throwableArray63);
        org.apache.commons.math.MathException mathException66 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException19, "{0}", (java.lang.Object[]) throwableArray63);
        org.apache.commons.math.MathException mathException67 = new org.apache.commons.math.MathException("2cc4bca353b0d36733d55b2ff91bbb544b5", (java.lang.Object[]) throwableArray63);
        org.apache.commons.math.MathException mathException68 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException67);
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertTrue("'" + localizable26 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable26.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNull(localizable42);
        org.junit.Assert.assertTrue("'" + localizable43 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable43.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizable50 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable50.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray56);
        org.junit.Assert.assertNotNull(throwableArray57);
        org.junit.Assert.assertNotNull(objArray62);
        org.junit.Assert.assertNotNull(throwableArray63);
    }

//    @Test
//    public void test156() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test156");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (byte) 0, 3.141592653589793d);
//        randomDataImpl0.reSeedSecure();
//        int[] intArray7 = randomDataImpl0.nextPermutation((int) (byte) 100, (int) (byte) 1);
//        int int10 = randomDataImpl0.nextZipf((int) (short) 1, (double) 1.0f);
//        double double13 = randomDataImpl0.nextCauchy(0.0d, (double) 82);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.33927638409104866d + "'", double3 == 0.33927638409104866d);
//        org.junit.Assert.assertNotNull(intArray7);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 50.10304638740941d + "'", double13 == 50.10304638740941d);
//    }

//    @Test
//    public void test157() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test157");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (byte) 0, 3.141592653589793d);
//        java.lang.String str5 = randomDataImpl0.nextHexString(52);
//        long long8 = randomDataImpl0.nextLong((long) 10, (long) 35);
//        randomDataImpl0.reSeed();
//        try {
//            int int12 = randomDataImpl0.nextBinomial(3, 3.3107611006663085d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 3.311 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.34490492602676404d + "'", double3 == 0.34490492602676404d);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "35d963afab4dbda55229a22d66cd50544111eb878b338a4f4928" + "'", str5.equals("35d963afab4dbda55229a22d66cd50544111eb878b338a4f4928"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 21L + "'", long8 == 21L);
//    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((-36.21784016432742d), (-0.8427007929497151d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-36.21784016432741d) + "'", double2 == (-36.21784016432741d));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.5201284964308879d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5438998195128688d + "'", double1 == 0.5438998195128688d);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        long long2 = org.apache.commons.math.util.FastMath.max(1L, (long) 90);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 90L + "'", long2 == 90L);
    }

//    @Test
//    public void test161() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test161");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextCauchy(0.0d, (double) 32);
//        double double6 = randomDataImpl0.nextChiSquare((double) '4');
//        double double8 = randomDataImpl0.nextChiSquare(0.8944271909999159d);
//        double double11 = randomDataImpl0.nextGamma(0.36787944117144233d, 2.2947995645263366d);
//        try {
//            int int15 = randomDataImpl0.nextHypergeometric((int) (byte) 0, 0, 52);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): population size (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-77.49079485925616d) + "'", double4 == (-77.49079485925616d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 35.83542774234492d + "'", double6 == 35.83542774234492d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.2700851187499024E-5d + "'", double8 == 2.2700851187499024E-5d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.013676921683226382d + "'", double11 == 0.013676921683226382d);
//    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        double double1 = org.apache.commons.math.special.Gamma.digamma((-1.5707963267948966d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.02680723529845863d + "'", double1 == 0.02680723529845863d);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        double double1 = org.apache.commons.math.util.FastMath.tan(8.83139705388539E-11d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.83139705388539E-11d + "'", double1 == 8.83139705388539E-11d);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.4019776376343749d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.33788383815307554d + "'", double1 == 0.33788383815307554d);
    }

//    @Test
//    public void test165() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test165");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (byte) 0, 3.141592653589793d);
//        randomDataImpl0.reSeedSecure();
//        int[] intArray7 = randomDataImpl0.nextPermutation((int) (byte) 100, (int) (byte) 1);
//        double double10 = randomDataImpl0.nextF((double) 100.0f, 100.0d);
//        double double12 = randomDataImpl0.nextChiSquare(96.016795330599d);
//        double double15 = randomDataImpl0.nextGamma(0.5201284964308879d, 0.010050166663333096d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.38796344270381805d + "'", double3 == 0.38796344270381805d);
//        org.junit.Assert.assertNotNull(intArray7);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.9607236830437537d + "'", double10 == 0.9607236830437537d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 89.77620112192454d + "'", double12 == 89.77620112192454d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 9.246485104273307E-4d + "'", double15 == 9.246485104273307E-4d);
//    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        long long1 = org.apache.commons.math.util.FastMath.round(1.2307280868187975d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        double double1 = org.apache.commons.math.util.FastMath.ulp((-5.221119010901584d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.881784197001252E-16d + "'", double1 == 8.881784197001252E-16d);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(1833.4649444186348d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 42.81897878766651d + "'", double1 == 42.81897878766651d);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable1, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException5.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray12 = mathException11.getArguments();
        java.lang.Throwable[] throwableArray13 = mathException11.getSuppressed();
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException0, localizable6, (java.lang.Object[]) throwableArray13);
        java.lang.Object[] objArray15 = null;
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException(localizable6, objArray15);
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException21 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable17, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable22 = numberIsTooSmallException21.getGeneralPattern();
        java.lang.Number number23 = null;
        java.lang.Number number24 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException26 = new org.apache.commons.math.exception.OutOfRangeException(localizable22, number23, number24, (java.lang.Number) 10);
        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException26);
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException26);
        java.lang.Number number29 = outOfRangeException26.getLo();
        java.lang.Number number30 = outOfRangeException26.getLo();
        java.lang.Number number31 = outOfRangeException26.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable32 = outOfRangeException26.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException37 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable33, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable38 = numberIsTooSmallException37.getGeneralPattern();
        java.lang.Number number39 = null;
        java.lang.Number number40 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException42 = new org.apache.commons.math.exception.OutOfRangeException(localizable38, number39, number40, (java.lang.Number) 10);
        org.apache.commons.math.MathException mathException43 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException42);
        java.lang.Number number44 = outOfRangeException42.getHi();
        java.lang.Throwable[] throwableArray45 = outOfRangeException42.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException(localizable32, (java.lang.Object[]) throwableArray45);
        org.apache.commons.math.MathException mathException49 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable50 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException54 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable50, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable55 = numberIsTooSmallException54.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException59 = new org.apache.commons.math.exception.OutOfRangeException(localizable55, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException60 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray61 = mathException60.getArguments();
        java.lang.Throwable[] throwableArray62 = mathException60.getSuppressed();
        org.apache.commons.math.MathException mathException63 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException49, localizable55, (java.lang.Object[]) throwableArray62);
        org.apache.commons.math.MathException mathException65 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray66 = mathException65.getArguments();
        java.lang.Throwable[] throwableArray67 = mathException65.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException68 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException49, "", (java.lang.Object[]) throwableArray67);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException69 = new org.apache.commons.math.MaxIterationsExceededException(0, "hi!", (java.lang.Object[]) throwableArray67);
        org.apache.commons.math.MathException mathException70 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException16, localizable32, (java.lang.Object[]) throwableArray67);
        org.apache.commons.math.exception.util.Localizable localizable71 = mathException70.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable72 = mathException70.getGeneralPattern();
        java.lang.Number number75 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException76 = new org.apache.commons.math.exception.OutOfRangeException(localizable72, (java.lang.Number) 0.006992129485781045d, (java.lang.Number) 2.718281828459045d, number75);
        org.apache.commons.math.ConvergenceException convergenceException77 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException76);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertTrue("'" + localizable22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable22.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNull(number29);
        org.junit.Assert.assertNull(number30);
        org.junit.Assert.assertNull(number31);
        org.junit.Assert.assertTrue("'" + localizable32 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable32.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable38 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable38.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + number44 + "' != '" + 10 + "'", number44.equals(10));
        org.junit.Assert.assertNotNull(throwableArray45);
        org.junit.Assert.assertTrue("'" + localizable55 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable55.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray61);
        org.junit.Assert.assertNotNull(throwableArray62);
        org.junit.Assert.assertNotNull(objArray66);
        org.junit.Assert.assertNotNull(throwableArray67);
        org.junit.Assert.assertTrue("'" + localizable71 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable71.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable72 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable72.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable1, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException5.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray12 = mathException11.getArguments();
        java.lang.Throwable[] throwableArray13 = mathException11.getSuppressed();
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException0, localizable6, (java.lang.Object[]) throwableArray13);
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray16 = mathException15.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException(localizable6, objArray16);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException19 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable6, (java.lang.Number) 0.9999999999989843d);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertNotNull(objArray16);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (short) 0, (java.lang.Number) (short) 0, true);
        java.lang.Object[] objArray4 = numberIsTooSmallException3.getArguments();
        org.junit.Assert.assertNotNull(objArray4);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable1, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException5.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray12 = mathException11.getArguments();
        java.lang.Throwable[] throwableArray13 = mathException11.getSuppressed();
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException0, localizable6, (java.lang.Object[]) throwableArray13);
        java.lang.Object[] objArray15 = null;
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException(localizable6, objArray15);
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException21 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable17, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable22 = numberIsTooSmallException21.getGeneralPattern();
        java.lang.Number number23 = null;
        java.lang.Number number24 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException26 = new org.apache.commons.math.exception.OutOfRangeException(localizable22, number23, number24, (java.lang.Number) 10);
        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException26);
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException26);
        java.lang.Number number29 = outOfRangeException26.getLo();
        java.lang.Number number30 = outOfRangeException26.getLo();
        java.lang.Number number31 = outOfRangeException26.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable32 = outOfRangeException26.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException37 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable33, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable38 = numberIsTooSmallException37.getGeneralPattern();
        java.lang.Number number39 = null;
        java.lang.Number number40 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException42 = new org.apache.commons.math.exception.OutOfRangeException(localizable38, number39, number40, (java.lang.Number) 10);
        org.apache.commons.math.MathException mathException43 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException42);
        java.lang.Number number44 = outOfRangeException42.getHi();
        java.lang.Throwable[] throwableArray45 = outOfRangeException42.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException(localizable32, (java.lang.Object[]) throwableArray45);
        org.apache.commons.math.MathException mathException49 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable50 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException54 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable50, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable55 = numberIsTooSmallException54.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException59 = new org.apache.commons.math.exception.OutOfRangeException(localizable55, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException60 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray61 = mathException60.getArguments();
        java.lang.Throwable[] throwableArray62 = mathException60.getSuppressed();
        org.apache.commons.math.MathException mathException63 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException49, localizable55, (java.lang.Object[]) throwableArray62);
        org.apache.commons.math.MathException mathException65 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray66 = mathException65.getArguments();
        java.lang.Throwable[] throwableArray67 = mathException65.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException68 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException49, "", (java.lang.Object[]) throwableArray67);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException69 = new org.apache.commons.math.MaxIterationsExceededException(0, "hi!", (java.lang.Object[]) throwableArray67);
        org.apache.commons.math.MathException mathException70 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException16, localizable32, (java.lang.Object[]) throwableArray67);
        org.apache.commons.math.ConvergenceException convergenceException71 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException16);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertTrue("'" + localizable22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable22.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNull(number29);
        org.junit.Assert.assertNull(number30);
        org.junit.Assert.assertNull(number31);
        org.junit.Assert.assertTrue("'" + localizable32 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable32.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable38 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable38.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + number44 + "' != '" + 10 + "'", number44.equals(10));
        org.junit.Assert.assertNotNull(throwableArray45);
        org.junit.Assert.assertTrue("'" + localizable55 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable55.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray61);
        org.junit.Assert.assertNotNull(throwableArray62);
        org.junit.Assert.assertNotNull(objArray66);
        org.junit.Assert.assertNotNull(throwableArray67);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        java.lang.Number number0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException(number0, number1, true);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.apache.commons.math.MathException mathException1 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException6 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable2, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable7 = numberIsTooSmallException6.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException11 = new org.apache.commons.math.exception.OutOfRangeException(localizable7, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray13 = mathException12.getArguments();
        java.lang.Throwable[] throwableArray14 = mathException12.getSuppressed();
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException1, localizable7, (java.lang.Object[]) throwableArray14);
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException("72ac4689d9e8052f48269d9311e485f4e3af813dab5c18f99bde", (java.lang.Object[]) throwableArray14);
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(throwableArray14);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(1.1071487177940904d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0522113465431222d + "'", double1 == 1.0522113465431222d);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        double double1 = org.apache.commons.math.util.FastMath.acos(1.812766979401334E-35d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.213319923908595d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

//    @Test
//    public void test179() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test179");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextCauchy(0.0d, (double) 32);
//        double double6 = randomDataImpl0.nextExponential(359.1342053695754d);
//        randomDataImpl0.reSeedSecure((long) (short) 1);
//        java.lang.String str10 = randomDataImpl0.nextSecureHexString((int) ' ');
//        int int13 = randomDataImpl0.nextZipf((int) (short) 1, 4.571545345114974d);
//        double double15 = randomDataImpl0.nextT((double) ' ');
//        long long18 = randomDataImpl0.nextSecureLong((long) (short) 0, 32L);
//        try {
//            int int21 = randomDataImpl0.nextBinomial((int) ' ', (-0.5772156677920701d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: -0.577 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-16.835996890177853d) + "'", double4 == (-16.835996890177853d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 296.8239943865659d + "'", double6 == 296.8239943865659d);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "a34ee12cd0a587f63b0235fc73a9900b" + "'", str10.equals("a34ee12cd0a587f63b0235fc73a9900b"));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.5922686823296613d + "'", double15 == 0.5922686823296613d);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 12L + "'", long18 == 12L);
//    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        double double1 = org.apache.commons.math.util.FastMath.asinh((-83.7545293260573d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-5.121073068230098d) + "'", double1 == (-5.121073068230098d));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(2.732900526423743d, 359.1342053695754d, 5.91525927214798E13d, 82);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

//    @Test
//    public void test182() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test182");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (byte) 0, 3.141592653589793d);
//        try {
//            int int6 = randomDataImpl0.nextSecureInt(0, (-1));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 0 is larger than, or equal to, the maximum (-1): lower bound (0) must be strictly less than upper bound (-1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.1478192255745887d + "'", double3 == 1.1478192255745887d);
//    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.6503626206345209d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7759268771913193d + "'", double1 == 0.7759268771913193d);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray1 = mathException0.getArguments();
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException0, "org.apache.commons.math.exception.NumberIsTooLargeException: 0 is larger than, or equal to, the maximum (0)", objArray3);
        org.apache.commons.math.exception.util.Localizable localizable5 = convergenceException4.getSpecificPattern();
        org.junit.Assert.assertNotNull(objArray1);
        org.junit.Assert.assertNull(localizable5);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

//    @Test
//    public void test186() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test186");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) (short) 1);
//        double double4 = normalDistributionImpl2.cumulativeProbability((-0.8427007929497151d));
//        double double5 = normalDistributionImpl2.sample();
//        double double6 = normalDistributionImpl2.getMean();
//        double double7 = normalDistributionImpl2.getStandardDeviation();
//        try {
//            double double9 = normalDistributionImpl2.inverseCumulativeProbability(3.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 3 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.19969790180335623d + "'", double4 == 0.19969790180335623d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-2.021677910233724d) + "'", double5 == (-2.021677910233724d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
//    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        double double1 = org.apache.commons.math.special.Gamma.logGamma((-1.170522548775396d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) (short) 1);
        double double5 = normalDistributionImpl2.cumulativeProbability(0.0d, 32.00000000000001d);
        double double7 = normalDistributionImpl2.density(0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.5d + "'", double5 == 0.5d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.3989422804014327d + "'", double7 == 0.3989422804014327d);
    }

//    @Test
//    public void test189() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test189");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextCauchy(0.0d, (double) 32);
//        double double6 = randomDataImpl0.nextExponential(359.1342053695754d);
//        randomDataImpl0.reSeedSecure((long) (short) 1);
//        double double10 = randomDataImpl0.nextT(57.29577951308232d);
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeed();
//        double double15 = randomDataImpl0.nextUniform(0.0d, 22.835055624293666d);
//        randomDataImpl0.reSeedSecure();
//        try {
//            int int19 = randomDataImpl0.nextInt(87, (int) '#');
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 87 is larger than, or equal to, the maximum (35): lower bound (87) must be strictly less than upper bound (35)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-14.77458312701133d) + "'", double4 == (-14.77458312701133d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 510.42293541472515d + "'", double6 == 510.42293541472515d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-2.488507117081323d) + "'", double10 == (-2.488507117081323d));
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.271470154759193d + "'", double15 == 8.271470154759193d);
//    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.6503626206345209d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8664001606123382d + "'", double1 == 0.8664001606123382d);
    }

//    @Test
//    public void test191() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test191");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) -1, (double) '#', (double) (-1L));
//        double double4 = normalDistributionImpl3.sample();
//        double double5 = normalDistributionImpl3.getStandardDeviation();
//        double[] doubleArray7 = normalDistributionImpl3.sample(7);
//        double double8 = normalDistributionImpl3.getMean();
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-63.09990677470818d) + "'", double4 == (-63.09990677470818d));
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 35.0d + "'", double5 == 35.0d);
//        org.junit.Assert.assertNotNull(doubleArray7);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
//    }

//    @Test
//    public void test192() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test192");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextCauchy(0.0d, (double) 32);
//        double double6 = randomDataImpl0.nextExponential(359.1342053695754d);
//        randomDataImpl0.reSeedSecure((long) (short) 1);
//        double double10 = randomDataImpl0.nextT(57.29577951308232d);
//        double double13 = randomDataImpl0.nextUniform(1.7637630371219195d, 30.769482320627947d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-12.757307449254395d) + "'", double4 == (-12.757307449254395d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 582.4874337195693d + "'", double6 == 582.4874337195693d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-0.7719223422741176d) + "'", double10 == (-0.7719223422741176d));
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 28.757333871208015d + "'", double13 == 28.757333871208015d);
//    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.4049276984261061d, (-0.6956786412517209d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.696 is smaller than, or equal to, the minimum (0): standard deviation (-0.696)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

//    @Test
//    public void test196() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test196");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (byte) 0, 3.141592653589793d);
//        java.lang.String str5 = randomDataImpl0.nextHexString(52);
//        long long8 = randomDataImpl0.nextLong((long) 10, (long) 35);
//        java.lang.String str10 = randomDataImpl0.nextSecureHexString(88);
//        double double13 = randomDataImpl0.nextGaussian(0.872451005389553d, 1.623800644944012d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.181309141378183d + "'", double3 == 1.181309141378183d);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "398296cdcbd459cac50d1b4080a9d623e6623b974ecba2e65664" + "'", str5.equals("398296cdcbd459cac50d1b4080a9d623e6623b974ecba2e65664"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 32L + "'", long8 == 32L);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "43733c1fad3c9c21845ddb29d020048095422f642c9500eaa45cc82a127601de826add24e722c690ef51109e" + "'", str10.equals("43733c1fad3c9c21845ddb29d020048095422f642c9500eaa45cc82a127601de826add24e722c690ef51109e"));
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 3.108526208678095d + "'", double13 == 3.108526208678095d);
//    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getGeneralPattern();
        java.lang.Number number6 = null;
        java.lang.Number number7 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException9 = new org.apache.commons.math.exception.OutOfRangeException(localizable5, number6, number7, (java.lang.Number) 10);
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException9);
        java.lang.Throwable[] throwableArray11 = outOfRangeException9.getSuppressed();
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException9);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(throwableArray11);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 100);
        int int2 = maxIterationsExceededException1.getMaxIterations();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

//    @Test
//    public void test199() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test199");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (byte) 0, 3.141592653589793d);
//        randomDataImpl0.reSeedSecure();
//        int[] intArray7 = randomDataImpl0.nextPermutation((int) (byte) 100, (int) (byte) 1);
//        randomDataImpl0.reSeed((long) (byte) -1);
//        try {
//            int int12 = randomDataImpl0.nextPascal((int) (byte) 0, 2.1129380639844704d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 2.113 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.9646095512457749d + "'", double3 == 0.9646095512457749d);
//        org.junit.Assert.assertNotNull(intArray7);
//    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        double double1 = org.apache.commons.math.util.FastMath.expm1((-0.8427007929497151d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.569453864216163d) + "'", double1 == (-0.569453864216163d));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.8746788966462123d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.015266026644187592d + "'", double1 == 0.015266026644187592d);
    }

//    @Test
//    public void test202() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test202");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextCauchy(0.0d, (double) 32);
//        java.lang.Class<?> wildcardClass5 = randomDataImpl0.getClass();
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-22.96654487549331d) + "'", double4 == (-22.96654487549331d));
//        org.junit.Assert.assertNotNull(wildcardClass5);
//    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0);
        int int2 = maxIterationsExceededException1.getMaxIterations();
        java.lang.Object[] objArray4 = null;
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException1, "hi!", objArray4);
        java.lang.Class<?> wildcardClass6 = maxIterationsExceededException1.getClass();
        int int7 = maxIterationsExceededException1.getMaxIterations();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        double double1 = org.apache.commons.math.util.FastMath.acos(184.78425380136386d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable1, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException5.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray12 = mathException11.getArguments();
        java.lang.Throwable[] throwableArray13 = mathException11.getSuppressed();
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException0, localizable6, (java.lang.Object[]) throwableArray13);
        java.lang.Object[] objArray15 = null;
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException(localizable6, objArray15);
        java.lang.Number number18 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException20 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable6, (java.lang.Number) 2.718281828459045d, number18, false);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException24 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable6, (java.lang.Number) 1, (java.lang.Number) 38.40781474984203d, false);
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException29 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable25, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable30 = numberIsTooSmallException29.getGeneralPattern();
        java.lang.Number number31 = null;
        java.lang.Number number32 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException34 = new org.apache.commons.math.exception.OutOfRangeException(localizable30, number31, number32, (java.lang.Number) 10);
        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException34);
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException34);
        java.lang.Number number37 = outOfRangeException34.getLo();
        java.lang.Number number38 = outOfRangeException34.getLo();
        java.lang.Number number39 = outOfRangeException34.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable40 = outOfRangeException34.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable42 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException46 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable42, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable47 = numberIsTooSmallException46.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException51 = new org.apache.commons.math.exception.OutOfRangeException(localizable47, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException52 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable53 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException57 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable53, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable58 = numberIsTooSmallException57.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException62 = new org.apache.commons.math.exception.OutOfRangeException(localizable58, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException63 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray64 = mathException63.getArguments();
        java.lang.Throwable[] throwableArray65 = mathException63.getSuppressed();
        org.apache.commons.math.MathException mathException66 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException52, localizable58, (java.lang.Object[]) throwableArray65);
        java.lang.Object[] objArray67 = null;
        org.apache.commons.math.MathException mathException68 = new org.apache.commons.math.MathException(localizable58, objArray67);
        org.apache.commons.math.MathException mathException69 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray70 = mathException69.getArguments();
        java.lang.Throwable[] throwableArray71 = mathException69.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException72 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable58, (java.lang.Object[]) throwableArray71);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException73 = new org.apache.commons.math.MaxIterationsExceededException((-1), localizable47, (java.lang.Object[]) throwableArray71);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException74 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable40, (java.lang.Object[]) throwableArray71);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException78 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable40, (java.lang.Number) 194.270024143189d, (java.lang.Number) 9.246117018011247E-12d, false);
        org.apache.commons.math.MathException mathException80 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable81 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException85 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable81, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable86 = numberIsTooSmallException85.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException90 = new org.apache.commons.math.exception.OutOfRangeException(localizable86, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException91 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray92 = mathException91.getArguments();
        java.lang.Throwable[] throwableArray93 = mathException91.getSuppressed();
        org.apache.commons.math.MathException mathException94 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException80, localizable86, (java.lang.Object[]) throwableArray93);
        java.lang.Object[] objArray95 = mathException80.getArguments();
        org.apache.commons.math.MathException mathException96 = new org.apache.commons.math.MathException("32b8f409325e4c2dd58057162086f2874d9", objArray95);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException97 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, localizable40, objArray95);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertTrue("'" + localizable30 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable30.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNull(number37);
        org.junit.Assert.assertNull(number38);
        org.junit.Assert.assertNull(number39);
        org.junit.Assert.assertTrue("'" + localizable40 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable40.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable47 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable47.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizable58 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable58.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray64);
        org.junit.Assert.assertNotNull(throwableArray65);
        org.junit.Assert.assertNotNull(objArray70);
        org.junit.Assert.assertNotNull(throwableArray71);
        org.junit.Assert.assertTrue("'" + localizable86 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable86.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray92);
        org.junit.Assert.assertNotNull(throwableArray93);
        org.junit.Assert.assertNotNull(objArray95);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 90, (float) (short) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        long long2 = org.apache.commons.math.util.FastMath.min((long) '#', (long) (-1));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

//    @Test
//    public void test208() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test208");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextCauchy(0.0d, (double) 32);
//        double double6 = randomDataImpl0.nextExponential(359.1342053695754d);
//        randomDataImpl0.reSeedSecure((long) (short) 1);
//        double double10 = randomDataImpl0.nextT(57.29577951308232d);
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeed();
//        double double15 = randomDataImpl0.nextUniform(0.0d, 22.835055624293666d);
//        double double17 = randomDataImpl0.nextExponential(14.15426224147926d);
//        randomDataImpl0.reSeed();
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 6.359044327688657d + "'", double4 == 6.359044327688657d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 264.17116795179896d + "'", double6 == 264.17116795179896d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.8256162727364438d + "'", double10 == 1.8256162727364438d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 12.845420261019672d + "'", double15 == 12.845420261019672d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 16.591663920509294d + "'", double17 == 16.591663920509294d);
//    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        double double2 = org.apache.commons.math.util.FastMath.pow((-1.567222437126173d), 4.196696532391377d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.8813735870195429d, (java.lang.Number) 5.172479873175625d, false);
        java.lang.Number number4 = numberIsTooSmallException3.getArgument();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.8813735870195429d + "'", number4.equals(0.8813735870195429d));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        double double1 = org.apache.commons.math.util.FastMath.asin((-44.0d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        double double1 = org.apache.commons.math.util.FastMath.atanh(95.78119403362746d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException9 = new org.apache.commons.math.exception.OutOfRangeException(localizable5, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        java.lang.Object[] objArray10 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException(localizable5, objArray10);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException15 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) 0.288405172032595d, (java.lang.Number) (byte) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException20 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable16, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable21 = numberIsTooSmallException20.getGeneralPattern();
        java.lang.Number number22 = null;
        java.lang.Number number23 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException25 = new org.apache.commons.math.exception.OutOfRangeException(localizable21, number22, number23, (java.lang.Number) 10);
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException25);
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException25);
        java.lang.Number number28 = outOfRangeException25.getLo();
        java.lang.Number number29 = outOfRangeException25.getLo();
        java.lang.Number number30 = outOfRangeException25.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable31 = outOfRangeException25.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable32 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException36 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable32, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable37 = numberIsTooSmallException36.getGeneralPattern();
        java.lang.Number number38 = null;
        java.lang.Number number39 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException41 = new org.apache.commons.math.exception.OutOfRangeException(localizable37, number38, number39, (java.lang.Number) 10);
        org.apache.commons.math.MathException mathException42 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException41);
        java.lang.Number number43 = outOfRangeException41.getHi();
        java.lang.Throwable[] throwableArray44 = outOfRangeException41.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException45 = new org.apache.commons.math.ConvergenceException(localizable31, (java.lang.Object[]) throwableArray44);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException49 = new org.apache.commons.math.exception.OutOfRangeException(localizable31, (java.lang.Number) (-0.8813735870195429d), (java.lang.Number) (byte) 0, (java.lang.Number) 1.3765887979465332d);
        org.apache.commons.math.MathException mathException53 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable54 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException58 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable54, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable59 = numberIsTooSmallException58.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException63 = new org.apache.commons.math.exception.OutOfRangeException(localizable59, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException64 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray65 = mathException64.getArguments();
        java.lang.Throwable[] throwableArray66 = mathException64.getSuppressed();
        org.apache.commons.math.MathException mathException67 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException53, localizable59, (java.lang.Object[]) throwableArray66);
        org.apache.commons.math.MathException mathException69 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray70 = mathException69.getArguments();
        java.lang.Throwable[] throwableArray71 = mathException69.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException72 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException53, "", (java.lang.Object[]) throwableArray71);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException73 = new org.apache.commons.math.MaxIterationsExceededException(0, "hi!", (java.lang.Object[]) throwableArray71);
        org.apache.commons.math.MathException mathException74 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException49, "", (java.lang.Object[]) throwableArray71);
        org.apache.commons.math.ConvergenceException convergenceException75 = new org.apache.commons.math.ConvergenceException(localizable5, (java.lang.Object[]) throwableArray71);
        java.lang.Number number77 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException79 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 25L, number77, (java.lang.Number) (short) 0);
        java.lang.Throwable[] throwableArray80 = outOfRangeException79.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException81 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, (java.lang.Object[]) throwableArray80);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertTrue("'" + localizable21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable21.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNull(number28);
        org.junit.Assert.assertNull(number29);
        org.junit.Assert.assertNull(number30);
        org.junit.Assert.assertTrue("'" + localizable31 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable31.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable37 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable37.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + number43 + "' != '" + 10 + "'", number43.equals(10));
        org.junit.Assert.assertNotNull(throwableArray44);
        org.junit.Assert.assertTrue("'" + localizable59 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable59.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray65);
        org.junit.Assert.assertNotNull(throwableArray66);
        org.junit.Assert.assertNotNull(objArray70);
        org.junit.Assert.assertNotNull(throwableArray71);
        org.junit.Assert.assertNotNull(throwableArray80);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        double double2 = org.apache.commons.math.util.FastMath.pow((-0.7008313510877778d), (double) 90L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.2741393386611755E-14d + "'", double2 == 1.2741393386611755E-14d);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        double double1 = org.apache.commons.math.util.FastMath.cos((-0.78515518613775d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7072785711797969d + "'", double1 == 0.7072785711797969d);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        double double1 = org.apache.commons.math.util.FastMath.asinh(1.540819445899548d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2171945527877708d + "'", double1 == 1.2171945527877708d);
    }

//    @Test
//    public void test217() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test217");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextCauchy(0.0d, (double) 32);
//        double double6 = randomDataImpl0.nextChiSquare((double) '4');
//        double double8 = randomDataImpl0.nextChiSquare(0.8944271909999159d);
//        double double10 = randomDataImpl0.nextT(205.42997533372358d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-14.654141927519822d) + "'", double4 == (-14.654141927519822d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 24.871813043181497d + "'", double6 == 24.871813043181497d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.149406054944098d + "'", double8 == 4.149406054944098d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.7354443651984129d + "'", double10 == 0.7354443651984129d);
//    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-2.0638064208948803d), (java.lang.Number) 32, false);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        double double1 = org.apache.commons.math.util.FastMath.exp(100.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.6881171418161356E43d + "'", double1 == 2.6881171418161356E43d);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        double double1 = org.apache.commons.math.special.Gamma.trigamma((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ((double) (byte) 100, 0.010050166663333096d, 0.0d, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: maximal number of iterations (0) exceeded");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

//    @Test
//    public void test223() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test223");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextCauchy(0.0d, (double) 32);
//        double double6 = randomDataImpl0.nextExponential(359.1342053695754d);
//        randomDataImpl0.reSeedSecure((long) (short) 1);
//        double double10 = randomDataImpl0.nextT(57.29577951308232d);
//        double double13 = randomDataImpl0.nextCauchy(10.0d, (double) 32.0f);
//        randomDataImpl0.reSeedSecure((long) (byte) 100);
//        java.lang.String str17 = randomDataImpl0.nextSecureHexString(52);
//        try {
//            long long20 = randomDataImpl0.nextSecureLong((long) 5, (-1L));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 5 is larger than, or equal to, the maximum (-1): lower bound (5) must be strictly less than upper bound (-1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-14.993228086326546d) + "'", double4 == (-14.993228086326546d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 488.79697491125785d + "'", double6 == 488.79697491125785d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.3708550483885445d + "'", double10 == 0.3708550483885445d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-519.117652442701d) + "'", double13 == (-519.117652442701d));
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "3493ec0701686751205dfa262e746b80df56c7d898f44f2a51f5" + "'", str17.equals("3493ec0701686751205dfa262e746b80df56c7d898f44f2a51f5"));
//    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getGeneralPattern();
        java.lang.Number number6 = null;
        java.lang.Number number7 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException9 = new org.apache.commons.math.exception.OutOfRangeException(localizable5, number6, number7, (java.lang.Number) 10);
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException9);
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException9);
        java.lang.Object[] objArray12 = convergenceException11.getArguments();
        java.lang.Object[] objArray13 = convergenceException11.getArguments();
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(objArray13);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        double double1 = org.apache.commons.math.util.FastMath.rint(32.62991765411683d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 33.0d + "'", double1 == 33.0d);
    }

//    @Test
//    public void test226() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test226");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextCauchy(0.0d, (double) 32);
//        double double6 = randomDataImpl0.nextExponential(359.1342053695754d);
//        randomDataImpl0.reSeedSecure((long) (short) 1);
//        double double10 = randomDataImpl0.nextT(57.29577951308232d);
//        double double13 = randomDataImpl0.nextCauchy(10.0d, (double) 32.0f);
//        double double16 = randomDataImpl0.nextGaussian(1206.606812147709d, 61.67657891271361d);
//        randomDataImpl0.reSeed();
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-26.171602739787943d) + "'", double4 == (-26.171602739787943d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 449.65452059815937d + "'", double6 == 449.65452059815937d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.5392583197252725d + "'", double10 == 1.5392583197252725d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 25.47534107093107d + "'", double13 == 25.47534107093107d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1232.6989979353114d + "'", double16 == 1232.6989979353114d);
//    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        double double1 = org.apache.commons.math.util.FastMath.atan(1.781072417990198d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0591976398858982d + "'", double1 == 1.0591976398858982d);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) '#');
    }

//    @Test
//    public void test229() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test229");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (byte) 0, 3.141592653589793d);
//        java.lang.String str5 = randomDataImpl0.nextHexString(52);
//        int int8 = randomDataImpl0.nextPascal(35, 0.9586987012903039d);
//        double double11 = randomDataImpl0.nextGaussian(16.72650105839174d, (double) 20L);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.8770966155889709d + "'", double3 == 0.8770966155889709d);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "31fb64b398fe7964a7b4d8f9aa5a75c9f8c3dad4ef184670f563" + "'", str5.equals("31fb64b398fe7964a7b4d8f9aa5a75c9f8c3dad4ef184670f563"));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 29.73126125242014d + "'", double11 == 29.73126125242014d);
//    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) (byte) -1);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (short) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) ' ', (-27.840419813850996d));
        double[] doubleArray5 = normalDistributionImpl3.sample(90);
        org.junit.Assert.assertNotNull(doubleArray5);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.602244797463029d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6022447974630291d + "'", double1 == 0.6022447974630291d);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        double double1 = org.apache.commons.math.util.FastMath.log(2.200736691117263E34d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 79.07668532570761d + "'", double1 == 79.07668532570761d);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.14999862817493861d, 0.7072785711797969d, 3.1226234750635724d, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: maximal number of iterations (0) exceeded");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getGeneralPattern();
        java.lang.Number number6 = null;
        java.lang.Number number7 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException9 = new org.apache.commons.math.exception.OutOfRangeException(localizable5, number6, number7, (java.lang.Number) 10);
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException9);
        java.lang.String str11 = outOfRangeException9.toString();
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math.exception.OutOfRangeException: null out of [null, 10] range: null is smaller than the minimum (null)" + "'", str11.equals("org.apache.commons.math.exception.OutOfRangeException: null out of [null, 10] range: null is smaller than the minimum (null)"));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        int int2 = org.apache.commons.math.util.FastMath.min(95, 75);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 75 + "'", int2 == 75);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        float float2 = org.apache.commons.math.util.FastMath.min((float) ' ', (float) (short) -1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

//    @Test
//    public void test239() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test239");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int int4 = randomDataImpl0.nextHypergeometric(10, 0, 0);
//        double double7 = randomDataImpl0.nextUniform(1.3765887979465332d, 1303.3950961665462d);
//        double double9 = randomDataImpl0.nextT((double) 11L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 518.8301734477889d + "'", double7 == 518.8301734477889d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.7409531605671271d + "'", double9 == 1.7409531605671271d);
//    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) (short) 1);
        normalDistributionImpl2.reseedRandomGenerator(1L);
        double double5 = normalDistributionImpl2.getStandardDeviation();
        double double6 = normalDistributionImpl2.sample();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.561581040188955d + "'", double6 == 1.561581040188955d);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        double double1 = org.apache.commons.math.util.FastMath.tan(309.9556846756072d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.7927727151325485d) + "'", double1 == (-1.7927727151325485d));
    }

//    @Test
//    public void test242() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test242");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextCauchy(0.0d, (double) 32);
//        double double6 = randomDataImpl0.nextChiSquare((double) '4');
//        double double9 = randomDataImpl0.nextWeibull(0.8813735870195429d, (double) 32);
//        java.lang.String str11 = randomDataImpl0.nextSecureHexString(35);
//        randomDataImpl0.reSeed(97L);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-34.532093172316586d) + "'", double4 == (-34.532093172316586d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 47.860610746161896d + "'", double6 == 47.860610746161896d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 13.909689770367537d + "'", double9 == 13.909689770367537d);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "15903ece14b54a5984265780546dba1e7ea" + "'", str11.equals("15903ece14b54a5984265780546dba1e7ea"));
//    }

//    @Test
//    public void test243() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test243");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextCauchy(0.0d, (double) 32);
//        double double6 = randomDataImpl0.nextExponential(359.1342053695754d);
//        randomDataImpl0.reSeedSecure((long) (short) 1);
//        double double10 = randomDataImpl0.nextT(57.29577951308232d);
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeedSecure();
//        double double15 = randomDataImpl0.nextExponential(1206.606812147709d);
//        long long18 = randomDataImpl0.nextLong(100L, 104L);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-35.48165788248654d) + "'", double4 == (-35.48165788248654d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 248.35667005783756d + "'", double6 == 248.35667005783756d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.6960352710187293d + "'", double10 == 0.6960352710187293d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1756.476898008417d + "'", double15 == 1756.476898008417d);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 100L + "'", long18 == 100L);
//    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 100, (java.lang.Number) 40.24700173372515d, (java.lang.Number) (short) 0);
        java.lang.Number number4 = outOfRangeException3.getLo();
        java.lang.Throwable throwable5 = null;
        try {
            outOfRangeException3.addSuppressed(throwable5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 40.24700173372515d + "'", number4.equals(40.24700173372515d));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(1.0962373903922824d, 6.681688318247657d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0962373903922826d + "'", double2 == 1.0962373903922826d);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        double double1 = org.apache.commons.math.util.FastMath.asinh(47.860610746161896d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.561549146090159d + "'", double1 == 4.561549146090159d);
    }

//    @Test
//    public void test247() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test247");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (byte) 0, 3.141592653589793d);
//        double double6 = randomDataImpl0.nextF(223.17441584557872d, (double) 21.0f);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.790416770173332d + "'", double3 == 0.790416770173332d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.9662404605783997d + "'", double6 == 0.9662404605783997d);
//    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        double double1 = org.apache.commons.math.util.FastMath.acosh(2.0988822915763574d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3722536627776192d + "'", double1 == 1.3722536627776192d);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 35);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 35 + "'", int1 == 35);
    }

//    @Test
//    public void test250() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test250");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (byte) 0, 3.141592653589793d);
//        java.lang.String str5 = randomDataImpl0.nextHexString(52);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl9 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 97L, (double) (short) 1, (double) (byte) 0);
//        double double11 = normalDistributionImpl9.inverseCumulativeProbability(0.5765158901134363d);
//        double double12 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl9);
//        int[] intArray15 = randomDataImpl0.nextPermutation(35, (int) (byte) 10);
//        java.lang.String str17 = randomDataImpl0.nextHexString((int) (byte) 10);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.7845067519867834d + "'", double3 == 0.7845067519867834d);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "5a08197b92d6ddf4af97939a014cdf08cac79b339691f2b6c8fd" + "'", str5.equals("5a08197b92d6ddf4af97939a014cdf08cac79b339691f2b6c8fd"));
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 97.19298818676732d + "'", double11 == 97.19298818676732d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 97.69519037898326d + "'", double12 == 97.69519037898326d);
//        org.junit.Assert.assertNotNull(intArray15);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "3192cc8132" + "'", str17.equals("3192cc8132"));
//    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 0.3044465563407555d, (java.lang.Number) 806.4077649578195d, (java.lang.Number) 2.0988822915763574d);
        org.apache.commons.math.MathException mathException4 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable10 = numberIsTooSmallException9.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException14 = new org.apache.commons.math.exception.OutOfRangeException(localizable10, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray16 = mathException15.getArguments();
        java.lang.Throwable[] throwableArray17 = mathException15.getSuppressed();
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException4, localizable10, (java.lang.Object[]) throwableArray17);
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray20 = mathException19.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException(localizable10, objArray20);
        org.apache.commons.math.exception.util.Localizable localizable22 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException26 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable22, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable27 = numberIsTooSmallException26.getGeneralPattern();
        java.lang.Number number28 = null;
        java.lang.Number number29 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException31 = new org.apache.commons.math.exception.OutOfRangeException(localizable27, number28, number29, (java.lang.Number) 10);
        org.apache.commons.math.MathException mathException32 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException31);
        org.apache.commons.math.ConvergenceException convergenceException33 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException31);
        java.lang.Number number34 = outOfRangeException31.getLo();
        java.lang.Number number35 = outOfRangeException31.getLo();
        java.lang.Number number36 = outOfRangeException31.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable37 = outOfRangeException31.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable38 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException42 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable38, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable43 = numberIsTooSmallException42.getGeneralPattern();
        java.lang.Number number44 = null;
        java.lang.Number number45 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException47 = new org.apache.commons.math.exception.OutOfRangeException(localizable43, number44, number45, (java.lang.Number) 10);
        org.apache.commons.math.MathException mathException48 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException47);
        java.lang.Number number49 = outOfRangeException47.getHi();
        java.lang.Throwable[] throwableArray50 = outOfRangeException47.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException51 = new org.apache.commons.math.ConvergenceException(localizable37, (java.lang.Object[]) throwableArray50);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException55 = new org.apache.commons.math.exception.OutOfRangeException(localizable37, (java.lang.Number) (-0.8813735870195429d), (java.lang.Number) (byte) 0, (java.lang.Number) 1.3765887979465332d);
        org.apache.commons.math.MathException mathException59 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable60 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException64 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable60, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable65 = numberIsTooSmallException64.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException69 = new org.apache.commons.math.exception.OutOfRangeException(localizable65, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException70 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray71 = mathException70.getArguments();
        java.lang.Throwable[] throwableArray72 = mathException70.getSuppressed();
        org.apache.commons.math.MathException mathException73 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException59, localizable65, (java.lang.Object[]) throwableArray72);
        org.apache.commons.math.MathException mathException75 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray76 = mathException75.getArguments();
        java.lang.Throwable[] throwableArray77 = mathException75.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException78 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException59, "", (java.lang.Object[]) throwableArray77);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException79 = new org.apache.commons.math.MaxIterationsExceededException(0, "hi!", (java.lang.Object[]) throwableArray77);
        org.apache.commons.math.MathException mathException80 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException55, "", (java.lang.Object[]) throwableArray77);
        org.apache.commons.math.ConvergenceException convergenceException81 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3, localizable10, (java.lang.Object[]) throwableArray77);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException85 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable10, (java.lang.Number) 782.624022480461d, (java.lang.Number) 0.33817103144503247d, true);
        org.junit.Assert.assertTrue("'" + localizable10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable10.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertTrue("'" + localizable27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable27.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNull(number34);
        org.junit.Assert.assertNull(number35);
        org.junit.Assert.assertNull(number36);
        org.junit.Assert.assertTrue("'" + localizable37 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable37.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable43 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable43.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + number49 + "' != '" + 10 + "'", number49.equals(10));
        org.junit.Assert.assertNotNull(throwableArray50);
        org.junit.Assert.assertTrue("'" + localizable65 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable65.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray71);
        org.junit.Assert.assertNotNull(throwableArray72);
        org.junit.Assert.assertNotNull(objArray76);
        org.junit.Assert.assertNotNull(throwableArray77);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException7 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable3, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable8 = numberIsTooSmallException7.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException12 = new org.apache.commons.math.exception.OutOfRangeException(localizable8, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException18 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable14, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable19 = numberIsTooSmallException18.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException23 = new org.apache.commons.math.exception.OutOfRangeException(localizable19, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray25 = mathException24.getArguments();
        java.lang.Throwable[] throwableArray26 = mathException24.getSuppressed();
        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException13, localizable19, (java.lang.Object[]) throwableArray26);
        java.lang.Object[] objArray28 = null;
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException(localizable19, objArray28);
        org.apache.commons.math.MathException mathException30 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray31 = mathException30.getArguments();
        java.lang.Throwable[] throwableArray32 = mathException30.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException33 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable19, (java.lang.Object[]) throwableArray32);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException34 = new org.apache.commons.math.MaxIterationsExceededException((-1), localizable8, (java.lang.Object[]) throwableArray32);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException35 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable1, (java.lang.Object[]) throwableArray32);
        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizable19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable19.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(throwableArray26);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(throwableArray32);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) (short) 1);
        normalDistributionImpl2.reseedRandomGenerator((long) (byte) -1);
        normalDistributionImpl2.reseedRandomGenerator((long) (short) 10);
        double double8 = normalDistributionImpl2.density((double) 10.0f);
        double double9 = normalDistributionImpl2.getStandardDeviation();
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 7.69459862670642E-23d + "'", double8 == 7.69459862670642E-23d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException7 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable5, (java.lang.Number) 28.757333871208015d);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 99.83167712300954d, number1, false);
        java.lang.Object[] objArray4 = numberIsTooLargeException3.getArguments();
        org.junit.Assert.assertNotNull(objArray4);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(7);
        java.lang.String str2 = maxIterationsExceededException1.toString();
        int int3 = maxIterationsExceededException1.getMaxIterations();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.apache.commons.math.MaxIterationsExceededException: maximal number of iterations (7) exceeded" + "'", str2.equals("org.apache.commons.math.MaxIterationsExceededException: maximal number of iterations (7) exceeded"));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 7 + "'", int3 == 7);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (byte) -1, (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(34.93114344459216d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.268919812819781d + "'", double1 == 3.268919812819781d);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        int int2 = org.apache.commons.math.util.FastMath.min((-1), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0);
        int int2 = maxIterationsExceededException1.getMaxIterations();
        java.lang.Object[] objArray4 = null;
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException1, "hi!", objArray4);
        int int6 = maxIterationsExceededException1.getMaxIterations();
        java.lang.String str7 = maxIterationsExceededException1.getPattern();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "maximal number of iterations ({0}) exceeded" + "'", str7.equals("maximal number of iterations ({0}) exceeded"));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        double double1 = org.apache.commons.math.util.FastMath.tan(69.87471745341755d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.949840810629543d + "'", double1 == 0.949840810629543d);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable1, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException5.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray12 = mathException11.getArguments();
        java.lang.Throwable[] throwableArray13 = mathException11.getSuppressed();
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException0, localizable6, (java.lang.Object[]) throwableArray13);
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException0);
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException20 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable16, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable21 = numberIsTooSmallException20.getGeneralPattern();
        java.lang.Number number22 = null;
        java.lang.Number number23 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException25 = new org.apache.commons.math.exception.OutOfRangeException(localizable21, number22, number23, (java.lang.Number) 10);
        java.lang.Number number26 = outOfRangeException25.getLo();
        org.apache.commons.math.exception.util.Localizable localizable29 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException33 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable29, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable34 = numberIsTooSmallException33.getGeneralPattern();
        java.lang.Throwable[] throwableArray35 = numberIsTooSmallException33.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException("", (java.lang.Object[]) throwableArray35);
        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException25, "hi!", (java.lang.Object[]) throwableArray35);
        mathException0.addSuppressed((java.lang.Throwable) outOfRangeException25);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertTrue("'" + localizable21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable21.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNull(number26);
        org.junit.Assert.assertTrue("'" + localizable34 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable34.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(throwableArray35);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getGeneralPattern();
        java.lang.Number number6 = null;
        java.lang.Number number7 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException9 = new org.apache.commons.math.exception.OutOfRangeException(localizable5, number6, number7, (java.lang.Number) 10);
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException9);
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException9);
        java.lang.Number number12 = outOfRangeException9.getLo();
        java.lang.Number number13 = outOfRangeException9.getLo();
        java.lang.Number number14 = outOfRangeException9.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable15 = outOfRangeException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException21 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable17, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable22 = numberIsTooSmallException21.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException26 = new org.apache.commons.math.exception.OutOfRangeException(localizable22, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable28 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException32 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable28, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable33 = numberIsTooSmallException32.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException37 = new org.apache.commons.math.exception.OutOfRangeException(localizable33, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException38 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray39 = mathException38.getArguments();
        java.lang.Throwable[] throwableArray40 = mathException38.getSuppressed();
        org.apache.commons.math.MathException mathException41 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException27, localizable33, (java.lang.Object[]) throwableArray40);
        java.lang.Object[] objArray42 = null;
        org.apache.commons.math.MathException mathException43 = new org.apache.commons.math.MathException(localizable33, objArray42);
        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray45 = mathException44.getArguments();
        java.lang.Throwable[] throwableArray46 = mathException44.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException47 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable33, (java.lang.Object[]) throwableArray46);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException48 = new org.apache.commons.math.MaxIterationsExceededException((-1), localizable22, (java.lang.Object[]) throwableArray46);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException49 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable15, (java.lang.Object[]) throwableArray46);
        org.apache.commons.math.exception.util.Localizable localizable50 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException54 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable50, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable55 = numberIsTooSmallException54.getGeneralPattern();
        java.lang.Throwable[] throwableArray56 = numberIsTooSmallException54.getSuppressed();
        java.lang.Number number57 = numberIsTooSmallException54.getMin();
        mathIllegalArgumentException49.addSuppressed((java.lang.Throwable) numberIsTooSmallException54);
        boolean boolean59 = numberIsTooSmallException54.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertNull(number13);
        org.junit.Assert.assertNull(number14);
        org.junit.Assert.assertTrue("'" + localizable15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable15.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable22.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizable33 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable33.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertNotNull(throwableArray40);
        org.junit.Assert.assertNotNull(objArray45);
        org.junit.Assert.assertNotNull(throwableArray46);
        org.junit.Assert.assertTrue("'" + localizable55 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable55.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(throwableArray56);
        org.junit.Assert.assertTrue("'" + number57 + "' != '" + 10L + "'", number57.equals(10L));
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getGeneralPattern();
        java.lang.Number number6 = null;
        java.lang.Number number7 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException9 = new org.apache.commons.math.exception.OutOfRangeException(localizable5, number6, number7, (java.lang.Number) 10);
        java.lang.Number number10 = outOfRangeException9.getHi();
        java.lang.Number number11 = outOfRangeException9.getLo();
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 10 + "'", number10.equals(10));
        org.junit.Assert.assertNull(number11);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.7354443651984129d, 57.29577951308232d, 0.7516038712662281d, (int) '4');
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 3.5843018142896895E-26d + "'", double4 == 3.5843018142896895E-26d);
    }

//    @Test
//    public void test267() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test267");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextCauchy(0.0d, (double) 32);
//        double double6 = randomDataImpl0.nextExponential(359.1342053695754d);
//        randomDataImpl0.reSeedSecure((long) (short) 1);
//        double double10 = randomDataImpl0.nextT(57.29577951308232d);
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeed();
//        long long15 = randomDataImpl0.nextLong((long) (byte) 0, 52L);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-8.484419269029214d) + "'", double4 == (-8.484419269029214d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 306.32238269761456d + "'", double6 == 306.32238269761456d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.5344078231510563d + "'", double10 == 1.5344078231510563d);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 22L + "'", long15 == 22L);
//    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(1.561581040188955d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5615810401889552d + "'", double1 == 1.5615810401889552d);
    }

//    @Test
//    public void test269() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test269");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (byte) 0, 3.141592653589793d);
//        randomDataImpl0.reSeedSecure();
//        int[] intArray7 = randomDataImpl0.nextPermutation((int) (byte) 100, (int) (byte) 1);
//        randomDataImpl0.reSeed((long) (byte) -1);
//        java.lang.String str11 = randomDataImpl0.nextSecureHexString(75);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.3149986668530627d + "'", double3 == 1.3149986668530627d);
//        org.junit.Assert.assertNotNull(intArray7);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "55c062029ae3888b1eed02c1e1ba6e1d0479124c940dabe78b2b4c7a3f9939934fcf6c02bfc" + "'", str11.equals("55c062029ae3888b1eed02c1e1ba6e1d0479124c940dabe78b2b4c7a3f9939934fcf6c02bfc"));
//    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) 0, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        double double1 = org.apache.commons.math.util.FastMath.log(1.2171945527877708d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.19654866383165995d + "'", double1 == 0.19654866383165995d);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getGeneralPattern();
        java.lang.Number number6 = null;
        java.lang.Number number7 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException9 = new org.apache.commons.math.exception.OutOfRangeException(localizable5, number6, number7, (java.lang.Number) 10);
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException9);
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException9);
        java.lang.Number number12 = outOfRangeException9.getLo();
        java.lang.Number number13 = outOfRangeException9.getLo();
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException18 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable14, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable19 = numberIsTooSmallException18.getGeneralPattern();
        java.lang.Object[] objArray20 = null;
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException9, localizable19, objArray20);
        java.lang.Number number24 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException26 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 25L, number24, (java.lang.Number) (short) 0);
        java.lang.Throwable[] throwableArray27 = outOfRangeException26.getSuppressed();
        org.apache.commons.math.MathException mathException28 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException21, "64d01382d4145b6030d2512fb450c6e1fbe75751f52d4ff62f83", (java.lang.Object[]) throwableArray27);
        org.apache.commons.math.exception.util.Localizable localizable29 = mathException28.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertNull(number13);
        org.junit.Assert.assertTrue("'" + localizable19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable19.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(throwableArray27);
        org.junit.Assert.assertNotNull(localizable29);
    }

//    @Test
//    public void test273() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test273");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (byte) 0, 3.141592653589793d);
//        java.lang.String str5 = randomDataImpl0.nextHexString(52);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl9 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 97L, (double) (short) 1, (double) (byte) 0);
//        double double11 = normalDistributionImpl9.inverseCumulativeProbability(0.5765158901134363d);
//        double double12 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl9);
//        int[] intArray15 = randomDataImpl0.nextPermutation(35, (int) (byte) 10);
//        try {
//            int int18 = randomDataImpl0.nextInt(10, (int) (short) 1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 10 is larger than, or equal to, the maximum (1): lower bound (10) must be strictly less than upper bound (1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.3501772060947639d + "'", double3 == 1.3501772060947639d);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "e64f55b2f488a3c19ed8554d5264a7646d8597d1f91e239281f1" + "'", str5.equals("e64f55b2f488a3c19ed8554d5264a7646d8597d1f91e239281f1"));
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 97.19298818676732d + "'", double11 == 97.19298818676732d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 95.39714915673393d + "'", double12 == 95.39714915673393d);
//        org.junit.Assert.assertNotNull(intArray15);
//    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable1, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException5.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray12 = mathException11.getArguments();
        java.lang.Throwable[] throwableArray13 = mathException11.getSuppressed();
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException0, localizable6, (java.lang.Object[]) throwableArray13);
        java.lang.Number number17 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException18 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) 0.0d, (java.lang.Number) 1L, number17);
        java.lang.Number number19 = outOfRangeException18.getLo();
        java.lang.String str20 = outOfRangeException18.toString();
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + 1L + "'", number19.equals(1L));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.apache.commons.math.exception.OutOfRangeException: 0 out of [1, null] range: 0 is smaller than the minimum (1)" + "'", str20.equals("org.apache.commons.math.exception.OutOfRangeException: 0 out of [1, null] range: 0 is smaller than the minimum (1)"));
    }

//    @Test
//    public void test275() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test275");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (byte) 0, 3.141592653589793d);
//        randomDataImpl0.reSeedSecure();
//        int[] intArray7 = randomDataImpl0.nextPermutation((int) (byte) 100, (int) (byte) 1);
//        double double10 = randomDataImpl0.nextF((double) 100.0f, 100.0d);
//        java.lang.String str12 = randomDataImpl0.nextHexString(97);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.3980199763951695d + "'", double3 == 1.3980199763951695d);
//        org.junit.Assert.assertNotNull(intArray7);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.2349271249572487d + "'", double10 == 1.2349271249572487d);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "08bdc3d4f5cd5d74d6f60bcaaac072966dabc8a66d83029818a52d2e668924355073d9a260f90c81048e695259d644629" + "'", str12.equals("08bdc3d4f5cd5d74d6f60bcaaac072966dabc8a66d83029818a52d2e668924355073d9a260f90c81048e695259d644629"));
//    }

//    @Test
//    public void test276() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test276");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (byte) 0, 3.141592653589793d);
//        java.lang.String str5 = randomDataImpl0.nextHexString(52);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl9 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 97L, (double) (short) 1, (double) (byte) 0);
//        double double11 = normalDistributionImpl9.inverseCumulativeProbability(0.5765158901134363d);
//        double double12 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl9);
//        int[] intArray15 = randomDataImpl0.nextPermutation(35, (int) (byte) 10);
//        double double18 = randomDataImpl0.nextF((double) 97L, 2.6859131956935225d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl21 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) (short) 1);
//        double double23 = normalDistributionImpl21.cumulativeProbability((-24.242513872234355d));
//        double double24 = normalDistributionImpl21.getStandardDeviation();
//        double double25 = normalDistributionImpl21.getMean();
//        double double26 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl21);
//        int int29 = randomDataImpl0.nextPascal(100, 0.9999854659974842d);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution30 = null;
//        try {
//            int int31 = randomDataImpl0.nextInversionDeviate(integerDistribution30);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.3943613937082586d + "'", double3 == 1.3943613937082586d);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "813f01142a9e0bfbc9fdf0c47e4ca4395b4c30ff0cb8ad808991" + "'", str5.equals("813f01142a9e0bfbc9fdf0c47e4ca4395b4c30ff0cb8ad808991"));
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 97.19298818676732d + "'", double11 == 97.19298818676732d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 96.04306069437514d + "'", double12 == 96.04306069437514d);
//        org.junit.Assert.assertNotNull(intArray15);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 3.1302776379957944d + "'", double18 == 3.1302776379957944d);
//        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0d + "'", double24 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.8419053150693998d + "'", double26 == 0.8419053150693998d);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
//    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.872451005389553d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6429512378982825d + "'", double1 == 0.6429512378982825d);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getGeneralPattern();
        java.lang.Number number6 = null;
        java.lang.Number number7 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException9 = new org.apache.commons.math.exception.OutOfRangeException(localizable5, number6, number7, (java.lang.Number) 10);
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException9);
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException9);
        java.lang.Number number12 = outOfRangeException9.getLo();
        java.lang.Number number13 = outOfRangeException9.getLo();
        java.lang.Number number14 = outOfRangeException9.getArgument();
        java.lang.Number number15 = outOfRangeException9.getLo();
        java.lang.Number number16 = outOfRangeException9.getHi();
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertNull(number13);
        org.junit.Assert.assertNull(number14);
        org.junit.Assert.assertNull(number15);
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 10 + "'", number16.equals(10));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.MathException mathException1 = new org.apache.commons.math.MathException(throwable0);
        java.lang.String str2 = mathException1.getPattern();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{0}" + "'", str2.equals("{0}"));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.3085179492431469d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        double double1 = org.apache.commons.math.util.FastMath.log(0.7072785711797969d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.34633067204866225d) + "'", double1 == (-0.34633067204866225d));
    }

//    @Test
//    public void test282() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test282");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) (short) 1);
//        double double4 = normalDistributionImpl2.cumulativeProbability((-0.8427007929497151d));
//        double double5 = normalDistributionImpl2.sample();
//        double double6 = normalDistributionImpl2.getMean();
//        double double7 = normalDistributionImpl2.getStandardDeviation();
//        double double8 = normalDistributionImpl2.getMean();
//        normalDistributionImpl2.reseedRandomGenerator((long) (byte) 10);
//        try {
//            double double12 = normalDistributionImpl2.inverseCumulativeProbability(2.302585092994046d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 2.303 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.19969790180335623d + "'", double4 == 0.19969790180335623d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-0.9133493956509314d) + "'", double5 == (-0.9133493956509314d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
//    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0);
        int int2 = maxIterationsExceededException1.getMaxIterations();
        java.lang.Object[] objArray4 = null;
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException1, "hi!", objArray4);
        java.lang.Class<?> wildcardClass6 = maxIterationsExceededException1.getClass();
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException12 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable8, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable13 = numberIsTooSmallException12.getGeneralPattern();
        java.lang.Number number14 = null;
        java.lang.Number number15 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException17 = new org.apache.commons.math.exception.OutOfRangeException(localizable13, number14, number15, (java.lang.Number) 10);
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException17);
        org.apache.commons.math.exception.util.Localizable localizable19 = mathException18.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException24 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable20, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable25 = numberIsTooSmallException24.getGeneralPattern();
        java.lang.Number number26 = null;
        java.lang.Number number27 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException29 = new org.apache.commons.math.exception.OutOfRangeException(localizable25, number26, number27, (java.lang.Number) 10);
        org.apache.commons.math.MathException mathException30 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException29);
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException29);
        java.lang.Number number32 = outOfRangeException29.getLo();
        java.lang.Number number33 = outOfRangeException29.getLo();
        java.lang.Number number34 = outOfRangeException29.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable35 = outOfRangeException29.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable36 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException40 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable36, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable41 = numberIsTooSmallException40.getGeneralPattern();
        java.lang.Number number42 = null;
        java.lang.Number number43 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException45 = new org.apache.commons.math.exception.OutOfRangeException(localizable41, number42, number43, (java.lang.Number) 10);
        org.apache.commons.math.MathException mathException46 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException45);
        java.lang.Number number47 = outOfRangeException45.getHi();
        java.lang.Throwable[] throwableArray48 = outOfRangeException45.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException49 = new org.apache.commons.math.ConvergenceException(localizable35, (java.lang.Object[]) throwableArray48);
        org.apache.commons.math.ConvergenceException convergenceException50 = new org.apache.commons.math.ConvergenceException(localizable19, (java.lang.Object[]) throwableArray48);
        org.apache.commons.math.MathException mathException51 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException1, localizable7, (java.lang.Object[]) throwableArray48);
        int int52 = maxIterationsExceededException1.getMaxIterations();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + localizable13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable13.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizable19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable19.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + localizable25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable25.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNull(number32);
        org.junit.Assert.assertNull(number33);
        org.junit.Assert.assertNull(number34);
        org.junit.Assert.assertTrue("'" + localizable35 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable35.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable41 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable41.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + number47 + "' != '" + 10 + "'", number47.equals(10));
        org.junit.Assert.assertNotNull(throwableArray48);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable1, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException5.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray12 = mathException11.getArguments();
        java.lang.Throwable[] throwableArray13 = mathException11.getSuppressed();
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException0, localizable6, (java.lang.Object[]) throwableArray13);
        java.lang.Object[] objArray15 = null;
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException(localizable6, objArray15);
        java.lang.Number number18 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException20 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable6, (java.lang.Number) 2.718281828459045d, number18, false);
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable22 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException26 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable22, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable27 = numberIsTooSmallException26.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException31 = new org.apache.commons.math.exception.OutOfRangeException(localizable27, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException32 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray33 = mathException32.getArguments();
        java.lang.Throwable[] throwableArray34 = mathException32.getSuppressed();
        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException21, localizable27, (java.lang.Object[]) throwableArray34);
        org.apache.commons.math.MathException mathException36 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray37 = mathException36.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException38 = new org.apache.commons.math.ConvergenceException(localizable27, objArray37);
        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException(localizable6, objArray37);
        org.apache.commons.math.exception.util.Localizable localizable40 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException44 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable40, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable45 = numberIsTooSmallException44.getGeneralPattern();
        java.lang.Number number46 = null;
        java.lang.Number number47 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException49 = new org.apache.commons.math.exception.OutOfRangeException(localizable45, number46, number47, (java.lang.Number) 10);
        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException49);
        org.apache.commons.math.ConvergenceException convergenceException51 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException49);
        java.lang.Number number52 = outOfRangeException49.getLo();
        java.lang.Number number53 = outOfRangeException49.getLo();
        java.lang.Number number54 = outOfRangeException49.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable55 = outOfRangeException49.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable56 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException60 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable56, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable61 = numberIsTooSmallException60.getGeneralPattern();
        java.lang.Number number62 = null;
        java.lang.Number number63 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException65 = new org.apache.commons.math.exception.OutOfRangeException(localizable61, number62, number63, (java.lang.Number) 10);
        org.apache.commons.math.MathException mathException66 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException65);
        java.lang.Number number67 = outOfRangeException65.getHi();
        java.lang.Throwable[] throwableArray68 = outOfRangeException65.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException69 = new org.apache.commons.math.ConvergenceException(localizable55, (java.lang.Object[]) throwableArray68);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException71 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable55, (java.lang.Number) 100);
        org.apache.commons.math.MathException mathException72 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable73 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException77 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable73, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable78 = numberIsTooSmallException77.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException82 = new org.apache.commons.math.exception.OutOfRangeException(localizable78, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException83 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray84 = mathException83.getArguments();
        java.lang.Throwable[] throwableArray85 = mathException83.getSuppressed();
        org.apache.commons.math.MathException mathException86 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException72, localizable78, (java.lang.Object[]) throwableArray85);
        org.apache.commons.math.MathException mathException88 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray89 = mathException88.getArguments();
        java.lang.Throwable[] throwableArray90 = mathException88.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException91 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException72, "", (java.lang.Object[]) throwableArray90);
        java.lang.String str92 = convergenceException91.getPattern();
        java.lang.Object[] objArray93 = convergenceException91.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException94 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable55, objArray93);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException95 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, objArray93);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertTrue("'" + localizable27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable27.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertNotNull(throwableArray34);
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertTrue("'" + localizable45 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable45.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNull(number52);
        org.junit.Assert.assertNull(number53);
        org.junit.Assert.assertNull(number54);
        org.junit.Assert.assertTrue("'" + localizable55 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable55.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable61 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable61.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + number67 + "' != '" + 10 + "'", number67.equals(10));
        org.junit.Assert.assertNotNull(throwableArray68);
        org.junit.Assert.assertTrue("'" + localizable78 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable78.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray84);
        org.junit.Assert.assertNotNull(throwableArray85);
        org.junit.Assert.assertNotNull(objArray89);
        org.junit.Assert.assertNotNull(throwableArray90);
        org.junit.Assert.assertTrue("'" + str92 + "' != '" + "" + "'", str92.equals(""));
        org.junit.Assert.assertNotNull(objArray93);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 79.76983250626756d, (java.lang.Number) Double.NaN, false);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooSmallException3.getSpecificPattern();
        org.junit.Assert.assertNull(localizable4);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) Double.POSITIVE_INFINITY, (java.lang.Number) (short) -1, false);
        boolean boolean4 = numberIsTooLargeException3.getBoundIsAllowed();
        boolean boolean5 = numberIsTooLargeException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

//    @Test
//    public void test287() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test287");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextCauchy(0.0d, (double) 32);
//        double double6 = randomDataImpl0.nextChiSquare((double) '4');
//        double double9 = randomDataImpl0.nextWeibull(0.8813735870195429d, (double) 32);
//        java.lang.String str11 = randomDataImpl0.nextSecureHexString(35);
//        randomDataImpl0.reSeedSecure((long) 3);
//        double double16 = randomDataImpl0.nextF(806.4077649578195d, 6.164682348792344E11d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 14.764812453216548d + "'", double4 == 14.764812453216548d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 62.83234269816392d + "'", double6 == 62.83234269816392d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 41.288004573738014d + "'", double9 == 41.288004573738014d);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "5b10d8b78c86bc7c0b47b61d0398c06fc22" + "'", str11.equals("5b10d8b78c86bc7c0b47b61d0398c06fc22"));
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.9900880684702758d + "'", double16 == 0.9900880684702758d);
//    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        double double1 = org.apache.commons.math.util.FastMath.sinh(41.288004573738014d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.2669991810494022E17d + "'", double1 == 4.2669991810494022E17d);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.9900880684702758d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8360742976350034d + "'", double1 == 0.8360742976350034d);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException4.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException10 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.8813735870195429d, (java.lang.Number) 5.172479873175625d, false);
        numberIsTooSmallException4.addSuppressed((java.lang.Throwable) numberIsTooSmallException10);
        org.junit.Assert.assertNull(localizable5);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
    }

//    @Test
//    public void test291() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test291");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (byte) 0, 3.141592653589793d);
//        java.lang.String str5 = randomDataImpl0.nextHexString(52);
//        long long8 = randomDataImpl0.nextLong((long) 10, (long) 35);
//        randomDataImpl0.reSeedSecure((long) (short) 100);
//        try {
//            double double13 = randomDataImpl0.nextF((-0.7719223422741176d), 1.2171945527877708d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.772 is smaller than, or equal to, the minimum (0): degrees of freedom (-0.772)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.9997131644304582d + "'", double3 == 1.9997131644304582d);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "fca45e63fdf481d448933e0e60d8f60cc9e5fe5028eddef5c31e" + "'", str5.equals("fca45e63fdf481d448933e0e60d8f60cc9e5fe5028eddef5c31e"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 21L + "'", long8 == 21L);
//    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.8746788966462123d, 105.10542445824282d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.8746788966462125d + "'", double2 == 0.8746788966462125d);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        double double1 = org.apache.commons.math.util.FastMath.acosh(3.108526208678095d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.8003578419488302d + "'", double1 == 1.8003578419488302d);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0L, (java.lang.Number) 0.0f, false);
        java.lang.Object[] objArray4 = numberIsTooLargeException3.getArguments();
        java.lang.Throwable[] throwableArray5 = numberIsTooLargeException3.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException12 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable8, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable13 = numberIsTooSmallException12.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException17 = new org.apache.commons.math.exception.OutOfRangeException(localizable13, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException23 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable19, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable24 = numberIsTooSmallException23.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException28 = new org.apache.commons.math.exception.OutOfRangeException(localizable24, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray30 = mathException29.getArguments();
        java.lang.Throwable[] throwableArray31 = mathException29.getSuppressed();
        org.apache.commons.math.MathException mathException32 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException18, localizable24, (java.lang.Object[]) throwableArray31);
        java.lang.Object[] objArray33 = null;
        org.apache.commons.math.MathException mathException34 = new org.apache.commons.math.MathException(localizable24, objArray33);
        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray36 = mathException35.getArguments();
        java.lang.Throwable[] throwableArray37 = mathException35.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException38 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable24, (java.lang.Object[]) throwableArray37);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException39 = new org.apache.commons.math.MaxIterationsExceededException((-1), localizable13, (java.lang.Object[]) throwableArray37);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException43 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (short) 0, (java.lang.Number) (short) 0, true);
        java.lang.Throwable[] throwableArray44 = numberIsTooSmallException43.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException45 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable13, (java.lang.Object[]) throwableArray44);
        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException3, "55c062029ae3888b1eed02c1e1ba6e1d0479124c940dabe78b2b4c7a3f9939934fcf6c02bfc", (java.lang.Object[]) throwableArray44);
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + localizable13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable13.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizable24 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable24.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertNotNull(throwableArray31);
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertNotNull(throwableArray37);
        org.junit.Assert.assertNotNull(throwableArray44);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 22L, (float) 100L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.38796344270381805d, 806.4077649578195d, 3.4657359027997265d, 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: Continued fraction convergents failed to converge (in less than 806.408 iterations) for value {1}");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        double double1 = org.apache.commons.math.util.FastMath.rint(258.23329197307703d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 258.0d + "'", double1 == 258.0d);
    }

//    @Test
//    public void test300() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test300");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (byte) 0, 3.141592653589793d);
//        randomDataImpl0.reSeedSecure();
//        try {
//            double double7 = randomDataImpl0.nextGaussian(4.584967478670572d, (-0.11948025350994579d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.119 is smaller than, or equal to, the minimum (0): standard deviation (-0.119)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.8756033442734805d + "'", double3 == 1.8756033442734805d);
//    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(1.6892497598624547d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): standard deviation (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

//    @Test
//    public void test302() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test302");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextCauchy(0.0d, (double) 32);
//        double double6 = randomDataImpl0.nextChiSquare((double) '4');
//        double double8 = randomDataImpl0.nextChiSquare(0.8944271909999159d);
//        double double11 = randomDataImpl0.nextUniform(0.6843968673252286d, 1.7637630371219195d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 9.869962971414296d + "'", double4 == 9.869962971414296d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 36.44293091494739d + "'", double6 == 36.44293091494739d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.30454332598555794d + "'", double8 == 0.30454332598555794d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.1652829859323144d + "'", double11 == 1.1652829859323144d);
//    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getGeneralPattern();
        java.lang.Number number6 = null;
        java.lang.Number number7 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException9 = new org.apache.commons.math.exception.OutOfRangeException(localizable5, number6, number7, (java.lang.Number) 10);
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException9);
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException9);
        java.lang.Number number12 = outOfRangeException9.getLo();
        java.lang.Number number13 = outOfRangeException9.getLo();
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException18 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable14, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable19 = numberIsTooSmallException18.getGeneralPattern();
        java.lang.Object[] objArray20 = null;
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException9, localizable19, objArray20);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException23 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable19, (java.lang.Number) 75);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertNull(number13);
        org.junit.Assert.assertTrue("'" + localizable19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable19.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.02680723529845863d, 2.993222846126381d, 1.2349271249572487d);
    }

//    @Test
//    public void test306() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test306");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextCauchy(0.0d, (double) 32);
//        double double6 = randomDataImpl0.nextExponential(359.1342053695754d);
//        randomDataImpl0.reSeedSecure(25L);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 83.3563626988194d + "'", double4 == 83.3563626988194d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 82.25613996032183d + "'", double6 == 82.25613996032183d);
//    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        long long1 = org.apache.commons.math.util.FastMath.abs(52L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 52L + "'", long1 == 52L);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        double double1 = org.apache.commons.math.util.FastMath.atanh((-7.231717743255292d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        double double2 = org.apache.commons.math.util.FastMath.min(7.105427357601002E-15d, (-0.587213915156929d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.587213915156929d) + "'", double2 == (-0.587213915156929d));
    }

//    @Test
//    public void test310() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test310");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextCauchy(0.0d, (double) 32);
//        double double6 = randomDataImpl0.nextExponential(359.1342053695754d);
//        randomDataImpl0.reSeedSecure((long) (short) 1);
//        java.lang.String str10 = randomDataImpl0.nextSecureHexString((int) ' ');
//        int int13 = randomDataImpl0.nextZipf((int) (short) 1, 4.571545345114974d);
//        double double15 = randomDataImpl0.nextT((double) ' ');
//        double double17 = randomDataImpl0.nextChiSquare(1.1874577780127846d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 90.76133035243554d + "'", double4 == 90.76133035243554d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 615.9509387457088d + "'", double6 == 615.9509387457088d);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0e605740f85c09f443ef9de5951de966" + "'", str10.equals("0e605740f85c09f443ef9de5951de966"));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.941532548775974d + "'", double15 == 1.941532548775974d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.8184781938462582d + "'", double17 == 0.8184781938462582d);
//    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException("bbed37e06e16210b7f3b3846551e2cd9697f603b18b2c64b508a", objArray1);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.8003578419488302d);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 7, (java.lang.Number) (-29.59362978710604d), (java.lang.Number) (-0.016670486925536795d));
        java.lang.Number number4 = outOfRangeException3.getHi();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-0.016670486925536795d) + "'", number4.equals((-0.016670486925536795d)));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        int int4 = randomDataImpl0.nextHypergeometric(10, 0, 0);
        randomDataImpl0.reSeedSecure((long) 10);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

//    @Test
//    public void test315() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test315");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextCauchy(0.0d, (double) 32);
//        double double6 = randomDataImpl0.nextChiSquare((double) '4');
//        double double9 = randomDataImpl0.nextWeibull(0.8813735870195429d, (double) 32);
//        java.lang.String str11 = randomDataImpl0.nextSecureHexString(35);
//        randomDataImpl0.reSeedSecure((long) 3);
//        java.lang.String str15 = randomDataImpl0.nextHexString(35);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 106.79638204065782d + "'", double4 == 106.79638204065782d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 47.72461264706857d + "'", double6 == 47.72461264706857d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 24.67146916299396d + "'", double9 == 24.67146916299396d);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "42d587ca89bfe0cdb40490f1e0c39b84893" + "'", str11.equals("42d587ca89bfe0cdb40490f1e0c39b84893"));
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "5079db7b6a3a6de99b0fd822b1a7eff6833" + "'", str15.equals("5079db7b6a3a6de99b0fd822b1a7eff6833"));
//    }

//    @Test
//    public void test316() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test316");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (byte) 0, 3.141592653589793d);
//        java.lang.String str5 = randomDataImpl0.nextHexString(52);
//        double double8 = randomDataImpl0.nextGamma(14.154262241479262d, 53.23505843707038d);
//        try {
//            double double11 = randomDataImpl0.nextGaussian(0.12161247345677362d, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): standard deviation (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.8560987762144037d + "'", double3 == 2.8560987762144037d);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "fcbbed776b886b1800a0fda4e8092c39bd6295d65aa91a13c397" + "'", str5.equals("fcbbed776b886b1800a0fda4e8092c39bd6295d65aa91a13c397"));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 991.234860273134d + "'", double8 == 991.234860273134d);
//    }

//    @Test
//    public void test317() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test317");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextCauchy(0.0d, (double) 32);
//        double double6 = randomDataImpl0.nextChiSquare((double) '4');
//        double double9 = randomDataImpl0.nextCauchy(0.0d, 4.571545345114974d);
//        try {
//            double double12 = randomDataImpl0.nextGamma(1.1223781811861266d, (-29675.81173637713d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -29,675.812 is smaller than, or equal to, the minimum (0): beta");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 105.39246590678007d + "'", double4 == 105.39246590678007d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 52.91678316379592d + "'", double6 == 52.91678316379592d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 38.46864903364367d + "'", double9 == 38.46864903364367d);
//    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getGeneralPattern();
        java.lang.Number number6 = null;
        java.lang.Number number7 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException9 = new org.apache.commons.math.exception.OutOfRangeException(localizable5, number6, number7, (java.lang.Number) 10);
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException9);
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException9);
        java.lang.Number number12 = outOfRangeException9.getLo();
        java.lang.Number number13 = outOfRangeException9.getLo();
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException18 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable14, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable19 = numberIsTooSmallException18.getGeneralPattern();
        java.lang.Object[] objArray20 = null;
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException9, localizable19, objArray20);
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException9);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertNull(number13);
        org.junit.Assert.assertTrue("'" + localizable19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable19.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 399.3087349225457d, (java.lang.Number) (-0.25559277486134857d), (java.lang.Number) 1.0522113465431222d);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 95);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 95.0d + "'", double1 == 95.0d);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.ConvergenceException convergenceException1 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException0);
        java.lang.Object[] objArray2 = convergenceException1.getArguments();
        java.lang.Object[] objArray4 = null;
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException1, "{0} is smaller than the minimum ({1})", objArray4);
        org.junit.Assert.assertNotNull(objArray2);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        double double1 = org.apache.commons.math.util.FastMath.tanh(1.623800644944012d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9251736453266556d + "'", double1 == 0.9251736453266556d);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getGeneralPattern();
        java.lang.Number number6 = null;
        java.lang.Number number7 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException9 = new org.apache.commons.math.exception.OutOfRangeException(localizable5, number6, number7, (java.lang.Number) 10);
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException9);
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException9);
        java.lang.Number number12 = outOfRangeException9.getLo();
        java.lang.Number number13 = outOfRangeException9.getArgument();
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertNull(number13);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        int int2 = org.apache.commons.math.util.FastMath.max(100, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 0.8184781938462582d, (java.lang.Number) (-36.21784016432741d), (java.lang.Number) 0.213319923908595d);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.5259752860080695d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

//    @Test
//    public void test327() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test327");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (byte) 0, 3.141592653589793d);
//        java.lang.String str5 = randomDataImpl0.nextHexString(52);
//        int int8 = randomDataImpl0.nextPascal(35, 0.9586987012903039d);
//        double double11 = randomDataImpl0.nextF(2.6470761673916674d, 3.046467412076156d);
//        double double14 = randomDataImpl0.nextGamma(0.690625641583559d, 30.4715006056123d);
//        int int17 = randomDataImpl0.nextZipf(87, (double) 25L);
//        randomDataImpl0.reSeed((long) (byte) 100);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.880020137957917d + "'", double3 == 2.880020137957917d);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "8f80a40e271a9901ec9f512a5d64a16a8a7e2b57d88137046e19" + "'", str5.equals("8f80a40e271a9901ec9f512a5d64a16a8a7e2b57d88137046e19"));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 5.617435151676266d + "'", double11 == 5.617435151676266d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 18.389277135573103d + "'", double14 == 18.389277135573103d);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//    }

//    @Test
//    public void test328() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test328");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextBeta(0.8184781938462582d, 2.091233300638824d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.6490633195212102d + "'", double4 == 0.6490633195212102d);
//    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.12161247345677362d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.12161247345677363d + "'", double1 == 0.12161247345677363d);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        long long2 = org.apache.commons.math.util.FastMath.max(25L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 25L + "'", long2 == 25L);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0);
        int int2 = maxIterationsExceededException1.getMaxIterations();
        java.lang.Object[] objArray4 = null;
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException1, "hi!", objArray4);
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException5);
        java.lang.Object[] objArray7 = convergenceException5.getArguments();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(objArray7);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) (short) 1);
        normalDistributionImpl2.reseedRandomGenerator((long) (byte) -1);
        normalDistributionImpl2.reseedRandomGenerator((long) (short) 10);
        double double8 = normalDistributionImpl2.density((double) 10.0f);
        double double11 = normalDistributionImpl2.cumulativeProbability(0.46336689408012516d, 615.9509387457088d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 7.69459862670642E-23d + "'", double8 == 7.69459862670642E-23d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.32155070217694925d + "'", double11 == 0.32155070217694925d);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.8813735870195429d, (java.lang.Number) 5.172479873175625d, false);
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException10 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable6, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooSmallException10.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException15 = new org.apache.commons.math.exception.OutOfRangeException(localizable11, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException21 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable17, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable22 = numberIsTooSmallException21.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException26 = new org.apache.commons.math.exception.OutOfRangeException(localizable22, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray28 = mathException27.getArguments();
        java.lang.Throwable[] throwableArray29 = mathException27.getSuppressed();
        org.apache.commons.math.MathException mathException30 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException16, localizable22, (java.lang.Object[]) throwableArray29);
        java.lang.Object[] objArray31 = null;
        org.apache.commons.math.MathException mathException32 = new org.apache.commons.math.MathException(localizable22, objArray31);
        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray34 = mathException33.getArguments();
        java.lang.Throwable[] throwableArray35 = mathException33.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException36 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable22, (java.lang.Object[]) throwableArray35);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException37 = new org.apache.commons.math.MaxIterationsExceededException((-1), localizable11, (java.lang.Object[]) throwableArray35);
        org.apache.commons.math.MathException mathException38 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException3, "aca46ca026eba4058aa03b5dd55e6b10af4cf8097233e4d5fed577303907c79681f394b31d32fc410ac36781", (java.lang.Object[]) throwableArray35);
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException38);
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizable22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable22.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertNotNull(throwableArray29);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(throwableArray35);
    }

//    @Test
//    public void test335() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test335");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) -1, (double) '#', (double) (-1L));
//        double double4 = normalDistributionImpl3.sample();
//        double double6 = normalDistributionImpl3.cumulativeProbability(1.0591976398858982d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 34.25096613892502d + "'", double4 == 34.25096613892502d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.5234579232961857d + "'", double6 == 0.5234579232961857d);
//    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, 0.8768190413350119d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

//    @Test
//    public void test337() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test337");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextCauchy(0.0d, (double) 32);
//        double double6 = randomDataImpl0.nextExponential(359.1342053695754d);
//        randomDataImpl0.reSeedSecure((long) (short) 1);
//        double double10 = randomDataImpl0.nextT(57.29577951308232d);
//        double double13 = randomDataImpl0.nextCauchy(10.0d, (double) 32.0f);
//        randomDataImpl0.reSeedSecure((long) (byte) 100);
//        randomDataImpl0.reSeedSecure(25L);
//        long long20 = randomDataImpl0.nextSecureLong(0L, 7L);
//        double double23 = randomDataImpl0.nextGaussian((-25.47618502773374d), 56.3235319783403d);
//        try {
//            int int26 = randomDataImpl0.nextZipf((int) (short) 10, (-0.03224884652631809d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.032 is smaller than, or equal to, the minimum (0): exponent (-0.032)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 17.230626373517442d + "'", double4 == 17.230626373517442d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 377.59338848563203d + "'", double6 == 377.59338848563203d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.6820670409814087d) + "'", double10 == (-1.6820670409814087d));
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 33.22015560405447d + "'", double13 == 33.22015560405447d);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
//        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 13.06941816014357d + "'", double23 == 13.06941816014357d);
//    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(8.258181274970009E37d, 538.6340346583722d, 0.5772156649015329d);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((-8.212797486430139d), 0.9339441429083891d);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        long long1 = org.apache.commons.math.util.FastMath.abs(90L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 90L + "'", long1 == 90L);
    }

//    @Test
//    public void test341() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test341");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextCauchy(0.0d, (double) 32);
//        double double6 = randomDataImpl0.nextChiSquare((double) '4');
//        double double9 = randomDataImpl0.nextWeibull(0.8813735870195429d, (double) 32);
//        java.lang.String str11 = randomDataImpl0.nextSecureHexString(35);
//        double double14 = randomDataImpl0.nextBeta(0.9999999999999984d, 1.1223781811861266d);
//        java.lang.String str16 = randomDataImpl0.nextSecureHexString(88);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution17 = null;
//        try {
//            int int18 = randomDataImpl0.nextInversionDeviate(integerDistribution17);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 171.51678178361973d + "'", double4 == 171.51678178361973d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 57.598216100970525d + "'", double6 == 57.598216100970525d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 32.37278973985627d + "'", double9 == 32.37278973985627d);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "f5861dbe0e4ebd3e9a461dc984f422c3a4a" + "'", str11.equals("f5861dbe0e4ebd3e9a461dc984f422c3a4a"));
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.08042089910893875d + "'", double14 == 0.08042089910893875d);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "4c83ab6ffe3acb396932099b98cfc7881b1ca4e64c967e999b82889a313a79592f10e28529d1a514c9b6dd6a" + "'", str16.equals("4c83ab6ffe3acb396932099b98cfc7881b1ca4e64c967e999b82889a313a79592f10e28529d1a514c9b6dd6a"));
//    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        int int2 = org.apache.commons.math.util.FastMath.min(95, 5);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
    }

//    @Test
//    public void test343() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test343");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextCauchy(0.0d, (double) 32);
//        double double6 = randomDataImpl0.nextExponential(359.1342053695754d);
//        randomDataImpl0.reSeedSecure((long) (short) 1);
//        java.lang.String str10 = randomDataImpl0.nextSecureHexString((int) ' ');
//        int int13 = randomDataImpl0.nextZipf((int) (short) 1, 4.571545345114974d);
//        double double15 = randomDataImpl0.nextT((double) ' ');
//        long long18 = randomDataImpl0.nextSecureLong((long) (short) 0, 32L);
//        randomDataImpl0.reSeed();
//        try {
//            long long22 = randomDataImpl0.nextLong(100L, (long) (byte) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100 is larger than, or equal to, the maximum (0): lower bound (100) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 173.95944986549065d + "'", double4 == 173.95944986549065d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 581.127281698972d + "'", double6 == 581.127281698972d);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "e09a22d54a55842de6083b6d7d4d6a0f" + "'", str10.equals("e09a22d54a55842de6083b6d7d4d6a0f"));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-1.7013590170376411d) + "'", double15 == (-1.7013590170376411d));
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 16L + "'", long18 == 16L);
//    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getGeneralPattern();
        java.lang.Number number6 = null;
        java.lang.Number number7 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException9 = new org.apache.commons.math.exception.OutOfRangeException(localizable5, number6, number7, (java.lang.Number) 10);
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException9);
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException9);
        java.lang.Number number12 = outOfRangeException9.getLo();
        java.lang.Number number13 = outOfRangeException9.getLo();
        java.lang.Number number14 = outOfRangeException9.getArgument();
        java.lang.Number number15 = outOfRangeException9.getLo();
        org.apache.commons.math.exception.util.Localizable localizable16 = outOfRangeException9.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertNull(number13);
        org.junit.Assert.assertNull(number14);
        org.junit.Assert.assertNull(number15);
        org.junit.Assert.assertTrue("'" + localizable16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable16.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
    }

//    @Test
//    public void test345() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test345");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextCauchy(0.0d, (double) 32);
//        int int7 = randomDataImpl0.nextSecureInt(0, (int) (short) 10);
//        int int10 = randomDataImpl0.nextInt(32, 100);
//        int int13 = randomDataImpl0.nextZipf(35, 1.771260819978906d);
//        double double16 = randomDataImpl0.nextUniform((-116.20953636056122d), 56.3235319783403d);
//        int int19 = randomDataImpl0.nextBinomial((int) (short) 1, 1.0E-9d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 156.1123282464575d + "'", double4 == 156.1123282464575d);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 59 + "'", int10 == 59);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2 + "'", int13 == 2);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + (-51.777052437698856d) + "'", double16 == (-51.777052437698856d));
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        double double1 = org.apache.commons.math.util.FastMath.cos(1.5344078231510563d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.036380473698524804d + "'", double1 == 0.036380473698524804d);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 25L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.258096538021482d + "'", double1 == 3.258096538021482d);
    }

//    @Test
//    public void test348() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test348");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (byte) 0, 3.141592653589793d);
//        java.lang.String str5 = randomDataImpl0.nextHexString(52);
//        long long8 = randomDataImpl0.nextLong((long) 10, (long) 35);
//        randomDataImpl0.reSeed();
//        double double12 = randomDataImpl0.nextF(330.30579510442254d, (double) (short) 10);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl16 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) -1, (double) '#', (double) (-1L));
//        double[] doubleArray18 = normalDistributionImpl16.sample(88);
//        double double19 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl16);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.0055482565599894d + "'", double3 == 3.0055482565599894d);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "c29482109f1e3d55883cf20be0defca79a572209e1170823cca7" + "'", str5.equals("c29482109f1e3d55883cf20be0defca79a572209e1170823cca7"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 14L + "'", long8 == 14L);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.666519412574427d + "'", double12 == 2.666519412574427d);
//        org.junit.Assert.assertNotNull(doubleArray18);
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-57.28609104166053d) + "'", double19 == (-57.28609104166053d));
//    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.apache.commons.math.MathException mathException1 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException6 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable2, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable7 = numberIsTooSmallException6.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException11 = new org.apache.commons.math.exception.OutOfRangeException(localizable7, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray13 = mathException12.getArguments();
        java.lang.Throwable[] throwableArray14 = mathException12.getSuppressed();
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException1, localizable7, (java.lang.Object[]) throwableArray14);
        java.lang.Number number18 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException19 = new org.apache.commons.math.exception.OutOfRangeException(localizable7, (java.lang.Number) 0.0d, (java.lang.Number) 1L, number18);
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException24 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable20, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable25 = numberIsTooSmallException24.getGeneralPattern();
        java.lang.Number number26 = null;
        java.lang.Number number27 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException29 = new org.apache.commons.math.exception.OutOfRangeException(localizable25, number26, number27, (java.lang.Number) 10);
        java.lang.Number number30 = outOfRangeException29.getLo();
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException37 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable33, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable38 = numberIsTooSmallException37.getGeneralPattern();
        java.lang.Throwable[] throwableArray39 = numberIsTooSmallException37.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException40 = new org.apache.commons.math.ConvergenceException("", (java.lang.Object[]) throwableArray39);
        org.apache.commons.math.MathException mathException41 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException29, "hi!", (java.lang.Object[]) throwableArray39);
        org.apache.commons.math.MathException mathException42 = new org.apache.commons.math.MathException(localizable7, (java.lang.Object[]) throwableArray39);
        org.apache.commons.math.MathException mathException43 = new org.apache.commons.math.MathException("940d321a94e952fe32618958c0098603", (java.lang.Object[]) throwableArray39);
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertTrue("'" + localizable25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable25.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNull(number30);
        org.junit.Assert.assertTrue("'" + localizable38 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable38.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(throwableArray39);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(1.0591976398858982d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.01848648624536214d + "'", double1 == 0.01848648624536214d);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getGeneralPattern();
        java.lang.Number number6 = null;
        java.lang.Number number7 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException9 = new org.apache.commons.math.exception.OutOfRangeException(localizable5, number6, number7, (java.lang.Number) 10);
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException9);
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException9);
        java.lang.Number number12 = outOfRangeException9.getLo();
        java.lang.Number number13 = outOfRangeException9.getLo();
        java.lang.Number number14 = outOfRangeException9.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable15 = outOfRangeException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException20 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable16, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable21 = numberIsTooSmallException20.getGeneralPattern();
        java.lang.Number number22 = null;
        java.lang.Number number23 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException25 = new org.apache.commons.math.exception.OutOfRangeException(localizable21, number22, number23, (java.lang.Number) 10);
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException25);
        java.lang.Number number27 = outOfRangeException25.getHi();
        java.lang.Throwable[] throwableArray28 = outOfRangeException25.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException(localizable15, (java.lang.Object[]) throwableArray28);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException33 = new org.apache.commons.math.exception.OutOfRangeException(localizable15, (java.lang.Number) (-0.8813735870195429d), (java.lang.Number) (byte) 0, (java.lang.Number) 1.3765887979465332d);
        org.apache.commons.math.exception.util.Localizable localizable34 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException38 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable34, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable39 = numberIsTooSmallException38.getGeneralPattern();
        java.lang.Number number40 = null;
        java.lang.Number number41 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException43 = new org.apache.commons.math.exception.OutOfRangeException(localizable39, number40, number41, (java.lang.Number) 10);
        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException43);
        org.apache.commons.math.ConvergenceException convergenceException45 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException43);
        java.lang.Number number46 = outOfRangeException43.getLo();
        java.lang.Number number47 = outOfRangeException43.getLo();
        java.lang.Number number48 = outOfRangeException43.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable49 = outOfRangeException43.getGeneralPattern();
        java.lang.Class<?> wildcardClass50 = localizable49.getClass();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException54 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable49, (java.lang.Number) 97.26737425890234d, (java.lang.Number) 0.8645945657283335d, false);
        outOfRangeException33.addSuppressed((java.lang.Throwable) numberIsTooSmallException54);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertNull(number13);
        org.junit.Assert.assertNull(number14);
        org.junit.Assert.assertTrue("'" + localizable15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable15.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable21.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + number27 + "' != '" + 10 + "'", number27.equals(10));
        org.junit.Assert.assertNotNull(throwableArray28);
        org.junit.Assert.assertTrue("'" + localizable39 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable39.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNull(number46);
        org.junit.Assert.assertNull(number47);
        org.junit.Assert.assertNull(number48);
        org.junit.Assert.assertTrue("'" + localizable49 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable49.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(wildcardClass50);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        double double1 = org.apache.commons.math.util.FastMath.asin(2.911379268997749E23d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.38796344270381805d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        double double1 = org.apache.commons.math.util.FastMath.cos((-1.7927727151325485d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.22015794794840568d) + "'", double1 == (-0.22015794794840568d));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable1, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException5.getGeneralPattern();
        java.lang.Number number7 = null;
        java.lang.Number number8 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, number7, number8, (java.lang.Number) 10);
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException10);
        org.apache.commons.math.exception.util.Localizable localizable12 = mathException11.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException16 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable12, (java.lang.Number) 1.0E-9d, (java.lang.Number) 97, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException21 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (short) 0, (java.lang.Number) (short) 0, true);
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException21);
        java.lang.Number number23 = numberIsTooSmallException21.getMin();
        org.apache.commons.math.exception.util.Localizable localizable24 = numberIsTooSmallException21.getSpecificPattern();
        java.lang.Object[] objArray25 = numberIsTooSmallException21.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException26 = new org.apache.commons.math.ConvergenceException("43733c1fad3c9c21845ddb29d020048095422f642c9500eaa45cc82a127601de826add24e722c690ef51109e", objArray25);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException27 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable12, objArray25);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + (short) 0 + "'", number23.equals((short) 0));
        org.junit.Assert.assertNull(localizable24);
        org.junit.Assert.assertNotNull(objArray25);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException6 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable2, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable7 = numberIsTooSmallException6.getGeneralPattern();
        java.lang.Number number8 = null;
        java.lang.Number number9 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException11 = new org.apache.commons.math.exception.OutOfRangeException(localizable7, number8, number9, (java.lang.Number) 10);
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException11);
        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException11);
        java.lang.Number number14 = outOfRangeException11.getLo();
        java.lang.Number number15 = outOfRangeException11.getLo();
        java.lang.Number number16 = outOfRangeException11.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable17 = outOfRangeException11.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException23 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable19, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable24 = numberIsTooSmallException23.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException28 = new org.apache.commons.math.exception.OutOfRangeException(localizable24, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable30 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException34 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable30, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable35 = numberIsTooSmallException34.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException39 = new org.apache.commons.math.exception.OutOfRangeException(localizable35, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException40 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray41 = mathException40.getArguments();
        java.lang.Throwable[] throwableArray42 = mathException40.getSuppressed();
        org.apache.commons.math.MathException mathException43 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException29, localizable35, (java.lang.Object[]) throwableArray42);
        java.lang.Object[] objArray44 = null;
        org.apache.commons.math.MathException mathException45 = new org.apache.commons.math.MathException(localizable35, objArray44);
        org.apache.commons.math.MathException mathException46 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray47 = mathException46.getArguments();
        java.lang.Throwable[] throwableArray48 = mathException46.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException49 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable35, (java.lang.Object[]) throwableArray48);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException50 = new org.apache.commons.math.MaxIterationsExceededException((-1), localizable24, (java.lang.Object[]) throwableArray48);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException51 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable17, (java.lang.Object[]) throwableArray48);
        org.apache.commons.math.exception.util.Localizable localizable52 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException56 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable52, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable57 = numberIsTooSmallException56.getGeneralPattern();
        java.lang.Throwable[] throwableArray58 = numberIsTooSmallException56.getSuppressed();
        java.lang.Number number59 = numberIsTooSmallException56.getMin();
        mathIllegalArgumentException51.addSuppressed((java.lang.Throwable) numberIsTooSmallException56);
        org.apache.commons.math.MathException mathException64 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable65 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException69 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable65, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable70 = numberIsTooSmallException69.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException74 = new org.apache.commons.math.exception.OutOfRangeException(localizable70, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException75 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray76 = mathException75.getArguments();
        java.lang.Throwable[] throwableArray77 = mathException75.getSuppressed();
        org.apache.commons.math.MathException mathException78 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException64, localizable70, (java.lang.Object[]) throwableArray77);
        org.apache.commons.math.MathException mathException80 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray81 = mathException80.getArguments();
        java.lang.Throwable[] throwableArray82 = mathException80.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException83 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException64, "", (java.lang.Object[]) throwableArray82);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException84 = new org.apache.commons.math.MaxIterationsExceededException(0, "hi!", (java.lang.Object[]) throwableArray82);
        org.apache.commons.math.exception.util.Localizable localizable85 = maxIterationsExceededException84.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable86 = maxIterationsExceededException84.getSpecificPattern();
        org.apache.commons.math.ConvergenceException convergenceException87 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException84);
        java.lang.Object[] objArray88 = maxIterationsExceededException84.getArguments();
        org.apache.commons.math.MathException mathException89 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException51, "e3c12efa86a9a9c5528ea7c416d2196dd70", objArray88);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException90 = new org.apache.commons.math.MaxIterationsExceededException(81, "b82a305a9e521dff499689e42a02f19ff770a6cd3d5f0d72f54c", objArray88);
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNull(number14);
        org.junit.Assert.assertNull(number15);
        org.junit.Assert.assertNull(number16);
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable24 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable24.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizable35 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable35.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray41);
        org.junit.Assert.assertNotNull(throwableArray42);
        org.junit.Assert.assertNotNull(objArray47);
        org.junit.Assert.assertNotNull(throwableArray48);
        org.junit.Assert.assertTrue("'" + localizable57 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable57.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(throwableArray58);
        org.junit.Assert.assertTrue("'" + number59 + "' != '" + 10L + "'", number59.equals(10L));
        org.junit.Assert.assertTrue("'" + localizable70 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable70.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray76);
        org.junit.Assert.assertNotNull(throwableArray77);
        org.junit.Assert.assertNotNull(objArray81);
        org.junit.Assert.assertNotNull(throwableArray82);
        org.junit.Assert.assertNull(localizable85);
        org.junit.Assert.assertNull(localizable86);
        org.junit.Assert.assertNotNull(objArray88);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ((double) 1L, 2.0988822915763574d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.12259337535357644d + "'", double2 == 0.12259337535357644d);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        int int4 = randomDataImpl0.nextHypergeometric(10, 0, 0);
        randomDataImpl0.reSeedSecure(1L);
        try {
            double double9 = randomDataImpl0.nextF((double) (-1), 95.89224529839018d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): degrees of freedom (-1)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        double double1 = org.apache.commons.math.util.FastMath.cosh((-0.9193443348656242d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4532130483852659d + "'", double1 == 1.4532130483852659d);
    }

//    @Test
//    public void test360() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test360");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (byte) 0, 3.141592653589793d);
//        java.lang.String str5 = randomDataImpl0.nextHexString(52);
//        long long8 = randomDataImpl0.nextLong((long) 10, (long) 35);
//        randomDataImpl0.reSeed();
//        double double12 = randomDataImpl0.nextF(330.30579510442254d, (double) (short) 10);
//        try {
//            double double15 = randomDataImpl0.nextF(4.2669991810494022E17d, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): degrees of freedom (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.5869442699745372d + "'", double3 == 0.5869442699745372d);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "d2a54380e50a2c52d2e2ddf306b0b6844c02b75c6b27cd197e9e" + "'", str5.equals("d2a54380e50a2c52d2e2ddf306b0b6844c02b75c6b27cd197e9e"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 11L + "'", long8 == 11L);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.7232540773011539d + "'", double12 == 0.7232540773011539d);
//    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 5L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 74.20994852478785d + "'", double1 == 74.20994852478785d);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getSpecificPattern();
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException4);
        org.apache.commons.math.exception.util.Localizable localizable7 = mathException6.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable8 = mathException6.getSpecificPattern();
        org.junit.Assert.assertNull(localizable5);
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNull(localizable8);
    }

//    @Test
//    public void test363() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test363");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        int int4 = randomDataImpl0.nextInt(75, (int) 'a');
//        randomDataImpl0.reSeed(22L);
//        try {
//            int int9 = randomDataImpl0.nextInt((int) (byte) 100, 81);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100 is larger than, or equal to, the maximum (81): lower bound (100) must be strictly less than upper bound (81)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 79 + "'", int4 == 79);
//    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        double double1 = org.apache.commons.math.util.FastMath.atan(1.1462630722404248d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8534407448736444d + "'", double1 == 0.8534407448736444d);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 104L);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.036380473698524804d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5344078231510563d + "'", double1 == 1.5344078231510563d);
    }

//    @Test
//    public void test367() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test367");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextCauchy(0.0d, (double) 32);
//        double double6 = randomDataImpl0.nextExponential(359.1342053695754d);
//        randomDataImpl0.reSeedSecure((long) (short) 1);
//        java.lang.String str10 = randomDataImpl0.nextSecureHexString((int) ' ');
//        int int13 = randomDataImpl0.nextZipf((int) (short) 1, 4.571545345114974d);
//        double double15 = randomDataImpl0.nextT((double) ' ');
//        int int18 = randomDataImpl0.nextBinomial(0, 0.0d);
//        try {
//            double double20 = randomDataImpl0.nextChiSquare((-0.0710722644357374d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.036 is smaller than, or equal to, the minimum (0): alpha");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-51.305368420577864d) + "'", double4 == (-51.305368420577864d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 162.75742452715514d + "'", double6 == 162.75742452715514d);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0cad538d5923c45561cdd800bfad046e" + "'", str10.equals("0cad538d5923c45561cdd800bfad046e"));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-0.7911315820491096d) + "'", double15 == (-0.7911315820491096d));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getGeneralPattern();
        java.lang.Number number6 = null;
        java.lang.Number number7 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException9 = new org.apache.commons.math.exception.OutOfRangeException(localizable5, number6, number7, (java.lang.Number) 10);
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException9);
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException9);
        java.lang.Number number12 = outOfRangeException9.getLo();
        java.lang.Number number13 = outOfRangeException9.getLo();
        java.lang.Number number14 = outOfRangeException9.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable15 = outOfRangeException9.getGeneralPattern();
        java.lang.Class<?> wildcardClass16 = localizable15.getClass();
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException22 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable18, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable23 = numberIsTooSmallException22.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException27 = new org.apache.commons.math.exception.OutOfRangeException(localizable23, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException28 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray29 = mathException28.getArguments();
        java.lang.Throwable[] throwableArray30 = mathException28.getSuppressed();
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException17, localizable23, (java.lang.Object[]) throwableArray30);
        java.lang.Number number34 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException35 = new org.apache.commons.math.exception.OutOfRangeException(localizable23, (java.lang.Number) 0.0d, (java.lang.Number) 1L, number34);
        org.apache.commons.math.exception.util.Localizable localizable36 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException40 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable36, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable41 = numberIsTooSmallException40.getGeneralPattern();
        java.lang.Number number42 = null;
        java.lang.Number number43 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException45 = new org.apache.commons.math.exception.OutOfRangeException(localizable41, number42, number43, (java.lang.Number) 10);
        java.lang.Number number46 = outOfRangeException45.getLo();
        org.apache.commons.math.exception.util.Localizable localizable49 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException53 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable49, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable54 = numberIsTooSmallException53.getGeneralPattern();
        java.lang.Throwable[] throwableArray55 = numberIsTooSmallException53.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException56 = new org.apache.commons.math.ConvergenceException("", (java.lang.Object[]) throwableArray55);
        org.apache.commons.math.MathException mathException57 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException45, "hi!", (java.lang.Object[]) throwableArray55);
        org.apache.commons.math.MathException mathException58 = new org.apache.commons.math.MathException(localizable23, (java.lang.Object[]) throwableArray55);
        org.apache.commons.math.MathException mathException59 = new org.apache.commons.math.MathException(localizable15, (java.lang.Object[]) throwableArray55);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertNull(number13);
        org.junit.Assert.assertNull(number14);
        org.junit.Assert.assertTrue("'" + localizable15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable15.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + localizable23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable23.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(throwableArray30);
        org.junit.Assert.assertTrue("'" + localizable41 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable41.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNull(number46);
        org.junit.Assert.assertTrue("'" + localizable54 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable54.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(throwableArray55);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 9.9999999999999987E17d, (java.lang.Number) 0.7336545584598283d, true);
        java.lang.Number number4 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.7336545584598283d + "'", number4.equals(0.7336545584598283d));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (short) 0, (java.lang.Number) 2.0d, true);
        java.lang.Number number4 = numberIsTooLargeException3.getArgument();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (short) 0 + "'", number4.equals((short) 0));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.6843968673252286d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6843968673252288d + "'", double1 == 0.6843968673252288d);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        long long2 = org.apache.commons.math.util.FastMath.min(0L, (long) 59);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        double double1 = org.apache.commons.math.util.FastMath.floor(1.7158642939653999d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        double double1 = org.apache.commons.math.util.FastMath.acos(24.871813043181497d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException6 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable2, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable7 = numberIsTooSmallException6.getGeneralPattern();
        java.lang.Number number8 = null;
        java.lang.Number number9 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException11 = new org.apache.commons.math.exception.OutOfRangeException(localizable7, number8, number9, (java.lang.Number) 10);
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException11);
        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException11);
        java.lang.Number number14 = outOfRangeException11.getLo();
        java.lang.Number number15 = outOfRangeException11.getLo();
        java.lang.Number number16 = outOfRangeException11.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable17 = outOfRangeException11.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException22 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable18, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable23 = numberIsTooSmallException22.getGeneralPattern();
        java.lang.Number number24 = null;
        java.lang.Number number25 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException27 = new org.apache.commons.math.exception.OutOfRangeException(localizable23, number24, number25, (java.lang.Number) 10);
        org.apache.commons.math.MathException mathException28 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException27);
        java.lang.Number number29 = outOfRangeException27.getHi();
        java.lang.Throwable[] throwableArray30 = outOfRangeException27.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException(localizable17, (java.lang.Object[]) throwableArray30);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException33 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable17, (java.lang.Number) 100);
        java.lang.Throwable[] throwableArray34 = notStrictlyPositiveException33.getSuppressed();
        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException("org.apache.commons.math.MathException: ", (java.lang.Object[]) throwableArray34);
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException("346ff53c6dcf49c36e2607360894de97", (java.lang.Object[]) throwableArray34);
        java.lang.Object[] objArray37 = convergenceException36.getArguments();
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNull(number14);
        org.junit.Assert.assertNull(number15);
        org.junit.Assert.assertNull(number16);
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable23.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + number29 + "' != '" + 10 + "'", number29.equals(10));
        org.junit.Assert.assertNotNull(throwableArray30);
        org.junit.Assert.assertNotNull(throwableArray34);
        org.junit.Assert.assertNotNull(objArray37);
    }

//    @Test
//    public void test376() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test376");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) -1, (double) '#', (double) (-1L));
//        double double4 = normalDistributionImpl3.sample();
//        double double5 = normalDistributionImpl3.getStandardDeviation();
//        double[] doubleArray7 = normalDistributionImpl3.sample(7);
//        double double9 = normalDistributionImpl3.cumulativeProbability(3.258096538021482d);
//        double[] doubleArray11 = normalDistributionImpl3.sample(7);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-27.694486186494593d) + "'", double4 == (-27.694486186494593d));
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 35.0d + "'", double5 == 35.0d);
//        org.junit.Assert.assertNotNull(doubleArray7);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.548415814218381d + "'", double9 == 0.548415814218381d);
//        org.junit.Assert.assertNotNull(doubleArray11);
//    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 40.24700173372515d, (java.lang.Number) (-24.892838891815952d), false);
        java.lang.Number number4 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-24.892838891815952d) + "'", number4.equals((-24.892838891815952d)));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException9 = new org.apache.commons.math.exception.OutOfRangeException(localizable5, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        java.lang.Object[] objArray10 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException(localizable5, objArray10);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException15 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) 0.288405172032595d, (java.lang.Number) (byte) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException20 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable16, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable21 = numberIsTooSmallException20.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable22 = numberIsTooSmallException20.getGeneralPattern();
        org.apache.commons.math.MathException mathException23 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException28 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable24, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable29 = numberIsTooSmallException28.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException33 = new org.apache.commons.math.exception.OutOfRangeException(localizable29, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException34 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray35 = mathException34.getArguments();
        java.lang.Throwable[] throwableArray36 = mathException34.getSuppressed();
        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException23, localizable29, (java.lang.Object[]) throwableArray36);
        java.lang.Object[] objArray38 = null;
        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException(localizable29, objArray38);
        org.apache.commons.math.MathException mathException40 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray41 = mathException40.getArguments();
        java.lang.Throwable[] throwableArray42 = mathException40.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException43 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable29, (java.lang.Object[]) throwableArray42);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException44 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable22, (java.lang.Object[]) throwableArray42);
        java.lang.Number number45 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException46 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable5, number45);
        org.apache.commons.math.exception.util.Localizable localizable47 = notStrictlyPositiveException46.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNull(localizable21);
        org.junit.Assert.assertTrue("'" + localizable22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable22.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizable29 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable29.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertNotNull(throwableArray36);
        org.junit.Assert.assertNotNull(objArray41);
        org.junit.Assert.assertNotNull(throwableArray42);
        org.junit.Assert.assertTrue("'" + localizable47 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable47.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }
}

