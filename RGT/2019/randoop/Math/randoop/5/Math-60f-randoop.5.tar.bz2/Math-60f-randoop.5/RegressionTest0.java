import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 57.29577951308232d + "'", double1 == 57.29577951308232d);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        double double0 = org.apache.commons.math.distribution.NormalDistributionImpl.DEFAULT_INVERSE_ABSOLUTE_ACCURACY;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-9d + "'", double0 == 1.0E-9d);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        double double0 = org.apache.commons.math.util.FastMath.E;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.718281828459045d + "'", double0 == 2.718281828459045d);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        double double1 = org.apache.commons.math.special.Erf.erf((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8427007929497151d) + "'", double1 == (-0.8427007929497151d));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (short) 1, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) -1, (double) '#', (double) (-1L));
        try {
            double double6 = normalDistributionImpl3.cumulativeProbability((double) 'a', (double) 0);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        double double1 = org.apache.commons.math.util.FastMath.acosh(10.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.993222846126381d + "'", double1 == 2.993222846126381d);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5707963267948966d) + "'", double1 == (-1.5707963267948966d));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        long long1 = org.apache.commons.math.util.FastMath.abs((-1L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (byte) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        int int1 = org.apache.commons.math.util.FastMath.round((float) '4');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 52 + "'", int1 == 52);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (short) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 52);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.9512437185814275d + "'", double1 == 3.9512437185814275d);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        double double1 = org.apache.commons.math.util.FastMath.log((-1.5707963267948966d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        double double0 = org.apache.commons.math.util.FastMath.PI;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.141592653589793d + "'", double0 == 3.141592653589793d);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (short) 1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(3.141592653589793d, (-1.0d), 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): standard deviation (-1)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        double double1 = org.apache.commons.math.special.Gamma.digamma((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.450029527644452d + "'", double1 == 3.450029527644452d);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(Double.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 'a');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 97.00000000000001d + "'", double1 == 97.00000000000001d);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (byte) 10, (float) 100);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getGeneralPattern();
        java.lang.Number number6 = null;
        java.lang.Number number7 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException9 = new org.apache.commons.math.exception.OutOfRangeException(localizable5, number6, number7, (java.lang.Number) 10);
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException9);
        java.lang.Number number11 = outOfRangeException9.getHi();
        java.lang.Number number12 = outOfRangeException9.getLo();
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 10 + "'", number11.equals(10));
        org.junit.Assert.assertNull(number12);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        double double1 = org.apache.commons.math.util.FastMath.log10(100.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) -1, (double) '#', (double) (-1L));
        try {
            double[] doubleArray5 = normalDistributionImpl3.sample(0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): number of samples (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) -1, (double) '#', (double) (-1L));
        try {
            double double5 = normalDistributionImpl3.inverseCumulativeProbability((double) 'a');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 97 out of [0, 1] range");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) (short) -1, (double) 1.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.7853981633974483d) + "'", double2 == (-0.7853981633974483d));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        double double0 = org.apache.commons.math.special.Gamma.GAMMA;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.5772156649015329d + "'", double0 == 0.5772156649015329d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(0.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6321205588285577d) + "'", double1 == (-0.6321205588285577d));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(2.993222846126381d, (double) (short) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.9932228461263803d + "'", double2 == 2.9932228461263803d);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8813735870195429d + "'", double1 == 0.8813735870195429d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        double double1 = org.apache.commons.math.util.FastMath.atan(2.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1071487177940904d + "'", double1 == 1.1071487177940904d);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 1.1071487177940904d, (java.lang.Number) (-1L), true);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        double double1 = org.apache.commons.math.util.FastMath.rint(10.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        double double1 = org.apache.commons.math.util.FastMath.acos(3.9512437185814275d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        int int2 = org.apache.commons.math.util.FastMath.min((int) 'a', (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32 + "'", int2 == 32);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        long long2 = org.apache.commons.math.util.FastMath.max((long) '#', (long) 'a');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 97L + "'", long2 == 97L);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1.0d, (java.lang.Number) (-1L), true);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooLargeException3.getSpecificPattern();
        org.junit.Assert.assertNull(localizable4);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (byte) 100, (float) 100L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        double double1 = org.apache.commons.math.special.Gamma.logGamma((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 359.1342053695754d + "'", double1 == 359.1342053695754d);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) 10, (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1.0d, (java.lang.Number) (-1L), true);
        boolean boolean4 = numberIsTooLargeException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        double double1 = org.apache.commons.math.util.FastMath.cosh((-0.8427007929497151d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3765887979465332d + "'", double1 == 1.3765887979465332d);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.141592653589793d + "'", double1 == 3.141592653589793d);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        double double1 = org.apache.commons.math.util.FastMath.cosh(79.76983250626756d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.200736691117263E34d + "'", double1 == 2.200736691117263E34d);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable1, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException5.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray12 = mathException11.getArguments();
        java.lang.Throwable[] throwableArray13 = mathException11.getSuppressed();
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException0, localizable6, (java.lang.Object[]) throwableArray13);
        java.lang.String str15 = mathException14.getPattern();
        java.lang.String str16 = mathException14.getPattern();
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "{0} is smaller than the minimum ({1})" + "'", str15.equals("{0} is smaller than the minimum ({1})"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "{0} is smaller than the minimum ({1})" + "'", str16.equals("{0} is smaller than the minimum ({1})"));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        double double1 = org.apache.commons.math.util.FastMath.expm1(2.200736691117263E34d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        double double1 = org.apache.commons.math.util.FastMath.expm1(2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 14.154262241479262d + "'", double1 == 14.154262241479262d);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        int int2 = org.apache.commons.math.util.FastMath.max(0, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(3.450029527644452d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1462630722404248d + "'", double1 == 1.1462630722404248d);
    }

//    @Test
//    public void test066() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test066");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextCauchy(0.0d, (double) 32);
//        try {
//            int int7 = randomDataImpl0.nextBinomial((-1), 100.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: -1 is smaller than the minimum (0): number of trials (-1)");
//        } catch (org.apache.commons.math.exception.NotPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-30.408441010552266d) + "'", double4 == (-30.408441010552266d));
//    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        double double1 = org.apache.commons.math.util.FastMath.log((double) (-1L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        long long1 = org.apache.commons.math.util.FastMath.abs(0L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 52);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test070() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test070");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (byte) 0, 3.141592653589793d);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution4 = null;
//        try {
//            int int5 = randomDataImpl0.nextInversionDeviate(integerDistribution4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.6684923938659949d + "'", double3 == 0.6684923938659949d);
//    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 97L, (double) (short) 1, (double) (byte) 0);
        normalDistributionImpl3.reseedRandomGenerator((long) (short) 100);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8813735870195429d) + "'", double1 == (-0.8813735870195429d));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 32);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 32.00000000000001d + "'", double1 == 32.00000000000001d);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException9 = new org.apache.commons.math.exception.OutOfRangeException(localizable5, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        java.lang.Number number10 = outOfRangeException9.getLo();
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 1.0E-9d + "'", number10.equals(1.0E-9d));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 1, (long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((-0.6321205588285577d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-36.21784016432742d) + "'", double1 == (-36.21784016432742d));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        int int2 = org.apache.commons.math.util.FastMath.max(35, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable1, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException5.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray12 = mathException11.getArguments();
        java.lang.Throwable[] throwableArray13 = mathException11.getSuppressed();
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException0, localizable6, (java.lang.Object[]) throwableArray13);
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray17 = mathException16.getArguments();
        java.lang.Throwable[] throwableArray18 = mathException16.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException0, "", (java.lang.Object[]) throwableArray18);
        org.apache.commons.math.exception.util.Localizable localizable20 = mathException0.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertNull(localizable20);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0f, (float) (short) 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ((double) 100L, (double) 100.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.48670120172084486d + "'", double2 == 0.48670120172084486d);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        double double1 = org.apache.commons.math.util.FastMath.tanh(14.154262241479262d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999999999989843d + "'", double1 == 0.9999999999989843d);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(1.1071487177940904d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.05286523481589489d) + "'", double1 == (-0.05286523481589489d));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.6144581759415864d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5765158901134363d + "'", double1 == 0.5765158901134363d);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.6881171418161356E43d + "'", double1 == 2.6881171418161356E43d);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        double double1 = org.apache.commons.math.util.FastMath.tan((-27.840419813850996d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.46336689408012516d + "'", double1 == 0.46336689408012516d);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (byte) 0, (float) 32);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 32.0f + "'", float2 == 32.0f);
    }

//    @Test
//    public void test089() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test089");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextCauchy(0.0d, (double) 32);
//        double double6 = randomDataImpl0.nextChiSquare((double) '4');
//        try {
//            java.lang.String str8 = randomDataImpl0.nextSecureHexString((int) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): length (-1)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-94.53326948955421d) + "'", double4 == (-94.53326948955421d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 40.41031105190111d + "'", double6 == 40.41031105190111d);
//    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        double double1 = org.apache.commons.math.util.FastMath.log(0.6144581759415864d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.4870144142263183d) + "'", double1 == (-0.4870144142263183d));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.3044465563407555d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        double double2 = org.apache.commons.math.util.FastMath.max((-0.05286523481589489d), (-1.0d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.05286523481589489d) + "'", double2 == (-0.05286523481589489d));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        double double1 = org.apache.commons.math.util.FastMath.sin(1.1071487177940904d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8944271909999159d + "'", double1 == 0.8944271909999159d);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((-1.5707963267948966d), (-27.840419813850996d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -27.84 is smaller than, or equal to, the minimum (0): standard deviation (-27.84)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

//    @Test
//    public void test096() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test096");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextCauchy(0.0d, (double) 32);
//        try {
//            double double7 = randomDataImpl0.nextGamma(Double.POSITIVE_INFINITY, (double) (byte) 1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0 p = 0.867");
//        } catch (org.apache.commons.math.exception.MathUserException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-132.3761260233494d) + "'", double4 == (-132.3761260233494d));
//    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        double double1 = org.apache.commons.math.special.Gamma.digamma(97.19298818676732d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.571545345114974d + "'", double1 == 4.571545345114974d);
    }

//    @Test
//    public void test098() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test098");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (byte) 0, 3.141592653589793d);
//        randomDataImpl0.reSeedSecure();
//        int[] intArray7 = randomDataImpl0.nextPermutation((int) (byte) 100, (int) (byte) 1);
//        try {
//            double double10 = randomDataImpl0.nextCauchy((-27.840419813850996d), (double) (-1L));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): scale (-1)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.29909944384249487d + "'", double3 == 0.29909944384249487d);
//        org.junit.Assert.assertNotNull(intArray7);
//    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        double double1 = org.apache.commons.math.util.FastMath.log(1.122717258875702d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.11575187101581663d + "'", double1 == 0.11575187101581663d);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        int int4 = randomDataImpl0.nextHypergeometric(10, 0, 0);
        org.apache.commons.math.distribution.IntegerDistribution integerDistribution5 = null;
        try {
            int int6 = randomDataImpl0.nextInversionDeviate(integerDistribution5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(359.1342053695754d, 1.1462630722404248d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (short) -1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        int int4 = randomDataImpl0.nextHypergeometric(10, 0, 0);
        try {
            double double7 = randomDataImpl0.nextF((double) 0L, (-0.7853981633974483d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): degrees of freedom (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.0d, (double) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        long long2 = org.apache.commons.math.util.FastMath.min(1L, (long) '4');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        double double1 = org.apache.commons.math.util.FastMath.asin(2.993222846126381d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) -1, (double) '#', (double) (-1L));
        try {
            double double6 = normalDistributionImpl3.cumulativeProbability((double) 35, 0.0d);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getGeneralPattern();
        java.lang.Number number6 = null;
        java.lang.Number number7 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException9 = new org.apache.commons.math.exception.OutOfRangeException(localizable5, number6, number7, (java.lang.Number) 10);
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException9);
        java.lang.String str11 = mathException10.getPattern();
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "{0}" + "'", str11.equals("{0}"));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

//    @Test
//    public void test110() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test110");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (byte) 0, 3.141592653589793d);
//        randomDataImpl0.reSeedSecure();
//        try {
//            long long7 = randomDataImpl0.nextSecureLong((long) (byte) 100, (long) (byte) 100);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100 is larger than, or equal to, the maximum (100): lower bound (100) must be strictly less than upper bound (100)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.9641139276114402d + "'", double3 == 0.9641139276114402d);
//    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.apache.commons.math.MathException mathException1 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException6 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable2, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable7 = numberIsTooSmallException6.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException11 = new org.apache.commons.math.exception.OutOfRangeException(localizable7, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray13 = mathException12.getArguments();
        java.lang.Throwable[] throwableArray14 = mathException12.getSuppressed();
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException1, localizable7, (java.lang.Object[]) throwableArray14);
        java.lang.Object[] objArray16 = null;
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException(localizable7, objArray16);
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray19 = mathException18.getArguments();
        java.lang.Throwable[] throwableArray20 = mathException18.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException21 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, (java.lang.Object[]) throwableArray20);
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException("{0}", (java.lang.Object[]) throwableArray20);
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(throwableArray20);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(Double.NaN, (double) (byte) 10);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

//    @Test
//    public void test113() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test113");
//        double double0 = org.apache.commons.math.util.FastMath.random();
//        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.6338492905650115d + "'", double0 == 0.6338492905650115d);
//    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 'a', 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        double double1 = org.apache.commons.math.util.FastMath.log(0.11575187101581663d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.1563064218629213d) + "'", double1 == (-2.1563064218629213d));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (short) 0, (java.lang.Number) 2.0d, true);
        java.lang.Number number4 = numberIsTooLargeException3.getMax();
        java.lang.Number number5 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 2.0d + "'", number4.equals(2.0d));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 2.0d + "'", number5.equals(2.0d));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        int int2 = org.apache.commons.math.util.FastMath.max((int) '4', (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (short) 1, (long) 35);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        long long2 = org.apache.commons.math.util.FastMath.min((-1L), (long) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5574077246549023d) + "'", double1 == (-1.5574077246549023d));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        try {
            randomDataImpl0.setSecureAlgorithm("", "hi!");
            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: hi!");
        } catch (java.security.NoSuchProviderException e) {
        }
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        double double1 = org.apache.commons.math.util.FastMath.cos(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5403023058681398d + "'", double1 == 0.5403023058681398d);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 10.0f, (java.lang.Number) 10L, false);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable1, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException5.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray12 = mathException11.getArguments();
        java.lang.Throwable[] throwableArray13 = mathException11.getSuppressed();
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException0, localizable6, (java.lang.Object[]) throwableArray13);
        java.lang.Object[] objArray15 = null;
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException(localizable6, objArray15);
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException16);
        java.lang.Class<?> wildcardClass18 = mathException17.getClass();
        org.apache.commons.math.exception.util.Localizable localizable19 = mathException17.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertTrue("'" + localizable19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable19.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.916079783099616d + "'", double1 == 5.916079783099616d);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 100.0f, (double) 52);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 99.99999999999999d + "'", double2 == 99.99999999999999d);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getGeneralPattern();
        java.lang.Number number6 = numberIsTooSmallException4.getMin();
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 10L + "'", number6.equals(10L));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getGeneralPattern();
        java.lang.Number number6 = null;
        java.lang.Number number7 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException9 = new org.apache.commons.math.exception.OutOfRangeException(localizable5, number6, number7, (java.lang.Number) 10);
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException9);
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException9);
        java.lang.Number number12 = outOfRangeException9.getLo();
        java.lang.Number number13 = outOfRangeException9.getLo();
        java.lang.Number number14 = outOfRangeException9.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable15 = outOfRangeException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException20 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable16, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable21 = numberIsTooSmallException20.getGeneralPattern();
        java.lang.Number number22 = null;
        java.lang.Number number23 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException25 = new org.apache.commons.math.exception.OutOfRangeException(localizable21, number22, number23, (java.lang.Number) 10);
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException25);
        java.lang.Number number27 = outOfRangeException25.getHi();
        java.lang.Throwable[] throwableArray28 = outOfRangeException25.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException(localizable15, (java.lang.Object[]) throwableArray28);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException33 = new org.apache.commons.math.exception.OutOfRangeException(localizable15, (java.lang.Number) (-0.8813735870195429d), (java.lang.Number) (byte) 0, (java.lang.Number) 1.3765887979465332d);
        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray36 = mathException35.getArguments();
        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException33, "hi!", objArray36);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertNull(number13);
        org.junit.Assert.assertNull(number14);
        org.junit.Assert.assertTrue("'" + localizable15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable15.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable21.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + number27 + "' != '" + 10 + "'", number27.equals(10));
        org.junit.Assert.assertNotNull(throwableArray28);
        org.junit.Assert.assertNotNull(objArray36);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 'a', (-0.05286523481589489d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5713413291617189d + "'", double2 == 1.5713413291617189d);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(32.00000000000001d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1833.4649444186348d + "'", double1 == 1833.4649444186348d);
    }

//    @Test
//    public void test133() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test133");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextCauchy(0.0d, (double) 32);
//        double double6 = randomDataImpl0.nextExponential(359.1342053695754d);
//        randomDataImpl0.reSeedSecure((long) (short) 1);
//        double double10 = randomDataImpl0.nextT(57.29577951308232d);
//        double double13 = randomDataImpl0.nextCauchy(10.0d, (double) 32.0f);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution14 = null;
//        try {
//            int int15 = randomDataImpl0.nextInversionDeviate(integerDistribution14);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 32.66448259891566d + "'", double4 == 32.66448259891566d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 848.2495582598206d + "'", double6 == 848.2495582598206d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.2822814838796579d + "'", double10 == 0.2822814838796579d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 6.354031716971656d + "'", double13 == 6.354031716971656d);
//    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.5403023058681398d, (double) 7, Double.NEGATIVE_INFINITY, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: Continued fraction convergents failed to converge (in less than 7 iterations) for value {1}");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        double double1 = org.apache.commons.math.util.FastMath.acos(27.02294661501453d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        int int1 = org.apache.commons.math.util.FastMath.abs(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        double double1 = org.apache.commons.math.util.FastMath.atan((-116.20953636056122d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.562191393417059d) + "'", double1 == (-1.562191393417059d));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        long long1 = org.apache.commons.math.util.FastMath.round(4.571545345114974d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 5L + "'", long1 == 5L);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        int int4 = randomDataImpl0.nextHypergeometric(10, 0, 0);
        try {
            int int7 = randomDataImpl0.nextInt((int) '#', 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 35 is larger than, or equal to, the maximum (1): lower bound (35) must be strictly less than upper bound (1)");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

//    @Test
//    public void test142() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test142");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextCauchy(0.0d, (double) 32);
//        double double6 = randomDataImpl0.nextExponential(359.1342053695754d);
//        randomDataImpl0.reSeedSecure((long) (short) 1);
//        java.lang.String str10 = randomDataImpl0.nextSecureHexString((int) ' ');
//        try {
//            double double13 = randomDataImpl0.nextGamma(0.0d, (double) (-1));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): alpha");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 16.416319779532067d + "'", double4 == 16.416319779532067d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 44.49062777383845d + "'", double6 == 44.49062777383845d);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "256b3734fa253e1355ea55eed433574d" + "'", str10.equals("256b3734fa253e1355ea55eed433574d"));
//    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.5403023058681398d, (double) 32);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9999999999999984d + "'", double2 == 0.9999999999999984d);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        int int4 = randomDataImpl0.nextHypergeometric(10, 0, 0);
        try {
            long long7 = randomDataImpl0.nextSecureLong((long) (byte) 100, (long) 35);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100 is larger than, or equal to, the maximum (35): lower bound (100) must be strictly less than upper bound (35)");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.6338492905650115d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeed();
        try {
            int int4 = randomDataImpl0.nextInt(52, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 52 is larger than, or equal to, the maximum (0): lower bound (52) must be strictly less than upper bound (0)");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 'a', (long) 32);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 97L + "'", long2 == 97L);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        double double1 = org.apache.commons.math.util.FastMath.log(0.9313945829916043d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0710722644357374d) + "'", double1 == (-0.0710722644357374d));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

//    @Test
//    public void test151() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test151");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextCauchy(0.0d, (double) 32);
//        double double6 = randomDataImpl0.nextExponential(359.1342053695754d);
//        try {
//            int int9 = randomDataImpl0.nextPascal(35, 38.40781474984203d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 38.408 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-7.31637716214587d) + "'", double4 == (-7.31637716214587d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 258.89953323507615d + "'", double6 == 258.89953323507615d);
//    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        double double1 = org.apache.commons.math.util.FastMath.log(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

//    @Test
//    public void test153() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test153");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (byte) 0, 3.141592653589793d);
//        java.lang.String str5 = randomDataImpl0.nextHexString(52);
//        try {
//            double double8 = randomDataImpl0.nextGamma((double) (-1), 359.1342053695754d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): alpha");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.3384244985889986d + "'", double3 == 1.3384244985889986d);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "c5b0e390ac547f1c9ba0a1a35f3dc951ba201539c2f103123fac" + "'", str5.equals("c5b0e390ac547f1c9ba0a1a35f3dc951ba201539c2f103123fac"));
//    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        double double1 = org.apache.commons.math.util.FastMath.asinh(298.78533565028516d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.392875355535802d + "'", double1 == 6.392875355535802d);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5872139151569291d) + "'", double1 == (-0.5872139151569291d));
    }

//    @Test
//    public void test156() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test156");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextCauchy(0.0d, (double) 32);
//        int int7 = randomDataImpl0.nextSecureInt(0, (int) (short) 10);
//        int int10 = randomDataImpl0.nextInt(32, 100);
//        try {
//            int int13 = randomDataImpl0.nextSecureInt(32, (int) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 32 is larger than, or equal to, the maximum (-1): lower bound (32) must be strictly less than upper bound (-1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-6.430739555883395d) + "'", double4 == (-6.430739555883395d));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 69 + "'", int10 == 69);
//    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 97L, (double) (short) 1, (double) (byte) 0);
        double double4 = normalDistributionImpl3.getMean();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 97.0d + "'", double4 == 97.0d);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 3.9512437185814275d, (java.lang.Number) 3.450029527644452d, (java.lang.Number) 10.0f);
        org.apache.commons.math.exception.util.Localizable localizable4 = outOfRangeException3.getSpecificPattern();
        org.junit.Assert.assertNull(localizable4);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException("hi!", objArray1);
    }

//    @Test
//    public void test160() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test160");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) (short) 1);
//        double double4 = normalDistributionImpl2.cumulativeProbability((-0.8427007929497151d));
//        double double5 = normalDistributionImpl2.sample();
//        double double6 = normalDistributionImpl2.getMean();
//        try {
//            double[] doubleArray8 = normalDistributionImpl2.sample((int) (short) -1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): number of samples (-1)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.19969790180335623d + "'", double4 == 0.19969790180335623d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-2.7155847052892446d) + "'", double5 == (-2.7155847052892446d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
//    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP((-0.5872139151569291d), 49.40634799044653d, (-36.21784016432742d), 32);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        long long1 = org.apache.commons.math.util.FastMath.round((-0.5872139151569291d));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.46336689408012516d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.501590259893643d + "'", double1 == 0.501590259893643d);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ((-1.5707963267948966d), (-2.1563064218629213d), 419.21122575799876d, (int) (byte) 0);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        long long1 = org.apache.commons.math.util.FastMath.abs(100L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 100L + "'", long1 == 100L);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(1.0E-9d, 1.5713413291617189d, 0.46336689408012516d, 10);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 8.83139705388539E-11d + "'", double4 == 8.83139705388539E-11d);
    }

//    @Test
//    public void test167() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test167");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextCauchy(0.0d, (double) 32);
//        double double6 = randomDataImpl0.nextExponential(359.1342053695754d);
//        randomDataImpl0.reSeedSecure((long) (short) 1);
//        double double10 = randomDataImpl0.nextT(57.29577951308232d);
//        try {
//            double double13 = randomDataImpl0.nextCauchy(0.9999999999989843d, (-1.562191393417059d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1.562 is smaller than, or equal to, the minimum (0): scale (-1.562)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-14.056558224695452d) + "'", double4 == (-14.056558224695452d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 311.42166329298556d + "'", double6 == 311.42166329298556d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 2.081384176153456d + "'", double10 == 2.081384176153456d);
//    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        double double1 = org.apache.commons.math.util.FastMath.atanh((-25.47618502773374d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(2.6881171418161356E43d, (-0.7853981633974483d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.785 is smaller than, or equal to, the minimum (0): standard deviation (-0.785)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

//    @Test
//    public void test171() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test171");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextCauchy(0.0d, (double) 32);
//        double double6 = randomDataImpl0.nextExponential(359.1342053695754d);
//        try {
//            java.lang.String str8 = randomDataImpl0.nextHexString((int) (short) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): length (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-12.2664332323732d) + "'", double4 == (-12.2664332323732d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 184.89333321220627d + "'", double6 == 184.89333321220627d);
//    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable1, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException5.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray12 = mathException11.getArguments();
        java.lang.Throwable[] throwableArray13 = mathException11.getSuppressed();
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException0, localizable6, (java.lang.Object[]) throwableArray13);
        java.lang.Number number17 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException18 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) 0.0d, (java.lang.Number) 1L, number17);
        java.lang.Number number19 = outOfRangeException18.getHi();
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertNull(number19);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 7);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 7L + "'", long1 == 7L);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        double double1 = org.apache.commons.math.util.FastMath.abs(105.10542445824282d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 105.10542445824282d + "'", double1 == 105.10542445824282d);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable1, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException5.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray12 = mathException11.getArguments();
        java.lang.Throwable[] throwableArray13 = mathException11.getSuppressed();
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException0, localizable6, (java.lang.Object[]) throwableArray13);
        java.lang.Object[] objArray15 = null;
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException(localizable6, objArray15);
        java.lang.Number number18 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException20 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable6, (java.lang.Number) 2.718281828459045d, number18, false);
        java.lang.Number number21 = numberIsTooSmallException20.getMin();
        boolean boolean22 = numberIsTooSmallException20.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertNull(number21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(1.0E-9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.9999999999999987E17d + "'", double1 == 9.9999999999999987E17d);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(2.0d, 0.0d, 2.718281828459045d, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1.3765887979465332d, number1, true);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        double double2 = org.apache.commons.math.util.FastMath.max((-0.11948025350994579d), 35.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 35.0d + "'", double2 == 35.0d);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        int int2 = org.apache.commons.math.util.FastMath.max(0, (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException(number0, (java.lang.Number) 2.718281828459045d, (java.lang.Number) (short) 0);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), (java.lang.Number) 2.091233300638824d, true);
    }

//    @Test
//    public void test183() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test183");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextCauchy(0.0d, (double) 32);
//        double double6 = randomDataImpl0.nextExponential(359.1342053695754d);
//        randomDataImpl0.reSeedSecure((long) (short) 1);
//        double double10 = randomDataImpl0.nextT(57.29577951308232d);
//        double double13 = randomDataImpl0.nextCauchy(10.0d, (double) 32.0f);
//        try {
//            double double16 = randomDataImpl0.nextGaussian(1833.4649444186348d, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): standard deviation (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 20.573653062292536d + "'", double4 == 20.573653062292536d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 60.392372955535144d + "'", double6 == 60.392372955535144d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-0.33936319286591987d) + "'", double10 == (-0.33936319286591987d));
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 13.344634495631002d + "'", double13 == 13.344634495631002d);
//    }

//    @Test
//    public void test184() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test184");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextCauchy(0.0d, (double) 32);
//        int int7 = randomDataImpl0.nextSecureInt(0, (int) (short) 10);
//        try {
//            double double10 = randomDataImpl0.nextBeta(0.0d, 2.091233300638824d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.5 p = 0.682");
//        } catch (org.apache.commons.math.exception.MathUserException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 12.015306004210293d + "'", double4 == 12.015306004210293d);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 7 + "'", int7 == 7);
//    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        double double1 = org.apache.commons.math.util.FastMath.rint((-8.212797486430139d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-8.0d) + "'", double1 == (-8.0d));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 2.718281828459045d, (java.lang.Number) (-7.231717743255292d), true);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getGeneralPattern();
        java.lang.Number number6 = null;
        java.lang.Number number7 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException9 = new org.apache.commons.math.exception.OutOfRangeException(localizable5, number6, number7, (java.lang.Number) 10);
        java.lang.Number number10 = outOfRangeException9.getLo();
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException17 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable13, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable18 = numberIsTooSmallException17.getGeneralPattern();
        java.lang.Throwable[] throwableArray19 = numberIsTooSmallException17.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException("", (java.lang.Object[]) throwableArray19);
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException9, "hi!", (java.lang.Object[]) throwableArray19);
        org.apache.commons.math.exception.util.Localizable localizable22 = mathException21.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNull(number10);
        org.junit.Assert.assertTrue("'" + localizable18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable18.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertNotNull(localizable22);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        double double2 = org.apache.commons.math.util.FastMath.max(0.0d, 0.19969790180335623d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.19969790180335623d + "'", double2 == 0.19969790180335623d);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        double double2 = org.apache.commons.math.util.FastMath.min(0.46336689408012516d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        double double1 = org.apache.commons.math.util.FastMath.signum((-7.231717743255292d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.48670120172084486d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 10.0d);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0L, (java.lang.Number) 0.0f, false);
        java.lang.Number number4 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.0f + "'", number4.equals(0.0f));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 79.76983250626756d, (java.lang.Number) Double.NaN, false);
        java.lang.Class<?> wildcardClass4 = numberIsTooSmallException3.getClass();
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException10 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable6, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooSmallException10.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException15 = new org.apache.commons.math.exception.OutOfRangeException(localizable11, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray17 = mathException16.getArguments();
        java.lang.Throwable[] throwableArray18 = mathException16.getSuppressed();
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException5, localizable11, (java.lang.Object[]) throwableArray18);
        java.lang.Object[] objArray20 = null;
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException(localizable11, objArray20);
        org.apache.commons.math.exception.util.Localizable localizable22 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException26 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable22, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable27 = numberIsTooSmallException26.getGeneralPattern();
        java.lang.Number number28 = null;
        java.lang.Number number29 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException31 = new org.apache.commons.math.exception.OutOfRangeException(localizable27, number28, number29, (java.lang.Number) 10);
        org.apache.commons.math.MathException mathException32 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException31);
        org.apache.commons.math.ConvergenceException convergenceException33 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException31);
        java.lang.Number number34 = outOfRangeException31.getLo();
        java.lang.Number number35 = outOfRangeException31.getLo();
        java.lang.Number number36 = outOfRangeException31.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable37 = outOfRangeException31.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable38 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException42 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable38, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable43 = numberIsTooSmallException42.getGeneralPattern();
        java.lang.Number number44 = null;
        java.lang.Number number45 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException47 = new org.apache.commons.math.exception.OutOfRangeException(localizable43, number44, number45, (java.lang.Number) 10);
        org.apache.commons.math.MathException mathException48 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException47);
        java.lang.Number number49 = outOfRangeException47.getHi();
        java.lang.Throwable[] throwableArray50 = outOfRangeException47.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException51 = new org.apache.commons.math.ConvergenceException(localizable37, (java.lang.Object[]) throwableArray50);
        org.apache.commons.math.MathException mathException54 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable55 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException59 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable55, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable60 = numberIsTooSmallException59.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException64 = new org.apache.commons.math.exception.OutOfRangeException(localizable60, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException65 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray66 = mathException65.getArguments();
        java.lang.Throwable[] throwableArray67 = mathException65.getSuppressed();
        org.apache.commons.math.MathException mathException68 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException54, localizable60, (java.lang.Object[]) throwableArray67);
        org.apache.commons.math.MathException mathException70 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray71 = mathException70.getArguments();
        java.lang.Throwable[] throwableArray72 = mathException70.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException73 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException54, "", (java.lang.Object[]) throwableArray72);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException74 = new org.apache.commons.math.MaxIterationsExceededException(0, "hi!", (java.lang.Object[]) throwableArray72);
        org.apache.commons.math.MathException mathException75 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException21, localizable37, (java.lang.Object[]) throwableArray72);
        java.lang.String str76 = mathException21.getPattern();
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) mathException21);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertTrue("'" + localizable27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable27.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNull(number34);
        org.junit.Assert.assertNull(number35);
        org.junit.Assert.assertNull(number36);
        org.junit.Assert.assertTrue("'" + localizable37 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable37.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable43 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable43.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + number49 + "' != '" + 10 + "'", number49.equals(10));
        org.junit.Assert.assertNotNull(throwableArray50);
        org.junit.Assert.assertTrue("'" + localizable60 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable60.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray66);
        org.junit.Assert.assertNotNull(throwableArray67);
        org.junit.Assert.assertNotNull(objArray71);
        org.junit.Assert.assertNotNull(throwableArray72);
        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "{0} is smaller than the minimum ({1})" + "'", str76.equals("{0} is smaller than the minimum ({1})"));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 79.76983250626756d, (java.lang.Number) Double.NaN, false);
        java.lang.Class<?> wildcardClass4 = numberIsTooSmallException3.getClass();
        java.lang.Number number5 = numberIsTooSmallException3.getMin();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertEquals((double) number5, Double.NaN, 0);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        double double1 = org.apache.commons.math.util.FastMath.signum((-36.21784016432742d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(4.571545345114974d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.659667198139738d + "'", double1 == 1.659667198139738d);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable1, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException5.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray12 = mathException11.getArguments();
        java.lang.Throwable[] throwableArray13 = mathException11.getSuppressed();
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException0, localizable6, (java.lang.Object[]) throwableArray13);
        java.lang.Object[] objArray15 = null;
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException(localizable6, objArray15);
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException21 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable17, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable22 = numberIsTooSmallException21.getGeneralPattern();
        java.lang.Number number23 = null;
        java.lang.Number number24 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException26 = new org.apache.commons.math.exception.OutOfRangeException(localizable22, number23, number24, (java.lang.Number) 10);
        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException26);
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException26);
        java.lang.Number number29 = outOfRangeException26.getLo();
        java.lang.Number number30 = outOfRangeException26.getLo();
        java.lang.Number number31 = outOfRangeException26.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable32 = outOfRangeException26.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException37 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable33, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable38 = numberIsTooSmallException37.getGeneralPattern();
        java.lang.Number number39 = null;
        java.lang.Number number40 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException42 = new org.apache.commons.math.exception.OutOfRangeException(localizable38, number39, number40, (java.lang.Number) 10);
        org.apache.commons.math.MathException mathException43 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException42);
        java.lang.Number number44 = outOfRangeException42.getHi();
        java.lang.Throwable[] throwableArray45 = outOfRangeException42.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException(localizable32, (java.lang.Object[]) throwableArray45);
        org.apache.commons.math.MathException mathException49 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable50 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException54 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable50, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable55 = numberIsTooSmallException54.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException59 = new org.apache.commons.math.exception.OutOfRangeException(localizable55, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException60 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray61 = mathException60.getArguments();
        java.lang.Throwable[] throwableArray62 = mathException60.getSuppressed();
        org.apache.commons.math.MathException mathException63 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException49, localizable55, (java.lang.Object[]) throwableArray62);
        org.apache.commons.math.MathException mathException65 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray66 = mathException65.getArguments();
        java.lang.Throwable[] throwableArray67 = mathException65.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException68 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException49, "", (java.lang.Object[]) throwableArray67);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException69 = new org.apache.commons.math.MaxIterationsExceededException(0, "hi!", (java.lang.Object[]) throwableArray67);
        org.apache.commons.math.MathException mathException70 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException16, localizable32, (java.lang.Object[]) throwableArray67);
        org.apache.commons.math.exception.util.Localizable localizable71 = null;
        org.apache.commons.math.MathException mathException72 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray73 = mathException72.getArguments();
        org.apache.commons.math.MathException mathException74 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException70, localizable71, objArray73);
        org.apache.commons.math.exception.util.Localizable localizable75 = mathException74.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertTrue("'" + localizable22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable22.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNull(number29);
        org.junit.Assert.assertNull(number30);
        org.junit.Assert.assertNull(number31);
        org.junit.Assert.assertTrue("'" + localizable32 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable32.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable38 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable38.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + number44 + "' != '" + 10 + "'", number44.equals(10));
        org.junit.Assert.assertNotNull(throwableArray45);
        org.junit.Assert.assertTrue("'" + localizable55 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable55.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray61);
        org.junit.Assert.assertNotNull(throwableArray62);
        org.junit.Assert.assertNotNull(objArray66);
        org.junit.Assert.assertNotNull(throwableArray67);
        org.junit.Assert.assertNotNull(objArray73);
        org.junit.Assert.assertNull(localizable75);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(99.99999999999999d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.641588833612778d + "'", double1 == 4.641588833612778d);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        double double1 = org.apache.commons.math.util.FastMath.cos(57.29577951308232d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7336545584598283d + "'", double1 == 0.7336545584598283d);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        try {
            int int3 = randomDataImpl0.nextZipf((int) '4', (-14.423394137532366d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -14.423 is smaller than, or equal to, the minimum (0): exponent (-14.423)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.3044465563407555d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.299929460301182d + "'", double1 == 0.299929460301182d);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        try {
            int int4 = randomDataImpl0.nextHypergeometric(7, (int) (short) 100, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100 is larger than the maximum (7): number of successes (100) must be less than or equal to population size (7)");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        try {
            double double3 = randomDataImpl0.nextBeta(38.40781474984203d, (double) (-1L));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.5 p = 0.715");
        } catch (org.apache.commons.math.exception.MathUserException e) {
        }
    }

//    @Test
//    public void test207() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test207");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) (short) 1);
//        double double3 = normalDistributionImpl2.sample();
//        double double5 = normalDistributionImpl2.density(Double.POSITIVE_INFINITY);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.1223781811861266d + "'", double3 == 1.1223781811861266d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
//    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.288405172032595d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9586987012903039d + "'", double1 == 0.9586987012903039d);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(100.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7453292519943295d + "'", double1 == 1.7453292519943295d);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        double double1 = org.apache.commons.math.util.FastMath.acos(61.67657891271361d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        double double1 = org.apache.commons.math.util.FastMath.cos(28.782429690343378d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8736725080126719d) + "'", double1 == (-0.8736725080126719d));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(4.9E-324d, 0.0d, 0.872447858588575d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): standard deviation (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((-3.864109722433218d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-221.3971786708914d) + "'", double1 == (-221.3971786708914d));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        double double1 = org.apache.commons.math.util.FastMath.signum(3.141592653589793d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getGeneralPattern();
        java.lang.Number number6 = null;
        java.lang.Number number7 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException9 = new org.apache.commons.math.exception.OutOfRangeException(localizable5, number6, number7, (java.lang.Number) 10);
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException9);
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException9);
        java.lang.Number number12 = outOfRangeException9.getLo();
        java.lang.Number number13 = outOfRangeException9.getLo();
        java.lang.Number number14 = outOfRangeException9.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable15 = outOfRangeException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException20 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable16, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable21 = numberIsTooSmallException20.getGeneralPattern();
        java.lang.Number number22 = null;
        java.lang.Number number23 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException25 = new org.apache.commons.math.exception.OutOfRangeException(localizable21, number22, number23, (java.lang.Number) 10);
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException25);
        java.lang.Number number27 = outOfRangeException25.getHi();
        java.lang.Throwable[] throwableArray28 = outOfRangeException25.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException(localizable15, (java.lang.Object[]) throwableArray28);
        java.lang.String str30 = convergenceException29.getPattern();
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertNull(number13);
        org.junit.Assert.assertNull(number14);
        org.junit.Assert.assertTrue("'" + localizable15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable15.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable21.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + number27 + "' != '" + 10 + "'", number27.equals(10));
        org.junit.Assert.assertNotNull(throwableArray28);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "{0} out of [{1}, {2}] range" + "'", str30.equals("{0} out of [{1}, {2}] range"));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        double double1 = org.apache.commons.math.util.FastMath.ceil((-0.8813735870195429d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (short) 0, (java.lang.Number) (short) 0, true);
        boolean boolean4 = numberIsTooSmallException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        int int2 = org.apache.commons.math.util.FastMath.max((-1), (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (short) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 97L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 97.0d + "'", double1 == 97.0d);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        double double1 = org.apache.commons.math.special.Erf.erf(61.67657891271361d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 10L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 10, (java.lang.Number) 0.11575187101581663d, true);
    }

//    @Test
//    public void test225() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test225");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (byte) 0, 3.141592653589793d);
//        try {
//            int int7 = randomDataImpl0.nextHypergeometric((int) (byte) 1, (int) (short) 10, 1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 10 is larger than the maximum (1): number of successes (10) must be less than or equal to population size (1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.7312119497990146d + "'", double3 == 2.7312119497990146d);
//    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) -1, (double) '#', (double) (-1L));
        normalDistributionImpl3.reseedRandomGenerator(1L);
        double double6 = normalDistributionImpl3.getStandardDeviation();
        try {
            double double8 = normalDistributionImpl3.inverseCumulativeProbability((double) (-1L));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: -1 out of [0, 1] range");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 35.0d + "'", double6 == 35.0d);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.46336689408012516d, 1.122717258875702d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.12161247345677362d + "'", double2 == 0.12161247345677362d);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(4.571545345114974d, 2.200736691117263E34d, 1.0d);
        try {
            double double5 = normalDistributionImpl3.inverseCumulativeProbability(23.20403525996744d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 23.204 out of [0, 1] range");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 52);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5515679276951895d + "'", double1 == 1.5515679276951895d);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.19969790180335623d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5845089524363901d + "'", double1 == 0.5845089524363901d);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeed();
        try {
            int int5 = randomDataImpl0.nextHypergeometric((int) (byte) 1, 95, 75);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 95 is larger than the maximum (1): number of successes (95) must be less than or equal to population size (1)");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (byte) -1, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (byte) 1, (float) 100);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

//    @Test
//    public void test234() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test234");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextCauchy(0.0d, (double) 32);
//        double double6 = randomDataImpl0.nextChiSquare((double) '4');
//        try {
//            int int9 = randomDataImpl0.nextInt((int) 'a', (int) (byte) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 97 is larger than, or equal to, the maximum (0): lower bound (97) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 32.68434156140545d + "'", double4 == 32.68434156140545d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 42.374533243960016d + "'", double6 == 42.374533243960016d);
//    }

//    @Test
//    public void test235() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test235");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextCauchy(0.0d, (double) 32);
//        double double6 = randomDataImpl0.nextExponential(359.1342053695754d);
//        randomDataImpl0.reSeedSecure((long) (short) 1);
//        double double10 = randomDataImpl0.nextT(57.29577951308232d);
//        double double13 = randomDataImpl0.nextCauchy(10.0d, (double) 32.0f);
//        randomDataImpl0.reSeedSecure((long) (byte) 100);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution16 = null;
//        try {
//            int int17 = randomDataImpl0.nextInversionDeviate(integerDistribution16);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 31.938667131887968d + "'", double4 == 31.938667131887968d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 749.0888350742596d + "'", double6 == 749.0888350742596d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.2015338805022824d + "'", double10 == 1.2015338805022824d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 175.57342997504523d + "'", double13 == 175.57342997504523d);
//    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(2.8553217231426142d, (double) 10, 3.450029527644452d);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        double double1 = org.apache.commons.math.util.FastMath.acos(99.99999999999999d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 'a');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.584967478670572d + "'", double1 == 4.584967478670572d);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP((-1.5574077246549023d), 0.0d, 0.0d, 95);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getGeneralPattern();
        java.lang.Number number6 = null;
        java.lang.Number number7 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException9 = new org.apache.commons.math.exception.OutOfRangeException(localizable5, number6, number7, (java.lang.Number) 10);
        java.lang.Number number10 = outOfRangeException9.getLo();
        java.lang.Number number11 = outOfRangeException9.getHi();
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNull(number10);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 10 + "'", number11.equals(10));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 52);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 52 + "'", int1 == 52);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException6 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable2, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable7 = numberIsTooSmallException6.getGeneralPattern();
        java.lang.Number number8 = null;
        java.lang.Number number9 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException11 = new org.apache.commons.math.exception.OutOfRangeException(localizable7, number8, number9, (java.lang.Number) 10);
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException11);
        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException11);
        java.lang.Number number14 = outOfRangeException11.getLo();
        java.lang.Number number15 = outOfRangeException11.getLo();
        java.lang.Number number16 = outOfRangeException11.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable17 = outOfRangeException11.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException22 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable18, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable23 = numberIsTooSmallException22.getGeneralPattern();
        java.lang.Number number24 = null;
        java.lang.Number number25 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException27 = new org.apache.commons.math.exception.OutOfRangeException(localizable23, number24, number25, (java.lang.Number) 10);
        org.apache.commons.math.MathException mathException28 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException27);
        java.lang.Number number29 = outOfRangeException27.getHi();
        java.lang.Throwable[] throwableArray30 = outOfRangeException27.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException(localizable17, (java.lang.Object[]) throwableArray30);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException35 = new org.apache.commons.math.exception.OutOfRangeException(localizable17, (java.lang.Number) (-0.8813735870195429d), (java.lang.Number) (byte) 0, (java.lang.Number) 1.3765887979465332d);
        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable40 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException44 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable40, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable45 = numberIsTooSmallException44.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException49 = new org.apache.commons.math.exception.OutOfRangeException(localizable45, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray51 = mathException50.getArguments();
        java.lang.Throwable[] throwableArray52 = mathException50.getSuppressed();
        org.apache.commons.math.MathException mathException53 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException39, localizable45, (java.lang.Object[]) throwableArray52);
        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException("hi!", (java.lang.Object[]) throwableArray52);
        org.apache.commons.math.ConvergenceException convergenceException55 = new org.apache.commons.math.ConvergenceException("2cc4bca353b0d36733d55b2ff91bbb544b5", (java.lang.Object[]) throwableArray52);
        org.apache.commons.math.ConvergenceException convergenceException56 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException35, "{0}", (java.lang.Object[]) throwableArray52);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException57 = new org.apache.commons.math.MaxIterationsExceededException(100, "2f1d926fce0959cfeb3f075273b1157c25fbc77c6071c7aef66e", (java.lang.Object[]) throwableArray52);
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNull(number14);
        org.junit.Assert.assertNull(number15);
        org.junit.Assert.assertNull(number16);
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable23.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + number29 + "' != '" + 10 + "'", number29.equals(10));
        org.junit.Assert.assertNotNull(throwableArray30);
        org.junit.Assert.assertTrue("'" + localizable45 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable45.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray51);
        org.junit.Assert.assertNotNull(throwableArray52);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((-1.5707963267948966d), 0.288405172032595d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.5707963267948963d) + "'", double2 == (-1.5707963267948963d));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.7336545584598283d, (-0.11948025350994579d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        int int2 = org.apache.commons.math.util.FastMath.min(90, (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

//    @Test
//    public void test247() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test247");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (byte) 0, 3.141592653589793d);
//        randomDataImpl0.reSeedSecure();
//        int[] intArray7 = randomDataImpl0.nextPermutation((int) (byte) 100, (int) (byte) 1);
//        randomDataImpl0.reSeed((long) (byte) -1);
//        double double11 = randomDataImpl0.nextT(0.7336545584598283d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.066490046725345d + "'", double3 == 2.066490046725345d);
//        org.junit.Assert.assertNotNull(intArray7);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-1.0197977355283092d) + "'", double11 == (-1.0197977355283092d));
//    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getGeneralPattern();
        java.lang.Number number6 = null;
        java.lang.Number number7 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException9 = new org.apache.commons.math.exception.OutOfRangeException(localizable5, number6, number7, (java.lang.Number) 10);
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException9);
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException9);
        java.lang.Number number12 = outOfRangeException9.getLo();
        java.lang.Number number13 = outOfRangeException9.getLo();
        java.lang.Number number14 = outOfRangeException9.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable15 = outOfRangeException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException20 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable16, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable21 = numberIsTooSmallException20.getGeneralPattern();
        java.lang.Number number22 = null;
        java.lang.Number number23 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException25 = new org.apache.commons.math.exception.OutOfRangeException(localizable21, number22, number23, (java.lang.Number) 10);
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException25);
        java.lang.Number number27 = outOfRangeException25.getHi();
        java.lang.Throwable[] throwableArray28 = outOfRangeException25.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException(localizable15, (java.lang.Object[]) throwableArray28);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException33 = new org.apache.commons.math.exception.OutOfRangeException(localizable15, (java.lang.Number) (-0.8813735870195429d), (java.lang.Number) (byte) 0, (java.lang.Number) 1.3765887979465332d);
        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable38 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException42 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable38, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable43 = numberIsTooSmallException42.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException47 = new org.apache.commons.math.exception.OutOfRangeException(localizable43, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException48 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray49 = mathException48.getArguments();
        java.lang.Throwable[] throwableArray50 = mathException48.getSuppressed();
        org.apache.commons.math.MathException mathException51 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException37, localizable43, (java.lang.Object[]) throwableArray50);
        org.apache.commons.math.MathException mathException53 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray54 = mathException53.getArguments();
        java.lang.Throwable[] throwableArray55 = mathException53.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException56 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException37, "", (java.lang.Object[]) throwableArray55);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException57 = new org.apache.commons.math.MaxIterationsExceededException(0, "hi!", (java.lang.Object[]) throwableArray55);
        org.apache.commons.math.MathException mathException58 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException33, "", (java.lang.Object[]) throwableArray55);
        java.lang.Object[] objArray59 = outOfRangeException33.getArguments();
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertNull(number13);
        org.junit.Assert.assertNull(number14);
        org.junit.Assert.assertTrue("'" + localizable15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable15.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable21.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + number27 + "' != '" + 10 + "'", number27.equals(10));
        org.junit.Assert.assertNotNull(throwableArray28);
        org.junit.Assert.assertTrue("'" + localizable43 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable43.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertNotNull(throwableArray50);
        org.junit.Assert.assertNotNull(objArray54);
        org.junit.Assert.assertNotNull(throwableArray55);
        org.junit.Assert.assertNotNull(objArray59);
    }

//    @Test
//    public void test249() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test249");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextCauchy(0.0d, (double) 32);
//        double double6 = randomDataImpl0.nextChiSquare((double) '4');
//        double double9 = randomDataImpl0.nextWeibull(0.8813735870195429d, (double) 32);
//        try {
//            int int12 = randomDataImpl0.nextZipf((-1), 2.749504722793435d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): dimension (-1)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 10.030741323292515d + "'", double4 == 10.030741323292515d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 57.01637276168616d + "'", double6 == 57.01637276168616d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 111.75680528672514d + "'", double9 == 111.75680528672514d);
//    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        double double2 = org.apache.commons.math.util.FastMath.pow((-0.0d), 1.1071487177940904d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException9 = new org.apache.commons.math.exception.OutOfRangeException(localizable5, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        java.lang.Number number10 = outOfRangeException9.getHi();
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + (-1) + "'", number10.equals((-1)));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        double double2 = org.apache.commons.math.util.FastMath.max((-221.3971786708914d), (-0.0710722644357374d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.0710722644357374d) + "'", double2 == (-0.0710722644357374d));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeed();
        org.apache.commons.math.distribution.IntegerDistribution integerDistribution2 = null;
        try {
            int int3 = randomDataImpl0.nextInversionDeviate(integerDistribution2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 52, (long) (byte) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52L + "'", long2 == 52L);
    }

//    @Test
//    public void test256() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test256");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (byte) 0, 3.141592653589793d);
//        randomDataImpl0.reSeedSecure();
//        try {
//            int int7 = randomDataImpl0.nextPascal(75, 2.732900526423743d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 2.733 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.917051764450959d + "'", double3 == 1.917051764450959d);
//    }

//    @Test
//    public void test257() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test257");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (byte) 0, 3.141592653589793d);
//        randomDataImpl0.reSeedSecure();
//        int[] intArray7 = randomDataImpl0.nextPermutation((int) (byte) 100, (int) (byte) 1);
//        double double10 = randomDataImpl0.nextF((double) 100.0f, 100.0d);
//        double double12 = randomDataImpl0.nextChiSquare(96.016795330599d);
//        try {
//            double double15 = randomDataImpl0.nextBeta((double) (byte) 10, (-0.11948025350994579d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.5 p = 0.762");
//        } catch (org.apache.commons.math.exception.MathUserException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.9691159294998062d + "'", double3 == 1.9691159294998062d);
//        org.junit.Assert.assertNotNull(intArray7);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.9159771230526649d + "'", double10 == 0.9159771230526649d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 85.40591945359883d + "'", double12 == 85.40591945359883d);
//    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(56.323531978340306d, (double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 56.3235319783403d + "'", double2 == 56.3235319783403d);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException7 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable3, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable8 = numberIsTooSmallException7.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException12 = new org.apache.commons.math.exception.OutOfRangeException(localizable8, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray14 = mathException13.getArguments();
        java.lang.Throwable[] throwableArray15 = mathException13.getSuppressed();
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException2, localizable8, (java.lang.Object[]) throwableArray15);
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray19 = mathException18.getArguments();
        java.lang.Throwable[] throwableArray20 = mathException18.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException2, "", (java.lang.Object[]) throwableArray20);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException22 = new org.apache.commons.math.MaxIterationsExceededException(0, "hi!", (java.lang.Object[]) throwableArray20);
        org.apache.commons.math.exception.util.Localizable localizable23 = maxIterationsExceededException22.getSpecificPattern();
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException22);
        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(throwableArray20);
        org.junit.Assert.assertNull(localizable23);
    }

//    @Test
//    public void test260() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test260");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (byte) 0, 3.141592653589793d);
//        randomDataImpl0.reSeedSecure();
//        int[] intArray7 = randomDataImpl0.nextPermutation((int) (byte) 100, (int) (byte) 1);
//        try {
//            double double10 = randomDataImpl0.nextUniform(85.74665507483543d, 27.02294661501453d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 85.747 is larger than, or equal to, the maximum (27.023): lower bound (85.747) must be strictly less than upper bound (27.023)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.9819755126811263d + "'", double3 == 2.9819755126811263d);
//        org.junit.Assert.assertNotNull(intArray7);
//    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        double double1 = org.apache.commons.math.util.FastMath.acos(49.40634799044653d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getGeneralPattern();
        java.lang.Number number6 = null;
        java.lang.Number number7 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException9 = new org.apache.commons.math.exception.OutOfRangeException(localizable5, number6, number7, (java.lang.Number) 10);
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException9);
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException9);
        java.lang.Number number12 = outOfRangeException9.getLo();
        java.lang.Number number13 = outOfRangeException9.getLo();
        java.lang.Number number14 = outOfRangeException9.getLo();
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertNull(number13);
        org.junit.Assert.assertNull(number14);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        double double1 = org.apache.commons.math.util.FastMath.asinh(79.76983250626756d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.072331860704032d + "'", double1 == 5.072331860704032d);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        try {
            double double4 = randomDataImpl1.nextUniform(0.0d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 0 is larger than, or equal to, the maximum (0): lower bound (0) must be strictly less than upper bound (0)");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(57.29577951308232d, 1.1071487177940904d, 0.299929460301182d, 10);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.48670120172084486d, (double) ' ');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.015208239937836163d + "'", double2 == 0.015208239937836163d);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        double double2 = org.apache.commons.math.util.FastMath.atan2((-43.833853519263435d), 1.3765887979465332d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.5394019500911686d) + "'", double2 == (-1.5394019500911686d));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        long long2 = org.apache.commons.math.util.FastMath.max((long) ' ', 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
    }

//    @Test
//    public void test269() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test269");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (byte) 0, 3.141592653589793d);
//        try {
//            int int6 = randomDataImpl0.nextInt((int) (short) 100, (int) (short) -1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100 is larger than, or equal to, the maximum (-1): lower bound (100) must be strictly less than upper bound (-1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.636100466144313d + "'", double3 == 2.636100466144313d);
//    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ((-1.0197977355283092d), 0.5845089524363901d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.8645945657283335d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

//    @Test
//    public void test272() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test272");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextCauchy(0.0d, (double) 32);
//        double double6 = randomDataImpl0.nextChiSquare((double) '4');
//        double double8 = randomDataImpl0.nextT((double) 35);
//        try {
//            int int11 = randomDataImpl0.nextInt((int) (short) 0, (int) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 0 is larger than, or equal to, the maximum (-1): lower bound (0) must be strictly less than upper bound (-1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-78.22119830737161d) + "'", double4 == (-78.22119830737161d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 49.97024127085587d + "'", double6 == 49.97024127085587d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-0.0978136857550743d) + "'", double8 == (-0.0978136857550743d));
//    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (short) 0, (java.lang.Number) 0.8813735870195429d, false);
        java.lang.Number number4 = numberIsTooSmallException3.getMin();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (short) 0, (java.lang.Number) (short) 0, true);
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException8);
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException8);
        boolean boolean11 = numberIsTooSmallException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.8813735870195429d + "'", number4.equals(0.8813735870195429d));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 97L, (double) (short) 1, (double) (byte) 0);
        double double5 = normalDistributionImpl3.inverseCumulativeProbability(0.5765158901134363d);
        double double6 = normalDistributionImpl3.getStandardDeviation();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 97.19298818676732d + "'", double5 == 97.19298818676732d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(14.154262241479262d, (-0.9021599785389828d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 14.15426224147926d + "'", double2 == 14.15426224147926d);
    }

//    @Test
//    public void test276() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test276");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextCauchy(0.0d, (double) 32);
//        double double6 = randomDataImpl0.nextExponential(359.1342053695754d);
//        randomDataImpl0.reSeedSecure((long) (short) 1);
//        java.lang.String str10 = randomDataImpl0.nextSecureHexString((int) ' ');
//        int int13 = randomDataImpl0.nextZipf((int) (short) 1, 4.571545345114974d);
//        double double15 = randomDataImpl0.nextT((double) ' ');
//        try {
//            randomDataImpl0.setSecureAlgorithm("b921bd76c95e3ab3954bb24c0f1934e7", "2f1d926fce0959cfeb3f075273b1157c25fbc77c6071c7aef66e");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: 2f1d926fce0959cfeb3f075273b1157c25fbc77c6071c7aef66e");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-204.01665353202205d) + "'", double4 == (-204.01665353202205d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 149.70985215665533d + "'", double6 == 149.70985215665533d);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "db8c689d2b0e2925aa6e3292e4506ad7" + "'", str10.equals("db8c689d2b0e2925aa6e3292e4506ad7"));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.3831835957936916d + "'", double15 == 0.3831835957936916d);
//    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ((-24.892838891815952d), 0.9999999999989843d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(96.34500443880789d, 79.76983250626756d, 0.288405172032595d);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        double double1 = org.apache.commons.math.util.FastMath.atanh((-1.5574077246549023d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        double double2 = org.apache.commons.math.util.FastMath.pow(97.00000000000001d, 3.9512437185814275d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.083034143026365E7d + "'", double2 == 7.083034143026365E7d);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        double double1 = org.apache.commons.math.util.FastMath.acosh(1303.3950961665462d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.865874784952156d + "'", double1 == 7.865874784952156d);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.288405172032595d, (-1.5394019500911686d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 'a');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 97 + "'", int1 == 97);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        double double2 = org.apache.commons.math.util.FastMath.atan2((-27.840419813850996d), (-24.892838891815952d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-2.300356543518642d) + "'", double2 == (-2.300356543518642d));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.MathException mathException3 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray4 = mathException3.getArguments();
        java.lang.Throwable[] throwableArray5 = mathException3.getSuppressed();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException6 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a', localizable2, (java.lang.Object[]) throwableArray5);
        org.apache.commons.math.MathException mathException7 = new org.apache.commons.math.MathException(localizable0, (java.lang.Object[]) throwableArray5);
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 90, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): standard deviation (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        double double1 = org.apache.commons.math.util.FastMath.cos(61.67657891271361d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4036677195930801d + "'", double1 == 0.4036677195930801d);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        double double1 = org.apache.commons.math.util.FastMath.floor((-43.833853519263435d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-44.0d) + "'", double1 == (-44.0d));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 97L, (double) (short) 1, (double) (byte) 0);
        double double5 = normalDistributionImpl3.inverseCumulativeProbability(0.5765158901134363d);
        double double7 = normalDistributionImpl3.density((-1.5707963267948963d));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 97.19298818676732d + "'", double5 == 97.19298818676732d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.36013841202237246d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

//    @Test
//    public void test293() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test293");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (byte) 0, 3.141592653589793d);
//        java.lang.String str5 = randomDataImpl0.nextHexString(52);
//        long long8 = randomDataImpl0.nextLong((long) 10, (long) 35);
//        randomDataImpl0.reSeed();
//        try {
//            int int12 = randomDataImpl0.nextPascal((int) (byte) 1, 96.016795330599d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 96.017 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.26787211479635853d + "'", double3 == 0.26787211479635853d);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "c2a44a82577ca07a7690f20ce3b3d087d5a42904b91ee64fe41d" + "'", str5.equals("c2a44a82577ca07a7690f20ce3b3d087d5a42904b91ee64fe41d"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 11L + "'", long8 == 11L);
//    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 32L);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.0d, 99.99999999999999d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        double double1 = org.apache.commons.math.util.FastMath.asin(1.5713413291617189d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        float float2 = org.apache.commons.math.util.FastMath.max(0.0f, 100.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

//    @Test
//    public void test298() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test298");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (byte) 0, 3.141592653589793d);
//        java.lang.String str5 = randomDataImpl0.nextHexString(52);
//        long long8 = randomDataImpl0.nextLong((long) 10, (long) 35);
//        randomDataImpl0.reSeedSecure((long) (short) 100);
//        try {
//            double double13 = randomDataImpl0.nextGamma(7.865874784952156d, (double) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): beta");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.014305455610899387d + "'", double3 == 0.014305455610899387d);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "dc4db8452d0de643753577e2a71d5ab8eb4abeda50fe4e86714d" + "'", str5.equals("dc4db8452d0de643753577e2a71d5ab8eb4abeda50fe4e86714d"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 17L + "'", long8 == 17L);
//    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        double double1 = org.apache.commons.math.special.Gamma.digamma((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

//    @Test
//    public void test300() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test300");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (byte) 0, 3.141592653589793d);
//        java.lang.String str5 = randomDataImpl0.nextHexString(52);
//        long long8 = randomDataImpl0.nextLong((long) 10, (long) 35);
//        try {
//            double double10 = randomDataImpl0.nextChiSquare((-142.3281413805767d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -71.164 is smaller than, or equal to, the minimum (0): alpha");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.006144048738091797d + "'", double3 == 0.006144048738091797d);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "a3e36b2f268d3a7e2a8d5b6c4fd9f9cf1bec64890df7143d9de2" + "'", str5.equals("a3e36b2f268d3a7e2a8d5b6c4fd9f9cf1bec64890df7143d9de2"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 15L + "'", long8 == 15L);
//    }

//    @Test
//    public void test301() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test301");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextCauchy(0.0d, (double) 32);
//        double double6 = randomDataImpl0.nextExponential(359.1342053695754d);
//        randomDataImpl0.reSeedSecure((long) (short) 1);
//        java.lang.String str10 = randomDataImpl0.nextSecureHexString((int) ' ');
//        int int13 = randomDataImpl0.nextZipf((int) (short) 1, 4.571545345114974d);
//        randomDataImpl0.reSeed();
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-29675.81173637713d) + "'", double4 == (-29675.81173637713d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 108.63026413900305d + "'", double6 == 108.63026413900305d);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "b61c086a27938ef74afb0dabdcf8e66c" + "'", str10.equals("b61c086a27938ef74afb0dabdcf8e66c"));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getGeneralPattern();
        java.lang.Number number6 = null;
        java.lang.Number number7 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException9 = new org.apache.commons.math.exception.OutOfRangeException(localizable5, number6, number7, (java.lang.Number) 10);
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException9);
        org.apache.commons.math.exception.util.Localizable localizable11 = mathException10.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException15 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable11, (java.lang.Number) 1.5515679276951895d, (java.lang.Number) 1.5515679276951895d, false);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException19 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable11, (java.lang.Number) (-116.20953636056122d), (java.lang.Number) 38.40781474984203d, false);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
    }

//    @Test
//    public void test303() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test303");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextCauchy(0.0d, (double) 32);
//        int int7 = randomDataImpl0.nextSecureInt(0, (int) (short) 10);
//        try {
//            long long10 = randomDataImpl0.nextLong((long) 90, 5L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 90 is larger than, or equal to, the maximum (5): lower bound (90) must be strictly less than upper bound (5)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-586.0397707483586d) + "'", double4 == (-586.0397707483586d));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
//    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((-7.231717743255292d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-7.231717743255291d) + "'", double1 == (-7.231717743255291d));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 100L + "'", long1 == 100L);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(32.00000000000001d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5585053606381856d + "'", double1 == 0.5585053606381856d);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 52, 52L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52L + "'", long2 == 52L);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.501590259893643d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4065247197838044d + "'", double1 == 0.4065247197838044d);
    }

//    @Test
//    public void test310() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test310");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (byte) 0, 3.141592653589793d);
//        java.lang.String str5 = randomDataImpl0.nextHexString(52);
//        int int8 = randomDataImpl0.nextPascal(35, 0.9586987012903039d);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution9 = null;
//        try {
//            int int10 = randomDataImpl0.nextInversionDeviate(integerDistribution9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.07340530978273536d + "'", double3 == 0.07340530978273536d);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "b16003aa93d00e0855ba471f1377e50360525e922d8be1bc1663" + "'", str5.equals("b16003aa93d00e0855ba471f1377e50360525e922d8be1bc1663"));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        double double1 = org.apache.commons.math.util.FastMath.expm1(1.5707963267948966d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.8104773809653514d + "'", double1 == 3.8104773809653514d);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) (short) 1);
        double double4 = normalDistributionImpl2.cumulativeProbability((-0.8427007929497151d));
        double double6 = normalDistributionImpl2.inverseCumulativeProbability((double) (short) 0);
        double double7 = normalDistributionImpl2.getMean();
        double double8 = normalDistributionImpl2.getStandardDeviation();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.19969790180335623d + "'", double4 == 0.19969790180335623d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.NEGATIVE_INFINITY + "'", double6 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.8645945657283335d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3112627113980244d + "'", double1 == 1.3112627113980244d);
    }

//    @Test
//    public void test314() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test314");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int int4 = randomDataImpl0.nextHypergeometric(10, 0, 0);
//        double double7 = randomDataImpl0.nextUniform(1.3765887979465332d, 1303.3950961665462d);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution8 = null;
//        try {
//            int int9 = randomDataImpl0.nextInversionDeviate(integerDistribution8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 496.93512750983314d + "'", double7 == 496.93512750983314d);
//    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.298342365610589d + "'", double1 == 5.298342365610589d);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 97L, (double) (short) 1, (double) (byte) 0);
        double double5 = normalDistributionImpl3.inverseCumulativeProbability(0.5765158901134363d);
        normalDistributionImpl3.reseedRandomGenerator((long) 32);
        double double9 = normalDistributionImpl3.density((-0.9193443348656242d));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 97.19298818676732d + "'", double5 == 97.19298818676732d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable1, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException5.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray12 = mathException11.getArguments();
        java.lang.Throwable[] throwableArray13 = mathException11.getSuppressed();
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException0, localizable6, (java.lang.Object[]) throwableArray13);
        java.lang.Object[] objArray15 = null;
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException(localizable6, objArray15);
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException21 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable17, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable22 = numberIsTooSmallException21.getGeneralPattern();
        java.lang.Number number23 = null;
        java.lang.Number number24 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException26 = new org.apache.commons.math.exception.OutOfRangeException(localizable22, number23, number24, (java.lang.Number) 10);
        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException26);
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException26);
        java.lang.Number number29 = outOfRangeException26.getLo();
        java.lang.Number number30 = outOfRangeException26.getLo();
        java.lang.Number number31 = outOfRangeException26.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable32 = outOfRangeException26.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException37 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable33, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable38 = numberIsTooSmallException37.getGeneralPattern();
        java.lang.Number number39 = null;
        java.lang.Number number40 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException42 = new org.apache.commons.math.exception.OutOfRangeException(localizable38, number39, number40, (java.lang.Number) 10);
        org.apache.commons.math.MathException mathException43 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException42);
        java.lang.Number number44 = outOfRangeException42.getHi();
        java.lang.Throwable[] throwableArray45 = outOfRangeException42.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException(localizable32, (java.lang.Object[]) throwableArray45);
        org.apache.commons.math.MathException mathException49 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable50 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException54 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable50, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable55 = numberIsTooSmallException54.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException59 = new org.apache.commons.math.exception.OutOfRangeException(localizable55, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException60 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray61 = mathException60.getArguments();
        java.lang.Throwable[] throwableArray62 = mathException60.getSuppressed();
        org.apache.commons.math.MathException mathException63 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException49, localizable55, (java.lang.Object[]) throwableArray62);
        org.apache.commons.math.MathException mathException65 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray66 = mathException65.getArguments();
        java.lang.Throwable[] throwableArray67 = mathException65.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException68 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException49, "", (java.lang.Object[]) throwableArray67);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException69 = new org.apache.commons.math.MaxIterationsExceededException(0, "hi!", (java.lang.Object[]) throwableArray67);
        org.apache.commons.math.MathException mathException70 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException16, localizable32, (java.lang.Object[]) throwableArray67);
        org.apache.commons.math.exception.util.Localizable localizable71 = mathException70.getGeneralPattern();
        java.lang.String str72 = mathException70.getPattern();
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertTrue("'" + localizable22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable22.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNull(number29);
        org.junit.Assert.assertNull(number30);
        org.junit.Assert.assertNull(number31);
        org.junit.Assert.assertTrue("'" + localizable32 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable32.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable38 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable38.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + number44 + "' != '" + 10 + "'", number44.equals(10));
        org.junit.Assert.assertNotNull(throwableArray45);
        org.junit.Assert.assertTrue("'" + localizable55 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable55.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray61);
        org.junit.Assert.assertNotNull(throwableArray62);
        org.junit.Assert.assertNotNull(objArray66);
        org.junit.Assert.assertNotNull(throwableArray67);
        org.junit.Assert.assertTrue("'" + localizable71 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable71.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "{0} out of [{1}, {2}] range" + "'", str72.equals("{0} out of [{1}, {2}] range"));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable1, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException5.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException16 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable12, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable17 = numberIsTooSmallException16.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException21 = new org.apache.commons.math.exception.OutOfRangeException(localizable17, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray23 = mathException22.getArguments();
        java.lang.Throwable[] throwableArray24 = mathException22.getSuppressed();
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException11, localizable17, (java.lang.Object[]) throwableArray24);
        java.lang.Object[] objArray26 = null;
        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException(localizable17, objArray26);
        org.apache.commons.math.MathException mathException28 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray29 = mathException28.getArguments();
        java.lang.Throwable[] throwableArray30 = mathException28.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException31 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable17, (java.lang.Object[]) throwableArray30);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException32 = new org.apache.commons.math.MaxIterationsExceededException((-1), localizable6, (java.lang.Object[]) throwableArray30);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException36 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (short) 0, (java.lang.Number) (short) 0, true);
        java.lang.Throwable[] throwableArray37 = numberIsTooSmallException36.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException38 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, (java.lang.Object[]) throwableArray37);
        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable40 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException44 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable40, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable45 = numberIsTooSmallException44.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException49 = new org.apache.commons.math.exception.OutOfRangeException(localizable45, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray51 = mathException50.getArguments();
        java.lang.Throwable[] throwableArray52 = mathException50.getSuppressed();
        org.apache.commons.math.MathException mathException53 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException39, localizable45, (java.lang.Object[]) throwableArray52);
        org.apache.commons.math.exception.util.Localizable localizable54 = null;
        org.apache.commons.math.MathException mathException56 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable57 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException61 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable57, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable62 = numberIsTooSmallException61.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException66 = new org.apache.commons.math.exception.OutOfRangeException(localizable62, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException67 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray68 = mathException67.getArguments();
        java.lang.Throwable[] throwableArray69 = mathException67.getSuppressed();
        org.apache.commons.math.MathException mathException70 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException56, localizable62, (java.lang.Object[]) throwableArray69);
        org.apache.commons.math.ConvergenceException convergenceException71 = new org.apache.commons.math.ConvergenceException("hi!", (java.lang.Object[]) throwableArray69);
        org.apache.commons.math.ConvergenceException convergenceException72 = new org.apache.commons.math.ConvergenceException(localizable54, (java.lang.Object[]) throwableArray69);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException73 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, localizable45, (java.lang.Object[]) throwableArray69);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException77 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable45, (java.lang.Number) 7, (java.lang.Number) (-0.9193443348656242d), true);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNotNull(throwableArray24);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(throwableArray30);
        org.junit.Assert.assertNotNull(throwableArray37);
        org.junit.Assert.assertTrue("'" + localizable45 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable45.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray51);
        org.junit.Assert.assertNotNull(throwableArray52);
        org.junit.Assert.assertTrue("'" + localizable62 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable62.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray68);
        org.junit.Assert.assertNotNull(throwableArray69);
    }

//    @Test
//    public void test319() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test319");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) (short) 1);
//        double double4 = normalDistributionImpl2.cumulativeProbability((-0.8427007929497151d));
//        double double5 = normalDistributionImpl2.sample();
//        double double6 = normalDistributionImpl2.getMean();
//        java.lang.Class<?> wildcardClass7 = normalDistributionImpl2.getClass();
//        double double8 = normalDistributionImpl2.getMean();
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.19969790180335623d + "'", double4 == 0.19969790180335623d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-0.743308732126873d) + "'", double5 == (-0.743308732126873d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
//    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.501590259893643d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0453603017892203d + "'", double1 == 1.0453603017892203d);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 79.76983250626756d, (java.lang.Number) Double.NaN, false);
        java.lang.Number number4 = numberIsTooSmallException3.getMin();
        org.junit.Assert.assertEquals((double) number4, Double.NaN, 0);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getGeneralPattern();
        java.lang.Number number6 = null;
        java.lang.Number number7 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException9 = new org.apache.commons.math.exception.OutOfRangeException(localizable5, number6, number7, (java.lang.Number) 10);
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException9);
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException9);
        java.lang.Number number12 = outOfRangeException9.getLo();
        java.lang.Number number13 = outOfRangeException9.getLo();
        java.lang.Number number14 = outOfRangeException9.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable15 = outOfRangeException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException20 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable16, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable21 = numberIsTooSmallException20.getGeneralPattern();
        java.lang.Number number22 = null;
        java.lang.Number number23 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException25 = new org.apache.commons.math.exception.OutOfRangeException(localizable21, number22, number23, (java.lang.Number) 10);
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException25);
        java.lang.Number number27 = outOfRangeException25.getHi();
        java.lang.Throwable[] throwableArray28 = outOfRangeException25.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException(localizable15, (java.lang.Object[]) throwableArray28);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException31 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable15, (java.lang.Number) 100);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException35 = new org.apache.commons.math.exception.OutOfRangeException(localizable15, (java.lang.Number) 2.200736691117263E34d, (java.lang.Number) 75, (java.lang.Number) 28.782429690343378d);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertNull(number13);
        org.junit.Assert.assertNull(number14);
        org.junit.Assert.assertTrue("'" + localizable15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable15.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable21.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + number27 + "' != '" + 10 + "'", number27.equals(10));
        org.junit.Assert.assertNotNull(throwableArray28);
    }

//    @Test
//    public void test323() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test323");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (byte) 0, 3.141592653589793d);
//        randomDataImpl0.reSeedSecure();
//        int[] intArray7 = randomDataImpl0.nextPermutation((int) (byte) 100, (int) (byte) 1);
//        double double10 = randomDataImpl0.nextCauchy(0.5845089524363901d, (double) 5L);
//        double double12 = randomDataImpl0.nextChiSquare(0.8746788966462123d);
//        try {
//            long long14 = randomDataImpl0.nextPoisson((double) 0L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): mean (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.47359605049479087d + "'", double3 == 0.47359605049479087d);
//        org.junit.Assert.assertNotNull(intArray7);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.3578882111749766d + "'", double10 == 3.3578882111749766d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.7909740344634341d + "'", double12 == 0.7909740344634341d);
//    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.501590259893643d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8768190413350119d + "'", double1 == 0.8768190413350119d);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (short) 1, 90);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 90 + "'", int2 == 90);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        float float2 = org.apache.commons.math.util.FastMath.min(32.0f, (float) 75);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 32.0f + "'", float2 == 32.0f);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        double double1 = org.apache.commons.math.util.FastMath.asinh(1615.860954293143d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.08077046855213d + "'", double1 == 8.08077046855213d);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        double double2 = org.apache.commons.math.util.FastMath.min((-8.0d), (-2.0638064208948803d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-8.0d) + "'", double2 == (-8.0d));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(5.072331860704032d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.21784908449956822d + "'", double1 == 0.21784908449956822d);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        double double1 = org.apache.commons.math.util.FastMath.abs(61.67657891271361d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 61.67657891271361d + "'", double1 == 61.67657891271361d);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        double double1 = org.apache.commons.math.special.Erf.erf(419.21122575799876d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        double double1 = org.apache.commons.math.util.FastMath.cosh(1.2268016374392727d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.851766807940772d + "'", double1 == 1.851766807940772d);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable1, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException5.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray12 = mathException11.getArguments();
        java.lang.Throwable[] throwableArray13 = mathException11.getSuppressed();
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException0, localizable6, (java.lang.Object[]) throwableArray13);
        java.lang.Object[] objArray15 = null;
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException(localizable6, objArray15);
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException21 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable17, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable22 = numberIsTooSmallException21.getGeneralPattern();
        java.lang.Number number23 = null;
        java.lang.Number number24 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException26 = new org.apache.commons.math.exception.OutOfRangeException(localizable22, number23, number24, (java.lang.Number) 10);
        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException26);
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException26);
        java.lang.Number number29 = outOfRangeException26.getLo();
        java.lang.Number number30 = outOfRangeException26.getLo();
        java.lang.Number number31 = outOfRangeException26.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable32 = outOfRangeException26.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException37 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable33, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable38 = numberIsTooSmallException37.getGeneralPattern();
        java.lang.Number number39 = null;
        java.lang.Number number40 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException42 = new org.apache.commons.math.exception.OutOfRangeException(localizable38, number39, number40, (java.lang.Number) 10);
        org.apache.commons.math.MathException mathException43 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException42);
        java.lang.Number number44 = outOfRangeException42.getHi();
        java.lang.Throwable[] throwableArray45 = outOfRangeException42.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException(localizable32, (java.lang.Object[]) throwableArray45);
        org.apache.commons.math.MathException mathException49 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable50 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException54 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable50, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable55 = numberIsTooSmallException54.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException59 = new org.apache.commons.math.exception.OutOfRangeException(localizable55, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException60 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray61 = mathException60.getArguments();
        java.lang.Throwable[] throwableArray62 = mathException60.getSuppressed();
        org.apache.commons.math.MathException mathException63 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException49, localizable55, (java.lang.Object[]) throwableArray62);
        org.apache.commons.math.MathException mathException65 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray66 = mathException65.getArguments();
        java.lang.Throwable[] throwableArray67 = mathException65.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException68 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException49, "", (java.lang.Object[]) throwableArray67);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException69 = new org.apache.commons.math.MaxIterationsExceededException(0, "hi!", (java.lang.Object[]) throwableArray67);
        org.apache.commons.math.MathException mathException70 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException16, localizable32, (java.lang.Object[]) throwableArray67);
        org.apache.commons.math.exception.util.Localizable localizable71 = mathException16.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertTrue("'" + localizable22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable22.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNull(number29);
        org.junit.Assert.assertNull(number30);
        org.junit.Assert.assertNull(number31);
        org.junit.Assert.assertTrue("'" + localizable32 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable32.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable38 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable38.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + number44 + "' != '" + 10 + "'", number44.equals(10));
        org.junit.Assert.assertNotNull(throwableArray45);
        org.junit.Assert.assertTrue("'" + localizable55 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable55.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray61);
        org.junit.Assert.assertNotNull(throwableArray62);
        org.junit.Assert.assertNotNull(objArray66);
        org.junit.Assert.assertNotNull(throwableArray67);
        org.junit.Assert.assertNull(localizable71);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.apache.commons.math.MathException mathException3 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable9 = numberIsTooSmallException8.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException13 = new org.apache.commons.math.exception.OutOfRangeException(localizable9, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray15 = mathException14.getArguments();
        java.lang.Throwable[] throwableArray16 = mathException14.getSuppressed();
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException3, localizable9, (java.lang.Object[]) throwableArray16);
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray20 = mathException19.getArguments();
        java.lang.Throwable[] throwableArray21 = mathException19.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException3, "", (java.lang.Object[]) throwableArray21);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException23 = new org.apache.commons.math.MaxIterationsExceededException(0, "hi!", (java.lang.Object[]) throwableArray21);
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException("32af367880fc0bb0a716c1d0055c641dd6cf8007f14ea3270231", (java.lang.Object[]) throwableArray21);
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(throwableArray21);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.36787944117144233d + "'", double1 == 0.36787944117144233d);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException9 = new org.apache.commons.math.exception.OutOfRangeException(localizable5, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        java.lang.Class<?> wildcardClass10 = outOfRangeException9.getClass();
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

//    @Test
//    public void test337() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test337");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (byte) 0, 3.141592653589793d);
//        randomDataImpl0.reSeedSecure();
//        int[] intArray7 = randomDataImpl0.nextPermutation((int) (byte) 100, (int) (byte) 1);
//        double double10 = randomDataImpl0.nextF((double) 100.0f, 100.0d);
//        double double12 = randomDataImpl0.nextChiSquare(96.016795330599d);
//        double double14 = randomDataImpl0.nextT(419.21122575799876d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.6843968673252286d + "'", double3 == 0.6843968673252286d);
//        org.junit.Assert.assertNotNull(intArray7);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.1367103224267854d + "'", double10 == 1.1367103224267854d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 89.61962732806538d + "'", double12 == 89.61962732806538d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.7516038712662281d + "'", double14 == 0.7516038712662281d);
//    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP((double) (byte) 10, 2.0988822915763574d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.897137601554944E-5d + "'", double2 == 6.897137601554944E-5d);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(32.00000000000001d, 85.74665507483543d, 0.015208239937836163d, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 9.246117018011247E-12d + "'", double4 == 9.246117018011247E-12d);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException9 = new org.apache.commons.math.exception.OutOfRangeException(localizable5, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        java.lang.Object[] objArray10 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException(localizable5, objArray10);
        java.lang.Object[] objArray12 = null;
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException(localizable5, objArray12);
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException18 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable14, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable19 = numberIsTooSmallException18.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException23 = new org.apache.commons.math.exception.OutOfRangeException(localizable19, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        java.lang.Object[] objArray24 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException25 = new org.apache.commons.math.ConvergenceException(localizable19, objArray24);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException29 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable19, (java.lang.Number) 0.288405172032595d, (java.lang.Number) (byte) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable30 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException34 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable30, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable35 = numberIsTooSmallException34.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable36 = numberIsTooSmallException34.getGeneralPattern();
        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable38 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException42 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable38, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable43 = numberIsTooSmallException42.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException47 = new org.apache.commons.math.exception.OutOfRangeException(localizable43, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException48 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray49 = mathException48.getArguments();
        java.lang.Throwable[] throwableArray50 = mathException48.getSuppressed();
        org.apache.commons.math.MathException mathException51 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException37, localizable43, (java.lang.Object[]) throwableArray50);
        java.lang.Object[] objArray52 = null;
        org.apache.commons.math.MathException mathException53 = new org.apache.commons.math.MathException(localizable43, objArray52);
        org.apache.commons.math.MathException mathException54 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray55 = mathException54.getArguments();
        java.lang.Throwable[] throwableArray56 = mathException54.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException57 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable43, (java.lang.Object[]) throwableArray56);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException58 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable19, localizable36, (java.lang.Object[]) throwableArray56);
        org.apache.commons.math.exception.util.Localizable localizable59 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException63 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable59, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable64 = numberIsTooSmallException63.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException68 = new org.apache.commons.math.exception.OutOfRangeException(localizable64, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        java.lang.Object[] objArray69 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException70 = new org.apache.commons.math.ConvergenceException(localizable64, objArray69);
        java.lang.Object[] objArray71 = null;
        org.apache.commons.math.MathException mathException72 = new org.apache.commons.math.MathException(localizable64, objArray71);
        org.apache.commons.math.MathException mathException74 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable75 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException79 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable75, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable80 = numberIsTooSmallException79.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException84 = new org.apache.commons.math.exception.OutOfRangeException(localizable80, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException85 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray86 = mathException85.getArguments();
        java.lang.Throwable[] throwableArray87 = mathException85.getSuppressed();
        org.apache.commons.math.MathException mathException88 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException74, localizable80, (java.lang.Object[]) throwableArray87);
        org.apache.commons.math.ConvergenceException convergenceException89 = new org.apache.commons.math.ConvergenceException("hi!", (java.lang.Object[]) throwableArray87);
        org.apache.commons.math.ConvergenceException convergenceException90 = new org.apache.commons.math.ConvergenceException(localizable64, (java.lang.Object[]) throwableArray87);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException91 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable19, (java.lang.Object[]) throwableArray87);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertTrue("'" + localizable19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable19.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNull(localizable35);
        org.junit.Assert.assertTrue("'" + localizable36 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable36.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizable43 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable43.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertNotNull(throwableArray50);
        org.junit.Assert.assertNotNull(objArray55);
        org.junit.Assert.assertNotNull(throwableArray56);
        org.junit.Assert.assertTrue("'" + localizable64 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable64.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray69);
        org.junit.Assert.assertTrue("'" + localizable80 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable80.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray86);
        org.junit.Assert.assertNotNull(throwableArray87);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getGeneralPattern();
        java.lang.Number number6 = null;
        java.lang.Number number7 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException9 = new org.apache.commons.math.exception.OutOfRangeException(localizable5, number6, number7, (java.lang.Number) 10);
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException9);
        java.lang.Number number11 = outOfRangeException9.getHi();
        java.lang.Number number12 = outOfRangeException9.getHi();
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 10 + "'", number11.equals(10));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 10 + "'", number12.equals(10));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        long long1 = org.apache.commons.math.util.FastMath.round(97.00000000000001d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 97L + "'", long1 == 97L);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.ConvergenceException convergenceException1 = new org.apache.commons.math.ConvergenceException(throwable0);
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException(throwable0);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ((-0.21901116231973658d), 0.0d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(41.59222128968955d, 0.36013841202237246d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 41.59222128968954d + "'", double2 == 41.59222128968954d);
    }

//    @Test
//    public void test348() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test348");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextCauchy(0.0d, (double) 32);
//        double double6 = randomDataImpl0.nextChiSquare((double) '4');
//        double double9 = randomDataImpl0.nextWeibull(0.8813735870195429d, (double) 32);
//        java.lang.String str11 = randomDataImpl0.nextSecureHexString(35);
//        randomDataImpl0.reSeedSecure((long) 3);
//        try {
//            int int16 = randomDataImpl0.nextPascal(1, (-1.5574077246549023d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: -1.557 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.215303706582182d + "'", double4 == 4.215303706582182d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 49.58013847158083d + "'", double6 == 49.58013847158083d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 11.985068432806155d + "'", double9 == 11.985068432806155d);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "b14a16a8f76466899648b5a08986cf8cc3c" + "'", str11.equals("b14a16a8f76466899648b5a08986cf8cc3c"));
//    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getGeneralPattern();
        java.lang.Number number6 = null;
        java.lang.Number number7 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException9 = new org.apache.commons.math.exception.OutOfRangeException(localizable5, number6, number7, (java.lang.Number) 10);
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException9);
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException9);
        java.lang.Number number12 = outOfRangeException9.getLo();
        java.lang.Number number13 = outOfRangeException9.getLo();
        java.lang.Object[] objArray14 = outOfRangeException9.getArguments();
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException21 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable17, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable22 = numberIsTooSmallException21.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException26 = new org.apache.commons.math.exception.OutOfRangeException(localizable22, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray28 = mathException27.getArguments();
        java.lang.Throwable[] throwableArray29 = mathException27.getSuppressed();
        org.apache.commons.math.MathException mathException30 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException16, localizable22, (java.lang.Object[]) throwableArray29);
        java.lang.Throwable[] throwableArray31 = mathException16.getSuppressed();
        org.apache.commons.math.MathException mathException32 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException9, "ac1a383863ee2cf8c2a923bf52d4cf748b3", (java.lang.Object[]) throwableArray31);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertNull(number13);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertTrue("'" + localizable22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable22.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertNotNull(throwableArray29);
        org.junit.Assert.assertNotNull(throwableArray31);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        double double1 = org.apache.commons.math.util.FastMath.acosh(1206.606812147709d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.788714420573732d + "'", double1 == 7.788714420573732d);
    }

//    @Test
//    public void test351() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test351");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextCauchy(0.0d, (double) 32);
//        double double6 = randomDataImpl0.nextExponential(359.1342053695754d);
//        randomDataImpl0.reSeedSecure((long) (short) 1);
//        java.lang.String str10 = randomDataImpl0.nextSecureHexString((int) ' ');
//        try {
//            double double13 = randomDataImpl0.nextF((-116.20953636056122d), 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -116.21 is smaller than, or equal to, the minimum (0): degrees of freedom (-116.21)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 7.143188796453408d + "'", double4 == 7.143188796453408d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1340.897408853091d + "'", double6 == 1340.897408853091d);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "76992c139a1ef23554cbdf426c44f045" + "'", str10.equals("76992c139a1ef23554cbdf426c44f045"));
//    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 32L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.4657359027997265d + "'", double1 == 3.4657359027997265d);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 32, (long) (byte) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        double double1 = org.apache.commons.math.util.FastMath.log1p((-8.212797486430139d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        long long2 = org.apache.commons.math.util.FastMath.min(97L, (long) 97);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 97L + "'", long2 == 97L);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(0);
        int int2 = maxIterationsExceededException1.getMaxIterations();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        double double1 = org.apache.commons.math.util.FastMath.sin(41.74365116743245d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.78515518613775d) + "'", double1 == (-0.78515518613775d));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0L, (java.lang.Number) 0.0f, false);
        boolean boolean4 = numberIsTooLargeException3.getBoundIsAllowed();
        java.lang.String str5 = numberIsTooLargeException3.toString();
        java.lang.Throwable[] throwableArray6 = numberIsTooLargeException3.getSuppressed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NumberIsTooLargeException: 0 is larger than, or equal to, the maximum (0)" + "'", str5.equals("org.apache.commons.math.exception.NumberIsTooLargeException: 0 is larger than, or equal to, the maximum (0)"));
        org.junit.Assert.assertNotNull(throwableArray6);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 97L, (double) (short) 1, (double) (byte) 0);
        normalDistributionImpl3.reseedRandomGenerator((-1L));
        double double7 = normalDistributionImpl3.cumulativeProbability(108.63026413900305d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
    }

//    @Test
//    public void test361() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test361");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (byte) 0, 3.141592653589793d);
//        java.lang.String str5 = randomDataImpl0.nextHexString(52);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl9 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 97L, (double) (short) 1, (double) (byte) 0);
//        double double11 = normalDistributionImpl9.inverseCumulativeProbability(0.5765158901134363d);
//        double double12 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl9);
//        int[] intArray15 = randomDataImpl0.nextPermutation(35, (int) (byte) 10);
//        try {
//            double double17 = randomDataImpl0.nextExponential((-0.5872139151569291d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.587 is smaller than, or equal to, the minimum (0): mean (-0.587)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.5249475513680717d + "'", double3 == 2.5249475513680717d);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "fd70d503bfbf27efae94b9b9c611f0a28f8482515289992b9593" + "'", str5.equals("fd70d503bfbf27efae94b9b9c611f0a28f8482515289992b9593"));
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 97.19298818676732d + "'", double11 == 97.19298818676732d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 96.40540692830912d + "'", double12 == 96.40540692830912d);
//        org.junit.Assert.assertNotNull(intArray15);
//    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        double double1 = org.apache.commons.math.util.FastMath.cos(1.1462630722404248d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.41189551366724736d + "'", double1 == 0.41189551366724736d);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        double double1 = org.apache.commons.math.util.FastMath.sinh(41.59222128968955d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.7841853418467827E17d + "'", double1 == 5.7841853418467827E17d);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        double double1 = org.apache.commons.math.util.FastMath.cosh((-27.840419813850996d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.164682348792344E11d + "'", double1 == 6.164682348792344E11d);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 1L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

//    @Test
//    public void test366() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test366");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (byte) 0, 3.141592653589793d);
//        java.lang.String str5 = randomDataImpl0.nextHexString(52);
//        long long8 = randomDataImpl0.nextLong((long) 10, (long) 35);
//        randomDataImpl0.reSeed();
//        int int12 = randomDataImpl0.nextZipf(100, 48.52960137980076d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.3425822121650004d + "'", double3 == 2.3425822121650004d);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "bbed37e06e16210b7f3b3846551e2cd9697f603b18b2c64b508a" + "'", str5.equals("bbed37e06e16210b7f3b3846551e2cd9697f603b18b2c64b508a"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 20L + "'", long8 == 20L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        int int1 = org.apache.commons.math.util.FastMath.abs(100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(95);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.6144581759415864d, 2.200736691117263E34d);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        double double1 = org.apache.commons.math.util.FastMath.acos((-83.7545293260573d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable1, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException5.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        java.lang.Object[] objArray11 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException(localizable6, objArray11);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException16 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable6, (java.lang.Number) 0.288405172032595d, (java.lang.Number) (byte) -1, false);
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException24 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable20, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable25 = numberIsTooSmallException24.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException29 = new org.apache.commons.math.exception.OutOfRangeException(localizable25, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException30 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray31 = mathException30.getArguments();
        java.lang.Throwable[] throwableArray32 = mathException30.getSuppressed();
        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException19, localizable25, (java.lang.Object[]) throwableArray32);
        java.lang.Object[] objArray34 = null;
        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException(localizable25, objArray34);
        org.apache.commons.math.exception.util.Localizable localizable36 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException40 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable36, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable41 = numberIsTooSmallException40.getGeneralPattern();
        java.lang.Number number42 = null;
        java.lang.Number number43 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException45 = new org.apache.commons.math.exception.OutOfRangeException(localizable41, number42, number43, (java.lang.Number) 10);
        org.apache.commons.math.MathException mathException46 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException45);
        org.apache.commons.math.ConvergenceException convergenceException47 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException45);
        java.lang.Number number48 = outOfRangeException45.getLo();
        java.lang.Number number49 = outOfRangeException45.getLo();
        java.lang.Number number50 = outOfRangeException45.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable51 = outOfRangeException45.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable52 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException56 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable52, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable57 = numberIsTooSmallException56.getGeneralPattern();
        java.lang.Number number58 = null;
        java.lang.Number number59 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException61 = new org.apache.commons.math.exception.OutOfRangeException(localizable57, number58, number59, (java.lang.Number) 10);
        org.apache.commons.math.MathException mathException62 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException61);
        java.lang.Number number63 = outOfRangeException61.getHi();
        java.lang.Throwable[] throwableArray64 = outOfRangeException61.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException65 = new org.apache.commons.math.ConvergenceException(localizable51, (java.lang.Object[]) throwableArray64);
        org.apache.commons.math.MathException mathException68 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable69 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException73 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable69, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable74 = numberIsTooSmallException73.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException78 = new org.apache.commons.math.exception.OutOfRangeException(localizable74, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException79 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray80 = mathException79.getArguments();
        java.lang.Throwable[] throwableArray81 = mathException79.getSuppressed();
        org.apache.commons.math.MathException mathException82 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException68, localizable74, (java.lang.Object[]) throwableArray81);
        org.apache.commons.math.MathException mathException84 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray85 = mathException84.getArguments();
        java.lang.Throwable[] throwableArray86 = mathException84.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException87 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException68, "", (java.lang.Object[]) throwableArray86);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException88 = new org.apache.commons.math.MaxIterationsExceededException(0, "hi!", (java.lang.Object[]) throwableArray86);
        org.apache.commons.math.MathException mathException89 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException35, localizable51, (java.lang.Object[]) throwableArray86);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException90 = new org.apache.commons.math.MaxIterationsExceededException(35, "346ff53c6dcf49c36e2607360894de97", (java.lang.Object[]) throwableArray86);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException91 = new org.apache.commons.math.MaxIterationsExceededException(10, localizable6, (java.lang.Object[]) throwableArray86);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException95 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0L, (java.lang.Number) 0.0f, false);
        java.lang.Object[] objArray96 = numberIsTooLargeException95.getArguments();
        java.lang.Throwable[] throwableArray97 = numberIsTooLargeException95.getSuppressed();
        org.apache.commons.math.MathException mathException98 = new org.apache.commons.math.MathException(localizable6, (java.lang.Object[]) throwableArray97);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertTrue("'" + localizable25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable25.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(throwableArray32);
        org.junit.Assert.assertTrue("'" + localizable41 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable41.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNull(number48);
        org.junit.Assert.assertNull(number49);
        org.junit.Assert.assertNull(number50);
        org.junit.Assert.assertTrue("'" + localizable51 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable51.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable57 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable57.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + number63 + "' != '" + 10 + "'", number63.equals(10));
        org.junit.Assert.assertNotNull(throwableArray64);
        org.junit.Assert.assertTrue("'" + localizable74 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable74.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray80);
        org.junit.Assert.assertNotNull(throwableArray81);
        org.junit.Assert.assertNotNull(objArray85);
        org.junit.Assert.assertNotNull(throwableArray86);
        org.junit.Assert.assertNotNull(objArray96);
        org.junit.Assert.assertNotNull(throwableArray97);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 1.0f, (-116.20953636056122d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9999999999999999d + "'", double2 == 0.9999999999999999d);
    }

//    @Test
//    public void test373() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test373");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (byte) 0, 3.141592653589793d);
//        randomDataImpl0.reSeedSecure();
//        int[] intArray7 = randomDataImpl0.nextPermutation((int) (byte) 100, (int) (byte) 1);
//        double double10 = randomDataImpl0.nextF((double) 100.0f, 100.0d);
//        try {
//            double double13 = randomDataImpl0.nextBeta(0.0d, 0.6338492905650115d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.5 p = 0.349");
//        } catch (org.apache.commons.math.exception.MathUserException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.3201652729947988d + "'", double3 == 1.3201652729947988d);
//        org.junit.Assert.assertNotNull(intArray7);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.2889051149647037d + "'", double10 == 1.2889051149647037d);
//    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) 'a');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 97 + "'", int1 == 97);
    }

//    @Test
//    public void test375() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test375");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        int int4 = randomDataImpl0.nextInt(75, (int) 'a');
//        double double7 = randomDataImpl0.nextCauchy(0.8746788966462123d, 28.782429690343378d);
//        randomDataImpl0.reSeedSecure();
//        try {
//            double double11 = randomDataImpl0.nextBeta((-0.11948025350994579d), 110.10693527505083d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.5 p = 0.926");
//        } catch (org.apache.commons.math.exception.MathUserException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 89 + "'", int4 == 89);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 43.66636644397801d + "'", double7 == 43.66636644397801d);
//    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ((-0.9193443348656242d), 0.0d, 0.5585053606381856d, 75);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        double double1 = org.apache.commons.math.util.FastMath.log(97.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.574710978503383d + "'", double1 == 4.574710978503383d);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        double double1 = org.apache.commons.math.util.FastMath.ulp(9.9999999999999987E17d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 128.0d + "'", double1 == 128.0d);
    }

//    @Test
//    public void test380() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test380");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextCauchy(0.0d, (double) 32);
//        double double6 = randomDataImpl0.nextChiSquare((double) '4');
//        double double9 = randomDataImpl0.nextWeibull(0.8813735870195429d, (double) 32);
//        double double11 = randomDataImpl0.nextT(3.9512437185814275d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 16.72650105839174d + "'", double4 == 16.72650105839174d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 60.419108900158754d + "'", double6 == 60.419108900158754d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 157.5576293095328d + "'", double9 == 157.5576293095328d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.2307280868187975d + "'", double11 == 1.2307280868187975d);
//    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) '#');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 35 + "'", int1 == 35);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(35);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        double double1 = org.apache.commons.math.util.FastMath.atanh(105.10542445824282d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test384() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test384");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (byte) 0, 3.141592653589793d);
//        java.lang.String str5 = randomDataImpl0.nextHexString(52);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl9 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 97L, (double) (short) 1, (double) (byte) 0);
//        double double11 = normalDistributionImpl9.inverseCumulativeProbability(0.5765158901134363d);
//        double double12 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl9);
//        int[] intArray15 = randomDataImpl0.nextPermutation(35, (int) (byte) 10);
//        int int19 = randomDataImpl0.nextHypergeometric(100, (int) (short) 100, 87);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.036962539188515d + "'", double3 == 2.036962539188515d);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "7eb40aa05deca8a780f2f0d90fbb982360665061fde3ff8be527" + "'", str5.equals("7eb40aa05deca8a780f2f0d90fbb982360665061fde3ff8be527"));
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 97.19298818676732d + "'", double11 == 97.19298818676732d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 96.27077244196634d + "'", double12 == 96.27077244196634d);
//        org.junit.Assert.assertNotNull(intArray15);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 87 + "'", int19 == 87);
//    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 97L, (double) (short) 1, (double) (byte) 0);
        double double5 = normalDistributionImpl3.cumulativeProbability(2.200736691117263E34d);
        try {
            double double8 = normalDistributionImpl3.cumulativeProbability((double) 52, (-1.5574077246549023d));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.10632736832433937d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.10672988369442259d + "'", double1 == 0.10672988369442259d);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.apache.commons.math.MathException mathException3 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable9 = numberIsTooSmallException8.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException13 = new org.apache.commons.math.exception.OutOfRangeException(localizable9, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray15 = mathException14.getArguments();
        java.lang.Throwable[] throwableArray16 = mathException14.getSuppressed();
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException3, localizable9, (java.lang.Object[]) throwableArray16);
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray20 = mathException19.getArguments();
        java.lang.Throwable[] throwableArray21 = mathException19.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException3, "", (java.lang.Object[]) throwableArray21);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException23 = new org.apache.commons.math.MaxIterationsExceededException(0, "hi!", (java.lang.Object[]) throwableArray21);
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException("2cc4bca353b0d36733d55b2ff91bbb544b5", (java.lang.Object[]) throwableArray21);
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(throwableArray21);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) (short) 1);
        try {
            double double5 = normalDistributionImpl2.cumulativeProbability(2.8201432307142915d, 0.6843968673252286d);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 52, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

//    @Test
//    public void test390() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test390");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextCauchy(0.0d, (double) 32);
//        double double6 = randomDataImpl0.nextExponential(359.1342053695754d);
//        randomDataImpl0.reSeedSecure((long) (short) 1);
//        java.lang.String str10 = randomDataImpl0.nextSecureHexString((int) ' ');
//        int int13 = randomDataImpl0.nextZipf((int) (short) 1, 4.571545345114974d);
//        double double15 = randomDataImpl0.nextT((double) ' ');
//        try {
//            double double18 = randomDataImpl0.nextBeta(0.0d, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.5 p = 0.752");
//        } catch (org.apache.commons.math.exception.MathUserException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 8.808175954535091d + "'", double4 == 8.808175954535091d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 687.904809513905d + "'", double6 == 687.904809513905d);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "e3c82c10976a45510821eecef05edf4e" + "'", str10.equals("e3c82c10976a45510821eecef05edf4e"));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-1.7752965824467046d) + "'", double15 == (-1.7752965824467046d));
//    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getGeneralPattern();
        java.lang.Number number6 = null;
        java.lang.Number number7 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException9 = new org.apache.commons.math.exception.OutOfRangeException(localizable5, number6, number7, (java.lang.Number) 10);
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException9);
        org.apache.commons.math.exception.util.Localizable localizable11 = mathException10.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = mathException10.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNull(localizable11);
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.5d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 28.64788975654116d + "'", double1 == 28.64788975654116d);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) (short) 1);
        double double4 = normalDistributionImpl2.cumulativeProbability((-0.8427007929497151d));
        double double6 = normalDistributionImpl2.cumulativeProbability(0.0d);
        double double8 = normalDistributionImpl2.inverseCumulativeProbability(0.8813735870195429d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.19969790180335623d + "'", double4 == 0.19969790180335623d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.5d + "'", double6 == 0.5d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.1818812419463103d + "'", double8 == 1.1818812419463103d);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable1, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException5.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray12 = mathException11.getArguments();
        java.lang.Throwable[] throwableArray13 = mathException11.getSuppressed();
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException0, localizable6, (java.lang.Object[]) throwableArray13);
        java.lang.Object[] objArray15 = null;
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException(localizable6, objArray15);
        java.lang.Number number18 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException20 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable6, (java.lang.Number) 2.718281828459045d, number18, false);
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable22 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException26 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable22, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable27 = numberIsTooSmallException26.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException31 = new org.apache.commons.math.exception.OutOfRangeException(localizable27, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException32 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray33 = mathException32.getArguments();
        java.lang.Throwable[] throwableArray34 = mathException32.getSuppressed();
        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException21, localizable27, (java.lang.Object[]) throwableArray34);
        org.apache.commons.math.MathException mathException36 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray37 = mathException36.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException38 = new org.apache.commons.math.ConvergenceException(localizable27, objArray37);
        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException(localizable6, objArray37);
        java.lang.Class<?> wildcardClass40 = objArray37.getClass();
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertTrue("'" + localizable27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable27.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertNotNull(throwableArray34);
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertNotNull(wildcardClass40);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.5d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.3010299956639812d) + "'", double1 == (-0.3010299956639812d));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        long long1 = org.apache.commons.math.util.FastMath.abs(97L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 97L + "'", long1 == 97L);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        try {
            randomDataImpl1.setSecureAlgorithm("7eb40aa05deca8a780f2f0d90fbb982360665061fde3ff8be527", "");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: missing provider");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1.0d, (java.lang.Number) (-1L), true);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooLargeException3.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable10 = numberIsTooSmallException9.getGeneralPattern();
        java.lang.Throwable[] throwableArray11 = numberIsTooSmallException9.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException(localizable4, (java.lang.Object[]) throwableArray11);
        java.lang.Class<?> wildcardClass13 = localizable4.getClass();
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertTrue("'" + localizable10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable10.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 87, (float) '#');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 35.0f + "'", float2 == 35.0f);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.5772156649015329d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.781072417990198d + "'", double1 == 1.781072417990198d);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 97, 0.872447858588575d);
        double double3 = normalDistributionImpl2.getStandardDeviation();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.872447858588575d + "'", double3 == 0.872447858588575d);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        double double1 = org.apache.commons.math.special.Erf.erf(1.5515679276951895d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9717824436664049d + "'", double1 == 0.9717824436664049d);
    }

//    @Test
//    public void test403() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test403");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (byte) 0, 3.141592653589793d);
//        java.lang.String str5 = randomDataImpl0.nextHexString(52);
//        try {
//            long long8 = randomDataImpl0.nextLong((long) (byte) 100, 0L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100 is larger than, or equal to, the maximum (0): lower bound (100) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.522988790190467d + "'", double3 == 2.522988790190467d);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "23006dd2b3e12129588a9bf2f3b576499cf3ec62c982e9c03507" + "'", str5.equals("23006dd2b3e12129588a9bf2f3b576499cf3ec62c982e9c03507"));
//    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable1, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException5.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray12 = mathException11.getArguments();
        java.lang.Throwable[] throwableArray13 = mathException11.getSuppressed();
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException0, localizable6, (java.lang.Object[]) throwableArray13);
        java.lang.Object[] objArray15 = null;
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException(localizable6, objArray15);
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException21 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable17, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable22 = numberIsTooSmallException21.getGeneralPattern();
        java.lang.Number number23 = null;
        java.lang.Number number24 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException26 = new org.apache.commons.math.exception.OutOfRangeException(localizable22, number23, number24, (java.lang.Number) 10);
        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException26);
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException26);
        java.lang.Number number29 = outOfRangeException26.getLo();
        java.lang.Number number30 = outOfRangeException26.getLo();
        java.lang.Number number31 = outOfRangeException26.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable32 = outOfRangeException26.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException37 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable33, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable38 = numberIsTooSmallException37.getGeneralPattern();
        java.lang.Number number39 = null;
        java.lang.Number number40 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException42 = new org.apache.commons.math.exception.OutOfRangeException(localizable38, number39, number40, (java.lang.Number) 10);
        org.apache.commons.math.MathException mathException43 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException42);
        java.lang.Number number44 = outOfRangeException42.getHi();
        java.lang.Throwable[] throwableArray45 = outOfRangeException42.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException(localizable32, (java.lang.Object[]) throwableArray45);
        org.apache.commons.math.MathException mathException49 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable50 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException54 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable50, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable55 = numberIsTooSmallException54.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException59 = new org.apache.commons.math.exception.OutOfRangeException(localizable55, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException60 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray61 = mathException60.getArguments();
        java.lang.Throwable[] throwableArray62 = mathException60.getSuppressed();
        org.apache.commons.math.MathException mathException63 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException49, localizable55, (java.lang.Object[]) throwableArray62);
        org.apache.commons.math.MathException mathException65 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray66 = mathException65.getArguments();
        java.lang.Throwable[] throwableArray67 = mathException65.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException68 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException49, "", (java.lang.Object[]) throwableArray67);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException69 = new org.apache.commons.math.MaxIterationsExceededException(0, "hi!", (java.lang.Object[]) throwableArray67);
        org.apache.commons.math.MathException mathException70 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException16, localizable32, (java.lang.Object[]) throwableArray67);
        org.apache.commons.math.exception.util.Localizable localizable71 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException75 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable71, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable76 = numberIsTooSmallException75.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException80 = new org.apache.commons.math.exception.OutOfRangeException(localizable76, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.exception.util.Localizable localizable81 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException85 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable81, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable86 = numberIsTooSmallException85.getGeneralPattern();
        java.lang.Number number87 = null;
        java.lang.Number number88 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException90 = new org.apache.commons.math.exception.OutOfRangeException(localizable86, number87, number88, (java.lang.Number) 10);
        org.apache.commons.math.MathException mathException91 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException90);
        org.apache.commons.math.ConvergenceException convergenceException92 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException90);
        java.lang.Number number93 = outOfRangeException90.getLo();
        java.lang.Number number94 = outOfRangeException90.getLo();
        java.lang.Object[] objArray95 = outOfRangeException90.getArguments();
        org.apache.commons.math.MathException mathException96 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException16, localizable76, objArray95);
        org.apache.commons.math.exception.util.Localizable localizable97 = mathException16.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertTrue("'" + localizable22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable22.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNull(number29);
        org.junit.Assert.assertNull(number30);
        org.junit.Assert.assertNull(number31);
        org.junit.Assert.assertTrue("'" + localizable32 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable32.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable38 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable38.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + number44 + "' != '" + 10 + "'", number44.equals(10));
        org.junit.Assert.assertNotNull(throwableArray45);
        org.junit.Assert.assertTrue("'" + localizable55 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable55.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray61);
        org.junit.Assert.assertNotNull(throwableArray62);
        org.junit.Assert.assertNotNull(objArray66);
        org.junit.Assert.assertNotNull(throwableArray67);
        org.junit.Assert.assertTrue("'" + localizable76 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable76.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizable86 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable86.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNull(number93);
        org.junit.Assert.assertNull(number94);
        org.junit.Assert.assertNotNull(objArray95);
        org.junit.Assert.assertTrue("'" + localizable97 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable97.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 87);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 87.0f + "'", float1 == 87.0f);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        double double1 = org.apache.commons.math.util.FastMath.acosh(4.196696532391377d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.1129380639844704d + "'", double1 == 2.1129380639844704d);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) Double.POSITIVE_INFINITY, (java.lang.Number) (short) -1, false);
        boolean boolean4 = numberIsTooLargeException3.getBoundIsAllowed();
        java.lang.Number number5 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (short) -1 + "'", number5.equals((short) -1));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        double double1 = org.apache.commons.math.util.FastMath.log10((-43.833853519263435d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable1, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException5.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        java.lang.Object[] objArray11 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException(localizable6, objArray11);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException16 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable6, (java.lang.Number) 0.288405172032595d, (java.lang.Number) (byte) -1, false);
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException24 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable20, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable25 = numberIsTooSmallException24.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException29 = new org.apache.commons.math.exception.OutOfRangeException(localizable25, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException30 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray31 = mathException30.getArguments();
        java.lang.Throwable[] throwableArray32 = mathException30.getSuppressed();
        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException19, localizable25, (java.lang.Object[]) throwableArray32);
        java.lang.Object[] objArray34 = null;
        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException(localizable25, objArray34);
        org.apache.commons.math.exception.util.Localizable localizable36 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException40 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable36, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable41 = numberIsTooSmallException40.getGeneralPattern();
        java.lang.Number number42 = null;
        java.lang.Number number43 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException45 = new org.apache.commons.math.exception.OutOfRangeException(localizable41, number42, number43, (java.lang.Number) 10);
        org.apache.commons.math.MathException mathException46 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException45);
        org.apache.commons.math.ConvergenceException convergenceException47 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException45);
        java.lang.Number number48 = outOfRangeException45.getLo();
        java.lang.Number number49 = outOfRangeException45.getLo();
        java.lang.Number number50 = outOfRangeException45.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable51 = outOfRangeException45.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable52 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException56 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable52, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable57 = numberIsTooSmallException56.getGeneralPattern();
        java.lang.Number number58 = null;
        java.lang.Number number59 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException61 = new org.apache.commons.math.exception.OutOfRangeException(localizable57, number58, number59, (java.lang.Number) 10);
        org.apache.commons.math.MathException mathException62 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException61);
        java.lang.Number number63 = outOfRangeException61.getHi();
        java.lang.Throwable[] throwableArray64 = outOfRangeException61.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException65 = new org.apache.commons.math.ConvergenceException(localizable51, (java.lang.Object[]) throwableArray64);
        org.apache.commons.math.MathException mathException68 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable69 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException73 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable69, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable74 = numberIsTooSmallException73.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException78 = new org.apache.commons.math.exception.OutOfRangeException(localizable74, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException79 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray80 = mathException79.getArguments();
        java.lang.Throwable[] throwableArray81 = mathException79.getSuppressed();
        org.apache.commons.math.MathException mathException82 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException68, localizable74, (java.lang.Object[]) throwableArray81);
        org.apache.commons.math.MathException mathException84 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray85 = mathException84.getArguments();
        java.lang.Throwable[] throwableArray86 = mathException84.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException87 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException68, "", (java.lang.Object[]) throwableArray86);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException88 = new org.apache.commons.math.MaxIterationsExceededException(0, "hi!", (java.lang.Object[]) throwableArray86);
        org.apache.commons.math.MathException mathException89 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException35, localizable51, (java.lang.Object[]) throwableArray86);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException90 = new org.apache.commons.math.MaxIterationsExceededException(35, "346ff53c6dcf49c36e2607360894de97", (java.lang.Object[]) throwableArray86);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException91 = new org.apache.commons.math.MaxIterationsExceededException(10, localizable6, (java.lang.Object[]) throwableArray86);
        org.apache.commons.math.ConvergenceException convergenceException92 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException91);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertTrue("'" + localizable25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable25.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(throwableArray32);
        org.junit.Assert.assertTrue("'" + localizable41 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable41.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNull(number48);
        org.junit.Assert.assertNull(number49);
        org.junit.Assert.assertNull(number50);
        org.junit.Assert.assertTrue("'" + localizable51 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable51.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable57 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable57.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + number63 + "' != '" + 10 + "'", number63.equals(10));
        org.junit.Assert.assertNotNull(throwableArray64);
        org.junit.Assert.assertTrue("'" + localizable74 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable74.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray80);
        org.junit.Assert.assertNotNull(throwableArray81);
        org.junit.Assert.assertNotNull(objArray85);
        org.junit.Assert.assertNotNull(throwableArray86);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        double double1 = org.apache.commons.math.special.Gamma.digamma(1.2268016374392727d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.25559277486134857d) + "'", double1 == (-0.25559277486134857d));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        double double1 = org.apache.commons.math.special.Gamma.digamma(0.9999999999999984d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5772156677920701d) + "'", double1 == (-0.5772156677920701d));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-0.05286523481589489d));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray1 = mathException0.getArguments();
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException0, "org.apache.commons.math.exception.NumberIsTooLargeException: 0 is larger than, or equal to, the maximum (0)", objArray3);
        java.lang.String str5 = mathException0.toString();
        org.junit.Assert.assertNotNull(objArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.MathException: " + "'", str5.equals("org.apache.commons.math.MathException: "));
    }

//    @Test
//    public void test415() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test415");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextCauchy(0.0d, (double) 32);
//        double double6 = randomDataImpl0.nextChiSquare((double) '4');
//        double double9 = randomDataImpl0.nextCauchy(0.0d, 4.571545345114974d);
//        try {
//            double double12 = randomDataImpl0.nextGaussian((double) (byte) 0, (-1.1530884312840275d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1.153 is smaller than, or equal to, the minimum (0): standard deviation (-1.153)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 149.94919789390116d + "'", double4 == 149.94919789390116d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 46.61279758591079d + "'", double6 == 46.61279758591079d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 25.794822786123355d + "'", double9 == 25.794822786123355d);
//    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getGeneralPattern();
        java.lang.Number number6 = null;
        java.lang.Number number7 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException9 = new org.apache.commons.math.exception.OutOfRangeException(localizable5, number6, number7, (java.lang.Number) 10);
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException9);
        org.apache.commons.math.exception.util.Localizable localizable11 = mathException10.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException15 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable11, (java.lang.Number) 1.5515679276951895d, (java.lang.Number) 1.5515679276951895d, false);
        boolean boolean16 = numberIsTooLargeException15.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.5403023058681398d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.009430054193516519d + "'", double1 == 0.009430054193516519d);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (byte) 100, (long) (short) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        double double1 = org.apache.commons.math.util.FastMath.signum((-27.840419813850996d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.0d, 2.2947995645263366d, 2.8553217231426142d, 1);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        double double1 = org.apache.commons.math.util.FastMath.log(5.072331860704032d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.623800644944012d + "'", double1 == 1.623800644944012d);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 0);
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        double double1 = org.apache.commons.math.util.FastMath.ulp((-0.7008313510877778d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        double double1 = org.apache.commons.math.util.FastMath.rint(205.42997533372358d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 205.0d + "'", double1 == 205.0d);
    }

//    @Test
//    public void test425() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test425");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextCauchy(0.0d, (double) 32);
//        double double6 = randomDataImpl0.nextExponential(359.1342053695754d);
//        java.lang.String str8 = randomDataImpl0.nextSecureHexString(81);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 258.23329197307703d + "'", double4 == 258.23329197307703d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 27.68855530164479d + "'", double6 == 27.68855530164479d);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "872d2e96414595ec08aaa77354a5c4a60b3abcb50b8f22ac09ac88ed5d3092da5dfd8112080bdf264" + "'", str8.equals("872d2e96414595ec08aaa77354a5c4a60b3abcb50b8f22ac09ac88ed5d3092da5dfd8112080bdf264"));
//    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.3044465563407555d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3044465563407555d + "'", double1 == 0.3044465563407555d);
    }

//    @Test
//    public void test427() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test427");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (byte) 0, 3.141592653589793d);
//        double double6 = randomDataImpl0.nextCauchy(200.2390918710703d, 258.23329197307703d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.5671842226885393d + "'", double3 == 2.5671842226885393d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 47.04026509063007d + "'", double6 == 47.04026509063007d);
//    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(1.781072417990198d, 0.7336545584598283d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.22190049895494263d + "'", double2 == 0.22190049895494263d);
    }

//    @Test
//    public void test429() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test429");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextCauchy(0.0d, (double) 32);
//        double double6 = randomDataImpl0.nextChiSquare((double) '4');
//        double double9 = randomDataImpl0.nextWeibull(0.8813735870195429d, (double) 32);
//        java.lang.String str11 = randomDataImpl0.nextSecureHexString(35);
//        double double13 = randomDataImpl0.nextT(5.916079783099616d);
//        try {
//            long long16 = randomDataImpl0.nextLong((long) (-1), (long) (short) -1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: -1 is larger than, or equal to, the maximum (-1): lower bound (-1) must be strictly less than upper bound (-1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 48.2144452289981d + "'", double4 == 48.2144452289981d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 45.68411758412678d + "'", double6 == 45.68411758412678d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 22.62677094311563d + "'", double9 == 22.62677094311563d);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ba68f25d80b542621480b48330ae808b6dd" + "'", str11.equals("ba68f25d80b542621480b48330ae808b6dd"));
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.6569874949096616d + "'", double13 == 0.6569874949096616d);
//    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        double double1 = org.apache.commons.math.util.FastMath.abs(1.2307280868187975d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2307280868187975d + "'", double1 == 1.2307280868187975d);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (short) 0, (java.lang.Number) 2.0d, true);
        boolean boolean4 = numberIsTooLargeException3.getBoundIsAllowed();
        boolean boolean5 = numberIsTooLargeException3.getBoundIsAllowed();
        boolean boolean6 = numberIsTooLargeException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        double double1 = org.apache.commons.math.util.FastMath.log1p(Double.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 97L, (double) (short) 1, (double) (byte) 0);
        normalDistributionImpl3.reseedRandomGenerator((-1L));
        try {
            double double8 = normalDistributionImpl3.cumulativeProbability(0.48670120172084486d, 0.0d);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        double double2 = org.apache.commons.math.util.FastMath.atan2(35.0d, 1.1818812419463103d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5370411175442078d + "'", double2 == 1.5370411175442078d);
    }

//    @Test
//    public void test435() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test435");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextCauchy(0.0d, (double) 32);
//        double double6 = randomDataImpl0.nextExponential(359.1342053695754d);
//        randomDataImpl0.reSeedSecure((long) (short) 1);
//        java.lang.String str10 = randomDataImpl0.nextSecureHexString((int) ' ');
//        randomDataImpl0.reSeedSecure();
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 54.0280840833561d + "'", double4 == 54.0280840833561d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 308.3126862709122d + "'", double6 == 308.3126862709122d);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1cda2adc76d490d86446df2d14d5e4ea" + "'", str10.equals("1cda2adc76d490d86446df2d14d5e4ea"));
//    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException9 = new org.apache.commons.math.exception.OutOfRangeException(localizable5, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        java.lang.Object[] objArray10 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException(localizable5, objArray10);
        java.lang.Object[] objArray12 = null;
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException(localizable5, objArray12);
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException20 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable16, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable21 = numberIsTooSmallException20.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException25 = new org.apache.commons.math.exception.OutOfRangeException(localizable21, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray27 = mathException26.getArguments();
        java.lang.Throwable[] throwableArray28 = mathException26.getSuppressed();
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException15, localizable21, (java.lang.Object[]) throwableArray28);
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException("hi!", (java.lang.Object[]) throwableArray28);
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException(localizable5, (java.lang.Object[]) throwableArray28);
        java.lang.String str32 = convergenceException31.getPattern();
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertTrue("'" + localizable21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable21.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(throwableArray28);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "{0} is smaller than the minimum ({1})" + "'", str32.equals("{0} is smaller than the minimum ({1})"));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.apache.commons.math.MathException mathException1 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException6 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable2, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable7 = numberIsTooSmallException6.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException11 = new org.apache.commons.math.exception.OutOfRangeException(localizable7, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray13 = mathException12.getArguments();
        java.lang.Throwable[] throwableArray14 = mathException12.getSuppressed();
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException1, localizable7, (java.lang.Object[]) throwableArray14);
        java.lang.Object[] objArray16 = null;
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException(localizable7, objArray16);
        java.lang.Number number19 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException21 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable7, (java.lang.Number) 2.718281828459045d, number19, false);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException25 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (short) 0, (java.lang.Number) (short) 0, true);
        java.lang.Number number26 = numberIsTooSmallException25.getArgument();
        java.lang.Object[] objArray27 = numberIsTooSmallException25.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, objArray27);
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException("", objArray27);
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertTrue("'" + number26 + "' != '" + (short) 0 + "'", number26.equals((short) 0));
        org.junit.Assert.assertNotNull(objArray27);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        double double2 = org.apache.commons.math.util.FastMath.min(5.298342365610589d, 68.85702336552696d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.298342365610589d + "'", double2 == 5.298342365610589d);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        double double1 = org.apache.commons.math.util.FastMath.sinh((-2.1563064218629213d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-4.261708669147672d) + "'", double1 == (-4.261708669147672d));
    }

//    @Test
//    public void test440() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test440");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (byte) 0, 3.141592653589793d);
//        java.lang.String str5 = randomDataImpl0.nextHexString(52);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl9 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 97L, (double) (short) 1, (double) (byte) 0);
//        double double11 = normalDistributionImpl9.inverseCumulativeProbability(0.5765158901134363d);
//        double double12 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl9);
//        try {
//            double double15 = randomDataImpl0.nextCauchy(4.434659205310982d, (-1.5574077246549023d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1.557 is smaller than, or equal to, the minimum (0): scale (-1.557)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.3693402644254595d + "'", double3 == 2.3693402644254595d);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "9b8b6f043b18572d2adf688e0cf1dae5065d77190a6651650300" + "'", str5.equals("9b8b6f043b18572d2adf688e0cf1dae5065d77190a6651650300"));
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 97.19298818676732d + "'", double11 == 97.19298818676732d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 97.14395584178399d + "'", double12 == 97.14395584178399d);
//    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        double double1 = org.apache.commons.math.util.FastMath.asin(1.0962373903922824d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        double double2 = org.apache.commons.math.util.FastMath.max(10.0d, (double) (short) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) (short) 1);
        double double4 = normalDistributionImpl2.cumulativeProbability((-14.423394137532366d));
        try {
            double double7 = normalDistributionImpl2.cumulativeProbability(0.5845089524363901d, (-1.5707963267948966d));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 97L, (double) (short) 1, (double) (byte) 0);
        double double4 = normalDistributionImpl3.getStandardDeviation();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 100.0f);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        int int2 = org.apache.commons.math.util.FastMath.min((int) '#', (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        double double1 = org.apache.commons.math.util.FastMath.tan(26.251898112714137d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0615213041709217d + "'", double1 == 2.0615213041709217d);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable1, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException5.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray12 = mathException11.getArguments();
        java.lang.Throwable[] throwableArray13 = mathException11.getSuppressed();
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException0, localizable6, (java.lang.Object[]) throwableArray13);
        java.lang.Object[] objArray15 = null;
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException(localizable6, objArray15);
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException21 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable17, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable22 = numberIsTooSmallException21.getGeneralPattern();
        java.lang.Number number23 = null;
        java.lang.Number number24 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException26 = new org.apache.commons.math.exception.OutOfRangeException(localizable22, number23, number24, (java.lang.Number) 10);
        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException26);
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException26);
        java.lang.Number number29 = outOfRangeException26.getLo();
        java.lang.Number number30 = outOfRangeException26.getLo();
        java.lang.Number number31 = outOfRangeException26.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable32 = outOfRangeException26.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException37 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable33, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable38 = numberIsTooSmallException37.getGeneralPattern();
        java.lang.Number number39 = null;
        java.lang.Number number40 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException42 = new org.apache.commons.math.exception.OutOfRangeException(localizable38, number39, number40, (java.lang.Number) 10);
        org.apache.commons.math.MathException mathException43 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException42);
        java.lang.Number number44 = outOfRangeException42.getHi();
        java.lang.Throwable[] throwableArray45 = outOfRangeException42.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException(localizable32, (java.lang.Object[]) throwableArray45);
        org.apache.commons.math.MathException mathException49 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable50 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException54 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable50, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable55 = numberIsTooSmallException54.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException59 = new org.apache.commons.math.exception.OutOfRangeException(localizable55, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException60 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray61 = mathException60.getArguments();
        java.lang.Throwable[] throwableArray62 = mathException60.getSuppressed();
        org.apache.commons.math.MathException mathException63 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException49, localizable55, (java.lang.Object[]) throwableArray62);
        org.apache.commons.math.MathException mathException65 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray66 = mathException65.getArguments();
        java.lang.Throwable[] throwableArray67 = mathException65.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException68 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException49, "", (java.lang.Object[]) throwableArray67);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException69 = new org.apache.commons.math.MaxIterationsExceededException(0, "hi!", (java.lang.Object[]) throwableArray67);
        org.apache.commons.math.MathException mathException70 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException16, localizable32, (java.lang.Object[]) throwableArray67);
        org.apache.commons.math.exception.util.Localizable localizable71 = mathException70.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable72 = mathException70.getGeneralPattern();
        java.lang.Number number75 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException76 = new org.apache.commons.math.exception.OutOfRangeException(localizable72, (java.lang.Number) 0.006992129485781045d, (java.lang.Number) 2.718281828459045d, number75);
        java.lang.String str77 = outOfRangeException76.toString();
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertTrue("'" + localizable22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable22.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNull(number29);
        org.junit.Assert.assertNull(number30);
        org.junit.Assert.assertNull(number31);
        org.junit.Assert.assertTrue("'" + localizable32 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable32.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable38 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable38.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + number44 + "' != '" + 10 + "'", number44.equals(10));
        org.junit.Assert.assertNotNull(throwableArray45);
        org.junit.Assert.assertTrue("'" + localizable55 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable55.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray61);
        org.junit.Assert.assertNotNull(throwableArray62);
        org.junit.Assert.assertNotNull(objArray66);
        org.junit.Assert.assertNotNull(throwableArray67);
        org.junit.Assert.assertTrue("'" + localizable71 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable71.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable72 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable72.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "org.apache.commons.math.exception.OutOfRangeException: 0.007 out of [2.718, null] range: 0.007 out of [2.718, null] range" + "'", str77.equals("org.apache.commons.math.exception.OutOfRangeException: 0.007 out of [2.718, null] range: 0.007 out of [2.718, null] range"));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getGeneralPattern();
        java.lang.Number number6 = null;
        java.lang.Number number7 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException9 = new org.apache.commons.math.exception.OutOfRangeException(localizable5, number6, number7, (java.lang.Number) 10);
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException9);
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException9);
        java.lang.Number number12 = outOfRangeException9.getLo();
        java.lang.Number number13 = outOfRangeException9.getLo();
        java.lang.Number number14 = outOfRangeException9.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable15 = outOfRangeException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException20 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable16, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable21 = numberIsTooSmallException20.getGeneralPattern();
        java.lang.Number number22 = null;
        java.lang.Number number23 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException25 = new org.apache.commons.math.exception.OutOfRangeException(localizable21, number22, number23, (java.lang.Number) 10);
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException25);
        java.lang.Number number27 = outOfRangeException25.getHi();
        java.lang.Throwable[] throwableArray28 = outOfRangeException25.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException(localizable15, (java.lang.Object[]) throwableArray28);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException33 = new org.apache.commons.math.exception.OutOfRangeException(localizable15, (java.lang.Number) (-0.8813735870195429d), (java.lang.Number) (byte) 0, (java.lang.Number) 1.3765887979465332d);
        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable38 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException42 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable38, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable43 = numberIsTooSmallException42.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException47 = new org.apache.commons.math.exception.OutOfRangeException(localizable43, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException48 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray49 = mathException48.getArguments();
        java.lang.Throwable[] throwableArray50 = mathException48.getSuppressed();
        org.apache.commons.math.MathException mathException51 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException37, localizable43, (java.lang.Object[]) throwableArray50);
        org.apache.commons.math.MathException mathException53 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray54 = mathException53.getArguments();
        java.lang.Throwable[] throwableArray55 = mathException53.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException56 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException37, "", (java.lang.Object[]) throwableArray55);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException57 = new org.apache.commons.math.MaxIterationsExceededException(0, "hi!", (java.lang.Object[]) throwableArray55);
        org.apache.commons.math.MathException mathException58 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException33, "", (java.lang.Object[]) throwableArray55);
        org.apache.commons.math.exception.util.Localizable localizable59 = mathException58.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertNull(number13);
        org.junit.Assert.assertNull(number14);
        org.junit.Assert.assertTrue("'" + localizable15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable15.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable21.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + number27 + "' != '" + 10 + "'", number27.equals(10));
        org.junit.Assert.assertNotNull(throwableArray28);
        org.junit.Assert.assertTrue("'" + localizable43 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable43.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertNotNull(throwableArray50);
        org.junit.Assert.assertNotNull(objArray54);
        org.junit.Assert.assertNotNull(throwableArray55);
        org.junit.Assert.assertNull(localizable59);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1.0d, (java.lang.Number) (-1L), true);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooLargeException3.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable10 = numberIsTooSmallException9.getGeneralPattern();
        java.lang.Throwable[] throwableArray11 = numberIsTooSmallException9.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException(localizable4, (java.lang.Object[]) throwableArray11);
        java.lang.Throwable throwable13 = null;
        try {
            convergenceException12.addSuppressed(throwable13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertTrue("'" + localizable10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable10.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(throwableArray11);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        double double1 = org.apache.commons.math.util.FastMath.asinh(1.1367103224267854d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9748169799074695d + "'", double1 == 0.9748169799074695d);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        float float2 = org.apache.commons.math.util.FastMath.max(0.0f, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException9 = new org.apache.commons.math.exception.OutOfRangeException(localizable5, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        java.lang.Object[] objArray10 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException(localizable5, objArray10);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException15 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) 0.288405172032595d, (java.lang.Number) (byte) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException20 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable16, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable21 = numberIsTooSmallException20.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException25 = new org.apache.commons.math.exception.OutOfRangeException(localizable21, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        java.lang.Object[] objArray26 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException(localizable21, objArray26);
        java.lang.Object[] objArray28 = null;
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException(localizable21, objArray28);
        org.apache.commons.math.MathException mathException30 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray31 = mathException30.getArguments();
        java.lang.Throwable[] throwableArray32 = mathException30.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException33 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException15, localizable21, (java.lang.Object[]) throwableArray32);
        java.lang.Number number34 = numberIsTooSmallException15.getMin();
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertTrue("'" + localizable21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable21.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(throwableArray32);
        org.junit.Assert.assertTrue("'" + number34 + "' != '" + (byte) -1 + "'", number34.equals((byte) -1));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((-44.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.767944870877505d) + "'", double1 == (-0.767944870877505d));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double2 = normalDistributionImpl0.density((double) (short) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.24197072451914337d + "'", double2 == 0.24197072451914337d);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((-1));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.501590259893643d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.12845606836266d + "'", double1 == 1.12845606836266d);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable1, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException5.getGeneralPattern();
        java.lang.Number number7 = null;
        java.lang.Number number8 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, number7, number8, (java.lang.Number) 10);
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException10);
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException10);
        java.lang.Number number13 = outOfRangeException10.getLo();
        java.lang.Number number14 = outOfRangeException10.getLo();
        java.lang.Number number15 = outOfRangeException10.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable16 = outOfRangeException10.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException21 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable17, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable22 = numberIsTooSmallException21.getGeneralPattern();
        java.lang.Number number23 = null;
        java.lang.Number number24 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException26 = new org.apache.commons.math.exception.OutOfRangeException(localizable22, number23, number24, (java.lang.Number) 10);
        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException26);
        java.lang.Number number28 = outOfRangeException26.getHi();
        java.lang.Throwable[] throwableArray29 = outOfRangeException26.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException(localizable16, (java.lang.Object[]) throwableArray29);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException32 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable16, (java.lang.Number) 100);
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable36 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException40 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable36, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable41 = numberIsTooSmallException40.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException45 = new org.apache.commons.math.exception.OutOfRangeException(localizable41, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException46 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray47 = mathException46.getArguments();
        java.lang.Throwable[] throwableArray48 = mathException46.getSuppressed();
        org.apache.commons.math.MathException mathException49 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException35, localizable41, (java.lang.Object[]) throwableArray48);
        org.apache.commons.math.ConvergenceException convergenceException50 = new org.apache.commons.math.ConvergenceException("hi!", (java.lang.Object[]) throwableArray48);
        org.apache.commons.math.ConvergenceException convergenceException51 = new org.apache.commons.math.ConvergenceException(localizable33, (java.lang.Object[]) throwableArray48);
        org.apache.commons.math.MathException mathException52 = new org.apache.commons.math.MathException(localizable16, (java.lang.Object[]) throwableArray48);
        org.apache.commons.math.exception.util.Localizable localizable53 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException57 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable53, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable58 = numberIsTooSmallException57.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException62 = new org.apache.commons.math.exception.OutOfRangeException(localizable58, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.exception.util.Localizable localizable63 = null;
        org.apache.commons.math.MathException mathException65 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable66 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException70 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable66, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable71 = numberIsTooSmallException70.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException75 = new org.apache.commons.math.exception.OutOfRangeException(localizable71, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException76 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray77 = mathException76.getArguments();
        java.lang.Throwable[] throwableArray78 = mathException76.getSuppressed();
        org.apache.commons.math.MathException mathException79 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException65, localizable71, (java.lang.Object[]) throwableArray78);
        org.apache.commons.math.ConvergenceException convergenceException80 = new org.apache.commons.math.ConvergenceException("hi!", (java.lang.Object[]) throwableArray78);
        org.apache.commons.math.ConvergenceException convergenceException81 = new org.apache.commons.math.ConvergenceException(localizable63, (java.lang.Object[]) throwableArray78);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException82 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable16, localizable58, (java.lang.Object[]) throwableArray78);
        org.apache.commons.math.MathException mathException83 = new org.apache.commons.math.MathException("", (java.lang.Object[]) throwableArray78);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNull(number13);
        org.junit.Assert.assertNull(number14);
        org.junit.Assert.assertNull(number15);
        org.junit.Assert.assertTrue("'" + localizable16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable16.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable22.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + number28 + "' != '" + 10 + "'", number28.equals(10));
        org.junit.Assert.assertNotNull(throwableArray29);
        org.junit.Assert.assertTrue("'" + localizable41 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable41.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray47);
        org.junit.Assert.assertNotNull(throwableArray48);
        org.junit.Assert.assertTrue("'" + localizable58 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable58.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizable71 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable71.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray77);
        org.junit.Assert.assertNotNull(throwableArray78);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        double double1 = org.apache.commons.math.util.FastMath.acos(14.15426224147926d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        double double1 = org.apache.commons.math.util.FastMath.atan(205.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5659183167054986d + "'", double1 == 1.5659183167054986d);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.0d, (-14.423394137532366d), 50.099536468767525d, (int) (short) 0);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(12.580307630659599d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.3257538777426525d + "'", double1 == 2.3257538777426525d);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 0);
        boolean boolean2 = notStrictlyPositiveException1.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.5765158901134363d, 3.111443690220943d);
        double[] doubleArray4 = normalDistributionImpl2.sample(90);
        org.junit.Assert.assertNotNull(doubleArray4);
    }

//    @Test
//    public void test465() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test465");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextCauchy(0.0d, (double) 32);
//        double double6 = randomDataImpl0.nextExponential(359.1342053695754d);
//        randomDataImpl0.reSeedSecure((long) (short) 1);
//        double double10 = randomDataImpl0.nextT(57.29577951308232d);
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeedSecure();
//        randomDataImpl0.reSeedSecure();
//        try {
//            int int17 = randomDataImpl0.nextInt((int) (byte) 10, (int) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 10 is larger than, or equal to, the maximum (-1): lower bound (10) must be strictly less than upper bound (-1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 192.92896681215936d + "'", double4 == 192.92896681215936d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 428.368284760596d + "'", double6 == 428.368284760596d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-0.7920378559899225d) + "'", double10 == (-0.7920378559899225d));
//    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 21L, (double) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 20.999999999999996d + "'", double2 == 20.999999999999996d);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.0d, (-1.5308617906612179d), (double) ' ', (int) (byte) 10);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

//    @Test
//    public void test468() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test468");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int int4 = randomDataImpl0.nextHypergeometric(10, 0, 0);
//        randomDataImpl0.reSeed();
//        double double8 = randomDataImpl0.nextF(2.993222846126381d, 0.41189551366724736d);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2181208.0827619378d + "'", double8 == 2181208.0827619378d);
//    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        double double1 = org.apache.commons.math.util.FastMath.acos((-1.5574077246549023d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) (short) 1);
        normalDistributionImpl2.reseedRandomGenerator((long) (byte) -1);
        double double6 = normalDistributionImpl2.density((double) 5L);
        try {
            double double9 = normalDistributionImpl2.cumulativeProbability(205.0d, 2.4114984556207744d);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.4867195147342979E-6d + "'", double6 == 1.4867195147342979E-6d);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(79.76983250626756d, 34.93114344459216d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 79.76983250626755d + "'", double2 == 79.76983250626755d);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(2.1129380639844704d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.602244797463029d + "'", double1 == 0.602244797463029d);
    }

//    @Test
//    public void test473() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test473");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextCauchy(0.0d, (double) 32);
//        try {
//            double double7 = randomDataImpl0.nextBeta(0.0d, 99.99999999999999d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.5 p = 0.793");
//        } catch (org.apache.commons.math.exception.MathUserException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-49.9069261881974d) + "'", double4 == (-49.9069261881974d));
//    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException("b61c086a27938ef74afb0dabdcf8e66c", objArray1);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable1, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException5.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray12 = mathException11.getArguments();
        java.lang.Throwable[] throwableArray13 = mathException11.getSuppressed();
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException0, localizable6, (java.lang.Object[]) throwableArray13);
        java.lang.Object[] objArray15 = null;
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException(localizable6, objArray15);
        java.lang.Number number18 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException20 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable6, (java.lang.Number) 2.718281828459045d, number18, false);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException24 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable6, (java.lang.Number) 1, (java.lang.Number) 38.40781474984203d, false);
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException29 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable25, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable30 = numberIsTooSmallException29.getGeneralPattern();
        java.lang.Number number31 = null;
        java.lang.Number number32 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException34 = new org.apache.commons.math.exception.OutOfRangeException(localizable30, number31, number32, (java.lang.Number) 10);
        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException34);
        java.lang.Number number36 = outOfRangeException34.getHi();
        java.lang.Throwable[] throwableArray37 = outOfRangeException34.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException38 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, (java.lang.Object[]) throwableArray37);
        org.apache.commons.math.MathException mathException40 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable41 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException45 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable41, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable46 = numberIsTooSmallException45.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException50 = new org.apache.commons.math.exception.OutOfRangeException(localizable46, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException51 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray52 = mathException51.getArguments();
        java.lang.Throwable[] throwableArray53 = mathException51.getSuppressed();
        org.apache.commons.math.MathException mathException54 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException40, localizable46, (java.lang.Object[]) throwableArray53);
        org.apache.commons.math.MathException mathException55 = new org.apache.commons.math.MathException("2cc4bca353b0d36733d55b2ff91bbb544b5", (java.lang.Object[]) throwableArray53);
        mathIllegalArgumentException38.addSuppressed((java.lang.Throwable) mathException55);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertTrue("'" + localizable30 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable30.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + number36 + "' != '" + 10 + "'", number36.equals(10));
        org.junit.Assert.assertNotNull(throwableArray37);
        org.junit.Assert.assertTrue("'" + localizable46 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable46.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray52);
        org.junit.Assert.assertNotNull(throwableArray53);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        double double1 = org.apache.commons.math.special.Gamma.digamma(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(2.6859131956935225d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 153.89149025173438d + "'", double1 == 153.89149025173438d);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((-1.5574077246549023d), 103.983788761077d, 1.851766807940772d);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (byte) 1, (float) (byte) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8813735870195429d + "'", double1 == 0.8813735870195429d);
    }

//    @Test
//    public void test482() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test482");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextCauchy(0.0d, (double) 32);
//        double double6 = randomDataImpl0.nextExponential(359.1342053695754d);
//        randomDataImpl0.reSeedSecure((long) (short) 1);
//        java.lang.String str10 = randomDataImpl0.nextSecureHexString((int) ' ');
//        try {
//            int int13 = randomDataImpl0.nextZipf(35, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): exponent (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-81.3987325101009d) + "'", double4 == (-81.3987325101009d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 168.30187973257065d + "'", double6 == 168.30187973257065d);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "f97012764e5b5b2f23a398076575d792" + "'", str10.equals("f97012764e5b5b2f23a398076575d792"));
//    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 3, (float) 22L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 3.0f + "'", float2 == 3.0f);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) ' ');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 32 + "'", int1 == 32);
    }

//    @Test
//    public void test485() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test485");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (byte) 0, 3.141592653589793d);
//        randomDataImpl0.reSeedSecure();
//        int[] intArray7 = randomDataImpl0.nextPermutation((int) (byte) 100, (int) (byte) 1);
//        double double10 = randomDataImpl0.nextCauchy(0.5845089524363901d, (double) 5L);
//        try {
//            int int13 = randomDataImpl0.nextInt(32, 32);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 32 is larger than, or equal to, the maximum (32): lower bound (32) must be strictly less than upper bound (32)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.4367625756553384d + "'", double3 == 0.4367625756553384d);
//        org.junit.Assert.assertNotNull(intArray7);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-25.399900747410346d) + "'", double10 == (-25.399900747410346d));
//    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 88);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.258181274970009E37d + "'", double1 == 8.258181274970009E37d);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22025.465794806718d + "'", double1 == 22025.465794806718d);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(2.3741245648621896d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.540819445899548d + "'", double1 == 1.540819445899548d);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0L, (java.lang.Number) 0.0f, false);
        java.lang.Object[] objArray4 = numberIsTooLargeException3.getArguments();
        java.lang.Throwable[] throwableArray5 = numberIsTooLargeException3.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooLargeException3.getSpecificPattern();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNull(localizable6);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 97L, (double) (short) 1, (double) (byte) 0);
        double double5 = normalDistributionImpl3.inverseCumulativeProbability(0.5765158901134363d);
        double double7 = normalDistributionImpl3.inverseCumulativeProbability(0.9999999999999984d);
        double[] doubleArray9 = normalDistributionImpl3.sample(87);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 97.19298818676732d + "'", double5 == 97.19298818676732d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 105.0d + "'", double7 == 105.0d);
        org.junit.Assert.assertNotNull(doubleArray9);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable1, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException5.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray12 = mathException11.getArguments();
        java.lang.Throwable[] throwableArray13 = mathException11.getSuppressed();
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException0, localizable6, (java.lang.Object[]) throwableArray13);
        java.lang.Object[] objArray15 = null;
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException(localizable6, objArray15);
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException21 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable17, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable22 = numberIsTooSmallException21.getGeneralPattern();
        java.lang.Number number23 = null;
        java.lang.Number number24 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException26 = new org.apache.commons.math.exception.OutOfRangeException(localizable22, number23, number24, (java.lang.Number) 10);
        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException26);
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException26);
        java.lang.Number number29 = outOfRangeException26.getLo();
        java.lang.Number number30 = outOfRangeException26.getLo();
        java.lang.Number number31 = outOfRangeException26.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable32 = outOfRangeException26.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException37 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable33, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable38 = numberIsTooSmallException37.getGeneralPattern();
        java.lang.Number number39 = null;
        java.lang.Number number40 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException42 = new org.apache.commons.math.exception.OutOfRangeException(localizable38, number39, number40, (java.lang.Number) 10);
        org.apache.commons.math.MathException mathException43 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException42);
        java.lang.Number number44 = outOfRangeException42.getHi();
        java.lang.Throwable[] throwableArray45 = outOfRangeException42.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException(localizable32, (java.lang.Object[]) throwableArray45);
        org.apache.commons.math.MathException mathException49 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable50 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException54 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable50, (java.lang.Number) 10, (java.lang.Number) 10L, true);
        org.apache.commons.math.exception.util.Localizable localizable55 = numberIsTooSmallException54.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException59 = new org.apache.commons.math.exception.OutOfRangeException(localizable55, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 1.0E-9d, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException60 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray61 = mathException60.getArguments();
        java.lang.Throwable[] throwableArray62 = mathException60.getSuppressed();
        org.apache.commons.math.MathException mathException63 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException49, localizable55, (java.lang.Object[]) throwableArray62);
        org.apache.commons.math.MathException mathException65 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray66 = mathException65.getArguments();
        java.lang.Throwable[] throwableArray67 = mathException65.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException68 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException49, "", (java.lang.Object[]) throwableArray67);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException69 = new org.apache.commons.math.MaxIterationsExceededException(0, "hi!", (java.lang.Object[]) throwableArray67);
        org.apache.commons.math.MathException mathException70 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException16, localizable32, (java.lang.Object[]) throwableArray67);
        org.apache.commons.math.exception.util.Localizable localizable71 = mathException70.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable72 = mathException70.getGeneralPattern();
        java.lang.String str73 = mathException70.toString();
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertTrue("'" + localizable22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable22.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNull(number29);
        org.junit.Assert.assertNull(number30);
        org.junit.Assert.assertNull(number31);
        org.junit.Assert.assertTrue("'" + localizable32 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable32.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable38 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable38.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + number44 + "' != '" + 10 + "'", number44.equals(10));
        org.junit.Assert.assertNotNull(throwableArray45);
        org.junit.Assert.assertTrue("'" + localizable55 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable55.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray61);
        org.junit.Assert.assertNotNull(throwableArray62);
        org.junit.Assert.assertNotNull(objArray66);
        org.junit.Assert.assertNotNull(throwableArray67);
        org.junit.Assert.assertTrue("'" + localizable71 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable71.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable72 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable72.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "org.apache.commons.math.MathException: {0} out of [{1}, {2}] range" + "'", str73.equals("org.apache.commons.math.MathException: {0} out of [{1}, {2}] range"));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0);
        int int2 = maxIterationsExceededException1.getMaxIterations();
        java.lang.Object[] objArray4 = null;
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException1, "hi!", objArray4);
        java.lang.Class<?> wildcardClass6 = maxIterationsExceededException1.getClass();
        java.lang.Class<?> wildcardClass7 = maxIterationsExceededException1.getClass();
        int int8 = maxIterationsExceededException1.getMaxIterations();
        int int9 = maxIterationsExceededException1.getMaxIterations();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.MathException mathException1 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray2 = mathException1.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException(localizable0, objArray2);
        java.lang.Object[] objArray4 = convergenceException3.getArguments();
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(objArray4);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.248699261236361d + "'", double1 == 4.248699261236361d);
    }

//    @Test
//    public void test495() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test495");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextCauchy(0.0d, (double) 32);
//        double double6 = randomDataImpl0.nextExponential(359.1342053695754d);
//        randomDataImpl0.reSeedSecure((long) (short) 1);
//        double double10 = randomDataImpl0.nextT(57.29577951308232d);
//        randomDataImpl0.reSeed((long) (short) -1);
//        randomDataImpl0.reSeedSecure(12L);
//        try {
//            long long16 = randomDataImpl0.nextPoisson((-2.1563064218629213d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -2.156 is smaller than, or equal to, the minimum (0): mean (-2.156)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-94.69475901551763d) + "'", double4 == (-94.69475901551763d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 15.770277713759548d + "'", double6 == 15.770277713759548d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.7034718421203555d + "'", double10 == 0.7034718421203555d);
//    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(2.3257538777426525d, (double) (-1), 1.771260819978906d, 3);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        double double1 = org.apache.commons.math.util.FastMath.sin(2.6859131956935225d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4400725428656519d + "'", double1 == 0.4400725428656519d);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((-142.3281413805767d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-5.221119010901584d) + "'", double1 == (-5.221119010901584d));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.5772156649015329d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8326184616337932d + "'", double1 == 0.8326184616337932d);
    }

//    @Test
//    public void test500() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test500");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeed();
//        double double4 = randomDataImpl0.nextCauchy(0.0d, (double) 32);
//        double double6 = randomDataImpl0.nextExponential(359.1342053695754d);
//        randomDataImpl0.reSeedSecure((long) (short) 1);
//        double double10 = randomDataImpl0.nextT(57.29577951308232d);
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeed();
//        double double15 = randomDataImpl0.nextUniform(0.0d, 22.835055624293666d);
//        double double17 = randomDataImpl0.nextExponential(14.15426224147926d);
//        try {
//            double double20 = randomDataImpl0.nextBeta(Double.POSITIVE_INFINITY, 2.3741245648621896d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Continued fraction diverged to NaN for value 0.5");
//        } catch (org.apache.commons.math.exception.MathUserException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-96.30047459954146d) + "'", double4 == (-96.30047459954146d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1698.2619884317767d + "'", double6 == 1698.2619884317767d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-2.0387696793731087d) + "'", double10 == (-2.0387696793731087d));
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 2.3380146608045096d + "'", double15 == 2.3380146608045096d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 9.805207884650837d + "'", double17 == 9.805207884650837d);
//    }
//}

