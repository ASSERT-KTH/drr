import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.0d, 3.970291913552122d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (short) 10, 34.713109915419565d, (double) 1079640064);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((-0.9443504370351303d), (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.1971063983333737E30d) + "'", double2 == (-1.1971063983333737E30d));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        long long2 = org.apache.commons.math.util.MathUtils.pow(160L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) (-940670014L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        long long1 = org.apache.commons.math.util.MathUtils.sign((-32L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        double double1 = org.apache.commons.math.util.FastMath.abs((-1.1971063983333737E30d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1971063983333737E30d + "'", double1 == 1.1971063983333737E30d);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) (-7766279631452241820L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(3628800.0d, (-0.5063656411097588d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-3.408679112792015d) + "'", double2 == (-3.408679112792015d));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        double double2 = org.apache.commons.math.util.FastMath.min(0.0d, 1.0040208370454589d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        double double1 = org.apache.commons.math.util.FastMath.floor(4.728984510222813d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.0d + "'", double1 == 4.0d);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        double double1 = org.apache.commons.math.util.FastMath.log(0.8842138921066355d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.12305628621530103d) + "'", double1 == (-0.12305628621530103d));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(0, 89);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 159);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.0689042022202315d + "'", double1 == 5.0689042022202315d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) (-7766279631452241820L), (-0.12305628621530103d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) 890.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        double double2 = org.apache.commons.math.util.FastMath.max((-1.75d), (double) 1L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10.739947145006717d, (java.lang.Number) (-232.81934595108032d), (int) (byte) 1);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 90L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 348L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        int int1 = org.apache.commons.math.util.MathUtils.sign((-1686110207));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        double double1 = org.apache.commons.math.util.FastMath.atanh((-0.5063656411097588d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5578300447656788d) + "'", double1 == (-0.5578300447656788d));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        long long1 = org.apache.commons.math.util.FastMath.round((double) (-42L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-42L) + "'", long1 == (-42L));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        double double1 = org.apache.commons.math.util.FastMath.asin((-1.2127883429123472d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(4.641588833612779d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 159);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, 0L);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) 159);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger7);
        java.math.BigInteger bigInteger11 = null;
        try {
            java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        try {
            java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (int) (short) -1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        int int2 = org.apache.commons.math.util.FastMath.min((-1048576), (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1048576) + "'", int2 == (-1048576));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) (-1L), 3.141592653589793d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.283185307179586d + "'", double2 == 5.283185307179586d);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(35.0d, 36.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 35.00000000000001d + "'", double2 == 35.00000000000001d);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((int) (short) 0, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.3088453256022203d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3088453256022203d + "'", double1 == 0.3088453256022203d);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 159, (double) ' ');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 141L, 160.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 141.0f + "'", float2 == 141.0f);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) (-940670014L), (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-9.4067002E8f) + "'", float2 == (-9.4067002E8f));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) (short) 1, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) (-178L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        double double2 = org.apache.commons.math.util.FastMath.max((double) (byte) 100, (double) 100.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(0.1888664060920433d, 0.0d, 2.461729143006029E41d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (-940670014L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 9.4067002E8f + "'", float1 == 9.4067002E8f);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        long long1 = org.apache.commons.math.util.FastMath.round((double) (-7766279631452241820L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-7766279631452241920L) + "'", long1 == (-7766279631452241920L));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((-1686110207), (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1686110197) + "'", int2 == (-1686110197));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        double double1 = org.apache.commons.math.util.MathUtils.sign(3628800.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        double double2 = org.apache.commons.math.util.FastMath.atan2((-1.2676506002282294E30d), 1.0E208d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.2676506002282295E-178d) + "'", double2 == (-1.2676506002282295E-178d));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(1, 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) (-1074790241));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) (-1048576));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.3304931400217347d) + "'", double1 == (-0.3304931400217347d));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        double[] doubleArray2 = new double[] { '#', (short) 0 };
        double[] doubleArray6 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray6);
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray10 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 10);
        double[] doubleArray11 = null;
        double[] doubleArray14 = new double[] { '#', (short) 0 };
        double[] doubleArray18 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray14, doubleArray18);
        int int20 = org.apache.commons.math.util.MathUtils.hash(doubleArray14);
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray14);
        double[] doubleArray24 = new double[] { '#', (short) 0 };
        double[] doubleArray28 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equals(doubleArray24, doubleArray28);
        int int30 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray24, (double) 10);
        double[] doubleArray35 = new double[] { '#', (short) 0 };
        double[] doubleArray39 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equals(doubleArray35, doubleArray39);
        int int41 = org.apache.commons.math.util.MathUtils.hash(doubleArray35);
        double[] doubleArray44 = new double[] { '#', (short) 0 };
        double[] doubleArray48 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean49 = org.apache.commons.math.util.MathUtils.equals(doubleArray44, doubleArray48);
        int int50 = org.apache.commons.math.util.MathUtils.hash(doubleArray44);
        double double51 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray35, doubleArray44);
        double double52 = org.apache.commons.math.util.MathUtils.distance1(doubleArray24, doubleArray35);
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equals(doubleArray14, doubleArray35);
        double double54 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray35);
        double[] doubleArray57 = new double[] { '#', (short) 0 };
        double[] doubleArray61 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean62 = org.apache.commons.math.util.MathUtils.equals(doubleArray57, doubleArray61);
        int int63 = org.apache.commons.math.util.MathUtils.hash(doubleArray57);
        double[] doubleArray65 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray57, (double) 10);
        double[] doubleArray68 = new double[] { '#', (short) 0 };
        double[] doubleArray72 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean73 = org.apache.commons.math.util.MathUtils.equals(doubleArray68, doubleArray72);
        int int74 = org.apache.commons.math.util.MathUtils.hash(doubleArray68);
        double[] doubleArray77 = new double[] { '#', (short) 0 };
        double[] doubleArray81 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean82 = org.apache.commons.math.util.MathUtils.equals(doubleArray77, doubleArray81);
        int int83 = org.apache.commons.math.util.MathUtils.hash(doubleArray77);
        double double84 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray68, doubleArray77);
        double double85 = org.apache.commons.math.util.MathUtils.distance1(doubleArray57, doubleArray68);
        double[] doubleArray87 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray57, 1.5574077246549023d);
        double double88 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray35, doubleArray87);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray87);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (1.557 >= 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-940670015) + "'", int8 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-940670015) + "'", int20 == (-940670015));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-940670015) + "'", int30 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-940670015) + "'", int41 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-940670015) + "'", int50 == (-940670015));
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + (-940670015) + "'", int63 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + (-940670015) + "'", int74 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + (-940670015) + "'", int83 == (-940670015));
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 0.0d + "'", double84 == 0.0d);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 0.0d + "'", double85 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 33.4425922753451d + "'", double88 == 33.4425922753451d);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (short) 0, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) (-940669124L), (-1), 1076101120);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        double[] doubleArray2 = new double[] { '#', (short) 0 };
        double[] doubleArray6 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray6);
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (35 >= 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-940670015) + "'", int8 == (-940670015));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) 1079640064, (long) 159);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 171662770176L + "'", long2 == 171662770176L);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 97, (double) 1.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 96.99999999999999d + "'", double2 == 96.99999999999999d);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        double double1 = org.apache.commons.math.util.FastMath.sinh(10.739947145006717d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 23081.80592729469d + "'", double1 == 23081.80592729469d);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        int int2 = org.apache.commons.math.util.FastMath.min(1076101120, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        double double1 = org.apache.commons.math.util.FastMath.expm1(92.13617560368711d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0333147966386297E40d + "'", double1 == 1.0333147966386297E40d);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) (-940670015), (double) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-9.406700149999999E8d) + "'", double2 == (-9.406700149999999E8d));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(0L, (long) 'a');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        double double1 = org.apache.commons.math.util.FastMath.rint((-1.2676506002282294E30d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.2676506002282294E30d) + "'", double1 == (-1.2676506002282294E30d));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(104, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 94 + "'", int2 == 94);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 135);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 135);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.08836868610400143d + "'", double1 == 0.08836868610400143d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) (-1963152018), 104, (-97517567));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 97);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(2.2448064095871728E38d, (-9.406700110730925E8d));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 1.07610112E9f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.031853083407121d + "'", double1 == 9.031853083407121d);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(1.3766190333333037d, (-338));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.4585284339049374E-102d + "'", double2 == 2.4585284339049374E-102d);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-1074790241), 39L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1208867745) + "'", int2 == (-1208867745));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        int[] intArray3 = new int[] { (-1), '#', 11 };
        int[] intArray9 = new int[] { 0, 'a', '4', 160, (short) -1 };
        int int10 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray9);
        int[] intArray17 = new int[] { (short) 1, (byte) 10, '#', (short) 10, 100, (-940670015) };
        double double18 = org.apache.commons.math.util.MathUtils.distance(intArray3, intArray17);
        int[] intArray22 = new int[] { (-1), '#', 11 };
        int[] intArray28 = new int[] { 0, 'a', '4', 160, (short) -1 };
        int int29 = org.apache.commons.math.util.MathUtils.distance1(intArray22, intArray28);
        int[] intArray36 = new int[] { (short) 1, (byte) 10, '#', (short) 10, 100, (-940670015) };
        double double37 = org.apache.commons.math.util.MathUtils.distance(intArray22, intArray36);
        int[] intArray41 = new int[] { (-1), '#', 11 };
        int[] intArray47 = new int[] { 0, 'a', '4', 160, (short) -1 };
        int int48 = org.apache.commons.math.util.MathUtils.distance1(intArray41, intArray47);
        int[] intArray55 = new int[] { (short) 1, (byte) 10, '#', (short) 10, 100, (-940670015) };
        double double56 = org.apache.commons.math.util.MathUtils.distance(intArray41, intArray55);
        int int57 = org.apache.commons.math.util.MathUtils.distance1(intArray22, intArray41);
        double double58 = org.apache.commons.math.util.MathUtils.distance(intArray3, intArray22);
        int[] intArray62 = new int[] { (-1), '#', 11 };
        int[] intArray68 = new int[] { 0, 'a', '4', 160, (short) -1 };
        int int69 = org.apache.commons.math.util.MathUtils.distance1(intArray62, intArray68);
        int[] intArray76 = new int[] { (short) 1, (byte) 10, '#', (short) 10, 100, (-940670015) };
        double double77 = org.apache.commons.math.util.MathUtils.distance(intArray62, intArray76);
        int[] intArray81 = new int[] { (-1), '#', 11 };
        int[] intArray87 = new int[] { 0, 'a', '4', 160, (short) -1 };
        int int88 = org.apache.commons.math.util.MathUtils.distance1(intArray81, intArray87);
        int[] intArray95 = new int[] { (short) 1, (byte) 10, '#', (short) 10, 100, (-940670015) };
        double double96 = org.apache.commons.math.util.MathUtils.distance(intArray81, intArray95);
        int int97 = org.apache.commons.math.util.MathUtils.distance1(intArray62, intArray81);
        double double98 = org.apache.commons.math.util.MathUtils.distance(intArray22, intArray81);
        java.lang.Class<?> wildcardClass99 = intArray22.getClass();
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 104 + "'", int10 == 104);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 34.713109915419565d + "'", double18 == 34.713109915419565d);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 104 + "'", int29 == 104);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 34.713109915419565d + "'", double37 == 34.713109915419565d);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 104 + "'", int48 == 104);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 34.713109915419565d + "'", double56 == 34.713109915419565d);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertNotNull(intArray62);
        org.junit.Assert.assertNotNull(intArray68);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 104 + "'", int69 == 104);
        org.junit.Assert.assertNotNull(intArray76);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 34.713109915419565d + "'", double77 == 34.713109915419565d);
        org.junit.Assert.assertNotNull(intArray81);
        org.junit.Assert.assertNotNull(intArray87);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 104 + "'", int88 == 104);
        org.junit.Assert.assertNotNull(intArray95);
        org.junit.Assert.assertTrue("'" + double96 + "' != '" + 34.713109915419565d + "'", double96 == 34.713109915419565d);
        org.junit.Assert.assertTrue("'" + int97 + "' != '" + 0 + "'", int97 == 0);
        org.junit.Assert.assertTrue("'" + double98 + "' != '" + 0.0d + "'", double98 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass99);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        int int1 = org.apache.commons.math.util.MathUtils.hash((-1.2676506002282294E30d));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-969932800) + "'", int1 == (-969932800));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        double double1 = org.apache.commons.math.util.FastMath.cos(22026.465794806718d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7250423179995003d) + "'", double1 == (-0.7250423179995003d));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.1888664060920433d, 0.9966541755785819d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.18727974939635064d + "'", double2 == 0.18727974939635064d);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialLog((-1048576));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5872139151569291d) + "'", double1 == (-0.5872139151569291d));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        double double1 = org.apache.commons.math.util.FastMath.tanh(4.9E-324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialLog((-969932800));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((-1963152018));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.718281828459045d + "'", double1 == 2.718281828459045d);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 89, 6.473322308742974E100d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 89.00000000000001d + "'", double2 == 89.00000000000001d);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-1963152018), (-1686110197));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        float float2 = org.apache.commons.math.util.FastMath.min((float) '#', (float) (-1074790241));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.07479027E9f) + "'", float2 == (-1.07479027E9f));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        int int2 = org.apache.commons.math.util.FastMath.max((int) 'a', (-1074790400));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (-338), 250L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-338L) + "'", long2 == (-338L));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        long long2 = org.apache.commons.math.util.FastMath.min(0L, (-32L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-32L) + "'", long2 == (-32L));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        int int1 = org.apache.commons.math.util.MathUtils.sign((int) '#');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) (-1074790241));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 159);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, 0L);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) 159);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger7);
        try {
            java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, (-338));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        int int1 = org.apache.commons.math.util.MathUtils.sign((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        long long1 = org.apache.commons.math.util.FastMath.abs(1L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(1.0333147966386297E40d, 135);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.50072070111515E80d + "'", double2 == 4.50072070111515E80d);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        long long2 = org.apache.commons.math.util.FastMath.max(141L, 4L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 141L + "'", long2 == 141L);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(11, (int) '4');
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        double double1 = org.apache.commons.math.util.FastMath.sin(33.4425922753451d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.897878614642861d + "'", double1 == 0.897878614642861d);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        double double1 = org.apache.commons.math.util.FastMath.acosh((-1.75d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        double double1 = org.apache.commons.math.util.FastMath.asinh(92.13617560368711d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.216444281158814d + "'", double1 == 5.216444281158814d);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 'a', 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        double double2 = org.apache.commons.math.util.MathUtils.round(0.0d, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) (-755042924), 94);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) (byte) 0, 0L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        float float2 = org.apache.commons.math.util.FastMath.min((-42.0f), 9.4067002E8f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-42.0f) + "'", float2 == (-42.0f));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(0.17543139267904395d, 62);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 8.0903450081119181E17d + "'", double2 == 8.0903450081119181E17d);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.8275335011967608E15d, (double) 1.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 160, 10.000000000000002d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.000000000000002d + "'", double2 == 10.000000000000002d);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 100, (-1074790400));
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 4L, 0.48917865697472146d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-1963152018), 104);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((int) '#', 1048576);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 36700160 + "'", int2 == 36700160);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(0L, (long) (-97517567));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(1048576, (-1686110197));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(89);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(0.5840734641020688d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6178531763471193d + "'", double1 == 0.6178531763471193d);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-89), 32);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2848) + "'", int2 == (-2848));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        double double2 = org.apache.commons.math.util.FastMath.min(10.000000000000002d, 1.4210804127942926d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.4210804127942926d + "'", double2 == 1.4210804127942926d);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        double double1 = org.apache.commons.math.util.FastMath.abs((-1.2127883429123472d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2127883429123472d + "'", double1 == 1.2127883429123472d);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 1L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(1.0040208370454589d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0013384866692687d + "'", double1 == 1.0013384866692687d);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-1074790241), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(348L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 348L + "'", long2 == 348L);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) (-1963152018), (long) '4');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-102083904936L) + "'", long2 == (-102083904936L));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) (-940670015));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 160.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.081404364984463d + "'", double1 == 5.081404364984463d);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) 89);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(11);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.99168E7d + "'", double1 == 3.99168E7d);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((int) (short) 10, (-940670015));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 159);
        try {
            java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (-2L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(1.1752011936438014d, (int) (short) -1, 1500625);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(0, (-1048576));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1048576 + "'", int2 == 1048576);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(250L, (long) 32);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2L + "'", long2 == 2L);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) (short) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1076101120 + "'", int1 == 1076101120);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 1.2676506002282294E30d + "'", number4.equals(1.2676506002282294E30d));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(32);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) 0.0f, 3.141592653589793d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        double double2 = org.apache.commons.math.util.MathUtils.log(0.17543139267904395d, (-0.6870488395497887d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray7 = nonMonotonousSequenceException6.getSuppressed();
        java.lang.Number number8 = nonMonotonousSequenceException6.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray13 = nonMonotonousSequenceException12.getSuppressed();
        nonMonotonousSequenceException6.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = nonMonotonousSequenceException6.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException17 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) Double.NEGATIVE_INFINITY, (java.lang.Number) 32.0d, (int) (byte) 1, orderDirection15, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection18 = nonMonotonousSequenceException17.getDirection();
        boolean boolean19 = nonMonotonousSequenceException17.getStrict();
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 1.2676506002282294E30d + "'", number8.equals(1.2676506002282294E30d));
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertTrue("'" + orderDirection15 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection15.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection18 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection18.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.0d, 0.8842138921066355d, 94);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 1076101120, (long) 1500625);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1077601745L + "'", long2 == 1077601745L);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 1048576);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        double double2 = org.apache.commons.math.util.MathUtils.log(0.17542037193601015d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (short) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) (-1686110207), (long) (-1));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1686110207L + "'", long2 == 1686110207L);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.8342233605065102d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6717532003326169d + "'", double1 == 0.6717532003326169d);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(1.5430806348152437d, 9167.324722093172d, 5.216444281158814d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) (-42.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow((int) (byte) 10, (-969932800));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((-0.0d), (int) (short) 1, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(34.713109915419565d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.952262699770491E14d + "'", double1 == 5.952262699770491E14d);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(1.9958400000000026E7d, (-1), (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-1074790241), 94);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1010486975) + "'", int2 == (-1010486975));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        long long2 = org.apache.commons.math.util.FastMath.max((-7766279631452241820L), (long) (byte) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) 0);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 135, 0, 89774434);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        double double2 = org.apache.commons.math.util.MathUtils.round(2.220446049250313E-16d, 104);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.220446049250313E-16d + "'", double2 == 2.220446049250313E-16d);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(1048576, 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) (-89), (-42L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3738L + "'", long2 == 3738L);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        float float2 = org.apache.commons.math.util.FastMath.max(100.0f, (float) (-7766279631452241820L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-7.7662794E18f) + "'", float2 == (-7.7662794E18f));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 10, number1, 0);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 1079640064);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0796400640000002E9d + "'", double1 == 1.0796400640000002E9d);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) (-2848));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.547473508864641E-13d + "'", double1 == 4.547473508864641E-13d);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        int int1 = org.apache.commons.math.util.FastMath.abs((-969932800));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 969932800 + "'", int1 == 969932800);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) 0);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        double double1 = org.apache.commons.math.util.FastMath.acos(5.952262699770491E14d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 969932800, (long) (-1686110197));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1686110197L) + "'", long2 == (-1686110197L));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((-1074790241));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) (-1048576));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        double double2 = org.apache.commons.math.util.FastMath.max(0.9866275920404853d, 17.502307845873883d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 17.502307845873883d + "'", double2 == 17.502307845873883d);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(4.50072070111515E80d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.8552394947127E78d + "'", double1 == 7.8552394947127E78d);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 969932800, (long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 969932900L + "'", long2 == 969932900L);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.0f), (java.lang.Number) 1.5533430342749532d, (int) (short) 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-1.0f) + "'", number4.equals((-1.0f)));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) (-89));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 969932800);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 969932800L + "'", long1 == 969932800L);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        double double1 = org.apache.commons.math.util.FastMath.ceil(6.473322308742974E100d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.473322308742974E100d + "'", double1 == 6.473322308742974E100d);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        double double1 = org.apache.commons.math.util.FastMath.ceil(5.283185307179586d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.0d + "'", double1 == 6.0d);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        float float1 = org.apache.commons.math.util.MathUtils.sign(0.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((-1.5197343734725893E-18d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(32, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) (-1963152018), (double) 2L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.9631520179999998E9d) + "'", double2 == (-1.9631520179999998E9d));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        int[] intArray3 = new int[] { (-1), '#', 11 };
        int[] intArray9 = new int[] { 0, 'a', '4', 160, (short) -1 };
        int int10 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray9);
        int[] intArray17 = new int[] { (short) 1, (byte) 10, '#', (short) 10, 100, (-940670015) };
        double double18 = org.apache.commons.math.util.MathUtils.distance(intArray3, intArray17);
        java.lang.Class<?> wildcardClass19 = intArray3.getClass();
        int[] intArray23 = new int[] { (-1), '#', 11 };
        int[] intArray29 = new int[] { 0, 'a', '4', 160, (short) -1 };
        int int30 = org.apache.commons.math.util.MathUtils.distance1(intArray23, intArray29);
        int[] intArray37 = new int[] { (short) 1, (byte) 10, '#', (short) 10, 100, (-940670015) };
        double double38 = org.apache.commons.math.util.MathUtils.distance(intArray23, intArray37);
        int[] intArray42 = new int[] { (-1), '#', 11 };
        int[] intArray48 = new int[] { 0, 'a', '4', 160, (short) -1 };
        int int49 = org.apache.commons.math.util.MathUtils.distance1(intArray42, intArray48);
        int[] intArray56 = new int[] { (short) 1, (byte) 10, '#', (short) 10, 100, (-940670015) };
        double double57 = org.apache.commons.math.util.MathUtils.distance(intArray42, intArray56);
        int[] intArray61 = new int[] { (-1), '#', 11 };
        int[] intArray67 = new int[] { 0, 'a', '4', 160, (short) -1 };
        int int68 = org.apache.commons.math.util.MathUtils.distance1(intArray61, intArray67);
        int[] intArray75 = new int[] { (short) 1, (byte) 10, '#', (short) 10, 100, (-940670015) };
        double double76 = org.apache.commons.math.util.MathUtils.distance(intArray61, intArray75);
        int[] intArray80 = new int[] { (-1), '#', 11 };
        int[] intArray86 = new int[] { 0, 'a', '4', 160, (short) -1 };
        int int87 = org.apache.commons.math.util.MathUtils.distance1(intArray80, intArray86);
        int[] intArray94 = new int[] { (short) 1, (byte) 10, '#', (short) 10, 100, (-940670015) };
        double double95 = org.apache.commons.math.util.MathUtils.distance(intArray80, intArray94);
        int int96 = org.apache.commons.math.util.MathUtils.distance1(intArray61, intArray80);
        double double97 = org.apache.commons.math.util.MathUtils.distance(intArray42, intArray61);
        int int98 = org.apache.commons.math.util.MathUtils.distance1(intArray23, intArray61);
        int int99 = org.apache.commons.math.util.MathUtils.distanceInf(intArray3, intArray61);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 104 + "'", int10 == 104);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 34.713109915419565d + "'", double18 == 34.713109915419565d);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 104 + "'", int30 == 104);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 34.713109915419565d + "'", double38 == 34.713109915419565d);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 104 + "'", int49 == 104);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 34.713109915419565d + "'", double57 == 34.713109915419565d);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertNotNull(intArray67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 104 + "'", int68 == 104);
        org.junit.Assert.assertNotNull(intArray75);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 34.713109915419565d + "'", double76 == 34.713109915419565d);
        org.junit.Assert.assertNotNull(intArray80);
        org.junit.Assert.assertNotNull(intArray86);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 104 + "'", int87 == 104);
        org.junit.Assert.assertNotNull(intArray94);
        org.junit.Assert.assertTrue("'" + double95 + "' != '" + 34.713109915419565d + "'", double95 == 34.713109915419565d);
        org.junit.Assert.assertTrue("'" + int96 + "' != '" + 0 + "'", int96 == 0);
        org.junit.Assert.assertTrue("'" + double97 + "' != '" + 0.0d + "'", double97 == 0.0d);
        org.junit.Assert.assertTrue("'" + int98 + "' != '" + 0 + "'", int98 == 0);
        org.junit.Assert.assertTrue("'" + int99 + "' != '" + 0 + "'", int99 == 0);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        double double2 = org.apache.commons.math.util.MathUtils.log(0.0d, (-1.1971063983333737E30d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        double double1 = org.apache.commons.math.util.FastMath.acosh((-0.5063656411097588d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        double double1 = org.apache.commons.math.util.FastMath.tanh(4.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.999329299739067d + "'", double1 == 0.999329299739067d);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((int) (byte) -1, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(100L, (long) (short) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray7 = nonMonotonousSequenceException6.getSuppressed();
        java.lang.Number number8 = nonMonotonousSequenceException6.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray13 = nonMonotonousSequenceException12.getSuppressed();
        nonMonotonousSequenceException6.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = nonMonotonousSequenceException6.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException17 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) Double.NEGATIVE_INFINITY, (java.lang.Number) 32.0d, (int) (byte) 1, orderDirection15, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection18 = nonMonotonousSequenceException17.getDirection();
        java.lang.String str19 = nonMonotonousSequenceException17.toString();
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 1.2676506002282294E30d + "'", number8.equals(1.2676506002282294E30d));
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertTrue("'" + orderDirection15 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection15.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection18 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection18.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (32 >= -∞)" + "'", str19.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (32 >= -∞)"));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 'a');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.691673596021348E41d + "'", double1 == 6.691673596021348E41d);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) (-1686110197L), (-1963152018));
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.99822295029797d + "'", double1 == 2.99822295029797d);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(29.57116476681019d, (double) (-940670015));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        int int2 = org.apache.commons.math.util.FastMath.min(36700160, 969932800);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 36700160 + "'", int2 == 36700160);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        double[] doubleArray0 = null;
        double[] doubleArray3 = new double[] { '#', (short) 0 };
        double[] doubleArray7 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean8 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray7);
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        double[] doubleArray12 = new double[] { '#', (short) 0 };
        double[] doubleArray16 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean17 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray16);
        int int18 = org.apache.commons.math.util.MathUtils.hash(doubleArray12);
        double double19 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray12);
        double[] doubleArray21 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, 35.0d);
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray21);
        double[] doubleArray25 = new double[] { '#', (short) 0 };
        double[] doubleArray29 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equals(doubleArray25, doubleArray29);
        int int31 = org.apache.commons.math.util.MathUtils.hash(doubleArray25);
        double[] doubleArray33 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, (double) 10);
        double[] doubleArray36 = new double[] { '#', (short) 0 };
        double[] doubleArray40 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean41 = org.apache.commons.math.util.MathUtils.equals(doubleArray36, doubleArray40);
        int int42 = org.apache.commons.math.util.MathUtils.hash(doubleArray36);
        double[] doubleArray45 = new double[] { '#', (short) 0 };
        double[] doubleArray49 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean50 = org.apache.commons.math.util.MathUtils.equals(doubleArray45, doubleArray49);
        int int51 = org.apache.commons.math.util.MathUtils.hash(doubleArray45);
        double double52 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray36, doubleArray45);
        double double53 = org.apache.commons.math.util.MathUtils.distance1(doubleArray25, doubleArray36);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection54 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray25, orderDirection54, false);
        double double57 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray25);
        int int58 = org.apache.commons.math.util.MathUtils.hash(doubleArray25);
        double double59 = org.apache.commons.math.util.MathUtils.distance1(doubleArray21, doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-940670015) + "'", int9 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-940670015) + "'", int18 == (-940670015));
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-940670015) + "'", int31 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-940670015) + "'", int42 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-940670015) + "'", int51 == (-940670015));
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection54 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection54.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 35.0d + "'", double57 == 35.0d);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + (-940670015) + "'", int58 == (-940670015));
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (-969932800), 1L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-969932800L) + "'", long2 == (-969932800L));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        double[] doubleArray2 = new double[] { '#', (short) 0 };
        double[] doubleArray6 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray6);
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray10 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 10);
        double[] doubleArray13 = new double[] { '#', (short) 0 };
        double[] doubleArray17 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray17);
        int int19 = org.apache.commons.math.util.MathUtils.hash(doubleArray13);
        double[] doubleArray22 = new double[] { '#', (short) 0 };
        double[] doubleArray26 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equals(doubleArray22, doubleArray26);
        int int28 = org.apache.commons.math.util.MathUtils.hash(doubleArray22);
        double double29 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray13, doubleArray22);
        double double30 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray13);
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, 1.5574077246549023d);
        double[] doubleArray35 = new double[] { '#', (short) 0 };
        double[] doubleArray39 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equals(doubleArray35, doubleArray39);
        double double41 = org.apache.commons.math.util.MathUtils.distance(doubleArray32, doubleArray39);
        double[] doubleArray42 = null;
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray32, doubleArray42);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-940670015) + "'", int8 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-940670015) + "'", int19 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-940670015) + "'", int28 == (-940670015));
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 100.03269632610193d + "'", double41 == 100.03269632610193d);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) (byte) 0, 62);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        double double1 = org.apache.commons.math.util.FastMath.cosh(46163.61187625146d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.332621544395286E157d + "'", double1 == 9.332621544395286E157d);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 35, (-2L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 37L + "'", long2 == 37L);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(1.9958400000000026E7d, (double) 348L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.08836868610400143d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) (-1963152018), 10L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1963152028L) + "'", long2 == (-1963152028L));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        long long1 = org.apache.commons.math.util.FastMath.round(10.739947145006717d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 11L + "'", long1 == 11L);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (short) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) (-1.07479027E9f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.875862901480542E7d) + "'", double1 == (-1.875862901480542E7d));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) (-178L), 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        double double1 = org.apache.commons.math.util.FastMath.acos(5.216444281158814d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-940670015), 0L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(94, (-940670015));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) 1L, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        long long2 = org.apache.commons.math.util.MathUtils.pow((-2L), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((int) (short) 0, (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-52) + "'", int2 == (-52));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray10 = nonMonotonousSequenceException9.getSuppressed();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException9);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = nonMonotonousSequenceException3.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray17 = nonMonotonousSequenceException16.getSuppressed();
        java.lang.Number number18 = nonMonotonousSequenceException16.getArgument();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException16);
        java.lang.String str20 = nonMonotonousSequenceException3.toString();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1.2676506002282294E30d + "'", number5.equals(1.2676506002282294E30d));
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 1.2676506002282294E30d + "'", number18.equals(1.2676506002282294E30d));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (0 >= 1,267,650,600,228,229,400,000,000,000,000)" + "'", str20.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (0 >= 1,267,650,600,228,229,400,000,000,000,000)"));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        double double1 = org.apache.commons.math.util.FastMath.sinh(136.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.794547712069427E58d + "'", double1 == 5.794547712069427E58d);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        double double1 = org.apache.commons.math.util.FastMath.sin(7.105427357601002E-15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.105427357601002E-15d + "'", double1 == 7.105427357601002E-15d);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(1.1752011936438014d, 0.0d, (-1.0d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((-755042924), 969932800);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 36700160);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.670016E7d + "'", double1 == 3.670016E7d);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 159);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, 0L);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) 159);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger7);
        try {
            java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (-2L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(36.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.1556157735575975E15d + "'", double1 == 2.1556157735575975E15d);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 1500625, (float) 10L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        long long2 = org.apache.commons.math.util.MathUtils.pow((-2L), 171662770176L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        double[] doubleArray5 = new double[] { (-1686110197), 2.302585092994046d, 5.283185307179586d, 52L, (-1208867745) };
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray10 = nonMonotonousSequenceException9.getSuppressed();
        java.lang.Number number11 = nonMonotonousSequenceException9.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray16 = nonMonotonousSequenceException15.getSuppressed();
        nonMonotonousSequenceException9.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException15);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection18 = nonMonotonousSequenceException9.getDirection();
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray5, orderDirection18, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 3 and 4 are not strictly increasing (52 >= -1,208,867,745)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 1.2676506002282294E30d + "'", number11.equals(1.2676506002282294E30d));
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertTrue("'" + orderDirection18 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection18.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 32.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6610060414837631d + "'", double1 == 0.6610060414837631d);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 969932800, 1686110207L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-716177407L) + "'", long2 == (-716177407L));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) (short) 10, (long) '#');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 70L + "'", long2 == 70L);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(969932800, (-1074790241));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        double double1 = org.apache.commons.math.util.FastMath.log((-0.8414709848078965d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        long long2 = org.apache.commons.math.util.FastMath.min(3738L, (long) 159);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 159L + "'", long2 == 159L);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 1048576, (-0.7615941559557649d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 2L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 114.59155902616465d + "'", double1 == 114.59155902616465d);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5574077246549023d + "'", double1 == 1.5574077246549023d);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.6610060414837631d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.01153673179946589d + "'", double1 == 0.01153673179946589d);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        double double1 = org.apache.commons.math.util.FastMath.atanh(6.283185307179586d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        int[] intArray5 = new int[] { ' ', (byte) 100, (short) 1, (-1963152018), (byte) 10 };
        int[] intArray6 = null;
        try {
            double double7 = org.apache.commons.math.util.MathUtils.distance(intArray5, intArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        double double1 = org.apache.commons.math.util.FastMath.cosh(100.03269632610193d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3887306754369975E43d + "'", double1 == 1.3887306754369975E43d);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        int int1 = org.apache.commons.math.util.FastMath.abs((-1686110197));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1686110197 + "'", int1 == 1686110197);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (short) 1, (-52));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-52) + "'", int2 == (-52));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        double double1 = org.apache.commons.math.util.FastMath.acosh(5.216444281158814d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.3356465550032266d + "'", double1 == 2.3356465550032266d);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        double double1 = org.apache.commons.math.util.FastMath.tan(1.5533430342749532d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 57.289961630759144d + "'", double1 == 57.289961630759144d);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        double double1 = org.apache.commons.math.util.FastMath.acos(4.547473508864641E-13d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267944418d + "'", double1 == 1.5707963267944418d);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 100L, (float) 94);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 94.0f + "'", float2 == 94.0f);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((int) (short) 1, 1076101120);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1076101121 + "'", int2 == 1076101121);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.01153673179946589d, 6.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        double double1 = org.apache.commons.math.util.FastMath.cosh(1.0333147966386297E40d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 1L, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(1076101120, (-89));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((int) 'a');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 160L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.792526803190927d + "'", double1 == 2.792526803190927d);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 1500625);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 114.48732085660063d + "'", double1 == 114.48732085660063d);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(1048576, 1079640064);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        long long2 = org.apache.commons.math.util.FastMath.max((-716177407L), (-338L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-338L) + "'", long2 == (-338L));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 1.07610112E9f, 6.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        int[] intArray3 = new int[] { (-1), '#', 11 };
        int[] intArray9 = new int[] { 0, 'a', '4', 160, (short) -1 };
        int int10 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray9);
        int[] intArray17 = new int[] { (short) 1, (byte) 10, '#', (short) 10, 100, (-940670015) };
        double double18 = org.apache.commons.math.util.MathUtils.distance(intArray3, intArray17);
        int[] intArray22 = new int[] { (-1), '#', 11 };
        int[] intArray28 = new int[] { 0, 'a', '4', 160, (short) -1 };
        int int29 = org.apache.commons.math.util.MathUtils.distance1(intArray22, intArray28);
        int[] intArray36 = new int[] { (short) 1, (byte) 10, '#', (short) 10, 100, (-940670015) };
        double double37 = org.apache.commons.math.util.MathUtils.distance(intArray22, intArray36);
        int[] intArray41 = new int[] { (-1), '#', 11 };
        int[] intArray47 = new int[] { 0, 'a', '4', 160, (short) -1 };
        int int48 = org.apache.commons.math.util.MathUtils.distance1(intArray41, intArray47);
        int[] intArray55 = new int[] { (short) 1, (byte) 10, '#', (short) 10, 100, (-940670015) };
        double double56 = org.apache.commons.math.util.MathUtils.distance(intArray41, intArray55);
        int[] intArray60 = new int[] { (-1), '#', 11 };
        int[] intArray66 = new int[] { 0, 'a', '4', 160, (short) -1 };
        int int67 = org.apache.commons.math.util.MathUtils.distance1(intArray60, intArray66);
        int[] intArray74 = new int[] { (short) 1, (byte) 10, '#', (short) 10, 100, (-940670015) };
        double double75 = org.apache.commons.math.util.MathUtils.distance(intArray60, intArray74);
        int int76 = org.apache.commons.math.util.MathUtils.distance1(intArray41, intArray60);
        double double77 = org.apache.commons.math.util.MathUtils.distance(intArray22, intArray41);
        double double78 = org.apache.commons.math.util.MathUtils.distance(intArray3, intArray22);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 104 + "'", int10 == 104);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 34.713109915419565d + "'", double18 == 34.713109915419565d);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 104 + "'", int29 == 104);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 34.713109915419565d + "'", double37 == 34.713109915419565d);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 104 + "'", int48 == 104);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 34.713109915419565d + "'", double56 == 34.713109915419565d);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 104 + "'", int67 == 104);
        org.junit.Assert.assertNotNull(intArray74);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 34.713109915419565d + "'", double75 == 34.713109915419565d);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 0 + "'", int76 == 0);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 0.0d + "'", double77 == 0.0d);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 0.0d + "'", double78 == 0.0d);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        long long1 = org.apache.commons.math.util.MathUtils.sign(2L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.017453292519943295d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0176064912058516d + "'", double1 == 1.0176064912058516d);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 35);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.473814720414451d + "'", double1 == 0.473814720414451d);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        double[] doubleArray2 = new double[] { '#', (short) 0 };
        double[] doubleArray6 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray6);
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray10 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 10);
        double[] doubleArray11 = new double[] {};
        double[] doubleArray18 = new double[] { (byte) -1, (-1.0f), 100L, (-1L), '4', 4.9E-324d };
        double double19 = org.apache.commons.math.util.MathUtils.distance(doubleArray11, doubleArray18);
        double double20 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray18);
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, 32.0d);
        double[] doubleArray25 = new double[] { '#', (short) 0 };
        double[] doubleArray29 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equals(doubleArray25, doubleArray29);
        int int31 = org.apache.commons.math.util.MathUtils.hash(doubleArray25);
        double[] doubleArray33 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, (double) 10);
        double[] doubleArray36 = new double[] { '#', (short) 0 };
        double[] doubleArray40 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean41 = org.apache.commons.math.util.MathUtils.equals(doubleArray36, doubleArray40);
        int int42 = org.apache.commons.math.util.MathUtils.hash(doubleArray36);
        double[] doubleArray45 = new double[] { '#', (short) 0 };
        double[] doubleArray49 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean50 = org.apache.commons.math.util.MathUtils.equals(doubleArray45, doubleArray49);
        int int51 = org.apache.commons.math.util.MathUtils.hash(doubleArray45);
        double double52 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray36, doubleArray45);
        double double53 = org.apache.commons.math.util.MathUtils.distance1(doubleArray25, doubleArray36);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection54 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray25, orderDirection54, false);
        double double57 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray25);
        int int58 = org.apache.commons.math.util.MathUtils.hash(doubleArray25);
        double[] doubleArray61 = new double[] { '#', (short) 0 };
        double[] doubleArray65 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean66 = org.apache.commons.math.util.MathUtils.equals(doubleArray61, doubleArray65);
        double[] doubleArray69 = new double[] { '#', (short) 0 };
        double[] doubleArray73 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean74 = org.apache.commons.math.util.MathUtils.equals(doubleArray69, doubleArray73);
        int int75 = org.apache.commons.math.util.MathUtils.hash(doubleArray69);
        double double76 = org.apache.commons.math.util.MathUtils.distance(doubleArray61, doubleArray69);
        double double77 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray25, doubleArray61);
        boolean boolean78 = org.apache.commons.math.util.MathUtils.equals(doubleArray22, doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-940670015) + "'", int8 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 36.0d + "'", double20 == 36.0d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-940670015) + "'", int31 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-940670015) + "'", int42 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-940670015) + "'", int51 == (-940670015));
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection54 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection54.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 35.0d + "'", double57 == 35.0d);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + (-940670015) + "'", int58 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + (-940670015) + "'", int75 == (-940670015));
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.0d + "'", double76 == 0.0d);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 0.0d + "'", double77 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 32);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 32.00000000000001d + "'", double1 == 32.00000000000001d);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 96L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.564348191467836d + "'", double1 == 4.564348191467836d);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) (-97517567));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialLog((-2848));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 969932800);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 969932800, (long) 969932800);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 969932800L + "'", long2 == 969932800L);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(34.713109915419565d, 97, 89774434);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        float float2 = org.apache.commons.math.util.MathUtils.round((-1.0f), 97);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        double double1 = org.apache.commons.math.util.FastMath.sin(35.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.428182669496151d) + "'", double1 == (-0.428182669496151d));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 159);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, 0L);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) 159);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger7);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, (int) (byte) 100);
        try {
            java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (long) (-969932800));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(1076101121, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.738095699105435E83d + "'", double2 == 5.738095699105435E83d);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        double double1 = org.apache.commons.math.util.FastMath.abs((-0.9443504370351303d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9443504370351303d + "'", double1 == 0.9443504370351303d);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) (-338L), (int) (short) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-338.0f) + "'", float2 == (-338.0f));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(100.03269632610193d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7458999105381139d + "'", double1 == 1.7458999105381139d);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) 135, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 100);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(135, 1500625);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 202584375 + "'", int2 == 202584375);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        int[] intArray0 = null;
        int[] intArray4 = new int[] { (-1), '#', 11 };
        int[] intArray10 = new int[] { 0, 'a', '4', 160, (short) -1 };
        int int11 = org.apache.commons.math.util.MathUtils.distance1(intArray4, intArray10);
        int[] intArray18 = new int[] { (short) 1, (byte) 10, '#', (short) 10, 100, (-940670015) };
        double double19 = org.apache.commons.math.util.MathUtils.distance(intArray4, intArray18);
        int[] intArray23 = new int[] { (-1), '#', 11 };
        int[] intArray29 = new int[] { 0, 'a', '4', 160, (short) -1 };
        int int30 = org.apache.commons.math.util.MathUtils.distance1(intArray23, intArray29);
        int[] intArray37 = new int[] { (short) 1, (byte) 10, '#', (short) 10, 100, (-940670015) };
        double double38 = org.apache.commons.math.util.MathUtils.distance(intArray23, intArray37);
        int int39 = org.apache.commons.math.util.MathUtils.distance1(intArray4, intArray23);
        try {
            int int40 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 104 + "'", int11 == 104);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 34.713109915419565d + "'", double19 == 34.713109915419565d);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 104 + "'", int30 == 104);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 34.713109915419565d + "'", double38 == 34.713109915419565d);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) (-969932800));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        long long1 = org.apache.commons.math.util.MathUtils.sign(7766279631452241920L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-2L), (float) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        long long1 = org.apache.commons.math.util.FastMath.round((double) (-755042924));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-755042924L) + "'", long1 == (-755042924L));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (byte) 0, 0.20787957635076196d, 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        double double2 = org.apache.commons.math.util.MathUtils.round((double) (-755042924), 89);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-7.55042924E8d) + "'", double2 == (-7.55042924E8d));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        double[] doubleArray2 = new double[] { '#', (short) 0 };
        double[] doubleArray6 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray6);
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray10 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 10);
        double[] doubleArray13 = new double[] { '#', (short) 0 };
        double[] doubleArray17 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray17);
        int int19 = org.apache.commons.math.util.MathUtils.hash(doubleArray13);
        double[] doubleArray22 = new double[] { '#', (short) 0 };
        double[] doubleArray26 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equals(doubleArray22, doubleArray26);
        int int28 = org.apache.commons.math.util.MathUtils.hash(doubleArray22);
        double double29 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray13, doubleArray22);
        double double30 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray13);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection31 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2, orderDirection31, false);
        double double34 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray2);
        int int35 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray38 = new double[] { '#', (short) 0 };
        double[] doubleArray42 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equals(doubleArray38, doubleArray42);
        double[] doubleArray46 = new double[] { '#', (short) 0 };
        double[] doubleArray50 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean51 = org.apache.commons.math.util.MathUtils.equals(doubleArray46, doubleArray50);
        int int52 = org.apache.commons.math.util.MathUtils.hash(doubleArray46);
        double double53 = org.apache.commons.math.util.MathUtils.distance(doubleArray38, doubleArray46);
        double double54 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray38);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException61 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray62 = nonMonotonousSequenceException61.getSuppressed();
        java.lang.Number number63 = nonMonotonousSequenceException61.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException67 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray68 = nonMonotonousSequenceException67.getSuppressed();
        nonMonotonousSequenceException61.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException67);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection70 = nonMonotonousSequenceException61.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException72 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) Double.NEGATIVE_INFINITY, (java.lang.Number) 32.0d, (int) (byte) 1, orderDirection70, true);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2, orderDirection70, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not increasing (35 > 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-940670015) + "'", int8 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-940670015) + "'", int19 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-940670015) + "'", int28 == (-940670015));
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection31 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection31.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 35.0d + "'", double34 == 35.0d);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-940670015) + "'", int35 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-940670015) + "'", int52 == (-940670015));
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertNotNull(throwableArray62);
        org.junit.Assert.assertTrue("'" + number63 + "' != '" + 1.2676506002282294E30d + "'", number63.equals(1.2676506002282294E30d));
        org.junit.Assert.assertNotNull(throwableArray68);
        org.junit.Assert.assertTrue("'" + orderDirection70 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection70.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.0f), (java.lang.Number) 1.5533430342749532d, (int) (short) 0);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        boolean boolean5 = nonMonotonousSequenceException3.getStrict();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (1.553 >= -1)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (1.553 >= -1)"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(33.4425922753451d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.221810392107183d + "'", double1 == 3.221810392107183d);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        double double3 = org.apache.commons.math.util.MathUtils.round(0.0d, (int) (byte) -1, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        float float2 = org.apache.commons.math.util.MathUtils.round(0.0f, 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 1076101121);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.076101121E9d + "'", double1 == 1.076101121E9d);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 969932900L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 890.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 890.0d + "'", double1 == 890.0d);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        int int1 = org.apache.commons.math.util.MathUtils.hash(2.99822295029797d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 275437447 + "'", int1 == 275437447);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) (-1686110197));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1190.2238585049765d) + "'", double1 == (-1190.2238585049765d));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray7 = nonMonotonousSequenceException6.getSuppressed();
        java.lang.Number number8 = nonMonotonousSequenceException6.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray13 = nonMonotonousSequenceException12.getSuppressed();
        nonMonotonousSequenceException6.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = nonMonotonousSequenceException6.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray20 = nonMonotonousSequenceException19.getSuppressed();
        java.lang.Number number21 = nonMonotonousSequenceException19.getArgument();
        nonMonotonousSequenceException6.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException19);
        java.lang.Number number23 = nonMonotonousSequenceException6.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection24 = nonMonotonousSequenceException6.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection25 = nonMonotonousSequenceException6.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException27 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.5533430342749532d, (java.lang.Number) (-0.0d), (-1048576), orderDirection25, true);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 1.2676506002282294E30d + "'", number8.equals(1.2676506002282294E30d));
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertTrue("'" + orderDirection15 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection15.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray20);
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 1.2676506002282294E30d + "'", number21.equals(1.2676506002282294E30d));
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + 0.0d + "'", number23.equals(0.0d));
        org.junit.Assert.assertTrue("'" + orderDirection24 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection24.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection25 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection25.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) (-1686110197L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        double double1 = org.apache.commons.math.util.FastMath.ulp((-3.408679112792015d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.440892098500626E-16d + "'", double1 == 4.440892098500626E-16d);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) (-338));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        double[] doubleArray0 = null;
        double[] doubleArray3 = new double[] { '#', (short) 0 };
        double[] doubleArray7 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean8 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray7);
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray3);
        java.lang.Class<?> wildcardClass11 = doubleArray3.getClass();
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-940670015) + "'", int9 == (-940670015));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        double double1 = org.apache.commons.math.util.FastMath.atanh(890.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        double double1 = org.apache.commons.math.util.FastMath.atanh(6.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        double double1 = org.apache.commons.math.util.FastMath.expm1((-9.406700110730925E8d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        double double2 = org.apache.commons.math.util.FastMath.pow((-1190.2238585049765d), (double) 969932900L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(0, (-755042924));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (short) -1, (long) (short) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 2L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.6610060414837631d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8711009277842993d + "'", double1 == 0.8711009277842993d);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((-52), (int) (short) 1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        long long1 = org.apache.commons.math.util.FastMath.round(1.1752011936438014d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 96L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) 250L, 1076101121, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(35.0d, 0.9612994009271427d, (double) (-1963152028L));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 96L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5500.394833255903d + "'", double1 == 5500.394833255903d);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        float float2 = org.apache.commons.math.util.MathUtils.round(9.4067002E8f, (int) '#');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + Float.POSITIVE_INFINITY + "'", float2 == Float.POSITIVE_INFINITY);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) (-338));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(171662770176L, 141L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 8068150198272L + "'", long2 == 8068150198272L);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 89774434);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        int int1 = org.apache.commons.math.util.MathUtils.sign(1076101120);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) (-1010486975), (long) (-1048576));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(159, (-1963152018));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        int int1 = org.apache.commons.math.util.MathUtils.hash(0.0d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) (byte) 0, 160, 104);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((-97517567), 35);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-97517532) + "'", int2 == (-97517532));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1 == 100.0d);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 159L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (-755042924L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 7.5504294E8f + "'", float1 == 7.5504294E8f);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        int int1 = org.apache.commons.math.util.MathUtils.sign((int) (short) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 11L, 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 11.0f + "'", float2 == 11.0f);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray7 = new double[] { (byte) -1, (-1.0f), 100L, (-1L), '4', 4.9E-324d };
        double double8 = org.apache.commons.math.util.MathUtils.distance(doubleArray0, doubleArray7);
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1261225150) + "'", int9 == (-1261225150));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(36700160, 97);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1339.6200473439546d + "'", double2 == 1339.6200473439546d);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(0.48917865697472146d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1220529280716858d + "'", double1 == 1.1220529280716858d);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 52L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 52.0d + "'", double1 == 52.0d);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        double double1 = org.apache.commons.math.util.FastMath.sinh(Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 250L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 250.00000000000003d + "'", double1 == 250.00000000000003d);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        double double1 = org.apache.commons.math.util.FastMath.atanh((-178.0d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((int) (short) 1, (-1963152018));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.993222846126381d + "'", double1 == 2.993222846126381d);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((int) (short) -1, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 99 + "'", int2 == 99);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((-0.3304931400217347d), (double) 100L, 3628800.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialLog((-1686110197));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) (-1261225150));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        byte byte1 = org.apache.commons.math.util.MathUtils.indicator((byte) 0);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 1 + "'", byte1 == (byte) 1);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        double double1 = org.apache.commons.math.util.FastMath.floor(100.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1 == 100.0d);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        double double1 = org.apache.commons.math.util.FastMath.floor((-2.672865509299179d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-3.0d) + "'", double1 == (-3.0d));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.6178531763471193d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1970210409165452d + "'", double1 == 1.1970210409165452d);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(159, (-89));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        double double1 = org.apache.commons.math.util.FastMath.atan((-9.406700110730925E8d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5707963257318245d) + "'", double1 == (-1.5707963257318245d));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.6881171418161356E43d + "'", double1 == 2.6881171418161356E43d);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (short) 0, (float) 100);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm((-97517532), (-1686110197));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.String str5 = nonMonotonousSequenceException3.toString();
        java.lang.Number number6 = nonMonotonousSequenceException3.getArgument();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (0 >= 1,267,650,600,228,229,400,000,000,000,000)" + "'", str5.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (0 >= 1,267,650,600,228,229,400,000,000,000,000)"));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 1.2676506002282294E30d + "'", number6.equals(1.2676506002282294E30d));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (-7766279631452241920L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-2147483648) + "'", int1 == (-2147483648));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 89);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        long long2 = org.apache.commons.math.util.FastMath.min(969932900L, (long) 1076101121);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 969932900L + "'", long2 == 969932900L);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 89);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 89 + "'", int1 == 89);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 89L, (-1963152018), 35);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 35, (-1686110197L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        double[] doubleArray2 = new double[] { '#', (short) 0 };
        double[] doubleArray6 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray6);
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray11 = new double[] { '#', (short) 0 };
        double[] doubleArray15 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray15);
        int int17 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        double double18 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray11);
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, 35.0d);
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) '4');
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray22);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (52 >= 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-940670015) + "'", int8 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-940670015) + "'", int17 == (-940670015));
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        int[] intArray3 = new int[] { (-1), '#', 11 };
        int[] intArray9 = new int[] { 0, 'a', '4', 160, (short) -1 };
        int int10 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray9);
        int[] intArray14 = new int[] { (-1), '#', 11 };
        int[] intArray20 = new int[] { 0, 'a', '4', 160, (short) -1 };
        int int21 = org.apache.commons.math.util.MathUtils.distance1(intArray14, intArray20);
        int[] intArray28 = new int[] { (short) 1, (byte) 10, '#', (short) 10, 100, (-940670015) };
        double double29 = org.apache.commons.math.util.MathUtils.distance(intArray14, intArray28);
        int[] intArray33 = new int[] { (-1), '#', 11 };
        int[] intArray39 = new int[] { 0, 'a', '4', 160, (short) -1 };
        int int40 = org.apache.commons.math.util.MathUtils.distance1(intArray33, intArray39);
        int[] intArray47 = new int[] { (short) 1, (byte) 10, '#', (short) 10, 100, (-940670015) };
        double double48 = org.apache.commons.math.util.MathUtils.distance(intArray33, intArray47);
        int int49 = org.apache.commons.math.util.MathUtils.distance1(intArray14, intArray33);
        int[] intArray53 = new int[] { (-1), '#', 11 };
        int[] intArray59 = new int[] { 0, 'a', '4', 160, (short) -1 };
        int int60 = org.apache.commons.math.util.MathUtils.distance1(intArray53, intArray59);
        int[] intArray67 = new int[] { (short) 1, (byte) 10, '#', (short) 10, 100, (-940670015) };
        double double68 = org.apache.commons.math.util.MathUtils.distance(intArray53, intArray67);
        int[] intArray72 = new int[] { (-1), '#', 11 };
        int[] intArray78 = new int[] { 0, 'a', '4', 160, (short) -1 };
        int int79 = org.apache.commons.math.util.MathUtils.distance1(intArray72, intArray78);
        int[] intArray86 = new int[] { (short) 1, (byte) 10, '#', (short) 10, 100, (-940670015) };
        double double87 = org.apache.commons.math.util.MathUtils.distance(intArray72, intArray86);
        int int88 = org.apache.commons.math.util.MathUtils.distance1(intArray53, intArray72);
        double double89 = org.apache.commons.math.util.MathUtils.distance(intArray14, intArray72);
        int int90 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray72);
        int[] intArray91 = null;
        try {
            int int92 = org.apache.commons.math.util.MathUtils.distanceInf(intArray3, intArray91);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 104 + "'", int10 == 104);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 104 + "'", int21 == 104);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 34.713109915419565d + "'", double29 == 34.713109915419565d);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 104 + "'", int40 == 104);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 34.713109915419565d + "'", double48 == 34.713109915419565d);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 104 + "'", int60 == 104);
        org.junit.Assert.assertNotNull(intArray67);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 34.713109915419565d + "'", double68 == 34.713109915419565d);
        org.junit.Assert.assertNotNull(intArray72);
        org.junit.Assert.assertNotNull(intArray78);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 104 + "'", int79 == 104);
        org.junit.Assert.assertNotNull(intArray86);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 34.713109915419565d + "'", double87 == 34.713109915419565d);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 0 + "'", int88 == 0);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 0.0d + "'", double89 == 0.0d);
        org.junit.Assert.assertTrue("'" + int90 + "' != '" + 0 + "'", int90 == 0);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((-97517532), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97517532 + "'", int2 == 97517532);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4711276743037347d + "'", double1 == 1.4711276743037347d);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(382.2585887730602d, (double) (-338));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 382.2585887730601d + "'", double2 == 382.2585887730601d);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        int int2 = org.apache.commons.math.util.FastMath.min((-1686110207), 1076101121);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1686110207) + "'", int2 == (-1686110207));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 104);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.337561192805306d + "'", double1 == 5.337561192805306d);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 1079640064, (long) 159);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1079640064L + "'", long2 == 1079640064L);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(0.16087055809932455d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.16156532704823662d + "'", double1 == 0.16156532704823662d);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.026931837701290245d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog((int) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 15.104412573075516d + "'", double1 == 15.104412573075516d);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(22026.465794806718d, 3.093102195050827d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.9012931422694237d + "'", double2 == 3.9012931422694237d);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        long long1 = org.apache.commons.math.util.FastMath.round(1.1102230246251565E-16d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(0.6557942026326724d, (int) ' ', 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((-1), (-97517532));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97517532 + "'", int2 == 97517532);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        long long1 = org.apache.commons.math.util.FastMath.abs(11L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 11L + "'", long1 == 11L);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        double double1 = org.apache.commons.math.util.FastMath.log(1.3887306754369975E43d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 99.33954914554198d + "'", double1 == 99.33954914554198d);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 100, (java.lang.Number) (-1.0d), (int) (short) 10);
        int int4 = nonMonotonousSequenceException3.getIndex();
        java.lang.String str5 = nonMonotonousSequenceException3.toString();
        java.lang.String str6 = nonMonotonousSequenceException3.toString();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (-1 >= 100)" + "'", str5.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (-1 >= 100)"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (-1 >= 100)" + "'", str6.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (-1 >= 100)"));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (-1074790241));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.07479027E9f + "'", float1 == 1.07479027E9f);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(1076101120, 89774434);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 986326686 + "'", int2 == 986326686);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 0, 969932900L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        double[] doubleArray2 = new double[] { '#', (short) 0 };
        double[] doubleArray6 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray6);
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray10 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 10);
        double[] doubleArray13 = new double[] { '#', (short) 0 };
        double[] doubleArray17 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray17);
        int int19 = org.apache.commons.math.util.MathUtils.hash(doubleArray13);
        double[] doubleArray22 = new double[] { '#', (short) 0 };
        double[] doubleArray26 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equals(doubleArray22, doubleArray26);
        int int28 = org.apache.commons.math.util.MathUtils.hash(doubleArray22);
        double double29 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray13, doubleArray22);
        double double30 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray13);
        double[] doubleArray33 = new double[] { '#', (short) 0 };
        double[] doubleArray37 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equals(doubleArray33, doubleArray37);
        int int39 = org.apache.commons.math.util.MathUtils.hash(doubleArray33);
        double[] doubleArray41 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray33, 5.428835233189813d);
        double[] doubleArray44 = new double[] { '#', (short) 0 };
        double[] doubleArray48 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean49 = org.apache.commons.math.util.MathUtils.equals(doubleArray44, doubleArray48);
        int int50 = org.apache.commons.math.util.MathUtils.hash(doubleArray44);
        double[] doubleArray52 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray44, (double) 10);
        double[] doubleArray53 = null;
        double[] doubleArray56 = new double[] { '#', (short) 0 };
        double[] doubleArray60 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equals(doubleArray56, doubleArray60);
        int int62 = org.apache.commons.math.util.MathUtils.hash(doubleArray56);
        boolean boolean63 = org.apache.commons.math.util.MathUtils.equals(doubleArray53, doubleArray56);
        double[] doubleArray66 = new double[] { '#', (short) 0 };
        double[] doubleArray70 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean71 = org.apache.commons.math.util.MathUtils.equals(doubleArray66, doubleArray70);
        int int72 = org.apache.commons.math.util.MathUtils.hash(doubleArray66);
        double[] doubleArray74 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray66, (double) 10);
        double[] doubleArray77 = new double[] { '#', (short) 0 };
        double[] doubleArray81 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean82 = org.apache.commons.math.util.MathUtils.equals(doubleArray77, doubleArray81);
        int int83 = org.apache.commons.math.util.MathUtils.hash(doubleArray77);
        double[] doubleArray86 = new double[] { '#', (short) 0 };
        double[] doubleArray90 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean91 = org.apache.commons.math.util.MathUtils.equals(doubleArray86, doubleArray90);
        int int92 = org.apache.commons.math.util.MathUtils.hash(doubleArray86);
        double double93 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray77, doubleArray86);
        double double94 = org.apache.commons.math.util.MathUtils.distance1(doubleArray66, doubleArray77);
        boolean boolean95 = org.apache.commons.math.util.MathUtils.equals(doubleArray56, doubleArray77);
        double double96 = org.apache.commons.math.util.MathUtils.distance(doubleArray44, doubleArray77);
        double double97 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray41, doubleArray44);
        double double98 = org.apache.commons.math.util.MathUtils.distance(doubleArray13, doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-940670015) + "'", int8 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-940670015) + "'", int19 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-940670015) + "'", int28 == (-940670015));
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-940670015) + "'", int39 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-940670015) + "'", int50 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + (-940670015) + "'", int62 == (-940670015));
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + (-940670015) + "'", int72 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + (-940670015) + "'", int83 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertNotNull(doubleArray90);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + (-940670015) + "'", int92 == (-940670015));
        org.junit.Assert.assertTrue("'" + double93 + "' != '" + 0.0d + "'", double93 == 0.0d);
        org.junit.Assert.assertTrue("'" + double94 + "' != '" + 0.0d + "'", double94 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + true + "'", boolean95 == true);
        org.junit.Assert.assertTrue("'" + double96 + "' != '" + 0.0d + "'", double96 == 0.0d);
        org.junit.Assert.assertTrue("'" + double97 + "' != '" + 29.57116476681019d + "'", double97 == 29.57116476681019d);
        org.junit.Assert.assertTrue("'" + double98 + "' != '" + 0.0d + "'", double98 == 0.0d);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) (-32L), 1500625);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        long long2 = org.apache.commons.math.util.FastMath.max(1079640064L, (long) (-923401279));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1079640064L + "'", long2 == 1079640064L);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(0, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        double double1 = org.apache.commons.math.util.FastMath.log10((-0.6870488395497887d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((-42L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        double double2 = org.apache.commons.math.util.FastMath.max(1.6917246050779422d, (double) (-969932800L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.6917246050779422d + "'", double2 == 1.6917246050779422d);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 160);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.428835233189813d + "'", double1 == 5.428835233189813d);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(29.732168412300734d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0979580174357335d + "'", double1 == 3.0979580174357335d);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.1622776601683795d + "'", double1 == 3.1622776601683795d);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        double double1 = org.apache.commons.math.util.FastMath.sin(2.993222846126381d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.14782604738794858d + "'", double1 == 0.14782604738794858d);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        double[] doubleArray0 = null;
        double[] doubleArray3 = new double[] { '#', (short) 0 };
        double[] doubleArray7 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean8 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray7);
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray3);
        int int11 = org.apache.commons.math.util.MathUtils.hash(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-940670015) + "'", int9 == (-940670015));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(0L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 0, 0.0d, 10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((int) (short) 1, (-755042924));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 755042925 + "'", int2 == 755042925);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(0.0d, (double) 1079640064L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.0013384866692687d, (double) 89774434, (int) '#');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((int) ' ', 32);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1024 + "'", int2 == 1024);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(135, 11);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1485 + "'", int2 == 1485);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.48917865697472146d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.008537778194692813d + "'", double1 == 0.008537778194692813d);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((int) '4', 62);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 135);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5633890548637315d + "'", double1 == 1.5633890548637315d);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        double[] doubleArray2 = new double[] { '#', (short) 0 };
        double[] doubleArray6 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray6);
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray10 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, 5.428835233189813d);
        double[] doubleArray13 = new double[] { '#', (short) 0 };
        double[] doubleArray17 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray17);
        int int19 = org.apache.commons.math.util.MathUtils.hash(doubleArray13);
        double[] doubleArray21 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray13, (double) 10);
        double[] doubleArray22 = null;
        double[] doubleArray25 = new double[] { '#', (short) 0 };
        double[] doubleArray29 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equals(doubleArray25, doubleArray29);
        int int31 = org.apache.commons.math.util.MathUtils.hash(doubleArray25);
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equals(doubleArray22, doubleArray25);
        double[] doubleArray35 = new double[] { '#', (short) 0 };
        double[] doubleArray39 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equals(doubleArray35, doubleArray39);
        int int41 = org.apache.commons.math.util.MathUtils.hash(doubleArray35);
        double[] doubleArray43 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray35, (double) 10);
        double[] doubleArray46 = new double[] { '#', (short) 0 };
        double[] doubleArray50 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean51 = org.apache.commons.math.util.MathUtils.equals(doubleArray46, doubleArray50);
        int int52 = org.apache.commons.math.util.MathUtils.hash(doubleArray46);
        double[] doubleArray55 = new double[] { '#', (short) 0 };
        double[] doubleArray59 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean60 = org.apache.commons.math.util.MathUtils.equals(doubleArray55, doubleArray59);
        int int61 = org.apache.commons.math.util.MathUtils.hash(doubleArray55);
        double double62 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray46, doubleArray55);
        double double63 = org.apache.commons.math.util.MathUtils.distance1(doubleArray35, doubleArray46);
        boolean boolean64 = org.apache.commons.math.util.MathUtils.equals(doubleArray25, doubleArray46);
        double double65 = org.apache.commons.math.util.MathUtils.distance(doubleArray13, doubleArray46);
        double double66 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray10, doubleArray13);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray13);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (35 >= 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-940670015) + "'", int8 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-940670015) + "'", int19 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-940670015) + "'", int31 == (-940670015));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-940670015) + "'", int41 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-940670015) + "'", int52 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-940670015) + "'", int61 == (-940670015));
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 29.57116476681019d + "'", double66 == 29.57116476681019d);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        double double1 = org.apache.commons.math.util.FastMath.sinh((-1.875862901480542E7d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (-1686110197));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.68611021E9f + "'", float1 == 1.68611021E9f);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) (-1686110197L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        double double1 = org.apache.commons.math.util.FastMath.log10(1.0176064912058516d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.007579868632454668d + "'", double1 == 0.007579868632454668d);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        double[] doubleArray2 = new double[] { '#', (short) 0 };
        double[] doubleArray6 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray6);
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray10 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, 5.428835233189813d);
        double[] doubleArray13 = new double[] { '#', (short) 0 };
        double[] doubleArray17 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray17);
        int int19 = org.apache.commons.math.util.MathUtils.hash(doubleArray13);
        double[] doubleArray21 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray13, (double) 10);
        double[] doubleArray22 = null;
        double[] doubleArray25 = new double[] { '#', (short) 0 };
        double[] doubleArray29 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equals(doubleArray25, doubleArray29);
        int int31 = org.apache.commons.math.util.MathUtils.hash(doubleArray25);
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equals(doubleArray22, doubleArray25);
        double[] doubleArray35 = new double[] { '#', (short) 0 };
        double[] doubleArray39 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equals(doubleArray35, doubleArray39);
        int int41 = org.apache.commons.math.util.MathUtils.hash(doubleArray35);
        double[] doubleArray43 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray35, (double) 10);
        double[] doubleArray46 = new double[] { '#', (short) 0 };
        double[] doubleArray50 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean51 = org.apache.commons.math.util.MathUtils.equals(doubleArray46, doubleArray50);
        int int52 = org.apache.commons.math.util.MathUtils.hash(doubleArray46);
        double[] doubleArray55 = new double[] { '#', (short) 0 };
        double[] doubleArray59 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean60 = org.apache.commons.math.util.MathUtils.equals(doubleArray55, doubleArray59);
        int int61 = org.apache.commons.math.util.MathUtils.hash(doubleArray55);
        double double62 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray46, doubleArray55);
        double double63 = org.apache.commons.math.util.MathUtils.distance1(doubleArray35, doubleArray46);
        boolean boolean64 = org.apache.commons.math.util.MathUtils.equals(doubleArray25, doubleArray46);
        double double65 = org.apache.commons.math.util.MathUtils.distance(doubleArray13, doubleArray46);
        double double66 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray10, doubleArray13);
        double[] doubleArray69 = new double[] { '#', (short) 0 };
        double[] doubleArray73 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean74 = org.apache.commons.math.util.MathUtils.equals(doubleArray69, doubleArray73);
        int int75 = org.apache.commons.math.util.MathUtils.hash(doubleArray69);
        double[] doubleArray78 = new double[] { '#', (short) 0 };
        double[] doubleArray82 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean83 = org.apache.commons.math.util.MathUtils.equals(doubleArray78, doubleArray82);
        int int84 = org.apache.commons.math.util.MathUtils.hash(doubleArray78);
        double double85 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray69, doubleArray78);
        double[] doubleArray87 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray69, 35.0d);
        double[] doubleArray89 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray69, (double) '4');
        double double90 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray13, doubleArray69);
        int int91 = org.apache.commons.math.util.MathUtils.hash(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-940670015) + "'", int8 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-940670015) + "'", int19 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-940670015) + "'", int31 == (-940670015));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-940670015) + "'", int41 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-940670015) + "'", int52 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-940670015) + "'", int61 == (-940670015));
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 29.57116476681019d + "'", double66 == 29.57116476681019d);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + (-940670015) + "'", int75 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + (-940670015) + "'", int84 == (-940670015));
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 0.0d + "'", double85 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + 0.0d + "'", double90 == 0.0d);
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + (-940670015) + "'", int91 == (-940670015));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(1.0796400640000002E9d, 35.00000000000001d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 37.357622385025024d + "'", double2 == 37.357622385025024d);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 159);
        try {
            java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) (-1963152018));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) (-755042924L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1920928955078125E-7d + "'", double1 == 1.1920928955078125E-7d);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-102083904936L), (float) 97517532);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 9.7517536E7f + "'", float2 == 9.7517536E7f);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.0d, 1.2127883429123472d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(0, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) (-1686110197L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.30782500324939893d) + "'", double1 == (-0.30782500324939893d));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        int[] intArray3 = new int[] { (-1), '#', 11 };
        int[] intArray9 = new int[] { 0, 'a', '4', 160, (short) -1 };
        int int10 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray9);
        int[] intArray17 = new int[] { (short) 1, (byte) 10, '#', (short) 10, 100, (-940670015) };
        double double18 = org.apache.commons.math.util.MathUtils.distance(intArray3, intArray17);
        int[] intArray22 = new int[] { (-1), '#', 11 };
        int[] intArray28 = new int[] { 0, 'a', '4', 160, (short) -1 };
        int int29 = org.apache.commons.math.util.MathUtils.distance1(intArray22, intArray28);
        int[] intArray36 = new int[] { (short) 1, (byte) 10, '#', (short) 10, 100, (-940670015) };
        double double37 = org.apache.commons.math.util.MathUtils.distance(intArray22, intArray36);
        int[] intArray41 = new int[] { (-1), '#', 11 };
        int[] intArray47 = new int[] { 0, 'a', '4', 160, (short) -1 };
        int int48 = org.apache.commons.math.util.MathUtils.distance1(intArray41, intArray47);
        int[] intArray55 = new int[] { (short) 1, (byte) 10, '#', (short) 10, 100, (-940670015) };
        double double56 = org.apache.commons.math.util.MathUtils.distance(intArray41, intArray55);
        int[] intArray60 = new int[] { (-1), '#', 11 };
        int[] intArray66 = new int[] { 0, 'a', '4', 160, (short) -1 };
        int int67 = org.apache.commons.math.util.MathUtils.distance1(intArray60, intArray66);
        int[] intArray74 = new int[] { (short) 1, (byte) 10, '#', (short) 10, 100, (-940670015) };
        double double75 = org.apache.commons.math.util.MathUtils.distance(intArray60, intArray74);
        int int76 = org.apache.commons.math.util.MathUtils.distance1(intArray41, intArray60);
        double double77 = org.apache.commons.math.util.MathUtils.distance(intArray22, intArray41);
        int int78 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray41);
        int[] intArray82 = new int[] { (-1), '#', 11 };
        int[] intArray88 = new int[] { 0, 'a', '4', 160, (short) -1 };
        int int89 = org.apache.commons.math.util.MathUtils.distance1(intArray82, intArray88);
        int[] intArray96 = new int[] { (short) 1, (byte) 10, '#', (short) 10, 100, (-940670015) };
        double double97 = org.apache.commons.math.util.MathUtils.distance(intArray82, intArray96);
        int int98 = org.apache.commons.math.util.MathUtils.distanceInf(intArray3, intArray96);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 104 + "'", int10 == 104);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 34.713109915419565d + "'", double18 == 34.713109915419565d);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 104 + "'", int29 == 104);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 34.713109915419565d + "'", double37 == 34.713109915419565d);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 104 + "'", int48 == 104);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 34.713109915419565d + "'", double56 == 34.713109915419565d);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 104 + "'", int67 == 104);
        org.junit.Assert.assertNotNull(intArray74);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 34.713109915419565d + "'", double75 == 34.713109915419565d);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 0 + "'", int76 == 0);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 0.0d + "'", double77 == 0.0d);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 0 + "'", int78 == 0);
        org.junit.Assert.assertNotNull(intArray82);
        org.junit.Assert.assertNotNull(intArray88);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 104 + "'", int89 == 104);
        org.junit.Assert.assertNotNull(intArray96);
        org.junit.Assert.assertTrue("'" + double97 + "' != '" + 34.713109915419565d + "'", double97 == 34.713109915419565d);
        org.junit.Assert.assertTrue("'" + int98 + "' != '" + 25 + "'", int98 == 25);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        double double1 = org.apache.commons.math.util.FastMath.acos(3.670016E7d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        double[] doubleArray2 = new double[] { '#', (short) 0 };
        double[] doubleArray6 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray6);
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray9 = null;
        try {
            double double10 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-940670015) + "'", int8 == (-940670015));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        double double1 = org.apache.commons.math.util.FastMath.atanh(Double.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        float float2 = org.apache.commons.math.util.FastMath.max(0.0f, (float) (-1074790400));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0747904E9f) + "'", float2 == (-1.0747904E9f));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 11L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 11 + "'", int1 == 11);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 1048576, 0, 32);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        double double1 = org.apache.commons.math.util.FastMath.ulp(3.670016E7d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.450580596923828E-9d + "'", double1 == 7.450580596923828E-9d);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        double[] doubleArray2 = new double[] { '#', (short) 0 };
        double[] doubleArray6 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray6);
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray10 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 10);
        double[] doubleArray13 = new double[] { '#', (short) 0 };
        double[] doubleArray17 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray17);
        int int19 = org.apache.commons.math.util.MathUtils.hash(doubleArray13);
        double[] doubleArray22 = new double[] { '#', (short) 0 };
        double[] doubleArray26 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equals(doubleArray22, doubleArray26);
        int int28 = org.apache.commons.math.util.MathUtils.hash(doubleArray22);
        double double29 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray13, doubleArray22);
        double double30 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray13);
        double[] doubleArray33 = new double[] { '#', (short) 0 };
        double[] doubleArray37 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equals(doubleArray33, doubleArray37);
        int int39 = org.apache.commons.math.util.MathUtils.hash(doubleArray33);
        double[] doubleArray41 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray33, (double) 10);
        double[] doubleArray42 = null;
        double[] doubleArray45 = new double[] { '#', (short) 0 };
        double[] doubleArray49 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean50 = org.apache.commons.math.util.MathUtils.equals(doubleArray45, doubleArray49);
        int int51 = org.apache.commons.math.util.MathUtils.hash(doubleArray45);
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equals(doubleArray42, doubleArray45);
        double[] doubleArray55 = new double[] { '#', (short) 0 };
        double[] doubleArray59 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean60 = org.apache.commons.math.util.MathUtils.equals(doubleArray55, doubleArray59);
        int int61 = org.apache.commons.math.util.MathUtils.hash(doubleArray55);
        double[] doubleArray63 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray55, (double) 10);
        double[] doubleArray66 = new double[] { '#', (short) 0 };
        double[] doubleArray70 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean71 = org.apache.commons.math.util.MathUtils.equals(doubleArray66, doubleArray70);
        int int72 = org.apache.commons.math.util.MathUtils.hash(doubleArray66);
        double[] doubleArray75 = new double[] { '#', (short) 0 };
        double[] doubleArray79 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean80 = org.apache.commons.math.util.MathUtils.equals(doubleArray75, doubleArray79);
        int int81 = org.apache.commons.math.util.MathUtils.hash(doubleArray75);
        double double82 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray66, doubleArray75);
        double double83 = org.apache.commons.math.util.MathUtils.distance1(doubleArray55, doubleArray66);
        boolean boolean84 = org.apache.commons.math.util.MathUtils.equals(doubleArray45, doubleArray66);
        double double85 = org.apache.commons.math.util.MathUtils.distance(doubleArray33, doubleArray66);
        boolean boolean86 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray33);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray33);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (35 >= 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-940670015) + "'", int8 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-940670015) + "'", int19 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-940670015) + "'", int28 == (-940670015));
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-940670015) + "'", int39 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-940670015) + "'", int51 == (-940670015));
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-940670015) + "'", int61 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + (-940670015) + "'", int72 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + (-940670015) + "'", int81 == (-940670015));
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 0.0d + "'", double82 == 0.0d);
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + 0.0d + "'", double83 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + true + "'", boolean84 == true);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 0.0d + "'", double85 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + true + "'", boolean86 == true);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 2L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(0, 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(1485);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 159);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, 0L);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) 159);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger7);
        java.math.BigInteger bigInteger11 = null;
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, 0L);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (long) 159);
        java.math.BigInteger bigInteger16 = null;
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, 0L);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, (long) 159);
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, bigInteger18);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger18);
        try {
            java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, (-1686110207));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger22);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) (-1010486975), (long) (byte) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 104);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 104L + "'", long1 == 104L);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        double double1 = org.apache.commons.math.util.FastMath.exp(1.5707963267948966d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.810477380965351d + "'", double1 == 4.810477380965351d);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) (-940669124L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow((-1), (long) (-1));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(4.547473508864641E-13d, (-940670015), (-1048576));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(0.9443504370351303d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-755042924), (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(2.792526803190927d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.671085516420667d + "'", double1 == 1.671085516420667d);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(36700160, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) 11.0f, 1500625, 1079640064);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        long long1 = org.apache.commons.math.util.FastMath.round((-1.2256386769522283d));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow(986326686, (-2848));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 275437447, 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((-716177407L), (long) (-1686110207));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(0L, (long) 89774434);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(2);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        long long2 = org.apache.commons.math.util.FastMath.max(0L, 104L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 104L + "'", long2 == 104L);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray10 = nonMonotonousSequenceException9.getSuppressed();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException9);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = nonMonotonousSequenceException3.getDirection();
        java.lang.String str13 = nonMonotonousSequenceException3.toString();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = nonMonotonousSequenceException3.getDirection();
        boolean boolean15 = nonMonotonousSequenceException3.getStrict();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1.2676506002282294E30d + "'", number5.equals(1.2676506002282294E30d));
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (0 >= 1,267,650,600,228,229,400,000,000,000,000)" + "'", str13.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (0 >= 1,267,650,600,228,229,400,000,000,000,000)"));
        org.junit.Assert.assertTrue("'" + orderDirection14 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection14.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (-755042924), 1485);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(97517532, (-52));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(382.2585887730601d, (double) (-1208867745));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 382.25858877306007d + "'", double2 == 382.25858877306007d);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.7071067811865476d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 40.51423422706978d + "'", double1 == 40.51423422706978d);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow((-969932800), (long) (-1686110207));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 1076101121);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        double double2 = org.apache.commons.math.util.FastMath.min((double) (-1L), (double) (-32L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-32.0d) + "'", double2 == (-32.0d));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (-338));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-338) + "'", int1 == (-338));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1752011936438014d + "'", double1 == 1.1752011936438014d);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        double double1 = org.apache.commons.math.util.FastMath.abs((-1.9631520179999998E9d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9631520179999998E9d + "'", double1 == 1.9631520179999998E9d);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) (-940670014L), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.5707963267948966d) + "'", double2 == (-1.5707963267948966d));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((-940669124L), 10L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-940669114L) + "'", long2 == (-940669114L));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 35, (double) 890.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.910142507926831d + "'", double2 == 1.910142507926831d);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) 986326686, (long) 275437447);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 271671304299810642L + "'", long2 == 271671304299810642L);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        long long2 = org.apache.commons.math.util.MathUtils.pow((-7766279631452241820L), 11);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1753482154622320640L + "'", long2 == 1753482154622320640L);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        float float1 = org.apache.commons.math.util.MathUtils.sign((-7.7662794E18f));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        double double2 = org.apache.commons.math.util.MathUtils.log(0.0d, (double) (-97517532));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((-1048576), (-97517567));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(1485, (-1686110197));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) (short) -1, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((-1.2676506002282295E-178d), 1.2483666764136787d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 171662770176L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.71662770176E11d + "'", double1 == 1.71662770176E11d);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 159);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, 0L);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) 159);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger7);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, (int) (byte) 100);
        try {
            java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, (long) (-1686110197));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.4210804127942926d, (java.lang.Number) 0.6557942026326724d, (int) (byte) -1);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection5 = nonMonotonousSequenceException3.getDirection();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + orderDirection5 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection5.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        double double1 = org.apache.commons.math.util.FastMath.sin(1.3766190333333037d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9812067505177319d + "'", double1 == 0.9812067505177319d);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        double[] doubleArray2 = new double[] { '#', (short) 0 };
        double[] doubleArray6 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray6);
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray11 = new double[] { '#', (short) 0 };
        double[] doubleArray15 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray15);
        int int17 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        double double18 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray11);
        double[] doubleArray21 = new double[] { '#', (short) 0 };
        double[] doubleArray25 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equals(doubleArray21, doubleArray25);
        int int27 = org.apache.commons.math.util.MathUtils.hash(doubleArray21);
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray21, (double) 10);
        double[] doubleArray32 = new double[] { '#', (short) 0 };
        double[] doubleArray36 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equals(doubleArray32, doubleArray36);
        int int38 = org.apache.commons.math.util.MathUtils.hash(doubleArray32);
        double[] doubleArray41 = new double[] { '#', (short) 0 };
        double[] doubleArray45 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equals(doubleArray41, doubleArray45);
        int int47 = org.apache.commons.math.util.MathUtils.hash(doubleArray41);
        double double48 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray32, doubleArray41);
        double double49 = org.apache.commons.math.util.MathUtils.distance1(doubleArray21, doubleArray32);
        double double50 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray32);
        double double51 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-940670015) + "'", int8 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-940670015) + "'", int17 == (-940670015));
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-940670015) + "'", int27 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-940670015) + "'", int38 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-940670015) + "'", int47 == (-940670015));
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 35.0d + "'", double51 == 35.0d);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(1.2605918365213562d, (-3.0d));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        double[] doubleArray2 = new double[] { '#', (short) 0 };
        double[] doubleArray6 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray6);
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray10 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 10);
        double[] doubleArray13 = new double[] { '#', (short) 0 };
        double[] doubleArray17 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray17);
        int int19 = org.apache.commons.math.util.MathUtils.hash(doubleArray13);
        double[] doubleArray21 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray13, (double) 10);
        int int22 = org.apache.commons.math.util.MathUtils.hash(doubleArray13);
        double double23 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray10, doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-940670015) + "'", int8 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-940670015) + "'", int19 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-940670015) + "'", int22 == (-940670015));
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 25.0d + "'", double23 == 25.0d);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) (-89), 1686110207L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(62, 89);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5518 + "'", int2 == 5518);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        long long2 = org.apache.commons.math.util.MathUtils.pow(2L, (long) 159);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        double double1 = org.apache.commons.math.util.FastMath.atan(2.99822295029797d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.248867972642223d + "'", double1 == 1.248867972642223d);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round(0.0f, 36700160, (int) (short) 100);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.644298430695373d + "'", double1 == 4.644298430695373d);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (-2147483648), (long) 97517532);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2147483648L) + "'", long2 == (-2147483648L));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 1076101120);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 21.489757452525488d + "'", double1 == 21.489757452525488d);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-1), (-97517567));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97517567 + "'", int2 == 97517567);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(2.1017612416682803d, 23081.80592729469d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 202584375);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray10 = nonMonotonousSequenceException9.getSuppressed();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException9);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = nonMonotonousSequenceException9.getDirection();
        java.lang.Class<?> wildcardClass13 = orderDirection12.getClass();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1.2676506002282294E30d + "'", number5.equals(1.2676506002282294E30d));
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        int int1 = org.apache.commons.math.util.MathUtils.sign(1485);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        double double3 = org.apache.commons.math.util.MathUtils.round((double) (-42.0f), 11, 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-42.0d) + "'", double3 == (-42.0d));
    }
}

